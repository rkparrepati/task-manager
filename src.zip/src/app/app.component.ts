import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy {
  title = 'cedrinfra';
  private resizeObserver: ResizeObserver | null = null;

  constructor(private elementRef: ElementRef, private cdr: ChangeDetectorRef) {
    setTheme('bs4'); // or 'bs4'
  }

  ngOnInit() {
    // Prevent scroll position from changing during initial load
    window.scrollTo(0, 0);
    
    // Lock scroll position during initial render
    document.documentElement.style.scrollBehavior = 'auto';
    document.body.style.scrollBehavior = 'auto';
  }

  ngAfterViewInit() {
    // Ensure scroll position is at top after view initialization
    setTimeout(() => {
      window.scrollTo(0, 0);
    }, 0);

    // Monitor content size changes to prevent scroll jumps
    const container = this.elementRef.nativeElement.querySelector('.container-fluid');
    if (container && typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => {
        // Keep scroll at top when content resizes
        window.scrollTo(0, 0);
      });
      this.resizeObserver.observe(container);
    }
  }

  ngOnDestroy() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
  }
}
