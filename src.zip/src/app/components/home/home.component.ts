import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OKTA_AUTH } from '@okta/okta-angular';
import { OktaAuth } from '@okta/okta-auth-js';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  constructor(
    @Inject(OKTA_AUTH) private oktaAuth: OktaAuth,
    private router: Router
  ) {}

  ngOnInit() {
    if (!this.isLoggedIn() && this.isLocalhost()) {
      this.oktaAuth.signInWithRedirect({ originalUri: this.router.url });
    }
  }

  private isLocalhost() {
    return window.location.hostname === 'localhost';
  }

  private isLoggedIn() {
    const state = this.oktaAuth.authStateManager.getAuthState();
    return !!state?.isAuthenticated;
  }
}
