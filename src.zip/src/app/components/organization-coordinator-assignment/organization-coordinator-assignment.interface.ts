export interface OrganizationCoordinatorAssignment {
  locationCoordinatorId: string;
  organization: {
    id: string;
    businessAreaCode: string;
    shortName: string;
    name: string;
  };
  worker: {
    workerId: string;
  };
  lifecycle: {
    beginDate: string;
    endDate: string | null;
  };
  selected?: boolean;
  audit?: {
    lastModifiedLoginId: string;
    lastModifiedDate: string;
  };
}

export interface OrganizationAssignmentResponse {
  results: OrganizationCoordinatorAssignment[];
  meta: {
    total: number;
  };
}

export interface WorkerInfo {
  workerId: string;
  preferredFirstName: string;
  familyName: string;
  loginId: string;
  activeEmploymentIndicator: boolean;
}

export interface WorkerResponse {
  results: WorkerInfo[];
}

export interface SearchOptions {
  workerNumber?: string;
  includeInactive?: boolean;
  businessAreaCode?: string;
  fromShortName?: string;
  toShortName?: string;
  activeOnly?: string;
}

export interface ComponentState {
  invalidWorkerNumber: boolean;
  searchResults: string;
  searchResultsMode: boolean;
  orgnizationAssignments: OrganizationCoordinatorAssignment[];
  resetTimeout: () => void;
  firstPage: () => void;
}

export interface AuditInfo {
  lastModifiedLoginId: string;
  lastModifiedDate: string;
}
