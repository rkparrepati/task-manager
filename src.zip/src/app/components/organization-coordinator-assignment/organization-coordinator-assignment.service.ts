import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';

import {
  SearchOptions,
  OrganizationCoordinatorAssignment,
} from './organization-coordinator-assignment.interface';

@Injectable({
  providedIn: 'root',
})
export class OrganizationCoordinatorAssignmentService {
  constructor(private httpService: HttpService) {}

  getWorkerInformation(searchOptions: SearchOptions, activeOnly: boolean) {
    const options: SearchOptions = {
      includeInactive: activeOnly,
      workerNumber: searchOptions.workerNumber || '',
    };
    const url = `/workers?${this.httpService.mergeQueryParams(options)}`;

    return this.httpService.get(url);
  }

  getOrganizationCoordinatorAssignment(
    searchOptions: SearchOptions,
    limit?: number,
    skip?: number,
    sortColumn?: string,
    sortOrder?: string
  ) {
    const options:any={};
    if (limit) options.limit = limit.toString();
    if (skip) options.skip = skip.toString();
    if (sortColumn) options.sortColumn = sortColumn.toString();
    if (sortOrder) options.sortOrder = sortOrder;
    if(searchOptions.workerNumber) options.workerNumber = searchOptions.workerNumber;
    const url = `/organization-coordinators?${this.httpService.mergeQueryParams(options)}`;

    return this.httpService.get(url);
  }

  addOrganizationAssignments(assignments: Partial<OrganizationCoordinatorAssignment>[]) {
    return this.httpService.post(`/organization-coordinators`, assignments);
  }

  deleteOrganizationCoordinatorAssignment(locationCoordinatorId: string) {
    return this.httpService.delete(`/organization-coordinators/${locationCoordinatorId}`);
  }

  deleteOrganizationCoordinatorAssignments(assignments: OrganizationCoordinatorAssignment[]) {
    const deleteRequests = assignments.map((assignment) =>
      this.httpService.delete(`/organization-coordinators/${assignment.locationCoordinatorId}`)
    );
    return this.httpService.delete(`/organization-coordinators/batch`);
    // , {
    //   body: assignments.map((a) => a.locationCoordinatorId),
    // });
  }

  getAcronymAssignments(searchOptions: SearchOptions, workerId?: string) {
    const options: any = {
      businessAreaCode: searchOptions.businessAreaCode || '',
      fromShortName: searchOptions.fromShortName || '',
      toShortName: searchOptions.toShortName || '',
    };
    const url = `/organizations?${this.httpService.mergeQueryParams(options)}`;

    return this.httpService.get(url);
  }

  getLastModifiedRole(workerNumber: string) {
    const options: any = {
      workerNumber: workerNumber,
      includeInactive: 'true',
      sortColumn: 'lastModifiedDate',
      sortOrder: 'desc',
      limit: '1',
      skip: '0',
    };
    const url = `/organization-coordinators?${this.httpService.mergeQueryParams(options)}`;

    return this.httpService.get(url);
  }
}
