import { Component, Inject } from '@angular/core';
import { OrganizationCoordinatorAssignmentService } from '../organization-coordinator-assignment.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-available-acronyms',
  templateUrl: './available-acronyms.component.html',
  styleUrls: ['./available-acronyms.component.scss'],
})
export class AvailableAcronymsComponent {
  dialogInfo: any = {};
  selectedItems: any = [];
  acronymInfoModel: any = {
    acronymInfo: [],
  };
  searchOptions: any = {};
  acronymResults: boolean = false;
  hideMessage: boolean = true;
  selectedAll: boolean = false;
  invalidBusinessArea: boolean = false;
  invalidFromShortName: boolean = false;
  invalidToShortName: boolean = false;
  showErrorMessage: boolean = false;
  returnMessage: string = '';
  showWait: boolean = false;
  workerInfoModel: any;
  total: number = 0;
  showAcronymMessage: boolean = false;
  acronymInfo: any;

  constructor(
    private organizationCoordinatorAssignmentService: OrganizationCoordinatorAssignmentService,
    private dialogRef: MatDialogRef<AvailableAcronymsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // Now you can access the modalOptions data passed from dialog.open()
    // Example: this.dialogInfo = this.data;
    // Or access specific properties: this.searchOptions.workerId = this.data.workerId;
  }
  clear() {
    this.searchOptions = {};
    this.acronymResults = false;
    this.hideMessage = true;
    this.selectedAll = false;
    this.acronymInfoModel = {
      acronymInfo: [],
    };
    this.invalidBusinessArea = false;
    this.invalidFromShortName = false;
    this.invalidToShortName = false;
  }

  getSelectedAcronyms() {
    if (!this.acronymInfoModel) {
      return;
    }
    const selectedAcronyms = this.acronymInfoModel.acronymInfo.filter((item: any) => {
      return item.selected;
    });

    return selectedAcronyms;
  }

  checkAll() {
    if (this.selectedAll) {
      this.selectedAll = false;
    } else {
      this.selectedAll = true;
    }

    this.selectedCount();
  }

  assignSelected() {
    const selectedAssignments = this.acronymInfoModel.acronymInfo.filter((item: any) => {
      return item.selected;
    });

    this.confirm(selectedAssignments);
  }

  selectedCount() {
    let selectedItems = 0;
    this.acronymInfoModel.acronymInfo.forEach((item: any) => {
      item.selected = this.selectedAll;

      selectedItems += item.selected ? 1 : 0;
    });
    this.selectedItems = selectedItems;
    return this.selectedItems;
  }

  validateSearchCriteria() {
    this.showErrorMessage = false;
    const fromShortNameInt = parseInt(this.searchOptions.fromShortName);
    const toShortNameInt = parseInt(this.searchOptions.toShortName);
    if ((fromShortNameInt && toShortNameInt) || (!fromShortNameInt && !toShortNameInt)) {
      return true;
    } else {
      this.showErrorMessage = true;
      this.returnMessage = 'Acronym search criteria must be alpha or numeric, not both.';
      return false;
    }
  }

  populateAcronymInformation() {
    this.showErrorMessage = false;
    if (this.validateSearchCriteria()) {
      this.showWait = true;
      this.organizationCoordinatorAssignmentService
        .getAcronymAssignments(this.searchOptions)
        .subscribe(
          (response: any) => {
            this.showWait = false;
            this.acronymInfo = response.results;

            this.total = response.meta.total;
            this.acronymInfoModel = {
              acronymInfo: this.acronymInfo,
            };

            this.acronymResults = true;

            this.showAcronymMessage = false;
          },
          (error: any) => {
            this.showWait = false;
            this.total = 0;
            this.workerInfoModel = {};
            this.showErrorMessage = true;
            this.returnMessage = 'No acronyms found.';
          }
        );
    }
  }

  /**
   * This method is triggered on key up event
   */
  populateAcronymKeyEvent(event: any) {
    if (event.keyCode === 13) {
      if (!this.searchOptions) {
        this.invalidBusinessArea = true;
        this.invalidFromShortName = true;
        this.invalidToShortName = true;
      } else {
        if (!this.searchOptions.businessAreaCode) {
          this.invalidBusinessArea = true;
        } else {
          this.invalidBusinessArea = false;
        }
        if (!this.searchOptions.fromShortName) {
          this.invalidFromShortName = true;
        } else {
          this.invalidFromShortName = false;
        }
        if (!this.searchOptions.toShortName) {
          this.invalidToShortName = true;
        } else {
          this.invalidToShortName = false;
        }
      }
      if (!this.invalidBusinessArea && !this.invalidFromShortName && !this.invalidToShortName) {
        this.populateAcronymInformation();
      }
    }
  }

  closeThisDialog() {
    this.dialogRef.close();
  }
  confirm(acronymInfo: any) {
    this.dialogRef.close(acronymInfo);
  }
}
