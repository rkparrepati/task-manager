import { Component, ChangeDetectorRef } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { OrganizationCoordinatorAssignmentService } from './organization-coordinator-assignment.service';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';
import { WorkerLookupComponent } from '../firm-assignment/worker-lookup/worker-lookup.component';
import { MatDialog } from '@angular/material/dialog';
import { AvailableAcronymsComponent } from './available-acronyms/available-acronyms.component';
import { ConfirmInactivateDialogComponent } from './confirm-inactivate-dialog/confirm-inactivate-dialog.component';
import { ConfirmInactivateAllDialogComponent } from './confirm-inactivate-all-dialog/confirm-inactivate-all-dialog.component';
import { get } from '@okta/okta-auth-js';
import { audit } from 'rxjs';

@Component({
  selector: 'app-organization-coordinator-assignment',
  templateUrl: './organization-coordinator-assignment.component.html',
  styleUrls: ['./organization-coordinator-assignment.component.scss'],
})
export class OrganizationCoordinatorAssignmentComponent {
  appTitle = 'Organization Coordinator Assignment';
  moduleName = 'Organization Coordinator Assignment';
  organizationCoordinatorSearchView: boolean = false;
  organizationCoordinatorDefaultView: boolean = true;
  coordinatorSearchDisabled: boolean = true;
  selectAssignment = true;
  showFormData = true;
  showInactivateButton = true;
  showType = 'active';
  sortColumn = 'shortName';
  sortDirection = 'asc';
  total = 0;
  invalidWorkerNumber = false;
  lastModifiedDate: string = '';
  lastModifiedLoginId: string = '';
  searchResults: any;
  searchOptions: any;
  coordinatorSearchWorkerNumber: any;
  hideMessage: boolean = false;
  currentSearchOptions: any;
  selectedAll: boolean = false;
  workerId: any;
  workerPreferencedFirstName: any;
  workerLastName: string = '';
  workerLoginId: any;
  activeEmploymentIndicator: any;
  orgnizationAssignments: any;
  organizationModel: any;
  returnCode: string = '';
  returnMessage: string = '';
  accessDenied: any;
  waitMessage: string = '';
  showWait: boolean = false;
  userRoles: any;
  pageSize: number = 10;
  pageNumber: number = 0;
  currentPage: number = 1; // 1-based page number for pagination component

  constructor(
    private dialog: MatDialog,
    public appService: AppService,
    private organizationCoordinatorAssignmentService: OrganizationCoordinatorAssignmentService,
    private utilityService: UtilityService,
    private httpService: HttpService,
    private cdr: ChangeDetectorRef
  ) {
    this.userRoles = this.appService.getUserRoles();
  }
  ngOnInit() {
    this.cancelAllInvalidates();
  }
  cancelAllInvalidates() {
    this.invalidWorkerNumber = false;
  }

  searchOrganizationCoordinator() {
    this.lastModifiedDate = '';
    this.lastModifiedLoginId = '';
    this.searchResults = '';

    this.searchOptions = {
      workerNumber: this.coordinatorSearchWorkerNumber,
    };
    this.hideMessage = true;
    this.currentSearchOptions = this.appService.deepCopy(this.searchOptions);
    this.searchResults = true;
    this.pageNumber = 0;
    this.currentPage = 1; // Reset to first page
    this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
  }

  getOrganizationAssignments(limit: number, skip: number) {
    if (!this.invalidOrgnizationAssignmentParameters()) {
      this.selectedAll = false;
      
      this.organizationCoordinatorAssignmentService
        .getWorkerInformation(this.currentSearchOptions, true)
        .subscribe(
          (data: any) => {
            this.workerId = data.results[0].workerId;
            this.workerPreferencedFirstName = data.results[0].preferredFirstName;
            this.workerLastName = data.results[0].familyName + ', ';
            this.workerLoginId = data.results[0].loginId;
            this.activeEmploymentIndicator = data.results[0].activeEmploymentIndicator;

            if (this.activeEmploymentIndicator) {
              this.organizationCoordinatorAssignmentService
                .getOrganizationCoordinatorAssignment(
                  this.currentSearchOptions,
                  limit,
                  skip,
                  this.sortColumn,
                  this.sortDirection
                )
                .subscribe(
                  (orgnizationAssignments: any) => {
                    this.orgnizationAssignments = orgnizationAssignments.results;

                    this.total = orgnizationAssignments.meta.total;
                    this.setLastModifiedInfo(orgnizationAssignments);

                    // Clear the model first to force refresh
                    this.organizationModel = {};
                    this.cdr.detectChanges();
                    
                    // Then set the new data
                    this.organizationModel = {
                      orgnizationAssignments: this.orgnizationAssignments,
                    };
                    this.searchResults = this.total + ' acronym assignment(s) found';
                    this.organizationCoordinatorDefaultView = false;
                    this.organizationCoordinatorSearchView = true;
                    this.showInactivateButton = false;
                    this.showFormData = true;
                    
                    // Trigger change detection after updating results
                    this.cdr.detectChanges();
                    this.getLastModifiedInfo();
                  },
                  (error) => {                    this.handleFailureResponse(error);
                  }
                );
            } else {
              // Worker is inactive - return code 600 with alert-warning
              this.hideMessage = false;
              this.returnCode = '600';
              this.returnMessage = 'Worker is inactive. Please enter active worker number.';
              this.organizationCoordinatorDefaultView = false;
              this.organizationCoordinatorSearchView = true;
              this.showFormData = true;
              this.showInactivateButton = false;

              this.total = 0;
              this.organizationModel = {};
            }
          },
          (response) => {
            this.hideMessage = false;
            this.returnCode = response.status;
            this.returnMessage = "No workers found that match the query";
            this.total = 0;
            this.organizationModel = {
              orgnizationAssignments: [],
            };
            this.workerPreferencedFirstName = '';
            this.workerLastName = '';
            this.workerLoginId = '';
            this.showInactivateButton = false;
          }
        );
    }
  }

  handleFailureResponse(response: any) {
    if (response.status === 403) {
      this.hideMessage = false;
      this.accessDenied = response.accessDenied;
      this.returnCode = response.status;
      return;
    }
    if (response.status === 404) {
      // Worker has no assigned acronyms - return code 100 with alert-warning
      this.hideMessage = false;
      this.returnCode = '100';
      this.returnMessage = 'Worker has no assigned acronym(s).';
      this.organizationCoordinatorDefaultView = false;
      this.organizationCoordinatorSearchView = true;
      this.showFormData = true;
      this.showInactivateButton = true;

      this.total = 0;
      this.searchResults = this.total + ' acronym assignment(s) found';
      this.organizationModel = {};
    } else {
      this.returnMessage = this.utilityService.processFailureMessage(
        response,
        'Error retrieving assign acronyms.'
      );
    }
  }

  getLastModifiedInfo() {
    const workerNumber = this.currentSearchOptions?.workerNumber;
    if (workerNumber) {
      this.organizationCoordinatorAssignmentService
        .getLastModifiedRole(workerNumber)
        .subscribe(
          (response: any) => {
            if (response.results && response.results.length > 0) {
              this.setLastModifiedInfo(response.results[0].audit);
            }
          },
          (failedResponse) => {          }
        );
    }
  }

  setLastModifiedInfo(auditObject: any) {
    this.lastModifiedLoginId = auditObject.lastModifiedLoginId;
    this.lastModifiedDate = auditObject.lastModifiedDate;
  }

  clearOrganizationCoordinatorSearch() {
    this.coordinatorSearchWorkerNumber = '';
    this.organizationCoordinatorDefaultView = true;
    this.organizationCoordinatorSearchView = false;
    this.coordinatorSearchDisabled = true;
    this.hideMessage = true;
  }

  clearOrganizationCoordinatorSearchResults() {
    this.selectedAll = false;
    this.coordinatorSearchWorkerNumber = '';
    this.coordinatorSearchDisabled = true;
    this.organizationCoordinatorDefaultView = false;
    this.organizationCoordinatorSearchView = true;
    this.showInactivateButton = true;
    this.total = 0;
    this.searchResults = '';
    this.organizationModel = {};
    this.workerPreferencedFirstName = '';
    this.workerLastName = '';
    this.workerLoginId = '';

    this.cancelAllInvalidates();
    this.hideMessage = true;
    this.lastModifiedDate = '';
    this.lastModifiedLoginId = '';
  }

  checkAll() {
    if (this.selectedAll) {
      this.selectedAll = false;
    } else {
      this.selectedAll = true;
    }

    this.selectedCount();
  }

  selectedCount() {
    let selectedItems = 0;
    this.organizationModel.orgnizationAssignments.forEach((item: any) => {
      item.selected = this.selectedAll;

      selectedItems += item.selected ? 1 : 0;
    });
    return selectedItems;
  }

  showAvailableAcronyms() {
    const modalOptions = {
      titleType: 'text-danger',
      primaryButton: 'delete',
      primaryButtonType: 'danger',
      cancelButton: true,
      currentAssignments: this.organizationModel.orgnizationAssignments,
      workerId: this.workerId,
    };
    this.openAcronymDialog(modalOptions);
  }

  openAcronymDialog(modalOptions: any) {    this.hideMessage = true;
    const dialogRef = this.dialog.open(AvailableAcronymsComponent, {
      width: '50vw',
      height: '75vh',
      data: modalOptions,
    });
    dialogRef.afterClosed().subscribe((assignments: any) => {
      if (!assignments || assignments.length === 0) {
        return;
      }
      
      // Build assignment list for POST call
      const assignmentList: any = [];
      assignments.forEach((assignment: any) => {
        const anAssignment = {
          organization: {
            id: assignment.organizationId,
          },
          worker: {
            workerId: this.workerId,
          },
          lifecycle: {
            beginDate: this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(new Date())
            ),
            endDate: null,
          },
        };
        assignmentList.push(anAssignment);
      });

      // Make POST call to assign acronyms
      this.organizationCoordinatorAssignmentService
        .addOrganizationAssignments(assignmentList)
        .subscribe(
          (data: any) => {
            // Display success toast message
            this.returnCode = '200';
            this.returnMessage = 'The assignment(s) were saved successfully';
            this.hideMessage = false;
            // Refresh the assignments list
            this.getLastModifiedInfo();
            this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
          },
          (failResponse: any) => {
            // Display error message
            this.returnCode = failResponse.status;
            this.hideMessage = false;
            this.accessDenied = failResponse.accessDenied;
            this.returnMessage = 'Failed to save assignment(s): ' + (failResponse.data?.message || 'Unknown error');
          }
        );
    });
  }

  performAssignments(assignments: any) {
    this.waitMessage = 'Assigning ' + assignments.length + ' organizations';

    this.showInactivateButton = false;
    const assignmentList: any = [];
    assignments.forEach((assignment: any) => {
      const anAssignment = {
        organization: {
          id: assignment.organizationId,
        },
        worker: {
          workerId: this.workerId,
        },
        lifecycle: {
          beginDate: this.utilityService.adjustDateFormatter(
            this.utilityService.dateFormatter(new Date())
          ),
          endDate: null,
        },
      };
      assignmentList.push(anAssignment);
    });

    if (assignmentList.length > 50) {
      const modalOptions = {
        titleType: 'text-warning',
        content:
          'Over 50 assignments may take 30 minutes or more to process. ' +
          'Click continue to run this process in the background. Then please wait 30 or more minutes and search worker ' +
          'assignments to view updated assignment list.',
        cancelButton: true,
        primaryButton: 'Continue',
        primaryButtonType: 'Primary',
        title: 'Possible long process warning.?',
      };
      // ngDialog
      //   .openConfirm({
      //     template: 'app/helperViewComponents/dialogs/commonDialog.html',
      //     controller: 'CommonDialogController',
      //     data: modalOptions,
      //     controllerAs: 'vm',
      //   })
      //   .then(
      //     function () {
      //       addAssignments(assignmentList, false);
      //     },
      //     function () {}
      //   );
    } else {
      this.showWait = true;
      this.addAssignments(assignmentList, true);
    }
  }

  addAssignments(assignmentList: any, showResults: boolean) {
    this.organizationCoordinatorAssignmentService
      .addOrganizationAssignments(assignmentList)
      .subscribe(
        (data: any) => {
          if (showResults) {
            this.returnCode = '201';
            this.returnMessage = 'The assignment(s) were saved successfully';
            this.hideMessage = false;
            this.getLastModifiedInfo();
            this.showWait = false;
          }
        },
        (failResponse: any) => {
          this.showWait = false;

          this.returnCode = failResponse.status;
          this.hideMessage = false;
          this.accessDenied = failResponse.accessDenied;
          this.returnMessage = 'Failed to save assignment(s): ' + failResponse.data.message;
        }
      );
  }

  confirmInactivate(assignment: any) {
    const modalOptions = {
      titleType: 'text-danger',
      content: {
        organization: assignment.organization,
        worker: {
          familyName: this.workerLastName.replace(', ', ''),
          givenName: this.workerPreferencedFirstName,
        },
        locationCoordinatorId: assignment.locationCoordinatorId,
      },
      cancelButton: true,
      primaryButton: 'Inactivate',
      primaryButtonType: 'danger',
      title: 'Unassign the assignment?',
    };
    this.openTheDialog(modalOptions);
  }

  openTheDialog(modalOptions: any) {
    this.hideMessage = true;
    const dialogRef = this.dialog.open(ConfirmInactivateDialogComponent, {
      width: '30vw',
      data: modalOptions,
    });
    
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.deleteIndividualAssignment(result);
      }
    });
  }

  deleteIndividualAssignment(assignment: any) {
    this.organizationCoordinatorAssignmentService
      .deleteOrganizationCoordinatorAssignment(assignment.content.locationCoordinatorId)
      .subscribe(
        (data: any) => {
          this.returnCode = '200';
          this.hideMessage = false;
          this.returnMessage = 'Successfully unassigned acronym assignment';
          this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
        },
        (response) => {
          this.hideMessage = false;
          this.returnCode = response.status;
          this.returnMessage = 'Problem unassigning acronym assignment';
          this.accessDenied = response.accessDenied;
        }
      );
  }

  searchAcronym() {
    this.hideMessage = false;
    this.returnCode = '400';
    this.returnMessage = 'Acronym search criteria';
  }

  inactivateAllAssignment() {
    const selectedAssignments = this.getSelectedAssignments();
    if (selectedAssignments.length === 0) {
      return;
    } else if (selectedAssignments.length === 1) {
      this.confirmInactivate(selectedAssignments[0]);
      return;
    }
    const theTitle = 'Inactivate all Assignments?';
    const theContent =
      ' All Selected acronym assignments to ' +
      this.workerLastName +
      ', ' +
      this.workerPreferencedFirstName +
      ' will be unassigned.';

    const modalOptions = {
      titleType: 'text-danger',
      content: theContent,
      primaryButton: 'delete',
      primaryButtonType: 'danger',
      cancelButton: true,
      title: theTitle,
    };
    this.openDeleteDialog(modalOptions);
  }

  getSelectedAssignments() {
    if (!this.organizationModel || !this.organizationModel.orgnizationAssignments) {
      return [];
    }
    const selectedAssignments = this.organizationModel.orgnizationAssignments.filter(
      (item: any) => {
        return item.selected;
      }
    );
    return selectedAssignments;
  }

  openDeleteDialog(modalOptions: any) {
    this.hideMessage = true;
    const dialogRef = this.dialog.open(ConfirmInactivateAllDialogComponent, {
      width: '50vw',
      data: modalOptions,
    });
    
    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        const selectedAssignments = this.getSelectedAssignments();
        this.deleteMultipleAssignments(selectedAssignments);
      }
    });
  }

  deleteMultipleAssignments(selectedAssignments: any[]) {
    // Delete each assignment individually
    let deleteCount = 0;
    let errorCount = 0;
    
    selectedAssignments.forEach((assignment) => {
      this.organizationCoordinatorAssignmentService
        .deleteOrganizationCoordinatorAssignment(assignment.locationCoordinatorId)
        .subscribe(
          (data: any) => {
            deleteCount++;
            if (deleteCount + errorCount === selectedAssignments.length) {
              this.handleBatchDeleteComplete(deleteCount, errorCount);
            }
           
            this.returnCode = '200';
          this.hideMessage = false;
          this.returnMessage = 'Successfully unassigned acronym assignment';
           this.getLastModifiedInfo();
          },
          (response) => {
            errorCount++;
            if (deleteCount + errorCount === selectedAssignments.length) {
              this.handleBatchDeleteComplete(deleteCount, errorCount);
            }
          }
        );
    });
  }

  handleBatchDeleteComplete(successCount: number, errorCount: number) {
    if (errorCount === 0) {
      this.returnCode = '200';
      this.hideMessage = false;
      this.returnMessage = 'Successfully unassigned acronym assignments';
    } else if (successCount === 0) {
      this.returnCode = '500';
      this.hideMessage = false;
      this.returnMessage = 'Failed to unassign acronym assignments';
    } else {
      this.returnCode = '206';
      this.hideMessage = false;
      this.returnMessage = `Partially completed: ${successCount} succeeded, ${errorCount} failed`;
    }
    
    this.selectedAll = false;
    this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
    this.getLastModifiedInfo();
  }

  /**
   * This method validates input parameters
   */
  invalidOrgnizationAssignmentParameters() {
    this.cancelAllInvalidates();

    let orgAssignementInvalid = false;

    if (!this.coordinatorSearchWorkerNumber) {
      this.invalidWorkerNumber = true;
      orgAssignementInvalid = true;
    }

    return orgAssignementInvalid;
  }

  /**
   * This function sorts data based on the selected column
   */
  resort($event: { columnName: string; sortOrder: string; sortId: string }) {
    // Update local sorting state
    this.sortColumn = $event.columnName;
    this.sortDirection = $event.sortOrder;
    
    // Reset to first page when sorting changes
    this.pageNumber = 0;
    this.currentPage = 1;
    
    // Trigger change detection before fetching data
    this.cdr.detectChanges();
    
    // Fetch data with new sort order
    this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
  }

  /**
   * This method captures the key up event when Enter key is
   * selected after entering search parameters.
   *
   * @param $event
   */
  searchKeyEventHandler($event: any) {
    this.coordinatorSearchDisabled = false;
    if (!this.coordinatorSearchWorkerNumber) {
      this.coordinatorSearchDisabled = true;
    } else {
      if ($event.keyCode === 13) {
        this.searchOrganizationCoordinator();
      }
    }
  }

  showWorkerSearchDialog() {
    // Remove focus from the button to prevent aria-hidden accessibility warning
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    
    const dialogRef = this.dialog.open(WorkerLookupComponent, {
      disableClose: true,
      width: '60vw',
      height: '70vh',
      maxHeight: '100vh',
      hasBackdrop: true,
    });
    dialogRef.afterClosed().subscribe((worker: any) => {
      if (!worker || !worker.workerNumber) {
        // this.errorMessage = 'Worker does not have a required Login Id.';
        return;
      }
      this.coordinatorSearchWorkerNumber = worker.workerNumber;
      this.coordinatorSearchDisabled = false;

      this.searchOrganizationCoordinator();
    });
  }

  exportDataCallback(): void {
    // Build URL with query parameters - matching transfer-search component format
    const url = `/organization-coordinators/excelReport?workerNumber=${this.currentSearchOptions.workerNumber}`;
    
    const fileName = 'OrganizationCoordinatorAssignment.xls';
    
    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';
          a.click();
          
          // Clean up the URL object
          URL.revokeObjectURL(blobUrl);
        }
      },
      error: (error) => {        // Show error message using service
        this.hideMessage = false;
        this.returnCode = error.status?.toString() || '500';
        this.returnMessage = error.error?.message || 'Failed to download Excel report';
        this.accessDenied = error.accessDenied;
        this.cdr.detectChanges();
      }
    });
  }

  pageSizeChangedEvent(pageSize: number) {
    this.pageSize = pageSize;
    this.pageNumber = 0;
    this.currentPage = 1; // Reset to first page when page size changes
    this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
  }

  onPageChanged(page: number) {
    // Convert 1-based page number to 0-based pageNumber
    this.currentPage = page;
    this.pageNumber = page - 1;
    this.getOrganizationAssignments(this.pageSize, this.pageNumber * this.pageSize);
  }

  isSearchResultsString(): boolean {
    return typeof this.searchResults === 'string';
  }
}

