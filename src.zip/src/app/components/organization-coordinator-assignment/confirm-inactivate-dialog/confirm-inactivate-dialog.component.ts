import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { A11yModule } from '@angular/cdk/a11y';

@Component({
  selector: 'app-confirm-inactivate-dialog',
  templateUrl: './confirm-inactivate-dialog.component.html',
  styleUrls: ['./confirm-inactivate-dialog.component.scss'],
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, A11yModule],
})
export class ConfirmInactivateDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmInactivateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onCancelClick(): void {
    this.dialogRef.close(false);
  }

  onUnassignClick(): void {
    this.dialogRef.close(this.data);
  }
}
