import { Component } from '@angular/core';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-other-management-tools',
  templateUrl: './other-management-tools.component.html',
  styleUrls: ['./other-management-tools.component.scss'],
})
export class OtherManagementToolsComponent {
  accessInfo: any = this.appService.getNavData();
  constructor(public appService: AppService) {}
}
