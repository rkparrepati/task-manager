import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss'],
})
export class ConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      message: string;
      title: string;
      buttonText: { ok: string; cancel: string };
      isSiteManagement?: boolean;
    }
  ) {}

  onConfirm(): void {
    // Pass true back to the component that opened the dialog
    this.dialogRef.close(true);
  }

  onCancel(): void {
    // Pass false back to the component that opened the dialog
    this.dialogRef.close(false);
  }
}
