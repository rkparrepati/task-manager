import { ComponentFixture, TestBed, fakeAsync, tick, flush } from '@angular/core/testing';
import { NotificationBannerComponent } from './notification-banner.component';
import { NotificationService, NotificationMessage } from 'src/app/services/notification.service';
import { BehaviorSubject } from 'rxjs';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { DebugElement, ChangeDetectionStrategy } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('NotificationBannerComponent', () => {
  let component: NotificationBannerComponent;
  let fixture: ComponentFixture<NotificationBannerComponent>;
  let notificationService: jasmine.SpyObj<NotificationService>;
  let notificationSubject: BehaviorSubject<NotificationMessage | null>;

  beforeEach(async () => {
    notificationSubject = new BehaviorSubject<NotificationMessage | null>(null);

    const notificationServiceSpy = jasmine.createSpyObj('NotificationService', [], {
      notification$: notificationSubject.asObservable()
    });

    await TestBed.configureTestingModule({
      declarations: [NotificationBannerComponent],
      imports: [CommonModule, MatIconModule, MatButtonModule],
      providers: [
        { provide: NotificationService, useValue: notificationServiceSpy }
      ]
    }).compileComponents();

    notificationService = TestBed.inject(NotificationService) as jasmine.SpyObj<NotificationService>;
    fixture = TestBed.createComponent(NotificationBannerComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    fixture.destroy();
  });

  describe('Component Initialization', () => {
    it('should create the component', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize with null notification', () => {
      expect(component.notification).toBeNull();
    });

    it('should initialize with isVisible as false', () => {
      expect(component.isVisible).toBeFalse();
    });

    it('should subscribe to notification$ on ngOnInit', () => {
      fixture.detectChanges();
      expect(component).toBeTruthy();
    });
  });

  describe('Notification Display', () => {
    it('should display notification when success message is emitted', (done) => {
      const successNotification: NotificationMessage = {
        code: '200',
        message: 'Operation successful',
        type: 'success'
      };

      fixture.detectChanges();

      notificationSubject.next(successNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(successNotification);
        expect(component.isVisible).toBeTrue();
        done();
      });
    });

    it('should display notification when error message is emitted', (done) => {
      const errorNotification: NotificationMessage = {
        code: '700',
        message: 'An error occurred',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(errorNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(errorNotification);
        expect(component.isVisible).toBeTrue();
        done();
      });
    });

    it('should display notification when warning message is emitted', (done) => {
      const warningNotification: NotificationMessage = {
        code: '100',
        message: 'Warning message',
        type: 'warning'
      };

      fixture.detectChanges();
      notificationSubject.next(warningNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(warningNotification);
        expect(component.isVisible).toBeTrue();
        done();
      });
    });

    it('should display notification when info message is emitted', (done) => {
      const infoNotification: NotificationMessage = {
        code: '300',
        message: 'Information message',
        type: 'info'
      };

      fixture.detectChanges();
      notificationSubject.next(infoNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(infoNotification);
        expect(component.isVisible).toBeTrue();
        done();
      });
    });

    it('should hide notification when null is emitted', (done) => {
      const successNotification: NotificationMessage = {
        code: '200',
        message: 'Operation successful',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(successNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.isVisible).toBeTrue();

        notificationSubject.next(null);
        fixture.detectChanges();

        fixture.whenStable().then(() => {
          expect(component.isVisible).toBeFalse();
          expect(component.notification).toBeNull();
          done();
        });
      });
    });
  });

  describe('getIcon() Method', () => {
    it('should return "check_circle" for success type', () => {
      component.notification = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      expect(component.getIcon()).toBe('check_circle');
    });

    it('should return "error" for error type', () => {
      component.notification = {
        code: '700',
        message: 'Error',
        type: 'error'
      };

      expect(component.getIcon()).toBe('error');
    });

    it('should return "warning" for warning type', () => {
      component.notification = {
        code: '100',
        message: 'Warning',
        type: 'warning'
      };

      expect(component.getIcon()).toBe('warning');
    });

    it('should return "info" for info type', () => {
      component.notification = {
        code: '300',
        message: 'Info',
        type: 'info'
      };

      expect(component.getIcon()).toBe('info');
    });

    it('should return "info" as default when notification is null', () => {
      component.notification = null;

      expect(component.getIcon()).toBe('info');
    });

    it('should return "info" as default for unknown type', () => {
      component.notification = {
        code: '999',
        message: 'Unknown',
        type: 'unknown' as any
      };

      expect(component.getIcon()).toBe('info');
    });
  });

  describe('getAriaLabel() Method', () => {
    it('should return correct aria label for success notification', () => {
      component.notification = {
        code: '200',
        message: 'Operation successful',
        type: 'success'
      };

      expect(component.getAriaLabel()).toBe('success message: Operation successful');
    });

    it('should return correct aria label for error notification', () => {
      component.notification = {
        code: '700',
        message: 'An error occurred',
        type: 'error'
      };

      expect(component.getAriaLabel()).toBe('error message: An error occurred');
    });

    it('should return correct aria label for warning notification', () => {
      component.notification = {
        code: '100',
        message: 'Warning message',
        type: 'warning'
      };

      expect(component.getAriaLabel()).toBe('warning message: Warning message');
    });

    it('should return correct aria label for info notification', () => {
      component.notification = {
        code: '300',
        message: 'Information message',
        type: 'info'
      };

      expect(component.getAriaLabel()).toBe('info message: Information message');
    });

    it('should return "notification message: " when notification is null', () => {
      component.notification = null;

      expect(component.getAriaLabel()).toBe('notification message: ');
    });

    it('should handle empty message in aria label', () => {
      component.notification = {
        code: '200',
        message: '',
        type: 'success'
      };

      expect(component.getAriaLabel()).toBe('success message: ');
    });
  });

  describe('close() Method', () => {
    it('should set isVisible to false when close is called', () => {
      component.notification = {
        code: '200',
        message: 'Success',
        type: 'success'
      };
      component.isVisible = true;

      component.close();

      expect(component.isVisible).toBeFalse();
    });

    it('should set notification to null when close is called', () => {
      component.notification = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      component.close();

      expect(component.notification).toBeNull();
    });

    it('should hide the notification banner in DOM when close is called', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        let bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement).toBeTruthy();

        component.close();
        fixture.detectChanges();

        bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement).toBeFalsy();
        done();
      });
    });
  });

  describe('DOM Rendering', () => {
    it('should render notification banner when isVisible is true', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success message',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement).toBeTruthy();
        done();
      });
    });

    it('should not render notification banner when isVisible is false', () => {
      fixture.detectChanges();

      const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
      expect(bannerElement).toBeFalsy();
    });

    it('should apply correct CSS class based on notification type', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement.nativeElement.classList.contains('notification-success')).toBeTrue();
        done();
      });
    });

    it('should display notification message text in DOM', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Test notification message',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const messageElement = fixture.debugElement.query(By.css('.notification-message p'));
        expect(messageElement.nativeElement.textContent).toContain('Test notification message');
        done();
      });
    });

    it('should render close button in notification banner', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const closeButton = fixture.debugElement.query(By.css('.close-button'));
        expect(closeButton).toBeTruthy();
        done();
      });
    });

    it('should render correct icon based on notification type', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain('check_circle');
        done();
      });
    });

    it('should have role="alert" on notification banner', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement.nativeElement.getAttribute('role')).toBe('alert');
        done();
      });
    });

    it('should have aria-label on notification banner', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success message',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement.nativeElement.getAttribute('aria-label')).toBe('success message: Success message');
        done();
      });
    });

    it('should have aria-label on close button', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const closeButton = fixture.debugElement.query(By.css('.close-button'));
        expect(closeButton.nativeElement.getAttribute('aria-label')).toBe('Close notification');
        done();
      });
    });
  });

  describe('Close Button Interaction', () => {
    it('should call close() when close button is clicked', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      spyOn(component, 'close');

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const closeButton = fixture.debugElement.query(By.css('.close-button'));
        closeButton.nativeElement.click();

        expect(component.close).toHaveBeenCalled();
        done();
      });
    });

    it('should hide notification after close button is clicked', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const closeButton = fixture.debugElement.query(By.css('.close-button'));
        closeButton.nativeElement.click();

        fixture.detectChanges();
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement).toBeFalsy();
        done();
      });
    });
  });

  describe('Multiple Notifications', () => {
    it('should replace previous notification with new one', (done) => {
      const firstNotification: NotificationMessage = {
        code: '200',
        message: 'First message',
        type: 'success'
      };

      const secondNotification: NotificationMessage = {
        code: '700',
        message: 'Second message',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(firstNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(firstNotification);

        notificationSubject.next(secondNotification);
        fixture.detectChanges();

        fixture.whenStable().then(() => {
          expect(component.notification).toEqual(secondNotification);
          done();
        });
      });
    });

    it('should update CSS class when notification type changes', (done) => {
      const firstNotification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      const secondNotification: NotificationMessage = {
        code: '700',
        message: 'Error',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(firstNotification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        let bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement.nativeElement.classList.contains('notification-success')).toBeTrue();

        notificationSubject.next(secondNotification);
        fixture.detectChanges();

        fixture.whenStable().then(() => {
          bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
          expect(bannerElement.nativeElement.classList.contains('notification-error')).toBeTrue();
          done();
        });
      });
    });
  });

  describe('ngOnDestroy', () => {
    it('should complete destroy subject on component destroy', () => {
      spyOn(component['destroy$'], 'complete');

      component.ngOnDestroy();

      expect(component['destroy$'].complete).toHaveBeenCalled();
    });

    it('should emit next on destroy subject on component destroy', () => {
      spyOn(component['destroy$'], 'next');

      component.ngOnDestroy();

      expect(component['destroy$'].next).toHaveBeenCalled();
    });

    it('should clear autoHideTimeout if it exists on destroy', () => {
      component['autoHideTimeout'] = setTimeout(() => {}, 1000);
      spyOn(window, 'clearTimeout');

      component.ngOnDestroy();

      expect(window.clearTimeout).toHaveBeenCalled();
    });

    it('should not throw error if autoHideTimeout is null on destroy', () => {
      component['autoHideTimeout'] = null;

      expect(() => {
        component.ngOnDestroy();
      }).not.toThrow();
    });
  });

  describe('Timeout Handling', () => {
    it('should clear existing timeout when new notification arrives', (done) => {
      spyOn(window, 'clearTimeout');

      const firstNotification: NotificationMessage = {
        code: '200',
        message: 'First',
        type: 'success'
      };

      const secondNotification: NotificationMessage = {
        code: '200',
        message: 'Second',
        type: 'success'
      };

      fixture.detectChanges();
      component['autoHideTimeout'] = setTimeout(() => {}, 1000);

      notificationSubject.next(firstNotification);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        notificationSubject.next(secondNotification);
        fixture.detectChanges();

        fixture.whenStable().then(() => {
          expect(window.clearTimeout).toHaveBeenCalled();
          done();
        });
      });
    });

    it('should set autoHideTimeout to null after clearing', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Test',
        type: 'success'
      };

      fixture.detectChanges();
      component['autoHideTimeout'] = setTimeout(() => {}, 1000);

      notificationSubject.next(notification);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(component['autoHideTimeout']).toBeNull();
        done();
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle notification with special characters in message', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Message with <special> & "characters"',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification?.message).toBe('Message with <special> & "characters"');
        done();
      });
    });

    it('should handle very long notification message', (done) => {
      const longMessage = 'A'.repeat(500);
      const notification: NotificationMessage = {
        code: '200',
        message: longMessage,
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification?.message).toBe(longMessage);
        done();
      });
    });

    it('should handle notification with empty string message', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: '',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.isVisible).toBeTrue();
        expect(component.notification?.message).toBe('');
        done();
      });
    });

    it('should handle rapid successive notifications', (done) => {
      const notifications: NotificationMessage[] = [
        { code: '200', message: 'First', type: 'success' },
        { code: '200', message: 'Second', type: 'success' },
        { code: '200', message: 'Third', type: 'success' }
      ];

      fixture.detectChanges();

      notifications.forEach(notification => {
        notificationSubject.next(notification);
      });

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.notification?.message).toBe('Third');
        done();
      });
    });
  });

  describe('Subscription Management', () => {
    it('should unsubscribe from notification$ on component destroy', (done) => {
      fixture.detectChanges();

      const notification: NotificationMessage = {
        code: '200',
        message: 'Test',
        type: 'success'
      };

      notificationSubject.next(notification);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(component.notification).toEqual(notification);

        component.ngOnDestroy();
        fixture.detectChanges();

        // After destroy, new notifications should not be received
        const newNotification: NotificationMessage = {
          code: '200',
          message: 'New message',
          type: 'success'
        };

        notificationSubject.next(newNotification);
        fixture.detectChanges();

        fixture.whenStable().then(() => {
          // Component should still have the old notification since subscription is destroyed
          expect(component.notification?.message).toBe('Test');
          done();
        });
      });
    });
  });

  describe('Integration Tests - Template Rendering with Methods', () => {
    it('should render success icon and call getIcon() for success notification', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain('check_circle');
        expect(component.getIcon()).toBe('check_circle');
        done();
      });
    });

    it('should render error icon and call getIcon() for error notification', (done) => {
      const notification: NotificationMessage = {
        code: '700',
        message: 'Error',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain('error');
        expect(component.getIcon()).toBe('error');
        done();
      });
    });

    it('should render warning icon and call getIcon() for warning notification', (done) => {
      const notification: NotificationMessage = {
        code: '100',
        message: 'Warning',
        type: 'warning'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain('warning');
        expect(component.getIcon()).toBe('warning');
        done();
      });
    });

    it('should render info icon and call getIcon() for info notification', (done) => {
      const notification: NotificationMessage = {
        code: '300',
        message: 'Info',
        type: 'info'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain('info');
        expect(component.getIcon()).toBe('info');
        done();
      });
    });

    it('should call getAriaLabel() and render correct aria-label for success', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success message',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        const ariaLabel = bannerElement.nativeElement.getAttribute('aria-label');
        expect(ariaLabel).toBe(component.getAriaLabel());
        expect(ariaLabel).toBe('success message: Success message');
        done();
      });
    });

    it('should call getAriaLabel() and render correct aria-label for error', (done) => {
      const notification: NotificationMessage = {
        code: '700',
        message: 'Error message',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        const ariaLabel = bannerElement.nativeElement.getAttribute('aria-label');
        expect(ariaLabel).toBe(component.getAriaLabel());
        expect(ariaLabel).toBe('error message: Error message');
        done();
      });
    });

    it('should call close() method when close button clicked', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.isVisible).toBeTrue();
        expect(component.notification).not.toBeNull();

        const closeButton = fixture.debugElement.query(By.css('.close-button'));
        closeButton.nativeElement.click();

        expect(component.isVisible).toBeFalse();
        expect(component.notification).toBeNull();
        done();
      });
    });

    it('should apply correct CSS class based on notification type in DOM', (done) => {
      const notification: NotificationMessage = {
        code: '700',
        message: 'Error',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        expect(bannerElement.nativeElement.classList.contains('notification-error')).toBeTrue();
        done();
      });
    });

    it('should display correct message text in DOM', (done) => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Test message content',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);

      fixture.detectChanges();
      fixture.whenStable().then(() => {
        const messageElement = fixture.debugElement.query(By.css('.notification-message p'));
        expect(messageElement.nativeElement.textContent).toContain('Test message content');
        done();
      });
    });
  });

  describe('Direct Method Calls', () => {
    it('should directly call close() and update component state', () => {
      component.notification = {
        code: '200',
        message: 'Test',
        type: 'success'
      };
      component.isVisible = true;

      component.close();

      expect(component.isVisible).toBeFalse();
      expect(component.notification).toBeNull();
    });

    it('should directly call getIcon() with all notification types', () => {
      const testCases = [
        { type: 'success' as const, expected: 'check_circle' },
        { type: 'error' as const, expected: 'error' },
        { type: 'warning' as const, expected: 'warning' },
        { type: 'info' as const, expected: 'info' }
      ];

      testCases.forEach(testCase => {
        component.notification = {
          code: '200',
          message: 'Test',
          type: testCase.type
        };
        expect(component.getIcon()).toBe(testCase.expected);
      });
    });

    it('should directly call getAriaLabel() with different notification types', () => {
      const testCases = [
        { type: 'success' as const, message: 'Success msg', expected: 'success message: Success msg' },
        { type: 'error' as const, message: 'Error msg', expected: 'error message: Error msg' },
        { type: 'warning' as const, message: 'Warning msg', expected: 'warning message: Warning msg' },
        { type: 'info' as const, message: 'Info msg', expected: 'info message: Info msg' }
      ];

      testCases.forEach(testCase => {
        component.notification = {
          code: '200',
          message: testCase.message,
          type: testCase.type
        };
        expect(component.getAriaLabel()).toBe(testCase.expected);
      });
    });

    it('should handle getIcon() when notification type is undefined', () => {
      component.notification = {
        code: '200',
        message: 'Test',
        type: undefined as any
      };

      expect(component.getIcon()).toBe('info');
    });

    it('should handle getAriaLabel() with null notification', () => {
      component.notification = null;

      expect(component.getAriaLabel()).toBe('notification message: ');
    });

    it('should handle getAriaLabel() with undefined type and message', () => {
      component.notification = {
        code: '200',
        message: undefined as any,
        type: undefined as any
      };

      expect(component.getAriaLabel()).toBe('notification message: ');
    });
  });

  describe('ngOnDestroy Lifecycle', () => {
    it('should clear timeout and complete destroy subject on destroy', () => {
      spyOn(window, 'clearTimeout');
      spyOn(component['destroy$'], 'next');
      spyOn(component['destroy$'], 'complete');

      component['autoHideTimeout'] = setTimeout(() => {}, 1000);

      component.ngOnDestroy();

      expect(window.clearTimeout).toHaveBeenCalled();
      expect(component['destroy$'].next).toHaveBeenCalled();
      expect(component['destroy$'].complete).toHaveBeenCalled();
    });

    it('should handle ngOnDestroy when autoHideTimeout is already null', () => {
      spyOn(window, 'clearTimeout');
      component['autoHideTimeout'] = null;

      expect(() => {
        component.ngOnDestroy();
      }).not.toThrow();

      expect(window.clearTimeout).not.toHaveBeenCalled();
    });
  });

  describe('Template Method Invocation Coverage', () => {
    it('should invoke getIcon() through template for success type', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const result = component.getIcon();
      expect(result).toBe('check_circle');
    }));

    it('should invoke getIcon() through template for error type', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '700',
        message: 'Error',
        type: 'error'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const result = component.getIcon();
      expect(result).toBe('error');
    }));

    it('should invoke getIcon() through template for warning type', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '100',
        message: 'Warning',
        type: 'warning'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const result = component.getIcon();
      expect(result).toBe('warning');
    }));

    it('should invoke getIcon() through template for info type', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '300',
        message: 'Info',
        type: 'info'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const result = component.getIcon();
      expect(result).toBe('info');
    }));

    it('should invoke getAriaLabel() through template', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Test message',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const result = component.getAriaLabel();
      expect(result).toBe('success message: Test message');
    }));

    it('should invoke close() through template click event', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      const closeButton = fixture.debugElement.query(By.css('.close-button'));
      expect(closeButton).toBeTruthy();

      closeButton.nativeElement.click();
      fixture.detectChanges();
      tick();

      expect(component.isVisible).toBeFalse();
      expect(component.notification).toBeNull();
    }));

    it('should render all notification types with correct icons', fakeAsync(() => {
      const testCases = [
        { type: 'success' as const, icon: 'check_circle' },
        { type: 'error' as const, icon: 'error' },
        { type: 'warning' as const, icon: 'warning' },
        { type: 'info' as const, icon: 'info' }
      ];

      testCases.forEach(testCase => {
        const notification: NotificationMessage = {
          code: '200',
          message: 'Test',
          type: testCase.type
        };

        fixture.detectChanges();
        notificationSubject.next(notification);
        fixture.detectChanges();
        tick();
        fixture.detectChanges();

        const iconElement = fixture.debugElement.query(By.css('.notification-icon mat-icon'));
        expect(iconElement.nativeElement.textContent).toContain(testCase.icon);
        expect(component.getIcon()).toBe(testCase.icon);

        component.close();
        fixture.detectChanges();
        tick();
      });
    }));

    it('should render aria-label with correct format for all types', fakeAsync(() => {
      const testCases = [
        { type: 'success' as const, message: 'Success msg', expected: 'success message: Success msg' },
        { type: 'error' as const, message: 'Error msg', expected: 'error message: Error msg' },
        { type: 'warning' as const, message: 'Warning msg', expected: 'warning message: Warning msg' },
        { type: 'info' as const, message: 'Info msg', expected: 'info message: Info msg' }
      ];

      testCases.forEach(testCase => {
        const notification: NotificationMessage = {
          code: '200',
          message: testCase.message,
          type: testCase.type
        };

        fixture.detectChanges();
        notificationSubject.next(notification);
        fixture.detectChanges();
        tick();
        fixture.detectChanges();

        const bannerElement = fixture.debugElement.query(By.css('.notification-banner'));
        const ariaLabel = bannerElement.nativeElement.getAttribute('aria-label');
        expect(ariaLabel).toBe(testCase.expected);
        expect(component.getAriaLabel()).toBe(testCase.expected);

        component.close();
        fixture.detectChanges();
        tick();
      });
    }));

    it('should properly handle close() invocation from template', fakeAsync(() => {
      const notification: NotificationMessage = {
        code: '200',
        message: 'Success',
        type: 'success'
      };

      fixture.detectChanges();
      notificationSubject.next(notification);
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      expect(component.isVisible).toBeTrue();
      expect(component.notification).not.toBeNull();

      const closeButton = fixture.debugElement.query(By.css('.close-button'));
      closeButton.nativeElement.click();
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      expect(component.isVisible).toBeFalse();
      expect(component.notification).toBeNull();
    }));

    it('should call getIcon() with null notification through template', fakeAsync(() => {
      component.notification = null;
      component.isVisible = true;
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      expect(component.getIcon()).toBe('info');
    }));

    it('should call getAriaLabel() with null notification through template', fakeAsync(() => {
      component.notification = null;
      component.isVisible = true;
      fixture.detectChanges();
      tick();
      fixture.detectChanges();

      expect(component.getAriaLabel()).toBe('notification message: ');
    }));
  });
});
