  import { Component, OnInit, OnDestroy } from '@angular/core';
import { NotificationService, NotificationMessage } from 'src/app/services/notification.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-notification-banner',
  templateUrl: './notification-banner.component.html',
  styleUrls: ['./notification-banner.component.scss']
})
export class NotificationBannerComponent implements OnInit, OnDestroy {
  notification: NotificationMessage | null = null;
  isVisible = false;
  private destroy$ = new Subject<void>();

  constructor(private notificationService: NotificationService) {}

  private autoHideTimeout: any;

  ngOnInit(): void {
    this.notificationService.notification$
      .pipe(takeUntil(this.destroy$))
      .subscribe((notification) => {
        
        // Clear any existing timeout
        if (this.autoHideTimeout) {
          clearTimeout(this.autoHideTimeout);
          this.autoHideTimeout = null;
        }

        // Only show non-null notifications
        if (notification !== null) {
          this.notification = notification;
          this.isVisible = true;
        } else {
          this.isVisible = false;
          this.notification = null;
        }
      });
  }

  ngOnDestroy(): void {
    if (this.autoHideTimeout) {
      clearTimeout(this.autoHideTimeout);
    }
    this.destroy$.next();
    this.destroy$.complete();
  }

  close(): void {
    this.isVisible = false;
    this.notification = null;
  }

  getIcon(): string {
    switch (this.notification?.type) {
      case 'success':
        return 'check_circle';
      case 'error':
        return 'error';
      case 'warning':
        return 'warning';
      case 'info':
        return 'info';
      default:
        return 'info';
    }
  }

  getAriaLabel(): string {
    return `${this.notification?.type || 'notification'} message: ${this.notification?.message || ''}`;
  }
}
