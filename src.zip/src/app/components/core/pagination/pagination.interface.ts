/**
 * Interface for page size option configuration
 */
export interface PageSizeOption {
  name: string;
  value: number;
}

/**
 * Interface for pagination state
 */
export interface PaginationState {
  currentPage: number;
  pageSize: number;
  totalRecords: number;
  totalPages: number;
}

/**
 * Interface for pagination request parameters
 */
export interface PaginationRequest {
  pageNumber: number;
  pageSize: number;
}

/**
 * Interface for pagination response metadata
 */
export interface PaginationMetadata {
  currentPage: number;
  pageSize: number;
  totalRecords: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}
