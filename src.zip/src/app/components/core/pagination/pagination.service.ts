import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { PaginationMetadata, PaginationRequest } from './pagination.interface';

/**
 * Generic Pagination Service
 * Provides utilities for managing pagination state and calculations across the application
 *
 * Usage:
 * constructor(private paginationService: PaginationService) {}
 *
 * // Get pagination metadata
 * const metadata = this.paginationService.getPaginationMetadata(currentPage, pageSize, totalRecords);
 *
 * // Create pagination request
 * const request = this.paginationService.createPaginationRequest(1, 25);
 */
@Injectable({
  providedIn: 'root',
})
export class PaginationService {
  private paginationState$ = new BehaviorSubject<PaginationMetadata | null>(null);

  constructor() {}

  /**
   * Calculate total number of pages
   * @param totalRecords Total number of records
   * @param pageSize Number of records per page
   * @returns Total number of pages
   */
  calculateTotalPages(totalRecords: number, pageSize: number): number {
    if (pageSize <= 0) {
      return 1;
    }
    const pages = Math.ceil(totalRecords / pageSize);
    return pages > 0 ? pages : 1;
  }

  /**
   * Create pagination request object
   * @param pageNumber Current page number
   * @param pageSize Number of records per page
   * @returns PaginationRequest object
   */
  createPaginationRequest(pageNumber: number, pageSize: number): PaginationRequest {
    return {
      pageNumber: Math.max(1, pageNumber),
      pageSize: Math.max(1, pageSize),
    };
  }

  /**
   * Get pagination metadata
   * @param currentPage Current page number
   * @param pageSize Number of records per page
   * @param totalRecords Total number of records
   * @returns PaginationMetadata object
   */
  getPaginationMetadata(
    currentPage: number,
    pageSize: number,
    totalRecords: number
  ): PaginationMetadata {
    const totalPages = this.calculateTotalPages(totalRecords, pageSize);
    const hasNextPage = currentPage < totalPages;
    const hasPreviousPage = currentPage > 1;

    return {
      currentPage,
      pageSize,
      totalRecords,
      totalPages,
      hasNextPage,
      hasPreviousPage,
    };
  }

  /**
   * Validate page number
   * @param pageNumber Page number to validate
   * @param totalPages Total number of pages
   * @returns True if page number is valid
   */
  isValidPageNumber(pageNumber: number, totalPages: number): boolean {
    return pageNumber >= 1 && pageNumber <= totalPages;
  }

  /**
   * Get pagination state as observable
   * @returns Observable of PaginationMetadata
   */
  getPaginationState$(): Observable<PaginationMetadata | null> {
    return this.paginationState$.asObservable();
  }

  /**
   * Update pagination state
   * @param metadata PaginationMetadata to update
   */
  updatePaginationState(metadata: PaginationMetadata): void {
    this.paginationState$.next(metadata);
  }

  /**
   * Calculate offset for API requests (0-based)
   * @param pageNumber Current page number (1-based)
   * @param pageSize Number of records per page
   * @returns Offset value for API
   */
  calculateOffset(pageNumber: number, pageSize: number): number {
    return (pageNumber - 1) * pageSize;
  }

  /**
   * Calculate skip value for database queries
   * @param pageNumber Current page number (1-based)
   * @param pageSize Number of records per page
   * @returns Skip value for database
   */
  calculateSkip(pageNumber: number, pageSize: number): number {
    return this.calculateOffset(pageNumber, pageSize);
  }
}
