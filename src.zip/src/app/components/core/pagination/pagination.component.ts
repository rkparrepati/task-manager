import {
  Component,
  EventEmitter,
  Output,
  Input,
  SimpleChanges,
  OnInit,
  OnChanges,
  OnDestroy,
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PageSizeOption, PaginationState } from './pagination.interface';
import { UtilityService } from 'src/app/services/utility.service';

/**
 * Generic Pagination Component
 * Reusable pagination component for all grids with configurable page sizes and pagination controls
 *
 * Usage:
 * <app-pagination
 *   [currentPage]="currentPage"
 *   [recordsLength]="totalRecords"
 *   [pageSizeOptions]="customPageSizes"
 *   [maxSize]="2"
 *   [small]="false"
 *   [disabled]="isLoading"
 *   (pageChanged)="onPageChanged($event)"
 *   (pageSizeChanged)="onPageSizeChanged($event)">
 * </app-pagination>
 */
@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
})
export class PaginationComponent implements OnInit, OnChanges, OnDestroy {
  /** Default page size options */
  private readonly DEFAULT_PAGE_SIZE_OPTIONS: PageSizeOption[] = [
    { name: '10', value: 10 },
    { name: '25', value: 25 },
    { name: '50', value: 50 },
    { name: '100', value: 100 },
  ];

  /** Page size options - can be customized per grid */
  @Input() pageSizeOptions: PageSizeOption[] = this.DEFAULT_PAGE_SIZE_OPTIONS;

  /** Initial/current page size (items per page) */
  @Input() set pageSize(value: number) {
    if (value) {
      this.selected = value;
      this.updateTotalPages();
    }
  }

  /** Current page number */
  @Input() currentPage: number = 1;

  /** Total number of records */
  @Input() set recordsLength(value: number | null) {
    this.total = value ?? 0;
    this.updateTotalPages();
  }

  /** The number of buttons to show either side of the current page */
  @Input() maxSize: number = 2;

  /** Display small pagination buttons */
  @Input() small: boolean = false;

  /** Disable pagination controls */
  @Input() set disabled(value: boolean) {
    this.infraDisabled = value;
  }

  /** Emits when page number changes */
  @Output() pageChanged: EventEmitter<number> = new EventEmitter<number>();

  /** Emits when page size changes */
  @Output() pageSizeChanged: EventEmitter<number> = new EventEmitter<number>();

  /** Emits pagination state changes */
  @Output() paginationStateChanged: EventEmitter<PaginationState> =
    new EventEmitter<PaginationState>();

  // Internal properties
  infraDisabled: boolean = false;
  selected: number = this.DEFAULT_PAGE_SIZE_OPTIONS[0].value;
  total: number = 0;
  totalPages: number[] = [];

  private destroy$ = new Subject<void>();

  constructor(private utilityService: UtilityService) {
    // this.selected = this.DEFAULT_PAGE_SIZE_OPTIONS[0].value;
  }

  ngOnInit(): void {
    this.initializePagination();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['recordsLength'] || changes['pageSizeOptions']) {
      this.updateTotalPages();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize pagination on component load
   */
  private initializePagination(): void {
    this.updateTotalPages();
  }

  /**
   * Update total pages array based on current records and page size
   */
  private updateTotalPages(): void {
    // Ensure 'selected' has a value before calculating
    if (!this.selected && this.pageSizeOptions.length > 0) {
      this.selected = this.pageSizeOptions[0].value;
    }

    const totalPagesCount = this.calculateTotalPages();
    // IMPORTANT: Actually fill the array so *ngFor can loop over it
    this.totalPages = Array.from({ length: totalPagesCount }, (_, i) => i + 1);
  }

  /**
   * Calculate total number of pages
   */
  private calculateTotalPages(): number {
    // Use 'this.selected' (the items per page) to divide 'this.total' (40)
    const pages = Math.ceil(this.total / (this.selected || 10));
    return pages > 0 ? pages : 1;
  }
  /**
   * Handle page size selection change
   */
  selectedOptionChanged(): void {
    this.selected = Number(this.selected);
    this.currentPage = 1; // Reset to first page when page size changes
    this.updateTotalPages();
    this.utilityService.scrollToTop();
    this.pageSizeChanged.emit(this.selected);
    this.emitPaginationState();
  }

  /**
   * Set specific page number
   */
  selectPageNumber(pageNumber: number): void {
    if (pageNumber >= 1 && pageNumber <= this.totalPages.length && !this.infraDisabled) {
      this.currentPage = pageNumber;
      this.utilityService.scrollToTop();
      this.pageChanged.emit(this.currentPage);
      this.emitPaginationState();
    }
  }

  /**
   * Navigate to next page
   */
  next(): void {
    const nextPage = this.currentPage + 1;
    if (nextPage <= this.totalPages.length && !this.infraDisabled) {
      this.selectPageNumber(nextPage);
    }
  }

  /**
   * Navigate to previous page
   */
  previous(): void {
    const previousPage = this.currentPage - 1;
    if (previousPage >= 1 && !this.infraDisabled) {
      this.selectPageNumber(previousPage);
    }
  }

  /**
   * Check if current page is first page
   */
  isFirstPage(): boolean {
    return this.currentPage === 1;
  }

  /**
   * Check if current page is last page
   */
  isLastPage(): boolean {
    return this.currentPage === this.totalPages.length;
  }

  /**
   * Get current pagination state
   */
  getPaginationState(): PaginationState {
    return {
      currentPage: this.currentPage,
      pageSize: this.selected,
      totalRecords: this.total,
      totalPages: this.totalPages.length,
    };
  }

  /**
   * Reset pagination to initial state
   * Resets current page to 1 and recalculates total pages
   * Can be called from parent component when filters/search changes
   *
   * Usage:
   * @ViewChild(PaginationComponent) paginationComponent!: PaginationComponent;
   *
   * onSearch() {
   *   this.paginationComponent.resetPagination();
   *   this.loadData();
   * }
   */
  resetPagination(): void {
    this.currentPage = 1;

    // Reset 'selected' to the first value in your options array (usually 10)
    if (this.pageSizeOptions && this.pageSizeOptions.length > 0) {
      this.selected = this.pageSizeOptions[0].value;
    }
    this.utilityService.scrollToTop();
    this.updateTotalPages();
    this.emitPaginationState();
  }

  /**
   * Emit current pagination state
   */
  private emitPaginationState(): void {
    this.paginationStateChanged.emit(this.getPaginationState());
  }

  /**
   * Get the starting record number for current page
   */
  getStartRecord(): number {
    if (this.total === 0) return 0;
    return (this.currentPage - 1) * this.selected + 1;
  }

  /**
   * Get the ending record number for current page
   */
  getEndRecord(): number {
    const end = this.currentPage * this.selected;
    return end > this.total ? this.total : end;
  }
}
