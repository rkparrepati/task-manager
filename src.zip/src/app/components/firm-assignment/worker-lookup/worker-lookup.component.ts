import { Component } from '@angular/core';
import { FirmAssignmentService } from '../firm-assignment.service';
import { MatDialogRef } from '@angular/material/dialog';

interface FirmWorkerSearch {
  workerNumber?: string;
  loginId?: string;
  firmName?: string | null;
  familyName?: string | null;
  givenName?: string | null;
  includeInactive?: boolean;
}

@Component({
  selector: 'app-worker-lookup',
  templateUrl: './worker-lookup.component.html',
  styleUrls: ['./worker-lookup.component.scss'],
})
export class WorkerLookupComponent {
  availableFirms: any[] = [];
  firmWorkerSearchList: any[] = [];
  showFirmWorkerSearchMessage: boolean = false;
  returnMessage: string = '';
  firmWorkerSearch: FirmWorkerSearch = {
    includeInactive: false,
    loginId: '',
    firmName: '',
    familyName: '',
    givenName: '',
  };

  constructor(
    private firmAssignmentService: FirmAssignmentService,
    private dialogRef: MatDialogRef<WorkerLookupComponent>
  ) {}

  ngOnInit(): void {
    this.firmAssignmentService.getAvailableFirms().subscribe((response: any) => {
      this.availableFirms = [
        {
          firmName: 'All',
          description: '',
        },
      ];
      this.availableFirms = [...this.availableFirms, ...response.results];
      this.availableFirms.forEach((firm) => {
        firm.selectDescription = firm.description.slice(0, 50);
      });
    });
  }

  searchWorker(): void {
    this.firmAssignmentService.searchWorker(this.firmWorkerSearch).subscribe(
      (response) => {
        this.firmWorkerSearchList = response.results;
        this.showFirmWorkerSearchMessage = false;
      },
      (error) => {
        this.firmWorkerSearchList = [];
        this.returnMessage = error.error.message;
        this.showFirmWorkerSearchMessage = true;
      }
    );
  }

  hideFirmWorkerSearchMessage(): void {
    this.showFirmWorkerSearchMessage = false;
  }

  clearFirmWorkerSearchFields(): void {
    this.firmWorkerSearch = {};
    this.firmWorkerSearchList = [];
    this.showFirmWorkerSearchMessage = false;
  }

  searchWorkerKeyEvent(event: any): void {
    if (event.keyCode === 13) {
      this.searchWorker();
    }
  }
  confirm(worker: any) {
    this.dialogRef.close(worker);
  }
  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }

  isButtonEnabled(): boolean {
    return !(
      this.firmWorkerSearch.loginId ||
      this.firmWorkerSearch.firmName ||
      this.firmWorkerSearch.familyName ||
      this.firmWorkerSearch.givenName
    );
  }
}
