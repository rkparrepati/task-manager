import { Component, OnInit, ChangeDetectorRef, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FirmAssignmentService } from './firm-assignment.service';
import { MatDialog } from '@angular/material/dialog';
import { ScrollStrategyOptions } from '@angular/cdk/overlay';
import { WorkerLookupComponent } from './worker-lookup/worker-lookup.component';
import { ConfirmationDialogComponent } from '../core/confirmation-dialog/confirmation-dialog.component';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

interface Worker {
  workerNumber: string;
  familyName: string;
  givenName: string;
  workerId: string;
  loginId: string;
}

interface Firm {
  id: number;
  value: string;
  description: string;
  displayItem?: string;
}

@Component({
  selector: 'app-firm-assignment',
  templateUrl: './firm-assignment.component.html',
  styleUrls: ['./firm-assignment.component.scss'],
})
export class FirmAssignmentComponent implements OnInit {
  firmWorkerSearch: FormGroup;
  worker: Worker | null = null;
  availableFirms: Firm[] = [];
  assignedFirms: any[] = [];
  selectedAvailableFirm: Firm[] = [];
  selectedAssignedFirm: any[] = [];
  initialAvailableFirms: Firm[] = [];
  initialAssignedFirms: any[] = [];
  assignFirmSaveList: any[] = [];
  unassignFirmSaveList: any[] = [];
  allFirmsAssigned: boolean = true;
  showContractorInfo = false;
  loading = false;
  errorMessage = '';
  lastModifiedDate = '';
  lastModifiedLoginId = '';
  userRoles: string[] = ['InfraAdmin']; // TODO: Get from auth service
  showWorkerNumberErrors = false; // Flag to control when to show validation errors
  hasOperationsPerformed = false; // Flag to control when to open clear firm assignment dialog

  // Toast message properties for acme-navbar-component
  main = { creationDate: new Date() };
  returnCode: string | number | null = null;
  hideMessage: boolean = true;
  returnMessage: string = '';

  constructor(
    private formBuilder: FormBuilder,
    public firmAssignmentService: FirmAssignmentService,
    private dialog: MatDialog,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private scrollStrategyOptions: ScrollStrategyOptions
  ) {
    this.firmWorkerSearch = this.formBuilder.group({
      workerNumber: ['', [Validators.required, Validators.minLength(5)]],
    });
  }

  ngOnInit(): void {
    this.firmAssignmentService.updateHideMessage(true);
  }

  searchWorker(): void {
    if (this.firmWorkerSearch.invalid) {
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.showContractorInfo = false;
    // Clear any previous toast messages
    this.firmAssignmentService.updateHideMessage(true);

    this.firmAssignmentService
      .searchWorker(this.firmWorkerSearch.value)
      .pipe(
        catchError((error) => {
          this.loading = false;
          this.showContractorInfo = false;

          // Test case 1: Invalid worker number - 404 not found, display with 404 warning toast (yellow)
          if (error.status === 404) {
            this.firmAssignmentService.updateReturnCode(404);
            this.firmAssignmentService.updateReturnMessage(
              'No workers found that match the query'
            );
            this.firmAssignmentService.updateHideMessage(false);
          } else {
            this.errorMessage = error.message || 'Error searching for worker';
          }

          return of(null);
        })
      )
      .subscribe({
        next: (workers) => {
          this.loading = false;
          
          if (workers && workers.results && workers.results.length > 0) {
            const worker = workers.results[0];
            this.worker = {
              workerNumber: worker.workerNumber,
              familyName: worker.familyName,
              givenName: worker.givenName,
              workerId: worker.workerId,
              loginId: worker.loginId,
            };

            if (!this.worker.loginId) {
              this.errorMessage = 'Worker does not have a required Login Id.';
              this.showContractorInfo = false;
              this.firmAssignmentService.updateReturnCode(404);
              this.firmAssignmentService.updateReturnMessage(
                'Worker does not have a required Login Id.'
              );
              this.firmAssignmentService.updateHideMessage(false);
              return;
            }

            // Test case 2: Valid worker number found - display worker info (no toast)
            this.getContractorFirms();
          } else if (workers && workers.results && workers.results.length === 0) {
            // No results found - display 404 warning toast (yellow)
            this.firmAssignmentService.updateReturnCode(404);
            this.firmAssignmentService.updateReturnMessage(
              'No workers found that match the query'
            );
            this.firmAssignmentService.updateHideMessage(false);
            this.showContractorInfo = false;
          }
        },
        error: (error) => {
          this.loading = false;
          this.showContractorInfo = false;
          this.errorMessage = error.message || 'Error searching for worker';
        }
      });
  }

  getContractorFirms(): void {
    if (!this.worker) {
      console.error('getContractorFirms: Worker is null, cannot fetch firms');
      return;
    }
    // Reset selection arrays before refreshing
    this.selectedAvailableFirm = [];
    this.selectedAssignedFirm = [];

    this.firmAssignmentService.getAvailableFirms().subscribe({
      next: (firms) => {
       this.availableFirms = firms.results.map((firm: Firm) => ({
          ...firm,
          displayItem: this.firmAssignmentService.getFirmDisplayOptionText(
            firm.value,
            firm.description
          ),
        }));
        this.initialAvailableFirms = [...this.availableFirms];

        this.firmAssignmentService.getWorkerFirmAssignments(this.worker!.workerNumber).subscribe({
          next: (assignedFirms) => {
            // Format the displayItem for assigned firms to match available firms display
            const formattedAssignedFirms = assignedFirms.map((assigned: any) => ({
              ...assigned,
              firm: {
                ...assigned.firm,
                displayItem: this.firmAssignmentService.getFirmDisplayOptionText(
                  assigned.firm.value,
                  assigned.firm.description
                )
              }
            }));
            
            // Create new array reference to trigger change detection
            this.assignedFirms = [...formattedAssignedFirms];
            this.initialAssignedFirms = [...this.assignedFirms];

            // Remove assigned firms from available firms
            // Handle both possible response structures: array of firms or object with results
            const assignedFirmsArray = Array.isArray(assignedFirms) ? assignedFirms : (assignedFirms?.results || []);
            
            // Check if worker has "ALL FIRMS" assigned (firm with id 0)
            const hasAllFirmsEntry = this.assignedFirms.some((assigned: any) => assigned.firm?.id === 0);
            
            let filteredAvailableFirms: Firm[] = [];
            if (hasAllFirmsEntry) {
              // If "ALL FIRMS" entry exists, set flag to true and clear available firms
              this.allFirmsAssigned = true;
              filteredAvailableFirms = [];
            } else {
              // Otherwise, filter out assigned firms from available firms
              filteredAvailableFirms = this.availableFirms.filter(
                (available) =>
                  !assignedFirmsArray.some((assigned: any) => {
                    // Handle both nested firm structure and direct structure
                    const assignedFirmId = assigned.firm?.id || assigned.id;
                    return assignedFirmId === available.id;
                  })
              );
              
              // Set flag based on whether there are any available firms left
              this.allFirmsAssigned = filteredAvailableFirms.length === 0;
            }
            
            // Create new array reference to trigger change detection
            this.availableFirms = [...filteredAvailableFirms];
            
            this.showContractorInfo = true;

            if (this.assignedFirms.length > 0) {
              this.lastModifiedDate = this.assignedFirms[0].createdDate;
              this.getWorkerLoginId(this.assignedFirms[0].createdUser);
            }

            this.cdr.detectChanges();
          },
          error: (error) => {
            // Even if there's an error getting assigned firms, still show the worker info
            this.assignedFirms = [...[]];
            this.initialAssignedFirms = [...[]];
            this.allFirmsAssigned = false;
            this.showContractorInfo = true;
            this.cdr.detectChanges();
          },
        });
      },
      error: (error) => {
        // If there's an error getting available firms, try to continue with assigned firms
        console.error('getContractorFirms: Error getting available firms:', error);
        this.availableFirms = [...[]];
        this.initialAvailableFirms = [...[]];
        // Still try to get assigned firms
        this.firmAssignmentService.getWorkerFirmAssignments(this.worker!.workerNumber).subscribe({
          next: (assignedFirms) => {
            this.assignedFirms = [...assignedFirms];
            this.initialAssignedFirms = [...this.assignedFirms];
            this.allFirmsAssigned = false;
            this.showContractorInfo = true;

            if (this.assignedFirms.length > 0) {
              this.lastModifiedDate = this.assignedFirms[0].createdDate;
              this.getWorkerLoginId(this.assignedFirms[0].createdUser);
            }
            this.cdr.detectChanges();
          },
          error: (error) => {
            console.error('getContractorFirms: Error getting assigned firms (fallback):', error);
            this.assignedFirms = [...[]];
            this.showContractorInfo = true;
            this.cdr.detectChanges();
          },
        });
      },
    });
  }

  getWorkerLoginId(workerId: string): void {
    this.firmAssignmentService.getWorkerLoginId(workerId).subscribe({
      next: (response) => {
        this.lastModifiedLoginId = response.loginId;
      },
      error: () => {
        this.lastModifiedLoginId = '';
      },
    });
  }

  assignFirms(): void {
    if (!this.selectedAvailableFirm.length) return;

    // Add each selected firm to assigned firms
    this.selectedAvailableFirm.forEach((firm) => {
      const assignFirm = {
        firm: {
          id: firm.id,
          value: firm.value,
          description: firm.description,
          displayItem: firm.displayItem,
        },
        worker: this.worker,
        createdDate: new Date().toISOString(),
      };
      this.assignedFirms.push(assignFirm);
      
      if (!this.assignFirmSaveList) {
        this.assignFirmSaveList = [];
      }
      this.assignFirmSaveList.push(assignFirm);
    });

    // Remove from available firms using the legacy logic with index management
    this.selectedAvailableFirm.forEach((firm) => {
      for (let index = this.availableFirms.length - 1; index >= 0; index--) {
        if (this.availableFirms[index].id === firm.id) {
          this.availableFirms.splice(index, 1);
        }
      }
    });

    this.selectedAvailableFirm = [];

    // Remove from unassign save list if they were there
    this.unassignFirmSaveList = this.removeFromUnassignSaveList(
      this.assignFirmSaveList,
      this.unassignFirmSaveList
    );
    
    this.allFirmsAssigned = this.availableFirms.length === 0;
    this.hasOperationsPerformed = true; // Set flag when operation is performed
  }

  unassignFirms(): void {
    if (!this.selectedAssignedFirm.length) return;

    // Add firms back to available (excluding "All Firms" with id 0)
    this.selectedAssignedFirm.forEach((contractorFirm) => {
      if (contractorFirm.firm.id !== 0) {
        // Ensure displayItem is set when adding back to available
        const firmToAdd = {
          ...contractorFirm.firm,
          displayItem: contractorFirm.firm.displayItem ||
            this.firmAssignmentService.getFirmDisplayOptionText(
              contractorFirm.firm.value,
              contractorFirm.firm.description
            )
        };
        this.availableFirms.push(firmToAdd);
      }
    });

    // Remove from assigned firms using the legacy logic with index management
    this.selectedAssignedFirm.forEach((firm) => {
      for (let index = this.assignedFirms.length - 1; index >= 0; index--) {
        if (this.assignedFirms[index].firm.id === firm.firm.id) {
          this.assignedFirms.splice(index, 1);
        }
      }
    });

    // Add to unassign save list
    this.selectedAssignedFirm.forEach((firm) => {
      if (!this.unassignFirmSaveList) {
        this.unassignFirmSaveList = [];
      }
      this.unassignFirmSaveList.push(firm);
    });

    this.selectedAssignedFirm = [];

    // Remove from assign save list if they were there
    this.assignFirmSaveList = this.removeFromAssignSaveList(
      this.assignFirmSaveList,
      this.unassignFirmSaveList
    );

    this.allFirmsAssigned = this.availableFirms.length === 0;
    this.hasOperationsPerformed = true; // Set flag when operation is performed
  }

  /**
   * Helper method to remove items from unassign save list that are in assign save list
   */
  private removeFromUnassignSaveList(assignList: any[], unassignList: any[]): any[] {
    return unassignList.filter(
      (unassign) => !assignList.some((assign) => assign.firm.id === unassign.firm.id)
    );
  }

  /**
   * Helper method to remove items from assign save list that are in unassign save list
   */
  private removeFromAssignSaveList(assignList: any[], unassignList: any[]): any[] {
    return assignList.filter(
      (assign) => !unassignList.some((unassign) => unassign.firm.id === assign.firm.id)
    );
  }

  saveFirmAssignment(): void {
    this.loading = true;
    this.errorMessage = '';

    const unassignIds = this.unassignFirmSaveList
      .map((firm) => firm.workerContractorFirmAssignmentId)
      .filter((id) => id);

    
    if (this.assignFirmSaveList.length > 0 && unassignIds.length > 0) {
      this.saveWithBoth(unassignIds);
    } else if (this.assignFirmSaveList.length > 0) {
      this.saveAssignOnly();
    } else if (unassignIds.length > 0) {
     this.saveUnassignOnly(unassignIds);
    }
  }

  private saveWithBoth(unassignIds: string[]): void {
   this.firmAssignmentService.assignFirms(this.assignFirmSaveList).subscribe({
      next: () => {
        this.firmAssignmentService.unassignFirms(unassignIds).subscribe({
          next: () => {
           this.handleSaveSuccess();
          },
          error: (error) => {
            console.error('saveWithBoth: Unassign error:', error);
            this.handleSaveError(error);
          },
        });
      },
      error: (error) => {
        console.error('saveWithBoth: Assign error:', error);
        this.handleSaveError(error);
      },
    });
  }

  private saveAssignOnly(): void {
    this.firmAssignmentService.assignFirms(this.assignFirmSaveList).subscribe({
      next: () => {
        this.handleSaveSuccess();
      },
      error: (error) => {
        console.error('saveAssignOnly: Assign error:', error);
        this.handleSaveError(error);
      },
    });
  }

  private saveUnassignOnly(unassignIds: string[]): void {
   this.firmAssignmentService.unassignFirms(unassignIds).subscribe({
      next: (response) => {
        this.handleSaveSuccess();
      },
      error: (error) => {
        console.error('saveUnassignOnly: Unassign error:', error);
        this.handleSaveError(error);
      },
      complete: () => {
       }
    });
  }

  private handleSaveSuccess(): void {
    this.loading = false;
    
    // Test case 3: Successfully saved - display 200 status success toast
    this.firmAssignmentService.updateReturnCode(200);
    this.firmAssignmentService.updateReturnMessage('Successfully assigned/unassigned firms.');
    this.firmAssignmentService.updateHideMessage(false);
    
    // Store unassigned firm IDs before clearing the list
    const unassignedFirmIds = this.unassignFirmSaveList.map((firm: any) => firm.firm?.id || firm.id);
    
    // Clear save lists and selection arrays before refreshing
    this.assignFirmSaveList = [];
    this.unassignFirmSaveList = [];
    this.selectedAvailableFirm = [];
    this.selectedAssignedFirm = [];
    
     if (!this.worker) {
      console.error('handleSaveSuccess: Worker is null, cannot refresh firms');
      return;
    }
    
     // Fetch available firms
    this.firmAssignmentService.getAvailableFirms().subscribe({
      next: (firmsResponse) => {
         const availableFirmsData = firmsResponse.results.map((firm: Firm) => ({
          ...firm,
          displayItem: this.firmAssignmentService.getFirmDisplayOptionText(firm.value, firm.description),
        })); 
        // Fetch assigned firms
        this.firmAssignmentService.getWorkerFirmAssignments(this.worker!.workerNumber).subscribe({
          next: (assignedFirmsResponse) => {
            
            // Map assigned firms
            const assignedFirmsData = assignedFirmsResponse.map((assigned: any) => ({
              ...assigned,
              firm: {
                ...assigned.firm,
                displayItem: this.firmAssignmentService.getFirmDisplayOptionText(
                  assigned.firm.value,
                  assigned.firm.description
                )
              }
            }));
            
            // Create new array references
            this.assignedFirms = [...assignedFirmsData];
            this.initialAssignedFirms = [...this.assignedFirms];
            
            // Filter logic with unassigned firms exclusion
            const assignedFirmsArray = Array.isArray(assignedFirmsResponse) ? assignedFirmsResponse : (assignedFirmsResponse?.results || []);
            
            let filteredAvailableFirms: Firm[] = [];
            filteredAvailableFirms = availableFirmsData.filter((available: Firm) => {
              const isCurrentlyAssigned = assignedFirmsArray.some((assigned: any) => {
                const assignedFirmId = assigned.firm?.id || assigned.id;
                return assignedFirmId === available.id;
              });
              const wasJustUnassigned = unassignedFirmIds.includes(available.id);
              const shouldKeep = !isCurrentlyAssigned && !wasJustUnassigned;
              return shouldKeep;
            });
            
            this.availableFirms = [...filteredAvailableFirms];
            this.initialAvailableFirms = [...this.availableFirms];
            
            this.cdr.detectChanges();
          },
          error: (error) => {
            console.error('handleSaveSuccess: Error fetching assigned firms:', error);
            this.assignedFirms = [...[]];
            this.initialAssignedFirms = [...[]];
            this.cdr.detectChanges();
          }
        });
      },
      error: (error) => {
        console.error('handleSaveSuccess: Error fetching available firms:', error);
        this.availableFirms = [...[]];
        this.initialAvailableFirms = [...[]];
        this.cdr.detectChanges();
      }
    });
  }

  private handleSaveError(error: any): void {
    this.loading = false;
    this.errorMessage = error.message || 'Error saving firm assignments';
    console.error('handleSaveError: Save operation failed:', error);
  }

  clearFirmAssignment(): void {
    // Only open dialog if operations have been performed
    if (!this.hasOperationsPerformed) {
      //clear the input
      this.performClearFirmAssignment();
      return;
    }

    // There are unsaved changes, show confirmation dialog
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      disableClose: true,
      width: '450px',
      data: {
        title: 'Clear Firm Assignment',
        message: 'There are one or more firms selected for assignment/unassignment.<br/>Click confirm to clear.',
        buttonText: {
          ok: 'Confirm',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.performClearFirmAssignment();
      }
    });
  }

  /**
   * Helper method to perform the actual reset logic
   */
  private performClearFirmAssignment(): void {
    this.firmWorkerSearch.reset();
    this.assignFirmSaveList = [];
    this.unassignFirmSaveList = [];
    this.showContractorInfo = false;
    this.errorMessage = '';
    this.showWorkerNumberErrors = false; // Reset error display flag
    this.hasOperationsPerformed = false; // Reset operations flag
    // Clear toast messages
    this.firmAssignmentService.updateHideMessage(true)
  }

  manageAllFirms(): void {
    this.hideMessage = true;
    this.hasOperationsPerformed = true; // Set flag when operation is performed
    
    if (this.allFirmsAssigned) {
      // First, handle unassigning all current firms
      // Add all assigned firms to unassign save list (but don't add back to available yet)
      this.assignedFirms.forEach((firm) => {
        if (!this.unassignFirmSaveList) {
          this.unassignFirmSaveList = [];
        }
        this.unassignFirmSaveList.push(firm);
      });
      
      // Update assign save list
      this.assignFirmSaveList = this.removeFromAssignSaveList(
        this.assignFirmSaveList,
        this.unassignFirmSaveList
      );
      
      // Now create the ALL FIRMS entry
      const assignFirm = {
        firm: {
          id: 0,
          value: 'ALL FIRMS',
          description: 'ALL FIRMS',
          displayItem: this.firmAssignmentService.getFirmDisplayOptionText('ALL FIRMS', 'ALL FIRMS'),
        },
        worker: this.worker,
        createdDate: new Date().toISOString(),
      };
      
      this.assignedFirms = [];
      this.assignedFirms.push(assignFirm);
      
      if (!this.assignFirmSaveList) {
        this.assignFirmSaveList = [];
      }
      this.assignFirmSaveList.push(assignFirm);
      
      this.availableFirms = [];
      
      // Trigger change detection
      this.cdr.detectChanges();
    } else {
      // Restore available firms from initial state (already has proper displayItems)
      this.availableFirms = [...this.initialAvailableFirms];
      
      // Add all currently assigned firms to unassign save list
      this.assignedFirms.forEach((firm) => {
        if (!this.unassignFirmSaveList) {
          this.unassignFirmSaveList = [];
        }
        this.unassignFirmSaveList.push(firm);
      });
      
      // Clear assigned firms
      this.assignedFirms = [];
      this.selectedAssignedFirm = [];
      
      // Update assign save list
   ;   this.assignFirmSaveList = this.removeFromAssignSaveList(
        this.assignFirmSaveList,
        this.unassignFirmSaveList
      );
      
      // Trigger change detection
      this.cdr.detectChanges();
    }
  }

  unassignAllFirms(): void {
    // Add all assigned firms back to available firms
    this.assignedFirms.forEach((contractorFirm) => {
      // Ensure displayItem is set when adding back to available
      const firmToAdd = {
        ...contractorFirm.firm,
        displayItem: contractorFirm.firm.displayItem ||
          this.firmAssignmentService.getFirmDisplayOptionText(
            contractorFirm.firm.value,
            contractorFirm.firm.description
          )
      };
      this.availableFirms.push(firmToAdd);
    });
    
    // Add all assigned firms to unassign save list
    this.assignedFirms.forEach((firm) => {
      if (!this.unassignFirmSaveList) {
        this.unassignFirmSaveList = [];
      }
      this.unassignFirmSaveList.push(firm);
    });
    
    this.assignedFirms = [];
    
    this.assignFirmSaveList = this.removeFromAssignSaveList(
      this.assignFirmSaveList,
      this.unassignFirmSaveList
    );
    
    this.hasOperationsPerformed = true; // Set flag when operation is performed
  }

  assignAllFirms(): void {
    this.allFirmsAssigned = true;
    this.manageAllFirms();
    
    // Refresh arrays by creating new references
    this.assignedFirms = [...this.assignedFirms];
    this.availableFirms = [...this.availableFirms];
  }

  searchWorkerKeyEvent(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.showWorkerNumberErrors = true; // Enable error display when Enter is pressed
      this.searchWorker();
    } else {
      // Reset error display flag when user types or deletes (including backspace)
      this.showWorkerNumberErrors = false;
    }
  }

  showWorkerSearchDialog(event?: Event) {
    // Blur the button to remove focus and prevent aria-hidden accessibility issue
    if (event && event.target instanceof HTMLElement) {
      event.target.blur();
    }
    
    // Clear any previous toast messages
    this.firmAssignmentService.updateHideMessage(true);
    
    const dialogRef = this.dialog.open(WorkerLookupComponent, {
      disableClose: true,
      width: '60vw',
      height: '75vh',
      maxHeight: '100vh',
      hasBackdrop: true,
    });
    dialogRef.afterClosed().subscribe((worker: any) => {
      
      // If dialog was cancelled or closed without selection, do nothing (preserve existing data)
      if (!worker || worker === 'continue') {
        return;
      }
      
      // If worker doesn't have loginId, show error but don't clear existing data
      if (worker.workerNumber && !worker.loginId) {
        this.firmAssignmentService.updateReturnCode(404);
        this.firmAssignmentService.updateReturnMessage(
          'Worker does not have a required Login Id.'
        );
        this.firmAssignmentService.updateHideMessage(false);
        this.firmWorkerSearch.setValue({
          workerNumber: worker.workerNumber,
        });
        this.showContractorInfo = false;
        return;
      }
      
      // Valid worker selected - update the form and load contractor firms
      if (worker.workerNumber) {
        this.firmWorkerSearch.setValue({
          workerNumber: worker.workerNumber,
        });
        this.worker = {
          workerNumber: worker.workerNumber,
          familyName: worker.familyName,
          givenName: worker.givenName,
          workerId: worker.workerId,
          loginId: worker.loginId,
        };
        // Test case 2: Valid worker from lookup - no toast message
        this.getContractorFirms();
        this.showContractorInfo=true;
      }
    });
  }

  /**
   * This method confirms and exits to landing page
   * Checks if there are unsaved changes and shows confirmation dialog
   */
  gotoLandingPage(): void {
    // Check if there are any unsaved changes
      this.returnCode = null;
      this.returnMessage = '';
    if (
      (!this.assignFirmSaveList || this.assignFirmSaveList.length === 0) &&
      (!this.unassignFirmSaveList || this.unassignFirmSaveList.length === 0)
    ) {
      // No unsaved changes, navigate directly to home
      this.router.navigate(['/']);
    } else {
      // There are unsaved changes, show confirmation dialog
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        disableClose: true,
        width: '450px',
        data: {
          title: 'Exit Firm Assignment',
          message: 'There are one or more firms selected for assignment/unassignment.<br/>Click confirm to exit.',
          buttonText: {
            ok: 'Confirm',
            cancel: 'Cancel'
          }
        }
      });

      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
        if (confirmed) {
          // User confirmed, navigate to home
          this.router.navigate(['/']);
        }
        // If not confirmed, dialog just closes and user stays on the page
      });
    }
  }
}
