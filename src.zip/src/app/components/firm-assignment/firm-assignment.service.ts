import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpService } from 'src/app/services/http.service';

@Injectable({
  providedIn: 'root',
})
export class FirmAssignmentService {
  // Toast message management (similar to TransferSearchService)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();

  constructor(private httpService: HttpService) {}

  // Methods to update toast messages
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  getAvailableFirms(): Observable<any> {
    const params = {
      sortOrder: 'asc',
    };
    return this.httpService.get(`/references/contractor-firms?${this.httpService.mergeQueryParams(params)}`, false);
  }

  getWorkerFirmAssignments(workerNumber: string): Observable<any> {
     const params = {
      workerNumber: workerNumber,
      assignedFirms: 'true',
      sortColumn: 'createdDate',
      sortOrder: 'desc',
    };
    return this.httpService.get(`/contractor-firms?${this.httpService.mergeQueryParams(params)}`, false);
  }

  searchWorker(searchParams: any): Observable<any> {
    // Build params in specific order to match legacy implementation
    const params: any = {
      includeInactive: false,
      workerNumber: searchParams.workerNumber || null,
      loginId: searchParams.loginId || null,
      firmName: searchParams.firmName || null,
      familyName: searchParams.familyName || null,
      givenName: searchParams.givenName || null,
    };
    
    // Remove null values to match legacy behavior
    Object.keys(params).forEach(key => {
      if (params[key] === null || params[key] === '') {
        delete params[key];
      }
    });

    return this.httpService.get(`/workers?${this.httpService.mergeQueryParams(params)}`, false);
  }

  getWorkerLoginId(workerId: string): Observable<any> {
    return this.httpService.get(`/workers/${workerId}`, false);
  }

  assignFirms(firmsList: any[]): Observable<any> {
    // Format the payload to match legacy implementation
    const formattedList = firmsList.map(item => ({
      ...item,
      firm: {
        ...item.firm,
        // Trim the value
        value: item.firm.value ? item.firm.value.trim() : item.firm.value,
        // Convert HTML entities back to regular text (like htmlDecode in legacy)
        displayItem: item.firm.displayItem ? this.htmlDecode(item.firm.displayItem) : item.firm.displayItem
      },
      // Format date using adjustDateFormatter logic from legacy
      createdDate: item.createdDate ? this.adjustDateFormatter(item.createdDate) : item.createdDate
    }));
    
    return this.httpService.post(`/contractor-firms`, formattedList);
  }

  /**
   * Mimics the htmlDecode function from legacy firmAssignmentHelper.js
   * Converts HTML entities back to regular text
   */
  private htmlDecode(input: string): string {
    const e = document.createElement('div');
    e.innerHTML = input;
    return e.childNodes[0]?.nodeValue || input;
  }

  /**
   * Mimics the adjustDateFormatter function from legacy utilities.service.js
   * Takes a date and formats it as YYYY-MM-DDTHH:mm:ss using current UTC time
   */
  private adjustDateFormatter(dateInput: string | Date): string {
    const now = new Date();
    const currentUTCDate = new Date(now.getTime() + (now.getTimezoneOffset() * 60000));
    const hours = String(currentUTCDate.getHours()).padStart(2, '0');
    const minutes = String(currentUTCDate.getMinutes()).padStart(2, '0');
    const seconds = String(currentUTCDate.getSeconds()).padStart(2, '0');
    const time = 'T' + hours + ':' + minutes + ':' + seconds;
    
    let dateStr = typeof dateInput === 'string' ? dateInput : dateInput.toISOString();
    // Take only the date part (YYYY-MM-DD) and append current UTC time
    return dateStr.substring(0, 10) + time;
  }

  unassignFirms(firmsList: string[]): Observable<any> {
    return this.httpService.post(`/contractor-firms/dissociations`, firmsList);
  }
  getFirmDisplayOptionText(val: string = '', desc: string = ''): string {
    const valLength = 30;
    const descLength = 50;

    val =
      val.length > valLength
        ? val.slice(0, valLength - 5) + '&hellip;&nbsp;&nbsp;&nbsp;&nbsp;'
        : val;
    desc =
      desc.length > descLength
        ? desc.slice(0, descLength - 5) + '&hellip;&nbsp;&nbsp;&nbsp;&nbsp;'
        : desc;

    const spaceToAdd = valLength - val.length;
    val += spaceToAdd > 0 ? Array(spaceToAdd + 1).join('&nbsp;') : '';
    val += desc;

    return val;
  }
}


/*
:host ::ng-deep .mat-mdc-dialog-surface.mdc-dialog__surface {
  overflow: hidden !important;
  max-height: 90vh !important;
}

:host ::ng-deep .mat-mdc-dialog-container .mdc-dialog__container {
  overflow: hidden !important;
}

:host ::ng-deep .mat-mdc-dialog-content {
  overflow: hidden !important;
  max-height: 700px !important;
}
*/