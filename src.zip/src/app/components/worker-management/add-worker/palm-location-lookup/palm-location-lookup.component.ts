import { Component, Inject, Optional, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpService } from 'src/app/services/http.service';

export interface PalmLocation {
  palmLocationId: number;
  visualLocationCode: string;
  dbLocationCode: string | null;
  description: string;
  systemName: string;
  lifecycle?: Lifecycle;
  audit?: Audit;
  errorMessageId: string;
}

export enum Messages{
   PALM_LOCATION_NOT_FOUND_ERROR_MESSAGE = 'No palm location(s) found'
}

export interface Lifecycle {
  beginDate: string; // ISO date string
}

export interface Audit {
  createdDate: string; // ISO date string
  createdUser: string;
  lastModifiedDate: string; // ISO date string
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

@Component({
  selector: 'app-palm-location-lookup',
  templateUrl: './palm-location-lookup.component.html',
  styleUrls: ['./palm-location-lookup.component.scss'],
})
export class PalmLocationLookupComponent implements OnInit {
  palmLocationSearchText: string = '';
  showPalmLocationMessage: boolean = false;
  showPalmLocationNumber: boolean = false;
  palmLocations: PalmLocation[] = [];
  palmLocationLookupRequired: boolean = false;
  totalRecords: number = 0;
  errorMessageId: string = '';
 

  constructor(
    private httpService: HttpService,
    private dialogRef: MatDialogRef<PalmLocationLookupComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    // If initial search value is provided, populate it in the search box
    // Do NOT trigger search automatically - user must click Search button
    if (this.data && this.data.initialSearchValue) {
      this.palmLocationSearchText = this.data.initialSearchValue.toUpperCase();
    }
  }

  hidePalmLocationMessage() {}

  filterPalmLocation() {
    let url = `/palmlocations?search=${this.palmLocationSearchText}`;
    if (this.palmLocationSearchText.length) {
      url += `&codePrefix=${this.palmLocationSearchText}`;
    }
    this.httpService.get(url).subscribe({
      next: (response: any) => {
        this.palmLocations = response.results.map((location: any) => ({
          visualLocationCode: location.visualLocationCode,
          palmLocationId: location.palmLocationId,
          dbLocationCode: location.dbLocationCode,
          description: location.description,
          systemName: location.systemName,
        }));
        // Update total records count and show the count display
        this.totalRecords = this.palmLocations.length;
        this.showPalmLocationNumber = this.totalRecords > 0;
        this.showPalmLocationMessage = false;
      },
      error: (err) => {
        if (err.status === 404) {
          this.palmLocations = [];
          this.totalRecords = 0;
          this.showPalmLocationNumber = false;
          this.errorMessageId = Messages.PALM_LOCATION_NOT_FOUND_ERROR_MESSAGE;
          this.showPalmLocationMessage = true;
        }
        return [];
      },
    });
  }

  clearPalmLocationSearch() {
    this.palmLocationSearchText = '';
    this.totalRecords = 0;
    this.palmLocations = [];
    this.showPalmLocationMessage = false;
    this.showPalmLocationNumber = false;
  }
  confirm(palmLocation: PalmLocation) {
    this.closeThisDialog(palmLocation);
  }

  closeThisDialog(message: any) {
    this.dialogRef.close(message);
  }

  filterPalmLocationOnEnter(event: any) {
    //this.errorMessageId= this.
  }
}
