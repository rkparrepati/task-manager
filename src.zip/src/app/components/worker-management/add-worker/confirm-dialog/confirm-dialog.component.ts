import { Component, EventEmitter, Output, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
})
export class ConfirmDialogComponent {
  @Output() confirmEvent: EventEmitter<any> = new EventEmitter();
  inputConfirmObject: any = {
    type: '',
    value: '',
  };
  errorMessage: string | null = '';
  confirmationInput: string = '';
  closeThisDialog(message: string) {}

  enterKeyHandler(orginialInput: string, newInput: string) {
    if (!this.validateInput(orginialInput, newInput)) {
      this.showErrorMessage();
    }
  }

  /**
   * This method is to compare values
   */
  validateInput(orginialInput: string, newInput: string) {
    if (orginialInput === newInput) {
      this.errorMessage = null;
      return true;
    } else {
      return false;
    }
  }
  showErrorMessage() {
    if (this.inputConfirmObject.type === 'Social Security Number') {
      this.errorMessage = 'The SSN entered does not match the previously entered value.';
    } else if (this.inputConfirmObject.type === 'PTO Organization Code') {
      this.errorMessage =
        'The PTO Organization Code entered does not match the previously entered value.';
    }
  }
  onClickSubmit(confirmValue: string, inputValue: string) {
    if (!!this.validateInput(confirmValue, inputValue)) {
      return this.confirm();
    }
    return this.showErrorMessage();
  }
  confirm() {
    this.confirmEvent.emit();
  }
}
