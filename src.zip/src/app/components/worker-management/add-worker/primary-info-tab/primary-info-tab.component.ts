import { Component, Input, OnInit, OnChanges, SimpleChanges, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'src/app/services/app.service';
import { WorkerValidationsService } from '../../worker-validations.service';

@Component({
  selector: 'app-primary-info-tab',
  templateUrl: './primary-info-tab.component.html',
  styleUrls: ['./primary-info-tab.component.scss'],
})
export class PrimaryInfoTabComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() primaryForm!: FormGroup;
  @Input() workerEmploymentType: string = 'E';
  @Input() canViewSecureData: boolean = false;
  @ViewChild('lastNameInput') lastNameInput!: ElementRef;
  
  public isDisplay = false;
  public userRoles: any = [];
  addMode = true;
  showBirthDate = false;
  showSsnLast2Digits = false;

  constructor(
    private fb: FormBuilder,
    private appService: AppService,
    private validationService: WorkerValidationsService
  ) {}

  ngOnInit(): void {
    this.initializeFormControls();
    this.userRoles = this.appService.getUserData().roles;
    
    //remove all teh validation errors on load
    Object.keys(this.primaryForm.controls).forEach(key => {
      const control = this.primaryForm.get(key);
      if (control) {
        control.setErrors(null);
      }
    });
    // Synchronize firstName and preferredFirstName fields
    this.setupFieldSynchronization();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Re-validate when employment type or secure data access changes
    if (changes['workerEmploymentType'] || changes['canViewSecureData']) {
      if (this.primaryForm) {
        // Always update validators without triggering validation
        // Validation will only occur when user interacts with the fields
        this.updateConditionalValidators(true);
        
        // Ensure fields remain untouched and pristine after validator updates
        setTimeout(() => {
          ['birthDate', 'ssnLast2Digits'].forEach(fieldName => {
            const control = this.primaryForm.get(fieldName);
            if (control) {
              control.markAsUntouched();
              control.markAsPristine();
              // Clear any validation errors that may have been set
              if (!control.value) {
                control.setErrors(null);
              }
            }
          });
        });
      }
    }
  }
  ngAfterViewInit(): void {
    // Focus on the last name field when component is initialized in update mode
    if (this.lastNameInput && this.lastNameInput.nativeElement) {
      setTimeout(() => {
        this.lastNameInput.nativeElement.focus();
      }, 100);
    }
  }

  /**
   * Initialize all form controls with appropriate validators
   */
  private initializeFormControls(): void {
    // Check if controls already exist to avoid duplicate additions
    if (this.primaryForm.get('firstName')) {
      return;
    }
    // Create separate FormControl instances
    const firstNameControl = new FormControl('', [Validators.required]);
    const lastNameControl = new FormControl('', [Validators.required]);
    const preferredFirstNameControl = new FormControl('', [Validators.required]);

    // Always required fields
    this.primaryForm.addControl('firstName', firstNameControl);
    this.primaryForm.addControl('lastName', lastNameControl);
    this.primaryForm.addControl('preferredFirstName', preferredFirstNameControl);
    
    // Optional fields
    this.primaryForm.addControl('middleName', new FormControl(''));
    this.primaryForm.addControl('loginId', new FormControl('', [Validators.required]));
    this.primaryForm.addControl('emailAddress', new FormControl('', [Validators.required]));
    
    // Conditional fields - initially without validators
    // Use null instead of empty string to avoid validation errors on initialization
    this.primaryForm.addControl('birthDate', new FormControl(null));
    this.primaryForm.addControl('ssnLast2Digits', new FormControl(null));
    // Apply conditional validators (but don't trigger validation yet)
    this.updateConditionalValidators(true);
    
    // Mark all fields as untouched and pristine after initialization
    // Use setTimeout to avoid ExpressionChangedAfterItHasBeenCheckedError
    setTimeout(() => {
      Object.keys(this.primaryForm.controls).forEach(key => {
        const control = this.primaryForm.get(key);
        if (control) {
          control.markAsUntouched();
          control.markAsPristine();
          // Clear any validation errors that were set during initialization
          // Only for fields that don't have a value
          if (!control.value) {
            control.setErrors(null);
          }
        }
      });
    });
  }

  /**
   * Setup two-way synchronization between firstName and preferredFirstName fields
   */
  private setupFieldSynchronization(): void {
    const firstNameControl = this.primaryForm.get('firstName');
    const preferredFirstNameControl = this.primaryForm.get('preferredFirstName');

    if (!firstNameControl || !preferredFirstNameControl) {

      return;
    }

    // Sync firstName -> preferredFirstName
    firstNameControl.valueChanges.subscribe(value => {
      if (preferredFirstNameControl.value !== value) {
        preferredFirstNameControl.setValue(value, { emitEvent: false });
      }
    });

    // Sync preferredFirstName -> firstName
    preferredFirstNameControl.valueChanges.subscribe(value => {
      if (firstNameControl.value !== value) {
        firstNameControl.setValue(value, { emitEvent: false });
      }
    });
  }

  /**
   * Update validators for conditional fields based on employment type and secure data access
   * @param skipValidation If true, sets validators without triggering validation (for initialization)
   */
  private updateConditionalValidators(skipValidation: boolean = false): void {
    this.updateFieldValidators('birthDate', skipValidation);
    this.updateFieldValidators('ssnLast2Digits', skipValidation);
  }

  /**
   * Update validators for a specific field
   * @param fieldName Name of the field to update
   * @param skipValidation If true, sets validators without triggering validation (for initialization)
   */
  private updateFieldValidators(fieldName: string, skipValidation: boolean = false): void {
    const control = this.primaryForm.get(fieldName);
    if (!control) {
      return;
    }

    const validators = this.validationService.getConditionalValidators(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      this.canViewSecureData
    );

    control.setValidators(validators);
    
    // Skip validation during initialization to prevent errors from showing on load
    if (skipValidation) {
      return;
    }
    
    // Update validity for fields that have been interacted with or have values
    control.updateValueAndValidity({ emitEvent: false, onlySelf: true });
  }

  /**
   * Check if a field should be visible
   * @param fieldName Name of the field
   * @returns True if field should be visible
   */
  isFieldVisible(fieldName: string): boolean {
    return this.validationService.isFieldVisible(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      this.canViewSecureData
    );
  }

  /**
   * Check if a field should be readonly
   * @param fieldName Name of the field
   * @returns True if field should be readonly
   */
  isFieldReadonly(fieldName: string): boolean {
    return this.validationService.isFieldReadonly(
      fieldName,
      this.workerEmploymentType,
      this.userRoles
    );
  }

  /**
   * Check if a field is required
   * @param fieldName Name of the field
   * @returns True if field has required validator
   */
  isFieldRequired(fieldName: string): boolean {
    const control = this.primaryForm.get(fieldName);
    if (!control) {
      return false;
    }
    
    // Check if the control has a required validator
    const validator = control.validator;
    if (!validator) {
      return false;
    }
    
    // Run the validator with an empty value to check if required error is present
    const validationResult = validator({} as any);
    return validationResult && validationResult['required'];
  }

  /**
   * Get error message for a field
   * @param fieldName Name of the field
   * @returns Error message string
   */
  getErrorMessage(fieldName: string): string {
    const control = this.primaryForm.get(fieldName);
    if (!control || !control.errors) {
      return '';
    }

    // Silent error - show red border but no message
    if (control.errors['duplicateContractorSilent']) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.validationService.getFieldDisplayName(fieldName)} is required`;
    }

    if (control.errors['duplicateContractor']) {
      // Return the full error message stored in the error object
      // The error value contains the complete message from the validation
      return control.errors['duplicateContractor'];
    }

    // Handle API validation errors (age validation, required fields, etc.)
    if (control.errors['apiValidation']) {
      return control.errors['apiValidation'];
    }

    // Legacy support for ageValidation error type
    if (control.errors['ageValidation']) {
      return control.errors['ageValidation'];
    }

    return '';
  }

  /**
   * Handle birth date change from date picker
   * @param date The selected date from the date picker
   */
  onBirthDateChange(date: any): void {
    const birthDateControl = this.primaryForm.get('birthDate');
    if (birthDateControl) {
      birthDateControl.setValue(date);
      birthDateControl.markAsTouched();
    }
  }

  /**
   * Toggle visibility of birth date field
   */
  toggleBirthDateVisibility(): void {
    this.showBirthDate = !this.showBirthDate;
  }

  /**
   * Toggle visibility of SSN last 2 digits field
   */
  toggleSsnLast2DigitsVisibility(): void {
    this.showSsnLast2Digits = !this.showSsnLast2Digits;
  }

  /**
   * Get masked birth date value
   * @returns Masked date string (e.g., "****-**-**") or actual value if visible
   */
  getMaskedBirthDate(): string {
    if (this.showBirthDate) {
      return this.primaryForm.get('birthDate')?.value || '';
    }
    const value = this.primaryForm.get('birthDate')?.value;
    return value ? '****-**-**' : '';
  }

  /**
   * Get masked SSN last 2 digits value
   * @returns Masked value (e.g., "**") or actual value if visible
   */
  getMaskedSsnLast2Digits(): string {
    if (this.showSsnLast2Digits) {
      return this.primaryForm.get('ssnLast2Digits')?.value || '';
    }
    const value = this.primaryForm.get('ssnLast2Digits')?.value;
    return value ? '**' : '';
  }
}
