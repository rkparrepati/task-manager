import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { WorkerLocationAssignmentService, WorkerLocationAssignment, Organization } from './worker-location-assignment.service';
import { WorkerLocationAssignmentHelperService } from './worker-location-assignment-helper.service';
import { LocationselectDialogComponent } from '../locationselect-dialog/locationselect-dialog.component';

/**
 * Component for adding/editing worker organization location assignments
 * Implements the same validation logic as the old AngularJS application
 */
@Component({
  selector: 'app-worker-org-location-add-edit',
  templateUrl: './worker-org-location-add-edit.component.html',
  styleUrls: ['./worker-org-location-add-edit.component.scss']
})
export class WorkerOrgLocationAddEditComponent implements OnInit {
  @Input() workerAssignments: WorkerLocationAssignment[] = [];
  @Input() buildingCodeList: any[] = [];
  @Input() userRoles: string[] = [];
  @Input() workerBase: any = {};
  @Output() assignmentSaved = new EventEmitter<WorkerLocationAssignment>();
  @Output() assignmentCancelled = new EventEmitter<void>();

  // Form state
  newLocation: WorkerLocationAssignment = {
    workerOrganization: {
      organization: {
        organizationId: '',
        acronym: '',
        businessAreaCode: '',
        shortName: ''
      }
    },
    location: {
      locationId: '',
      building: {
        code: '',
        buildingId: '',
        floorNumber: ''
      },
      corridorId: '',
      suiteId: '',
      roomId: '',
      zoneId: ''
    },
    mailStopLocation: {
      locationId: '',
      building: {
        code: '',
        buildingId: '',
        floorNumber: ''
      },
      corridorId: '',
      suiteId: '',
      roomId: '',
      zoneId: ''
    },
    primaryLocationIndicator: false,
    hiddenIndicator: false,
    alternateIndicator: false,
    mailLocationIndicator: false,
    palmLocationDetail: {
      visualLocationCode: '',
      description: '',
      palmLocationId: ''
    },
    lifecycle: {
      beginDate: new Date().toISOString()
    }
  };
  editAddMode = false;
  showAddLocationRow = false;
  buildingFloors: any[] = [];
  mailstopBuildingFloors: any[] = [];

  // Display control
  showAllLocations = false;
  addEditMode = false;
  currentIndex: number = 0;

  // Validation flags
  acronymRequired = false;
  locationInvalid = false;
  mailLocationInvalid = false;
  locationRequired = false;
  palmLocationLookupNoResults = false;
  selectedPalmLocationDescription = '';

  // Location indicator validation flags
  // invalidHiddenIndicator = false;
  // invalidPrimaryIndicator = false;
  // multipleHiddenAssignments = false;
  // multiplePrimaryAssignments = false;
  // singlePrimary = false;

  // Mailstop location flag
  isMailstopLocationActive = false;
  isMailstopLocationDisabled = true;
  // Message display
  hideMessage = true;
  returnMessage = '';
  returnCode: number = 0;

  constructor(
    private locationService: WorkerLocationAssignmentService,
    private helperService: WorkerLocationAssignmentHelperService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.initializeNewLocation();




  }

  /**
   * Initialize new location object
   */
  private initializeNewLocation(): void {
    this.newLocation = {
      workerOrganization: {
        organization: {
          organizationId: '',
          acronym: '',
          businessAreaCode: '',
          shortName: ''
        }
      },
      location: {
        locationId: '',
        building: {
          code: '',
          buildingId: '',
          floorNumber: ''
        },
        corridorId: '',
        suiteId: '',
        roomId: '',
        zoneId: ''
      },
      mailStopLocation: {
        locationId: '',
        building: {
          code: '',
          buildingId: '',
          floorNumber: ''
        },
        corridorId: '',
        suiteId: '',
        roomId: '',
        zoneId: ''
      },
      primaryLocationIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      mailLocationIndicator: false,
      palmLocationDetail: {
        visualLocationCode: '',
        description: '',
        palmLocationId: ''
      },
      lifecycle: {
        beginDate: new Date().toISOString()
      }
    };
    this.resetValidationFlags();
  }

  /**
   * Reset all validation flags
   */
  private resetValidationFlags(): void {
    this.acronymRequired = false;
    this.locationInvalid = false;
    this.mailLocationInvalid = false;
    this.locationRequired = false;
    this.palmLocationLookupNoResults = false;
    // this.invalidHiddenIndicator = false;
    // this.invalidPrimaryIndicator = false;
    // this.multipleHiddenAssignments = false;
    // this.multiplePrimaryAssignments = false;
    // this.singlePrimary = false;
  }

  /**
   * STEP 1: Accept/Save button click handler
   * Validates acronym and triggers the save flow
   */
  acceptAddEdit(index: number): void {
    this.currentIndex = index;
    this.validateAcronym(true);
  }

  /**
   * STEP 2: Validate acronym exists in system
   * Makes API call to verify acronym
   */
  validateAcronym(fromAccept: boolean): void {
    this.acronymRequired = false;

    if (!this.newLocation.workerOrganization?.organization?.acronym) {
      this.acronymRequired = true;
      return;
    }

    const { businessAreaCode, shortName } = this.newLocation.workerOrganization.organization;

    if (businessAreaCode && shortName) {
      this.locationService.getOrganizationByAcronym(
        this.newLocation.workerOrganization.organization.acronym
      ).subscribe(
        (response) => {
          if (response.results && response.results.length > 0) {
            const orgId = response.results[0].organizationId;
            // Ensure organizationId is set in the newLocation before calling selectAcronym
            if (this.newLocation.workerOrganization?.organization) {
              this.newLocation.workerOrganization.organization.organizationId =
                orgId ? String(orgId) : '';
            }
            this.selectAcronym(orgId ? String(orgId) : '', fromAccept);
          } else {
            this.acronymRequired = true;
          }
        },
        (error) => {
          this.acronymRequired = true;
        }
      );
    } else {
      this.acronymRequired = true;
    }
  }

  /**
   * STEP 3: Select acronym and get organization details
   */

  /**
   * STEP 4: Accept row - Main validation entry point
   */
  // private acceptRow(): void {
  //   this.resetValidationFlags();

  //   if (this.validLocation(this.currentIndex)) {
  //     this.newLocation = this.helperService.assignPalmLocation(this.newLocation);

  //     if (this.workerAssignments && this.workerAssignments.length >= 1) {
  //       this.adjustWorkerLocationIndicator(this.currentIndex);
  //     } else {
  //       this.newLocation.primaryLocationIndicator = true;
  //       if (this.newLocation.workerOrganization) {
  //         this.newLocation.workerOrganization.primaryOrganizationIndicator = true;
  //       }
  //     }

  //     this.acceptLocationAssignments(this.currentIndex);
  //   }
  // }

  /**
   * STEP 5: Validate location - Comprehensive validation
   */
  // private validLocation(index: number): boolean {
  //   this.locationInvalid = false;

  //   const invalidWorkerOrganization = this.validateWorkerOrganizationPalmLocation();
  //   const invalidSplitLocation = this.splitValidLocation();
  //   const invalidIndicators = this.validateLocationIndicator(index);

  //   return !invalidWorkerOrganization && !invalidIndicators && !invalidSplitLocation;
  // }

  /**
   * Validate worker organization and PALM location
   */
  private validateWorkerOrganizationPalmLocation(): boolean {
    if (!this.newLocation.workerOrganization?.organization?.acronym) {
      this.acronymRequired = true;
    }

    if (this.acronymRequired || this.palmLocationLookupNoResults) {
      return true;
    }

    return false;
  }

  /**
   * Validate worker location and mailstop location
   */
  private splitValidLocation(): boolean {
    const invalidWorkerLocation = this.validateWorkerLocation();

    if (this.newLocation.mailStopInvalid || invalidWorkerLocation) {
      return true;
    }

    return false;
  }

  /**
   * STEP 6: Validate worker location fields
   * NOTE: Building code, floor, corridor, suite, room, and zone are now optional fields
   */
  private validateWorkerLocation(): boolean {
    if (this.newLocation.location) {
      this.locationRequired = false;
      this.locationInvalid = false;
    }

    this.validateMailstopLocation();

    if (this.locationRequired || this.locationInvalid) {
      return true;
    }

    return false;
  }

  /**
   * Validate mailstop location fields
   * NOTE: Mailstop building code, floor, and other location details are now optional fields
   */
  private validateMailstopLocation(): void {
    if (this.newLocation.mailLocationIndicator) {
      this.newLocation.mailStopInvalid = false;
    }
  }

  /**
   * Validate location indicators (primary/hidden/alternate)
   */
  // private validateLocationIndicator(index: number): boolean {
  //   this.getMultipleHiddenIndicator(index);
  //   const invalidHiddenIndicators = this.validateHiddenIndicator();

  //   return invalidHiddenIndicators || this.invalidPrimaryIndicator || this.singlePrimary;
  // }

  /**
   * Check for multiple hidden indicators
   */
  private getMultipleHiddenIndicator(index: number): void {
    let locationTypeCount = 0;

    if (this.workerAssignments) {
      for (const assignment of this.workerAssignments) {
        if (assignment.hiddenIndicator) {
          locationTypeCount++;
        }
      }
    }

    if ((this.showAddLocationRow && this.newLocation.hiddenIndicator) ||
        (this.newLocation.hiddenIndicator && !this.workerAssignments[index]?.hiddenIndicator)) {
      locationTypeCount++;
    }

    // this.multipleHiddenAssignments = locationTypeCount > 1;
  }

  /**
   * Validate hidden indicator
   */
  // private validateHiddenIndicator(): boolean {
  //   if (this.multipleHiddenAssignments || this.invalidHiddenIndicator) {
  //     return true;
  //   }

  //   return false;
  // }

  /**
   * STEP 7: Accept location assignments - CRITICAL VALIDATION
   * Validates if location exists in system via API call
   * API call removed - skipping location validation
   */
  private acceptLocationAssignments(index: number): void {
    // Skip location validation API call
    this.locationInvalid = false;
    this.acceptMailLocationAssignment(index);
  }

  /**
   * STEP 8: Accept mailstop location assignments
   * Validates if mailstop location exists in system
   * API call removed - skipping mailstop location validation
   */
  private acceptMailLocationAssignment(index: number): void {
    // Skip mailstop location validation API call
    this.mailLocationInvalid = false;
    this.addLocationAssignment(index, false);
  }

  /**
   * STEP 9: Add location assignment to array
   */
  private addLocationAssignment(index: number, invalidLocationAssignment: boolean): void {
    if (!invalidLocationAssignment) {
      if (this.showAddLocationRow) {
        if (!Array.isArray(this.workerAssignments)) {
          this.workerAssignments = [];
        }
        this.workerAssignments.push(this.newLocation);
      } else {
        this.workerAssignments[index] = { ...this.newLocation };
      }

      this.assignmentSaved.emit(this.newLocation);
      this.cancelAddEdit();
    }
  }

  /**
   * Adjust worker location indicators
   */
  private adjustWorkerLocationIndicator(index: number): void {
    if (this.showAddLocationRow) {
      if (this.newLocation.primaryLocationIndicator) {
        this.adjustAlternateToPrimaryIndicator();
      }

      if (!this.newLocation.primaryLocationIndicator &&
          !this.newLocation.hiddenIndicator &&
          !this.newLocation.alternateIndicator) {
        this.newLocation.alternateIndicator = true;
        if (this.newLocation.workerOrganization) {
          this.newLocation.workerOrganization.primaryOrganizationIndicator = false;
        }
      }
    }
  }


  /**
   * Cancel add/edit mode
   */
  cancelAddEdit(): void {
    this.initializeNewLocation();
    this.editAddMode = false;
    this.locationInvalid = false;
    this.resetValidationFlags();
    this.showAddLocationRow = false;
    this.assignmentCancelled.emit();
  }

  /**
   * Reset form to original state
   */
  resetAddEdit(): void {
    this.resetValidationFlags();
    this.initializeNewLocation();
  }

  /**
   * Show add location row
   */
  showLocationAddRow(): void {
    if (!this.editAddMode) {
      this.buildingFloors = [];
      this.editAddMode = true;
      this.showAddLocationRow = true;
      this.initializeNewLocation();
    }
  }


  /**
   * Validate PALM location
   */
  validatePalmLocation(): void {
    this.palmLocationLookupNoResults = false;
    this.selectedPalmLocationDescription = '';

    if (!this.newLocation.palmLocationDetail?.visualLocationCode) {
      return;
    }

    this.locationService.getPalmLocations(
      this.newLocation.palmLocationDetail.visualLocationCode.trim()
    ).subscribe(
      (response) => {
        let foundPALMLocation = false;

        for (const palmLocation of response.results) {
          if (palmLocation.visualLocationCode?.trim() === 
              this.newLocation.palmLocationDetail?.visualLocationCode?.trim()) {
            foundPALMLocation = true;
            this.newLocation.palmLocationDetail = { ...palmLocation };
            this.selectedPalmLocationDescription = `[${palmLocation.description}]`;
            break;
          }
        }

        if (!foundPALMLocation) {
          this.palmLocationLookupNoResults = true;
          this.selectedPalmLocationDescription = '';
        }
      },
      (error) => {

        this.palmLocationLookupNoResults = true;
        this.selectedPalmLocationDescription = '';
      }
    );
  }

  /**
   * Set mailstop location
   */
  setMailStopLocation(): void {
    if (this.newLocation.mailLocationIndicator) {
      // Mailstop checkbox is checked - set flag to disable assignments list
      this.isMailstopLocationActive = true;
      this.isMailstopLocationDisabled = false;
    } else {
      // Mailstop checkbox is unchecked - clear flag and reset mailstop data
      this.isMailstopLocationActive = false;
      this.isMailstopLocationDisabled = true;
      this.newLocation.mailStopLocation = undefined;
      this.newLocation.mailStopInvalid = false;
      this.mailLocationInvalid = false;
    }
  }

  /**
   * Handle building code change - populate floors
   */
  buildingChanged(): void {
    if (this.newLocation.location?.building?.code) {
      // Load floors for selected building
      const selectedBuilding = this.buildingCodeList.find(
        b => b.buildingCode === this.newLocation.location?.building?.code
      );
      if (selectedBuilding && selectedBuilding.floors) {
        this.buildingFloors = selectedBuilding.floors;
      } else {
        this.buildingFloors = [];
      }
      // Reset floor selection
      if (this.newLocation.location?.building) {
        this.newLocation.location.building.floorNumber = '';
      }
    }
  }

  /**
   * Handle mailstop building code change - populate floors
   */
  mailstopBuildingChanged(): void {
    if (this.newLocation.mailStopLocation?.building?.code) {
      // Load floors for selected mailstop building
      const selectedBuilding = this.buildingCodeList.find(
        b => b.buildingCode === this.newLocation.mailStopLocation?.building?.code
      );
      if (selectedBuilding && selectedBuilding.floors) {
        this.mailstopBuildingFloors = selectedBuilding.floors;
      } else {
        this.mailstopBuildingFloors = [];
      }
      // Reset floor selection
      if (this.newLocation.mailStopLocation?.building) {
        this.newLocation.mailStopLocation.building.floorNumber = '';
      }
    }
  }

  /**
   * Get template name based on view mode
   */
  getTemplateWorkerAssignments(workerLocation: WorkerLocationAssignment): string {
    if (!workerLocation.viewMode) {
      workerLocation.viewMode = 0;
    }

    switch (workerLocation.viewMode) {
      case 1:
        return 'locationDetails';
      case 2:
        this.setAcronym(workerLocation);
        return 'locationEdit';
      default:
        if (this.showAllLocations) {
          return 'locationsDisplayAll';
        } else {
          if (workerLocation.primaryLocationIndicator) {
            return 'primaryLocationDisplay';
          }
        }
    }
    return '';
  }

  /**
   * Toggle between showing all locations and primary only
   */
  toggleCommunications(): void {
    this.showAllLocations = !this.showAllLocations;
  }

  /**
   * Set view mode to default
   */
  setViewMode(workerLocation: WorkerLocationAssignment): void {
    workerLocation.viewMode = 0;
    this.editAddMode = false;
  }

  /**
   * Set view mode to details
   */
  setshowMode(workerLocation: WorkerLocationAssignment): void {
    workerLocation.viewMode = 1;
  }

  /**
   * Enter edit mode for a worker location
   */
  setEditModeWorkerLocation(workerLocation: WorkerLocationAssignment): void {
    if (!this.addEditMode) {
      this.addEditMode = true;
      this.newLocation = JSON.parse(JSON.stringify(workerLocation));
      workerLocation.viewMode = 2;
      this.newLocation.edited = true;

      // Set mailLocationIndicator if mailLocation exists
      if (this.newLocation.mailLocation && this.newLocation.mailLocation.locationId) {
        this.newLocation.mailLocationIndicator = true;
      } else {
        this.newLocation.mailLocationIndicator = false;
      }

      // Set alternateIndicator if not primary and not hidden
      if (!this.newLocation.primaryLocationIndicator && !this.newLocation.hiddenIndicator) {
        this.newLocation.alternateIndicator = true;
      } else {
        this.newLocation.alternateIndicator = false;
      }

      // Load building floors
      if (this.newLocation.location?.building?.code) {
        const tempFloorNum = this.newLocation.location.building.floorNumber;
        this.buildingChanged();
        if (tempFloorNum) {
          this.newLocation.location.building.floorNumber = tempFloorNum;
        }
      }

      // Load mailstop building floors
      if (this.newLocation.mailStopLocation?.building?.code) {
        const tempMailFloorNum = this.newLocation.mailStopLocation.building.floorNumber;
        this.mailstopBuildingChanged();
        if (tempMailFloorNum) {
          this.newLocation.mailStopLocation.building.floorNumber = tempMailFloorNum;
        }
      }

      // Get PALM location description
      this.getPalmLocationDescription();
    }
  }

  /**
   * Handle acronym change from acronym-input component
   * @param acronym The new acronym value
   */
  onAcronymChange(acronym: string): void {
    if (this.newLocation.workerOrganization?.organization) {
      this.newLocation.workerOrganization.organization.acronym = acronym;
      
      // Parse acronym to extract business area code and short name
      if (acronym && acronym.includes('/')) {
        const parts = acronym.split('/');
        this.newLocation.workerOrganization.organization.businessAreaCode = parts[0].trim();
        this.newLocation.workerOrganization.organization.shortName = parts[1].trim();
      }
    }
  }

  /**
   * Handle acronym selection from organization lookup dialog
   * @param organization The selected organization object
   */
  onAcronymSelected(organization: any): void {
    if (organization && this.newLocation.workerOrganization?.organization) {
      // Ensure organizationId is properly set as string
      this.newLocation.workerOrganization.organization.organizationId =
        organization.organizationId ? String(organization.organizationId) : '';
      this.newLocation.workerOrganization.organization.businessAreaCode =
        organization.organizationType?.businessArea?.code?.trim() || '';
      this.newLocation.workerOrganization.organization.shortName = organization.shortName?.trim() || '';
      
      // Construct acronym
      const businessAreaCode = this.newLocation.workerOrganization.organization.businessAreaCode;
      const shortName = this.newLocation.workerOrganization.organization.shortName;
      this.newLocation.workerOrganization.organization.acronym = `${businessAreaCode}/${shortName}`;
      
      // Validate the acronym after selection
      this.validateAcronym(false);
    }
  }

  /**
   * Open organization lookup dialog
   */
  openLookupOrganization(): void {
    // This will be implemented with dialog integration
    // For now, placeholder for dialog opening logic

  }

  /**
   * Change location (primary or mailstop)
   */
  changeLocation(type: 'primary' | 'mail'): void {
    const dialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '90vw',
      height: '75vh',
      data: {}
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        if (type === 'mail') {
          this.newLocation.mailStopLocation = {
            building: {
              code: result.building?.code || '',
              floorNumber: result.building?.floorNumber || '',
              buildingId: result.building?.buildingId || ''
            },
            corridorId: result.corridorId || '',
            suiteId: result.suiteId || '',
            roomId: result.roomId || '',
            zoneId: result.zoneId || '',
            locationId: result.locationId || ''
          };
        } else {
          this.newLocation.location = {
            building: {
              code: result.building?.code || '',
              floorNumber: result.building?.floorNumber || '',
              buildingId: result.building?.buildingId || ''
            },
            corridorId: result.corridorId || '',
            suiteId: result.suiteId || '',
            roomId: result.roomId || '',
            zoneId: result.zoneId || '',
            locationId: result.locationId || ''
          };
        }
      }
    });
  }

  /**
   * Get PALM location description from cached list
   */
  getPalmLocationDescription(): void {
    if (this.newLocation.palmLocationDetail?.visualLocationCode && this.workerBase?.palmLocations) {
      for (const palmLocation of this.workerBase.palmLocations) {
        if (palmLocation.visualLocationCode === this.newLocation.palmLocationDetail.visualLocationCode) {
          this.selectedPalmLocationDescription = `[${palmLocation.description}]`;
          this.newLocation.palmLocationDetail = { ...palmLocation };
          this.palmLocationLookupNoResults = false;
          return;
        }
      }
      this.palmLocationLookupNoResults = true;
      this.selectedPalmLocationDescription = '';
    } else {
      this.selectedPalmLocationDescription = '';
      this.palmLocationLookupNoResults = false;
    }
  }

  /**
   * Show PALM location lookup dialog
   */
  showPalmLocationLookup(): void {
    // This will be implemented with dialog integration
    // For now, placeholder for dialog opening logic

  }

  /**
   * Confirm delete worker location
   */
  confirmDeleteWorkerLocation(index: number): void {
    // This will be implemented with dialog integration
    // For now, placeholder for delete confirmation
    if (confirm('Are you sure you want to delete this location assignment?')) {
      this.removeWorkerLocation(index);
    }
  }

  /**
   * Remove worker location from assignments
   */
  removeWorkerLocation(index: number): void {
    if (this.workerAssignments[index].primaryLocationIndicator) {
      let primaryCount = 0;
      for (const assignment of this.workerAssignments) {
        if (assignment.primaryLocationIndicator) {
          primaryCount++;
        }
      }

      if (primaryCount === 1) {
        this.newLocation.singlePrimary = true;
        return;
      } else {
        this.newLocation.singlePrimary = false;
        if (this.workerAssignments[index].workerAssignmentId) {
          if (!this.workerBase.assignmentsDeleteList) {
            this.workerBase.assignmentsDeleteList = [];
          }
          this.workerBase.assignmentsDeleteList.push(this.workerAssignments[index]);
        }
        if (this.workerAssignments[index].workerOrganization) {
          this.workerAssignments[index].workerOrganization!.primaryOrganizationIndicator = false;
        }
        this.workerAssignments.splice(index, 1);
      }
    } else {
      if (this.workerAssignments[index].workerAssignmentId) {
        if (!this.workerBase.assignmentsDeleteList) {
          this.workerBase.assignmentsDeleteList = [];
        }
        this.workerBase.assignmentsDeleteList.push(this.workerAssignments[index]);
      }
      this.workerAssignments.splice(index, 1);
    }

    // If removed primary and no other primary exists, promote alternate
    if (!this.workerAssignments.some(a => a.primaryLocationIndicator)) {
      this.adjustPrimaryToAlternateIndicator();
    }
  }

  /**
   * Adjust alternate to primary indicator when setting new primary
   */
  private adjustAlternateToPrimaryIndicator(): void {
    const now = new Date().toISOString();

    for (const assignment of this.workerAssignments) {
      if (assignment.primaryLocationIndicator) {
        assignment.primaryLocationIndicator = false;
        assignment.alternateIndicator = true;
        if (assignment.workerOrganization) {
          assignment.workerOrganization.primaryOrganizationIndicator = false;
        }
        assignment.edited = true;
        if (!assignment.lifecycle) {
          assignment.lifecycle = { beginDate: now };
        } else {
          assignment.lifecycle.beginDate = now;
        }
        if (assignment.workerOrganization) {
          if (!assignment.workerOrganization.lifecycle) {
            assignment.workerOrganization.lifecycle = { beginDate: now };
          } else {
            assignment.workerOrganization.lifecycle.beginDate = now;
          }
        }
      }
    }
  }

  /**
   * Adjust primary to alternate indicator when removing primary
   */
  private adjustPrimaryToAlternateIndicator(): void {
    const now = new Date().toISOString();

    for (let i = 0; i < this.workerAssignments.length; i++) {
      if (!this.workerAssignments[i].primaryLocationIndicator &&
          !this.workerAssignments[i].hiddenIndicator) {
        this.workerAssignments[i].primaryLocationIndicator = true;
        this.workerAssignments[i].alternateIndicator = false;
        this.workerAssignments[i].edited = true;
        if (!this.workerAssignments[i].lifecycle) {
          this.workerAssignments[i].lifecycle = { beginDate: now };
        } else {
          this.workerAssignments[i].lifecycle!.beginDate = now;
        }
        if (this.workerAssignments[i].workerOrganization) {
          this.workerAssignments[i].workerOrganization!.primaryOrganizationIndicator = true;
          if (!this.workerAssignments[i].workerOrganization!.lifecycle) {
            this.workerAssignments[i].workerOrganization!.lifecycle = { beginDate: now };
          } else {
            this.workerAssignments[i].workerOrganization!.lifecycle!.beginDate = now;
          }
        }
        break;
      }
    }
  }

  /**
   * Check if add/edit mode is allowed
   */
  canChangeMode(): boolean {
    if (this.addEditMode) {
      this.setMessage('Action not allow. Currently Add or Edit mode.', -1);
      return false;
    } else {
      return true;
    }
  }

  /**
   * Set error/success message
   */
  setMessage(messageText: string, errorCode: number): void {
    this.returnMessage = messageText;
    this.returnCode = errorCode;
  }

  /**
   * Hide message div
   */
  hideMessageDiv(): void {
    this.hideMessage = true;
    this.returnMessage = '';
  }

  /**
   * Set acronym from organization details
   */
  private setAcronym(workerLocation: WorkerLocationAssignment): void {
    if (this.newLocation.workerOrganization?.organization) {
      this.newLocation.workerOrganization.organization.acronym =
        this.helperService.getAcronym(
          this.newLocation.workerOrganization.organization.businessAreaCode?.trim() || '',
          this.newLocation.workerOrganization.organization.shortName?.trim() || ''
        );
    } else if (workerLocation.workerOrganization?.organization) {
      this.newLocation.workerOrganization = JSON.parse(JSON.stringify(workerLocation.workerOrganization));
      if (this.newLocation.workerOrganization?.organization) {
        this.newLocation.workerOrganization.organization.acronym =
          this.helperService.getAcronym(
            workerLocation.workerOrganization.organization.businessAreaCode?.trim() || '',
            workerLocation.workerOrganization.organization.shortName?.trim() || ''
          );
      }
    }
  }

  /**
   * Reset primary indicator
   */
  resetPrimaryIndicator(workerLocation?: WorkerLocationAssignment): void {
    if (workerLocation && workerLocation.primaryLocationIndicator) {
      this.newLocation.invalidHiddenIndicator = true;
    } else {
      this.newLocation.invalidHiddenIndicator = false;
    }
    this.newLocation.primaryLocationIndicator = false;
    if (this.newLocation.workerOrganization) {
      this.newLocation.workerOrganization.primaryOrganizationIndicator = false;
    }
    this.newLocation.alternateIndicator = false;
    this.newLocation.invalidPrimaryIndicator = false;
    this.newLocation.singlePrimary = false;
    this.newLocation.noPrimary = false;
  }

  /**
   * Reset primary and set alternate indicator
   */
  resetPrimarySetAlternateIndicator(): void {
    this.newLocation.primaryLocationIndicator = false;
    if (this.newLocation.workerOrganization) {
      this.newLocation.workerOrganization.primaryOrganizationIndicator = false;
    }
    this.newLocation.hiddenIndicator = false;
    this.newLocation.invalidHiddenIndicator = false;
    this.newLocation.invalidPrimaryIndicator = false;
    this.newLocation.multiplePrimaryAssignments = false;
    this.newLocation.multipleHiddenAssignments = false;

    if (this.newLocation.edited) {
      if (this.workerAssignments.length === 1) {
        this.newLocation.singlePrimary = true;
      } else {
        this.newLocation.singlePrimary = false;
      }
    } else {
      this.newLocation.singlePrimary = false;
    }
  }

  /**
   * Set primary indicator
   */
  setPrimaryIndicator(workerLocation?: WorkerLocationAssignment): void {
    if (workerLocation && workerLocation.hiddenIndicator) {
      this.newLocation.invalidPrimaryIndicator = true;
    } else {
      this.newLocation.invalidPrimaryIndicator = false;
    }
    this.newLocation.alternateIndicator = false;
    this.newLocation.hiddenIndicator = false;
    this.newLocation.invalidHiddenIndicator = false;
    if (this.newLocation.workerOrganization) {
      this.newLocation.workerOrganization.primaryOrganizationIndicator = true;
      if (this.newLocation.workerOrganization.organization?.organizationId &&
          this.newLocation.workerOrganization.organization.organizationId.trim() !== '') {
        this.selectAcronym(this.newLocation.workerOrganization.organization.organizationId, false);
      }
    }
    this.newLocation.singlePrimary = false;
    this.newLocation.noPrimary = false;
  }

  /**
   * Select acronym and get organization details
   */
  private selectAcronym(organizationId: string, fromAccept: boolean): void {
    // Validate organizationId before making API call
    if (!organizationId || organizationId.trim() === '') {
      this.acronymRequired = true;
      return;
    }

    this.locationService.getOrganization(organizationId).subscribe(
      (response) => {
        this.newLocation = this.helperService.setOrganization(
          this.newLocation,
          response.organization
        );
        this.acronymRequired = false;

        // if (fromAccept) {
        //   this.acceptRow();
        // }
      },
      (error) => {
        this.acronymRequired = true;
      }
    );
  }

  /**
   * Reset form to original state
   */
  reset(): void {
    this.resetValidationFlags();
  }

}
