import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

/**
 * Interface for Location Search Parameters
 */
export interface LocationSearchParams {
  buildingCodeSearch: string;
  floorSearch?: string;
  corridorSearch?: string;
  suiteSearch?: string;
  roomSearch?: string;
  zoneSearch?: string;
  mailStopIndicator: boolean;
}

/**
 * Interface for Location object
 */
export interface Location {
  locationId: string;
  building: {
    code: string;
    buildingId?: string;
    floorNumber?: string;
  };
  corridorId?: string;
  suiteId?: string;
  roomId?: string;
  zoneId?: string;
}

/**
 * Interface for Organization
 */
export interface Organization {
  organizationId: string;
  acronym: string;
  businessAreaCode: string;
  shortName: string;
  organizationType?: {
    businessArea: {
      code: string;
    };
  };
}

/**
 * Interface for Worker Organization
 */
export interface WorkerOrganization {
  workerOrganizationId?: string;
  organization: Organization;
  primaryOrganizationIndicator?: boolean;
  lifecycle?: {
    beginDate: string;
    endDate?: string;
  };
}

/**
 * Interface for Worker Location Assignment
 */
export interface WorkerLocationAssignment {
  workerAssignmentId?: string;
  workerOrganization?: WorkerOrganization;
  location?: Location;
  mailStopLocation?: Location;
  assignmentLocation?: {
    locationId: string;
  };
  mailLocation?: {
    locationId: string;
  };
  palmLocation?: {
    legacyLocationId: string;
  };
  palmLocationDetail?: {
    visualLocationCode?: string;
    description?: string;
    palmLocationId?: string;
  };
  primaryLocationIndicator?: boolean;
  hiddenIndicator?: boolean;
  alternateIndicator?: boolean;
  mailLocationIndicator?: boolean;
  mailStopInvalid?: boolean;
  assignmentStatusCurrent?: string;
  lifecycle?: {
    beginDate: string;
    endDate?: string;
  };
  edited?: boolean;
  audit?: {
    lockControlNumber: string;
  };
  // View mode and state properties
  viewMode?: number;
  singlePrimary?: boolean;
  noPrimary?: boolean;
  invalidHiddenIndicator?: boolean;
  invalidPrimaryIndicator?: boolean;
  multipleHiddenAssignments?: boolean;
  multiplePrimaryAssignments?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class WorkerLocationAssignmentService {
  private apiUrl = '/api'; // Adjust based on your API configuration

  constructor(private http: HttpClient) {}

  /**
   * Get organization details by ID
   */
  getOrganization(organizationId: string): Observable<{ organization: Organization }> {
    return this.http.get<{ organization: Organization }>(
      `${this.apiUrl}/organizations/${organizationId}`
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Get organization by acronym
   */
  getOrganizationByAcronym(acronym: string): Observable<{ results: Organization[] }> {
    const params = new HttpParams().set('acronym', acronym);
    return this.http.get<{ results: Organization[] }>(
      `${this.apiUrl}/organizations`,
      { params }
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Get locations based on search parameters
   */
  getLocations(searchParams: LocationSearchParams): Observable<{ results: Location[] }> {
    let params = new HttpParams()
      .set('buildingCode', searchParams.buildingCodeSearch)
      .set('mailStopIndicator', searchParams.mailStopIndicator.toString())
      .set('includeInactive', 'false');

    if (searchParams.floorSearch) {
      params = params.set('floorPrefix', searchParams.floorSearch);
    }
    if (searchParams.corridorSearch) {
      params = params.set('corridorPrefix', searchParams.corridorSearch);
    }
    if (searchParams.suiteSearch) {
      params = params.set('suitePrefix', searchParams.suiteSearch);
    }
    if (searchParams.roomSearch) {
      params = params.set('roomPrefix', searchParams.roomSearch);
    }
    if (searchParams.zoneSearch) {
      params = params.set('zonePrefix', searchParams.zoneSearch);
    }

    return this.http.get<{ results: Location[] }>(
      `${this.apiUrl}/locations`,
      { params }
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Get PALM locations
   */
  getPalmLocations(codePrefix: string): Observable<{ results: any[] }> {
    const params = new HttpParams().set('codePrefix', codePrefix);
    return this.http.get<{ results: any[] }>(
      `${this.apiUrl}/palmlocations`,
      { params }
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Update worker organization location assignment
   */
  updateLocationOrganizationAssignment(
    workerId: string,
    assignment: WorkerLocationAssignment
  ): Observable<any> {
    if (assignment.workerOrganization?.workerOrganizationId) {
      if (assignment.edited) {
        return this.updateLocationOrganization(workerId, assignment);
      }
    } else {
      return this.addWorkerOrganization(workerId, assignment);
    }
    return of(null);
  }

  /**
   * Update location organization
   */
  private updateLocationOrganization(
    workerId: string,
    assignment: WorkerLocationAssignment
  ): Observable<any> {
    const params = {
      audit: {
        lockControlNumber: assignment.audit?.lockControlNumber
      }
    };

    return this.http.put(
      `${this.apiUrl}/workers/${workerId}/organizations/${assignment.workerOrganization?.workerOrganizationId}`,
      params
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Add worker organization
   */
  private addWorkerOrganization(
    workerId: string,
    assignment: WorkerLocationAssignment
  ): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/workers/${workerId}/organizations`,
      assignment.workerOrganization
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }

  /**
   * Delete assignment
   */
  deleteAssignment(workerId: string, assignment: WorkerLocationAssignment): Observable<any> {
    return this.http.delete(
      `${this.apiUrl}/workers/${workerId}/assignments/${assignment.workerAssignmentId}`
    ).pipe(
      catchError(error => {

        throw error;
      })
    );
  }
}
