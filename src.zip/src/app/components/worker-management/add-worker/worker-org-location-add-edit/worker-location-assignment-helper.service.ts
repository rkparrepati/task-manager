import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {
  WorkerLocationAssignmentService,
  Location,
  LocationSearchParams,
  WorkerLocationAssignment,
  Organization
} from './worker-location-assignment.service';

/**
 * Helper service for Worker Location Assignment validation and manipulation
 */
@Injectable({
  providedIn: 'root'
})
export class WorkerLocationAssignmentHelperService {
  constructor(private locationService: WorkerLocationAssignmentService) {}

  /**
   * Validate location assignment by checking if it exists in the system
   * @param newLocation - The location assignment to validate
   * @returns Observable that resolves to the exact location match or 'Not Found'
   */
  validateLocationAssignment(newLocation: WorkerLocationAssignment): Observable<Location | string> {
    if (!newLocation.location) {
      return of('Not Found' as string);
    }

    const locationFormData = this.buildLocationSearchParams(newLocation.location, false);

    return this.locationService.getLocations(locationFormData).pipe(
      map(response => {
        const exactMatch = this.getExactLocation(locationFormData, response.results);
        if (exactMatch) {
          // Update the location with exact match data
          newLocation.location = exactMatch;
          if (newLocation.assignmentLocation) {
            newLocation.assignmentLocation.locationId = exactMatch.locationId;
          } else {
            newLocation.assignmentLocation = { locationId: exactMatch.locationId };
          }
          return newLocation.location;
        } else {
          return 'Not Found';
        }
      }),
      catchError(error => {

        return of('Not Found' as string);
      })
    );
  }

  /**
   * Validate mailstop location assignment
   * @param newLocation - The location assignment to validate
   * @returns Observable that resolves to the exact location match or 'Not Found'
   */
  validateMailLocationAssignment(newLocation: WorkerLocationAssignment): Observable<Location | string> {
    if (!newLocation.mailStopLocation) {
      return of('Not Found' as string);
    }

    const locationFormData = this.buildLocationSearchParams(newLocation.mailStopLocation, true);

    return this.locationService.getLocations(locationFormData).pipe(
      map(response => {
        const exactMatch = this.getExactLocation(locationFormData, response.results);
        if (exactMatch) {
          // Update the mailstop location with exact match data
          if (newLocation.mailLocation) {
            newLocation.mailLocation.locationId = exactMatch.locationId;
          } else {
            newLocation.mailLocation = { locationId: exactMatch.locationId };
          }
          newLocation.mailStopLocation = exactMatch;
          return newLocation.mailStopLocation;
        } else {
          return 'Not Found';
        }
      }),
      catchError(error => {

        return of('Not Found' as string);
      })
    );
  }

  /**
   * Build location search parameters from location object
   * @param location - The location object
   * @param mailStopIndicator - Whether this is a mailstop location
   * @returns LocationSearchParams object
   */
  private buildLocationSearchParams(location: Location, mailStopIndicator: boolean): LocationSearchParams {
    return {
      buildingCodeSearch: location.building?.code || '',
      floorSearch: location.building?.floorNumber || '',
      corridorSearch: location.corridorId,
      suiteSearch: location.suiteId,
      roomSearch: location.roomId,
      zoneSearch: location.zoneId,
      mailStopIndicator: mailStopIndicator
    };
  }

  /**
   * Get exact location match from search results
   * @param searchParams - The search parameters used
   * @param results - The search results
   * @returns The exact matching location or null
   */
  private getExactLocation(searchParams: LocationSearchParams, results: Location[]): Location | null {
    if (!results || results.length === 0) {
      return null;
    }

    return results.find(location => {
      const buildingMatch = location.building?.code === searchParams.buildingCodeSearch;
      const floorMatch = !searchParams.floorSearch || location.building?.floorNumber === searchParams.floorSearch;
      const corridorMatch = !searchParams.corridorSearch || location.corridorId === searchParams.corridorSearch;
      const suiteMatch = !searchParams.suiteSearch || location.suiteId === searchParams.suiteSearch;
      const roomMatch = !searchParams.roomSearch || location.roomId === searchParams.roomSearch;
      const zoneMatch = !searchParams.zoneSearch || location.zoneId === searchParams.zoneSearch;

      return buildingMatch && floorMatch && corridorMatch && suiteMatch && roomMatch && zoneMatch;
    }) || null;
  }

  /**
   * Format acronym from business area code and short name
   * @param businessAreaCode - The business area code
   * @param shortName - The short name
   * @returns Formatted acronym
   */
  getAcronym(businessAreaCode: string, shortName: string): string {
    if (!businessAreaCode && !shortName) {
      return '';
    } else if (!shortName) {
      return businessAreaCode;
    } else {
      return `${businessAreaCode}/${shortName}`;
    }
  }

  /**
   * Set organization details in location assignment
   * @param newLocation - The location assignment
   * @param organization - The organization details
   * @returns Updated location assignment
   */
  setOrganization(newLocation: WorkerLocationAssignment, organization: Organization): WorkerLocationAssignment {
    const now = new Date().toISOString();

    if (newLocation.workerOrganization) {
      newLocation.workerOrganization.organization = {
        organizationId: organization.organizationId,
        shortName: organization.shortName,
        businessAreaCode: organization.organizationType?.businessArea?.code || '',
        acronym: `${organization.organizationType?.businessArea?.code || ''}/${organization.shortName}`
      };
      newLocation.workerOrganization.primaryOrganizationIndicator = newLocation.primaryLocationIndicator || false;
      newLocation.workerOrganization.lifecycle = { beginDate: now };
      newLocation.lifecycle = { beginDate: now };
    } else {
      newLocation.workerOrganization = {
        organization: {
          organizationId: organization.organizationId,
          shortName: organization.shortName,
          businessAreaCode: organization.organizationType?.businessArea?.code || '',
          acronym: `${organization.organizationType?.businessArea?.code || ''}/${organization.shortName}`
        },
        primaryOrganizationIndicator: newLocation.primaryLocationIndicator || false,
        lifecycle: { beginDate: now }
      };
      newLocation.lifecycle = { beginDate: now };
    }

    newLocation.assignmentStatusCurrent = 'A';
    return newLocation;
  }

  /**
   * Assign PALM location to location assignment
   * @param newLocation - The location assignment
   * @returns Updated location assignment
   */
  assignPalmLocation(newLocation: WorkerLocationAssignment): WorkerLocationAssignment {
    if (newLocation.palmLocationDetail?.palmLocationId) {
      if (newLocation.palmLocation) {
        newLocation.palmLocation.legacyLocationId = newLocation.palmLocationDetail.palmLocationId;
      } else {
        newLocation.palmLocation = {
          legacyLocationId: newLocation.palmLocationDetail.palmLocationId
        };
      }
    }
    return newLocation;
  }

  /**
   * Build organization worker roles list by removing already assigned roles
   * @param organizationWorkerRoles - The available organization roles
   * @param workerRoles - The already assigned worker roles
   * @returns Filtered list of available roles
   */
  buildOrganizationWorkerRolesList(organizationWorkerRoles: any[], workerRoles: any[]): any[] {
    if (!workerRoles || workerRoles.length === 0) {
      return organizationWorkerRoles;
    }

    return organizationWorkerRoles.filter(orgRole => {
      return !workerRoles.some(workerRole => workerRole.reportRole?.id === orgRole.reportRole?.id);
    });
  }
}
