import { Component, inject, Input, OnInit, OnChanges, SimpleChanges, ChangeDetectorRef, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AssignmentSelectComponent } from '../assignment-select/assignment-select.component';
import { HttpService } from 'src/app/services/http.service';
import { RelocationService } from 'src/app/components/relocation-management/relocation.service';
import { AssignmentLocationService } from './assignment-location.service';

@Component({
  selector: 'app-communication-assignment',
  templateUrl: './communication-assignment.component.html',
  styleUrls: ['./communication-assignment.component.scss']
})
export class CommunicationAssignmentComponent implements OnInit, OnChanges {
  @Input() communicationWorker!: FormGroup;
  @Input() workerBase: any = {
    workerCommunications: [],
    workerTelecommunicationHistory: [],
    telecomTypes: [],
    teleworkPrograms: [],
    palmLocations: []
  };
  @Input() userRoles: string[] = [];
  
  // Track telework program invalid flag locally instead of on worker object
  teleworkProgramInvalid = false;
  teleworkErrorMessages: string[] = [];
  showAllCommunications = false;
  expandedPrimaryIndex: number = -1; // Track which primary communication's alternatives are expanded
  editAddMode = false;
  readOnlyMode = false;
  readDetailMode = false;
  showAddCommunication = false;

  isHoteling = false;
  base: any = {
    newCommunication: {
      primaryIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      telephoneNo: '',
      telecomAddressType: null
    },
    selectedCommunication: {},
    location: [],
    organization: {},
    newCommunicationLocation: {},
    newCommunicationOrganization: {},
  };
  editingCommunicationIndex: number = -1;
  originalCommunication: any = null;
  selectedCommunication: any = {};
  telephoneNoInvalid = false;
  communicationTypeInvalid = false;
  primaryIndicatorInvalid = false;

  dialog = inject(MatDialog);

  constructor(
    private httpService: HttpService,
    private relocationService: RelocationService,
    private cdr: ChangeDetectorRef,
    private assignmentLocationService: AssignmentLocationService,
    private elRef: ElementRef
  ) {
    this.communicationWorker = new FormGroup({});
  }
  ngOnInit(): void {
    this.communicationWorker.addControl(
      'internetDisplayIndicator',
      new FormControl(true)
    );
    this.communicationWorker.addControl(
      'intranetDisplayIndicator',
      new FormControl(true)
    );
    this.communicationWorker.addControl(
      'hotelDisplayIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'teleworkIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'teleworkProgram',
      new FormControl('')
    );

    this.communicationWorker.addControl(
      'primaryIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'hiddenIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'alternateIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'telecomAddressType',
      new FormControl('')
    );
    this.communicationWorker.addControl(
      'communicationTypeError',
      new FormControl('')
    );
    this.communicationWorker.addControl(
      'telephoneNoError',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'telephoneNo',
      new FormControl('')
    );
    this.communicationWorker.addControl(
      'extensionNo',
      new FormControl('')
    );
    this.communicationWorker.addControl('code', new FormControl(''));
    this.communicationWorker.addControl('floorNumber', new FormControl(''));
    this.communicationWorker.addControl('corridorId', new FormControl(''));

    this.communicationWorker.addControl('suiteId', new FormControl(''));
    this.communicationWorker.addControl('roomId', new FormControl(''));
    this.communicationWorker.addControl('zoneId', new FormControl(''));

    this.communicationWorker.addControl(
      'alphabeticalDirIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'publishOrgDirIndicator',
      new FormControl(false)
    );
    this.communicationWorker.addControl(
      'telephoneBookText',
      new FormControl('')
    );
    this.loadAssignments();
    
    // Subscribe to teleworkProgram changes to auto-check telework checkbox
    this.communicationWorker.get('teleworkProgram')?.valueChanges.subscribe((value: any) => {
      if (value) {
        this.selectedTelework();
      }
      // Update teleworkProgramInvalid flag
      this.updateTeleworkProgramInvalidFlag();
    });
    
    // Subscribe to teleworkIndicator changes to update invalid flag
    this.communicationWorker.get('teleworkIndicator')?.valueChanges.subscribe((value: any) => {
      this.updateTeleworkProgramInvalidFlag();
    });

    // Subscribe to hotelDisplayIndicator changes to update validation
    this.communicationWorker.get('hotelDisplayIndicator')?.valueChanges.subscribe((value: any) => {
      this.updateTeleworkProgramInvalidFlag();
    });
    
    // CRITICAL FIX: Prevent accordion from scrolling page
    this.disableAccordionScroll();
  }

  ngAfterViewInit(): void {
   const inputs = this.elRef.nativeElement.querySelectorAll('input', 'select', 'textarea', 'button');

   inputs.forEach((input: HTMLElement)=> {
     input.focus = () => {console.warn('focus prevented')};
   });
  }

  /**
   * CRITICAL FIX: Disable scrollIntoView behavior on accordion elements
   */
  private disableAccordionScroll(): void {
    const originalScrollIntoView = (Element.prototype as any).scrollIntoView;
    
    (Element.prototype as any).scrollIntoView = function(options?: boolean | ScrollIntoViewOptions) {
      const isAccordionElement = (this as HTMLElement).closest('accordion-group') !== null;
      
      if (!isAccordionElement) {
        originalScrollIntoView.call(this, options);
      }
    };
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['workerBase']) {
      // Load display indicators from worker data when workerBase changes
      this.loadDisplayIndicatorsFromWorker();
    }
    // Also check if the worker object itself changed (for cases where workerBase reference doesn't change)
    if (changes['workerBase']?.currentValue?.worker) {
      this.loadDisplayIndicatorsFromWorker();
    }
  }

  /**
   * Load display indicators from worker data
   * These are stored at the worker level and should be populated into the form
   */
  private loadDisplayIndicatorsFromWorker(): void {
    if (this.workerBase?.worker) {
      // When teleworkProgram is present, check the telework checkbox and set the program
      const teleworkProgramValue = this.workerBase.worker.teleworkProgram?.teleworkProgramId ||
                                   this.workerBase.worker.teleworkProgram?.id || '';
      
      // Determine if hoteling should be checked based on telework program's hotelingIndicator
      const shouldCheckHoteling = this.workerBase.worker.teleworkProgram?.hotelingIndicator === true ||
                                  this.workerBase.worker.hotelDisplayIndicator === true;
      
      this.communicationWorker.patchValue({
        internetDisplayIndicator: this.workerBase.worker.internetDisplayIndicator || false,
        intranetDisplayIndicator: this.workerBase.worker.intranetDisplayIndicator || false,
        hotelDisplayIndicator: shouldCheckHoteling,
        teleworkIndicator: this.workerBase.worker.teleworkProgram ? true : (this.workerBase.worker.teleworkIndicator || false),
        teleworkProgram: teleworkProgramValue
      });
      
      // Update isHoteling flag for UI purposes
      if (this.workerBase.worker.teleworkProgram?.hotelingIndicator === true) {
        this.isHoteling = true;
      }
      
      // Initialize the teleworkProgramInvalid flag based on current state
      this.updateTeleworkProgramInvalidFlag();
    }
  }

  addCommunication() {
    if (!this.editAddMode) {
      // this.viewMode = 0;
      this.editAddMode = true;
      this.selectedCommunication = {};
      this.base.newCommunicationLocation = {};
      this.base.newCommunicationOrganization = {};
      this.showAddCommunication = true;
      // this.mode(this.editAddMode);
    }
  }

  onTeleworkProgramChange() {
    this.selectedTelework();
    // Update flag
    this.updateTeleworkProgramInvalidFlag();
  }

  selectedTelework() {
    const teleworkProgram = this.communicationWorker.get('teleworkProgram')?.value;
    if (teleworkProgram) {
      // When a telework program is selected, automatically check the telework checkbox
      this.communicationWorker.patchValue({
        teleworkIndicator: true
      });
      
      // Update worker telework indicator
      if (this.workerBase?.worker) {
        this.workerBase.worker.teleworkIndicator = true;
      }
      
      // Check if the program has hoteling
      if (teleworkProgram.hotelingIndicator) {
        this.isHoteling = true;
        this.communicationWorker.patchValue({
          hotelDisplayIndicator: true
        });
        if (this.workerBase?.worker) {
          this.workerBase.worker.hotelDisplayIndicator = true;
        }
      } else {
        this.isHoteling = false;
      }
    } else {
      this.isHoteling = false;
    }
  }

  /**
   * Update telework validation errors in real-time based on checkbox and program selection
   * Shows all applicable error messages as user interacts with the form
   */
  private updateTeleworkProgramInvalidFlag(): void {
    const teleworkIndicator = this.communicationWorker.get('teleworkIndicator')?.value;
    const hotelDisplayIndicator = this.communicationWorker.get('hotelDisplayIndicator')?.value;
    const teleworkProgram = this.communicationWorker.get('teleworkProgram')?.value;
    const isRoomCoordinator = this.userRoles.indexOf('InfraRoomCoordinator') !== -1;

    // Clear previous error messages
    this.teleworkErrorMessages = [];

    // Error 1: Hoteling checked but Telework NOT checked (non-RoomCoordinator)
    if (hotelDisplayIndicator && !teleworkIndicator && !isRoomCoordinator) {
      this.teleworkErrorMessages.push('The Telework box must be check first with a description');
    }

    // Error 2: Telework checked but no program selected
    if (teleworkIndicator && (teleworkProgram === null || teleworkProgram === '' || teleworkProgram === undefined)) {
      this.teleworkErrorMessages.push('Telework program is required');
    }

    // Set invalid flag for backward compatibility
    this.teleworkProgramInvalid = this.teleworkErrorMessages.length > 0;
    
    // Also update the worker object for persistence
    if (this.workerBase?.worker) {
      this.workerBase.worker.teleworkProgramInvalid = this.teleworkProgramInvalid;
      this.workerBase.worker.teleworkErrorMessages = this.teleworkErrorMessages;
    }
  }

  cancelAdd() {
    // If we were editing a communication, restore it to its original state
    if (this.editingCommunicationIndex >= 0 && this.originalCommunication) {
      // Restore the original communication data (it's still in the list, just update it)
      this.workerBase.workerTelecommunicationHistory[this.editingCommunicationIndex] = this.originalCommunication;
      this.editingCommunicationIndex = -1;
      this.originalCommunication = null;
    }
    
    this.showAddCommunication = false;
    this.editAddMode = false;
    this.base.selectedCommunication = {};
    this.base.newCommunication = {
      primaryIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      telephoneNo: '',
      telecomAddressType: null
    };
    this.telephoneNoInvalid = false;
    this.communicationTypeInvalid = false;
    this.primaryIndicatorInvalid = false;
    
    // IMPORTANT: Do NOT reset worker-level display indicators (internet, intranet, hoteling)
    // These are worker-level settings, not communication-level
    // They should be preserved when canceling communication edit
    
    // Reset only communication-specific form fields
    this.communicationWorker.patchValue({
      telephoneNo: '',
      extensionNo: '',
      telecomAddressType: '',
      primaryIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      alphabeticalDirIndicator: false,
      publishOrgDirIndicator: false,
      telephoneBookText: '',
      code: '',
      floorNumber: '',
      corridorId: '',
      suiteId: '',
      roomId: '',
      zoneId: ''
    });
  }

  resetAdd() {
    this.base.newCommunication = {
      primaryIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      telephoneNo: '',
      telecomAddressType: null
    };
    
    // Reset ONLY communication-specific form controls
    // IMPORTANT: Do NOT reset display indicators (internet, intranet, hoteling, telework)
    // These are worker-level settings that should persist across communication saves
    this.communicationWorker.patchValue({
      // DO NOT RESET: internetDisplayIndicator, intranetDisplayIndicator, hotelDisplayIndicator, teleworkIndicator
      // These are worker-level and should be preserved
      teleworkProgram: '',
      primaryIndicator: false,
      hiddenIndicator: false,
      alternateIndicator: false,
      telecomAddressType: '',
      communicationTypeError: '',
      telephoneNo: '',
      extensionNo: '',
      telephoneNoError: false,
      code: '',
      floorNumber: '',
      corridorId: '',
      suiteId: '',
      roomId: '',
      zoneId: '',
      alphabeticalDirIndicator: false,
      publishOrgDirIndicator: false,
      telephoneBookText: ''
    });
    
    this.telephoneNoInvalid = false;
    this.communicationTypeInvalid = false;
    this.primaryIndicatorInvalid = false;
    this.teleworkProgramInvalid = false;
  }

  acceptAdd() {
    if (!this.validateCommunication()) {
      return;
    }

    // Update worker display indicators from form
    // IMPORTANT: Display indicators are WORKER-LEVEL settings, NOT communication-level
    // They should be updated on the worker object, NOT added to the communication object
    if (this.workerBase?.worker) {
      this.workerBase.worker.internetDisplayIndicator = this.communicationWorker.get('internetDisplayIndicator')?.value || false;
      this.workerBase.worker.intranetDisplayIndicator = this.communicationWorker.get('intranetDisplayIndicator')?.value || false;
      this.workerBase.worker.hotelDisplayIndicator = this.communicationWorker.get('hotelDisplayIndicator')?.value || false;
      this.workerBase.worker.teleworkIndicator = this.communicationWorker.get('teleworkIndicator')?.value || false;
    }

    // Build communication object with ONLY communication-specific fields
    // Display indicators (internet, intranet, hoteling, telework) are NOT part of the communication
    
    // Smart indicator logic:
    // 1. If it's the first communication (no existing records), set primaryIndicator to true
    // 2. If all three indicators are false AND there's already a primary record, set alternateIndicator to true
    // 3. If all three indicators are false AND there's no primary record, set primaryIndicator to true
    let primaryIndicator = this.base.newCommunication.primaryIndicator;
    let hiddenIndicator = this.base.newCommunication.hiddenIndicator;
    let alternateIndicator = this.base.newCommunication.alternateIndicator;
    
    // Check if all three indicators are false
    if (!primaryIndicator && !hiddenIndicator && !alternateIndicator) {
      // Check if this is the first communication (no existing records)
      const isFirstCommunication = !this.workerBase.workerTelecommunicationHistory ||
                                   this.workerBase.workerTelecommunicationHistory.length === 0;
      
      if (isFirstCommunication) {
        // First communication - set primaryIndicator to true
        primaryIndicator = true;
        this.base.newCommunication.primaryIndicator = true;
        this.communicationWorker.patchValue({ primaryIndicator: true }, { emitEvent: false });
      } else {
        // Check if there's already a primary record
        const hasPrimaryRecord = this.workerBase.workerTelecommunicationHistory.some(
          (comm: any) => comm.primaryIndicator === true
        );
        
        if (hasPrimaryRecord) {
          // Primary record exists - set alternateIndicator to true
          alternateIndicator = true;
          this.base.newCommunication.alternateIndicator = true;
          this.communicationWorker.patchValue({ alternateIndicator: true }, { emitEvent: false });
        } else {
          // No primary record exists - set primaryIndicator to true
          primaryIndicator = true;
          this.base.newCommunication.primaryIndicator = true;
          this.communicationWorker.patchValue({ primaryIndicator: true }, { emitEvent: false });
        }
      }
    }
    
    const communication: any = {
      // Basic communication data
      telephoneNo: this.base.newCommunication.telephoneNo,
      extensionNo: this.base.newCommunication.extensionNo || '',
      telecomAddressType: this.base.newCommunication.telecomAddressType,
      
      // Indicators
      primaryIndicator: primaryIndicator,
      hiddenIndicator: hiddenIndicator,
      alternateIndicator: alternateIndicator,
      
      // Publication indicators - PRESERVE THESE FIELDS
      alphabeticalDirIndicator: this.communicationWorker.get('alphabeticalDirIndicator')?.value || false,
      publishOrgDirIndicator: this.communicationWorker.get('publishOrgDirIndicator')?.value || false,
      telephoneBookText: this.communicationWorker.get('telephoneBookText')?.value || ''
    };
    
    // Ensure telecomAddressType has the full object with description for display
    if (communication.telecomAddressType && typeof communication.telecomAddressType === 'object' && !communication.telecomAddressType.description) {
      // If it's an object but missing description, try to find it
      const typeId = communication.telecomAddressType.id || communication.telecomAddressType;
      const telecomType = this.workerBase.telecomTypes.find((type: any) => type.id === typeId);
      if (telecomType) {
        communication.telecomAddressType = telecomType;
      }
    } else if (communication.telecomAddressType && typeof communication.telecomAddressType !== 'object') {
      // If it's just an ID, find the full object
      const telecomType = this.workerBase.telecomTypes.find((type: any) => type.id === communication.telecomAddressType);
      if (telecomType) {
        communication.telecomAddressType = telecomType;
      }
    }
    
    // DEBUG: Log the communication object being saved
    console.log('Communication being saved:', communication);
    console.log('Telecom Address Type:', communication.telecomAddressType);
    console.log('Available Telecom Types:', this.workerBase.telecomTypes);

    // Add location assignment data from form controls
    const assignmentLocation: any = {
      code: this.communicationWorker.get('code')?.value || '',
      floorNumber: this.communicationWorker.get('floorNumber')?.value || '',
      corridorId: this.communicationWorker.get('corridorId')?.value || '',
      suiteId: this.communicationWorker.get('suiteId')?.value || '',
      roomId: this.communicationWorker.get('roomId')?.value || '',
      zoneId: this.communicationWorker.get('zoneId')?.value || ''
    };
    
    // Only add assignmentLocation if it has any values
    if (Object.values(assignmentLocation).some(val => val)) {
      communication.assignmentLocation = assignmentLocation;
    }

    // Add workerAssignment if present (for acronym and organization data)
    if (this.base.newCommunication.workerAssignment) {
      communication.workerAssignment = this.base.newCommunication.workerAssignment;
    }

    // Add mailLocation if present
    if (this.base.newCommunication.mailLocation && Object.keys(this.base.newCommunication.mailLocation).length > 0) {
      communication.mailLocation = this.base.newCommunication.mailLocation;
    }

    // Add palmLocation if present
    if (this.base.newCommunication.palmLocation && Object.keys(this.base.newCommunication.palmLocation).length > 0) {
      communication.palmLocation = this.base.newCommunication.palmLocation;
    }

    // Add location if present (legacy support)
    if (this.base.newCommunicationLocation) {
      communication.location = this.base.newCommunicationLocation;
    }

    // Add organization if present (legacy support)
    if (this.base.newCommunicationOrganization) {
      communication.organization = this.base.newCommunicationOrganization;
    }

    // Check if we're editing an existing communication or adding a new one
    if (this.editingCommunicationIndex >= 0) {
      // Update existing communication in the history (it's still in the list)
      this.workerBase.workerTelecommunicationHistory[this.editingCommunicationIndex] = communication;
      this.editingCommunicationIndex = -1;
      this.originalCommunication = null;
    } else {
      // Add new communication to telecommunications history (displayed in template)
      this.workerBase.workerTelecommunicationHistory.push(communication);
      // Also add to workerCommunications for backward compatibility
      this.workerBase.workerCommunications.push(communication);
    }
    
    // Reset form
    this.resetAdd();
    this.showAddCommunication = false;
    this.editAddMode = false;
  }

  validateCommunication(): boolean {
    let isValid = true;

    // Validate telephone number
    const telephoneNo = this.base.newCommunication.telephoneNo;
    if (!telephoneNo || telephoneNo.trim() === '') {
      this.telephoneNoInvalid = true;
      isValid = false;
    } else if (telephoneNo.length !== 14) { // Format: (XXX) XXX-XXXX
      this.telephoneNoInvalid = true;
      isValid = false;
    } else {
      this.telephoneNoInvalid = false;
    }

    // Validate communication type
    if (!this.base.newCommunication.telecomAddressType) {
      this.communicationTypeInvalid = true;
      isValid = false;
    } else {
      this.communicationTypeInvalid = false;
    }

    // Validate indicators (exactly one must be true)
    const primary = this.base.newCommunication.primaryIndicator;
    const hidden = this.base.newCommunication.hiddenIndicator;
    const alternate = this.base.newCommunication.alternateIndicator;
    const indicatorCount = [primary, hidden, alternate].filter(Boolean).length;
    
    // if (indicatorCount !== 1) {
    //   this.primaryIndicatorInvalid = true;
    //   isValid = false;
    // } else {
    //   this.primaryIndicatorInvalid = false;
    // }

    return isValid;
  }

  changeLocation(val: any) {
    // Get the workerId from the current worker
    const workerId = this.workerBase?.worker?.workerId;
    
    const failureDialogRef = this.dialog.open(AssignmentSelectComponent, {
      width: '80%',
      maxWidth: '1200px',
      height: 'auto',
      data: {
        workerId: workerId,
        location: val
      },
    });

    // Handle the dialog response when user selects a location
    failureDialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.location) {
        // Populate the location assignment fields from the selected location
        const location = result.location;
        
        // Update form controls with location data
        this.communicationWorker.patchValue({
          code: location.building?.code || '',
          floorNumber: location.building?.floorNumber || '',
          corridorId: location.corridorId || '',
          suiteId: location.suiteId || '',
          roomId: location.roomId || '',
          zoneId: location.zoneId || ''
        });

        // Also update the base object for persistence
        if (this.editingCommunicationIndex >= 0) {
          // Editing mode - update selectedCommunication
          this.base.selectedCommunication.assignmentLocation = {
            code: location.building?.code || '',
            floorNumber: location.building?.floorNumber || '',
            corridorId: location.corridorId || '',
            suiteId: location.suiteId || '',
            roomId: location.roomId || '',
            zoneId: location.zoneId || ''
          };
        } else {
          // Add mode - update newCommunication
          this.base.newCommunication.assignmentLocation = {
            code: location.building?.code || '',
            floorNumber: location.building?.floorNumber || '',
            corridorId: location.corridorId || '',
            suiteId: location.suiteId || '',
            roomId: location.roomId || '',
            zoneId: location.zoneId || ''
          };
        }

        // Store the assignment data if available - this includes the acronym information
        if (result.assignment) {
          if (this.editingCommunicationIndex >= 0) {
            this.base.selectedCommunication.workerAssignment = result.assignment;
          } else {
            this.base.newCommunication.workerAssignment = result.assignment;
          }
          // Trigger change detection to update the acronym field
          this.cdr.detectChanges();
        }
      } else if (result && result.assignment) {
        // If only assignment is returned (from location lookup), fetch the full location details
        const assignment = result.assignment;
        
        // Store the assignment data for acronym display
        if (this.editingCommunicationIndex >= 0) {
          this.base.selectedCommunication.workerAssignment = assignment;
        } else {
          this.base.newCommunication.workerAssignment = assignment;
        }
        
        // Call API to get full location details
        if (assignment.assignmentLocation && assignment.assignmentLocation.locationId) {
          this.assignmentLocationService.getLocationDetails(assignment.assignmentLocation.locationId).subscribe(
            (location: any) => {
              if (location) {
                // Update form controls with location data
                this.communicationWorker.patchValue({
                  code: location.building?.code || '',
                  floorNumber: location.building?.floorNumber || '',
                  corridorId: location.corridorId || '',
                  suiteId: location.suiteId || '',
                  roomId: location.roomId || '',
                  zoneId: location.zoneId || ''
                });

                // Update base object for persistence
                const assignmentLocation = {
                  code: location.building?.code || '',
                  floorNumber: location.building?.floorNumber || '',
                  corridorId: location.corridorId || '',
                  suiteId: location.suiteId || '',
                  roomId: location.roomId || '',
                  zoneId: location.zoneId || ''
                };

                if (this.editingCommunicationIndex >= 0) {
                  this.base.selectedCommunication.assignmentLocation = assignmentLocation;
                } else {
                  this.base.newCommunication.assignmentLocation = assignmentLocation;
                }

                // Trigger change detection to update all fields including acronym
                this.cdr.detectChanges();
              }
            },
            (error: any) => {
              console.error('Error fetching location details:', error);
            }
          );
        }
      }
    });
  }

  setPrimary(val: boolean) {
    if (val) {
      this.base.newCommunication.primaryIndicator = true;
      this.base.newCommunication.hiddenIndicator = false;
      this.base.newCommunication.alternateIndicator = false;
      this.communicationWorker.patchValue({
        primaryIndicator: true,
        hiddenIndicator: false,
        alternateIndicator: false
      });
    } else {
      this.base.newCommunication.primaryIndicator = false;
      this.communicationWorker.patchValue({ primaryIndicator: false });
    }
    this.primaryIndicatorInvalid = false;
  }

  setHidden(val: boolean) {
    if (val) {
      this.base.newCommunication.hiddenIndicator = true;
      this.base.newCommunication.primaryIndicator = false;
      this.base.newCommunication.alternateIndicator = false;
      this.communicationWorker.patchValue({
        hiddenIndicator: true,
        primaryIndicator: false,
        alternateIndicator: false
      });
    } else {
      this.base.newCommunication.hiddenIndicator = false;
      this.communicationWorker.patchValue({ hiddenIndicator: false });
    }
    this.primaryIndicatorInvalid = false;
  }

  setAlternate(val: boolean) {
    if (val) {
      this.base.newCommunication.alternateIndicator = true;
      this.base.newCommunication.primaryIndicator = false;
      this.base.newCommunication.hiddenIndicator = false;
      this.communicationWorker.patchValue({
        alternateIndicator: true,
        primaryIndicator: false,
        hiddenIndicator: false
      });
    } else {
      this.base.newCommunication.alternateIndicator = false;
      this.communicationWorker.patchValue({ alternateIndicator: false });
    }
    this.primaryIndicatorInvalid = false;
  }

  removeCommunication(index: number) {
    // Remove from workerTelecommunicationHistory (the array being displayed)
    if (index >= 0 && this.workerBase?.workerTelecommunicationHistory && index < this.workerBase.workerTelecommunicationHistory.length) {
      this.workerBase.workerTelecommunicationHistory.splice(index, 1);
    }
    // Also remove from workerCommunications for backward compatibility
    if (index >= 0 && this.workerBase?.workerCommunications && index < this.workerBase.workerCommunications.length) {
      this.workerBase.workerCommunications.splice(index, 1);
    }
  }

  editCommunication(index: number) {
    // Check if we have telecommunications data (from dedicated endpoint)
    if (index >= 0 && this.workerBase?.workerTelecommunicationHistory && index < this.workerBase.workerTelecommunicationHistory.length) {
      const communication = this.workerBase.workerTelecommunicationHistory[index];
      
      // Store the original communication and index for restoration if user cancels
      this.editingCommunicationIndex = index;
      this.originalCommunication = JSON.parse(JSON.stringify(communication));
      
      // Store the entire communication object for editing
      this.base.selectedCommunication = JSON.parse(JSON.stringify(communication));
      
      // Populate the form with existing communication data - PRESERVE ALL FIELDS
      this.base.newCommunication = {
        // Basic communication data
        telephoneNo: communication.telephoneNo || '',
        extensionNo: communication.extensionNo || '',
        telecomAddressType: communication.telecomAddressType || null,
        
        // Indicators
        primaryIndicator: communication.primaryIndicator || false,
        hiddenIndicator: communication.hiddenIndicator || false,
        alternateIndicator: communication.alternateIndicator || false,
        
        // Publication indicators
        alphabeticalDirIndicator: communication.alphabeticalDirIndicator || false,
        publishOrgDirIndicator: communication.publishOrgDirIndicator || false,
        telephoneBookText: communication.telephoneBookText || '',
        
        // Location and organization data
        workerAssignment: communication.workerAssignment || {},
        assignmentLocation: communication.assignmentLocation || {},
        mailLocation: communication.mailLocation || {},
        palmLocation: communication.palmLocation || {}
      };

      // Ensure telecomAddressType has the full object with description for display
      let telecomAddressTypeValue = communication.telecomAddressType;
      if (telecomAddressTypeValue && typeof telecomAddressTypeValue === 'object' && telecomAddressTypeValue.id) {
        // Already an object, use its ID for form control
        telecomAddressTypeValue = telecomAddressTypeValue.id;
      } else if (telecomAddressTypeValue && typeof telecomAddressTypeValue !== 'object') {
        // It's just an ID, find the full object
        const telecomType = this.workerBase.telecomTypes.find((type: any) => type.id === telecomAddressTypeValue);
        if (telecomType) {
          this.base.newCommunication.telecomAddressType = telecomType;
          this.base.selectedCommunication.telecomAddressType = telecomType;
        }
      }
      
      // Set form controls for communication-specific fields
      this.communicationWorker.patchValue({
        // Basic communication
        telephoneNo: communication.telephoneNo || '',
        extensionNo: communication.extensionNo || '',
        telecomAddressType: telecomAddressTypeValue || null,
        
        // Indicators
        primaryIndicator: communication.primaryIndicator || false,
        hiddenIndicator: communication.hiddenIndicator || false,
        alternateIndicator: communication.alternateIndicator || false,
        
        // Publication indicators - CRITICAL: These must be set for edit mode
        alphabeticalDirIndicator: communication.alphabeticalDirIndicator || false,
        publishOrgDirIndicator: communication.publishOrgDirIndicator || false,
        telephoneBookText: communication.telephoneBookText || '',
        
        // Location assignment fields - populate from assignmentLocation if available
        code: communication.assignmentLocation?.code || '',
        floorNumber: communication.assignmentLocation?.floorNumber || '',
        corridorId: communication.assignmentLocation?.corridorId || '',
        suiteId: communication.assignmentLocation?.suiteId || '',
        roomId: communication.assignmentLocation?.roomId || '',
        zoneId: communication.assignmentLocation?.zoneId || ''
      });

      // Store the workerAssignment for acronym display
      if (communication.workerAssignment) {
        this.base.newCommunication.workerAssignment = communication.workerAssignment;
        this.base.selectedCommunication.workerAssignment = communication.workerAssignment;
      }

      // DO NOT remove the communication from the list - keep it there and just hide the display row
      // The display row will be hidden by the *ngIf condition in the template
      // and the edit row will be shown in its place

      // Load primary assignment details from API when entering edit mode
      // This mirrors the old setPrimaryDetails() method behavior
      // API Calls:
      // 1. GET /infra-services/workers/{workerId}/assignments
      // 2. GET /infra-services/locations/{locationId} (for each assignment)
      this.setPrimaryDetails(communication);

      // Show edit mode
      this.editAddMode = true;
    }
  }

  /**
   * Load primary assignment details when editing a communication
   * This method:
   * 1. Calls API to get all assignments for the worker: GET /infra-services/workers/{workerId}/assignments
   * 2. For each assignment with location, calls API to get location details: GET /infra-services/locations/{locationId}
   * 3. Loops through ALL assignments and sets location on the communication from each one
   * 4. Then filters to get primary assignment and sets it on the communication
   *
   * This mirrors the old controller's setPrimaryDetails() method exactly
   *
   * IMPORTANT: This method loads the assignments and location data but does NOT populate the location form fields.
   * Location form fields are only populated when the user explicitly clicks the location lookup button.
   *
   * @param telecommunication - The communication being edited
   */
  private setPrimaryDetails(telecommunication: any): void {
    if (!this.workerBase?.worker?.workerId) {
      return;
    }

    const workerId = this.workerBase.worker.workerId;

    // Call the service to get all location assignments
    // API Call 1: GET /infra-services/workers/{workerId}/assignments
    // API Call 2: GET /infra-services/locations/{locationId} (for each assignment)
    this.assignmentLocationService.getLocationAssignments(workerId).subscribe(
      (assignmentLocations: any[]) => {
        if (!assignmentLocations || assignmentLocations.length === 0) {
          return;
        }

        const primaryAssignments: any[] = [];

        // Loop through ALL assignments (mirrors old code behavior)
        assignmentLocations.forEach((element: any) => {
          // Set location on telecommunication from EACH assignment
          // This means the location will be set from the LAST assignment in the loop
          if (element.location) {
            telecommunication.location = element.location;
            this.base.selectedCommunication.location = element.location;
            this.base.newCommunication.location = element.location;
          }

          // Filter for PRIMARY assignments
          if (element.assignment && element.assignment.primaryLocationIndicator === true) {
            primaryAssignments.push(element);
          }
        });

        // If we have primary assignments, set the primary info
        if (primaryAssignments.length > 0) {
          this.setPrimaryInfo(telecommunication, primaryAssignments);
        }

        // IMPORTANT: Do NOT populate location form fields here
        // Location form fields should only be populated when user clicks the location lookup button
        // The location data is loaded and available in the telecommunication object for later use

        // Trigger change detection to update the view
        this.cdr.detectChanges();
      },
      (error: any) => {

      }
    );
  }

  /**
   * Set primary assignment info on the communication
   * This mirrors the old setPrimaryInfo() method
   *
   * @param telecommunication - The communication being edited
   * @param primaryAssignments - Array of primary assignments
   */
  private setPrimaryInfo(telecommunication: any, primaryAssignments: any[]): void {
    if (primaryAssignments.length === 0) {
      return;
    }

    const primaryAssignment = primaryAssignments[0].assignment;
    const primaryLocation = primaryAssignments[0].location;
    
    // Set the primary assignment on the communication
    telecommunication.workerAssignment = primaryAssignment;
    this.base.newCommunication.workerAssignment = primaryAssignment;
    this.base.selectedCommunication.workerAssignment = primaryAssignment;

    // Set the primary location on the communication and populate form fields
    if (primaryLocation) {
      // Store location in communication objects
      telecommunication.assignmentLocation = {
        code: primaryLocation.building?.code || '',
        floorNumber: primaryLocation.building?.floorNumber || '',
        corridorId: primaryLocation.corridorId || '',
        suiteId: primaryLocation.suiteId || '',
        roomId: primaryLocation.roomId || '',
        zoneId: primaryLocation.zoneId || ''
      };
      
      this.base.newCommunication.assignmentLocation = telecommunication.assignmentLocation;
      this.base.selectedCommunication.assignmentLocation = telecommunication.assignmentLocation;
      
      // Populate form controls with location data
      this.communicationWorker.patchValue({
        code: primaryLocation.building?.code || '',
        floorNumber: primaryLocation.building?.floorNumber || '',
        corridorId: primaryLocation.corridorId || '',
        suiteId: primaryLocation.suiteId || '',
        roomId: primaryLocation.roomId || '',
        zoneId: primaryLocation.zoneId || ''
      });
    }

    // Compute and set acronym if organization data is available
    if (primaryAssignment?.workerOrganization?.organization) {
      const org = primaryAssignment.workerOrganization.organization;
      const businessAreaCode = org.businessAreaCode?.trim() || '';
      const shortName = org.shortName?.trim() || '';
      
      // Acronym is computed as businessAreaCode/shortName
      primaryAssignment.workerOrganization.organization.acronym =
        shortName ? `${businessAreaCode}/${shortName}` : businessAreaCode;
    }
  }

  formatPhoneNumber(phoneNumber: string): string {
    // Remove all non-numeric characters
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // Format as (XXX) XXX-XXXX
    if (cleaned.length === 10) {
      return `(${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)}-${cleaned.substring(6, 10)}`;
    }
    
    return phoneNumber;
  }

  onPhoneNumberChange(event: any) {
    let value = event.target.value;
    
    // Remove all non-numeric characters
    const cleaned = value.replace(/\D/g, '');
    
    // Format progressively as user types
    let formatted = '';
    if (cleaned.length === 0) {
      formatted = '';
    } else if (cleaned.length <= 3) {
      // (XXX
      formatted = `(${cleaned}`;
    } else if (cleaned.length <= 6) {
      // (XXX) XXX
      formatted = `(${cleaned.substring(0, 3)}) ${cleaned.substring(3)}`;
    } else {
      // (XXX) XXX-XXXX
      formatted = `(${cleaned.substring(0, 3)}) ${cleaned.substring(3, 6)}-${cleaned.substring(6, 10)}`;
    }
    
    // Update the model and input field
    this.base.newCommunication.telephoneNo = formatted;
    event.target.value = formatted;
    
    // Sync form control
    this.communicationWorker.patchValue({
      telephoneNo: formatted
    }, { emitEvent: false });
    
    // Clear validation error when user starts typing
    if (this.telephoneNoInvalid && cleaned.length > 0) {
      this.telephoneNoInvalid = false;
    }
  }

  onTelecomTypeChange(event: any) {
    console.log('onTelecomTypeChange called');
    console.log('event.target.value:', event.target.value);
    console.log('this.communicationWorker.get(telecomAddressType).value:', this.communicationWorker.get('telecomAddressType')?.value);
    
    // Get the value from the form control (which uses ngValue)
    const selectedId = this.communicationWorker.get('telecomAddressType')?.value;
    
    console.log('selectedId:', selectedId);
    console.log('Available telecomTypes:', this.workerBase.telecomTypes);
    
    // Find the full telecom type object from the available types
    const selectedTelecomType = this.workerBase.telecomTypes.find((type: any) => type.id === selectedId);
    
    console.log('selectedTelecomType:', selectedTelecomType);
    
    // Update the model with the full object (or just ID if object not found)
    this.base.newCommunication.telecomAddressType = selectedTelecomType || selectedId;
    
    console.log('Updated base.newCommunication.telecomAddressType:', this.base.newCommunication.telecomAddressType);
    
    // Clear validation error when user selects a type
    if (this.communicationTypeInvalid && selectedId) {
      this.communicationTypeInvalid = false;
    }
  }

  onExtensionChange(event: any) {
    let value = event.target.value;
    
    // Remove all non-numeric characters
    const cleaned = value.replace(/\D/g, '');
    
    // Limit to 4 digits
    const limited = cleaned.substring(0, 4);
    
    // Update the model and input field
    this.base.newCommunication.extensionNo = limited;
    event.target.value = limited;
    
    // Sync form control
    this.communicationWorker.patchValue({
      extensionNo: limited
    }, { emitEvent: false });
  }

  getWorkerTeleworkPrograms() {
    this.httpService.get('/telework-programs').subscribe(
      (response: any) => {
        this.workerBase.teleworkPrograms = response.results.map((program: any) => ({
          id: program.id,
          value: program.code,
          description: program.description,
          hotelingIndicator: program.hotelingIndicator,
        }));
      },
      (error: any) => {
        this.handleError(error);
      }
    );
  }

  getTelecomTypes() {
    this.relocationService.getTelecomTypes().subscribe({
      next: (response: any) => {
        this.workerBase.telecomTypes = response.results.map((type: any) => ({
          id: type.id,
          value: type.code,
          description: type.description,
          inactive: type.inactive,
        }));
      },
      error: (err) => {
        this.handleError(err);
      },
    });
  }

  getPalmLocations() {
    this.httpService.get('/palmlocations?includeInactive=false').subscribe({
      next: (response: any) => {
        this.workerBase.palmLocations = response.results.map((location: any) => ({
          id: location.id,
          value: location.code,
          description: location.description,
          inactive: location.inactive,
        }));
      },
      error: (err) => {
        return [];
      },
    });
  }
  loadAssignments() {
    // Replace accessAssignmentsRef() with your actual access check logic
    if (this.accessAssignmentsRef()) {
      this.getWorkerTeleworkPrograms();
      this.getTelecomTypes();
      this.getPalmLocations();
    }
  }

  accessAssignmentsRef(): boolean {
    // Implement your access check logic here
    return true;
  }

  handleError(response: any) {}

  /**
   * Get grouped communications with primary as parent and alternatives as children
   * Returns array of primary communications with their alternatives nested
   */
  getGroupedCommunications(): any[] {
    if (!this.workerBase?.workerTelecommunicationHistory) {
      return [];
    }

    const communications = this.workerBase.workerTelecommunicationHistory;
    const grouped: any[] = [];

    // Find all primary communications
    communications.forEach((comm: any, index: number) => {
      if (comm.primaryIndicator === true) {
        // Add primary communication with its index
        grouped.push({
          ...comm,
          originalIndex: index,
          isPrimary: true,
          alternatives: []
        });
      }
    });

    // Find all alternative communications and group them under their primary
    communications.forEach((comm: any, index: number) => {
      if (comm.alternateIndicator === true || comm.hiddenIndicator === true) {
        // For now, add alternatives to the first primary
        // In a real scenario, you might want to match them based on type or other criteria
        if (grouped.length > 0) {
          grouped[0].alternatives.push({
            ...comm,
            originalIndex: index,
            isPrimary: false
          });
        } else {
          // If no primary exists, add as standalone
          grouped.push({
            ...comm,
            originalIndex: index,
            isPrimary: false,
            alternatives: []
          });
        }
      }
    });

    return grouped;
  }

  /**
   * Toggle between showing all communications or just primary
   * Now accepts optional parameter to expand/collapse specific primary
   */
  toggleCommunications(primaryIndex?: number) {
    if (primaryIndex !== undefined) {
      // Toggle specific primary's alternatives
      if (this.expandedPrimaryIndex === primaryIndex) {
        this.expandedPrimaryIndex = -1; // Collapse
      } else {
        this.expandedPrimaryIndex = primaryIndex; // Expand
      }
    } else {
      // Toggle all communications visibility
      this.showAllCommunications = !this.showAllCommunications;
    }
  }

  /**
   * Set detail mode for a communication (expand to show details)
   */
 setDetailMode(workerLocation: any): void {
    if (!workerLocation.viewMode || workerLocation.viewMode === 0) {
      workerLocation.viewMode = 1;
    } else if (workerLocation.viewMode === 1) {
      workerLocation.viewMode = 0;
    }
    // Trigger change detection to update the view
    // this.cdr.detectChanges();
  }


  setDetailModeAlt(workerLocation: any): void {
    if (!workerLocation.viewMode || workerLocation.viewMode === 0) {
      workerLocation.viewMode = 1;
    } else if (workerLocation.viewMode === 1) {
      workerLocation.viewMode = 0;
    }
    // Trigger change detection to update the view
    this.cdr.detectChanges();
  }
  /**
   * Get telecom type description safely
   * Handles both cases: when telecomAddressType is an object or just an ID
   * @param telecomAddressType - The telecom address type (object or ID)
   * @returns The description string
   */
  getTelecomTypeDescription(telecomAddressType: any): string {
    console.log('getTelecomTypeDescription called with:', telecomAddressType);
    
    if (!telecomAddressType) {
      console.log('telecomAddressType is null/undefined');
      return '';
    }
    
    // If it's already an object with description, return it
    if (typeof telecomAddressType === 'object' && telecomAddressType.description) {
      console.log('Returning description from object:', telecomAddressType.description);
      return telecomAddressType.description;
    }
    
    // If it's just an ID, look it up in the telecomTypes array
    const typeId = (typeof telecomAddressType === 'object' && telecomAddressType.id) ? telecomAddressType.id : telecomAddressType;
    
    console.log('Looking up typeId:', typeId);
    
    if (!typeId) {
      console.log('typeId is null/undefined');
      return '';
    }
    
    const telecomType = this.workerBase.telecomTypes.find((type: any) => type.id === typeId);
    console.log('Found telecomType:', telecomType);
    const result = telecomType?.description || telecomType?.value || '';
    console.log('Returning result:', result);
    return result;
  }
  getTelecomAcronym(businessAreaCode: string, shortName: string) {
    let acronym = '';
    if (businessAreaCode) {
      acronym += businessAreaCode;
    }
    if (shortName) {
      acronym += '/' + shortName;
    }
    return acronym;
  }
}
