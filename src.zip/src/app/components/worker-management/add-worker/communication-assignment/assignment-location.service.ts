import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { Observable, forkJoin, of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';

/**
 * Service to handle worker assignment and location data fetching
 * This service mirrors the old AssignmentsSelectService functionality
 * 
 * API Calls:
 * 1. GET /infra-services/workers/{workerId}/assignments - Get all assignments for a worker
 * 2. GET /infra-services/locations/{locationId} - Get location details for each assignment
 */
@Injectable({
  providedIn: 'root'
})
export class AssignmentLocationService {

  constructor(private httpService: HttpService) { }

  /**
   * Get all assignments for a worker
   * API Call: GET /infra-services/workers/{workerId}/assignments
   * (HttpService automatically adds /infra-services prefix, so we only pass /workers/{workerId}/assignments)
   *
   * @param workerId - The worker ID
   * @returns Observable of assignments array
   */
  private getAssignments(workerId: string | number): Observable<any[]> {
    return this.httpService.get(`/workers/${workerId}/assignments`).pipe(
      map((response: any) => {
        return response.results || response || [];
      }),
      catchError((error) => {

        return of([]);
      })
    );
  }

  /**
    * Get location details for a specific location ID
    * API Call: GET /infra-services/locations/{locationId}
    * (HttpService automatically adds /infra-services prefix, so we only pass /locations/{locationId})
    *
    * @param locationId - The location ID
    * @returns Observable of location object
    */
  private getLocation(locationId: string | number): Observable<any> {
    return this.httpService.get(`/locations/${locationId}`).pipe(
      map((response: any) => response || {}),
      catchError((error) => {

        return of({});
      })
    );
  }

  /**
    * Public method to get location details for a specific location ID
    * API Call: GET /infra-services/locations/{locationId}
    * (HttpService automatically adds /infra-services prefix, so we only pass /locations/{locationId})
    *
    * @param locationId - The location ID
    * @returns Observable of location object
    */
  getLocationDetails(locationId: string | number): Observable<any> {
    return this.getLocation(locationId);
  }

  /**
   * Get location assignments for a worker
   * This method:
   * 1. Fetches all assignments for the worker
   * 2. For each assignment with an assignmentLocation, fetches the location details
   * 3. Returns an array of objects containing both assignment and location data
   * 
   * This mirrors the old AssignmentsSelectService.getLocationAssignments() functionality
   * 
   * @param workerId - The worker ID
   * @returns Observable of array containing assignment and location objects
   */
  getLocationAssignments(workerId: string | number): Observable<any[]> {
    return this.getAssignments(workerId).pipe(
      switchMap((assignments: any[]) => {
        if (!assignments || assignments.length === 0) {
          return of([]);
        }

        // Create an array of observables for location fetches
        const locationObservables = assignments.map((assignment: any) => {
          if (assignment.assignmentLocation && assignment.assignmentLocation.locationId) {
            // Fetch location details for this assignment
            return this.getLocation(assignment.assignmentLocation.locationId).pipe(
              map((location: any) => ({
                assignment: assignment,
                location: location
              }))
            );
          } else {
            // No location for this assignment
            return of({
              assignment: assignment,
              location: null
            });
          }
        });

        // Execute all location fetches in parallel and combine results
        return forkJoin(locationObservables);
      }),
      catchError((error) => {

        return of([]);
      })
    );
  }

  /**
   * Get primary location assignment for a worker
   * Filters assignments to return only those with primaryLocationIndicator = true
   * 
   * @param workerId - The worker ID
   * @returns Observable of array containing primary assignment and location
   */
  getPrimaryLocationAssignment(workerId: string | number): Observable<any[]> {
    return this.getLocationAssignments(workerId).pipe(
      map((assignmentLocations: any[]) => {
        return assignmentLocations.filter((item: any) => 
          item.assignment && item.assignment.primaryLocationIndicator === true
        );
      })
    );
  }
}
