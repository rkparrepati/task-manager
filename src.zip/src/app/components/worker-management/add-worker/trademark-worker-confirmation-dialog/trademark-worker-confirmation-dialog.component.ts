import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-trademark-worker-confirmation-dialog',
  templateUrl: './trademark-worker-confirmation-dialog.component.html',
  styleUrls: ['./trademark-worker-confirmation-dialog.component.scss']
})
export class TrademarkWorkerConfirmationDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<TrademarkWorkerConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  /**
   * User confirmed - proceed with trademark position
   */
  onConfirm(): void {
    this.dialogRef.close({ confirmed: true, response: 'Yes' });
  }

  /**
   * User declined - reject trademark position
   */
  onCancel(): void {
    this.dialogRef.close({ confirmed: false, response: 'No' });
  }
}
