import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-org-code-confirmation-dialog',
  templateUrl: './org-code-confirmation-dialog.component.html',
  styleUrls: ['./org-code-confirmation-dialog.component.scss']
})
export class OrgCodeConfirmationDialogComponent {
  confirmationValue: string = '';
  errorMessage: string = '';

  constructor(
    public dialogRef: MatDialogRef<OrgCodeConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { orgCodeValue: string }
  ) {}

  /**
   * Validate that the re-entered org code matches the original
   * Returns true if values match, false otherwise
   */
  validateInput(): boolean {
    if (this.data.orgCodeValue === this.confirmationValue) {
      this.errorMessage = '';
      return true;
    } else {
      return false;
    }
  }

  /**
   * Show error message when validation fails
   */
  showErrorMessage(): void {
    this.errorMessage = 'The PTO Organization Code entered does not match the previously entered value.';
  }

  /**
   * Handle Enter key press
   * Auto-confirms if values match, shows error if they don't
   */
  onEnterKey(): void {
    if (this.validateInput()) {
      this.onConfirm();
    } else {
      this.showErrorMessage();
    }
  }

  onCancel(): void {
    this.dialogRef.close({ confirmed: false, value: '' });
  }

  onConfirm(): void {
    // Validate before confirming
    if (!this.validateInput()) {
      this.showErrorMessage();
      return;
    }
    this.dialogRef.close({ confirmed: true, value: this.confirmationValue });
  }
}
