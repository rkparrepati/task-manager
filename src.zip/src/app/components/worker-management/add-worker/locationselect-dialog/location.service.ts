import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class LocationService {
  private readonly apiUrl = `${environment.DOMAIN}/infra-services/locations`;
  private readonly DEFAULT_LOCATION_PURPOSE_ID = 4; // Search Room (SR)

  constructor(private http: HttpClient) {}

  /**
   * Search for locations based on form criteria
   * @param formData - Form data containing search criteria
   * @returns Observable with location search results
   */
  getLocations(formData: any): Observable<any> {
    const params = this.buildQueryParams(formData);
    return this.http.get<any>(this.apiUrl, { params });
  }

  /**
   * Build HTTP query parameters from form data
   * @param formData - Form data with search criteria
   * @returns HttpParams object for the request
   */
  private buildQueryParams(formData: any): HttpParams {
    let params = new HttpParams();

    // Add building code (required)
    if (formData.buildingCodeSearch) {
      params = params.set('buildingCode', formData.buildingCodeSearch);
    }

    // Add optional search criteria
    if (formData.floorSearch) {
      params = params.set('floorPrefix', formData.floorSearch);
    } else {
      // Add empty floorPrefix to match API requirement
      params = params.set('floorPrefix', '');
    }

    if (formData.corridorSearch) {
      params = params.set('corridorPrefix', formData.corridorSearch);
    }

    if (formData.suiteSearch) {
      params = params.set('suitePrefix', formData.suiteSearch);
    }

    if (formData.roomSearch) {
      params = params.set('roomPrefix', formData.roomSearch);
    }

    if (formData.zoneSearch) {
      params = params.set('zonePrefix', formData.zoneSearch);
    }

    // Add default parameters
    params = params.set('includeInactive', 'false');

    // Add location purpose ID (default to 4 for Search Room)
    if (formData.purposeSearch && formData.purposeSearch.id) {
      params = params.set('locationPurposeId', formData.purposeSearch.id.toString());
    } else {
      params = params.set('locationPurposeId', this.DEFAULT_LOCATION_PURPOSE_ID.toString());
    }

    return params;
  }
}
