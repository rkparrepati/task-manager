import { Component, EventEmitter, inject, Input, Output, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { LocationService } from './location.service';
import { LocationConfirmation } from './location-confirmation';

@Component({
  selector: 'app-locationselect-dialog',
  templateUrl: './locationselect-dialog.component.html',
  styleUrls: ['./locationselect-dialog.component.scss'],
})
export class LocationselectDialogComponent implements OnInit {
  locationSelect!: FormGroup;

  data: any = inject(MAT_DIALOG_DATA);
  workerLocationButtonText = 'Select mail stop location';
  locations: any[] = [];
  workerLocation = '';
  searchPurpose = '';
  mailStopIndicator = '';
  searchingLocation = false;
  formData: any = {};
  returnMessage = '';
  showLocationMessage = false;
  buildingsList: any[] = [];
  searchResultsCount = 0;

  constructor(
    private dialogRef: MatDialogRef<LocationselectDialogComponent>,
    private organisationService: OrganizationService,
    private locationService: LocationService
  ) {}

  ngOnInit(): void {
    this.getBuildingCodesList();
    this.initializeForm();
  }

  /**
   * Initialize the search form with empty controls
   */
  private initializeForm(): void {
    this.locationSelect = new FormGroup({
      buildingCodeSearch: new FormControl('', Validators.required),
      floorSearch: new FormControl(''),
      corridorSearch: new FormControl(''),
      suiteSearch: new FormControl(''),
      roomSearch: new FormControl(''),
      zoneSearch: new FormControl(''),
    });
  }

  /**
   * Handle building code selection change
   * @param event - Change event from dropdown
   */
  buildingCodeChange(event: any): void {
    this.formData.buildingCodeSearch = event.target.value;
  }

  /**
   * Submit search request with form criteria
   */
  submitSearch(): void {
    if (!this.hasSearchData()) {
      this.showLocationMessage = true;
      this.returnMessage = 'Please enter at least a building code.';
      return;
    }

    // Collect form data
    this.formData.buildingCodeSearch = this.locationSelect.value.buildingCodeSearch;
    this.formData.floorSearch = this.locationSelect.value.floorSearch || '';
    this.formData.corridorSearch = this.locationSelect.value.corridorSearch || '';
    this.formData.suiteSearch = this.locationSelect.value.suiteSearch || '';
    this.formData.roomSearch = this.locationSelect.value.roomSearch || '';
    this.formData.zoneSearch = this.locationSelect.value.zoneSearch || '';

    // Set loading state and fetch locations
    this.searchingLocation = true;
    this.showLocationMessage = false;
    this.locations = [];
    this.getLocationsList();
  }

  /**
   * Fetch locations from API based on form criteria
   */
  private getLocationsList(): void {
    if (this.searchPurpose) {
      this.formData.purposeSearch = this.searchPurpose;
    }

    this.locationService.getLocations(this.formData).subscribe({
      next: (response: any) => {
        this.handleSearchSuccess(response);
      },
      error: (error: any) => {
        this.handleSearchError(error);
      },
    });
  }

  /**
   * Handle successful API response
   * @param response - API response containing location results
   */
  private handleSearchSuccess(response: any): void {
    this.searchingLocation = false;
    this.showLocationMessage = false;

    if (response && response.results && response.results.length > 0) {
      this.locations = response.results;
      this.searchResultsCount = response.meta?.total || response.results.length;
    } else {
      this.locations = [];
      this.searchResultsCount = 0;
      this.showLocationMessage = true;
      this.returnMessage = 'No locations found matching your search criteria.';
    }
  }

  /**
   * Handle API error response
   * @param error - Error object from API call
   */
  private handleSearchError(error: any): void {
    this.searchingLocation = false;
    this.showLocationMessage = true;
    this.locations = [];
    this.searchResultsCount = 0;

    // Provide user-friendly error message
    if (error.status === 400) {
      this.returnMessage = 'Invalid search criteria. Please check your input.';
    } else if (error.status === 401 || error.status === 403) {
      this.returnMessage = 'You do not have permission to search locations.';
    } else if (error.status === 404) {
      this.returnMessage = 'No locations found matching your search criteria.';
    } else if (error.status === 0) {
      this.returnMessage = 'Unable to connect to the server. Please check your connection.';
    } else {
      this.returnMessage = 'An error occurred while searching for locations. Please try again.';
    }
  }

  /**
   * Hide the error/info message
   */
  hideLocationMessage(): void {
    this.showLocationMessage = false;
  }

  /**
   * Handle keyboard events for search (Enter key)
   * @param event - Keyboard event
   */
  searchKeyEventAdvanced(event: any): void {
    if (event.keyCode === 13 && this.hasSearchData()) {
      this.submitSearch();
    }
  }

  /**
   * Confirm location selection and close dialog
   * @param location - Selected location object
   */
  confirm(location: LocationConfirmation): void {
    this.closeThisDialog(location);
  }

  /**
   * Check if search form has required data
   * @returns true if building code is provided
   */
  hasSearchData(): boolean {
    return !!this.formData.buildingCodeSearch;
  }

  /**
   * Close dialog and return result to parent component
   * @param message - Result to return (location object or null)
   */
  closeThisDialog(message: any): void {
    this.dialogRef.close(message);
  }

  /**
   * Fetch building codes list for dropdown
   */
  private getBuildingCodesList(): void {
    this.organisationService.getBuildings().subscribe({
      next: (response: any) => {
        if (response && response.results && response.results.length > 0) {
          this.buildingsList = response.results;
        }
      },
      error: (error: any) => {
        console.error('Error fetching building codes:', error);
        this.buildingsList = [];
      },
    });
  }
}
