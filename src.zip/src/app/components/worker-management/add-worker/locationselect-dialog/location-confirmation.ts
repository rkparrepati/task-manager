export interface LocationPurpose {
  id: number;
  value: string;
  description: string;
}

export interface Site {
  siteId: number;
  siteCode: string;
  siteDescription: string;
  region: string | null;
}

export interface Building {
  buildingFloorId: number;
  floorNumber: string;
  buildingId: number;
  code: string;
  name: string;
  site: Site;
  zip: string;
  city: string;
  addressLine2: string;
  addressLine1: string;
  state: string;
}

export interface Lifecycle {
  beginDate: string;
}

export interface Audit {
  createdDate: string;
  createdUser: number;
  lastModifiedDate: string;
  lastModifiedUser: number;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface LocationConfirmation {
  locationId: number;
  corridorId: string;
  roomId: string;
  suiteId: string;
  zoneId: string | null;
  mailStopIndicator: boolean;
  locationPurpose: LocationPurpose;
  building: Building;
  lifecycle: Lifecycle;
  audit: Audit;
}

export interface LocationSearchResponse {
  meta: {
    total: number;
    skip: number | null;
    limit: number | null;
  };
  results: LocationConfirmation[];
}
