import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { LocationselectDialogComponent } from '../locationselect-dialog/locationselect-dialog.component';
import { AssignmentLocationService } from '../communication-assignment/assignment-location.service';

@Component({
  selector: 'app-assignment-select',
  templateUrl: './assignment-select.component.html',
  styleUrls: ['./assignment-select.component.scss'],
})
export class AssignmentSelectComponent implements OnInit {
  assignments: any = [];
  dialogData: any;
  isLoading: boolean = false;

  constructor(
    private dialogRef: MatDialogRef<LocationselectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private assignmentLocationService: AssignmentLocationService
  ) {
    this.dialogData = data;
  }

  ngOnInit(): void {
    // Load assignments when component initializes
    if (this.dialogData && this.dialogData.workerId) {
      this.loadAssignments(this.dialogData.workerId);
    }
  }

  loadAssignments(workerId: string | number): void {
    this.isLoading = true;
    this.assignmentLocationService.getLocationAssignments(workerId).subscribe(
      (assignmentLocations: any[]) => {
        this.assignments = assignmentLocations || [];
        this.isLoading = false;
      },
      (error: any) => {
        console.error('Error loading assignments:', error);
        this.isLoading = false;
        this.assignments = [];
      }
    );
  }

  confirm(assignment: any) {
    // Return the selected assignment with location data
    this.dialogRef.close({
      assignment: assignment,
      location: assignment.location
    });
  }

  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
}
