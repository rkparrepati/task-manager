import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { WorkerValidationsService } from '../../worker-validations.service';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { map, Observable } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../../../relocation-management/dialog/dialog.component';
import { InactivateWorkerConfirmComponent } from '../inactivate-worker-confirm/inactivate-worker-confirm.component';
import { OrgCodeConfirmationDialogComponent } from '../org-code-confirmation-dialog/org-code-confirmation-dialog.component';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-details-info-tab',
  templateUrl: './details-info-tab.component.html',
  styleUrls: ['./details-info-tab.component.scss'],
})
export class DetailsInfoTabComponent implements OnInit, OnChanges {
  employmentType = 'E';
  workerEmploymentType = 'E';
  userRoles: string[] = [];
  applicationType = 'Worker';
  showContractorInvalid = false;
  showEmployeeInvalid = false;
  showRehireInvalid = false;
  showAgencyTransferInvalid = false;
  showFirmNameInvalid = false;
  private isInitialLoad = true;
  private previousOrgCodeInput: string = ''; // Track previous org code to prevent duplicate dialogs

  // Inactivate worker properties
  invalidInactivateDate: boolean = false;
  inactivateDateErrorMessage: string = '';

  @Input() detailsInfoForm!: FormGroup;
  @Input() referenceData: any = {};
  @Input() workerEmploymentTypeInput: string = 'E';
  @Input() userRolesInput: string[] = [];
  @Input() workerBase: any = {};
  @Input() editAddMode: boolean = false;
  @Input() isContractorAdminEditMode: boolean = false;
  @Output() workerDataUpdated = new EventEmitter<void>();

  public isDisplay = false;
  public firms: any = [];
  public tours: any = [];
  public jobClasses: any = [];
  public phoneBookTitleCodes: any = [];
  public employmentTypes: any = [];
  public grades: any = [];
  public steps: any = [];
  public payPlans: any = [];
  public signatoryAuthorities: any = [];
  public occupationalSeries: any = [];
  public appointmentTypes: any = [];
  public positionSensitivities: any = [];
  public leaveAccruals: any = [];
  public BUSTypes: any = [];
  public auxiliaryRoles: any = [];
  public teleworkPrograms: any = [];
  public titleCodes: any = [];

  constructor(
    private fb: FormBuilder,
    private httpService: HttpService,
    private appService: AppService,
    private validationService: WorkerValidationsService,
    private dialog: MatDialog,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initializeFormControls();
    if (!this.userRoles || this.userRoles.length === 0) {
      this.userRoles = this.appService.getUserData().roles;
    }
    // Set initial values from inputs
    if (this.workerEmploymentTypeInput && this.workerEmploymentTypeInput !== 'E') {
      this.workerEmploymentType = this.workerEmploymentTypeInput;
    }
    if (this.userRolesInput && this.userRolesInput.length > 0) {
      this.userRoles = this.userRolesInput;
    }
    // Set default tour of duty and pay plan if reference data is already available
    if (this.referenceData && Object.keys(this.referenceData).length > 0) {
      this.setDefaultTourOfDutyFromReferenceData();
      this.setDefaultPayPlan();
      this.setDefaultSignatoryAuthority();
    }
    
    // Listen to employment type changes in the form
    this.detailsInfoForm.get('employmentType')?.valueChanges.subscribe((value: string) => {
      this.workerEmploymentType = value;
      this.updateConditionalValidators();
      // CRITICAL FIX: Trigger change detection after updating employment type
      // This ensures template bindings like [disabled]="workerEmploymentType !== 'C'" are re-evaluated
      // and the Firm Name dropdown disabled state is properly reflected in the DOM
      this.cdr.markForCheck();
    });
    
    // Setup listener for position title changes to disable/enable orgCode field
    this.setupPositionTitleListener();
    
    // Mark initial load as complete - do NOT update validators on page load
    this.isInitialLoad = false;
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Re-validate when employment type or roles change (but not on initial load)
    if (changes['workerEmploymentTypeInput'] || changes['userRolesInput']) {
      if (changes['workerEmploymentTypeInput'] && !changes['workerEmploymentTypeInput'].firstChange) {
        this.workerEmploymentType = changes['workerEmploymentTypeInput'].currentValue;

      }
      if (changes['userRolesInput'] && !changes['userRolesInput'].firstChange) {
        this.userRoles = changes['userRolesInput'].currentValue;

      }
      if (this.detailsInfoForm && !this.isInitialLoad) {
        this.updateConditionalValidators();
      }
    }
    
    // Set default tour of duty and pay plan when reference data is loaded
    if (changes['referenceData']) {
      const currentValue = changes['referenceData'].currentValue;
      const previousValue = changes['referenceData'].previousValue;

      // Only process if reference data has actually changed and has content
      if (currentValue && currentValue !== previousValue) {
        if (currentValue.toursOfDuty && currentValue.toursOfDuty.length > 0) {
          this.setDefaultTourOfDutyFromReferenceData();
        }
        
        if (currentValue.payPlans && currentValue.payPlans.length > 0) {
          // Use setTimeout to ensure form is ready
          setTimeout(() => {
            this.setDefaultPayPlan();
          }, 0);
        }
      }
    }

    // When worker base data is loaded, ensure orgCode disabled state is correct
    if (changes['workerBase']) {
      const currentValue = changes['workerBase'].currentValue;
      if (currentValue && !changes['workerBase'].firstChange) {
        // Re-evaluate orgCode disabled state based on position title
        this.updateOrgCodeDisabledState();
      }
    }

    // When detailsInfoForm is initialized with data, set otherFederalAgencyIndicator value
    // This ensures the checkbox reflects the API response value
    if (changes['detailsInfoForm']) {
      const currentForm = changes['detailsInfoForm'].currentValue;
      if (currentForm && !changes['detailsInfoForm'].firstChange) {
        // Delay to ensure form controls are fully initialized
        setTimeout(() => {
          this.initializeAgencyTransferFromFormData();
        }, 0);
      }
    }
  }

  /**
   * Custom validator for org code field
   * Validates that position title is provided when org code field is focused/clicked
   * @param control The form control being validated
   * @returns Validation error object or null
   */
  positionTitleRequiredValidator(control: AbstractControl): ValidationErrors | null {
    // Only validate if org code field has been touched (clicked/focused)
    if (!control.touched) {
      return null;
    }

    // Check if position title is empty
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    if (!positionTitleControl || !positionTitleControl.value || positionTitleControl.value.trim() === '') {
      return { positionTitleRequired: true };
    }

    return null;
  }

  /**
   * Handle position title field interaction
   * Clears org code validation error when position title is focused/clicked
   * Prevents position title from showing required error on focus
   */
  onPositionTitleFocus(): void {
    const orgCodeControl = this.detailsInfoForm.get('orgCode');
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    
    if (orgCodeControl) {
      // Clear the touched state from orgCode to remove its validation error
      orgCodeControl.markAsUntouched();
      // Re-validate org code to clear error
      orgCodeControl.updateValueAndValidity();
    }
    
    if (positionTitleControl) {
      // Mark position title as untouched to prevent showing required error on focus
      // This allows user to interact with the field without seeing validation errors
      positionTitleControl.markAsUntouched();
    }
  }

  /**
   * Handle position title blur event
   * Auto-selects the first matching job class when user clicks away
   * If input matches multiple options, selects the first one
   */
  onPositionTitleBlur(): void {
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    if (!positionTitleControl) {
      return;
    }

    const inputValue = positionTitleControl.value;
    
    // If field is empty, do nothing
    if (!inputValue || inputValue.trim() === '') {
      return;
    }

    // Find all job classes that match the input (partial match)
    const matchingJobClasses = this.referenceData.jobClasses?.filter(
      (jobClass: any) => jobClass.description &&
      jobClass.description.toLowerCase().includes(inputValue.toLowerCase())
    ) || [];

    // If there are matching options, select the first one
    if (matchingJobClasses.length > 0) {
      const firstMatch = matchingJobClasses[0];
      positionTitleControl.setValue(firstMatch.description, { emitEvent: false });
      // Clear any validation errors since we have a valid selection
      if (positionTitleControl.errors?.['positionTitleNotFound']) {
        positionTitleControl.setErrors(null);
      }
    }
  }

  /**
   * Handle position title input change
   * Validates that the entered value matches an available job class
   * Only shows error if user has typed something and there are NO matching options
   * If there are matching options, allow user to select from typeahead
   */
  onPositionTitleChange(): void {
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    if (!positionTitleControl) {
      return;
    }

    const inputValue = positionTitleControl.value;
    
    // If field is empty, clear any validation errors
    if (!inputValue || inputValue.trim() === '') {
      positionTitleControl.setErrors(null);
      return;
    }

    // Check if there are ANY job classes that match the input (partial match for typeahead filtering)
    const matchingJobClasses = this.referenceData.jobClasses?.filter(
      (jobClass: any) => jobClass.description &&
      jobClass.description.toLowerCase().includes(inputValue.toLowerCase())
    ) || [];

    // Only show error if:
    // 1. User has typed something
    // 2. There are NO matching job classes at all (not even partial matches)
    if (matchingJobClasses.length === 0) {
      positionTitleControl.setErrors({ 'positionTitleNotFound': true });
    } else {
      // Clear the error if there are matching options available
      if (positionTitleControl.errors?.['positionTitleNotFound']) {
        positionTitleControl.setErrors(null);
      }
    }
  }

  private initializeFormControls(): void {
    // Employment Type and Indicators - Default to Employee ('E')
    // Initialize with workerEmploymentType to ensure form reflects current state
    this.detailsInfoForm.addControl('employmentType', new FormControl(this.workerEmploymentType, [Validators.required]));
    this.detailsInfoForm.addControl('rehireIndicator', new FormControl(false));
    this.detailsInfoForm.addControl('otherFederalAgencyIndicator', new FormControl(false));
    
    // Setup listener for otherFederalAgencyIndicator to disable it when true
    this.setupAgencyTransferListener();

    // Position and Organization - Position title starts empty, user must select from typeahead
    this.detailsInfoForm.addControl('positionTitle', new FormControl('', [Validators.required]));
    // orgCode starts DISABLED because position title is empty - user must fill position title first
    this.detailsInfoForm.addControl('orgCode', new FormControl({ value: '', disabled: true }, [this.positionTitleRequiredValidator.bind(this)]));
    this.detailsInfoForm.addControl('firmName', new FormControl(''));

    // Grade and Step Information
    this.detailsInfoForm.addControl('grade', new FormControl(''));
    this.detailsInfoForm.addControl('gradeStartDate', new FormControl(''));
    this.detailsInfoForm.addControl('step', new FormControl(''));
    this.detailsInfoForm.addControl('stepStartDate', new FormControl(''));
    this.detailsInfoForm.addControl('payPlan', new FormControl(''));

    // Dates - Leave entrance duty date empty
    this.detailsInfoForm.addControl('entranceDutyDate', new FormControl('', [Validators.required]));
    this.detailsInfoForm.addControl('endOfDutyDate', new FormControl(''));
    this.detailsInfoForm.addControl('accessionDate', new FormControl(''));
    this.detailsInfoForm.addControl('finalJobOfferExtendedDate', new FormControl(''));
    this.detailsInfoForm.addControl('finalJobOfferAcceptedDate', new FormControl(''));

    // Tour and Signatory
    this.detailsInfoForm.addControl('tourDuty', new FormControl('', [Validators.required]));
    this.detailsInfoForm.addControl('signatoryAuthority', new FormControl(''));

    // Telework
    this.detailsInfoForm.addControl('teleworkIndicator', new FormControl(false));
    this.detailsInfoForm.addControl('teleworkProgram', new FormControl(''));

    // Occupational and Title Codes
    this.detailsInfoForm.addControl('occServicesCode', new FormControl(''));
    this.detailsInfoForm.addControl('titleCode', new FormControl(''));

    // Appointment and Position
    this.detailsInfoForm.addControl('typeAppointment', new FormControl('', [Validators.required]));
    this.detailsInfoForm.addControl('positionSensitivity', new FormControl('', [Validators.required]));

    // Leave and Business Unit
    this.detailsInfoForm.addControl('leaveAccrual', new FormControl('', [Validators.required]));
    this.detailsInfoForm.addControl('busCode', new FormControl('', [Validators.required]));

    // Directory and Service Account
    this.detailsInfoForm.addControl('phoneBookTitleCode', new FormControl(''));
    this.detailsInfoForm.addControl('pubOrgDirectory', new FormControl(true));
    this.detailsInfoForm.addControl('publishedAlphabetical', new FormControl(false));
    this.detailsInfoForm.addControl('supervisor', new FormControl(false));
    this.detailsInfoForm.addControl('actingSPE', new FormControl(false));
    // Service account indicator can be true, false, or null (either)
    this.detailsInfoForm.addControl('serviceAccountIndicator', new FormControl(null));

    // Notes
    this.detailsInfoForm.addControl('notes', new FormControl(''));
  }

  /**
   * Update validators for conditional fields based on employment type and roles
   */
  private updateConditionalValidators(): void {
    const conditionalFields = [
      'firmName', 'orgCode', 'grade', 'gradeStartDate', 'step', 'stepStartDate',
      'payPlan', 'accessionDate', 'occServicesCode', 'titleCode', 'typeAppointment',
      'positionSensitivity', 'leaveAccrual', 'busCode'
    ];

    conditionalFields.forEach(fieldName => {
      this.updateFieldValidators(fieldName);
    });

    // Update firmName enable/disable state based on employment type
    this.updateFirmNameState();
  }

  /**
   * Update firmName field enable/disable state based on employment type
   * Contractors (C): enabled and required
   * Non-Contractors (E): disabled and not required
   * On page load, field is always disabled until contractor is explicitly selected
   */
  private updateFirmNameState(): void {
    const firmNameControl = this.detailsInfoForm.get('firmName');
    if (!firmNameControl) {
      return;
    }

    if (this.workerEmploymentType === 'C') {
      // Contractor: Firm name is required and enabled
      firmNameControl.setValidators([Validators.required]);
      firmNameControl.enable();
    } else {
      // Non-Contractor: Firm name is not required and disabled
      firmNameControl.clearValidators();
      firmNameControl.disable();
      firmNameControl.setValue(''); // Clear value when disabled
    }

    firmNameControl.updateValueAndValidity();
  }

  /**
   * Update validators for a specific field
   * @param fieldName Name of the field to update
   */
  private updateFieldValidators(fieldName: string): void {
    const control = this.detailsInfoForm.get(fieldName);
    if (!control) {
      return;
    }

    const validators = this.validationService.getConditionalValidators(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      false // Details info doesn't require secure data access
    );

    control.setValidators(validators);
    control.updateValueAndValidity();
  }

  /**
   * Check if a field should be visible
   * @param fieldName Name of the field
   * @returns True if field should be visible
   */
  isFieldVisible(fieldName: string): boolean {
    return this.validationService.isFieldVisible(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      false // Details info doesn't require secure data access
    );
  }

  /**
   * Get error message for a field
   * @param fieldName Name of the field
   * @returns Error message string
   */
  getErrorMessage(fieldName: string): string {
    const control = this.detailsInfoForm.get(fieldName);
    if (!control || !control.errors) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.validationService.getFieldDisplayName(fieldName)} is required`;
    }

    if (control.errors['positionTitleRequired']) {
      return 'Please provide position title';
    }

    return '';
  }

  setDefaultPayPlan() {
    const payPlansArray = this.referenceData?.payPlans || this.payPlans;
    console.log('setDefaultPayPlan called. payPlansArray:', payPlansArray);
    
    if (payPlansArray && Array.isArray(payPlansArray) && payPlansArray.length > 0) {
      // Check if a value is already set
      const currentValue = this.detailsInfoForm.get('payPlan')?.value;
      if (currentValue) {
        console.log('Pay plan already has value:', currentValue);
        return; // Don't override existing value
      }

      // Log all available pay plans for debugging
      console.log('Available pay plans:', payPlansArray.map((p: any) => ({ id: p.id, description: p.description })));

      // Try to find "General Schedule" pay plan (case-insensitive)
      let defaultPayPlan = payPlansArray.find(
        (payplan: any) => payplan.description && payplan.description.toLowerCase() === 'general schedule'
      );
      
      // If not found, try other common variations
      if (!defaultPayPlan) {
        defaultPayPlan = payPlansArray.find(
          (payplan: any) => payplan.description && payplan.description.toLowerCase().includes('general')
        );
      }
      
      // If still not found, use the first available pay plan
      if (!defaultPayPlan) {
        defaultPayPlan = payPlansArray[0];
        console.warn('General Schedule not found, using first available pay plan');
      }
      
      if (defaultPayPlan) {
        // Convert ID to string to match the dropdown [value] binding
        const payPlanId = String(defaultPayPlan.id);
        this.detailsInfoForm.get('payPlan')?.setValue(payPlanId);
        // Trigger change detection to ensure the dropdown updates
        this.cdr.markForCheck();
        console.log('✓ Default Pay Plan set to:', payPlanId, 'Description:', defaultPayPlan.description);
      }
    } else {
      console.warn('Pay plans array is not available, not an array, or is empty. Array:', payPlansArray);
    }
  }

  setDefaultSignatoryAuthority() {
    this.detailsInfoForm.get('signatoryAuthority')?.setValue('');
  }

  setDefaultTourOfDuty() {

    if (this.tours && Array.isArray(this.tours)) {
      // Try to find "Full-Time" by value 'FT' or by description
      const defaultDuty = this.tours.find((duty: any) =>
        duty.value === 'FT' ||
        duty.description === 'Full-Time' ||
        duty.description?.toLowerCase().includes('full-time') ||
        duty.description?.toLowerCase().includes('full time')
      );
      if (defaultDuty) {

        this.detailsInfoForm.get('tourDuty')?.setValue(defaultDuty.id);

      } else {

      }
    }
  }

  setDefaultTourOfDutyFromReferenceData() {


    if (this.referenceData && this.referenceData.toursOfDuty && Array.isArray(this.referenceData.toursOfDuty)) {
      // Try to find "Full-Time" by value 'FT' or by description
      const defaultDuty = this.referenceData.toursOfDuty.find((duty: any) =>
        duty.value === 'FT' ||
        duty.description === 'Full-Time' ||
        duty.description?.toLowerCase().includes('full-time') ||
        duty.description?.toLowerCase().includes('full time')
      );
      
      const currentValue = this.detailsInfoForm.get('tourDuty')?.value;

      if (defaultDuty && !currentValue) {

        this.detailsInfoForm.get('tourDuty')?.setValue(defaultDuty.id);

      } else if (defaultDuty && currentValue) {

      } else if (!defaultDuty) {

      }
    } else {

    }
  }

  // Unique methods for this component only - Tour of Duties and Phone Book Title Codes
  // These are not called from add-worker.component.ts
  getTourOfDuties() {

    return this.httpService.get('/references/tour-of-duties').subscribe((response: any) => {
      if (response) {
        // Handle both response.results and direct array response
        this.tours = Array.isArray(response) ? response : (response.results || []);

        this.setDefaultTourOfDuty(); // Set default tour of duty after fetching
      }
    }, (error: any) => {

    });
  }

  getPhoneBookTitleCodes() {
    return this.httpService.get('/references/directory-title-types').subscribe((response: any) => {
      if (response) {
        const data = Array.isArray(response) ? response : (response.results || []);
        this.phoneBookTitleCodes = data.sort((a: any, b: any) =>
          a.description.localeCompare(b.description)
        );
      }
    }, (error: any) => {
    });
  }

  getEmploymentTypes() {
    return this.httpService.get('/references/employment-types').subscribe((response: any) => {
      if (response) {
        this.employmentTypes = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getSignatoryAuthorities() {
    return this.httpService.get('/references/signatory-authorities').subscribe((response: any) => {
      if (response) {
        this.signatoryAuthorities = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getAppointmentTypes() {
    return this.httpService.get('/references/appointment-types').subscribe((response: any) => {
      if (response) {
        this.appointmentTypes = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getPositionSensitivities() {
    return this.httpService.get('/references/position-sensitivities').subscribe((response: any) => {
      if (response) {
        this.positionSensitivities = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getLeaveAccruals() {
    return this.httpService.get('/references/leave-accruals').subscribe((response: any) => {
      if (response) {
        this.leaveAccruals = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getBargainUnitTypes() {
    return this.httpService.get('/references/bargain-unit-types').subscribe((response: any) => {
      if (response) {
        this.BUSTypes = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  getAuxiliaryRoles() {
    return this.httpService.get('/references/auxiliary-roles').subscribe((response: any) => {
      if (response) {
        this.auxiliaryRoles = Array.isArray(response) ? response : (response.results || []);
      }
    }, (error: any) => {
    });
  }

  /**
   * Get occupational titles based on selected occupational series
   * @param occupationalSeriesId The ID of the selected occupational series
   */
  getOccupationalTitles(occupationalSeriesId: number) {
    if (!occupationalSeriesId) {
      this.titleCodes = [];
      this.detailsInfoForm.get('titleCode')?.setValue('');
      return;
    }

    const url = `/occupational-series-titles?includeInactive=true&occupationalSeriesId=${occupationalSeriesId}`;
    
    this.httpService.get(url).subscribe(
      (response: any) => {
        if (response) {
          this.titleCodes = Array.isArray(response) ? response : (response.results || []);

        }
      },
      (error: any) => {

        this.titleCodes = [];
      }
    );
  }

  /**
   * Handle OCC Series Code typeahead selection
   * @param event The typeahead match event
   */
  onOccSeriesCodeSelect(event: TypeaheadMatch): void {
    const selectedOccSeries = event.item;
    if (selectedOccSeries && selectedOccSeries.id) {

      // Set the input value to "value - description" format
      const displayValue = `${selectedOccSeries.value} - ${selectedOccSeries.description}`;
      this.detailsInfoForm.get('occServicesCode')?.setValue(displayValue, { emitEvent: false });
      // Clear title code when OCC series changes
      this.detailsInfoForm.get('titleCode')?.setValue('');
      this.titleCodes = [];
      // Load title codes for selected OCC series
      this.getOccupationalTitles(selectedOccSeries.id);
    }
  }

  get filteredOccupationalSeries()  {
    return ((this.referenceData || {}).occupationalSeries || []).map((occSeries: { value: string; description: string; }) => ({
      ...occSeries,
      searchString: `${occSeries.value} ${occSeries.description}`.toLowerCase() 
    })
    );   
  }

  /**
   * Handle OCC Series Code input change
   * When user clears or modifies the input, clear title codes
   */
  onOccSeriesCodeChange(): void {
    const occSeriesValue = this.detailsInfoForm.get('occServicesCode')?.value;
    // If the value is not an object (user is typing), clear title codes
    if (!occSeriesValue || typeof occSeriesValue === 'string') {
      this.titleCodes = [];
      this.detailsInfoForm.get('titleCode')?.setValue('');
    }
  }

  /**
   * Handle Title Code typeahead selection
   * @param event The typeahead match event
   */
  onTitleCodeSelect(event: TypeaheadMatch): void {
    const selectedTitle = event.item;
    if (selectedTitle) {
      // Set the input value to "value - description" format
      const displayValue = `${selectedTitle.value} - ${selectedTitle.description}`;
      this.detailsInfoForm.get('titleCode')?.setValue(displayValue, { emitEvent: false });
    }
  }

  /**
   * Get filtered title codes based on search input
   * Uses contains logic for filtering both value and description fields
   * Adds searchString property combining value and description for typeahead filtering
   * @returns Filtered title codes array with searchString property
   */
  get filteredTitleCodes(): any[] {
    return this.titleCodes.map((title: any) => ({
      ...title,
      searchString: `${title.value} ${title.description}`.toLowerCase()
    }));
  }

  /**
   * Handle Title Code input change
   * When user clears or modifies the input, update the filtered list
   */
  onTitleCodeChange(): void {
    const titleCodeValue = this.detailsInfoForm.get('titleCode')?.value;
    // If the value is not an object (user is typing), keep the filtered list updated
    if (!titleCodeValue || typeof titleCodeValue === 'string') {
      // Trigger change detection to update filtered results
      this.cdr.markForCheck();
    }
  }

  /**
   * Handle Job Class (Position Title) typeahead selection
   
   * @param event The typeahead match event
   */
  onJobClassSelect(event: TypeaheadMatch): void {
    const selectedJobClass = event.item;
    if (selectedJobClass) {
      // Set the description as the display value
      this.detailsInfoForm.get('positionTitle')?.setValue(selectedJobClass.description, { emitEvent: false });
    }
  }

  /**
   * Format OCC Series Code for display in typeahead
   * @param item The occupational series item
   * @returns Formatted string
   */
  formatOccSeriesCode(item: any): string {
    return item ? `${item.value} - ${item.description}` : '';
  }

  /**
   * Format Title Code for display in typeahead
   * @param item The title code item
   * @returns Formatted string
   */
  formatTitleCode(item: any): string {
    return item ? `${item.value} - ${item.description}` : '';
  }

  // Method to get all worker details references in parallel
  // Note: Duplicate methods (getJobClasses, getPayPlans, getGrades, getSteps, getTeleworkPrograms,
  // getOccupationalSeries) have been removed as they are already called from add-worker.component.ts
  getWorkerDetailsReferences() {
    this.getTourOfDuties();
    this.getPhoneBookTitleCodes();
    this.getEmploymentTypes();
    this.getSignatoryAuthorities();
    this.getAppointmentTypes();
    this.getPositionSensitivities();
    this.getLeaveAccruals();
    this.getBargainUnitTypes();
    this.getAuxiliaryRoles();
  }

  /**
   * Validates the end of duty date for worker inactivation
   * @returns true if date is valid, false otherwise
   */
  private validateWorkerInactivateDate(): boolean {
    const endOfDutyDate = this.detailsInfoForm.get('endOfDutyDate')?.value;
    
    if (!endOfDutyDate) {
      return true; // No date provided is valid - will use today's date
    }

    const endDate = new Date(endOfDutyDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);

    // Check if end date is in the future
    if (endDate > today) {
      this.notificationService.showError(
        'End of duty date cannot be in the future. Please enter a valid date.'
      );
      return false;
    }

    // Check if end date is before entrance date
    if (this.workerBase?.entranceOnDutyDate) {
      const entranceDate = new Date(this.workerBase.entranceOnDutyDate);
      entranceDate.setHours(0, 0, 0, 0);
      
      if (endDate < entranceDate) {
        this.notificationService.showError(
          'End of duty date cannot be before entrance on duty date. Please enter a valid date.'
        );
        return false;
      }
    }

    return true;
  }

  /**
   * Formats the inactivation date for display
   * @returns Formatted date string or "today's date"
   */
  private getInactivationDateDisplay(): string {
    const endOfDutyDate = this.detailsInfoForm.get('endOfDutyDate')?.value;
    
    if (!endOfDutyDate) {
      return "today's date";
    }

    const date = new Date(endOfDutyDate);
    return date.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    });
  }

  /**
   * Shows confirmation dialog before inactivating worker
   * Validates date and displays consequences
   */
  confirmInactivate(): void {
    console.log('confirmInactivate() called');
    
    // Check if worker exists and has been saved
    // CRITICAL FIX: Check for workerId (not id) as that's the actual property name
    const workerId = this.workerBase?.workerId || this.workerBase?.id || this.workerBase?.worker?.workerId;
    if (!this.workerBase || !workerId) {
      console.warn('Worker not saved or missing ID', this.workerBase);
      this.notificationService.showError(
        'Worker must be saved before inactivation. Please save the worker first.'
      );
      return;
    }

    console.log('Worker exists:', this.workerBase);

    // Validate the end of duty date
    if (!this.validateWorkerInactivateDate()) {
      console.warn('End of duty date validation failed');
      return;
    }

    console.log('Date validation passed');

    // Check user permissions
    if (!this.userRoles.includes('InfraAdmin') && !this.userRoles.includes('InfraContractorAdmin')) {
      console.warn('User lacks permission. User roles:', this.userRoles);
      this.notificationService.showError(
        'You do not have permission to inactivate workers.'
      );
      return;
    }

    console.log('User has permission. Roles:', this.userRoles);

    // Extract name fields from workerBase.worker (using AngularJS property names: familyName, givenName)
    // Handle both direct properties and nested worker object
    const worker = this.workerBase?.worker || this.workerBase;
    const familyName = worker?.familyName || '';
    const givenName = worker?.givenName || '';
    const middleName = worker?.middleName || '';
    const workerName = `${familyName}${familyName && givenName ? ', ' : ''}${givenName}${middleName ? ' ' + middleName : ''}`.trim();
    const workerNumber = worker?.workerNumber || 'N/A';
    const inactivationDate = this.getInactivationDateDisplay();

    console.log('Worker details:', { workerName, workerNumber, inactivationDate });

    console.log('Opening InactivateWorkerConfirmComponent dialog');

    const dialogRef = this.dialog.open(InactivateWorkerConfirmComponent, {
      width: '600px',
      data: {
        worker: {
          familyName: worker?.familyName || '',
          givenName: worker?.givenName || '',
          middleName: worker?.middleName || '',
          workerNumber: worker?.workerNumber || '',
          lifecycle: worker?.lifecycle || {}
        },
        inactivationDate: inactivationDate
      },
      disableClose: true,
      panelClass: 'inactivate-worker-dialog'
    });

    console.log('Dialog opened');

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog closed with result:', result);
      if (result === true) {
        this.inactivateWorker();
      }
    });
  }

  /**
   * Shows confirmation dialog before activating worker
   */
  confirmActivate(): void {
    // Check user permissions
    if (!this.userRoles.includes('InfraAdmin') && !this.userRoles.includes('InfraContractorAdmin')) {
      this.notificationService.showError(
        'You do not have permission to activate workers.'
      );
      return;
    }

    // Extract name fields from workerBase.worker (using AngularJS property names: familyName, givenName)
    const familyName = this.workerBase?.worker?.familyName || '';
    const givenName = this.workerBase?.worker?.givenName || '';
    const middleName = this.workerBase?.worker?.middleName || '';
    const workerName = `${familyName}${familyName && givenName ? ', ' : ''}${givenName}${middleName ? ' ' + middleName : ''}`.trim();
    const workerNumber = this.workerBase?.worker?.workerNumber || 'N/A';

    const dialogContent = `
      <p>Please confirm that you would like to reactivate the following worker:</p>
      <p><strong>${workerName} (Worker number: ${workerNumber})</strong></p>
    `;

    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Reactivation Confirmation',
        titleType: 'text-success',
        content: dialogContent,
        cancelButton: true,
        primaryButton: 'Reactivate',
        primaryButtonType: 'success'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === true) {
        this.activateWorker();
      }
    });
  }

  /**
   * Formats date to ISO 8601 format with end of day time
   * @param date Date to format
   * @returns Formatted date string
   */
  private adjustEndDateFormatter(date: string | Date): string {
    const d = new Date(date);
    d.setHours(23, 59, 59, 999);
    return d.toISOString();
  }

  /**
   * Inactivates the worker by calling the API
   * Sets activeEmploymentIndicator to false and updates end of duty date
   * Also removes CEDR roles for contractors
   */
  private inactivateWorker(): void {
    if (!this.workerBase?.workerId) {
      this.notificationService.showError('Worker ID is missing. Cannot inactivate worker.');
      return;
    }

    const endOfDutyDate = this.detailsInfoForm.get('endOfDutyDate')?.value || new Date().toISOString().split('T')[0];
    const formattedEndDate = this.adjustEndDateFormatter(endOfDutyDate);
    const lockControlNumber = this.workerBase.audit?.lockControlNumber;

    // Build the complete worker payload
    const workerPayload = {
      ...this.workerBase,
      activeEmploymentIndicator: false,
      lifecycle: {
        ...this.workerBase.lifecycle,
        endDate: formattedEndDate
      },
      // Update organization history end dates
      organizationHistory: this.workerBase.organizationHistory?.map((org: any) => ({
        ...org,
        lifecycle: {
          ...org.lifecycle,
          endDate: formattedEndDate
        },
        locationSummary: org.locationSummary?.map((loc: any) => ({
          ...loc,
          primaryLocationIn: false
        }))
      })),
      // Clear auxiliary roles
      auxiliaryRoleSummary: null
    };

    // Build URL with lockControlNumber
    const url = lockControlNumber
      ? `/workers/${this.workerBase.workerId}?lockControlNumber=${lockControlNumber}`
      : `/workers/${this.workerBase.workerId}`;

    // Step 1: Update worker status
    this.httpService.put(url, workerPayload)
      .subscribe({
        next: (response: any) => {
          // Step 2: Remove CEDR roles if contractor
          if (this.workerEmploymentType === 'C' && this.workerBase.workerNumber) {
            this.removeCEDRRoles(this.workerBase.workerNumber);
          }
          
          const givenName = this.workerBase?.worker?.givenName || '';
          const familyName = this.workerBase?.worker?.familyName || '';
          this.notificationService.showSuccess(
            `Worker ${givenName} ${familyName} has been successfully inactivated.`
          );
          
          // Update local worker base object
          this.workerBase.activeEmploymentIndicator = false;
          this.workerBase.lifecycle = {
            ...this.workerBase.lifecycle,
            endDate: formattedEndDate
          };
          
          // Update form control
          this.detailsInfoForm.patchValue({
            endOfDutyDate: endOfDutyDate
          });
          
          // Step 3: Refresh worker data and trigger change detection
          this.refreshWorkerData();
          
          // Step 4: Reload the page after successful inactivation
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        error: (error: any) => {
          this.notificationService.showError(
            error?.error?.data?.message || error?.error?.message || 'Failed to inactivate worker. Please try again.'
          );
        }
      });
  }

  /**
   * Removes CEDR roles for the worker
   * @param workerNumber Worker number
   */
  private removeCEDRRoles(workerNumber: string): void {
    // Step 1: Get current CEDR roles
    this.httpService.post('/getCERDRoles', [workerNumber])
      .subscribe({
        next: (response: any) => {
          if (response?.data && response.data.length > 0) {
            const userData = response.data[0];
            const patronId = userData.user?.patronId;
            
            if (userData.attributes && userData.attributes.length > 0) {
              userData.attributes.forEach((attr: any) => {
                const roleName = attr.roleName;
                
                // Disable all modifiers
                const disabledModifiers = attr.modifiers?.map((mod: any) => ({
                  modifier: mod.modifier,
                  enabled: false
                })) || [];
                
                // Step 2: Update CEDR roles to disable all
                if (disabledModifiers.length > 0) {
                  this.httpService.post(
                    `/updateCERDRoles/patronId=${patronId}&enterpriseRole=${roleName}`,
                    disabledModifiers
                  ).subscribe({
                    next: () => {
                    },
                    error: (error: any) => {
                    }
                  });
                }
              });
            }
          }
        },
        error: (error: any) => {
        }
      });
  }

  /**
   * Refreshes worker data after activation/inactivation
   * Calls the worker API directly to fetch updated worker data
   * This ensures the activeEmploymentIndicator is updated immediately
   */
  private refreshWorkerData(): void {
    if (!this.workerBase?.workerId) {
      return;
    }

    // Call the worker API directly to get the updated worker data
    this.httpService.get(`/workers/${this.workerBase.workerId}`).subscribe({
      next: (response: any) => {
        // Update the local workerBase with the fresh data from the server
        this.workerBase = response;
        
        // Trigger change detection immediately to update button state
        this.cdr.detectChanges();
        
        // Emit event to parent component to refresh all worker data
        // This ensures the parent's lockControlNumber is updated
        this.workerDataUpdated.emit();
      },
      error: (error: any) => {
        console.error('Error refreshing worker data:', error);
        // Still emit the event even if refresh fails, so parent can attempt to reload
        this.workerDataUpdated.emit();
      }
    });
  }

  /**
   * Activates the worker by calling the API
   * Sets activeEmploymentIndicator to true and clears end of duty date
   */
  private activateWorker(): void {
    if (!this.workerBase?.workerId) {
      this.notificationService.showError('Worker ID is missing. Cannot activate worker.');
      return;
    }

    const lockControlNumber = this.workerBase.audit?.lockControlNumber;

    // Build the complete worker payload
    const workerPayload = {
      ...this.workerBase,
      activeEmploymentIndicator: true,
      lifecycle: {
        ...this.workerBase.lifecycle,
        endDate: null
      },
      // Clear organization history end dates
      organizationHistory: this.workerBase.organizationHistory?.map((org: any) => ({
        ...org,
        lifecycle: {
          ...org.lifecycle,
          endDate: null
        }
      })),
      auxiliaryRoleSummary: null
    };

    // Build URL with lockControlNumber
    const url = lockControlNumber
      ? `/workers/${this.workerBase.workerId}?lockControlNumber=${lockControlNumber}`
      : `/workers/${this.workerBase.workerId}`;

    // Update worker status
    this.httpService.put(url, workerPayload)
      .subscribe({
        next: (response: any) => {
          const givenName = this.workerBase?.worker?.givenName || '';
          const familyName = this.workerBase?.worker?.familyName || '';
          this.notificationService.showSuccess(
            `Worker ${givenName} ${familyName} has been successfully reactivated.`
          );
          
          // Update local worker base object
          this.workerBase.activeEmploymentIndicator = true;
          this.workerBase.lifecycle = {
            ...this.workerBase.lifecycle,
            endDate: null
          };
          
          // Clear form control
          this.detailsInfoForm.patchValue({
            endOfDutyDate: null
          });
          
          // Refresh worker data and trigger change detection
          this.refreshWorkerData();
          
          // Reload the page after successful reactivation
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        },
        error: (error: any) => {
          this.notificationService.showError(
            error?.error?.data?.message || error?.error?.message || 'Failed to activate worker. Please try again.'
          );
        }
      });
  }

  onEntranceDutyDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      entranceDutyDate: date
    });
  }

  onEndOfDutyDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      endOfDutyDate: date
    });
  }

  onAccessionDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      accessionDate: date
    });
  }

  onFinalJobOfferExtendedDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      finalJobOfferExtendedDate: date
    });
  }

  onFinalJobOfferAcceptedDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      finalJobOfferAcceptedDate: date
    });
  }

  onGradeStartDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      gradeStartDate: date
    });
    
    // Auto-populate stepStartDate with the same value
    if (date) {
      this.detailsInfoForm.patchValue({
        stepStartDate: date
      });
    }
  }

  onStepStartDateChange(date: string): void {
    this.detailsInfoForm.patchValue({
      stepStartDate: date
    });
  }

  getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  /**
   * Handle Organization Code blur event
   * Shows confirmation dialog when user leaves the field with a value
   * Implements duplicate dialog prevention using previousOrgCodeInput tracker
   */
  onOrgCodeBlur(): void {
    const orgCodeValue = this.detailsInfoForm.get('orgCode')?.value;
    const positionTitleValue = this.detailsInfoForm.get('positionTitle')?.value;

    // Only show dialog if:
    // 1. Org code has a value
    // 2. Position title has a value
    // 3. This is a NEW value (different from previous input)
    if (orgCodeValue && orgCodeValue.trim() && positionTitleValue && positionTitleValue.trim()) {
      if (this.previousOrgCodeInput !== orgCodeValue.trim()) {
        // Store the new value as previous for next comparison
        this.previousOrgCodeInput = orgCodeValue.trim();
        // CRITICAL FIX: Do NOT clear the field before showing dialog
        // This was causing the field to appear empty when the dialog opened
        // The field will be cleared only if user cancels or confirmation fails
        this.showOrgCodeConfirmationDialog(orgCodeValue.trim());
      }
    }
  }

  /**
   * Handle org code focus event
   * Validates that position title is set before allowing org code entry
   * If position title is empty, prevent focus and show error message
   */
  onOrgCodeFocus(): void {
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    const orgCodeControl = this.detailsInfoForm.get('orgCode');
    
    if (!positionTitleControl || !positionTitleControl.value || positionTitleControl.value.trim() === '') {
      // Position title is not set - ensure org code is disabled
      if (orgCodeControl) {
        orgCodeControl.disable();
        orgCodeControl.markAsUntouched();
        this.cdr.markForCheck();
      }
    } else {
      // Position title is set - ensure org code is enabled
      if (orgCodeControl) {
        orgCodeControl.enable();
        this.cdr.markForCheck();
      }
    }
  }

  /**
   * Update orgCode disabled state based on position title value
   * Called when worker data is loaded to ensure proper initial state
   */
  private updateOrgCodeDisabledState(): void {
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    const orgCodeControl = this.detailsInfoForm.get('orgCode');
    
    if (positionTitleControl && orgCodeControl) {
      if (!positionTitleControl.value || positionTitleControl.value.trim() === '') {
        // Position title is empty - disable orgCode
        orgCodeControl.disable();
        orgCodeControl.setValue('', { emitEvent: false });
      } else {
        // Position title has value - enable orgCode
        orgCodeControl.enable();
      }
      this.cdr.markForCheck();
    }
  }

  /**
   * Listen to position title changes and update orgCode disabled state
   * This ensures orgCode is disabled whenever position title becomes empty
   * Also triggers change detection to update UI bindings
   */
  private setupPositionTitleListener(): void {
    const positionTitleControl = this.detailsInfoForm.get('positionTitle');
    const orgCodeControl = this.detailsInfoForm.get('orgCode');
    
    if (positionTitleControl && orgCodeControl) {
      positionTitleControl.valueChanges.subscribe((value: string) => {
        if (!value || value.trim() === '') {
          // Position title is empty - disable orgCode
          orgCodeControl.disable();
          orgCodeControl.setValue('', { emitEvent: false });
          orgCodeControl.markAsUntouched();
          // Trigger change detection to update UI
          this.cdr.markForCheck();
        } else {
          // Position title has value - enable orgCode
          orgCodeControl.enable();
          // Trigger change detection to update UI
          this.cdr.markForCheck();
        }
      });
    }
  }

  /**
   * Setup listener for Agency Transfer (otherFederalAgencyIndicator)
   * When the checkbox is checked (true), it becomes disabled so user cannot uncheck it
   * This ensures that if the response has Agency Transfer set, user cannot change it
   */
  private setupAgencyTransferListener(): void {
    const agencyTransferControl = this.detailsInfoForm.get('otherFederalAgencyIndicator');
    
    if (agencyTransferControl) {
      agencyTransferControl.valueChanges.subscribe((value: boolean) => {
        if (value === true) {
          // Agency Transfer is checked - disable the checkbox
          agencyTransferControl.disable({ emitEvent: false });
          this.cdr.markForCheck();
        } else {
          // Agency Transfer is unchecked - enable the checkbox
          agencyTransferControl.enable({ emitEvent: false });
          this.cdr.markForCheck();
        }
      });
    }
  }

  /**
   * Initialize Agency Transfer checkbox from form data
   * When form is populated with API response data, this method ensures:
   * 1. The checkbox is set to the correct value from the API
   * 2. If the value is true, the checkbox is disabled so user cannot change it
   * This is called after the form data is patched from the parent component
   */
  private initializeAgencyTransferFromFormData(): void {
    const agencyTransferControl = this.detailsInfoForm.get('otherFederalAgencyIndicator');
    
    if (agencyTransferControl) {
      const currentValue = agencyTransferControl.value;
      
      // If the value is true (from API response), disable the checkbox
      if (currentValue === true) {
        agencyTransferControl.disable({ emitEvent: false });
        this.cdr.markForCheck();
      } else {
        // Otherwise ensure it's enabled
        agencyTransferControl.enable({ emitEvent: false });
        this.cdr.markForCheck();
      }
    }
  }

  /**
   * Display confirmation dialog for PTO Organization Code
   * @param orgCodeValue The organization code value entered by user
   */
  private showOrgCodeConfirmationDialog(orgCodeValue: string): void {
    const dialogRef = this.dialog.open(OrgCodeConfirmationDialogComponent, {
      width: '450px',
      data: { orgCodeValue: orgCodeValue },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.confirmed) {
        const confirmationValue = result.value || '';

        // Validate that the re-typed value matches the original
        if (confirmationValue.trim() === orgCodeValue.trim()) {
          // Values match - confirmation successful
          // Pad org code to exactly 10 characters with zeros
          const formattedOrgCode = this.padOrgCodeToTenCharacters(orgCodeValue.trim());
          // CRITICAL FIX: Ensure the field retains the value after confirmation
          // The field should already have the original value, just format it
          this.detailsInfoForm.get('orgCode')?.setValue(formattedOrgCode, { emitEvent: false });
          
          // Check if this is a trademark position
          this.checkTrademarkPosition(formattedOrgCode);
          
          this.notificationService.showSuccess('Organization Code confirmed successfully.');
        } else {
          // Values don't match - clear the orgCode field and show error
          this.detailsInfoForm.get('orgCode')?.setValue('');
          this.previousOrgCodeInput = '';
          this.notificationService.showError('Organization Code confirmation failed. The values do not match. Please try again.');
        }
      } else {
        // User clicked Cancel - clear the orgCode field and reset tracker
        this.detailsInfoForm.get('orgCode')?.setValue('');
        this.previousOrgCodeInput = '';
      }
    });
  }

  /**
   * Pad organization code to exactly 10 characters with zeros
   * Example: "123" becomes "1230000000"
   * @param orgCode The organization code to pad
   * @returns Padded organization code
   */
  private padOrgCodeToTenCharacters(orgCode: string): string {
    if (orgCode.length >= 10) {
      return orgCode.substring(0, 10);
    }
    const zerosNeeded = 10 - orgCode.length;
    return orgCode + '0'.repeat(zerosNeeded);
  }

  /**
   * Check if the organization code is a trademark position
   * Makes HTTP call to position-org-tx endpoint
   * @param orgCode The padded organization code
   */
  private checkTrademarkPosition(orgCode: string): void {
    this.httpService.get(`/position-org-tx/${orgCode}`).subscribe(
      (response: any) => {
        if (response && response.data) {
          // Trademark position found - show trademark confirmation dialog
          this.showTrademarkWorkerConfirmationDialog();
        } else {
          // Check if position title contains "Trade" - if so, show error
          const positionTitle = this.detailsInfoForm.get('positionTitle')?.value || '';
          if (positionTitle && positionTitle.indexOf('Trade') >= 0) {
            this.notificationService.showError('Please Enter valid trademark Org code');
          }
        }
      },
      (error: any) => {
        // Error checking trademark - log but don't block user
      }
    );
  }

  /**
   * Show trademark worker confirmation dialog
   * User must confirm they want to proceed with a trademark position
   */
  private showTrademarkWorkerConfirmationDialog(): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Trademark Position Confirmation',
        titleType: 'text-warning',
        content: 'This organization code is associated with a trademark position. Do you want to proceed?',
        cancelButton: true,
        primaryButton: 'Yes',
        primaryButtonType: 'warning'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result !== true) {
        // User declined - clear the org code field
        this.detailsInfoForm.get('orgCode')?.setValue('');
        this.previousOrgCodeInput = '';
      }
    });
  }

  /**
   * Handle firm name dropdown click event
   * Prevents dropdown from opening when worker employment type is not Contractor
   * @param event The click event
   */
  onFirmNameClick(event: MouseEvent): void {
    // If employment type is not Contractor, prevent the dropdown from opening
    if (this.workerEmploymentType !== 'C') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }

  /**
   * Handle firm name dropdown mousedown event
   * Prevents dropdown from opening when worker employment type is not Contractor
   * @param event The mousedown event
   */
  onFirmNameMouseDown(event: MouseEvent): void {
    // If employment type is not Contractor, prevent the dropdown from opening
    if (this.workerEmploymentType !== 'C') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }

  /**
   * Handle firm name dropdown keydown event
   * Prevents dropdown from opening when worker employment type is not Contractor
   * @param event The keydown event
   */
  onFirmNameKeyDown(event: KeyboardEvent): void {
    // If employment type is not Contractor, prevent keyboard interaction
    if (this.workerEmploymentType !== 'C') {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }

  /**
   * Handle inactivate date change
   * Updates the worker's lifecycle end date
   * @param event The date change event
   */
  onInactivateDateChange(event: any): void {
    if (event) {
      // Handle both nested (workerBase.worker.lifecycle) and flat (workerBase.lifecycle) structures
      if (this.workerBase?.worker?.lifecycle) {
        this.workerBase.worker.lifecycle.endDate = event;
      } else if (this.workerBase?.lifecycle) {
        this.workerBase.lifecycle.endDate = event;
      } else if (this.workerBase?.worker) {
        // Create lifecycle object if it doesn't exist
        if (!this.workerBase.worker.lifecycle) {
          this.workerBase.worker.lifecycle = {};
        }
        this.workerBase.worker.lifecycle.endDate = event;
      } else if (this.workerBase) {
        // Create lifecycle object if it doesn't exist
        if (!this.workerBase.lifecycle) {
          this.workerBase.lifecycle = {};
        }
        this.workerBase.lifecycle.endDate = event;
      }
      this.invalidInactivateDate = false;
      this.inactivateDateErrorMessage = '';
    }
  }

  /**
   * Check if worker number starts with 'C'
   * Used to hide inactivate section for contractor workers
   * @returns true if worker number starts with 'C', false otherwise
   */
  isWorkerNumberStartsWithC(): boolean {
    const workerNumber = this.workerBase?.worker?.workerNumber || this.workerBase?.workerNumber || '';
    return workerNumber.toString().startsWith('C');
  }

  /**
   * Check if worker is currently active
   * Used to determine which button to show (Inactivate or Activate)
   * @returns true if worker is active, false if inactive
   */
  isWorkerActive(): boolean {
    // If activeEmploymentIndicator is explicitly false, worker is inactive
    // Otherwise, worker is considered active
    return this.workerBase?.activeEmploymentIndicator !== false;
  }

  /**
   * Check if worker is a contractor
   * Used to hide Acting SPE checkbox for contractor workers
   * @returns true if worker employment type is 'C' (Contractor), false otherwise
   */
  isContractor(): boolean {
    return this.workerEmploymentType === 'C';
  }

  /**
   * Get the display text for service account indicator
   * true = "Yes", false = "No", null = either "Yes" or "No"
   * @returns Display text for the service account indicator
   */
  getServiceAccountDisplayText(): string {
    const value = this.detailsInfoForm.get('serviceAccountIndicator')?.value;
    
    if (value === true) {
      return 'Yes';
    } else if (value === false) {
      return 'No';
    } else {
      // null - can be either
      return 'Not Set';
    }
  }

  /**
   * Check if service account indicator is set to a specific value
   * @param value The value to check (true, false, or null)
   * @returns true if the current value matches the provided value
   */
  isServiceAccountValue(value: boolean | null): boolean {
    const currentValue = this.detailsInfoForm.get('serviceAccountIndicator')?.value;
    return currentValue === value;
  }

  /**
   * Check if service account section should be hidden
   * Hide service account section when editing a contractor as InfraContractorAdmin
   * @returns true if service account section should be hidden
   */
  shouldHideServiceAccountSection(): boolean {
    return this.isContractorAdminEditMode;
  }
}
