import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { OnInit } from '@angular/core';

@Component({
  selector: 'app-inactivate-worker-confirm',
  templateUrl: './inactivate-worker-confirm.component.html',
  styleUrls: ['./inactivate-worker-confirm.component.scss'],
})
export class InactivateWorkerConfirmComponent implements OnInit {
  data: any = inject(MAT_DIALOG_DATA);
  
  constructor(private dialogRef: MatDialogRef<InactivateWorkerConfirmComponent>) {}

  ngOnInit() {
    // Initialize any required data
  }

  /**
   * Confirm inactivation and close dialog with true result
   */
  confirm(result: boolean = true): void {
    this.dialogRef.close(result);
  }
  
  /**
   * Cancel inactivation and close dialog with false result
   * @param message Optional message to log
   */
  closeThisDialog(message?: string): void {
    if (message) {
      console.log(message);
    }
    this.dialogRef.close(false);
  }
}
