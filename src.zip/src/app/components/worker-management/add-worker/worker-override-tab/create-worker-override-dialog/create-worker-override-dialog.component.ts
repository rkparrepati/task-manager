import { Component, Inject, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { WorkerManagementService } from '../../../worker-management.service';
import { OrganizationService } from '../../../../../shared/services/organizations.services';
import { HttpService } from '../../../../../services/http.service';
import { DatePipe } from '@angular/common';
import { Observable, of } from 'rxjs';

interface OverrideProperty {
  propertyId?: string;
  stndWorkerOverridePropertyId?: string;
  propertyName: string;
  originalValue: string;
  overrideValue: any;
  endEffectiveDate?: string | null;
  selectedProperty?: any;
  noResults?: boolean;
  invalid?: boolean;
  isDatepickerOpen?: boolean;
  acronymValidationError?: string;
  selectedOccCode?: any;
  selectedTitleCode?: any;
  selectedPositionTitle?: any;
  selectedSignatoryAuthority?: any;
  acronymValidationTimer?: any;
  occCodeFilter?: Observable<any[]>;
  titleCodeFilter?: Observable<any[]>;
  positionTitleFilter?: Observable<any[]>;
  occCodeInput?: string;
  titleCodeInput?: string;
  positionTitleInput?: string;
  propertyErrors?: string[]; // Individual property-level errors
  typeaheadError?: string; // Error for typeahead fields (code not found)
  showOccCodeDropdown?: boolean; // Control OCC code dropdown visibility
  showTitleCodeDropdown?: boolean; // Control Title code dropdown visibility
  showPositionTitleDropdown?: boolean; // Control Position title dropdown visibility
}

@Component({
  selector: 'app-create-worker-override-dialog',
  templateUrl: './create-worker-override-dialog.component.html',
  styleUrls: ['./create-worker-override-dialog.component.scss']
})
export class CreateWorkerOverrideDialogComponent implements OnInit {
  overrideProperties: OverrideProperty[] = [];
  overrideStartDate: Date | null = null;
  overrideEndDate: Date | null = null;
  invalidOverrideStartDate: string = '';
  invalidOverrideEndDate: string = '';
  startDateRequired: boolean = false;
  endDateRequired: boolean = false;
  isOverrideStartDateOpen: boolean = false;
  isOverrideEndDateOpen: boolean = false;
  maxEndDateFromStartDate: Date | undefined = undefined;
  todayDate: Date = new Date();
  formErrorMessage: string = '';
  validationErrors: string[] = [];
  validationBooleans: any = {};
  showValidationErrors: boolean = false;
  workerBase: any = {
    worker: {},
    references: {
      grades: [],
      steps: [],
      payplans: [],
      tourOfDuties: [],
      examSigs: [],
      posSensCodes: [],
      leaveAccruals: [],
      appointmentTypes: [],
      occCodes: [],
      busCodes: [],
      jobClasses: [],
      titleCodes: [],
      availableWorkerRoles: []
    },
    organizations: [],
    workerAssignments: [],
    workerRoles: []
  };
  selectedItemId: number | null = null;
  overrideEditMode: boolean = false;
  propertyList: any[] = [];
  endDatePickerConfig: any = {};
  duplicateDatePairError: string = '';
  orgOccSeries: string = '';
  orgOccTitle: string = '';
  orgSignAuthority: string = '';
  orgGrade: string = '';
  orgGradeStartDate: string = '';
  orgStep: string = '';
  orgStepStartDate: string = '';
  orgPriAcronym: string = '';
  orgSecAcronym: string = '';
  orgPositionTitle: string = '';
  orgSupervisor: string = '';
  orgWorkerRoles: string = '';

  constructor(
    public dialogRef: MatDialogRef<CreateWorkerOverrideDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private workerManagementService: WorkerManagementService,
    private organizationService: OrganizationService,
    private httpService: HttpService,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef
  ) {
    this.todayDate.setHours(0, 0, 0, 0);
  }

  public closeThisDialog(data: any): void {
    this.dialogRef.close(data);
  }

  /**
   * Initialize worker base details from dialog data
   */
  private initializeWorkerBaseDetails(): void {
    console.log("called")
    if (this.data && this.data.workerBaseDetails) {
      this.workerBase.worker = this.data.workerBaseDetails.worker || {};
      this.workerBase.organizations = this.data.workerBaseDetails.organizations || [];
      this.workerBase.workerAssignments = this.data.workerBaseDetails.workerAssignments || [];
      this.workerBase.workerRoles = this.data.workerBaseDetails.workerRoles || [];
    }
    
    // Set original values from worker data
    this.setOriginalValuesFromWorker();
  }

  /**
   * Set original values from worker data for display
   */
  private setOriginalValuesFromWorker(): void {
    console.log("here")
    const worker = this.workerBase.worker;
    console.log("worker",worker);
    this.orgOccSeries = worker.occupationalSeries
      ? worker.occupationalSeries.value + ' - ' + worker.occupationalSeries.description
      : '';
    
    this.orgOccTitle = worker.occupationalSeriesTitle
      ? worker.occupationalSeriesTitle.value + ' - ' + worker.occupationalSeriesTitle.description
      : '';
    
    this.orgSignAuthority = worker.signatoryAuthority?.description || '';
    // Grade and Step are nested in payPlan object
    this.orgGrade = worker.payPlan?.currentGrade?.value || '';
    // Grade start date is in payPlan.gradeLifecycle.beginDate - format as MM/dd/yyyy
    this.orgGradeStartDate = worker.payPlan?.gradeLifecycle?.beginDate
      ? this.datePipe.transform(worker.payPlan.gradeLifecycle.beginDate, 'MM/dd/yyyy', 'UTC') || ''
      : '';
    this.orgStep = worker.payPlan?.currentStep?.value || '';
    // Step start date is in payPlan.stepLifecycle.beginDate - format as MM/dd/yyyy
    this.orgStepStartDate = worker.payPlan?.stepLifecycle?.beginDate
      ? this.datePipe.transform(worker.payPlan.stepLifecycle.beginDate, 'MM/dd/yyyy', 'UTC') || ''
      : '';
    this.orgPositionTitle = worker.jobClass
      ? worker.jobClass.value + ' - ' + worker.jobClass.description
      : '';
    
    this.orgSupervisor = worker.supervisorIndicator !== null && worker.supervisorIndicator !== undefined
      ? (worker.supervisorIndicator ? 'Yes' : 'No')
      : '';
    
    // Set primary organization acronym - try workerAssignments first, then organizations
    if (this.workerBase.workerAssignments && this.workerBase.workerAssignments[0] &&
        this.workerBase.workerAssignments[0].workerOrganization &&
        this.workerBase.workerAssignments[0].workerOrganization.organization) {
      const org = this.workerBase.workerAssignments[0].workerOrganization.organization;
      this.orgPriAcronym = org.businessAreaCode + '/' + org.shortName;
    } else if (this.workerBase.organizations && this.workerBase.organizations[0] &&
               this.workerBase.organizations[0].organization) {
      const org = this.workerBase.organizations[0].organization;
      this.orgPriAcronym = org.businessAreaCode + '/' + org.shortName;
    }
    
    // Set secondary organization acronym - try workerAssignments first, then organizations
    if (this.workerBase.workerAssignments && this.workerBase.workerAssignments[1] &&
        this.workerBase.workerAssignments[1].workerOrganization &&
        this.workerBase.workerAssignments[1].workerOrganization.organization) {
      const org = this.workerBase.workerAssignments[1].workerOrganization.organization;
      this.orgSecAcronym = org.businessAreaCode + '/' + org.shortName;
    } else if (this.workerBase.organizations && this.workerBase.organizations[1] &&
               this.workerBase.organizations[1].organization) {
      const org = this.workerBase.organizations[1].organization;
      this.orgSecAcronym = org.businessAreaCode + '/' + org.shortName;
    }
    
    // Set worker roles - matching legacy implementation
    // Extract reportRole.description from each role and join with commas
    // prop.originalValue = vm.orgWorkerRoles;
    if (this.workerBase.workerRoles && this.workerBase.workerRoles.length > 0) {
      const roleDescriptions = this.workerBase.workerRoles
        .map((role: any) => role.reportRole ? role.reportRole.description : '')
        .filter((desc: string) => desc)
        .join(', ');
      this.orgWorkerRoles = roleDescriptions || '';
    } else {
      this.orgWorkerRoles = '';
    }
  }

  ngOnInit(): void {
    // Initialize worker base details from dialog data FIRST
    // This ensures workerRoles and other data are available before other operations
    console.log('constructor')
    this.initializeWorkerBaseDetails();

    // Load override properties from service
    this.loadOverrideProperties();
    this.loadWorkerReferences();
    this.getAvailableWorkerRoles();
    
    // Initialize originalValue for any existing override properties
    if (this.overrideProperties && this.overrideProperties.length > 0) {
      this.overrideProperties.forEach((prop) => {
        if (prop.selectedProperty) {
          this.setOriginalValue(prop);
        }
        // Initialize propertyErrors if not already initialized
        if (!prop.propertyErrors) {
          prop.propertyErrors = [];
        }
        if (!prop.typeaheadError) {
          prop.typeaheadError = '';
        }
      });
    }
    
    // Watch for Grade Start Date (ID 5) changes and auto-populate Step Start Date (ID 7)
    // This matches the legacy behavior (createWorkerOverrideDialogController.js lines 1325-1343)
    this.setupGradeStartDateWatcher();
  }

  /**
   * Watch for Grade Start Date (ID 5) changes and auto-populate Step Start Date (ID 7)
   * Matches legacy behavior from createWorkerOverrideDialogController.js lines 1325-1343
   */
  private setupGradeStartDateWatcher(): void {
    // Use a simple approach: watch the overrideProperties array for changes
    // When Grade Start Date (ID 5) changes, update Step Start Date (ID 7)
    const watchInterval = setInterval(() => {
      if (!this.overrideProperties || this.overrideProperties.length === 0) {
        return;
      }
      
      // Find Grade Start Date property (ID 5)
      const gradeStartDateProp = this.getPropertyById(5);
      if (!gradeStartDateProp || !gradeStartDateProp.overrideValue) {
        return;
      }
      
      // Find Step Start Date property (ID 7)
      const stepStartDateProp = this.getPropertyById(7);
      if (!stepStartDateProp) {
        return;
      }
      
      // If Step Start Date is empty and Grade Start Date has a value, auto-populate it
      if ((!stepStartDateProp.overrideValue || stepStartDateProp.overrideValue === null || stepStartDateProp.overrideValue === undefined) &&
          gradeStartDateProp.overrideValue) {
        stepStartDateProp.overrideValue = gradeStartDateProp.overrideValue;
      }
    }, 100); // Check every 100ms
    
    // Store interval ID for cleanup if needed
    (this as any).gradeStartDateWatcherInterval = watchInterval;
  }

  /**
   * Recursively flatten nested arrays until we get to the actual data
   */
  private flattenArray(arr: any[]): any[] {
    if (!Array.isArray(arr) || arr.length === 0) {
      return arr;
    }

    // If first element is an array, flatten it
    if (Array.isArray(arr[0])) {
      return this.flattenArray(arr[0]);
    }

    // If first element is an object with properties, we've reached the data
    if (typeof arr[0] === 'object' && arr[0] !== null) {
      return arr;
    }

    return arr;
  }

  /**
   * Load override properties from service
   */
  private loadOverrideProperties(): void {
    this.workerManagementService.getOverrideProperties().subscribe(
      (response: any) => {
        // Handle different response structures
        let data: any[] = [];
        
        console.log('Raw API response:', response);
        console.log('Response type:', typeof response);
        console.log('Is array:', Array.isArray(response));
        
        if (Array.isArray(response)) {
          // Use recursive flattening to handle any level of nesting
          data = this.flattenArray(response);
        } else if (response && Array.isArray(response.results)) {
          data = response.results;
        } else if (response && Array.isArray(response.data)) {
          data = response.data;
        } else if (response && Array.isArray(response.properties)) {
          // Handle response with properties array (e.g., {count: 12, properties: [...]})
          data = response.properties;
        } else if (response && typeof response === 'object') {
          // If response is an object with properties, try to extract array
          const values = Object.values(response).filter(item => Array.isArray(item));
          data = values.length > 0 ? (values[0] as any[]) : [];
        }
        
        // Ensure data is always an array
        if (!Array.isArray(data)) {
          data = [];
        }
        
        this.propertyList = data;
        console.log('Override properties loaded:', this.propertyList);
        console.log('Property list length:', this.propertyList.length);
        console.log('First property:', this.propertyList.length > 0 ? this.propertyList[0] : 'No properties');
        
        // Initialize propertyErrors for all existing override properties
        if (this.overrideProperties && this.overrideProperties.length > 0) {
          this.overrideProperties.forEach((prop) => {
            if (!prop.propertyErrors) {
              prop.propertyErrors = [];
            }
            if (!prop.typeaheadError) {
              prop.typeaheadError = '';
            }
          });
        }
        
        // Trigger change detection to update the view
        this.cdr.detectChanges();
      },
      (error: any) => {
        console.error('Error loading override properties:', error);
        this.propertyList = [];
        this.cdr.detectChanges();
      }
    );
  }

  /**
   * Load worker references for dropdowns
   */
  private loadWorkerReferences(): void {
    // Always load fresh references when called from onPropertyChange
    this.workerManagementService.getWorkerDetailsReferences().subscribe(
      (response: any) => {
        console.log('Worker references loaded:', response);
        this.workerBase.references = {
          grades: response.grades?.results || response.grades || [],
          steps: response.steps?.results || response.steps || [],
          payPlans: response.payPlans?.results || response.payPlans || [],
          tourOfDuties: response.tourOfDuties?.results || response.tourOfDuties || [],
          examSigs: response.examSigs?.results || response.examSigs || [],
          posSensCodes: response.posSensCodes?.results || response.posSensCodes || [],
          leaveAccruals: response.leaveAccruals?.results || response.leaveAccruals || [],
          appointmentTypes: response.appointmentTypes?.results || response.appointmentTypes || [],
          occCodes: response.occCodes?.results || response.occCodes || [],
          busCodes: response.busCodes?.results || response.busCodes || [],
          jobClasses: response.jobClasses?.results || response.jobClasses || [],
          titleCodes: response.titleCodes?.results || response.titleCodes || [],
          availableWorkerRoles: this.workerBase.references?.availableWorkerRoles || []
        };
        this.cdr.detectChanges();
      },
      (error: any) => {
        console.warn('Warning loading worker references:', error);
        // Don't throw error, just use empty arrays
        this.cdr.detectChanges();
      }
    );
  }

  /**
   * Update references and trigger change detection
   * Called by parent component after updating workerBase with API data
   */
  updateReferences(): void {
    this.cdr.detectChanges();
  }

  /**
   * Add a new property row
   */
  addRow(): void {
    this.overrideProperties.push({
      propertyName: '',
      originalValue: '',
      overrideValue: '',
      selectedProperty: null,
      noResults: false,
      invalid: false,
      isDatepickerOpen: false,
      acronymValidationError: '',
      occCodeInput: '',
      titleCodeInput: '',
      positionTitleInput: '',
      occCodeFilter: of([]),
      titleCodeFilter: of([]),
      positionTitleFilter: of([]),
      propertyErrors: [],
      typeaheadError: ''
    });
    // Trigger change detection to display the new row
    this.cdr.detectChanges();
  }

  /**
   * Filter OCC codes for typeahead
   */
  filterOccCodes(prop: OverrideProperty, searchValue: string): void {
    console.log('filterOccCodes called with:', searchValue);
    
    if (!searchValue || searchValue.length === 0) {
      prop.occCodeFilter = of([]);
      return;
    }

    // Get the data from workerBase.references or from the passed data
    let occCodes = this.workerBase?.references?.occCodes || [];
    
    // If no data in references, try to get from the initial data passed to dialog
    if (occCodes.length === 0 && this.data?.workerBase?.references?.occCodes) {
      occCodes = this.data.workerBase.references.occCodes;
    }

    console.log('Available OCC codes:', occCodes.length);
    
    const filtered = occCodes.filter((code: any) =>
      (code.value + ' - ' + code.description).toLowerCase().includes(searchValue.toLowerCase())
    ).slice(0, 25); // Limit to 25 results like legacy

    console.log('Filtered OCC codes:', filtered.length);
    
    prop.occCodeFilter = of(filtered);
    this.cdr.detectChanges();
  }

  /**
   * Filter title codes for typeahead
   */
  filterTitleCodes(prop: OverrideProperty, searchValue: string): void {
    console.log('filterTitleCodes called with:', searchValue);
    
    if (!searchValue || searchValue.length === 0) {
      prop.titleCodeFilter = of([]);
      return;
    }

    // Get the data from workerBase.references or from the passed data
    let titleCodes = this.workerBase?.references?.titleCodes || [];
    
    // If no data in references, try to get from the initial data passed to dialog
    if (titleCodes.length === 0 && this.data?.workerBase?.references?.titleCodes) {
      titleCodes = this.data.workerBase.references.titleCodes;
    }

    console.log('Available title codes:', titleCodes.length);
    
    const filtered = titleCodes.filter((code: any) =>
      (code.value + ' - ' + code.description).toLowerCase().includes(searchValue.toLowerCase())
    ).slice(0, 25); // Limit to 25 results like legacy

    console.log('Filtered title codes:', filtered.length);
    
    prop.titleCodeFilter = of(filtered);
    this.cdr.detectChanges();
  }

  /**
   * Filter position titles for typeahead
   */
  filterPositionTitles(prop: OverrideProperty, searchValue: string): void {
    console.log('filterPositionTitles called with:', searchValue);
    
    if (!searchValue || searchValue.length === 0) {
      prop.positionTitleFilter = of([]);
      return;
    }

    // Get the data from workerBase.references or from the passed data
    let jobClasses = this.workerBase?.references?.jobClasses || [];
    
    // If no data in references, try to get from the initial data passed to dialog
    if (jobClasses.length === 0 && this.data?.workerBase?.references?.jobClasses) {
      jobClasses = this.data.workerBase.references.jobClasses;
    }

    console.log('Available job classes:', jobClasses.length);
    
    const filtered = jobClasses.filter((jobClass: any) =>
      (jobClass.value + ' - ' + jobClass.description).toLowerCase().includes(searchValue.toLowerCase())
    ).slice(0, 25); // Limit to 25 results like legacy

    console.log('Filtered job classes:', filtered.length);
    
    prop.positionTitleFilter = of(filtered);
    this.cdr.detectChanges();
  }

  /**
   * Reset a property row
   */
  resetOverride(index: number): void {
    if (index >= 0 && index < this.overrideProperties.length) {
      this.overrideProperties[index] = {
        propertyName: '',
        originalValue: '',
        overrideValue: '',
        selectedProperty: null,
        noResults: false,
        invalid: false,
        isDatepickerOpen: false,
        acronymValidationError: '',
        occCodeInput: '',
        titleCodeInput: '',
        positionTitleInput: '',
        propertyErrors: [],
        typeaheadError: ''
      };
      // Re-validate dependencies after reset
      this.validatePropertyDependencies();
    }
  }
  overrideReset():void{
    // Clear only the input fields, not the override properties themselves
    this.overrideProperties.forEach((prop) => {
      prop.overrideValue = '';
      prop.propertyErrors = [];
      prop.invalid = false;
      prop.typeaheadError = '';
      prop.acronymValidationError = '';
      prop.occCodeInput = '';
      prop.titleCodeInput = '';
      prop.positionTitleInput = '';
    });
    
    // Reset dates
    this.overrideStartDate = null;
    this.overrideEndDate = null;
    this.invalidOverrideStartDate = '';
    this.invalidOverrideEndDate = '';
    this.startDateRequired = false;
    this.endDateRequired = false;
    this.isOverrideStartDateOpen = false;
    this.isOverrideEndDateOpen = false;
    this.maxEndDateFromStartDate = undefined;
    
    // Re-validate dependencies after reset
    this.validatePropertyDependencies();
    
    // Trigger change detection to update the view
    this.cdr.detectChanges();
  }

  /**
   * Remove a property row
   */
  removeRow(index: number): void {
    if (index >= 0 && index < this.overrideProperties.length) {
      this.overrideProperties.splice(index, 1);
      // Validate dependencies after removing row
      this.validatePropertyDependencies();
      this.cdr.detectChanges();
    }
  }

  /**
   * Handle property change - load references and set original values
   * NOTE: Validation is NOT called here because the user hasn't entered a value yet.
   * Validation only happens in onPropertyValueChange() after the user enters/selects a value.
   * This matches the legacy AngularJS behavior (lines 673-761 of createWorkerOverrideDialogController.js)
   */
  onPropertyChange(prop: OverrideProperty): void {
    console.log('=== onPropertyChange called ===');
    console.log('Selected property:', prop.selectedProperty);
    
    if (prop.selectedProperty) {
      this.selectedItemId = prop.selectedProperty.stndWorkerOverridePropertyId;
      console.log('Selected property ID:', this.selectedItemId);
      
      // Clear any previous errors when property is changed
      if (!prop.propertyErrors) {
        prop.propertyErrors = [];
      } else {
        prop.propertyErrors = [];
      }
      
      // Clear validation errors from main container when property is changed
      if (this.validationErrors && this.validationErrors.length > 0) {
        this.validationErrors = this.validationErrors.filter((error) => {
          // Remove dependency errors (OCC/Title, Grade/Step dependencies)
          if (error.indexOf('Add override properties for') === 0) {
            console.log('Removing validation error on property change:', error);
            return false;
          }
          return true;
        });
        
        // Hide validation errors if none remain
        if (this.validationErrors.length === 0) {
          this.showValidationErrors = false;
        }
      }
      
      // Load worker references to populate dependent dropdowns
      this.loadWorkerReferences();
      
      // Set original value based on property ID
      this.setOriginalValue(prop);
      
      // Load occupational titles if needed
      if (this.workerBase.worker.occupationalSeries && this.workerBase.worker.occupationalSeries.id) {
        this.getOccupationalTitle(this.workerBase.worker.occupationalSeries.id);
      }
      
      // Fetch available worker roles when property 12 (Assigned Worker Roles) is selected
      if (prop.selectedProperty.stndWorkerOverridePropertyId === 12) {
        this.getAvailableWorkerRoles();
      }
      
      // Auto-populate Step Start Date (ID 7) with Grade Start Date (ID 5) value if Grade Start Date is set
      // This matches the legacy behavior (createWorkerOverrideDialogController.js lines 1325-1343)
      if (prop.selectedProperty.stndWorkerOverridePropertyId === 7) {
        const gradeStartDateProp = this.getPropertyById(5);
        if (gradeStartDateProp && gradeStartDateProp.overrideValue) {
          prop.overrideValue = gradeStartDateProp.overrideValue;
        }
      }
      
      // Trigger change detection to display current value immediately
      this.cdr.detectChanges();
    }
  }

  /**
   * Set original value based on selected property
   */
  private setOriginalValue(prop: OverrideProperty): void {
    if (!prop.selectedProperty) {
      return;
    }

    const propertyId = prop.selectedProperty.stndWorkerOverridePropertyId;
    const worker = this.workerBase.worker;

    // Map property IDs to worker properties - matching legacy template mapping
    switch (propertyId) {
      case 1: // Occupational Series Code
        prop.originalValue = worker.occupationalSeries
          ? worker.occupationalSeries.value + ' - ' + worker.occupationalSeries.description
          : '';
        break;
      case 2: // Title Code
        prop.originalValue = worker.occupationalSeriesTitle
          ? worker.occupationalSeriesTitle.value + ' - ' + worker.occupationalSeriesTitle.description
          : '';
        break;
      case 3: // Signatory Authority
        prop.originalValue = worker.signatoryAuthority?.description || '';
        break;
      case 4: // Grade
        // Use the pre-calculated orgGrade value (already set in setOriginalValuesFromWorker)
        prop.originalValue = this.orgGrade || '';
        break;
      case 5: // Grade Start Date
        // Use the pre-calculated orgGradeStartDate value (already formatted as MM/dd/yyyy in setOriginalValuesFromWorker)
        prop.originalValue = this.orgGradeStartDate || '';
        break;
      case 6: // Step
        // Use the pre-calculated orgStep value (already set in setOriginalValuesFromWorker)
        prop.originalValue = this.orgStep || '';
        break;
      case 7: // Step Start Date
        // Use the pre-calculated orgStepStartDate value (already formatted as MM/dd/yyyy in setOriginalValuesFromWorker)
        prop.originalValue = this.orgStepStartDate || '';
        break;
      case 8: // Primary GAU (Organization)
        // First try workerAssignments (primary source)
        if (this.workerBase.workerAssignments && this.workerBase.workerAssignments[0] &&
            this.workerBase.workerAssignments[0].workerOrganization &&
            this.workerBase.workerAssignments[0].workerOrganization.organization) {
          const org = this.workerBase.workerAssignments[0].workerOrganization.organization;
          prop.originalValue = org.businessAreaCode + '/' + org.shortName;
        } else if (this.workerBase.organizations && this.workerBase.organizations[0] &&
                   this.workerBase.organizations[0].organization) {
          // Fall back to organizations
          const org = this.workerBase.organizations[0].organization;
          prop.originalValue = org.businessAreaCode + '/' + org.shortName;
        } else {
          prop.originalValue = '';
        }
        break;
      case 9: // Secondary GAU (Organization)
        // First try workerAssignments (primary source)
        if (this.workerBase.workerAssignments && this.workerBase.workerAssignments[1] &&
            this.workerBase.workerAssignments[1].workerOrganization &&
            this.workerBase.workerAssignments[1].workerOrganization.organization) {
          const org = this.workerBase.workerAssignments[1].workerOrganization.organization;
          prop.originalValue = org.businessAreaCode + '/' + org.shortName;
        } else if (this.workerBase.organizations && this.workerBase.organizations[1] &&
                   this.workerBase.organizations[1].organization) {
          // Fall back to organizations
          const org = this.workerBase.organizations[1].organization;
          prop.originalValue = org.businessAreaCode + '/' + org.shortName;
        } else {
          prop.originalValue = '';
        }
        break;
      case 10: // Position Title
        prop.originalValue = worker.jobClass
          ? worker.jobClass.value + ' - ' + worker.jobClass.description
          : '';
        break;
      case 11: // Supervisor
        prop.originalValue = worker.supervisorIndicator !== null && worker.supervisorIndicator !== undefined
          ? (worker.supervisorIndicator ? 'Yes' : 'No')
          : '';
        break;
      case 12: // Assigned Worker Roles
        // Use the pre-calculated orgWorkerRoles value (matching legacy implementation)
        console.log("descp",this.orgWorkerRoles)
        prop.originalValue = this.orgWorkerRoles;
        // Fetch available worker roles when this property is selected
        this.getAvailableWorkerRoles();
        break;
      default:
        prop.originalValue = '';
    }
  }

  /**
   * Get occupational titles for selected series
   */
  getOccupationalTitle(occupationalSeriesId: string): void {
    // Fetch occupational titles for the selected series
    const url = `/occupational-series-titles?includeInactive=true&occupationalSeriesId=${occupationalSeriesId}`;
    
    this.workerManagementService.getOccupationalSeriesTitles(occupationalSeriesId).subscribe(
      (response: any) => {
        console.log('Occupational titles loaded:', response);
        // Extract title codes from response
        const titleCodes = Array.isArray(response) ? response : (response?.results || []);
        if (this.workerBase.references) {
          this.workerBase.references.titleCodes = titleCodes;
        }
        this.cdr.detectChanges();
      },
      (error: any) => {
        console.warn('Warning loading occupational titles:', error);
        this.cdr.detectChanges();
      }
    );
  }

  /**
   * TrackBy function for property list to improve performance
   */
  trackByPropertyId(index: number, item: any): any {
    return item.stndWorkerOverridePropertyId || item.propertyId || index;
  }

  /**
   * Handle property value change with dynamic validation
   * Follows legacy logic from AngularJS controller (lines 673-761)
   * This is called whenever a property's override value changes
   */
  onPropertyValueChange(index: number): void {
    console.log('=== onPropertyValueChange called ===');
    console.log('Index:', index);
    console.log('Current overrideProperties:', this.overrideProperties);
    
    if (index >= 0 && index < this.overrideProperties.length) {
      const prop = this.overrideProperties[index];
      console.log('Property at index:', prop);
      console.log('Selected property:', prop.selectedProperty);
      console.log('Override value:', prop.overrideValue);
    }
    
    // Re-validate all dependencies after any value change
    this.validatePropertyDependencies();
    
    // Trigger change detection to re-render the validation errors div
    this.cdr.detectChanges();
  }

  /**
   * Validate property dependencies
   * Clears old dependency errors and adds new ones based on current state
   */
  private validatePropertyDependencies(): void {
    // Initialize validationErrors if not already initialized
    if (!this.validationErrors) {
      this.validationErrors = [];
    }
    
    // Remove all dependency-related errors (keep other errors like date validation)
    this.validationErrors = this.validationErrors.filter((error) => {
      // Remove dependency errors (OCC/Title, Grade/Step dependencies)
      if (error.indexOf('Add override properties for') === 0) {
        console.log('Removing old dependency error:', error);
        return false;
      }
      return true;
    });
    
    console.log('After removing old dependency errors:', this.validationErrors);
    
    // Log current property state for debugging
    console.log('=== Checking dependencies ===');
    console.log('Property 1 (OCC Series Code) present:', this.checkPresent(1));
    console.log('Property 2 (Title Code) present:', this.checkPresent(2));
    console.log('Property 4 (Grade) present:', this.checkPresent(4));
    console.log('Property 5 (Grade Start Date) present:', this.checkPresent(5));
    console.log('Property 6 (Step) present:', this.checkPresent(6));
    console.log('Property 7 (Step Start Date) present:', this.checkPresent(7));
    
    // Show validation errors if any dependency errors will be added
    if (this.validationErrors.length > 0) {
      this.showValidationErrors = true;
    }
    
    // OCC Series and Title Code dependency
    if (this.checkPresent(1) && !this.checkPresent(2)) {
      const titleError = 'Add override properties for Title Code.';
      console.log('Adding error: ' + titleError);
      if (this.validationErrors.indexOf(titleError) === -1) {
        this.validationErrors.push(titleError);
      }
    }
    if (this.checkPresent(2) && !this.checkPresent(1)) {
      const occError = 'Add override properties for OCC Series Code.';
      console.log('Adding error: ' + occError);
      if (this.validationErrors.indexOf(occError) === -1) {
        this.validationErrors.push(occError);
      }
    }
    
    // Dynamic validation for Grade and Step dependencies
    // Rule 1: If Grade (4) is present, require Grade Start Date (5), Step (6), and Step Start Date (7)
    if (this.checkPresent(4)) {
      const missingGradeProps: string[] = [];
      if (!this.checkPresent(5)) missingGradeProps.push('Grade Start Date');
      if (!this.checkPresent(6)) missingGradeProps.push('Step');
      if (!this.checkPresent(7)) missingGradeProps.push('Step Start Date');
      
      if (missingGradeProps.length > 0) {
        const gradeError = 'Add override properties for ' + missingGradeProps.join(', ') + '.';
        console.log('Adding error: ' + gradeError);
        if (this.validationErrors.indexOf(gradeError) === -1) {
          this.validationErrors.push(gradeError);
        }
      }
    }
    // Rule 2: If Step (6) is present without Grade (4), only require Step Start Date (7)
    else if (this.checkPresent(6) && !this.checkPresent(7)) {
      const stepError = 'Add override properties for Step Start Date.';
      console.log('Adding error: ' + stepError);
      if (this.validationErrors.indexOf(stepError) === -1) {
        this.validationErrors.push(stepError);
      }
    }
    // Rule 3: If Grade Start Date (5) or Step Start Date (7) is present without their parent, show error
    if (this.checkPresent(5) && !this.checkPresent(4)) {
      const gradeStartError = 'Add override properties for Grade.';
      console.log('Adding error: ' + gradeStartError);
      if (this.validationErrors.indexOf(gradeStartError) === -1) {
        this.validationErrors.push(gradeStartError);
      }
    }
    if (this.checkPresent(7) && !this.checkPresent(6)) {
      const stepStartError = 'Add override properties for Step.';
      console.log('Adding error: ' + stepStartError);
      if (this.validationErrors.indexOf(stepStartError) === -1) {
        this.validationErrors.push(stepStartError);
      }
    }
    
    console.log('Final validationErrors after dependency check:', this.validationErrors);
    
    // Update individual property errors for inline display
    this.updatePropertyErrors();
    
    // Show validation errors if any errors exist
    if (this.validationErrors.length > 0) {
      this.showValidationErrors = true;
    } else {
      this.showValidationErrors = false;
    }
  }

  /**
   * Update individual property-level errors for inline display
   * Displays dependency messages directly below each field
   */
  private updatePropertyErrors(): void {
    if (!this.overrideProperties) {
      return;
    }

    // Clear all property errors first
    this.overrideProperties.forEach(prop => {
      prop.propertyErrors = [];
    });

    // Check Title Code dependency (Property 2)
    const titleCodeProp = this.getPropertyById(2);
    if (titleCodeProp && titleCodeProp.overrideValue && !this.checkPresent(1)) {
      if (!titleCodeProp.propertyErrors) {
        titleCodeProp.propertyErrors = [];
      }
      titleCodeProp.propertyErrors.push('OCC Series Code is required when Title Code is selected.');
    }

    // Check OCC Series Code dependency (Property 1)
    const occSeriesProp = this.getPropertyById(1);
    if (occSeriesProp && occSeriesProp.overrideValue && !this.checkPresent(2)) {
      if (!occSeriesProp.propertyErrors) {
        occSeriesProp.propertyErrors = [];
      }
      occSeriesProp.propertyErrors.push('Title Code is required when OCC Series Code is selected.');
    }

    // Check Grade dependencies (Property 4)
    const gradeProp = this.getPropertyById(4);
    if (gradeProp && gradeProp.overrideValue) {
      const missingGradeProps: string[] = [];
      if (!this.checkPresent(5)) missingGradeProps.push('Grade Start Date');
      if (!this.checkPresent(6)) missingGradeProps.push('Step');
      if (!this.checkPresent(7)) missingGradeProps.push('Step Start Date');

      if (missingGradeProps.length > 0) {
        if (!gradeProp.propertyErrors) {
          gradeProp.propertyErrors = [];
        }
        gradeProp.propertyErrors.push('When Grade is selected, you must also select: ' + missingGradeProps.join(', ') + '.');
      }
    }

    // Check Grade Start Date dependency (Property 5)
    const gradeStartDateProp = this.getPropertyById(5);
    if (gradeStartDateProp && gradeStartDateProp.overrideValue && !this.checkPresent(4)) {
      if (!gradeStartDateProp.propertyErrors) {
        gradeStartDateProp.propertyErrors = [];
      }
      gradeStartDateProp.propertyErrors.push('Grade is required when Grade Start Date is selected.');
    }

    // Check Step dependency (Property 6)
    const stepProp = this.getPropertyById(6);
    if (stepProp && stepProp.overrideValue && !this.checkPresent(7)) {
      if (!stepProp.propertyErrors) {
        stepProp.propertyErrors = [];
      }
      stepProp.propertyErrors.push('Step Start Date is required when Step is selected.');
    }

    // Check Step Start Date dependency (Property 7)
    const stepStartDateProp = this.getPropertyById(7);
    if (stepStartDateProp && stepStartDateProp.overrideValue && !this.checkPresent(6)) {
      if (!stepStartDateProp.propertyErrors) {
        stepStartDateProp.propertyErrors = [];
      }
      stepStartDateProp.propertyErrors.push('Step is required when Step Start Date is selected.');
    }
  }

  /**
   * Get property errors for display below a field
   */
  getPropertyErrors(prop: OverrideProperty): string[] {
    return prop.propertyErrors || [];
  }

  /**
   * Check if property has errors
   */
  hasPropertyErrors(prop: OverrideProperty): boolean {
    return !!(prop.propertyErrors && prop.propertyErrors.length > 0);
  }

  /**
   * Check if a specific property ID exists with a value
   */
  checkPresent(id: number): boolean {
    if (!this.overrideProperties) {
      console.log(`checkPresent(${id}): overrideProperties is null/undefined`);
      return false;
    }
    
    for (let i = 0; i < this.overrideProperties.length; i++) {
      const p = this.overrideProperties[i];
      if (p.selectedProperty &&
          p.selectedProperty.stndWorkerOverridePropertyId === id &&
          (p.overrideValue !== null && p.overrideValue !== undefined && p.overrideValue !== '')) {
        console.log(`checkPresent(${id}): FOUND at index ${i}, value:`, p.overrideValue);
        return true;
      }
    }
    
    console.log(`checkPresent(${id}): NOT FOUND`);
    return false;
  }

  /**
   * Check if property is missing
   */
  isPropertyMissing(id: number): boolean {
    if (!this.overrideProperties) return true;
    for (let i = 0; i < this.overrideProperties.length; i++) {
      const p = this.overrideProperties[i];
      if (p.selectedProperty &&
          p.selectedProperty.stndWorkerOverridePropertyId === id &&
          (p.overrideValue !== null && p.overrideValue !== undefined && p.overrideValue !== '')) {
        return false;
      }
    }
    return true;
  }

  /**
   * Get property by ID
   */
  getPropertyById(id: number): OverrideProperty | null {
    if (!this.overrideProperties) return null;
    for (let i = 0; i < this.overrideProperties.length; i++) {
      const p = this.overrideProperties[i];
      if (p.selectedProperty && p.selectedProperty.stndWorkerOverridePropertyId === id) {
        return p;
      }
    }
    return null;
  }

  /**
   * Get available worker roles for the primary organization
   */
  getAvailableWorkerRoles(): void {
    let organizationId: string | null = null;
    
    // Try from workerAssignments in data.workerBaseDetails
    if (this.data && this.data.workerBaseDetails && this.data.workerBaseDetails.workerAssignments &&
        this.data.workerBaseDetails.workerAssignments[0] &&
        this.data.workerBaseDetails.workerAssignments[0].workerOrganization &&
        this.data.workerBaseDetails.workerAssignments[0].workerOrganization.organization) {
      
      const org = this.data.workerBaseDetails.workerAssignments[0].workerOrganization.organization;
      organizationId = org.organizationId || org.id;
    }
    // Try from workerAssignments in workerBase
    else if (this.workerBase.workerAssignments && this.workerBase.workerAssignments[0] &&
             this.workerBase.workerAssignments[0].workerOrganization &&
             this.workerBase.workerAssignments[0].workerOrganization.organization) {
      
      const org = this.workerBase.workerAssignments[0].workerOrganization.organization;
      organizationId = org.organizationId || org.id;
    }
    // Try from organizations array
    else if (this.workerBase.organizations && this.workerBase.organizations[0] &&
             this.workerBase.organizations[0].organization) {
      
      const org = this.workerBase.organizations[0].organization;
      organizationId = org.organizationId || org.id;
    }
    // Try from worker.organization
    else if (this.workerBase.worker && this.workerBase.worker.organization) {
      organizationId = this.workerBase.worker.organization.organizationId || this.workerBase.worker.organization.id;
    }
    if (organizationId) {
      this.workerManagementService.getOrganizationReportRoles(organizationId).subscribe(
        (response: any) => {
          let rolesArray: any[] = [];
          
          // Handle different response formats
          if (response && response.results && Array.isArray(response.results)) {
            // Response format: { results: [...], meta: {...} }
            rolesArray = response.results;
          } else if (response && response.organizationReportRoles && Array.isArray(response.organizationReportRoles)) {
            // Response format: { organizationReportRoles: [...] }
            rolesArray = response.organizationReportRoles;
          } else if (Array.isArray(response)) {
            // Direct array response
            rolesArray = response;
          }
          
          if (rolesArray && rolesArray.length > 0) {
            // Process roles to build display options
            this.workerBase.references.availableWorkerRoles = this.buildDisplayOptions(rolesArray);
          } else {
            this.workerBase.references.availableWorkerRoles = [];
          }
          this.cdr.detectChanges();
        },
        (error: any) => {
          console.error('Error fetching organization report roles:', error);
          this.workerBase.references.availableWorkerRoles = [];
          this.cdr.detectChanges();
        }
      );
    } else {
      this.workerBase.references.availableWorkerRoles = [];
    }
  }

  /**
   * Check if Title Code is disabled (requires OCC Series Code first)
   */
  isTitleCodeDisabled(prop: OverrideProperty): boolean {
    if (prop.selectedProperty && prop.selectedProperty.stndWorkerOverridePropertyId === 2) {
      return !this.hasOccSeriesCodeSelected();
    }
    return false;
  }

  /**
   * Check if OCC Series Code is selected in any property
   */
  hasOccSeriesCodeSelected(): boolean {
    if (!this.overrideProperties || this.overrideProperties.length === 0) {
      return false;
    }
    
    for (let i = 0; i < this.overrideProperties.length; i++) {
      const prop = this.overrideProperties[i];
      if (prop.selectedProperty &&
          prop.selectedProperty.stndWorkerOverridePropertyId === 1 &&
          prop.selectedOccCode && prop.selectedOccCode.id) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get Title Code validation message
   */
  getTitleCodeValidationMessage(prop: OverrideProperty): string | null {
    if (prop.selectedProperty &&
        prop.selectedProperty.stndWorkerOverridePropertyId === 2 &&
        !this.hasOccSeriesCodeSelected()) {
      return 'Please select OCC Series Code before selecting Title Code.';
    }
    return null;
  }

  /**
   * Handle OCC Code selection
   */
  onOccCodeSelect(item: any, prop: OverrideProperty): void {
    console.log('=== onOccCodeSelect called ===');
    console.log('Item:', item);
    
    if (!this.validationBooleans) {
      this.validationBooleans = {};
    }
    
    this.validationBooleans.occSeriesCodeLookupNoResults = false;
    
    // Set the formatted string with value and description
    prop.overrideValue = item.value + ' - ' + item.description;
    console.log('Set prop.overrideValue to:', prop.overrideValue);
    
    // Set the input field to the full value to display the selection
    prop.occCodeInput = prop.overrideValue;
    
    // Close the dropdown by setting the flag to false
    prop.showOccCodeDropdown = false;
    
    // Store the actual item object for later use
    prop.selectedOccCode = item;
    
    // Load title codes based on the selected occupational series ID
    if (item && item.id) {
      this.getOccupationalTitle(item.id);
    }
  }

  /**
   * Handle Title Code selection
   */
  onTitleCodeSelect(item: any, prop: OverrideProperty): void {
    console.log('=== onTitleCodeSelect called ===');
    console.log('Item:', item);
    
    // Clear any validation errors
    prop.noResults = false;
    
    // Set the formatted string with value and description
    prop.overrideValue = item.value + ' - ' + item.description;
    console.log('Set prop.overrideValue to:', prop.overrideValue);
    
    // Set the input field to the full value to display the selection
    prop.titleCodeInput = prop.overrideValue;
    
    // Close the dropdown by setting the flag to false
    prop.showTitleCodeDropdown = false;
    
    // Store the actual item object for later use
    prop.selectedTitleCode = item;
  }

  /**
   * Handle Position Title selection
   */
  onPositionTitleSelect(item: any, prop: OverrideProperty): void {
    console.log('=== onPositionTitleSelect called ===');
    console.log('Item:', item);
    
    // Clear any validation errors
    prop.noResults = false;
    
    // Set the formatted string with value and description
    prop.overrideValue = item.value + ' - ' + item.description;
    console.log('Set prop.overrideValue to:', prop.overrideValue);
    
    // Set the input field to the full value to display the selection
    prop.positionTitleInput = prop.overrideValue;
    
    // Close the dropdown by setting the flag to false
    prop.showPositionTitleDropdown = false;
    
    // Store the actual item object for later use
    prop.selectedPositionTitle = item;
  }

  /**
   * Handle Signatory Authority selection
   */
  onSignatoryAuthoritySelect(item: any, prop: OverrideProperty): void {
    // The select dropdown already binds the full object to prop.overrideValue
    if (prop.overrideValue) {
      prop.selectedSignatoryAuthority = prop.overrideValue;
    }
  }

  /**
   * Search for organization by acronym using lookup button
   */
  searchAcronym(prop: OverrideProperty, propertyId: number): void {
    // Search for organizations by acronym
    // The acronym format is X/XX where X is business area code and XX is short name
    if (!prop.overrideValue || typeof prop.overrideValue !== 'string') {
      alert('Please enter an acronym first (format: X/XX)');
      return;
    }

    const acronym = prop.overrideValue.trim();
    if (acronym.length < 3) {
      alert('Please enter a complete acronym (format: X/XX)');
      return;
    }

    // Parse acronym: X/XX format
    const parts = acronym.split('/');
    if (parts.length !== 2) {
      alert('Invalid acronym format. Expected format: X/XX');
      return;
    }

    const businessAreaCode = parts[0].trim();
    const shortName = parts[1].trim();

    // Search for organization with this acronym
    this.organizationService.searchOrganizations(businessAreaCode, shortName, 'false').subscribe(
      (response: any) => {
        const organizations = response?.results || [];
        if (organizations.length === 0) {
          alert(`No organization found with acronym ${acronym}`);
        } else if (organizations.length === 1) {
          // Auto-select if only one match
          const org = organizations[0];
          prop.overrideValue = org.businessAreaCode + '/' + org.shortName;
          prop.acronymValidationError = '';
          this.cdr.detectChanges();
        } else {
          // Multiple matches - show selection dialog
          alert(`Found ${organizations.length} organizations with acronym ${acronym}. Please select one from the list.`);
          // In a real implementation, this would open a MatDialog for selection
        }
      },
      (error: any) => {
        console.error('Error searching for organization:', error);
        alert('Error searching for organization. Please try again.');
      }
    );
  }

  /**
   * Handle acronym change event from acronym-input component
   */
  onAcronymChange(event: any, prop: OverrideProperty, propertyId: number): void {
    // Format and validate the acronym input
    if (event && typeof event === 'string') {
      prop.overrideValue = event;
      this.validateAcronymInput(prop, propertyId);
    }
  }

  /**
   * Handle acronym selected event from acronym-input component
   * This is called when user selects from worker lookup
   */
  onAcronymSelected(event: any, prop: OverrideProperty, propertyId: number): void {
    if (event) {
      // Event contains the selected organization data
      if (event.organization) {
        // Set the acronym from the selected organization
        const org = event.organization;
        prop.overrideValue = org.businessAreaCode + '/' + org.shortName;
        prop.acronymValidationError = '';
      } else if (typeof event === 'string') {
        // If event is just a string, use it directly
        prop.overrideValue = event;
        this.validateAcronymInput(prop, propertyId);
      }
      this.cdr.detectChanges();
    }
  }

  /**
   * Format acronym input to automatically add "/" after first character
   */
  formatAcronymInput(prop: OverrideProperty): void {
    if (!prop.overrideValue) {
      prop.overrideValue = '';
    }
    
    if (typeof prop.overrideValue === 'string' && prop.overrideValue) {
      // Remove any non-word characters except forward slash
      let value = prop.overrideValue.replace(/[^\w\/]/g, '');
      // Remove any existing slashes to reformat
      value = value.replace(/\//g, '');
      
      // Apply the acronym filter logic (X/XX format)
      if (value.length > 0) {
        const formatted = value.substring(0, 1) + '/' + value.substring(1);
        prop.overrideValue = formatted.substring(0, 12); // Limit to maxlength
      }
    }
  }

  /**
   * Validate acronym input for IDs 8 (Primary GAU) and 9 (Secondary GAU)
   */
  validateAcronymInput(prop: OverrideProperty, propertyId: number): void {
    // Immediately clear error when field is empty or cleared
    if (!prop.overrideValue || typeof prop.overrideValue !== 'string' || !prop.overrideValue.trim()) {
      prop.acronymValidationError = '';
      // Cancel any pending debounce timer
      if (prop.acronymValidationTimer) {
        clearTimeout(prop.acronymValidationTimer);
      }
      return;
    }

    const acronym = prop.overrideValue.trim();

    // Skip validation if acronym is less than 3 characters (minimum "X/XX")
    if (acronym.length < 3) {
      // Clear error immediately for incomplete input
      prop.acronymValidationError = '';
      // Cancel any pending debounce timer
      if (prop.acronymValidationTimer) {
        clearTimeout(prop.acronymValidationTimer);
      }
      return;
    }

    // Cancel previous debounce timer if exists
    if (prop.acronymValidationTimer) {
      clearTimeout(prop.acronymValidationTimer);
    }

    // Set debounce timer (300ms delay before validation)
    prop.acronymValidationTimer = setTimeout(() => {
      // Basic validation: check if acronym matches expected format (X/XX)
      const acronymRegex = /^[A-Z]{1}\/[A-Z0-9]{2,}$/i;
      
      if (acronymRegex.test(acronym)) {
        // Valid format - clear error
        prop.acronymValidationError = '';
      } else {
        // Invalid format
        prop.acronymValidationError = `Acronym "${acronym}" format is invalid. Expected format: X/XX`;
      }
      this.cdr.detectChanges();
    }, 300); // 300ms debounce delay
  }

  /**
   * Update end date picker configuration
   */
  private updateEndDatePickerConfig(): void {
    if (this.overrideStartDate && this.maxEndDateFromStartDate) {
      const startDate = new Date(this.overrideStartDate);
      startDate.setHours(0, 0, 0, 0);
      
      const maxDate = new Date(this.maxEndDateFromStartDate);
      maxDate.setHours(0, 0, 0, 0);
      
      this.endDatePickerConfig = {
        minDate: startDate,
        maxDate: maxDate
      };
    } else {
      this.endDatePickerConfig = {
        minDate: this.todayDate
      };
    }
  }

  /**
   * Handle start date change
   */
  onStartDateChange(): void {
    // Clear the required error flag when user changes the date
    this.startDateRequired = false;

    // Remove start date related errors from validationErrors array if they exist
    if (this.validationErrors && this.validationErrors.length > 0) {
      this.validationErrors = this.validationErrors.filter((error) => {
        return error !== 'Start Date is required.' &&
               !error.includes('Start date cannot be less than today\'s date');
      });

      // Clear form error message if no validation errors remain
      if (this.validationErrors.length === 0) {
        this.formErrorMessage = '';
      }
    }

    if (this.overrideStartDate) {
      // Validate start date is not in the past
      const startDate = new Date(this.overrideStartDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      startDate.setHours(0, 0, 0, 0);

      if (startDate < today) {
        this.invalidOverrideStartDate = 'Start date cannot be less than today\'s date.';
        // Also add to validationErrors array for the main error div
        if (!this.validationErrors) {
          this.validationErrors = [];
        }
        this.showValidationErrors = true;
        const errorExists = this.validationErrors.some((error) => {
          return error === this.invalidOverrideStartDate;
        });
        if (!errorExists) {
          this.validationErrors.push(this.invalidOverrideStartDate);
        }
      } else {
        this.invalidOverrideStartDate = '';
      }

      // Set max end date to 6 months from start date
      const maxDate = new Date(this.overrideStartDate);
      maxDate.setMonth(maxDate.getMonth() + 6);
      maxDate.setHours(0, 0, 0, 0);
      this.maxEndDateFromStartDate = maxDate;

      // Reset end date if it's beyond max
      if (this.overrideEndDate) {
        const endDate = new Date(this.overrideEndDate);
        endDate.setHours(0, 0, 0, 0);
        if (endDate > maxDate) {
          this.overrideEndDate = null;
          this.invalidOverrideEndDate = 'End date must be within 6 months of start date';
        }
      }

      // Update end date picker configuration
      this.updateEndDatePickerConfig();

      // Trigger change detection to update end date picker constraints
      this.cdr.detectChanges();
    } else {
      // Reset max end date when start date is cleared
      this.maxEndDateFromStartDate = undefined;
      this.invalidOverrideStartDate = '';
      this.updateEndDatePickerConfig();
    }
  }

  /**
   * Handle end date change
   */
  onEndDateChange(): void {
    // Clear the required error flag when user changes the date
    this.endDateRequired = false;

    // Remove end date related errors from validationErrors array if they exist
    if (this.validationErrors && this.validationErrors.length > 0) {
      this.validationErrors = this.validationErrors.filter((error) => {
        return error !== 'End Date is required.' &&
               !error.includes('End date must be greater than the start date') &&
               !error.includes('End date cannot exceed 6 months from the start date');
      });

      // Clear form error message if no validation errors remain
      if (this.validationErrors.length === 0) {
        this.formErrorMessage = '';
      }
    }

    if (this.overrideEndDate && this.overrideStartDate) {
      const startDate = new Date(this.overrideStartDate);
      const endDate = new Date(this.overrideEndDate);
      
      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(0, 0, 0, 0);

      if (endDate <= startDate) {
        this.invalidOverrideEndDate = 'End date must be greater than the start date.';
        // Also add to validationErrors array for the main error div
        if (!this.validationErrors) {
          this.validationErrors = [];
        }
        this.showValidationErrors = true;
        const errorExists = this.validationErrors.some((error) => {
          return error === this.invalidOverrideEndDate;
        });
        if (!errorExists) {
          this.validationErrors.push(this.invalidOverrideEndDate);
        }
      } else {
        // Validate 6-month constraint
        const maxEndDate = new Date(startDate);
        maxEndDate.setMonth(maxEndDate.getMonth() + 6);
        maxEndDate.setHours(0, 0, 0, 0);

        if (endDate > maxEndDate) {
          this.invalidOverrideEndDate = 'End date cannot exceed 6 months from the start date.';
          // Also add to validationErrors array for the main error div
          if (!this.validationErrors) {
            this.validationErrors = [];
          }
          this.showValidationErrors = true;
          const errorExists = this.validationErrors.some((error) => {
            return error === this.invalidOverrideEndDate;
          });
          if (!errorExists) {
            this.validationErrors.push(this.invalidOverrideEndDate);
          }
        } else {
          // Check for duplicate date pairs and properties in existing worker overrides
          this.duplicateDatePairError = this.checkForDuplicateOverride(startDate, endDate);

          // If there's a duplicate error, add it to validation errors if not already present
          if (this.duplicateDatePairError) {
            this.showValidationErrors = true;
            if (!this.validationErrors) {
              this.validationErrors = [];
            }
            // Only add if not already in the array
            const errorExists = this.validationErrors.some((error) => {
              return error === this.duplicateDatePairError;
            });
            if (!errorExists) {
              this.validationErrors.push(this.duplicateDatePairError);
            }
          } else {
            this.invalidOverrideEndDate = '';
          }
        }
      }
    }

    // Trigger change detection
    this.cdr.detectChanges();
  }

  /**
   * Format original value for display - handles dates and other formats
   */
  formatOriginalValue(value: any): string {
    if (!value) return '';
    
    // Check if it's a date-like string (e.g., contains 'T' and can be parsed)
    if (typeof value === 'string') {
      const date = new Date(value);
      const isDate = value.includes('T') && !isNaN(date.getTime());
      
      if (isDate) {
        // Return formatted date using DatePipe
        return this.datePipe.transform(value, 'MM/dd/yyyy', 'UTC') || value;
      }
      
      // Return regular string as-is
      return value;
    }
    
    if (typeof value === 'object') {
      if (value.description) return value.description;
      if (value.value) return value.value;
      if (value.displayItem) return value.displayItem;
    }
    
    return String(value);
  }

  /**
   * Perform real-time validation as user selects properties
   * This validates ONLY dependency rules and displays errors immediately
   * Shows all applicable dependency messages as user fills in fields
   * Required field validation is only shown on form submission
   * Follows legacy validation rules from AngularJS controller
   */
  private performRealTimeValidation(): void {
    this.validationErrors = [];
    this.showValidationErrors = true;

    // Helper to check if a specific Property ID exists with a value
    const checkPresent = (id: number): boolean => this.checkPresent(id);

    // Only validate if there are properties
    if (!this.overrideProperties || this.overrideProperties.length === 0) {
      this.cdr.detectChanges();
      return;
    }

    // ONLY validate dependency rules - NOT required fields
    // Required field validation happens only on form submission
    // Show all applicable dependency messages as user fills in fields

    // OCC Series Code (1) and Title Code (2) mutual dependency - LEGACY RULE
    if (checkPresent(1) && !checkPresent(2)) {
      this.validationErrors.push('Add override properties for Title Code.');
    }
    if (checkPresent(2) && !checkPresent(1)) {
      this.validationErrors.push('Add override properties for OCC Series Code.');
    }

    // Grade (4) and related dependencies - LEGACY RULE
    // Rule 1: If Grade (4) is present, require Grade Start Date (5), Step (6), and Step Start Date (7)
    if (checkPresent(4)) {
      const missingGradeProps: string[] = [];
      if (!checkPresent(5)) missingGradeProps.push('Grade Start Date');
      if (!checkPresent(6)) missingGradeProps.push('Step');
      if (!checkPresent(7)) missingGradeProps.push('Step Start Date');

      if (missingGradeProps.length > 0) {
        this.validationErrors.push('Add override properties for ' + missingGradeProps.join(', ') + '.');
      }
    }

    // Rule 2: If Step (6) is present without Grade (4), only require Step Start Date (7)
    if (checkPresent(6) && !checkPresent(4) && !checkPresent(7)) {
      this.validationErrors.push('Add override properties for Step Start Date.');
    }

    // Rule 3: If Grade Start Date (5) is present without Grade (4), show error
    if (checkPresent(5) && !checkPresent(4)) {
      this.validationErrors.push('Add override properties for Grade.');
    }

    // Rule 3: If Step Start Date (7) is present without Step (6), show error
    if (checkPresent(7) && !checkPresent(6)) {
      this.validationErrors.push('Add override properties for Step.');
    }

    this.cdr.detectChanges();
  }

  /**
   * Validate form before submission - comprehensive validation matching legacy logic
   */
  private validateForm(): boolean {
    this.validationErrors = [];
    this.formErrorMessage = '';
    this.showValidationErrors = true;
    this.startDateRequired = false;
    this.endDateRequired = false;

    // Helper to check if a specific Property ID exists with a value
    const checkPresent = (id: number): boolean => this.checkPresent(id);

    /* --- SECTION 1: Global Date & Basic Checks --- */

    // Check if start date is provided
    if (!this.overrideStartDate) {
      this.startDateRequired = true;
      this.validationErrors.push('Start Date is required.');
    }

    // Check if end date is provided
    if (!this.overrideEndDate) {
      this.validationErrors.push('End Date is required');
      this.endDateRequired = true;
    }

    // Check for existing logic errors (e.g., End Date < Start Date)
    if (this.invalidOverrideStartDate) {
      this.validationErrors.push(this.invalidOverrideStartDate);
    }
    if (this.invalidOverrideEndDate) {
      this.validationErrors.push(this.invalidOverrideEndDate);
    }
    // Check for duplicate date pair
    if (this.duplicateDatePairError) {
      this.validationErrors.push(this.duplicateDatePairError);
    }

    // Check if the property array is empty
    if (!this.overrideProperties || this.overrideProperties.length === 0) {
      this.validationErrors.push('Please add at least one property to override.');
    }

    /* --- SECTION 2: Property & Dependency Checks --- */

    // Only run these if there are properties to check
    if (this.overrideProperties && this.overrideProperties.length > 0) {

      // Ensure every row has both a selection and a value
      for (let i = 0; i < this.overrideProperties.length; i++) {
        const prop = this.overrideProperties[i];
        const hasPropType = prop.selectedProperty && prop.selectedProperty.propertyName;
        const hasVal = prop.overrideValue !== null && prop.overrideValue !== undefined && prop.overrideValue !== '';

        if (!hasPropType || !hasVal) {
          this.validationErrors.push(`Row ${i + 1} is incomplete. Both property and value are required.`);
        }
        if (prop.noResults) {
          this.validationErrors.push(`Row ${i + 1} contains an invalid code.`);
        }
        // Check for acronym validation errors on IDs 8 and 9
        if ((prop.selectedProperty?.stndWorkerOverridePropertyId === 8 || prop.selectedProperty?.stndWorkerOverridePropertyId === 9) &&
            prop.acronymValidationError) {
          this.validationErrors.push(`Row ${i + 1}: ${prop.acronymValidationError}`);
        }
      }

      // Logic Dependencies
      if (checkPresent(1) && !checkPresent(2)) {
        this.validationErrors.push('Add override properties for Title Code.');
      }
      if (checkPresent(2) && !checkPresent(1)) {
        this.validationErrors.push('Add override properties for OCC Series Code.');
    }

      // Dynamic validation for Grade and Step dependencies
      // Rule 1: If Grade (4) is present, require Grade Start Date (5), Step (6), and Step Start Date (7)
      if (checkPresent(4)) {
        const missingGradeProps: string[] = [];
        if (!checkPresent(5)) missingGradeProps.push('Grade Start Date');
        if (!checkPresent(6)) missingGradeProps.push('Step');
        if (!checkPresent(7)) missingGradeProps.push('Step Start Date');

        if (missingGradeProps.length > 0) {
          this.validationErrors.push('Add override properties for ' + missingGradeProps.join(', ') + '.');
        }
      }
      // Rule 2: If Step (6) is present without Grade (4), only require Step Start Date (7)
      else if (checkPresent(6) && !checkPresent(7)) {
        this.validationErrors.push('Add override properties for Step Start Date.');
      }
      // Rule 3: If Grade Start Date (5) or Step Start Date (7) is present without their parent, show error
      if (checkPresent(5) && !checkPresent(4)) {
        this.validationErrors.push('Add override properties for Grade.');
      }
      if (checkPresent(7) && !checkPresent(6)) {
        this.validationErrors.push('Add override properties for Step.');
      }
    }

    /* --- SECTION 3: Final Verification --- */

    // Stop if we found ANY errors
    if (this.validationErrors.length > 0) {
      return false;
    }

    return true;
  }

  /**
   * Check for duplicate date pairs and properties in existing worker overrides
   */
  private checkForDuplicateOverride(startDate: Date, endDate: Date): string {
    const existingOverrides = this.data?.existingOverrides || [];
    const currentProperties = this.overrideProperties || [];

    // Check each current property against existing overrides
    for (let i = 0; i < currentProperties.length; i++) {
      const currentProp = currentProperties[i];

      // Skip if property not selected yet
      if (!currentProp.selectedProperty || !currentProp.selectedProperty.stndWorkerOverridePropertyId) {
        continue;
      }
      const currentPropertyId = currentProp.selectedProperty.stndWorkerOverridePropertyId;

      // Check against all existing overrides
      for (let j = 0; j < existingOverrides.length; j++) {
        const override = existingOverrides[j];
        const existingStart = new Date(override.startDate);
        const existingEnd = new Date(override.endDate);

        // Normalize times to midnight
        existingStart.setHours(0, 0, 0, 0);
        existingEnd.setHours(0, 0, 0, 0);

        // Check if any property matches
        if (override.properties && override.properties.length > 0) {
          for (let k = 0; k < override.properties.length; k++) {
            const existingProp = override.properties[k];

            if (existingProp.propertyId === currentPropertyId ||
                existingProp.stndWorkerOverridePropertyId === currentPropertyId) {

              // Check for date overlap or exact match
              const newStartInRange = startDate >= existingStart && startDate <= existingEnd;
              const newEndInRange = endDate >= existingStart && endDate <= existingEnd;
              const newWrapsExisting = startDate <= existingStart && endDate >= existingEnd;

              if (newStartInRange || newEndInRange || newWrapsExisting) {
                return `A worker override for this property already exists with overlapping dates (${this.datePipe.transform(existingStart, 'MM/dd/yyyy')} - ${this.datePipe.transform(existingEnd, 'MM/dd/yyyy')}). Please select different dates.`;
              }
            }
          }
        }
      }
    }

    return '';
  }

  /**
   * Submit the override
   * Follows the legacy pattern from workerUpdate.controller.js (lines 1723-1830)
   * Validates form and then calls updateOverride service to save the override
   */
  submitUpdate(): void {
    if (!this.validateForm()) {
      this.cdr.detectChanges();
      return;
    }

    // Build original values map for submission
    // Following legacy pattern: dates are formatted as MM/dd/yyyy via datePipe in setOriginalValuesFromWorker()
    const originalValuesMap: { [key: string]: string } = {
      'OCC Series Code': this.orgOccSeries,
      'Title Code': this.orgOccTitle,
      'Examiner Signatory Auth Level': this.orgSignAuthority,
      'Grade': this.orgGrade,
      'Grade Start Date': this.orgGradeStartDate,  // Already formatted as MM/dd/yyyy
      'Step': this.orgStep,
      'Step Start Date': this.orgStepStartDate,  // Already formatted as MM/dd/yyyy
      'GAU Primary': this.orgPriAcronym,
      'GAU Secondary': this.orgSecAcronym,
      'Position Title': this.orgPositionTitle,
      'Supervisor': this.orgSupervisor,
      'Assigned Worker Roles': this.orgWorkerRoles
    };

    // Format dates to ISO 8601 format (YYYY-MM-DDTHH:mm:ssZ)
    const startDateISO = this.overrideStartDate
      ? new Date(this.overrideStartDate).toISOString()
      : '';
    const endDateISO = this.overrideEndDate
      ? new Date(this.overrideEndDate).toISOString()
      : '';

    // Build the override data matching the legacy format
    // Get workerId from multiple possible sources
    const workerId = this.data?.workerId ||
                     this.workerBase.worker?.id ||
                     this.data?.workerBaseDetails?.worker?.id ||
                     this.data?.workerBaseDetails?.worker?.workerId;
    
    if (!workerId) {
      console.error('Worker ID is missing from dialog data');
      this.formErrorMessage = 'Worker ID is required to save override';
      this.showValidationErrors = true;
      this.cdr.detectChanges();
      return;
    }

    const overrideData = {
      workerId: workerId,
      startDate: startDateISO,
      endDate: endDateISO,
      isActive: true,
      properties: this.overrideProperties
        .filter(p => p.selectedProperty && p.overrideValue)
        .map(p => {
          const propName = p.selectedProperty.propertyName;
          const val = p.overrideValue;
          let finalUpdatedValue = '';

          // Extract the actual value from different types
          if (val !== undefined && val !== null) {
            if (typeof val === 'object' && val.reportRole && val.reportRole.displayItem !== undefined) {
              // For worker roles
              finalUpdatedValue = val.reportRole.displayItem;
            } else if (typeof val === 'object' && val.description !== undefined) {
              // For Signatory Authority - use description
              finalUpdatedValue = val.description;
            } else if (typeof val === 'object' && val.value !== undefined) {
              finalUpdatedValue = val.value;
            } else if (typeof val === 'object' && val.acronym !== undefined) {
              finalUpdatedValue = val.acronym;
            } else {
              finalUpdatedValue = String(val);
            }
          }

          return {
            stndWorkerOverridePropertyId: p.selectedProperty.stndWorkerOverridePropertyId,
            overrideValue: finalUpdatedValue,
            originalValue: String(originalValuesMap[propName] || '')
          };
        })
    };

    // Save the override to the backend using the updateOverride service
    // This matches the legacy implementation (line 1767 of workerUpdate.controller.js)
    this.workerManagementService.updateOverride(overrideData).subscribe({
      next: (response) => {
        console.log('Override saved successfully:', response);
        
        // Clear the entire HTTP cache to ensure fresh data is fetched
        // This ensures the parent component gets fresh data when it calls getOverrides(false)
        console.log('Clearing HTTP cache after override save');
        this.httpService.clearCache();
        
        // Close dialog with the saved override data
        // The parent component will handle refreshing the override list with fresh data
        // Parent calls getOverrides(false) which bypasses cache and fetches fresh data
        this.dialogRef.close(overrideData);
      },
      error: (error) => {
        console.error('Error saving override:', error);
        // Show error message to user
        const errorMessage = error?.error?.message || error?.message || 'Failed to save override. Please try again.';
        this.formErrorMessage = errorMessage;
        this.showValidationErrors = true;
        this.cdr.detectChanges();
      }
    });
  }

  /**
   * Cleanup on component destroy
   */
  ngOnDestroy(): void {
    // Clear the Grade Start Date watcher interval to prevent memory leaks
    if ((this as any).gradeStartDateWatcherInterval) {
      clearInterval((this as any).gradeStartDateWatcherInterval);
    }
  }

  /**
   * Close dialog
   */
  closeDialog(): void {
    this.dialogRef.close();
  }

  /**
   * Build display options for roles (align role codes with descriptions)
   */
  private buildDisplayOptions(roles: any[]): any[] {
    const maxLength = 6;
    
    return roles.map(role => {
      // Handle different role data structures
      let reportRole = role.reportRole;
      
      // If role doesn't have reportRole property, it might be the role itself
      if (!reportRole && role.value && role.description) {
        reportRole = role;
      }
      
      // If still no reportRole, create a default structure
      if (!reportRole) {
        reportRole = {
          id: role.id || role.reportRoleId || '',
          value: role.value || role.code || '',
          description: role.description || '',
          displayItem: ''
        };
      }
      
      // Ensure reportRole has required properties
      if (!reportRole.value) {
        reportRole.value = reportRole.code || '';
      }
      if (!reportRole.description) {
        reportRole.description = '';
      }
      if (!reportRole.id) {
        reportRole.id = reportRole.reportRoleId || '';
      }
      
      // Build display item with aligned spacing
      let spaces = '';
      const codeLength = (reportRole.value || '').length;
      for (let i = codeLength; i <= maxLength; i++) {
        spaces += '\u00A0'; // Non-breaking space
      }
      
      reportRole.displayItem = `${reportRole.value}${spaces}  ${reportRole.description}`;
      
      // Ensure the role object has the proper structure
      const processedRole = {
        ...role,
        reportRole: reportRole
      };
      
      return processedRole;
    });
  }
}

