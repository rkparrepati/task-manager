import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { WorkerManagementService } from '../../worker-management.service';
import { MatDialog } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { NotificationService } from 'src/app/services/notification.service';
import { CreateWorkerOverrideDialogComponent } from './create-worker-override-dialog/create-worker-override-dialog.component';

interface WorkerOverride {
  workerOverrideId?: string;
  workerId: string;
  startDate: string;
  endDate: string;
  startDateISO?: string;
  endDateISO?: string;
  isActive: boolean;
  properties: OverrideProperty[];
  audit?: {
    createdLoginId: string;
    createdDate: string;
    lastModifiedLoginId: string;
    lastModifiedDate?: string;
  };
  displayStatus?: string;
  isStartDateOpen?: boolean;
  isEndDateOpen?: boolean;
  errorMessage?: string;
  invalidEndDateMessage?: string;
}

interface OverrideProperty {
  propertyId?: string;
  stndWorkerOverridePropertyId?: string;
  propertyName: string;
  originalValue: string;
  overrideValue: string;
  endEffectiveDate?: string | null;
}

@Component({
  selector: 'app-worker-override-tab',
  templateUrl: './worker-override-tab.component.html',
  styleUrls: ['./worker-override-tab.component.scss'],
})
export class WorkerOverrideTabComponent implements OnInit, OnChanges {
  @Input() workerId: string = '';
  @Input() workerBase: any = {};
  @Input() editAddMode: boolean = false;
  @Output() overrideEditModeChange = new EventEmitter<boolean>();

  workerOverrides: WorkerOverride[] = [];
  newWorkerOverrides: WorkerOverride[] = [];
  includeInactiveOverriders: boolean = false;
  isOverrideRefreshedFromServer: boolean = false;
  isInitialLoad: boolean = true;
  editingId: string | null = null;
  overrideEditMode: boolean = false;
  isAddOverrideDialogOpen: boolean = false;

  // Date picker states
  todayDate: Date = new Date();
  sixMonthsFromTodayDate: Date = new Date();
  overrideStartDate: Date | null = null;
  overrideEndDate: Date | null = null;
  originalDateForComparison: number = 0;
  originalStartDateForComparison: number = 0;

  // Property to field mapping for highlighting
  propertyToFieldMap: { [key: string]: string } = {
    'Last Name': 'lastName',
    'First Name': 'firstName',
    'Middle Name': 'middleName',
    'Preferred First Name': 'preferredFirstName',
    'System Login Id': 'systemLoginId',
    'Email Address': 'emailAddress',
    'Position Title': 'jobClassCode',
    'Org Code': 'orgCode',
    'Grade': 'grade',
    'Grade Start Date': 'gradeStartDate',
    'Step': 'step',
    'Step Start Date': 'stepStartDate',
    'Pay Plan': 'payPlan',
    'Entrance on Duty Date': 'entranceDutyDate',
    'Accession Date': 'entranceDutyDate',
    'Tour of Duty': 'tourDuty',
    'Phone Book Title Code': 'phoneBookTitleCode',
    'Examiner Signatory Auth Level': 'signatoryAuthority',
    'OCC Series Code': 'occServicesCode',
    'Title Code': 'titleCode',
    'Type of Appointment': 'typeAppointment',
    'Position Sensitivity': 'positionSensitivity',
    'Leave Accrual': 'leaveAccural',
    'BUS Code': 'busCode',
    'Notes': 'notes',
    'Point of Contact/Notes': 'notes',
    'Supervisor': 'supervisor'
  };

  highlightedFields: { [key: string]: any } = {};

  constructor(
    private workerManagementService: WorkerManagementService,
    private dialog: MatDialog,
    private datePipe: DatePipe,
    private notificationService: NotificationService
  ) {
    // Initialize today's date for date picker minimum date
    this.todayDate.setHours(0, 0, 0, 0);

    // Initialize 6-month maximum date for end date picker
    this.sixMonthsFromTodayDate.setMonth(this.sixMonthsFromTodayDate.getMonth() + 6);
    this.sixMonthsFromTodayDate.setHours(0, 0, 0, 0);
  }

  ngOnInit(): void {
    if (this.workerId) {
      this.getOverrides();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['workerId'] && !changes['workerId'].firstChange) {
      if (this.workerId) {
        this.getOverrides();
      }
    }
  }

  /**
   * Fetch worker overrides from the server
   * @param useCache - Whether to use cached data (default: true for initial load, false for refresh after operations)
   */
  getOverrides(useCache: boolean = true): void {
    this.includeInactiveOverriders = this.includeInactiveOverriders || false;
    this.isInitialLoad = true;
    this.isOverrideRefreshedFromServer = true;
    console.log('Fetching the initial data for the table')
    this.workerManagementService.getWorkerOverrides(this.workerId, this.includeInactiveOverriders, useCache)
      .subscribe({
        next: (response: any) => {
          // Handle case where API returns object with different property names
          console.log("this is the response", response)
          let overrideArray: WorkerOverride[] = [];
          if (Array.isArray(response)) {
            overrideArray = response;
          } else if (response && Array.isArray(response.workerOverrides)) {
            // API returns { totalCount: X, workerOverrides: [...] }
            overrideArray = response.workerOverrides;
          } else if (response && Array.isArray(response.data)) {
            overrideArray = response.data;
          } else if (response && Array.isArray(response.results)) {
            overrideArray = response.results;
          }

          console.log('Override array extracted:', overrideArray);
          this.workerOverrides = overrideArray;
          this.checkAndDisplayOverrideMessage(overrideArray);
          
          // Format dates and set display status
          this.workerOverrides = overrideArray.map((worker: WorkerOverride) => {
            worker.startDateISO = worker.startDate;
            worker.endDateISO = worker.endDate;
            worker.startDate = this.datePipe.transform(worker.startDate, 'MM/dd/yyyy') || '';
            worker.endDate = this.datePipe.transform(worker.endDate, 'MM/dd/yyyy') || '';

            // Format audit dates
            if (worker.audit) {
              worker.audit.createdDate = this.datePipe.transform(worker.audit.createdDate, 'MM/dd/yyyy') || '';
              if (worker.audit.lastModifiedDate) {
                worker.audit.lastModifiedDate = this.datePipe.transform(worker.audit.lastModifiedDate, 'MM/dd/yyyy') || '';
              }
            }

            if (worker.properties) {
              worker.properties.forEach((prop: OverrideProperty) => {
                if (prop.propertyName && prop.propertyName.indexOf('Date') > -1) {
                  prop.overrideValue = this.datePipe.transform(prop.overrideValue, 'MM/dd/yyyy') || '';
                  prop.originalValue = this.datePipe.transform(prop.originalValue, 'MM/dd/yyyy') || '';
                }
              });
            }

            if (worker.isActive) {
              worker.displayStatus = 'Active';
            } else {
              const hasEndEffectiveDate = worker.properties?.some(p => p.endEffectiveDate !== null && p.endEffectiveDate !== undefined);
              worker.displayStatus = hasEndEffectiveDate ? 'Inactive' : 'Inactive(Deleted)';
            }

            return worker;
          });

          this.updateHighlightedFields();

          // Reset isInitialLoad after 100ms
          setTimeout(() => {
            this.isInitialLoad = false;
          }, 100);
        },
        error: (error) => {
          console.error('Error fetching overrides:', error);
        }
      });
  }

  /**
   * Check if worker has active overrides and display message
   */
  checkAndDisplayOverrideMessage(overrides: any): void {
    // Handle case where API returns object with different property names
    let overrideArray: WorkerOverride[] = [];
    if (Array.isArray(overrides)) {
      overrideArray = overrides;
    } else if (overrides && typeof overrides === 'object' && Array.isArray(overrides.workerOverrides)) {
      // API returns { totalCount: X, workerOverrides: [...] }
      overrideArray = overrides.workerOverrides;
    } else if (overrides && typeof overrides === 'object' && Array.isArray(overrides.data)) {
      overrideArray = overrides.data;
    } else if (overrides && typeof overrides === 'object' && Array.isArray(overrides.results)) {
      overrideArray = overrides.results;
    }

    if (!overrideArray || overrideArray.length === 0) {
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const override of overrideArray) {
      if (!override.isActive) continue;

      const startDate = new Date(override.startDateISO || override.startDate);
      startDate.setHours(0, 0, 0, 0);

      const endDate = new Date(override.endDateISO || override.endDate);
      endDate.setHours(0, 0, 0, 0);

      if (today >= startDate && today <= endDate) {
        this.notificationService.showInfo('Worker has active overrides');
        break;
      }
    }
  }

  /**
   * Update highlighted fields based on active overrides
   */
  updateHighlightedFields(): void {
    this.highlightedFields = {};

    if (!this.workerOverrides || this.workerOverrides.length === 0) {
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const override of this.workerOverrides) {
      if (!override.isActive) continue;

      const startDate = new Date(override.startDateISO || override.startDate);
      startDate.setHours(0, 0, 0, 0);

      const endDate = new Date(override.endDateISO || override.endDate);
      endDate.setHours(0, 0, 0, 0);

      if (today >= startDate && today <= endDate) {
        if (override.properties && override.properties.length > 0) {
          for (const property of override.properties) {
            const fieldId = this.propertyToFieldMap[property.propertyName];
            if (fieldId) {
              this.highlightedFields[fieldId] = {
                propertyName: property.propertyName,
                overrideValue: property.overrideValue,
                originalValue: property.originalValue,
                startDate: override.startDate,
                endDate: override.endDate
              };
            }
          }
        }
      }
    }
  }

  /**
   * Check if a specific field should be highlighted
   */
  isFieldHighlighted(fieldId: string): boolean {
    return this.highlightedFields && this.highlightedFields[fieldId] !== undefined;
  }

  /**
   * Check if a date is past or today
   */
  isPastOrToday(dateString: string): boolean {
    if (!dateString) return false;

    const checkDate = new Date(dateString);
    checkDate.setHours(0, 0, 0, 0);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return checkDate <= today;
  }

  /**
   * Format override value for display
   */
  formatOverrideValue(value: any): string {
    if (value === null || value === undefined) return '';

    if (typeof value === 'string') return value;

    if (typeof value === 'object') {
      if (value.description) return value.description;
      if (value.value) return value.value;
      if (value.displayItem) return value.displayItem;
      if (value.acronym) return value.acronym;
      return '';
    }

    return String(value);
  }

  /**
   * Handle start date change from date picker
   */
  onStartDateChange(dateValue: any): void {
    if (dateValue) {
      const dateObj = new Date(dateValue);
      this.overrideStartDate = dateObj;
      this.originalStartDateForComparison = dateObj.getTime();
    }
  }

  /**
   * Handle end date change from date picker
   */
  onEndDateChange(dateValue: any): void {
    if (dateValue) {
      const dateObj = new Date(dateValue);
      this.overrideEndDate = dateObj;
      this.originalDateForComparison = dateObj.getTime();
    }
  }

  /**
   * Add a new override by opening the dialog
   * Follows the legacy pattern from workerUpdate.controller.js (lines 1723-1830)
   * After dialog closes with saved data, refreshes the override list from server
   */
  addOverride(): void {
    if (this.isAddOverrideDialogOpen) {
      return;
    }

    this.isAddOverrideDialogOpen = true;

    // Open dialog immediately without waiting for API call
    const dialogRef = this.dialog.open(CreateWorkerOverrideDialogComponent, {
      width: '900px',
      height:'500px',
      disableClose:true,
      data: {
        workerId: this.workerId,
        workerBaseDetails: {
          worker: this.workerBase.worker,
          organizations: this.workerBase.organizations,
          workerAssignments: this.workerBase.workerAssignments,
          workerRoles: this.workerBase.workerRoles
        },
        existingOverrides: this.workerOverrides || []
      }
    });

    // Load worker references in the background and pass to dialog component
    this.workerManagementService.getWorkerDetailsReferences().subscribe(
      (response: any) => {
        // Prepare workerBase with references data
        const workerBaseWithReferences = {
          ...this.workerBase,
          references: {
            grades: response.grades?.results || [],
            steps: response.steps?.results || [],
            payplans: response.payPlans?.results || [],
            tourOfDuties: response.tourOfDuties?.results || [],
            examSigs: response.examSigs?.results || [],
            posSensCodes: response.posSensCodes?.results || [],
            leaveAccruals: response.leaveAccruals?.results || [],
            appointmentTypes: response.appointmentTypes?.results || [],
            occCodes: response.occCodes?.results || [],
            busCodes: response.busCodes?.results || [],
            jobClasses: response.jobClasses?.results || [],
            titleCodes: response.titleCodes?.results || []
          }
        };

        // Update the dialog component's workerBase with references
        if (dialogRef.componentInstance) {
          dialogRef.componentInstance.workerBase = workerBaseWithReferences;
          dialogRef.componentInstance.updateReferences();
        }
      },
      (error: any) => {
        console.error('Error loading worker references:', error);
        // Dialog is already open, continue with basic workerBase
      }
    );

    dialogRef.afterClosed().subscribe((result) => {
      this.isAddOverrideDialogOpen = false;
      
      console.log('Dialog closed with result:', result);
      console.log('Current this.workerId:', this.workerId);
      console.log('Result workerId:', result?.workerId);
      
      // Only refresh if result exists (meaning override was saved)
      if (result) {
        // Always refresh the override list after dialog closes with result
        // This ensures newly saved overrides are displayed
        // Disable cache to get fresh data from server
        console.log('Refreshing overrides after add operation');
        this.getOverrides(false);
        
        // Show success notification
        this.notificationService.showSuccess('Override created successfully');
      }
    });
  }

  /**
   * Edit an existing override
   */
  editOverride(overrideObject: WorkerOverride): void {
    this.editingId = overrideObject.workerOverrideId || '';
    this.overrideEditMode = true;
    
    // Use ISO dates for proper Date object creation
    // startDateISO and endDateISO contain the original ISO format dates
    const endDateObj = new Date(overrideObject.endDateISO || overrideObject.endDate);
    const startDateObj = new Date(overrideObject.startDateISO || overrideObject.startDate);
    
    this.overrideEndDate = endDateObj;
    this.originalDateForComparison = endDateObj.getTime();
    this.overrideStartDate = startDateObj;
    this.originalStartDateForComparison = startDateObj.getTime();
    
    overrideObject.isStartDateOpen = false;
    overrideObject.isEndDateOpen = false;

    this.overrideEditModeChange.emit(true);
  }

  /**
   * Save override changes
   */
  saveOverride(overrideObject: WorkerOverride): void {
    if (!this.editingId) return;

    overrideObject.endDate = this.datePipe.transform(this.overrideEndDate, 'MM/dd/yyyy') || '';
    overrideObject.startDate = this.datePipe.transform(this.overrideStartDate, 'MM/dd/yyyy') || '';

    // Format dates to ISO 8601 format
    const startDateISO = this.overrideStartDate
      ? new Date(this.overrideStartDate).toISOString()
      : (overrideObject.startDateISO || overrideObject.startDate);
    const endDateISO = this.overrideEndDate
      ? new Date(this.overrideEndDate).toISOString()
      : (overrideObject.endDateISO || overrideObject.endDate);

    const result = {
      workerId: overrideObject.workerId,
      startDate: startDateISO,
      endDate: endDateISO,
      isActive: overrideObject.isActive,
      properties: overrideObject.properties.map((prop: OverrideProperty) => ({
        stndWorkerOverridePropertyId: prop.propertyId || prop.stndWorkerOverridePropertyId,
        overrideValue: prop.overrideValue,
        originalValue: prop.originalValue
      }))
    };

    this.workerManagementService.updateOverrideId(this.editingId, result)
      .subscribe({
        next: () => {
          // Disable cache to get fresh data from server after update
          this.getOverrides(false);
          this.editingId = null;
          this.overrideEditMode = false;
          this.overrideEditModeChange.emit(false);
          this.notificationService.showSuccess('Override updated successfully');
        },
        error: (error) => {
          console.error('Error saving override:', error);
          this.notificationService.showError('Error saving override');
        }
      });
  }

  /**
   * Cancel edit mode
   */
  cancelEdit(): void {
    this.editingId = null;
    this.overrideEditMode = false;
    this.overrideEditModeChange.emit(false);
  }

  /**
   * Reset override to original values
   */
  resetOverride(overrideObject: WorkerOverride): void {
    this.overrideEndDate = new Date(this.originalDateForComparison);
  }

  /**
   * Delete an override
   */
  deleteOverride(workerOverrideId: string): void {
    let overrideToDelete: WorkerOverride | null = null;

    if (this.workerOverrides && this.workerOverrides.length > 0) {
      overrideToDelete = this.workerOverrides.find(o => o.workerOverrideId === workerOverrideId) || null;
    }

    if (!overrideToDelete && this.newWorkerOverrides && this.newWorkerOverrides.length > 0) {
      overrideToDelete = this.newWorkerOverrides.find(o => o.workerOverrideId === workerOverrideId) || null;
    }

    if (!overrideToDelete) {
      this.notificationService.showError('Override not found');
      return;
    }

    const propertyNames = overrideToDelete.properties
      .map(prop => prop.propertyName || 'Unknown Property')
      .join(', ');

    // Format dates to ISO 8601 format
    const startDateISO = overrideToDelete.startDateISO || overrideToDelete.startDate;
    const endDateISO = overrideToDelete.endDateISO || overrideToDelete.endDate;

    const payload = {
      workerId: overrideToDelete.workerId,
      startDate: startDateISO,
      endDate: endDateISO,
      isActive: false,
      properties: overrideToDelete.properties.map((prop: OverrideProperty) => ({
        stndWorkerOverridePropertyId: prop.propertyId || prop.stndWorkerOverridePropertyId,
        overrideValue: prop.overrideValue,
        originalValue: prop.originalValue
      }))
    };

    this.workerManagementService.deleteOverride(workerOverrideId, payload)
      .subscribe({
        next: () => {
          // Disable cache to get fresh data from server after delete
          this.getOverrides(false);
          this.notificationService.showSuccess(`${propertyNames} Override deleted successfully`);
        },
        error: (error) => {
          console.error('Error deleting override:', error);
          this.notificationService.showError('Error deleting override');
        }
      });
  }

  /**
   * Filter inactive overriders
   */
  filterInactiveOverriders(): void {
    this.getOverrides();
  }
}
