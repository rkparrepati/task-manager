import { Component, ViewChild, OnInit, ChangeDetectorRef } from '@angular/core';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { WorkerManagementService } from '../worker-management.service';
import { WorkerValidationsService, ValidationError } from '../worker-validations.service';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { Element } from '@angular/compiler';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ConfInfoTabComponent } from './conf-info-tab/conf-info-tab.component';
import { PrimaryInfoTabComponent } from './primary-info-tab/primary-info-tab.component';
import { DetailsInfoTabComponent } from './details-info-tab/details-info-tab.component';
import { FormUtilityService } from 'src/app/services/form-utility.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { DialogComponent } from '../../relocation-management/dialog/dialog.component';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { NotificationService } from 'src/app/services/notification.service';
import { forkJoin, of, Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Component({
  selector: 'app-add-worker',
  templateUrl: './add-worker.component.html',
  styleUrls: ['./add-worker.component.scss', './validation-error-styles.scss'],
})
export class AddWorkerComponent implements OnInit {
  public addWorkerFormGroup!: FormGroup;

  hideMessage: boolean = true;
  returnCode: string | number = '';
  returnMessage: string = '';
  workerRole: any;
  appTitle: string = 'Add a new worker';
  applicationType: any;
  isOrganizationLocationEditMode: any;
  workerEmploymentType: any = 'E'; // Default to Employee, will be set to 'C' for contractors in constructor
  userRoles: any = ['InfraAdmin', 'InfraOfficeCoordinator', 'InfraContractorAdmin'];
  workerBase: any = {
    workerAssignments: [],
    workerTelecommunicationHistory: [],
    workerRoles: [],
    workerCommunications: [],
    telecomTypes: [],
    teleworkPrograms: [],
    palmLocations: [],
    worker: {},
    workerSecure: null,
    workerAccession: null
  };
  validationBooleans: any = {};
  validationErrorMessages: string[] = [];
  applicationTypeLowerCase = 'worker';
  editAddMode: boolean = false;
  referenceData: any = {};
  showWait: boolean = false;
  hasActiveOverrides: boolean = false;
  private initialWorkerBase: any = null;
  communicationEditMode: boolean = false;
  organizationLocationEditMode: boolean = false;
  // For ACME navbar component
  main = { creationDate: new Date() };
  // Scroll position preservation to prevent jumping on accordion expansion
  private lastScrollPosition: number = 0;

  public primaryInfoTab: FormGroup = new FormGroup({});
  public conInfoTab: FormGroup = new FormGroup({});
  public detailsInfo: FormGroup = new FormGroup({});
  public assignMentWorker: FormGroup = new FormGroup({});
  public communicationWorker: FormGroup = new FormGroup({});
  public roleassignmentWorker: FormGroup = new FormGroup({});
  public expandConfInfoTab: boolean = false;
  public showWorkerRoleAssignmentTab: boolean = true;

  @ViewChild(PrimaryInfoTabComponent) primaryInfoTabComponent!: PrimaryInfoTabComponent;
  @ViewChild(ConfInfoTabComponent) confInfoTabComponent!: ConfInfoTabComponent;
  @ViewChild(DetailsInfoTabComponent) detailsInfoTabComponent!: DetailsInfoTabComponent;

  constructor(
    public workerManagementService: WorkerManagementService,
    private httpService: HttpService,
    private appService: AppService,
    private formUtility: FormUtilityService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private authService: AuthorizationService,
    private notificationService: NotificationService,
    private workerValidationsService: WorkerValidationsService,
    private cdr: ChangeDetectorRef,
    private breadcrumbService: BreadcrumbService
  ) {
    // CRITICAL FIX: Initialize applicationType in constructor from route snapshot
    // This prevents flickering by setting the correct type before template renders
    const routeSnapshot = this.route.snapshot;
    const workerTypeFromRoute = routeSnapshot.params['workerType'];
    
    if (workerTypeFromRoute) {
      this.applicationType = workerTypeFromRoute;
      this.applicationTypeLowerCase = workerTypeFromRoute.toLowerCase();
      
      // Set editAddMode if workerId exists
      if (routeSnapshot.params['workerId']) {
        this.editAddMode = true;
      }
      
      // Set appropriate title and employment type based on worker type
      // CRITICAL: Set workerEmploymentType IMMEDIATELY for field visibility checks
      if (workerTypeFromRoute === 'Contractor') {
        this.appTitle = this.editAddMode ? 'Update contractor' : 'Add a new contractor';
        this.workerEmploymentType = 'C';
      } else {
        this.appTitle = this.editAddMode ? 'Update worker' : 'Add a new worker';
        this.workerEmploymentType = 'E';
      }
      
      // CRITICAL: Set breadcrumb after a micro-task to ensure it overrides route's static breadcrumb
      // Use setTimeout to ensure it runs after route's static breadcrumb is applied
      setTimeout(() => {
        this.updateBreadcrumbForWorkerType(workerTypeFromRoute);
        this.cdr.detectChanges();
      }, 0);
    }
    
    this.initilaiseForm();
    
    // CRITICAL FIX: Prevent accordion from scrolling page
    // Disable scrollIntoView on accordion elements
    this.disableAccordionScroll();
  }

  /**
   * CRITICAL FIX: Disable scrollIntoView behavior on accordion elements
   * This prevents ngx-bootstrap accordion from scrolling the page
   */
  private disableAccordionScroll(): void {
    // Override scrollIntoView to prevent scroll on accordion elements
    const originalScrollIntoView = (Element.prototype as any).scrollIntoView;
    
    (Element.prototype as any).scrollIntoView = function(options?: boolean | ScrollIntoViewOptions) {
      // Check if this element is part of an accordion
      const isAccordionElement = (this as HTMLElement).closest('accordion-group') !== null;
      
      if (!isAccordionElement) {
        // Call original for non-accordion elements
        originalScrollIntoView.call(this, options);
      }
      // For accordion elements, do nothing - prevent scroll
    };
  }

  /**
   * Callback for ACME navbar component events
   */
  callBack(event: any): void {
    // Handle navbar callback events if needed
  }

  // Panel Visibility Methods
  isConfidentialInfoVisible(): boolean {
    // Show for admin users with Employee type, or for non-admin users when NOT a contractor
    const isAdminWithEmployee = (this.userRoles.includes('InfraHRAdmin') || this.userRoles.includes('InfraAdmin'))
      && this.workerEmploymentType === 'E';
    const isNonAdminNonContractor = !this.userRoles.includes('InfraHRAdmin')
      && !this.userRoles.includes('InfraAdmin')
      && this.applicationType !== 'Contractor';
    return isAdminWithEmployee || isNonAdminNonContractor;
  }

  isDetailsInfoVisible(): boolean {
    return !this.userRoles.includes('InfraRoomCoordinator');
  }

  isLocationAssignmentVisible(): boolean {
    // Hide for InfraHRAdmin
    if (this.userRoles.includes('InfraHRAdmin')) {
      return false;
    }
    return this.userRoles.includes('InfraAdmin')
      || this.userRoles.includes('InfraViewer')
      || this.userRoles.includes('InfraOfficeCoordinator')
      || this.userRoles.includes('InfraContractorAdmin');
  }

  isCommunicationAssignmentVisible(): boolean {
    // Hide for InfraHRAdmin
    if (this.userRoles.includes('InfraHRAdmin')) {
      return false;
    }
    return this.userRoles.includes('InfraAdmin')
      || this.userRoles.includes('InfraViewer')
      || this.userRoles.includes('InfraOfficeCoordinator')
      || this.userRoles.includes('InfraContractorAdmin');
  }

  isWorkerRoleAssignmentVisible(): boolean {
    return (this.userRoles.includes('InfraAdmin') || this.userRoles.includes('InfraViewer'))
      && this.applicationType === 'Worker';
  }

  isWorkerOverrideVisible(): boolean {
    // Hide worker override section for contractors
    const isContractor = this.workerEmploymentType === 'C';
    return (this.userRoles.includes('InfraAdmin') || this.userRoles.includes('InfraOverrideAdmin'))
      && this.editAddMode
      && !isContractor;
  }

  /**
   * Check if we are in contractor admin edit mode
   * This is used to hide the service account section for InfraContractorAdmin editing contractors
   */
  isContractorAdminEditMode(): boolean {
    return this.editAddMode &&
           this.workerRole === 'InfraContractorAdmin' &&
           this.workerEmploymentType === 'C';
  }

  onOverrideEditModeChange(isInEditMode: boolean): void {
    // Update the navbar's override edit mode tracking
    // This is used to prevent saving when override is being edited
  }
  ngOnInit(): void {
    // Hide ACME navbar message on page initialization using service
    this.workerManagementService.updateHideMessage(true);
    
    // CRITICAL FIX: Set applicationType immediately from route snapshot to prevent flickering
    // This ensures the correct type is set before any async operations or template rendering
    const routeSnapshot = this.route.snapshot;
    const workerTypeFromRoute = routeSnapshot.params['workerType'];
    if (workerTypeFromRoute) {
      this.applicationType = workerTypeFromRoute;
      this.applicationTypeLowerCase = workerTypeFromRoute.toLowerCase();
      
      // Set appropriate title based on worker type
      if (workerTypeFromRoute === 'Contractor') {
        this.appTitle = routeSnapshot.params['workerId'] ? 'Update contractor' : 'Add a new contractor';
        this.workerEmploymentType = 'C';
      } else {
        this.appTitle = routeSnapshot.params['workerId'] ? 'Update worker' : 'Add a new worker';
        this.workerEmploymentType = 'E';
      }
    }
    
    // Expand confidential information accordion on page load in ADD mode
    // This ensures the accordion is expanded when user first loads the add worker page
    if (!routeSnapshot.params['workerId']) {
      this.expandConfInfoTab = true;
    }
    
    // Initialize userRoles from actual user data (CRITICAL FIX)
    // This ensures validation uses the correct user roles instead of hardcoded defaults
    const userData = this.appService.getUserData();
    if (userData && userData.roles && userData.roles.length > 0) {
      this.userRoles = userData.roles;
    } else {
    }

    // Subscribe to service observables for ACME navbar component message handling
    this.workerManagementService.hideMessage$.subscribe((val: boolean) => {
      this.hideMessage = val;
      this.cdr.detectChanges();
    });

    this.workerManagementService.returnMessage$.subscribe((msg: string) => {
      this.returnMessage = msg;
      this.cdr.detectChanges();
    });

    this.workerManagementService.returnCode$.subscribe((code: string | number) => {
      this.returnCode = code;
      this.cdr.detectChanges();
    });

    this.workerManagementService.returnMessagesArray$.subscribe((messages: string[]) => {
      this.validationErrorMessages = messages;
      this.cdr.detectChanges();
    });

    // Load reference data first, then handle route params
    this.loadReferenceData().subscribe(
      () => {
        this.route.params.subscribe((params) => {
          if (params['workerId']) {
            // Edit mode - load worker details
            const workerId = params['workerId'];
            const workerNumber = params['workerNumber'];
            const workerType = params['workerType'];
            const type = params['type'];

            // Map short role codes to full role names for navbar tab visibility
            // 'A' = Admin (InfraAdmin), 'O' = Office Coordinator (InfraOfficeCoordinator),
            // 'CA' = Contractor Admin (InfraContractorAdmin), 'N' = Normal/View
            if (type === 'A') {
              this.workerRole = 'InfraAdmin';
            } else if (type === 'O') {
              this.workerRole = 'InfraOfficeCoordinator';
            } else if (type === 'CA') {
              this.workerRole = 'InfraContractorAdmin';
            } else {
              this.workerRole = type; // Keep original for other cases
            }
            
            // Load worker details from API
            this.loadWorkerDetails(workerId);
          } else {
            // Add mode
            const workerType = params['workerType'];
            
            // Set workerRole based on user's actual roles
            if (this.userRoles.includes('InfraAdmin')) {
              this.workerRole = 'InfraAdmin';
            } else if (this.userRoles.includes('InfraContractorAdmin')) {
              this.workerRole = 'InfraContractorAdmin';
            } else if (this.userRoles.includes('InfraHRAdmin')) {
              this.workerRole = 'InfraHRAdmin';
            } else if (this.userRoles.includes('InfraOfficeCoordinator')) {
              this.workerRole = 'InfraOfficeCoordinator';
            } else {
              this.workerRole = 'InfraAdmin'; // Default fallback
            }
          }
        });
      },
      (error) => {
      }
    );
  }

  private loadWorkerDetails(workerId: string): void {
    // Always fetch fresh data from API for edit mode
    this.workerManagementService.getWorkerById(workerId).subscribe(
      (response: any) => {
        // Merge the API response with the existing workerBase structure to preserve initialized arrays
        this.workerBase = {
          ...this.workerBase,
          ...response,
          // CRITICAL: Store the worker data in a 'worker' property for child components
          // The communication-assignment component expects workerBase.worker.employmentType
          worker: response,
          // Preserve the initialized arrays
          workerAssignments: this.workerBase.workerAssignments,
          workerTelecommunicationHistory: this.workerBase.workerTelecommunicationHistory,
          workerRoles: this.workerBase.workerRoles,
          workerCommunications: this.workerBase.workerCommunications,
          telecomTypes: this.workerBase.telecomTypes,
          teleworkPrograms: this.workerBase.teleworkPrograms,
          teleworkProgram: this.workerBase.teleworkProgram,
          palmLocations: this.workerBase.palmLocations
        };
        debugger
        this.setApplicationTypeFromWorker(response);
        
        // Check for active overrides to display the notice banner
        this.checkForActiveOverrides(workerId);
        // Load additional data if needed (secure data, assignments, accession data, etc.)
        // Prefill will be called from loadAdditionalWorkerData after all data is loaded
        this.loadAdditionalWorkerData(workerId);
      },
      (error: any) => {
        this.showErrorMessage('Failed to load worker details', error);
      }
    );
  }

  /**
   * Check if worker has active overrides
   * An override is active if its isActive flag is true and today's date falls between start and end dates
   */
  private checkForActiveOverrides(workerId: string): void {
    this.workerManagementService.getWorkerOverrides(workerId, false).subscribe(
      (response: any) => {
        // Handle case where API returns object with different property names
        let overrideArray: any[] = [];
        if (Array.isArray(response)) {
          overrideArray = response;
        } else if (response && Array.isArray(response.workerOverrides)) {
          overrideArray = response.workerOverrides;
        } else if (response && Array.isArray(response.data)) {
          overrideArray = response.data;
        } else if (response && Array.isArray(response.results)) {
          overrideArray = response.results;
        }

        // Check if any override is currently active
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        this.hasActiveOverrides = overrideArray.some((override: any) => {
          if (!override.isActive) return false;

          const startDate = new Date(override.startDate);
          startDate.setHours(0, 0, 0, 0);

          const endDate = new Date(override.endDate);
          endDate.setHours(0, 0, 0, 0);

          return today >= startDate && today <= endDate;
        });
      },
      (error: any) => {
        // If there's an error fetching overrides, assume no active overrides
        this.hasActiveOverrides = false;
      }
    );
  }

  /**
   * Event handler for when worker data is updated from child components
   * (e.g., after inactivate/activate operations)
   * Refreshes the worker data to get the latest lockControlNumber
   */
  onWorkerDataUpdated(): void {
    if (this.workerBase?.workerId) {
      this.loadWorkerDetails(this.workerBase.workerId.toString());
    }
  }

  private setApplicationTypeFromWorker(worker: any): void {
    if (worker.employmentType?.value === 'C') {
      this.workerEmploymentType = 'C';
      this.applicationTypeLowerCase = 'contractor';
      this.appTitle = 'Update contractor';
    } else {
      this.workerEmploymentType = 'E';
      this.applicationTypeLowerCase = 'worker';
      this.appTitle = 'Update worker';
    }
  }

  private loadAdditionalWorkerData(workerId: string): void {
    const workerIdNum = parseInt(workerId, 10);
    
    // Use forkJoin to wait for all critical data to load before prefilling form
    const observables: any = {
      assignments: this.workerManagementService.getWorkerAssignments(workerIdNum),
      telecommunications: this.workerManagementService.getWorkerTelecommunications(workerId),
      accession: this.workerManagementService.getWorkerAccession(workerId)
    };

    // Add secure data if user has permission
    if (this.canViewSecureData()) {
      observables.secureData = this.workerManagementService.getWorkerSecureData(workerId);
    }

    // Use catchError to handle individual observable errors gracefully
    const observablesWithErrorHandling: any = {};
    
    observablesWithErrorHandling.assignments = observables.assignments.pipe(
      catchError((error: any) => {
        return of(null);
      })
    );
    
    observablesWithErrorHandling.telecommunications = observables.telecommunications.pipe(
      catchError((error: any) => {
        return of(null);
      })
    );
    
    observablesWithErrorHandling.accession = observables.accession.pipe(
      catchError((error: any) => {
        return of(null);
      })
    );
    
    if (observables.secureData) {
      observablesWithErrorHandling.secureData = observables.secureData.pipe(
        catchError((error: any) => {
          return of(null);
        })
      );
    }

    forkJoin(observablesWithErrorHandling).subscribe(
      (results: any) => {
        // Process assignments - API returns {meta: {...}, results: Array}
        if (results.assignments) {
          // The API returns {meta: {...}, results: Array} where results contains assignment objects
          const assignmentsArray = results.assignments.results || results.assignments;
          
          // Filter assignments into their respective categories
          const organizationLocations: any[] = [];
          const organizationRoles: any[] = [];
          
          if (Array.isArray(assignmentsArray)) {
            assignmentsArray.forEach((assignment: any, idx: number) => {
              // Organization location assignments - include all assignments with workerOrganization
              if (assignment.workerOrganization) {
                // Ensure workerOrganizationId is set from the workerOrganization object
                if (!assignment.workerOrganization.workerOrganizationId && assignment.workerOrganization.id) {
                  assignment.workerOrganization.workerOrganizationId = assignment.workerOrganization.id;
                }
                // Also check if it's at the root level of workerOrganization
                if (!assignment.workerOrganization.workerOrganizationId && assignment.workerOrganizationId) {
                  assignment.workerOrganization.workerOrganizationId = assignment.workerOrganizationId;
                }
                organizationLocations.push(assignment);
              }
            });
          }
          
          // Create new object references to trigger change detection in child components
          // IMPORTANT: Preserve the worker object that was merged from the API response
          // Also preserve telework program data from the worker object
          this.workerBase = {
            ...this.workerBase,
            worker: this.workerBase.worker, // Explicitly preserve worker object with telework program data
            workerAssignments: organizationLocations,
            workerRoles: organizationRoles,
            // Ensure telework program data is accessible at the top level if needed
            teleworkProgram: this.workerBase.worker?.teleworkProgram
          };
          
          // Load detailed location information for each assignment
          if (this.workerBase.workerAssignments.length > 0) {
            this.loadLocationDetailsForAssignments(workerId, this.workerBase.workerAssignments);
          }
          
          // Load detailed role information
          if (this.workerBase.workerRoles.length > 0) {
            this.loadWorkerRoleData(workerId, this.workerBase.workerRoles);
          }
        }

        // Process telecommunications data from dedicated endpoint
        if (results.telecommunications) {
          const telecomArray = results.telecommunications.results || results.telecommunications;
          
          if (Array.isArray(telecomArray)) {
            this.workerBase.workerTelecommunicationHistory = telecomArray;
            
            // Load detailed communication information
            if (this.workerBase.workerTelecommunicationHistory.length > 0) {
              this.loadCommunicationDetails(workerId, this.workerBase.workerTelecommunicationHistory);
            }
          }
        }

        // Process accession data
        if (results.accession) {
          this.workerBase.workerAccession = results.accession;
        }

        // Process secure data
        if (results.secureData) {
          this.workerBase.workerSecure = results.secureData;
        }

        // Now prefill the form after all data is loaded
        setTimeout(() => {
          this.prefillWorkerForm(this.workerBase);
        }, 500);
      },
      (error: any) => {
        // Still attempt to prefill with whatever data we have
        setTimeout(() => {
          this.prefillWorkerForm(this.workerBase);
        }, 500);
      }
    );
  }

  private loadLocationDetailsForAssignments(workerId: string, assignments: any[]): void {
    if (!assignments || assignments.length === 0) {
      return;
    }

    assignments.forEach((assignment: any, idx: number) => {
      // Initialize assignmentLocation if it doesn't exist
      if (!assignment.assignmentLocation) {
        assignment.assignmentLocation = {};
      }
      
      // Load assignment location details - check if we have a locationId
      const locationId = assignment.assignmentLocation?.locationId || assignment.locationId;
      if (locationId) {
        this.workerManagementService.getLocationDetails(locationId).subscribe(
          (locationDetails: any) => {
            // Merge the location details into assignmentLocation
            assignment.assignmentLocation = { ...assignment.assignmentLocation, ...locationDetails };
            // Also store in location property for compatibility
            assignment.location = {
              building: {
                code: locationDetails?.building?.code || locationDetails?.buildingCode || locationDetails?.code,
                floorNumber: locationDetails?.building?.floorNumber || locationDetails?.floorNumber
              },
              corridorId: locationDetails?.corridorId,
              suiteId: locationDetails?.suiteId,
              roomId: locationDetails?.roomId,
              zoneId: locationDetails?.zoneId
            };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load mail stop location details
      if (!assignment.mailLocation) {
        assignment.mailLocation = {};
      }
      const mailLocationId = assignment.mailLocation?.locationId || assignment.mailLocationId;
      if (mailLocationId) {
        this.workerManagementService.getLocationDetails(mailLocationId).subscribe(
          (mailStopDetails: any) => {
            assignment.mailLocation = { ...assignment.mailLocation, ...mailStopDetails };
            // Ensure building object structure is preserved
            if (mailStopDetails?.building) {
              assignment.mailLocation.building = mailStopDetails.building;
            }
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load PALM location details
      if (!assignment.palmLocation) {
        assignment.palmLocation = {};
      }
      const palmLocationId = assignment.palmLocation?.legacyLocationId || assignment.palmLocationId;
      if (palmLocationId) {
        this.workerManagementService.getPalmLocationDetails(palmLocationId).subscribe(
          (palmDetails: any) => {
            assignment.palmLocation = { ...assignment.palmLocation, ...palmDetails };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load organization details
      if (assignment.workerOrganization && assignment.workerOrganization.organization && assignment.workerOrganization.organization.id) {
        const organizationId = assignment.workerOrganization.organization.id;
        this.workerManagementService.getOrganizationDetails(organizationId).subscribe(
          (orgDetails: any) => {
            assignment.workerOrganization.organization = { ...assignment.workerOrganization.organization, ...orgDetails };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }
    });
  }

  private loadCommunicationDetails(workerId: string, communications: any[]): void {
    if (!communications || communications.length === 0) {
      return;
    }

    communications.forEach((communication: any, idx: number) => {
      // Initialize assignmentLocation if it doesn't exist
      if (!communication.assignmentLocation) {
        communication.assignmentLocation = {};
      }
      
      // Load assignment location details for the communication
      const locationId = communication.assignmentLocation?.locationId || communication.locationId;
      if (locationId) {
        this.workerManagementService.getLocationDetails(locationId).subscribe(
          (locationDetails: any) => {
            communication.assignmentLocation = { ...communication.assignmentLocation, ...locationDetails };
            // Ensure building object structure is preserved
            if (locationDetails?.building) {
              communication.assignmentLocation.building = locationDetails.building;
            }
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load mail stop location details for communication
      if (!communication.mailLocation) {
        communication.mailLocation = {};
      }
      const mailLocationId = communication.mailLocation?.locationId || communication.mailLocationId;
      if (mailLocationId) {
        this.workerManagementService.getLocationDetails(mailLocationId).subscribe(
          (mailStopDetails: any) => {
            communication.mailLocation = { ...communication.mailLocation, ...mailStopDetails };
            // Ensure building object structure is preserved
            if (mailStopDetails?.building) {
              communication.mailLocation.building = mailStopDetails.building;
            }
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load PALM location details for communication
      if (!communication.palmLocation) {
        communication.palmLocation = {};
      }
      const palmLocationId = communication.palmLocation?.legacyLocationId || communication.palmLocationId;
      if (palmLocationId) {
        this.workerManagementService.getPalmLocationDetails(palmLocationId).subscribe(
          (palmDetails: any) => {
            communication.palmLocation = { ...communication.palmLocation, ...palmDetails };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }

      // Load organization details for communication
      if (communication.workerOrganization && communication.workerOrganization.organization && communication.workerOrganization.organization.id) {
        const organizationId = communication.workerOrganization.organization.id;
        this.workerManagementService.getOrganizationDetails(organizationId).subscribe(
          (orgDetails: any) => {
            communication.workerOrganization.organization = { ...communication.workerOrganization.organization, ...orgDetails };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }
    });
  }

  private loadWorkerRoleData(workerId: string, roles: any[]): void {
    if (!roles || roles.length === 0) {
      return;
    }

    // Load primary worker organization roles
    // This requires fetching the worker's organizations first, then getting roles for the primary organization
    this.workerManagementService.getWorkerOrganizations(workerId).subscribe(
      (organizations: any) => {
        // Find the primary organization
        const primaryOrg = organizations.find((org: any) => org.primaryOrganizationIndicator);
        
        if (primaryOrg && primaryOrg.organization && primaryOrg.organization.id) {
          const primaryOrgId = primaryOrg.organization.id;
          
          // Load organization report roles for the primary organization
          this.workerManagementService.getWorkerOrganizationRoles(primaryOrgId).subscribe(
            (orgRoles: any) => {
              this.workerBase.organizationWorkerRoles = orgRoles;
              // Trigger change detection
              this.workerBase = { ...this.workerBase };
            },
            (error: any) => {
            }
          );
        }
      },
      (error: any) => {
      }
    );

    // Load details for each role
    roles.forEach((role: any, idx: number) => {
      // Initialize workerOrganization if it doesn't exist
      if (!role.workerOrganization) {
        role.workerOrganization = { organization: {} };
      }
      if (!role.workerOrganization.organization) {
        role.workerOrganization.organization = {};
      }
      
      // If role has organization info, load organization details
      const organizationId = role.workerOrganization?.organization?.id || role.organizationId;
      if (organizationId) {
        this.workerManagementService.getOrganizationDetails(organizationId).subscribe(
          (orgDetails: any) => {
            role.workerOrganization.organization = { ...role.workerOrganization.organization, ...orgDetails };
            // Trigger change detection
            this.workerBase = { ...this.workerBase };
          },
          (error: any) => {
          }
        );
      }
    });
  }

  /**
   * Updates the breadcrumb dynamically based on the worker type (Contractor or Worker)
   * For contractors: "Contractor Management > Add a new contractor/Update contractor"
   * For employees: "Worker Management > Add a new worker/Update worker"
   */
  private updateBreadcrumbForWorkerType(workerType: string): void {
    const isAddMode = !this.editAddMode;
    let actionTitle: string;
    
    if (workerType === 'Contractor') {
      actionTitle = isAddMode ? 'Add a new contractor' : 'Update contractor';
    } else {
      actionTitle = isAddMode ? 'Add a new worker' : 'Update worker';
    }
    
    const breadcrumbData = workerType === 'Contractor'
      ? [
          {
            title: 'CEDR INFRA Home',
            url: '/app/home',
            tooltip: 'Go to CEDR INFRA home',
          },
          {
            title: 'Contractor Management',
            url: '/app/workerManagement/Contractor',
            tooltip: 'Go to Contractor management search',
          },
          {
            title: actionTitle,
            isActive: true,
          },
        ]
      : [
          {
            title: 'CEDR INFRA Home',
            url: '/app/home',
            tooltip: 'Go to CEDR INFRA home',
          },
          {
            title: 'Worker Management',
            url: '/app/worker-management',
            tooltip: 'Go to Worker management search',
          },
          {
            title: actionTitle,
            isActive: true,
          },
        ];

    // Update the breadcrumb via the BreadcrumbService
    this.breadcrumbService.setBreadcrumb(breadcrumbData);
  }

  public canViewSecureData(): boolean {
    return this.workerManagementService.canViewSecureData(
      this.userRoles,
      this.workerEmploymentType
    );
  }

  // private loadWorkerDetails(workerId: string, workerNumber: string, workerType: string, type: string): void {
  //   // Fetch worker details from the service
  //   this.workerManagementService.getWorkerById(workerId).subscribe(
  //     (response: any) => {
  //       this.workerBase = response;
  //       this.applicationType = workerType;
  //       this.workerRole = type; // 'A' for Admin, 'N' for Office Coordinator
  //       // Prefill the form with worker details after a delay to ensure child components have initialized
  //       setTimeout(() => {
  //         this.prefillWorkerForm(response);
  //       }, 500);
  //     },
  //     (error: any) => {
  //       
  //     }
  //   );
  // }

  /**
   * Convert date from various formats to yyyy-MM-dd format required by HTML5 date inputs
   * Handles: MM/DD/YYYY, ISO 8601 (yyyy-MM-ddTHH:mm:ss.sssZ), and yyyy-MM-dd
   *
   * CRITICAL FIX: For ISO 8601 UTC dates, extract the date portion directly from the string
   * to avoid timezone offset issues. When parsing "2008-02-19T05:00:00.000Z" in EST timezone,
   * JavaScript converts it to 2008-02-18, losing a day. By extracting "2008-02-19" directly,
   * we preserve the intended date regardless of the user's timezone.
   */
  private convertDateToHtml5Format(dateValue: any): string | null {
    if (!dateValue) {
      return null;
    }

    try {
      // If it's an ISO 8601 string (e.g., "2008-02-19T05:00:00.000Z")
      // Extract the date portion directly to avoid timezone offset issues
      if (typeof dateValue === 'string' && dateValue.includes('T')) {
        const isoDateMatch = dateValue.match(/^(\d{4}-\d{2}-\d{2})/);
        if (isoDateMatch) {
          return isoDateMatch[1]; // Return yyyy-MM-dd directly
        }
      }
      let date: Date;

      // If it's already a Date object
      if (dateValue instanceof Date) {
        date = dateValue;
      }
      // If it's a string in MM/DD/YYYY format (e.g., "01/08/1984")
      else if (typeof dateValue === 'string' && /^\d{2}\/\d{2}\/\d{4}$/.test(dateValue)) {
        const [month, day, year] = dateValue.split('/');
        date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      }
      // If it's already in yyyy-MM-dd format
      else if (typeof dateValue === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dateValue)) {
        return dateValue;
      }
      // Try parsing as a generic date string
      else {
        date = new Date(dateValue);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        return null;
      }

      // Format as yyyy-MM-dd
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      
      return `${year}-${month}-${day}`;
    } catch (error) {
      return null;
    }
  }

  /**
   * Format SSN to ###-##-#### pattern for display
   * Handles various input formats: raw digits, already formatted, or empty
   */
  private formatSSNForDisplay(ssn: string): string {
    if (!ssn) {
      return '';
    }

    // Remove any existing formatting
    const digitsOnly = ssn.replace(/\D/g, '').substring(0, 9);

    // Format as ###-##-####
    if (digitsOnly.length <= 3) {
      return digitsOnly;
    } else if (digitsOnly.length <= 5) {
      return digitsOnly.slice(0, 3) + '-' + digitsOnly.slice(3);
    } else {
      return digitsOnly.slice(0, 3) + '-' + digitsOnly.slice(3, 5) + '-' + digitsOnly.slice(5, 9);
    }
  }

  private prefillWorkerForm(workerData: any): void {
    // Prefill primary info tab
    if (this.primaryInfoTab && Object.keys(this.primaryInfoTab.controls).length > 0) {
      const primaryInfoData: any = {
        firstName: workerData.givenName,
        lastName: workerData.familyName,
        middleName: workerData.middleName,
        // Use preferredFirstName if available, otherwise fallback to givenName
        preferredFirstName: workerData.preferredFirstName || workerData.givenName,
        loginId: workerData.loginId,
        emailAddress: workerData.emailAddress,
      };
      // For contractors, also populate birthDate and ssnLast2Digits from secure data
      if (this.workerEmploymentType === 'C' && this.workerBase.workerSecure) {
        const secureData = this.workerBase.workerSecure;
        const formattedDob = this.convertDateToHtml5Format(secureData.birthDate);
        
        primaryInfoData.birthDate = formattedDob;
        primaryInfoData.ssnLast2Digits = secureData.contractorSocialSecurity;
      }

      this.primaryInfoTab.patchValue(primaryInfoData);
    }

    // Prefill confirmation info tab (data comes from workerSecure)
    if (this.conInfoTab && Object.keys(this.conInfoTab.controls).length > 0 && this.workerBase.workerSecure) {
      const secureData = this.workerBase.workerSecure;
      
      // Convert date of birth to HTML5 format (YYYY-MM-DD for date input)
      const formattedDob = this.convertDateToHtml5Format(secureData.birthDate);
      
      // Format SSN to ###-##-#### pattern
      const rawSSN = secureData.employeeSocialSecurity || secureData.contractorSocialSecurity || '';
      const formattedSSN = this.formatSSNForDisplay(rawSSN);
      
      this.conInfoTab.patchValue({
        ssn: formattedSSN,
        dateOfBirth: formattedDob,
        birthCityName: secureData.birthCityName,
        // Use birthCountryCode and birthStateCode directly instead of nested .value
        birthCountry: secureData.birthCountryCode || secureData.birthCountry?.value,
        birthState: secureData.birthStateCode || secureData.birthState?.value,
      });
      
      // Mark SSN as valid and pristine after prefill to avoid false validation errors
      const ssnControl = this.conInfoTab.get('ssn');
      if (ssnControl && formattedSSN) {
        setTimeout(() => {
          ssnControl.markAsUntouched();
          ssnControl.markAsPristine();
          ssnControl.setErrors(null);
        }, 0);
      }
    }

    // Prefill details info tab
    if (this.detailsInfo && Object.keys(this.detailsInfo.controls).length > 0) {
      // Convert dates to HTML5 format
      const formattedEntranceDutyDate = this.convertDateToHtml5Format(workerData.lifecycle?.beginDate);
      const formattedGradeStartDate = this.convertDateToHtml5Format(workerData.payPlan?.gradeLifecycle?.beginDate);
      const formattedStepStartDate = this.convertDateToHtml5Format(workerData.payPlan?.stepLifecycle?.beginDate);
      
      // Convert accession dates if available
      const accessionData = this.workerBase.workerAccession;
      
      const formattedAccessionDate = accessionData ? this.convertDateToHtml5Format(accessionData.accessionDt) : null;
      const formattedFinalJobOfferExtendedDate = accessionData ? this.convertDateToHtml5Format(accessionData.finalJobOfferExtendedDt) : null;
      const formattedFinalJobOfferAcceptedDate = accessionData ? this.convertDateToHtml5Format(accessionData.finalJobOfferAcceptedDt) : null;
      const detailsData: any = {
        employmentType: workerData.employmentType?.value,
        rehireIndicator: workerData.rehireIndicator,
        otherFederalAgencyIndicator: workerData.otherFederalAgencyIndicator || false,
        positionTitle: workerData.jobClass?.description,
        orgCode: workerData.positionOrganizationListing,
        entranceDutyDate: formattedEntranceDutyDate,
        accessionDate: formattedAccessionDate,
        finalJobOfferExtendedDate: formattedFinalJobOfferExtendedDate,
        finalJobOfferAcceptedDate: formattedFinalJobOfferAcceptedDate,
        notes: workerData.notes,
        firmName: workerData.contractorFirm?.id,
        pubOrgDirectory: workerData.publishOrganizationDirectoryIndicator,
        phoneBookTitleCode: workerData.directoryTitleType?.id,
        supervisor: workerData.supervisorIndicator,
        teleworkIndicator: workerData.teleworkIndicator,
        tourDuty: workerData.standardTourOfDuty?.id,
        jobClass: workerData.jobClass?.id,
        // CRITICAL FIX: Format occupationalSeries as "value - description" string to match typeahead selection format
        // This prevents [object Object] from displaying in the form field
        occServicesCode: workerData.occupationalSeries
          ? `${workerData.occupationalSeries.value} - ${workerData.occupationalSeries.description}`
          : '',
        // CRITICAL FIX: Format occupationalSeriesTitle as "value - description" string to match typeahead selection format
        titleCode: workerData.occupationalSeriesTitle
          ? `${workerData.occupationalSeriesTitle.value} - ${workerData.occupationalSeriesTitle.description}`
          : '',
        typeAppointment: workerData.appointmentType?.id,
        positionSensitivity: workerData.positionSensitivity?.id,
        leaveAccrual: workerData.leaveAccrual?.id,
        busCode: workerData.bargainUnitType?.id,
        // CRITICAL FIX: For contractors, always default signatoryAuthority to NONE (empty string)
        // Contractors should not have signatory authority levels
        signatoryAuthority: workerData.employmentType?.value === 'C' ? '' : (workerData.signatoryAuthority?.id || ''),
        // Set serviceAccountIndicator based on the worker data (true, false, or null)
        serviceAccountIndicator: workerData.serviceAccountIndicator !== undefined ? workerData.serviceAccountIndicator : null,
      };

      // Add pay plan data if available
      if (workerData.payPlan) {
        detailsData.grade = workerData.payPlan.currentGrade?.id;
        detailsData.step = workerData.payPlan.currentStep?.id;
        detailsData.payPlan = workerData.payPlan.currentPayPlan?.id;
        detailsData.gradeStartDate = formattedGradeStartDate;
        detailsData.stepStartDate = formattedStepStartDate;
      }

      // Add telework program if available
      if (workerData.teleworkProgram) {
        detailsData.teleworkProgram = workerData.teleworkProgram.id;
      }

      this.detailsInfo.patchValue(detailsData);
    }

    // Set employment type for contractor/employee distinction
    if (workerData.employmentType?.value) {
      this.workerEmploymentType = workerData.employmentType.value;
    }

    // Set application type
    if (workerData.employmentType?.value === 'C') {
      this.applicationTypeLowerCase = 'contractor';
    } else {
      this.applicationTypeLowerCase = 'worker';
    }
    
    // Store the original data for reset functionality (deep clone to avoid reference issues)
    this.initialWorkerBase = JSON.parse(JSON.stringify(this.workerBase));
  }

  private loadReferenceData(): Observable<any> {
    // Load all reference data needed for form dropdowns and selections
    // Returns an Observable that completes when all reference data is loaded
    // Note: API responses have a .results property that contains the actual array
    
    const observables = {
      countries: this.workerManagementService.getCountries().pipe(
        tap((response: any) => {
          this.referenceData.countries = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.countries = [];
          return of([]);
        })
      ),
      states: this.workerManagementService.getStates().pipe(
        tap((response: any) => {
          this.referenceData.states = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.states = [];
          return of([]);
        })
      ),
      jobClasses: this.workerManagementService.getJobClasses().pipe(
        tap((response: any) => {
          this.referenceData.jobClasses = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.jobClasses = [];
          return of([]);
        })
      ),
      payPlans: this.workerManagementService.getPayPlans().pipe(
        tap((response: any) => {
          this.referenceData.payPlans = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.payPlans = [];
          return of([]);
        })
      ),
      grades: this.workerManagementService.getGrades().pipe(
        tap((response: any) => {
          this.referenceData.grades = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.grades = [];
          return of([]);
        })
      ),
      steps: this.workerManagementService.getSteps().pipe(
        tap((response: any) => {
          this.referenceData.steps = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.steps = [];
          return of([]);
        })
      ),
      teleworkPrograms: this.workerManagementService.getTeleworkPrograms().pipe(
        tap((response: any) => {
          this.referenceData.teleworkPrograms = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.teleworkPrograms = [];
          return of([]);
        })
      ),
      directoryTitleTypes: this.workerManagementService.getDirectoryTitleTypes().pipe(
        tap((response: any) => {
          this.referenceData.directoryTitleTypes = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.directoryTitleTypes = [];
          return of([]);
        })
      ),
      telecomAddressTypes: this.workerManagementService.getTelecomAddressTypes().pipe(
        tap((response: any) => {
          this.referenceData.telecomAddressTypes = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.telecomAddressTypes = [];
          return of([]);
        })
      ),
      occupationalSeries: this.workerManagementService.getOccupationalSeries().pipe(
        tap((response: any) => {
          this.referenceData.occupationalSeries = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.occupationalSeries = [];
          return of([]);
        })
      ),
      contractorFirms: this.workerManagementService.getContractorFirms().pipe(
        tap((response: any) => {
          this.referenceData.contractorFirms = Array.isArray(response) ? response : (response?.results || []);
          if (this.referenceData.contractorFirms && this.referenceData.contractorFirms.length > 0) {
          }
        }),
        catchError((error: any) => {
          this.referenceData.contractorFirms = [];
          return of([]);
        })
      ),
      toursOfDuty: this.httpService.get('/references/tour-of-duties').pipe(
        tap((response: any) => {
          // Handle both array response and object with results property
          if (Array.isArray(response)) {
            this.referenceData.toursOfDuty = response;
          } else if (response && response.results) {
            this.referenceData.toursOfDuty = response.results;
          } else if (response) {
            this.referenceData.toursOfDuty = response;
          } else {
            this.referenceData.toursOfDuty = [];
          }
        }),
        catchError((error: any) => {
          this.referenceData.toursOfDuty = [];
          return of([]);
        })
      ),
      signatoryAuthorities: this.httpService.get('/references/signatory-authorities').pipe(
        tap((response: any) => {
          // Handle both array response and object with results property
          if (Array.isArray(response)) {
            this.referenceData.signatoryAuthorities = response;
          } else if (response && response.results) {
            this.referenceData.signatoryAuthorities = response.results;
          } else if (response) {
            this.referenceData.signatoryAuthorities = response;
          } else {
            this.referenceData.signatoryAuthorities = [];
          }
        }),
        catchError((error: any) => {
          this.referenceData.signatoryAuthorities = [];
          return of([]);
        })
      ),
      telecomTypes: this.workerManagementService.getTelecomTypes().pipe(
        tap((response: any) => {
          this.referenceData.telecomTypes = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.telecomTypes = [];
          return of([]);
        })
      ),
      appointmentTypes: this.httpService.get('/references/appointment-types').pipe(
        tap((response: any) => {
          this.referenceData.appointmentTypes = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.appointmentTypes = [];
          return of([]);
        })
      ),
      positionSensitivities: this.httpService.get('/references/position-sensitivities').pipe(
        tap((response: any) => {
          this.referenceData.positionSensitivities = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.positionSensitivities = [];
          return of([]);
        })
      ),
      leaveAccruals: this.httpService.get('/references/leave-accruals').pipe(
        tap((response: any) => {
          this.referenceData.leaveAccruals = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.leaveAccruals = [];
          return of([]);
        })
      ),
      bargainUnitTypes: this.httpService.get('/references/bargain-unit-types').pipe(
        tap((response: any) => {
          this.referenceData.bargainUnitTypes = Array.isArray(response) ? response : (response?.results || []);
        }),
        catchError((error: any) => {
          this.referenceData.bargainUnitTypes = [];
          return of([]);
        })
      )
    };

    return forkJoin(observables).pipe(
      tap(() => {
        // Set default Tour of Duty to "Full-Time" after reference data is loaded
        if (this.detailsInfoTabComponent && this.referenceData.toursOfDuty && this.referenceData.toursOfDuty.length > 0) {
          // Use setTimeout to ensure the component is fully initialized
          setTimeout(() => {
            this.detailsInfoTabComponent.setDefaultTourOfDutyFromReferenceData();
          }, 0);
        }
        
        // Set default Pay Plan to "General Schedule" after reference data is loaded
        if (this.detailsInfoTabComponent && this.referenceData.payPlans && this.referenceData.payPlans.length > 0) {
          // Use setTimeout to ensure the component is fully initialized
          setTimeout(() => {
            this.detailsInfoTabComponent.setDefaultPayPlan();
          }, 0);
        }
      })
    );
  }

  private initilaiseForm(): void {
    this.addWorkerFormGroup = this.fb.group({
      primaryInfoTab: this.primaryInfoTab,
      conInfoTab: this.conInfoTab,
      detailsInfo: this.detailsInfo,
      assignMentWorker: this.assignMentWorker,
      communicationWorker: this.communicationWorker,
      roleassignmentWorker: this.roleassignmentWorker,
    });
  }

  buildDOBAndCountryEmployee(workerSecure: any) {
    // Handle both object format (with .value/.description) and simple value format
    let birthCountryCode = null;
    let birthCountryName = null;
    
    if (workerSecure.birthCountry) {
      if (typeof workerSecure.birthCountry === 'object' && workerSecure.birthCountry.value) {
        // Object format: { value: 'IR', description: 'IRAN, ISLAMIC REPUBLIC OF' }
        birthCountryCode = workerSecure.birthCountry.value;
        birthCountryName = workerSecure.birthCountry.description;
      } else if (typeof workerSecure.birthCountry === 'string') {
        // Simple value format: 'IR'
        birthCountryCode = workerSecure.birthCountry;
        // Try to find the country in reference data to get the description
        const countryObj = this.referenceData.countries?.find(
          (c: any) => c.value === workerSecure.birthCountry || c.id === workerSecure.birthCountry
        );
        birthCountryName = countryObj?.description || null;
      }
    }

    // Format date to MM/dd/yyyy if it exists
    let formattedDate = null;
    if (workerSecure.birthDate) {
      const dateObj = new Date(workerSecure.birthDate);
      if (!isNaN(dateObj.getTime())) {
        const month = String(dateObj.getMonth() + 1).padStart(2, '0');
        const day = String(dateObj.getDate()).padStart(2, '0');
        const year = dateObj.getFullYear();
        formattedDate = `${month}/${day}/${year}`;
      }
    }

    const workerSecureInformation = {
      birthCountryCode: birthCountryCode,
      birthCountryName: birthCountryName,
      birthCityName: workerSecure.birthCityName || null,
      birthDate: formattedDate,
      employeeSocialSecurity: workerSecure.employeeSocialSecurity || null,
    };
    return workerSecureInformation;
  }
  buildDOBAndCountryContractor(workerAddObject: any) {
    let workerSecureInformation;
    // CRITICAL FIX: For contractors, use the full SSN (not just last 2 digits)
    // The API requires the full SSN for contractors, not just the last 2 digits
    if (!!workerAddObject.birthDate && (!!workerAddObject.ssn || !!workerAddObject.ssnLast2Digits)) {
      // Format date to MM/dd/yyyy if it exists
      let formattedDate = null;
      if (workerAddObject.birthDate) {
        const dateObj = new Date(workerAddObject.birthDate);
        if (!isNaN(dateObj.getTime())) {
          const month = String(dateObj.getMonth() + 1).padStart(2, '0');
          const day = String(dateObj.getDate()).padStart(2, '0');
          const year = dateObj.getFullYear();
          formattedDate = `${month}/${day}/${year}`;
        }
      }
      
      // Use full SSN if available, otherwise fall back to last 2 digits
      const ssn = workerAddObject.ssn || workerAddObject.ssnLast2Digits;
      
      workerSecureInformation = {
        birthDate: formattedDate || null,
        contractorSocialSecurity: ssn || null,
      };
    }
    return workerSecureInformation;
  }
  buildPayplanWorkerData(workerAddObject: any) {
    let workerPayplanInformation;

    if (!!workerAddObject.grade && !!workerAddObject.step && !!workerAddObject.payplan) {
      workerPayplanInformation = {
        currentGrade: {
          id: workerAddObject.grade.id,
        },
        currentStep: {
          id: workerAddObject.step.id,
        },
        currentPayPlan: {
          id: workerAddObject.payplan.id,
        },
        gradeLifecycle: {
          beginDate: workerAddObject.gradeStartDate,
        },
        stepLifecycle: {
          beginDate: workerAddObject.stepStartDate,
        },
      };
    }
    return workerPayplanInformation;
  }
  buildSecureWorkerData(workerEmploymentType: any, workerSecure: any, workerAddObject: any) {
    const workerId = this.workerBase.id || this.workerBase.workerId;
    let workerSecureInformation: any = {
      worker: { workerId: String(workerId) }
    };
    
    if (workerEmploymentType === 'C') {
      const contractorData = this.buildDOBAndCountryContractor(workerAddObject);
      workerSecureInformation = { ...workerSecureInformation, ...contractorData };
    } else {
      const employeeData = this.buildDOBAndCountryEmployee(workerSecure);
      workerSecureInformation = { ...workerSecureInformation, ...employeeData };
      
      // Handle birthState - can be object format or simple value format
      if (workerSecure.birthState) {
        let birthStateCode = null;
        let birthStateName = null;
        
        if (typeof workerSecure.birthState === 'object' && workerSecure.birthState.value) {
          // Object format: { value: 'CA', description: 'CALIFORNIA' }
          birthStateCode = workerSecure.birthState.value;
          birthStateName = workerSecure.birthState.description;
        } else if (typeof workerSecure.birthState === 'string') {
          // Simple value format: 'CA'
          birthStateCode = workerSecure.birthState;
          // Try to find the state in reference data to get the description
          const stateObj = this.referenceData.states?.find(
            (s: any) => s.value === workerSecure.birthState || s.id === workerSecure.birthState
          );
          birthStateName = stateObj?.description || null;
        }
        
        if (birthStateCode) {
          workerSecureInformation.birthStateCode = birthStateCode;
          workerSecureInformation.birthStateName = birthStateName;
        }
      }
    }
    return workerSecureInformation;
  }
  // addWorker(workerEmploymentType: any = {}, workerSecure: any = {}, workerAddObject: any = {}) {
  //   let responseCreate;
  //   workerAddObject.secure = this.buildSecureWorkerData(workerEmploymentType, workerSecure, workerAddObject);
  //   if (workerEmploymentType === 'E') {
  //     workerAddObject.payPlan = this.buildPayplanWorkerData(workerAddObject);
  //   }

  //   return this.httpService.post('hrWorkers',
  //     workerAddObject)
  //     .subscribe((response: any) => {
  //       responseCreate = {
  //         worker: response.data,
  //         status: response.status,
  //         statusText: "Created"
  //       };
  //       return responseCreate;
  //     },
  //       (response) => {
  //         return;
  //       });
  // }

 /**
  * Priority 1: Check if assignments (Communication or Location) are in edit mode
  * This prevents saving the worker while child assignments are being edited
  * Based on old AngularJS implementation: assignmentsEditMode() in workerUpdate.controller.js
  */
 private assignmentsEditMode(): boolean {
   return this.communicationEditMode || this.organizationLocationEditMode;
 }

 public addWorker(): void {
    // Priority 1: Check if assignments are in edit mode (CRITICAL)
    if (this.assignmentsEditMode()) {
      this.dialog.open(ConfirmDialogComponent, {
        width: '500px',
        data: {
          title: 'Edit Mode Active',
          message: 'Please save or cancel changes in the Communication or Location assignment tabs before saving the worker.',
          type: 'error'
        }
      });
      return;
    }
    // Check form validity
    const isValid = this.formUtility.ValidateForm(this.addWorkerFormGroup);
    // Trigger validation for birthDate and ssnLast2Digits fields on save
    // This ensures required validation errors are displayed when user tries to save
    this.triggerPrimaryInfoValidation();
    
    // NOTE: Form validation may fail due to required fields in child form groups
    // (e.g., location assignment fields). These fields may not be applicable to all scenarios.
    // Following the old AngularJS pattern, we proceed with save and let the API validate.
    // The old code used updateWorkerInvalid() which only checked specific critical fields.
debugger
     // Telework/Hoteling validation (from old code)
     // CRITICAL FIX: Get telework values from form data, not from workerBase.worker
     // workerBase.worker may not have the latest form values yet
     const detailsFormValue = this.detailsInfo.value;
     const hotelDisplayIndicator = detailsFormValue?.hotelDisplayIndicator || this.workerBase.worker?.hotelDisplayIndicator;
     const teleworkIndicator = detailsFormValue?.teleworkIndicator || this.workerBase.worker?.teleworkIndicator;
     const teleworkProgram = detailsFormValue?.teleworkProgram || this.workerBase.worker?.teleworkProgram;
     const isRoomCoordinator = this.userRoles.indexOf('InfraRoomCoordinator') !== -1;
    // Build error messages array for all validation failures
    const errorMessages: string[] = [];

    // Error 1: Hoteling checked but Telework not checked (and not RoomCoordinator)
    if (hotelDisplayIndicator && !teleworkIndicator && !isRoomCoordinator) {
      errorMessages.push('The Telework box must be check first with a description');
    }

    // Error 2: Telework checked but no program selected
    if (teleworkIndicator && !teleworkProgram) {
      errorMessages.push('Telework program is required');
    }

    // Error 3: Hoteling checked without telework program (and not RoomCoordinator)
    if (hotelDisplayIndicator && !teleworkProgram && !isRoomCoordinator) {
      // This is a duplicate of Error 1 or Error 2, so only add if not already present
      if (!errorMessages.includes('The Telework box must be check first with a description') &&
          !errorMessages.includes('Telework program is required')) {
        errorMessages.push('Telework program is required when hoteling is selected.');
      }
    }

    // If there are any validation errors, log them but proceed with save
    // (matching old AngularJS behavior where validation errors don't prevent save)
    if (errorMessages.length > 0) {
    } else {
    }

    // Build worker object from form data
    const workerData = this.buildWorkerDataFromForm();
    // Validate worker details (Position Sensitivity, Leave Accrual, etc.)
    // This follows the old AngularJS pattern from workerUpdate.controller.js
    const detailsValidation = this.validateWorkerDetailsOnSave(workerData);
    if (!detailsValidation.isValid) {
      // Add details validation errors to the error messages array
      errorMessages.push(...detailsValidation.errorMessages);
    } else {
    }

    // If there are any validation errors, prevent save and display via ACME navbar
    if (errorMessages.length > 0) {
      // Display validation errors via ACME navbar component using service
      this.workerManagementService.showValidationErrors(errorMessages);
      // Mark all form fields as touched so inline error messages display
      Object.keys(this.detailsInfo.controls).forEach(key => {
        const control = this.detailsInfo.get(key);
        control?.markAsTouched();
      });
      
      // Also mark primary info and conf info fields as touched
      Object.keys(this.primaryInfoTab.controls).forEach(key => {
        const control = this.primaryInfoTab.get(key);
        control?.markAsTouched();
      });
      
      Object.keys(this.conInfoTab.controls).forEach(key => {
        const control = this.conInfoTab.get(key);
        control?.markAsTouched();
      });
      // Trigger change detection to ensure error messages display
      this.cdr.detectChanges();
      
      // CRITICAL FIX: Scroll to top to show error message and ensure page remains scrollable
      // Use setTimeout to ensure scroll happens after change detection completes
      setTimeout(() => {
        // Ensure body and html elements are scrollable
        document.body.style.overflow = 'auto';
        document.documentElement.style.overflow = 'auto';
        
        // Scroll to top smoothly to show ACME navbar error messages
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      }, 100);
      
      return;
    }
   // Check if this is ADD mode or EDIT mode
   if (!this.editAddMode) {
     // ADD MODE: Create new worker/contractor using POST /hrWorkers
     // For contractors in ADD mode, validate contractor ID (DOB + Last 2 SSN) before creating
     if (this.workerEmploymentType === 'C') {
       this.validateContractorIdBeforeCreate(workerData);
     } else {
       this.createWorker(workerData);
     }
   } else {
     // EDIT MODE: Update existing worker/contractor
     // Save initial worker data for rollback
     this.initialWorkerBase = JSON.parse(JSON.stringify(this.workerBase));
     
     // Prepare update parameters
     const updateParams = {
       lockControlNumber: this.workerBase.worker.audit?.lockControlNumber || 0
     };
     // Route to appropriate save function based on user role
     if (this.userRoles.indexOf('InfraHRAdmin') >= 0) {
       this.saveWorkerHR(workerData, updateParams);
     } else if (this.userRoles.indexOf('InfraAdmin') >= 0 || this.userRoles.indexOf('InfraContractorAdmin') >= 0) {
       this.saveWorkerAdminAndContractorAdmin(workerData, updateParams);
     } else if (this.userRoles.indexOf('InfraOfficeCoordinator') >= 0) {
       this.saveWorkerOfficeCoordinator(workerData, updateParams);
     } else if (this.userRoles.indexOf('InfraRoomCoordinator') >= 0) {
       this.saveWorkerOfficeCoordinator(workerData, updateParams);
     } else {
       this.showErrorMessage('Error', 'User role not recognized');
     }
   }
 }

  private buildWorkerDataFromForm(): any {
    // In ADD mode, start with empty object. In EDIT mode, start with existing worker data
    const workerData = this.editAddMode
      ? JSON.parse(JSON.stringify(this.workerBase.worker))
      : {};
    // Update with form values
    const primaryInfo = this.primaryInfoTab.value;
    const confInfo = this.conInfoTab.value;
    const detailsInfo = this.detailsInfo.value;
    // Update primary info fields
    if (primaryInfo) {
      workerData.givenName = primaryInfo.firstName;
      workerData.familyName = primaryInfo.lastName;
      workerData.middleName = primaryInfo.middleName;
      workerData.preferredFirstName = primaryInfo.preferredFirstName;
      workerData.loginId = primaryInfo.loginId;
      workerData.emailAddress = primaryInfo.emailAddress;
      
      // CRITICAL FIX: Extract birthDate and ssnLast2Digits from primaryInfoTab for contractors
      // These fields are in the primary info tab for contractors (not in confidential info tab)
      if (this.workerEmploymentType === 'C') {
        if (primaryInfo.birthDate !== undefined) {
          workerData.birthDate = primaryInfo.birthDate;
        }
        if (primaryInfo.ssnLast2Digits !== undefined) {
          workerData.ssnLast2Digits = primaryInfo.ssnLast2Digits;
        }
      }
    }

    // Update confidential info
    if (confInfo) {
      if (confInfo.patronId !== undefined) {
        workerData.patronId = confInfo.patronId;
      }
      if (confInfo.positionOrganizationListing !== undefined) {
        workerData.positionOrganizationListing = confInfo.positionOrganizationListing;
      }
      if (confInfo.otherFederalAgencyIndicator !== undefined) {
        workerData.otherFederalAgencyIndicator = confInfo.otherFederalAgencyIndicator;
      }
      // Note: Form uses 'dateOfBirth' but we need to pass it as 'birthDate' to secure data builder
      if (confInfo.dateOfBirth !== undefined) {
        workerData.birthDate = confInfo.dateOfBirth;
      }
      if (confInfo.birthState !== undefined) {
        workerData.birthState = confInfo.birthState;
      }
      if (confInfo.birthCountry !== undefined) {
        workerData.birthCountry = confInfo.birthCountry;
      }
      if (confInfo.birthCityName !== undefined) {
        workerData.birthCityName = confInfo.birthCityName;
      }
      if (confInfo.ssn !== undefined) {
        workerData.employeeSocialSecurity = confInfo.ssn;
      }
      if (confInfo.ssnLast2Digits !== undefined) {
        workerData.ssnLast2Digits = confInfo.ssnLast2Digits;
      }
    }

    // Update details info
    if (detailsInfo) {
      // CRITICAL FIX: Map firmName form control to contractorFirm property
      // firmName can be either a firm name string, a description, or an ID number
      // If it's a string (name/description), we need to find the matching firm by value or description
      // If it's a number (ID), we use it directly
      if (detailsInfo.firmName !== undefined && detailsInfo.firmName !== null && detailsInfo.firmName !== '') {
        if (typeof detailsInfo.firmName === 'string' && isNaN(Number(detailsInfo.firmName))) {
          // It's a string (firm name or description), find the matching firm ID
          const firm = this.referenceData.contractorFirms?.find(
            (f: any) => f.value === detailsInfo.firmName || f.description === detailsInfo.firmName
          );
          if (firm) {
            workerData.contractorFirm = firm.id;
          } else {
          }
        } else {
          // It's already an ID (number or numeric string)
          workerData.contractorFirm = Number(detailsInfo.firmName);
        }
      } else {
      }
      // Map phoneBookTitleCode form control to directoryTitleType property
      if (detailsInfo.phoneBookTitleCode !== undefined && detailsInfo.phoneBookTitleCode !== null && detailsInfo.phoneBookTitleCode !== '') {
        workerData.directoryTitleType = detailsInfo.phoneBookTitleCode;
      } else {
        // Set default directoryTitleType to 17 (matching old payload)
        workerData.directoryTitleType = 17;
      }
      if (detailsInfo.teleworkProgram !== undefined) {
        workerData.teleworkProgram = detailsInfo.teleworkProgram;
      }
      // CRITICAL FIX: Map positionTitle form control to jobClass property
      // positionTitle can be either a description string or an ID number
      // If it's a string (description), we need to find the matching jobClass by description
      // If it's a number (ID), we use it directly
      if (detailsInfo.positionTitle !== undefined && detailsInfo.positionTitle !== null && detailsInfo.positionTitle !== '') {
        if (typeof detailsInfo.positionTitle === 'string') {
          // It's a description, find the matching jobClass ID
          const jobClass = this.referenceData.jobClasses?.find(
            (jc: any) => jc.description === detailsInfo.positionTitle
          );
          if (jobClass) {
            workerData.jobClass = jobClass.id;
          } else {
          }
        } else {
          // It's already an ID
          workerData.jobClass = detailsInfo.positionTitle;
        }
      }
      // CRITICAL FIX: Map orgCode to positionOrganizationListing
      if (detailsInfo.orgCode !== undefined && detailsInfo.orgCode !== null && detailsInfo.orgCode !== '') {
        workerData.positionOrganizationListing = detailsInfo.orgCode;
      }
      // CRITICAL FIX: Map occServicesCode to occupationalSeries
      if (detailsInfo.occServicesCode !== undefined && detailsInfo.occServicesCode !== null && detailsInfo.occServicesCode !== '') {
        if (typeof detailsInfo.occServicesCode === 'string') {
          // Extract ID from "value - description" format
          const occSeries = this.referenceData.occupationalSeries?.find(
            (os: any) => `${os.value} - ${os.description}` === detailsInfo.occServicesCode || os.id === detailsInfo.occServicesCode
          );
          if (occSeries) {
            workerData.occupationalSeries = occSeries.id;
          }
        } else {
          workerData.occupationalSeries = detailsInfo.occServicesCode;
        }
      }
      // CRITICAL FIX: Map titleCode to occupationalSeriesTitle
      // The occupationalSeriesTitle.occupationalSeriesTitleId should contain the title code ID
      // This is the ID of the selected title code from the titleCodes array
      if (detailsInfo.titleCode !== undefined && detailsInfo.titleCode !== null && detailsInfo.titleCode !== '') {
        if (typeof detailsInfo.titleCode === 'string') {
          // Extract ID from "value - description" format
          // titleCodes are loaded dynamically in the child component based on occupational series
          // Try to get them from the child component
          const titleCodes = this.detailsInfoTabComponent?.titleCodes || [];
          const titleCode = titleCodes.find(
            (tc: any) => `${tc.value} - ${tc.description}` === detailsInfo.titleCode || tc.id === detailsInfo.titleCode
          );
          if (titleCode) {
            // Store the title code ID
            // This will be wrapped as { occupationalSeriesTitleId: titleCode.id } in the payload
            workerData.occupationalSeriesTitle = titleCode.id;
          } else {
            // If not found in titleCodes array, assume it's already an ID
            workerData.occupationalSeriesTitle = detailsInfo.titleCode;
          }
        } else {
          // If it's already an object with id property, extract the id
          if (typeof detailsInfo.titleCode === 'object' && detailsInfo.titleCode.id) {
            workerData.occupationalSeriesTitle = detailsInfo.titleCode.id;
          } else {
            workerData.occupationalSeriesTitle = detailsInfo.titleCode;
          }
        }
      }
      if (detailsInfo.tourOfDuty !== undefined) {
        workerData.tourOfDuty = detailsInfo.tourOfDuty;
      }
      if (detailsInfo.hotelDisplayIndicator !== undefined) {
        workerData.hotelDisplayIndicator = detailsInfo.hotelDisplayIndicator;
      }
      if (detailsInfo.teleworkIndicator !== undefined) {
        workerData.teleworkIndicator = detailsInfo.teleworkIndicator;
      }
      // Add mandatory validation fields from details form
      if (detailsInfo.positionSensitivity !== undefined) {
        workerData.positionSensitivity = detailsInfo.positionSensitivity;
      }
      if (detailsInfo.leaveAccrual !== undefined) {
        workerData.leaveAccrual = detailsInfo.leaveAccrual;
      }
      if (detailsInfo.typeAppointment !== undefined) {
        workerData.appointmentType = detailsInfo.typeAppointment;
      }
      if (detailsInfo.busCode !== undefined) {
        workerData.bargainUnitType = detailsInfo.busCode;
      }
      if (detailsInfo.tourDuty !== undefined) {
        workerData.standardTourOfDuty = detailsInfo.tourDuty;
      }
      if (detailsInfo.grade !== undefined) {
        workerData.grade = detailsInfo.grade;
      }
      if (detailsInfo.step !== undefined) {
        workerData.step = detailsInfo.step;
      }
      if (detailsInfo.payPlan !== undefined) {
        workerData.payplan = detailsInfo.payPlan;
      }
      if (detailsInfo.gradeStartDate !== undefined) {
        workerData.gradeStartDate = detailsInfo.gradeStartDate;
      }
      if (detailsInfo.stepStartDate !== undefined) {
        workerData.stepStartDate = detailsInfo.stepStartDate;
      }
      // CRITICAL FIX: Map entranceDutyDate to lifecycle.beginDate
      if (detailsInfo.entranceDutyDate !== undefined && detailsInfo.entranceDutyDate !== null && detailsInfo.entranceDutyDate !== '') {
        if (!workerData.lifecycle) {
          workerData.lifecycle = {};
        }
        workerData.lifecycle.beginDate = detailsInfo.entranceDutyDate;
      }
    }

    // Ensure employment type is set
    if (!workerData.employmentType) {
      workerData.employmentType = {
        value: this.workerEmploymentType
      };
    }

    // Add secure data if applicable
    // Transform confInfo to match the expected format for buildSecureWorkerData
    // The form uses 'dateOfBirth' and 'ssn', but the method expects 'birthDate' and 'employeeSocialSecurity'
    const secureDataInput = {
      birthDate: confInfo?.dateOfBirth,
      employeeSocialSecurity: confInfo?.ssn,
      birthCityName: confInfo?.birthCityName,
      birthCountry: confInfo?.birthCountry,
      birthState: confInfo?.birthState
    };
    
    // For contractors, also include the full SSN in the workerAddObject passed to buildSecureWorkerData
    const workerAddObjectForSecure = { ...primaryInfo, ...detailsInfo };
    if (this.workerEmploymentType === 'C' && confInfo?.ssn) {
      workerAddObjectForSecure.ssn = confInfo.ssn;
    }
    
    const secureData = this.buildSecureWorkerData(
      this.workerEmploymentType,
      secureDataInput,
      workerAddObjectForSecure
    );
    if (secureData) {
      workerData.secure = secureData;
    }

    // Add pay plan for employees
    if (this.workerEmploymentType === 'E') {
      const payPlanData = this.buildPayplanWorkerData(detailsInfo);
      if (payPlanData) {
        workerData.payPlan = payPlanData;
      }
    }
    return workerData;
  }

  /**
   * Build filtered payload for workers PUT endpoint
   * Matches the exact structure from the provided working payload
   */
  private buildFilteredWorkerPayload(workerData: any): any {
    // Start with the original worker data from workerBase to preserve all loaded fields
    const originalWorker = this.workerBase.worker || this.workerBase;
    
    // Helper function to ensure reference data objects have id, value, description format
    const formatReferenceObject = (obj: any): any => {
      if (!obj) return null;
      if (typeof obj === 'object' && obj.id !== undefined) {
        return {
          id: obj.id,
          value: obj.value,
          description: obj.description
        };
      }
      return obj;
    };

    // Build payload matching the EXACT order from the provided example
    const payload: any = {
      workerId: String(originalWorker.workerId),
      workerNumber: originalWorker.workerNumber,
      jobClass: formatReferenceObject(originalWorker.jobClass),
      signatoryAuthority: formatReferenceObject(originalWorker.signatoryAuthority),
      contractorFirm: formatReferenceObject(originalWorker.contractorFirm),
      leaveAccrual: formatReferenceObject(originalWorker.leaveAccrual),
      appointmentType: formatReferenceObject(originalWorker.appointmentType),
      occupationalSeries: formatReferenceObject(originalWorker.occupationalSeries),
      bargainUnitType: formatReferenceObject(originalWorker.bargainUnitType),
      positionSensitivity: formatReferenceObject(originalWorker.positionSensitivity),
      teleworkProgram: formatReferenceObject(originalWorker.teleworkProgram),
      patronId: originalWorker.patronId,
      auxiliaryRoleSummary: null,
      positionOrganizationListing: originalWorker.positionOrganizationListing,
      familyName: workerData.familyName || originalWorker.familyName,
      givenName: workerData.givenName || originalWorker.givenName,
      middleName: workerData.middleName || originalWorker.middleName,
      preferredFirstName: workerData.preferredFirstName || originalWorker.preferredFirstName,
      emailAddress: workerData.emailAddress || originalWorker.emailAddress,
      activeEmploymentIndicator: originalWorker.activeEmploymentIndicator,
      supervisorIndicator: originalWorker.supervisorIndicator,
      otherFederalAgencyIndicator: originalWorker.otherFederalAgencyIndicator,
      publishOrganizationDirectoryIndicator: originalWorker.publishOrganizationDirectoryIndicator,
      loginId: workerData.loginId || originalWorker.loginId,
      internetDisplayIndicator: originalWorker.internetDisplayIndicator,
      intranetDisplayIndicator: originalWorker.intranetDisplayIndicator,
      hotelDisplayIndicator: originalWorker.hotelDisplayIndicator,
      rehireIndicator: originalWorker.rehireIndicator,
      notes: originalWorker.notes,
      serviceAccountIndicator: originalWorker.serviceAccountIndicator,
      standardTourOfDuty: formatReferenceObject(originalWorker.standardTourOfDuty),
      workerTelecommunicationHistory: originalWorker.workerTelecommunicationHistory || [],
      organizationHistory: originalWorker.organizationHistory || [],
      workerRelationship: originalWorker.workerRelationship,
      audit: {
        lockControlNumber: originalWorker.audit?.lockControlNumber || 0
      },
      lifecycle: originalWorker.lifecycle,
      employmentType: formatReferenceObject(originalWorker.employmentType),
      teleworkIndicator: originalWorker.teleworkIndicator !== undefined ? originalWorker.teleworkIndicator : false,
      ssnLast2Digits: originalWorker.ssnLast2Digits,
      birthDate: originalWorker.birthDate,
      teleworkProgramInvalid: originalWorker.teleworkProgramInvalid !== undefined ? originalWorker.teleworkProgramInvalid : false,
      gradeStartDate: originalWorker.gradeStartDate || null,
      stepStartDate: originalWorker.stepStartDate || null
    };

    if(payload.employmentType.value === 'E'){
        payload.employmentType.id = 5;
    }
    // Update with form values if they exist and convert to proper format
    if (workerData.contractorFirm !== undefined) {
      if (typeof workerData.contractorFirm === 'number') {
        const firm = this.referenceData.contractorFirms?.find((f: any) => f.id === workerData.contractorFirm);
        payload.contractorFirm = firm ? formatReferenceObject(firm) : payload.contractorFirm;
      } else {
        payload.contractorFirm = formatReferenceObject(workerData.contractorFirm);
      }
    }
    
    if (workerData.jobClass !== undefined) {
      if (typeof workerData.jobClass === 'number') {
        const jobClass = this.referenceData.jobClasses?.find((j: any) => j.id === workerData.jobClass);
        payload.jobClass = jobClass ? formatReferenceObject(jobClass) : payload.jobClass;
      } else {
        payload.jobClass = formatReferenceObject(workerData.jobClass);
      }
    }
    
    if (workerData.bargainUnitType !== undefined) {
      if (typeof workerData.bargainUnitType === 'number') {
        const bargainUnit = this.referenceData.bargainUnitTypes?.find((b: any) => b.id === workerData.bargainUnitType);
        payload.bargainUnitType = bargainUnit ? formatReferenceObject(bargainUnit) : payload.bargainUnitType;
      } else {
        payload.bargainUnitType = formatReferenceObject(workerData.bargainUnitType);
      }
    }
    
    if (workerData.standardTourOfDuty !== undefined) {
      if (typeof workerData.standardTourOfDuty === 'number') {
        const tourOfDuty = this.referenceData.toursOfDuty?.find((t: any) => t.id === workerData.standardTourOfDuty);
        payload.standardTourOfDuty = tourOfDuty ? formatReferenceObject(tourOfDuty) : payload.standardTourOfDuty;
      } else {
        payload.standardTourOfDuty = formatReferenceObject(workerData.standardTourOfDuty);
      }
    }
    
    if (workerData.teleworkProgram !== undefined) {
      if (workerData.teleworkProgram === '' || workerData.teleworkProgram === null) {
        payload.teleworkProgram = null;
      } else if (typeof workerData.teleworkProgram === 'number') {
        const teleworkProg = this.referenceData.teleworkPrograms?.find((t: any) => t.id === workerData.teleworkProgram);
        payload.teleworkProgram = teleworkProg ? formatReferenceObject(teleworkProg) : null;
      } else {
        payload.teleworkProgram = formatReferenceObject(workerData.teleworkProgram);
      }
    }
    
    if (workerData.teleworkIndicator !== undefined) {
      payload.teleworkIndicator = workerData.teleworkIndicator;
    }
    if (workerData.hotelDisplayIndicator !== undefined) {
      payload.hotelDisplayIndicator = workerData.hotelDisplayIndicator;
    }
    if (workerData.supervisorIndicator !== undefined) {
      payload.supervisorIndicator = workerData.supervisorIndicator;
    }
    if (workerData.publishOrganizationDirectoryIndicator !== undefined) {
      payload.publishOrganizationDirectoryIndicator = workerData.publishOrganizationDirectoryIndicator;
    }
    if (workerData.notes !== undefined) {
      payload.notes = workerData.notes;
    }

    // Keep only the first organizationHistory entry (primary organization)
    if (Array.isArray(payload.organizationHistory) && payload.organizationHistory.length > 0) {
      payload.organizationHistory = [payload.organizationHistory[0]];
    }
    return payload;
  }

  /**
   * Build payload for POST /hrWorkers endpoint
   * Matches the EXACT structure and order from the provided working payload
   */
  private buildHrWorkerPayload(workerData: any): any {
    console.log('buildHrWorkerPayload called with workerData:', workerData);
    // Helper function to format date to ISO without milliseconds and Z
    const formatDateWithoutMilliseconds = (date: Date): string => {
      const isoString = date.toISOString();
      // Remove milliseconds and Z: "2026-04-07T18:28:42.123Z" -> "2026-04-07T18:28:42"
      return isoString.replace(/\.\d{3}Z$/, '');
    };

    // Helper function to format reference data objects with full structure
    const formatReferenceObject = (idField?: number | null, referenceArray?: any[], isContractorFirm: boolean = false): any => {
      if (!idField || !referenceArray) {
        return null;
      }
      
      // Convert string ID to number for comparison
      const numericId = typeof idField === 'string' ? Number(idField) : idField;
      const refObj = referenceArray.find((item: any) => item.id === numericId);
      if (refObj) {
        // For contractor firms, use the complete object from reference data (like legacy AngularJS code)
        // Legacy code: contractorFirm: angular.isDefined(workerBase.contractorFirm) ? workerBase.contractorFirm : null
        if (isContractorFirm) {
          // Get the current user's login ID from appService
          const userData = this.appService.getUserData();
          const currentLoginId = userData?.loginId || 'evlcedr009';
          
          const contractorFirmResult: any = {
            id: refObj.id,
            value: refObj.value,
            description: refObj.description,
            lifecycle: refObj.lifecycle || {
              beginDate: "1970-01-01T05:00:00.000Z"
            },
            audit: {
              createdDate: refObj.audit?.createdDate || "1970-01-01T05:00:00.000Z",
              createdUser: refObj.audit?.createdUser || "101307",
              lastModifiedDate: refObj.audit?.lastModifiedDate || "1970-01-01T05:00:00.000Z",
              lastModifiedUser: refObj.audit?.lastModifiedUser || "101307",
              lockControlNumber: refObj.audit?.lockControlNumber || 0,
              createdLoginId: refObj.audit?.createdLoginId || currentLoginId,
              lastModifiedLoginId: refObj.audit?.lastModifiedLoginId || currentLoginId
            },
            firmDisplay: refObj.firmDisplay || `${refObj.value} - ${refObj.description}`
          };
          return contractorFirmResult;
        }
        
        // For other reference objects, use default values
        const result: any = {
          id: refObj.id,
          value: refObj.value,
          description: refObj.description,
          lifecycle: refObj.lifecycle || {
            beginDate: "1970-01-01T05:00:00.000Z"
          },
          audit: {
            createdDate: refObj.audit?.createdDate || "1970-01-01T05:00:00.000Z",
            createdUser: refObj.audit?.createdUser || "101307",
            lastModifiedDate: refObj.audit?.lastModifiedDate || "1970-01-01T05:00:00.000Z",
            lastModifiedUser: refObj.audit?.lastModifiedUser || "101307",
            lockControlNumber: refObj.audit?.lockControlNumber || 0,
            createdLoginId: refObj.audit?.createdLoginId || "relkins",
            lastModifiedLoginId: refObj.audit?.lastModifiedLoginId || "relkins"
          }
        };
        
        return result;
      }
      return null;
    };

    // Format birthDate for the main payload (ISO format without milliseconds and Z)
    const formattedBirthDate = workerData.birthDate
      ? formatDateWithoutMilliseconds(new Date(workerData.birthDate))
      : null;
    // Format birthDate for secure object (MM/DD/YYYY format)
    // CRITICAL FIX: Use the actual form input value directly without conversion
    // The form provides yyyy-MM-dd format, but we need to convert it to MM/DD/YYYY
    // to match what the user entered
    const formatSecureBirthDate = (dateStr: string): string | null => {
      if (!dateStr) return null;
      
      // Parse the date string carefully to avoid timezone issues
      let year: number, month: number, day: number;
      
      if (dateStr.includes('-')) {
        // ISO format: "2003-02-01" or "2003-02-01T00:00:00"
        const parts = dateStr.split('T')[0].split('-');
        year = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10);
        day = parseInt(parts[2], 10);
      } else if (dateStr.includes('/')) {
        // Already in MM/DD/YYYY format
        const parts = dateStr.split('/');
        month = parseInt(parts[0], 10);
        day = parseInt(parts[1], 10);
        year = parseInt(parts[2], 10);
      } else {
        // Fallback to Date object parsing
        const date = new Date(dateStr);
        year = date.getFullYear();
        month = date.getMonth() + 1;
        day = date.getDate();
      }
      
      return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}/${year}`;
    };

    // Log critical field values
    // Build the payload matching the EXACT order and format from the sample payload
    const payload: any = {
      // 1. standardTourOfDuty - REQUIRED with full structure
      standardTourOfDuty: formatReferenceObject(
        workerData.standardTourOfDuty,
        this.referenceData.toursOfDuty
      ),
      
      // 2. leaveAccrual - REQUIRED with full structure
      leaveAccrual: formatReferenceObject(
        workerData.leaveAccrual,
        this.referenceData.leaveAccruals
      ),
      
      // 3. appointmentType - REQUIRED with full structure
      appointmentType: formatReferenceObject(
        workerData.appointmentType,
        this.referenceData.appointmentTypes
      ),
      
      // 4. positionSensitivity - REQUIRED with full structure
      positionSensitivity: formatReferenceObject(
        workerData.positionSensitivity,
        this.referenceData.positionSensitivities
      ),
      
      // 5. bargainUnitType - REQUIRED with full structure
      bargainUnitType: formatReferenceObject(
        workerData.bargainUnitType,
        this.referenceData.bargainUnitTypes
      ),
      
      // 6. activeEmploymentIndicator - boolean
      activeEmploymentIndicator: true,
      
      // 7. publishOrganizationDirectoryIndicator - boolean
      publishOrganizationDirectoryIndicator: workerData.publishOrganizationDirectoryIndicator !== undefined
        ? workerData.publishOrganizationDirectoryIndicator
        : true,
      
      // 8. internetDisplayIndicator - boolean
      internetDisplayIndicator: workerData.internetDisplayIndicator !== undefined
        ? workerData.internetDisplayIndicator
        : true,
      
      // 9. intranetDisplayIndicator - boolean
      intranetDisplayIndicator: workerData.intranetDisplayIndicator !== undefined
        ? workerData.intranetDisplayIndicator
        : true,
      
      // 10. teleworkIndicator - boolean
      teleworkIndicator: workerData.teleworkIndicator !== undefined
        ? workerData.teleworkIndicator
        : false,
      
      // 11. employmentType - REQUIRED simple object (no lifecycle/audit)
      employmentType: {
        id: this.workerEmploymentType === 'C' ? 3 : 5,
        value: this.workerEmploymentType,
        description: this.workerEmploymentType === 'C' ? 'Contractor' : 'Employee'
      },
      
      // 12. serviceAccountIndicator - boolean (can be true, false, or null for "either")
      serviceAccountIndicator: null,
      
      // 13. gradeStartDate - ISO format without milliseconds
      gradeStartDate: workerData.gradeStartDate
        ? formatDateWithoutMilliseconds(new Date(workerData.gradeStartDate))
        : null,
      
      // 14. stepStartDate - ISO format without milliseconds
      stepStartDate: workerData.stepStartDate
        ? formatDateWithoutMilliseconds(new Date(workerData.stepStartDate))
        : null,
      
      // 15. birthDate - MUST be null at root level (only in secure object for employees)
      birthDate: null,
      
      // 16. ssnLast2Digits - REQUIRED string: "66"
      ssnLast2Digits: workerData.ssnLast2Digits ? String(workerData.ssnLast2Digits) : null,
      
      // 17. lifecycle - REQUIRED with beginDate without milliseconds
      lifecycle: {
        beginDate: workerData.lifecycle?.beginDate
          ? formatDateWithoutMilliseconds(new Date(workerData.lifecycle.beginDate))
          : formatDateWithoutMilliseconds(new Date()),
        endDate: null
      },
      
      // 18. payplan - REQUIRED with full structure
      payplan: formatReferenceObject(
        workerData.payplan,
        this.referenceData.payPlans
      ),
      
      // 19. familyName - REQUIRED string
      familyName: workerData.familyName || '',
      
      // 20. givenName - REQUIRED string
      givenName: workerData.givenName || '',
      
      // 21. preferredFirstName - REQUIRED string
      preferredFirstName: workerData.preferredFirstName || workerData.givenName || '',
      
      // 22. jobClass - REQUIRED with full structure
      jobClass: formatReferenceObject(
        workerData.jobClass,
        this.referenceData.jobClasses
      ),
      
      // 23. positionOrganizationListing - REQUIRED string
      positionOrganizationListing: workerData.positionOrganizationListing || null,
      
      // 24. grade - REQUIRED with full structure
      grade: formatReferenceObject(
        workerData.grade,
        this.referenceData.grades
      ),
      
      // 25. step - REQUIRED with full structure
      step: formatReferenceObject(
        workerData.step,
        this.referenceData.steps
      ),
      
      // 26. occupationalSeries - REQUIRED with full structure
      occupationalSeries: formatReferenceObject(
        workerData.occupationalSeries,
        this.referenceData.occupationalSeries
      ),
   
      // 27. occupationalSeriesTitle - REQUIRED object with occupationalSeriesTitleId
      // The occupationalSeriesTitle should contain just the ID value
      // which gets wrapped in { occupationalSeriesTitleId: id } format
      occupationalSeriesTitle: workerData.occupationalSeriesTitle
        ? { occupationalSeriesTitleId: workerData.occupationalSeriesTitle }
        : null,
      
      // 28. teleworkProgram - null
      teleworkProgram: null,
      
      // 29. supervisorIndicator - boolean
      supervisorIndicator: workerData.supervisorIndicator !== undefined
        ? workerData.supervisorIndicator
        : false,
      
      // 30. teleworkProgramInvalid - boolean
      teleworkProgramInvalid: false,
      
      // 31. workerTrademarkIn - boolean
      workerTrademarkIn: false,
      
      // 32. secure - REQUIRED nested object with specific formats
      // NOTE: Only include properties that have values; omit null properties to match actual_payload.json structure
      secure: (() => {
        const secureObj: any = {
          birthCountryCode: workerData.birthCountry ? (typeof workerData.birthCountry === 'object' ? workerData.birthCountry.value : workerData.birthCountry) : null,
          birthCountryName: workerData.birthCountry ? (typeof workerData.birthCountry === 'object' ? workerData.birthCountry.description : (() => {
            // Look up country name from reference data if birthCountry is a string code
            const countryObj = this.referenceData.countries?.find((c: any) => c.value === workerData.birthCountry);
            return countryObj?.description || null;
          })()) : null,
          birthCityName: workerData.birthCityName || null,
          birthDate: workerData.birthDate ? formatSecureBirthDate(workerData.birthDate) : null,
          employeeSocialSecurity: workerData.employeeSocialSecurity ? workerData.employeeSocialSecurity.replace(/-/g, '') : null
        };
        
        // Only add contractorSocialSecurity if it has a value
        if (workerData.contractorSocialSecurity) {
          secureObj.contractorSocialSecurity = workerData.contractorSocialSecurity.replace(/-/g, '');
        }
        
        // Only add birthStateCode and birthStateName if birthState has a value
        if (workerData.birthState && workerData.birthState.trim()) {
          secureObj.birthStateCode = typeof workerData.birthState === 'object' ? workerData.birthState.value : workerData.birthState;
          secureObj.birthStateName = typeof workerData.birthState === 'object' ? workerData.birthState.description : (() => {
            // Look up state name from reference data if birthState is a string code
            const stateObj = this.referenceData.states?.find((s: any) => s.value === workerData.birthState);
            return stateObj?.description || null;
          })();
        }
        
        return secureObj;
      })(),
      
      // 33. payPlan - REQUIRED nested object with grade, step, payplan lifecycle info
      payPlan: {
        currentGrade: workerData.grade ? { id: Number(workerData.grade) } : null,
        currentStep: workerData.step ? { id: Number(workerData.step) } : null,
        currentPayPlan: workerData.payplan ? { id: Number(workerData.payplan) } : null,
        gradeLifecycle: workerData.gradeStartDate ? {
          beginDate: formatDateWithoutMilliseconds(new Date(workerData.gradeStartDate))
        } : null,
        stepLifecycle: workerData.stepStartDate ? {
          beginDate: formatDateWithoutMilliseconds(new Date(workerData.stepStartDate))
        } : null
      }
    };
    return payload;
  }

  private createWorker(workerData: any): void {
    // Build the payload matching the expected structure
    const hrWorkerPayload = this.buildHrWorkerPayload(workerData);
    
    this.showWait = true;
    this.workerManagementService.createWorker(hrWorkerPayload).subscribe(
      (response: any) => {
        this.showWait = false;
        this.navigateToSuccess(response);
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        
        // Handle field-specific validation errors from API
        if (error.status === 400 && errorMessage) {
          this.handleApiValidationError(errorMessage);
        } else {
          // Show generic error notification
          this.notificationService.showError(
            `Failed to create worker: ${errorMessage}`,
            '700'
          );
        }
      }
    );
  }

  private updateWorker(workerData: any): void {
    const workerId = this.workerBase.id || this.workerBase.workerId;
    const lockControlNumber = this.workerBase.audit?.lockControlNumber;
    
    if (!this.initialWorkerBase) {
      this.initialWorkerBase = JSON.parse(JSON.stringify(this.workerBase));
    }
    
    // Format the worker data for PUT call to match expected API payload
    const formattedWorkerData = this.buildFilteredWorkerPayload(workerData);
    this.showWait = true;
    this.workerManagementService.updateWorker(workerId, formattedWorkerData, lockControlNumber).subscribe(
      (response: any) => {
        this.showWait = false;
        this.navigateToSuccess(response);
      },
      (error: any) => {
        this.showWait = false;
        if (this.initialWorkerBase) {
          this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
        }
        const errorMessage = this.extractErrorMessage(error);
        
        // Handle field-specific validation errors from API
        if (error.status === 400 && errorMessage) {
          this.handleApiValidationError(errorMessage);
        } else {
          // Show generic error notification
          this.notificationService.showError(
            `Failed to update worker: ${errorMessage}`,
            '700'
          );
        }
      }
    );
  }

  private saveWorkerHR(workerData: any, updateParams: any): void {
    this.showWait = true;
    const workerId = this.workerBase.id || this.workerBase.workerId;

    // Make two PUT calls in sequence:
    // 1. First PUT: secure-workers (if secure data exists)
    // 2. Second PUT: workers (primary/details)
    
    if (this.canViewSecureData() && workerData.secure) {
      this.saveWorkerSecureDataThenPrimary(workerId, workerData, updateParams);
    } else {
      this.saveWorkerPrimaryAndDetails(workerId, workerData, updateParams);
    }
  }

  private saveWorkerAdminAndContractorAdmin(workerData: any, updateParams: any): void {
    this.showWait = true;
    const workerId = this.workerBase.id || this.workerBase.workerId;

    // Make two PUT calls in sequence:
    // 1. First PUT: secure-workers (if secure data exists)
    // 2. Second PUT: workers (primary/details)
    
    if (this.canViewSecureData() && workerData.secure) {
      this.saveWorkerSecureDataThenPrimary(workerId, workerData, updateParams);
    } else {
      this.saveWorkerPrimaryAndDetails(workerId, workerData, updateParams);
    }
  }

  private saveWorkerSecureDataThenPrimary(workerId: string, workerData: any, updateParams: any): void {
    const secureData = workerData.secure;
    
    if (!secureData) {
      this.saveWorkerPrimaryAndDetails(workerId, workerData, updateParams);
      return;
    }
    this.workerManagementService.saveWorkerSecureInformation(workerId, secureData, updateParams).subscribe(
      (response: any) => {
        // After secure data is saved, make the second PUT call for primary/details
        this.saveWorkerPrimaryAndDetailsOnly(workerId, workerData, updateParams);
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker secure information: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  private saveWorkerPrimaryAndDetailsOnly(workerId: string, workerData: any, updateParams: any): void {
    const workerDataForUpdate = this.buildFilteredWorkerPayload(workerData);
    this.workerManagementService.updateWorker(workerId, workerDataForUpdate, updateParams.lockControlNumber).subscribe(
      (response: any) => {
        // Update lock control number from response for subsequent calls
        if (response?.audit?.lockControlNumber) {
          updateParams.lockControlNumber = response.audit.lockControlNumber;
        }
        
        // After both PUT calls complete, save location assignments first
        this.saveLocationAssignments(workerId, updateParams, response);
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker primary and details: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  private saveWorkerOfficeCoordinator(workerData: any, updateParams: any): void {
    this.showWait = true;
    const workerId = this.workerBase.id || this.workerBase.workerId;
    this.saveWorkerPrimaryAndDetails(workerId, workerData, updateParams);
  }

  private saveWorkerSecureData(workerId: string, workerData: any, updateParams: any): void {
    const secureData = workerData.secure;
    
    if (!secureData) {
      this.showWait = false;
      this.navigateToSuccess();
      return;
    }
    this.workerManagementService.saveWorkerSecureInformation(workerId, secureData, updateParams).subscribe(
      (response: any) => {
        this.showWait = false;
        this.navigateToSuccess(response);
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker secure information: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  private saveWorkerPrimaryAndDetails(workerId: string, workerData: any, updateParams: any): void {
    const workerDataForUpdate = this.buildFilteredWorkerPayload(workerData);
    this.workerManagementService.updateWorker(workerId, workerDataForUpdate, updateParams.lockControlNumber).subscribe(
      (response: any) => {
        // After primary/details update, check if we need to save secure data
        if (this.canViewSecureData() && workerData.secure) {
          this.saveWorkerSecureDataAfterPrimaryUpdate(workerId, workerData, updateParams, response);
        } else {
          // Save location assignments before proceeding to accession or completion
          this.saveLocationAssignments(workerId, updateParams, response);
        }
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker primary and details: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  private saveWorkerSecureDataAfterPrimaryUpdate(workerId: string, workerData: any, updateParams: any, primaryDetailsResponse?: any): void {
    const secureData = workerData.secure;
    
    if (!secureData) {
      // Save location assignments before proceeding
      this.saveLocationAssignments(workerId, updateParams, primaryDetailsResponse);
      return;
    }
    this.workerManagementService.saveWorkerSecureInformation(workerId, secureData, updateParams).subscribe(
      (response: any) => {
        // After secure data is saved, save location assignments
        this.saveLocationAssignments(workerId, updateParams, primaryDetailsResponse);
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker secure information: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  /**
   * Build list of worker assignments that have been edited
   * Based on legacy buildAssignmentsEditedList function
   */
  private buildAssignmentsEditedList(workerAssignments: any[]): any[] {
    const editedAssignments: any[] = [];
    
    if (!workerAssignments || !Array.isArray(workerAssignments)) {
      return editedAssignments;
    }
    workerAssignments.forEach((assignment: any, index: number) => {
      if (assignment.edited === true) {
        editedAssignments.push(assignment);
      } else {
      }
    });
    return editedAssignments;
  }

  /**
   * Save worker location assignments
   * Based on legacy saveLocationAssignments function
   * Makes PUT calls to update worker organization and assignment data
   */
  private saveLocationAssignments(workerId: string, updateParams: any, primaryDetailsResponse?: any): void {
    // Fetch latest worker data to get updated lock control numbers
    this.workerManagementService.getWorkerById(workerId).subscribe(
      (latestWorkerData: any) => {
        // Update the lock control number from latest data
        if (latestWorkerData.audit?.lockControlNumber) {
          updateParams.lockControlNumber = latestWorkerData.audit.lockControlNumber;
        }
        
        // Fetch latest assignments to get their lock control numbers
        this.workerManagementService.getWorkerAssignments(parseInt(workerId, 10)).subscribe(
          (assignmentsResponse: any) => {
            const latestAssignments = assignmentsResponse.results || assignmentsResponse;
            
            // Update lock control numbers in workerBase.workerAssignments
            if (Array.isArray(latestAssignments) && Array.isArray(this.workerBase.workerAssignments)) {
              this.workerBase.workerAssignments.forEach((assignment: any) => {
                const latestAssignment = latestAssignments.find((la: any) =>
                  la.workerAssignmentId === assignment.workerAssignmentId
                );
                if (latestAssignment?.audit?.lockControlNumber) {
                  if (!assignment.audit) {
                    assignment.audit = {};
                  }
                  assignment.audit.lockControlNumber = latestAssignment.audit.lockControlNumber;
                }
              });
            }
            
            // Now proceed with saving assignments
            this.processSaveLocationAssignments(workerId, updateParams, primaryDetailsResponse);
          },
          (error: any) => {
            // Proceed anyway with existing lock control numbers
            this.processSaveLocationAssignments(workerId, updateParams, primaryDetailsResponse);
          }
        );
      },
      (error: any) => {
        // Proceed anyway with existing lock control numbers
        this.processSaveLocationAssignments(workerId, updateParams, primaryDetailsResponse);
      }
    );
  }

  private processSaveLocationAssignments(workerId: string, updateParams: any, primaryDetailsResponse?: any): void {
    const workerAssignments = this.workerBase.workerAssignments;
    const editedAssignments = this.buildAssignmentsEditedList(workerAssignments);
    
    if (!editedAssignments || editedAssignments.length === 0) {
      if (this.workerEmploymentType !== 'C') {
        this.saveWorkerAccession(workerId, updateParams, primaryDetailsResponse);
      } else {
        this.navigateToSuccess(primaryDetailsResponse);
      }
      return;
    }
    
    // Create array of observables for all update operations
    const updateObservables: any[] = [];
    
    editedAssignments.forEach((assignment: any, index: number) => {
      // CRITICAL FIX: Ensure workerOrganizationId is populated - try multiple sources
      if (assignment.workerOrganization && !assignment.workerOrganization.workerOrganizationId) {
        // Try to get from assignment.workerOrganization.id
        if (assignment.workerOrganization.id) {
          assignment.workerOrganization.workerOrganizationId = assignment.workerOrganization.id;
        }
        // Try to get from assignment root level
        else if (assignment.workerOrganizationId) {
          assignment.workerOrganization.workerOrganizationId = assignment.workerOrganizationId;
        }
        // Try to get from assignment.id (some APIs return it this way)
        else if (assignment.id) {
          assignment.workerOrganization.workerOrganizationId = assignment.id;
        }
        else {
        }
      }
      
      // PUT CALL #1: Update worker organization
      if (assignment.workerOrganization && assignment.workerOrganization.workerOrganizationId) {
        // Helper function to format date without milliseconds and Z
        const formatDateForPayload = (dateStr: string): string => {
          if (!dateStr) return dateStr;
          const date = new Date(dateStr);
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');
          const seconds = String(date.getSeconds()).padStart(2, '0');
          return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
        };
        
        // Extract location data with proper fallbacks
        const locationId = assignment.assignmentLocation?.locationId || assignment.location?.locationId;
        const corridorId = assignment.location?.corridorId || assignment.assignmentLocation?.corridorId || "1";
        const roomId = assignment.location?.roomId || assignment.assignmentLocation?.roomId || "1";
        const suiteId = assignment.location?.suiteId || assignment.assignmentLocation?.suiteId || "1";
        const zoneId = assignment.location?.zoneId || assignment.assignmentLocation?.zoneId || "1";
        
        // Extract building data with proper fallbacks
        const building = assignment.location?.building || assignment.assignmentLocation?.building || {};
        const buildingFloorId = building.buildingFloorId || 816;
        const floorNumber = building.floorNumber || "15";
        const buildingId = building.buildingId || building.id || 77;
        const buildingCode = building.code || "ABC27";
        const buildingName = building.name || building.code || "ABC27";
        const buildingState = building.state || "GA";
        const buildingZip = building.zip || "55555";
        
        const organizationPayload = {
          workerOrganizationId: assignment.workerOrganization.workerOrganizationId,
          primaryOrganizationIndicator: assignment.workerOrganization.primaryOrganizationIndicator !== undefined
            ? assignment.workerOrganization.primaryOrganizationIndicator
            : true,
          organization: {
            id: assignment.workerOrganization.organization.id,
            shortName: assignment.workerOrganization.organization.shortName,
            businessAreaCode: assignment.workerOrganization.organization.businessAreaCode,
            acronym: assignment.workerOrganization.organization.acronym
          },
          organizationStatusCurrent: assignment.workerOrganization.organizationStatusCurrent || 'A',
          lifecycle: {
            beginDate: formatDateForPayload(assignment.workerOrganization.lifecycle?.beginDate || assignment.lifecycle?.beginDate)
          },
          locationSummary: [{
            workerAssignmentId: assignment.workerAssignmentId,
            assignmentStatusCurrent: assignment.assignmentStatusCurrent || 'A',
            locationSummary: {
              locationId: locationId,
              corridorId: corridorId,
              roomId: roomId,
              suiteId: suiteId,
              zoneId: zoneId,
              building: {
                buildingFloorId: buildingFloorId,
                floorNumber: floorNumber,
                buildingId: buildingId,
                code: buildingCode,
                name: buildingName,
                state: buildingState,
                zip: buildingZip
              }
            },
            lifecycle: {
              beginDate: formatDateForPayload(assignment.lifecycle?.beginDate)
            },
            primaryLocationIn: assignment.primaryLocationIndicator !== undefined
              ? assignment.primaryLocationIndicator
              : true,
            suffixId: assignment.suffixId || 1
          }],
          reportRoleList: assignment.workerOrganization.reportRoleList || [],
          workerOrganizationQueue: assignment.workerOrganization.workerOrganizationQueue || null
        };
        
        const orgLockControlNumber = assignment.workerOrganization.audit?.lockControlNumber || 0;
        const orgLockControlNumberParam = JSON.stringify({ lockControlNumber: orgLockControlNumber });
        
        updateObservables.push(
          this.workerManagementService.updateWorkerOrganization(
            workerId.toString(),
            assignment.workerOrganization.workerOrganizationId.toString(),
            organizationPayload,
            orgLockControlNumberParam
          )
        );
      }
      
      // PUT CALL #2: Update worker assignment
      if (assignment.workerAssignmentId) {
        const formatDateForPayload = (dateStr: string): string => {
          if (!dateStr) return dateStr;
          const date = new Date(dateStr);
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');
          const seconds = String(date.getSeconds()).padStart(2, '0');
          return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
        };
        
        const assignmentPayload: any = {
          workerAssignmentId: assignment.workerAssignmentId,
          workerOrganization: {
            workerOrganizationId: assignment.workerOrganization?.workerOrganizationId,
            organization: {
              id: assignment.workerOrganization?.organization?.id,
              shortName: assignment.workerOrganization?.organization?.shortName,
              name: assignment.workerOrganization?.organization?.name,
              businessAreaCode: assignment.workerOrganization?.organization?.businessAreaCode
            }
          },
          assignmentLocation: {
            locationId: assignment.assignmentLocation?.locationId || assignment.location?.locationId
          },
          mailLocation: (assignment.mailLocation && Object.keys(assignment.mailLocation).length > 0) ? assignment.mailLocation : null,
          palmLocation: (assignment.palmLocation && Object.keys(assignment.palmLocation).length > 0) ? assignment.palmLocation : null,
          assignmentStatusCurrent: assignment.assignmentStatusCurrent || 'A',
          lifecycle: {
            beginDate: formatDateForPayload(assignment.lifecycle?.beginDate)
          },
          primaryLocationIndicator: assignment.primaryLocationIndicator !== undefined
            ? assignment.primaryLocationIndicator
            : true,
          hiddenIndicator: assignment.hiddenIndicator !== undefined
            ? assignment.hiddenIndicator
            : false
        };
        
        const assignmentLockControlNumber = assignment.audit?.lockControlNumber || 0;
        const assignmentLockControlNumberParam = JSON.stringify({ lockControlNumber: assignmentLockControlNumber });
        
        updateObservables.push(
          this.workerManagementService.updateWorkerAssignment(
            workerId.toString(),
            assignment.workerAssignmentId.toString(),
            assignmentPayload,
            assignmentLockControlNumberParam
          )
        );
      }
    });
    
    if (updateObservables.length === 0) {
      if (this.workerEmploymentType !== 'C') {
        this.saveWorkerAccession(workerId, updateParams, primaryDetailsResponse);
      } else {
        this.navigateToSuccess(primaryDetailsResponse);
      }
      return;
    }
    
    // Execute all updates using forkJoin
    forkJoin(updateObservables).subscribe(
      (responses: any[]) => {
        if (this.workerEmploymentType !== 'C') {
          this.saveWorkerAccession(workerId, updateParams, primaryDetailsResponse);
        } else {
          this.navigateToSuccess(primaryDetailsResponse);
        }
      },
      (error: any) => {
        this.showWait = false;
        const errorMessage = this.extractErrorMessage(error);
        this.notificationService.showError(
          `Failed to save worker location assignments: ${errorMessage}`,
          '700'
        );
        this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      }
    );
  }

  private saveWorkerAccession(workerId: string, updateParams: any, primaryDetailsResponse?: any): void {
    const workerAccession = this.workerBase.workerAccession;

    if (!workerAccession) {
      this.navigateToSuccess(primaryDetailsResponse);
      return;
    }
    if (!workerAccession.fkWorkerId || !workerAccession.accessionDt) {
      this.workerManagementService.addWorkerAccession(workerAccession, updateParams).subscribe(
        (response: any) => {
          this.navigateToSuccess(primaryDetailsResponse);
        },
        (error: any) => {
          this.showWait = false;
          const errorMessage = this.extractErrorMessage(error);
          this.notificationService.showError(
            `Failed to save worker accession: ${errorMessage}`,
            '700'
          );
          this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
        }
      );
    } else {
      this.workerManagementService.updateWorkerAccession(workerAccession, updateParams).subscribe(
        (response: any) => {
          this.navigateToSuccess(primaryDetailsResponse);
        },
        (error: any) => {
          this.showWait = false;
          const errorMessage = this.extractErrorMessage(error);
          this.notificationService.showError(
            `Failed to update worker accession: ${errorMessage}`,
            '700'
          );
          this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
        }
      );
    }
  }

  private navigateToSuccess(response?: any): void {
    this.showWait = false;
    const workerId = response?.workerId || this.workerBase.worker?.workerId || this.workerBase.workerId;
    
    // Extract lastName from form or workerBase
    let lastName = '';
    if (this.primaryInfoTab?.value?.lastName) {
      lastName = this.primaryInfoTab.value.lastName;
    } else if (this.workerBase.worker?.lastName) {
      lastName = this.workerBase.worker.lastName;
    } else if (this.workerBase.worker?.familyName) {
      lastName = this.workerBase.worker.familyName;
    }
    
    // Extract workerNo and workerNumber - check response first, then workerBase
    let workerNo = '';
    if (response?.workerNo) {
      workerNo = response.workerNo;
    } else if (this.workerBase.worker?.workerNo) {
      workerNo = this.workerBase.worker.workerNo;
    } else if (this.workerBase.workerNo) {
      workerNo = this.workerBase.workerNo;
    }
    
    // Extract workerNumber (can be different from workerNo)
    // Check response first, then workerBase
    let workerNumber = '';
    if (response?.workerNumber) {
      workerNumber = response.workerNumber;
    } else if (response?.workerNo) {
      workerNumber = response.workerNo;
    } else if (this.workerBase.worker?.workerNumber) {
      workerNumber = this.workerBase.worker.workerNumber;
    } else if (this.workerBase.workerNumber) {
      workerNumber = this.workerBase.workerNumber;
    } else {
      // Fallback to workerNo if workerNumber not found
      workerNumber = workerNo;
    }
    
    const status = this.editAddMode ? 'updated' : 'created';
    const workerType = this.applicationType === 'Contractor' ? 'Contractor' : 'Worker';
    
    const successData = {
      workerNumber: workerNumber,
      lastName: lastName,
      workerNo: workerNumber, // Use workerNumber for display (e.g., "C45655")
      workerId: workerId,
      status: status as 'created' | 'updated',
      workerType: workerType as 'Worker' | 'Contractor'
    };
    this.notificationService.setSuccessMessageData(successData);
    
    // For contractors, navigate to workerManagement/Contractor page
    // For workers, navigate to worker management with status
    let navigationPath: string[];
    if (this.applicationType === 'Contractor') {
      navigationPath = ['/app', 'workerManagement', 'Contractor'];
    } else {
      navigationPath = ['/app', 'workerManagement', this.applicationType, status, workerId];
    }
    // Small delay to ensure service data is set before navigation
    setTimeout(() => {
      this.router.navigate(navigationPath).then(
        (success) => {
        },
        (error) => {
        }
      );
    }, 100);
  }

  private navigateToWorkerSearch(): void {
    this.router.navigate(['/app/workerManagement', this.applicationType]);
  }

  private showErrorMessage(title: string, error: any): void {
    // Error handling - can be extended for dialog display if needed
  }

  /**
   * Extract error message from various error response formats
   * Handles API errors, HTTP errors, and string errors
   */
  private extractErrorMessage(error: any): string {
    if (!error) {
      return 'An unknown error occurred';
    }
    
    // Check for various error response formats
    if (typeof error === 'string') {
      return error;
    }
    
    // Prioritize error.error.message (actual API error) over error.message (HTTP error wrapper)
    if (error.error) {
      if (typeof error.error === 'string') {
        return error.error;
      }
      if (error.error.message) {
        return error.error.message;
      }
      if (error.error.error) {
        return error.error.error;
      }
    }
    
    // Fallback to error.message (may contain HTTP wrapper message)
    if (error.message) {
      return error.message;
    }
    
    if (error.statusText) {
      return error.statusText;
    }
    
    return 'An error occurred. Please try again.';
  }

  /**
   * Trigger validation for all primary info fields
   * This marks the fields as touched so validation errors are displayed
   * and sets validation booleans for tracking
   */
  private triggerPrimaryInfoValidation(): void {
    // Validate always-required fields
    const firstNameControl = this.primaryInfoTab.get('firstName');
    const lastNameControl = this.primaryInfoTab.get('lastName');
    const preferredFirstNameControl = this.primaryInfoTab.get('preferredFirstName');
    
    if (firstNameControl) {
      firstNameControl.markAsTouched();
      firstNameControl.updateValueAndValidity();
      this.validationBooleans.invalidFirstName = firstNameControl.invalid;
    }
    
    if (lastNameControl) {
      lastNameControl.markAsTouched();
      lastNameControl.updateValueAndValidity();
      this.validationBooleans.invalidLastName = lastNameControl.invalid;
    }
    
    if (preferredFirstNameControl) {
      preferredFirstNameControl.markAsTouched();
      preferredFirstNameControl.updateValueAndValidity();
      this.validationBooleans.invalidPreferredFirstName = preferredFirstNameControl.invalid;
    }
    
    // Validate conditional fields (birthDate and ssnLast2Digits)
    const birthDateControl = this.primaryInfoTab.get('birthDate');
    const ssnControl = this.primaryInfoTab.get('ssnLast2Digits');
    
    // Only trigger validation for fields that are visible and have validators
    if (birthDateControl && this.isFieldVisible('birthDate')) {
      birthDateControl.markAsTouched();
      birthDateControl.updateValueAndValidity();
      this.validationBooleans.invalidBirthDate = birthDateControl.invalid;
    }
    
    if (ssnControl && this.isFieldVisible('ssnLast2Digits')) {
      ssnControl.markAsTouched();
      ssnControl.updateValueAndValidity();
      this.validationBooleans.invalidSsnLast2Digits = ssnControl.invalid;
    }
  }

  /**
   * Check if a field should be visible based on employment type and user roles
   * @param fieldName Name of the field
   * @returns True if field should be visible
   */
  private isFieldVisible(fieldName: string): boolean {
    return this.workerValidationsService.isFieldVisible(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      this.canViewSecureData()
    );
  }

  /**
   * Handle API validation errors and set them on the appropriate form controls
   * @param errorMessage The error message from the API
   */
  private handleApiValidationError(errorMessage: string): void {
    let errorHandled = false;

    // Check for age validation error (date of birth)
    if (errorMessage.includes('16 years old') || errorMessage.includes('Employee needs to be')) {
      const birthDateControl = this.primaryInfoTab.get('birthDate');
      if (birthDateControl) {
        birthDateControl.setErrors({ 'apiValidation': errorMessage });
        birthDateControl.markAsTouched();
        errorHandled = true;
      }
    }

    // Check for SSN required error
    if (errorMessage.includes('Contractor SSN') ||
        (errorMessage.includes('SSN') && errorMessage.includes('required'))) {
      const ssnControl = this.primaryInfoTab.get('ssnLast2Digits');
      if (ssnControl) {
        ssnControl.setErrors({ 'apiValidation': errorMessage });
        ssnControl.markAsTouched();
        errorHandled = true;
      }
    }

    // Check for date of birth required error
    if ((errorMessage.includes('date of birth') || errorMessage.includes('Date of birth') ||
         errorMessage.includes('DOB') || errorMessage.includes('birthDate')) &&
        errorMessage.includes('required')) {
      const birthDateControl = this.primaryInfoTab.get('birthDate');
      if (birthDateControl) {
        birthDateControl.setErrors({ 'apiValidation': errorMessage });
        birthDateControl.markAsTouched();
        errorHandled = true;
      }
    }

    // Always show the notification
    this.notificationService.showError(errorMessage, '700');
  }
  /**
   * Validates contractor ID (DOB + Last 2 SSN) before creating a new contractor
   * This is called in ADD mode only, before the POST /hrWorkers call
   * @param workerData The worker data being created
   */
  private validateContractorIdBeforeCreate(workerData: any): void {
    // Check if we have the required fields
    if (!workerData.birthDate || !workerData.ssnLast2Digits) {
      this.createWorker(workerData);
      return;
    }
    
    // Format birthDate to MM/DD/YYYY for the API call
    // Parse date string directly to avoid timezone issues
    const formatDateForValidation = (dateStr: string): string => {
      // Handle both ISO format (yyyy-MM-dd) and other formats
      let year: number, month: number, day: number;
      
      if (dateStr.includes('-')) {
        // ISO format: "2004-02-02" or "2004-02-02T00:00:00"
        const parts = dateStr.split('T')[0].split('-');
        year = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10);
        day = parseInt(parts[2], 10);
      } else if (dateStr.includes('/')) {
        // Already in MM/DD/YYYY format
        const parts = dateStr.split('/');
        month = parseInt(parts[0], 10);
        day = parseInt(parts[1], 10);
        year = parseInt(parts[2], 10);
      } else {
        // Fallback to Date object parsing
        const date = new Date(dateStr);
        year = date.getFullYear();
        month = date.getMonth() + 1;
        day = date.getDate();
      }
      
      return `${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}/${year}`;
    };
    
    const formattedBirthDate = formatDateForValidation(workerData.birthDate);
    const contractorSSN = String(workerData.ssnLast2Digits);
    // Call the validation API
    this.workerManagementService
      .validateContractorId(formattedBirthDate, contractorSSN)
      .subscribe(
        (response: any) => {
          // Check if any contractors were found
          if (response && response.results && response.results.length > 0) {
            // Contractor with same DOB + SSN already exists
            const existingContractor = response.results[0];
            // Extract worker number - try multiple possible field names
            const workerNumber = existingContractor.workerNumber
              || existingContractor.workerId
              || existingContractor.id
              || existingContractor.employeeNumber
              || 'Unknown';
            
            const errorMessage = `Contractor ID (DOB + Last 2 SSN) already exists for user ${workerNumber}. Please provide a different DOB/Last 2 SSN combination`;
            // Display error via ACME navbar
            this.workerManagementService.showValidationErrors([errorMessage]);
            
            // Verify the message was set
            setTimeout(() => {
              // Check what the service observables are emitting
              this.workerManagementService.returnMessagesArray$.subscribe(msgs => {
              }).unsubscribe();
              
              this.workerManagementService.returnCode$.subscribe(code => {
              }).unsubscribe();
              
              this.workerManagementService.hideMessage$.subscribe(hide => {
              }).unsubscribe();
            }, 100);
            
            // Mark form fields as invalid and touched to show inline errors
            // Set error on birthDate to show red border, but without message text
            // Set error on SSN field with the full message
            const birthDateControl = this.primaryInfoTab.get('birthDate');
            const ssnControl = this.primaryInfoTab.get('ssnLast2Digits');
            
            if (birthDateControl) {
              // Set a silent error to trigger red border without displaying message
              birthDateControl.setErrors({ 'duplicateContractorSilent': true });
              birthDateControl.markAsTouched();
            }
            
            if (ssnControl) {
              // Set custom error with the full message for SSN field
              ssnControl.setErrors({ 'duplicateContractor': errorMessage });
              ssnControl.markAsTouched();
            }
            
            // Scroll to top to show error message and ensure page remains scrollable
            setTimeout(() => {
              // Ensure body and html elements are scrollable
              document.body.style.overflow = 'auto';
              document.documentElement.style.overflow = 'auto';
              
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }, 100);
            
            this.cdr.detectChanges();
          } else {
            // No existing contractor found - proceed with creation
            this.createWorker(workerData);
          }
        },
        (error: any) => {
          // If the API returns an error, it might mean a contractor exists
          // Check if error contains workerNumber
          if (error && error.workerNumber) {
            const errorMessage = `Contractor ID (DOB + Last 2 SSN) already exists for user ${error.workerNumber}. Please provide a different DOB/Last 2 SSN combination`;
            // Display error via ACME navbar
            this.workerManagementService.showValidationErrors([errorMessage]);
            
            // Mark form fields as invalid and touched to show inline errors
            // Set error on birthDate to show red border, but without message text
            // Set error on SSN field with the full message
            const birthDateControl = this.primaryInfoTab.get('birthDate');
            const ssnControl = this.primaryInfoTab.get('ssnLast2Digits');
            
            if (birthDateControl) {
              // Set a silent error to trigger red border without displaying message
              birthDateControl.setErrors({ 'duplicateContractorSilent': true });
              birthDateControl.markAsTouched();
            }
            
            if (ssnControl) {
              // Set custom error with the full message for SSN field
              ssnControl.setErrors({ 'duplicateContractor': errorMessage });
              ssnControl.markAsTouched();
            }
            
            // Scroll to top to show error message and ensure page remains scrollable
            setTimeout(() => {
              // Ensure body and html elements are scrollable
              document.body.style.overflow = 'auto';
              document.documentElement.style.overflow = 'auto';
              
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }, 100);
            
            this.cdr.detectChanges();
          } else {
            // Other API error - proceed with creation (let the create API handle it)
            this.createWorker(workerData);
          }
        }
      );
  }

  /**
   * Legacy method - kept for backward compatibility with existing code
   * This is used in EDIT mode
   */
  validateContractorId() {
    // if (WorkerAddControllerHelper.canViewSecureData(this.userRoles, this.workerEmploymentType) &&
    //   this.workerEmploymentType === 'C') {
    //check for date of birth and last two ssn valid
    //validate Contractor Id (DOB + last 2 SSN)
    if (!!this.workerBase.worker.birthDate && !!this.workerBase.worker.ssnLast2Digits) {
      this.workerManagementService
        .validateContractorId(
          this.workerBase.worker.birthDate,
          this.workerBase.worker.ssnLast2Digits
        )
        .subscribe(
          (response: any) => {
            this.validationBooleans.invalidContractorIdErrorMsg = '';
            this.validationBooleans.invalidContractorId = false;
            this.addWorker();
          },
          (error: any) => {
            this.validationBooleans.invalidContractorIdErrorMsg =
              'Contractor ID (DOB + Last 2 SSN) already exists for user ' +
              error.workerNumber +
              '. Please provide a different DOB/Last 2 SSN combination';
            this.validationBooleans.invalidContractorId = true;
            this.addWorker();
          }
        );
    } else {
      this.validationBooleans.invalidContractorIdErrorMsg = '';
      this.validationBooleans.invalidContractorId = false;
      this.addWorker();
    }
    //}
  }
  /**
   * This method is redirects to worker search view.
   */
  exitToWorkerSearchWithoutSave() {
    this.appService.changePage('/workerManagement/' + this.applicationType);
  }

  /**
   * Shows confirmation dialog before exiting add worker page
   * Uses DialogComponent from relocation-management
   */
  confirmExitAddWorker() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Exit without saving?',
        titleType: 'danger',
        content: `You have not saved and submitted this updated information for this worker. Would you like to save and submit information before exiting?`,
        cancelButton: true,
        primaryButton: 'Save and Exit',
        primaryButtonType: 'primary',
        secondaryButton: 'No, exit without saving',
        secondaryButtonType: 'danger'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === true) {
        // User clicked "Save and Exit"
        this.addWorker();
      } else if (result === 'exit') {
        // User clicked "No, exit without saving"
        this.exitToWorkerSearchWithoutSave();
      }
      // If result is false or undefined, user clicked Cancel - do nothing
    });
  }

  /**
   * Shows confirmation dialog before resetting add worker form
   * Uses DialogComponent from relocation-management
   */
  confirmResetAddWorker() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Reset and clear information?',
        content: 'You have not saved the information for this worker.</br>Resetting the screen will clear all of the changes entered for this worker.',
        primaryButton: 'Cancel',
        primaryButtonType: 'primary',
        secondaryButton: 'Yes, clear all changes',
        secondaryButtonType: 'danger'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'exit') {
        // User clicked "Yes, clear all changes"
        this.handleResetWorker();
      }
      // If result is false or undefined, user clicked Cancel - do nothing
    });
  }

  /**
   * Handles reset worker event from worker-navbar
   * Resets all form inputs and templates back to original values
   */
  handleResetWorker() {
    // Log current form state before reset
    // Check if we have original data stored (edit mode)
    if (this.initialWorkerBase && this.editAddMode) {
      // Deep clone to avoid reference issues
      this.workerBase = JSON.parse(JSON.stringify(this.initialWorkerBase));
      this.prefillWorkerForm(this.workerBase);
    } else {
      this.primaryInfoTab.reset();
      this.detailsInfo.reset();
      this.conInfoTab.reset();
      if (this.workerBase.workerAssignments) {
        this.workerBase.workerAssignments = [];
      }
      if (this.workerBase.workerCommunications) {
        this.workerBase.workerCommunications = [];
      }
      this.initilaiseForm();
    }
    this.validationErrorMessages = [];
    this.hideMessage = true;
    // Log final form state after reset
  }

  /**
   * Handles exit worker event from worker-navbar
   * Navigates back to worker search without saving
   */
  handleExitWorker() {
    this.exitToWorkerSearchWithoutSave();
  }

  @ViewChild('workerAddPrimaryInfoTab') workerAddPrimaryInfoTab!: any;
  @ViewChild('workerAddConfInfoTab') workerAddConfInfoTab!: any;
  @ViewChild('workerAddDetailInfoTab') workerAddDetailInfoTab!: any;
  @ViewChild('workerOrgLocationAssgnmt') workerOrgLocationAssgnmt!: any;
  @ViewChild('workerCommAddressAssgnmt') workerCommAddressAssgnmt!: any;
  @ViewChild('workerOrgRoleAssgnmt') WorkerRoleAssignment!: any;
  @ViewChild('workerOverrideTab') workerOverrideTab!: any;

  public handleScrollOffSet(elementID: string): void {
    // CRITICAL FIX: Preserve scroll position to prevent jumping when accordion expands
    // Store current scroll position before any changes
    this.lastScrollPosition = window.pageYOffset;
    
    // Handle tab-level scrolling with offset for fixed navbar
    const navbarHeight = 120; // Adjust this value based on your navbar height
    
    // Expand confidential info accordion when user clicks on that tab
    if (elementID === 'workerAddConfInfoTab') {
      this.expandConfInfoTab = true;
    } else {
      this.expandConfInfoTab = false;
    }
    
    let element: any = null;
    if (elementID === 'workerAddPrimaryInfoTab')
      element = this.workerAddPrimaryInfoTab;
    else if (elementID === 'workerAddConfInfoTab')
      element = this.workerAddConfInfoTab;
    else if (elementID === 'workerAddDetailInfoTab')
      element = this.workerAddDetailInfoTab;
    else if (elementID === 'workerOrgLocationAssgnmt')
      element = this.workerOrgLocationAssgnmt;
    else if (elementID === 'workerCommAddressAssgnmt')
      element = this.workerCommAddressAssgnmt;
    else if (elementID === 'workerOrgRoleAssgnmt')
      element = this.WorkerRoleAssignment;
    else if (elementID === 'workerOverrideTab')
      element = this.workerOverrideTab;
    
    if (element && element.nativeElement) {
      const elementPosition = element.nativeElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navbarHeight;
      
      // Use requestAnimationFrame to ensure scroll happens after layout is stable
      requestAnimationFrame(() => {
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      });
      return;
    }

    // Handle field-level scrolling for error message hyperlinks
    const fieldElement = document.getElementById(elementID);
    if (fieldElement) {
      // Use requestAnimationFrame to ensure scroll happens after layout is stable
      requestAnimationFrame(() => {
        fieldElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
      
      // Try to focus on the field if it's an input or select element
      const inputElement = fieldElement.querySelector('input, select, textarea') as HTMLElement;
      if (inputElement) {
        setTimeout(() => {
          inputElement.focus();
        }, 300); // Small delay to allow scroll to complete
      }
    }
  }

  /**
   * Validates worker details on save
   * Calls the worker validations service to check mandatory fields
   * Returns validation result with error messages
   */
  private validateWorkerDetailsOnSave(workerData: any): { isValid: boolean; errorMessages: string[] } {
    const validationResult = this.workerValidationsService.validateWorkerDetailsOnSave(
      workerData,
      this.userRoles,
      this.workerEmploymentType,
      this.validationBooleans
    );
    return validationResult;
  }

  /**
   * Shows validation error dialog with all error messages
   * Follows the old AngularJS pattern from workerUpdate.controller.js
   */
  private showValidationErrorDialog(errorMessages: string[]): void {
    const errorMessage = errorMessages.join('\n');
    const dialogData = {
      title: 'Validation Error',
      message: 'Please correct the following errors before saving:\n\n' + errorMessage,
      type: 'error',
      confirmText: 'OK',
      showCancel: false
    };
    try {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '600px',
        data: dialogData
      });
      // Log when dialog is closed
      dialogRef.afterClosed().subscribe((result) => {
      });
    } catch (error) {
    }
  }

 /**
  * Extracts field ID from error message for navigation
  * Error messages are in format: "[TabName] FieldName: Error message"
  * Extracts the field name and converts it to field ID
  */
 public extractFieldIdFromError(errorMsg: string): string {
   if (!errorMsg || typeof errorMsg !== 'string') {
     return '';
   }
   
   let fieldName = '';
   
   // Extract field name from new format: "Field name is required" (no brackets or colons)
   // The error message is just the field name followed by " is required" or other error text
   // Extract everything before " is " or " has " or other error indicators
   let match = errorMsg.match(/^([^i]+?)\s+(?:is|has|must)/i);
   if (match && match[1]) {
     fieldName = match[1].trim();
   } else {
     // Fallback: if no match, try to get the first part before any common error keywords
     match = errorMsg.match(/^([^:]+?)(?:\s+is|\s+has|\s+must|:)/);
     if (match && match[1]) {
       fieldName = match[1].trim();
     }
   }
   
   if (fieldName) {
     // Convert field name to camelCase field ID
     // e.g., "Position sensitivity" -> "positionSensitivity"
     // e.g., "Leave accrual" -> "leaveAccrual"
     // e.g., "Type of appointment" -> "typeOfAppointment"
     // e.g., "Last name" -> "lastName"
     // e.g., "First name" -> "firstName"
     const camelCase = fieldName
       .split(/\s+/)
       .map((word, index) => {
         if (index === 0) {
           return word.toLowerCase();
         }
         return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
       })
       .join('');
     return camelCase;
   }
   return '';
 }

 /**
  * Extracts field name from error message for tooltip
  * Error messages follow new format: "Field name is required" (no brackets or colons)
  */
 public extractFieldNameFromError(errorMsg: string): string {
   // Extract everything before " is ", " has ", " must ", etc.
   const match = errorMsg.match(/^([^i]+?)\s+(?:is|has|must)/i);
   if (match && match[1]) {
     return match[1].trim();
   }
   // Fallback: return the whole message or 'field' if empty
   return errorMsg ? errorMsg.substring(0, 50) : 'field';
 }

 /**
  * Aggregates validation errors from all child form components
  * Collects errors from Primary Info, Confidential Info, and Details Info tabs
  * Returns array of ValidationError objects with field information and error messages
  */
 private aggregateFormErrors(): ValidationError[] {
   const forms = new Map<FormGroup, string>();
   
   // Add visible forms to the map
   if (this.primaryInfoTab) {
     forms.set(this.primaryInfoTab, 'Primary Info');
   }
   if (this.conInfoTab && this.isConfidentialInfoVisible()) {
     forms.set(this.conInfoTab, 'Confidential Info');
   }
   if (this.detailsInfo && this.isDetailsInfoVisible()) {
     forms.set(this.detailsInfo, 'Details Info');
   }
   
   
   // Use the validation service to aggregate errors
   const errors = this.workerValidationsService.aggregateFormErrors(
     Array.from(forms.keys()),
     forms
   );
   errors.forEach((error, index) => {
   });
   
   return errors;
 }

 /**
  * Navigates to a specific field by ID and highlights it
  * Scrolls the field into view and focuses on it
  * Used for error message hyperlink navigation
  *
  * Handles nested field structures where wrapper div has ID and input is nested inside
  */
 public navigateToField(fieldId: string): void {
   // Longer delay to ensure DOM is fully updated and rendered
   setTimeout(() => {
     // First, try to find the wrapper element with the field ID
     let fieldElement = document.getElementById(fieldId);
     
     if (!fieldElement) {
       // Try to find input element directly by formControlName attribute
       const inputElement = document.querySelector(`input[formControlName="${fieldId}"], select[formControlName="${fieldId}"], textarea[formControlName="${fieldId}"]`) as HTMLElement;
       if (inputElement) {
         fieldElement = inputElement;
       }
     }
     
     if (fieldElement) {
       // Scroll the element into view with smooth behavior
       fieldElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
       // Try to focus on the input element within the field
       let inputElement = fieldElement.querySelector('input, select, textarea') as HTMLElement;
       
       // If the fieldElement itself is an input, use it directly
       if (!inputElement && (fieldElement.tagName === 'INPUT' || fieldElement.tagName === 'SELECT' || fieldElement.tagName === 'TEXTAREA')) {
         inputElement = fieldElement;
       }
       
       if (inputElement) {
         // Delay focus to allow scroll to complete
         setTimeout(() => {
           inputElement.focus();
           // Add visual highlight to the input element
           inputElement.classList.add('field-error-highlight');
           // Remove highlight after 3 seconds
           setTimeout(() => {
             inputElement.classList.remove('field-error-highlight');
           }, 3000);
         }, 500);
       } else {
       }
     } else {
     }
   }, 200);
 }

 /**
  * Displays validation errors with hyperlinks for navigation
  * Creates clickable error messages that navigate to the corresponding fields
  */
 public displayValidationErrorsWithNavigation(errors: ValidationError[]): void {
   // Convert ValidationError objects to user-friendly messages with navigation capability
   const errorMessages: string[] = errors.map((error) => {
     const message = `[${error.tabName}] ${error.fieldName}: ${error.message}`;
     return message;
   });
   
   // Store error messages for display
   this.validationErrorMessages = errorMessages;
   
   // Mark all form fields as touched to display inline error messages
   this.markAllFormFieldsAsTouched();
   
   // Trigger change detection
   this.cdr.detectChanges();
 }

 /**
  * Marks all form fields as touched to trigger error message display
  * Called when validation fails to show all error messages inline
  */
 private markAllFormFieldsAsTouched(): void {
   const forms = [this.primaryInfoTab, this.conInfoTab, this.detailsInfo];
   
   forms.forEach((form) => {
     if (form && form.controls) {
       Object.keys(form.controls).forEach((controlName) => {
         const control = form.get(controlName);
         if (control) {
           control.markAsTouched();
         }
       });
     }
   });
 }

  changeLocationEvent() {
    this.showWorkerRoleAssignmentTab = false;
    setTimeout(() => {
      this.showWorkerRoleAssignmentTab = true;
    }, 0)
  }
}

