import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { WorkerValidationsService } from '../../worker-validations.service';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { DialogComponent } from '../../../relocation-management/dialog/dialog.component';

@Component({
  selector: 'app-worker-navbar',
  templateUrl: './worker-navbar.component.html',
  styleUrls: ['./worker-navbar.component.scss'],
})
export class WorkerNavbarComponent {
  tab: string = 'addWorkerPrimaryWorkerInfoTab';
  @Input() workerRole: string = 'InfraAdmin';
  @Input() applicationType: string = 'Worker';
  @Input() workerEmploymentType: string = '';
  @Input() isUpdateMode: boolean = false;
  @Input() showWorkerOverride: boolean = false;
  @Input() hasActiveOverrides: boolean = false;
  @Input() showWait: boolean = false;
  workerBase: any = {};
  addWorkerInvalidFlag: boolean = false;
  validationBooleans: any = {};
  communcationEditMode: boolean = false;
  organizationLocationEditMode: boolean = false;
  overrideEditMode: boolean = false;
  workerAccession: any;
  isActive: boolean = true;
  userRoles: string[] = [];
  applicationTypeLowerCase = '';
  select: boolean = true;
  private dialog = inject(MatDialog);
  private router = inject(Router);

  constructor(
    private workerValidationsService: WorkerValidationsService,
    private workerValidationService: WorkerValidationsService
  ) {}

  @Output() resetWorkerHandler: EventEmitter<any> = new EventEmitter();
  @Output() exitWorkerHandler: EventEmitter<any> = new EventEmitter();
  /**
   * Confirms exit from add worker screen
   * Shows dialog asking user if they want to save before exiting
   */
  confirmExitAddWorker() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Exit without saving?',
        titleType: 'danger',
        content: `You have not saved and submitted this updated information for this worker. Would you like to save and submit information before exiting?`,
        cancelButton: true,
        primaryButton: 'Save and Exit',
        primaryButtonType: 'primary',
        secondaryButton: 'No, exit without saving',
        secondaryButtonType: 'danger'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === true) {
        // User clicked "Save and Exit"
        this.addWorker();
      } else if (result === 'exit') {
        // User clicked "No, exit without saving"
        this.exitToWorkerSearchWithoutSave();
      }
      // If result is false/undefined, user clicked Cancel - do nothing
    });
  }

  /**
   * Exits to worker search without saving
   */
  private exitToWorkerSearchWithoutSave() {
    this.exitWorkerHandler.emit();
    // Navigate back to worker management/search page
    if (this.applicationType === 'Contractor') {
      this.router.navigate(['/app/workerManagement/Contractor']);
    } else {
      this.router.navigate(['/app/workerManagement/Worker']);
    }
  }
  /**
   * Confirms reset of add worker form
   * Shows dialog asking user to confirm reset action
   */
  confirmResetAddWorker() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        title: 'Reset and clear information?',
        content: 'You have not saved the information for this worker.</br>Resetting the screen will clear all of the changes entered for this worker.',
        primaryButton: 'Cancel',
        primaryButtonType: 'primary',
        secondaryButton: 'Yes, clear all changes',
        secondaryButtonType: 'danger'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'exit') {
        // User clicked "Yes, clear all changes" (secondary button)
        this.resetWorkerHandler.emit();
      }
      // If result is true, user clicked "Cancel" (primary button) - do nothing
      // If result is false/undefined, dialog was closed - do nothing
    });
  }

  @Output() addWorkerHandler: EventEmitter<any> = new EventEmitter();
  /**
   * Triggers add worker save operation
   * Emits event to parent component to handle the actual save
   */
  addWorker() {
    // Check if assignments are in edit mode
    if (this.assignmentsEditMode()) {
      this.dialog.open(DialogComponent, {
        width: '400px',
        data: {
          title: 'Warning',
          titleType: 'warning',
          content: 'Please save or cancel your current assignment edits before saving the worker.',
          cancelButton: false,
          primaryButton: 'OK',
          primaryButtonType: 'primary'
        }
      });
      return;
    }

    // Emit event to parent component (add-worker.component.ts) to handle save
    this.addWorkerHandler.emit();
  }
  assignmentsEditMode() {
    if (this.communcationEditMode) {
      return true;
    } else if (this.organizationLocationEditMode) {
      return true;
    } else if (this.overrideEditMode) {
      return true;
    }
    return false;
  }
  addWorkerInvalid() {
    let addWorkerInvalidFlag = this.addWorkerInvalidHelper();

    // Only set teleworkProgramInvalid if telework is checked AND no program is selected
    // AND the user is not a RoomCoordinator (who can set hoteling without telework)
    if (this.workerBase.worker.teleworkIndicator && !this.workerBase.worker.teleworkProgram) {
      this.workerBase.worker.teleworkProgramInvalid = true;
      addWorkerInvalidFlag = true;
    }
    // Also check if hoteling is checked without telework program (for non-RoomCoordinators)
    else if (this.workerBase.worker.hotelDisplayIndicator && !this.workerBase.worker.teleworkProgram &&
             this.userRoles.indexOf('InfraRoomCoordinator') === -1) {
      this.workerBase.worker.teleworkProgramInvalid = true;
      addWorkerInvalidFlag = true;
    }
    else {
      this.workerBase.worker.teleworkProgramInvalid = false;
    }

    return addWorkerInvalidFlag;
  }
  addWorkerInvalidHelper() {
    const addWorkerInvalidFlag = false;

    if (
      this.workerRole !== 'InfraOfficeCoordinator' &&
      this.workerRole !== 'InfraContractorAdmin' &&
      this.workerEmploymentType === 'E' &&
      this.workerValidationsService.confidentialInfomationInvalid(
        this.validationBooleans,
        this.workerBase.workerSecure
      )
    ) {
      this.addWorkerInvalidFlag = true;
    }

    if (
      this.workerValidationsService.primaryInfomationInvalid(
        this.validationBooleans,
        this.workerBase.worker,
        this.userRoles,
        this.workerEmploymentType,
        undefined
      )
    ) {
      this.addWorkerInvalidFlag = true;
    }
    if (
      this.workerValidationsService.workerDetailsInfomationInvalid(
        this.validationBooleans,
        this.workerBase.worker,
        this.userRoles,
        this.workerEmploymentType,
        this.workerAccession
      )
    ) {
      this.addWorkerInvalidFlag = true;
    }
    if (
      this.workerRole !== 'InfraContractorAdmin' &&
      this.workerEmploymentType === 'E' &&
      !this.validationBooleans.validEmployeeSocialSecurity
    ) {
      this.addWorkerInvalidFlag = true;
    }
    return addWorkerInvalidFlag;
  }
  createWorker(workerSecure: any, worker: any, initialWorkerBase: any) {
    let isTrademarkWorker = sessionStorage.getItem('isTrademarkWorker') || '';
    let value = isTrademarkWorker.trim().toLowerCase() === 'true';
    if (value) {
      worker.workerTrademarkIn = true;
    } else {
      worker.workerTrademarkIn = false;
    }
    if (this.userRoles.indexOf('InfraHRAdmin') >= 0) {
      this.createWorkerHR(workerSecure, worker, initialWorkerBase);
    } else {
      if (
        this.userRoles.indexOf('InfraAdmin') >= 0 ||
        this.userRoles.indexOf('InfraContractorAdmin') >= 0
      ) {
        this.createWorkerAdmin(workerSecure, worker, initialWorkerBase);
      }
    }
  }
  createWorkerAdmin(workerSecure: any, worker: any, initialWorkerBase: any) {
    let workerCreated: any;
    let telecommunicationHistory = this.workerBase.workerTelecommunicationHistory;
    let workerAssignments = this.workerBase.workerAssignments;
    let selectedOrganizationRoles = this.workerBase.workerRoles;
    let workerEmploymentType = worker.employmentType.value;

    // WorkerAddService.addWorker(workerEmploymentType, workerSecure, worker)
    //   .then(function (response) {
    //     workerCreated = response.worker;
    //     if (this.workerEmploymentType === 'E') {
    //       createAccession(response.worker);
    //     }
    //     return WorkerUpdateControllerHelper.saveLocationAssignments(workerCreated.workerId, workerAssignments);
    //   },
    //     function (response) {
    //       response.failed = true;
    //       response.failedAt = 'Primary Worker Information';
    //       return $q.reject(response);
    //     })
    //   .then(function () {
    //     return WorkerUpdateControllerHelper.saveTelecommunication(workerCreated.workerId, telecommunicationHistory);
    //   },
    //     function (response) {
    //       if (!response.failed) {
    //         response.failed = true;
    //         response.failedAt = 'Worker Organization Location Assignment';
    //       }
    //       return $q.reject(response);
    //     })
    //   .then(function () {
    //     return WorkerUpdateControllerHelper.assignWorkerOrganizationRoles(workerCreated.workerId,
    //       selectedOrganizationRoles);
    //   },
    //     function (response) {
    //       response = checkFailedComm(response);
    //       return $q.reject(response);
    //     })
    //   .then(function () {
    //     workerCreateSuccessModelUpdate(workerCreated);
    //   },
    //     function (response) {
    //       handleFailedRespone(response, workerCreated, initialWorkerBase);
    //     });
  }
  createWorkerHR(workerSecure: any, worker: any, initialWorkerBase: any) {
    let workerCreated;
    let workerEmploymentType = worker.employmentType.value;

    // WorkerAddService.addWorker(workerEmploymentType, workerSecure, worker)
    // .then(function(response) {
    //     workerCreated = response.worker;
    //      if(this.workerEmploymentType === 'E'){
    //         createAccession(response.worker);
    //     }
    //     workerCreateSuccessModelUpdate(workerCreated);
    //     sessionStorage.removeItem('isTrademarkWorker');
    // },
    // function(response) {
    //     this.hideMessage = false;
    //     this.returnMessage = response.data.message;
    //     this.returnCode = response.status;
    //     this.workerBase = angular.copy(initialWorkerBase);
    // });
  }
  /**
   * Validates contractor ID before saving
   * Checks for duplicate contractor based on DOB and last 2 SSN digits
   */
  validateContractorId() {
    // Check if assignments are in edit mode
    if (this.assignmentsEditMode()) {
      this.dialog.open(DialogComponent, {
        width: '400px',
        data: {
          title: 'Warning',
          titleType: 'warning',
          content: 'Please save or cancel your current assignment edits before saving the contractor.',
          cancelButton: false,
          primaryButton: 'OK',
          primaryButtonType: 'primary'
        }
      });
      return;
    }

    // Get contractor data from workerBase
    const dateOfBirth = this.workerBase?.workerSecure?.birthDate;
    const contractorSSN = this.workerBase?.workerSecure?.ssnLast2Digits;

    // Validate that required fields are present
    if (!dateOfBirth || !contractorSSN) {
      this.validationBooleans.invalidContractorId = false;
      this.addWorker();
      return;
    }

    // Validate contractor ID using the validation service
    this.workerValidationsService.validateContractorId(dateOfBirth, contractorSSN).subscribe(
      (response: any) => {
        // Contractor ID is valid and unique
        this.validationBooleans.invalidContractorId = false;
        this.addWorker();
      },
      (error: any) => {
        if (error.type === 'duplicate') {
          // Contractor ID already exists
          this.validationBooleans.invalidContractorId = true;
          this.dialog.open(DialogComponent, {
            width: '500px',
            data: {
              title: 'Duplicate Contractor ID',
              titleType: 'danger',
              content: error.message || 'A contractor with this Date of Birth and SSN (last 2 digits) already exists.',
              cancelButton: false,
              primaryButton: 'OK',
              primaryButtonType: 'danger'
            }
          });
        } else {
          // Other validation error
          this.validationBooleans.invalidContractorId = true;
          this.addWorker();
        }
      }
    );
  }

  @Output() public handleScrollOffSet: EventEmitter<string> = new EventEmitter();

  gotoAnchor(elementID: string) {
    this.handleScrollOffSet.emit(elementID);
    //el.scrollIntoView();
  }
}
