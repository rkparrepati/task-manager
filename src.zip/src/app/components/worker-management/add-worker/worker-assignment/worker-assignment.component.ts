import { Component, inject, Input, OnInit, ChangeDetectorRef, OnChanges, SimpleChanges, ViewChild, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { LocationselectDialogComponent } from '../locationselect-dialog/locationselect-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { PalmLocationLookupComponent } from '../palm-location-lookup/palm-location-lookup.component';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { UtilityService } from 'src/app/services/utility.service';
import { RelocationPlanDetailsService } from 'src/app/components/relocation-management/relocation-plan-details/relocation-plan-details.service';
import { RelocationService } from 'src/app/components/relocation-management/relocation.service';
import { WorkerManagementService } from '../../worker-management.service';
import { PalmLocationService } from 'src/app/services/palm-location.service';

@Component({
  selector: 'app-worker-assignment',
  templateUrl: './worker-assignment.component.html',
  styleUrls: ['./worker-assignment.component.scss'],
})
export class WorkerAssignmentComponent implements OnInit, OnChanges {
   @ViewChild('accordionGroupRef') accordionGroupRef: any;
  @Output() changeLocationEvent = new EventEmitter();
   
   isAccordionOpen = true;
   
   editedLocation: any = {};
   selectedRelocation: any = {};
   telecomTypes: any = {};
   returnMessage: string = '';
   showAddLocationRow = false;
   edit = false;
   showHiddenLocationFlag = false;
   workerLocations = [];
   selectedPalmLocation = {};
   newPalmLocation = {};
   palmLocationModel = {};
   showLocationsIcon = 'fa-plus-square-o';
   workerLocationModel = {
     selectedWorkerLocation: {},
     newWorkerLocation: {},
   };
   vmCommunication: any = {};
   showAllLocations = false;
   addEditMode = false;
   originalLocation: any = {}; // Store original values for reset functionality
   public base: any = {
    newLocation: {
      invalidHiddenIndicator: true,
      singlePrimary: '',
      noPrimary: '',
      setPrimary: '',
      lifecycle: {},
      invalidPrimaryIndicator: false,
      multipleHiddenAssignments: false,
      multiplePrimaryAssignments: false,
      mailLocationIndicator: false,
      workerOrganization: {
        organization: {
          acronym: '',
          businessAreaCode: '',
          shortName: '',
          id: 0,
        },
      },
      location: {
        building: {
          code: '',
          floorNumber: '',
        },
      },
      palmLocationDetail: {},
    },
  };
  locationInvalid = false;
  disableMailLocation = true;
  editAddMode = false;
  organizationInvalid = false;
  selectedPalmLocationDescription = '';
  selectedPalmLocationArtUnit = '';
  buildingFloors: any = [];
  @Input() assignMentWorker!: FormGroup;
  @Input() workerAssignments: any = [];
  @Input() workerBase: any = {};
  mailLocationInvalid: any = false;
  palmLocationLookupNoResults: any = false;
  workerLocation: any = {};
  mailStopBuildingFloors: any = [];
  locationRequired: any = false;
  acronymRequired = false;
  userRoles = ['InfraAdmin'];
  dialog = inject(MatDialog);
  @Input() public acronym = '';
  buildingsList: any[] = [];
  palmLocationSearchInput = '';
  palmLocationSearchResults: any[] = [];
  palmLocationSearchNoResults = false;
  palmLocationSearchLoading = false;
  palmLocationSearchErrorMessage = '';
  
  constructor(
    private fb: FormBuilder,
    private organisationService: OrganizationService,
    private utilityService: UtilityService,
    private relocationPlanDetailsService: RelocationPlanDetailsService,
    private relocationService: RelocationService,
    private cdr: ChangeDetectorRef,
    private workerManagementService: WorkerManagementService,
    private palmLocationService: PalmLocationService
  ) {}

  ngOnInit(): void {
    this.assignMentWorker.addControl(
      'primaryLocationIndicator',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl('hiddenIndicator', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl(
      'alternateIndicator',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl('code', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl('floorNumber', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl('corridorId', new FormControl('', [Validators.required]));

    this.assignMentWorker.addControl('suiteId', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl('roomId', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl('zoneId', new FormControl('', [Validators.required]));
    this.assignMentWorker.addControl(
      'visualLocationCode',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailLocationIndicator',
      new FormControl('', [Validators.required])
    );

    this.assignMentWorker.addControl(
      'mailStopLocationcode',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailStopLocationFloorNumber',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailStopLocationcorridorId',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailStopLocationsuiteId',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailStopLocationroomId',
      new FormControl('', [Validators.required])
    );
    this.assignMentWorker.addControl(
      'mailStopLocationzoneId',
      new FormControl('', [Validators.required])
    );
    
    // Disable all mailstop location fields by default on page load
    this.disableMailStopLocationFields();
    
    this.getBuildingCode();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Initialize viewMode property on all worker assignments when they are loaded
    if (changes['workerAssignments'] && this.workerAssignments && Array.isArray(this.workerAssignments)) {
      this.workerAssignments.forEach((assignment: any) => {
        if (assignment) {
          // Always initialize viewMode to 0 (collapsed)
          assignment.viewMode = 0;
        }
      });
    }
  }

  resetForm() {
    // this.assignMentWorker.reset();
    this.assignMentWorker.get('code')?.setValue('');
    this.assignMentWorker.get('floorNumber')?.setValue('');
    this.assignMentWorker.get('corridorId')?.setValue('');
    this.assignMentWorker.get('suiteId')?.setValue('');
    this.assignMentWorker.get('roomId')?.setValue('');
    this.assignMentWorker.get('zoneId')?.setValue('');
    this.assignMentWorker.get('visualLocationCode')?.setValue('');
    this.assignMentWorker.get('mailLocationIndicator')?.setValue('');
    this.assignMentWorker.get('mailStopLocationcode')?.setValue('');
    this.assignMentWorker.get('mailStopLocationFloorNumber')?.setValue('');
    this.assignMentWorker.get('mailStopLocationcorridorId')?.setValue('');
    this.assignMentWorker.get('mailStopLocationsuiteId')?.setValue('');
    this.assignMentWorker.get('mailStopLocationroomId')?.setValue('');
    this.assignMentWorker.get('mailStopLocationzoneId')?.setValue('');
  }

  showLocationAddRow() {
    if (!this.editAddMode) {
      this.buildingFloors = [];
      this.editAddMode = true;
      this.base.newLocation = {
        invalidHiddenIndicator: false,
        singlePrimary: false,
        noPrimary: false,
        setPrimary: false,
        lifecycle: {
          beginDate: new Date().toISOString(),
          endDate: '',
        },
        mailLocationIndicator: false,
        primaryLocationIndicator: false,
        hiddenIndicator: false,
        alternateIndicator: false,
        workerOrganization: {
          organization: {
            acronym: '',
            businessAreaCode: '',
            shortName: '',
            id: 0,
          },
        },
        location: {
          building: {
            code: '',
            floorNumber: '',
          },
        },
        palmLocationDetail: {},
      };
      this.showAddLocationRow = true;
      this.addEditMode = true;
      this.selectedPalmLocationDescription = '';
      this.selectedPalmLocationArtUnit = '';
     this.resetForm();
    }
    this.editedLocation = this.base.newLocation;
  }

  openLookupOrganization() {
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      height: '80vh',
      data: {
        message: 'Are you sure want to delete?',
        buttonText: {
          ok: 'Save',
          cancel: 'No',
        },
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.acronym = result.shortName;
      this.base.newLocation.workerOrganization.organization.acronym =
        result.organizationType.businessArea.code + '/' + result.shortName;
      this.base.newLocation.workerOrganization.organization.businessAreaCode =
        result.organizationType.businessArea.code;
      this.base.newLocation.workerOrganization.organization.shortName = result.shortName;
    });
  }

  /**
   * Handle acronym change from acronym-input component
   * Matches legacy AngularJS implementation pattern
   * @param acronym The new acronym value
   */
  onAcronymChange(acronym: string): void {
    // Reset validation error when user starts typing (legacy pattern)
    this.acronymRequired = false;
    
    // Ensure workerOrganization structure exists
    if (!this.base.newLocation.workerOrganization) {
      this.base.newLocation.workerOrganization = { organization: {} };
    }
    if (!this.base.newLocation.workerOrganization.organization) {
      this.base.newLocation.workerOrganization.organization = {};
    }
    
    // Set acronym value
    this.base.newLocation.workerOrganization.organization.acronym = acronym;
    
    // Parse acronym to extract business area code and short name (legacy pattern)
    if (acronym && acronym.includes('/')) {
      const parts = acronym.split('/');
      if (parts.length === 2 && parts[0].trim() && parts[1].trim()) {
        this.base.newLocation.workerOrganization.organization.businessAreaCode = parts[0].trim();
        this.base.newLocation.workerOrganization.organization.shortName = parts[1].trim();
      } else {
        // Clear parsed values if format is invalid (empty parts)
        this.base.newLocation.workerOrganization.organization.businessAreaCode = '';
        this.base.newLocation.workerOrganization.organization.shortName = '';
      }
    } else {
      // Clear parsed values if format is invalid
      this.base.newLocation.workerOrganization.organization.businessAreaCode = '';
      this.base.newLocation.workerOrganization.organization.shortName = '';
    }
  }

  /**
   * Handle acronym selection from organization lookup dialog
   * @param organization The selected organization object
   */
  onAcronymSelected(organization: any): void {
    if (organization && this.base.newLocation.workerOrganization?.organization) {
      // Clear validation error immediately when organization is selected
      this.acronymRequired = false;
      
      // Set organization ID - try both possible property names
      const orgId = organization.organizationId || organization.id;
      this.base.newLocation.workerOrganization.organization.id = orgId;
      
      // Extract business area code - try multiple possible paths
      let businessAreaCode = '';
      if (organization.organizationType?.businessArea?.code) {
        businessAreaCode = organization.organizationType.businessArea.code.trim();
      } else if (organization.businessAreaCode) {
        businessAreaCode = organization.businessAreaCode.trim();
      } else if (organization.businessArea?.code) {
        businessAreaCode = organization.businessArea.code.trim();
      }
      
      // Extract short name
      const shortName = (organization.shortName || organization.name || '').trim();
      
      // Only proceed if we have both required fields
      if (businessAreaCode && shortName) {
        this.base.newLocation.workerOrganization.organization.businessAreaCode = businessAreaCode;
        this.base.newLocation.workerOrganization.organization.shortName = shortName;
        this.base.newLocation.workerOrganization.organization.acronym = `${businessAreaCode}/${shortName}`;
      } else {
        this.acronymRequired = true;
      }
      
      // Trigger change detection to update the view
      this.cdr.detectChanges();
    }
  }

  /**
   * Handle acronym blur event - validate the acronym by checking organization report roles
   * @param acronym The acronym value when field loses focus
   */
  onAcronymBlur(acronym: string): void {
    // Don't validate if acronym is empty
    if (!acronym) {
      return;
    }

    // Parse acronym to get business area and short name
    const parts = acronym.split('/');
    if (parts.length !== 2 || !parts[0].trim() || !parts[1].trim()) {
      // Invalid format - set error
      this.acronymRequired = true;
      return;
    }

    // Valid format, validate the acronym exists by calling validateAcronym
    this.validateAcronym(false);
  }

  changeLocation(type: string, val: any) {
    const locationSelectDialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '90vw',
      height: '75vh',
      data: val,
    });

    locationSelectDialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        if (type === 'mail') {
          // First, populate the mailstop building floors
          this.mailstopBuildingChanged(result.building?.code || '');
          
          // Find the buildingFloorId that matches the floorNumber
          const selectedFloorId = this.findBuildingFloorId(
            result.building?.code || '',
            result.building?.floorNumber || '',
            true // isMailStop
          );
          
          this.assignMentWorker.patchValue({
            mailStopLocationcode: result.building?.code || '',
            mailStopLocationFloorNumber: selectedFloorId || '',
            mailStopLocationcorridorId: result.corridorId || '',
            mailStopLocationsuiteId: result.suiteId || '',
            mailStopLocationroomId: result.roomId || '',
            mailStopLocationzoneId: result.zoneId || '',
          });
        } else {
          // First, populate the building floors
          this.buildingChangedEvent({ target: { value: result.building?.code || '' } });
          
          // Find the buildingFloorId that matches the floorNumber
          const selectedFloorId = this.findBuildingFloorId(
            result.building?.code || '',
            result.building?.floorNumber || '',
            false // isMailStop
          );
          
          this.assignMentWorker.patchValue({
            code: result.building?.code || '',
            floorNumber: selectedFloorId || '',
            corridorId: result.corridorId || '',
            suiteId: result.suiteId || '',
            roomId: result.roomId || '',
            zoneId: result.zoneId || '',
          });
        }
      }
    });
  }

  /**
   * Find the buildingFloorId that matches the given floorNumber
   * @param buildingCode The building code
   * @param floorNumber The floor number to match
   * @param isMailStop Whether this is for mailstop location
   * @returns The buildingFloorId or empty string if not found
   */
  private findBuildingFloorId(buildingCode: string, floorNumber: string, isMailStop: boolean): string {
    const floorsList = isMailStop ? this.mailStopBuildingFloors : this.buildingFloors;
    
    if (!floorsList || floorsList.length === 0 || !floorNumber) {
      return '';
    }
    
    const matchedFloor = floorsList.find((floor: any) =>
      floor.floorNumber && floor.floorNumber.trim() === floorNumber.trim()
    );
    
    return matchedFloor ? matchedFloor.buildingFloorId : '';
  }

  cancelAddEdit(data: any) {
    this.base.newLocation = {};
    this.editAddMode = false;
    this.locationInvalid = false;
    this.addEditMode = false;
    this.palmLocationLookupNoResults = false;
    this.acronymRequired = false;
    this.mailLocationInvalid = false;
    this.locationRequired = false;
    this.selectedPalmLocationArtUnit = '';
    if (this.showAddLocationRow) {
      this.showAddLocationRow = false;
      // Trigger change detection to hide the add row form
      this.cdr.detectChanges();
    } else {
      if (data) {
        data.viewMode = 0; // Reset to display mode
      }
      this.base.newLocation.edited = false;
    }
  }

  resetAddEdit(data: any) {
    this.locationInvalid = false;
    this.palmLocationLookupNoResults = false;
    this.acronymRequired = false;
    this.mailLocationInvalid = false;
    this.locationRequired = false;
    this.selectedPalmLocationArtUnit = '';
    
    // Reset all form controls to empty values
    this.assignMentWorker.reset();
    
    if (this.showAddLocationRow) {
      this.base.newLocation = {};
      this.base.newLocation.lifecycle = {
        beginDate: new Date().toISOString(),
        endDate: '',
      };
      this.selectedPalmLocationDescription = '';
      this.mailStopBuildingFloors = [];
      this.base.newLocation.mailLocationIndicator = false;
    } else {
      // Restore from original values if in edit mode
      if (this.originalLocation && Object.keys(this.originalLocation).length > 0) {
        this.base.newLocation = JSON.parse(JSON.stringify(this.originalLocation));
      } else {
        this.base.newLocation = JSON.parse(JSON.stringify(data));
      }
      if (
        !this.base.newLocation.primaryLocationIndicator &&
        !this.base.newLocation.hiddenIndicator
      ) {
        this.base.newLocation.alternateIndicator = true;
      } else {
        this.base.newLocation.alternateIndicator = false;
      }
      this.base.newLocation.edited = false;
      this.getPalmLocationDescription();

      if (this.base.newLocation.location) {
        const tempFloorNum = this.base.newLocation.location.building.floorNumber;
        this.buildingChanged(tempFloorNum);
      }
      if (this.base.newLocation.mailStopLocation) {
        const tempMailFloorNum = this.base.newLocation.mailStopLocation.building.floorNumber;
        this.mailstopBuildingChanged(tempMailFloorNum);
      }
      if (this.base.newLocation.mailLocation && this.base.newLocation.mailLocation.locationId) {
        this.base.newLocation.mailLocationIndicator = true;
      } else {
        this.base.newLocation.mailLocationIndicator = false;
      }
    }
    
    // Disable mailstop location fields after reset
    this.disableMailStopLocationFields();
    
    // Collapse the accordion
    this.isAccordionOpen = false;
    this.cdr.detectChanges();
  }

  getTelephoneType() {
    let theType = null;
    this.telecomTypes.forEach((teleType: any) => {
      if (teleType.value === 'T') {
        theType = teleType.id;
      }
    });
    return theType;
  }

  invalidRelocationEdit = () => {
    const editedLocation = this.editedLocation;
    let moveDateInvalid = false;
    let planDetailInvalid = false;
    let telephoneNumberInvalid = false;
    if (editedLocation.to.lifecycle) {
      if (!editedLocation.to.lifecycle.beginDate) {
        moveDateInvalid = true;
        planDetailInvalid = true;
      } else {
        const newDateStr = editedLocation.to.lifecycle.beginDate.replace(
          '00:00:00',
          this.utilityService.getUniqueTime()
        );
        editedLocation.to.lifecycle.beginDate = newDateStr;
      }
    } else {
      moveDateInvalid = true;
      planDetailInvalid = true;
    }
    if (
      editedLocation.to.communication &&
      editedLocation.to.communication.telephoneNo &&
      editedLocation.to.communication.telephoneNo.length !== 14
    ) {
      telephoneNumberInvalid = true;
      planDetailInvalid = true;
    } else if (editedLocation.to.communication) {
      editedLocation.to.communication.telecomAddressType = { id: this.getTelephoneType() };
      editedLocation.to.communication.primaryIndicator = true;
    }
    return planDetailInvalid;
  };

  /**
   * Transfer form control values to base.newLocation.location
   * This ensures the building code and other location details are populated
   * before the accept/validation process
   */
  private transferFormValuesToLocation(): void {
    // Ensure location structure exists
    if (!this.base.newLocation.location) {
      this.base.newLocation.location = { building: {} };
    }
    if (!this.base.newLocation.location.building) {
      this.base.newLocation.location.building = {};
    }

    // Transfer building code from form control
    const buildingCodeControl = this.assignMentWorker.get('code');
    if (buildingCodeControl && buildingCodeControl.value) {
      this.base.newLocation.location.building.code = buildingCodeControl.value;
    }

    // Transfer floor number from form control
    const floorNumberControl = this.assignMentWorker.get('floorNumber');
    if (floorNumberControl && floorNumberControl.value) {
      this.base.newLocation.location.building.floorNumber = floorNumberControl.value;
    }

    // Transfer corridor from form control
    const corridorControl = this.assignMentWorker.get('corridorId');
    if (corridorControl && corridorControl.value) {
      this.base.newLocation.location.corridorId = corridorControl.value;
    }

    // Transfer suite from form control
    const suiteControl = this.assignMentWorker.get('suiteId');
    if (suiteControl && suiteControl.value) {
      this.base.newLocation.location.suiteId = suiteControl.value;
    }

    // Transfer room from form control
    const roomControl = this.assignMentWorker.get('roomId');
    if (roomControl && roomControl.value) {
      this.base.newLocation.location.roomId = roomControl.value;
    }

    // Transfer zone from form control
    const zoneControl = this.assignMentWorker.get('zoneId');
    if (zoneControl && zoneControl.value) {
      this.base.newLocation.location.zoneId = zoneControl.value;
    }

    // Transfer mailstop location fields if mailstop indicator is checked
    if (this.base.newLocation.mailLocationIndicator) {
      if (!this.base.newLocation.mailStopLocation) {
        this.base.newLocation.mailStopLocation = { building: {} };
      }
      if (!this.base.newLocation.mailStopLocation.building) {
        this.base.newLocation.mailStopLocation.building = {};
      }

      const mailBuildingCodeControl = this.assignMentWorker.get('mailStopLocationcode');
      if (mailBuildingCodeControl && mailBuildingCodeControl.value) {
        this.base.newLocation.mailStopLocation.building.code = mailBuildingCodeControl.value;
      }

      const mailFloorNumberControl = this.assignMentWorker.get('mailStopLocationFloorNumber');
      if (mailFloorNumberControl && mailFloorNumberControl.value) {
        this.base.newLocation.mailStopLocation.building.floorNumber = mailFloorNumberControl.value;
      }

      const mailCorridorControl = this.assignMentWorker.get('mailStopLocationcorridorId');
      if (mailCorridorControl && mailCorridorControl.value) {
        this.base.newLocation.mailStopLocation.corridorId = mailCorridorControl.value;
      }

      const mailSuiteControl = this.assignMentWorker.get('mailStopLocationsuiteId');
      if (mailSuiteControl && mailSuiteControl.value) {
        this.base.newLocation.mailStopLocation.suiteId = mailSuiteControl.value;
      }

      const mailRoomControl = this.assignMentWorker.get('mailStopLocationroomId');
      if (mailRoomControl && mailRoomControl.value) {
        this.base.newLocation.mailStopLocation.roomId = mailRoomControl.value;
      }

      const mailZoneControl = this.assignMentWorker.get('mailStopLocationzoneId');
      if (mailZoneControl && mailZoneControl.value) {
        this.base.newLocation.mailStopLocation.zoneId = mailZoneControl.value;
      }
    }
  }

  acceptAddEdit(index?: number) {
    if (index !== undefined) {
      this.index = index;
    }
    // Transfer form control values to base.newLocation before validation
    this.transferFormValuesToLocation();
    this.validateAcronym(true);
  }

  private index = 0;

  validateAcronym(fromAccept: boolean): void {
    this.acronymRequired = false;
    if (
      !this.base.newLocation.workerOrganization ||
      !this.base.newLocation.workerOrganization.organization?.acronym
    ) {
      this.acronymRequired = true;
      return;
    }
    
    const acronym = this.base.newLocation.workerOrganization.organization.acronym;
    
    // Validate acronym format: must contain '/' and have non-empty parts
    if (!acronym || !acronym.includes('/')) {
      this.acronymRequired = true;
      return;
    }
    
    const parts = acronym.split('/');
    if (parts.length !== 2 || !parts[0].trim() || !parts[1].trim()) {
      this.acronymRequired = true;
      return;
    }
    
    // Format is valid, now validate against API
    this.organisationService
      .getOrganizationByAcronym(acronym, false)
      .subscribe(
        (response: any) => {
          if (response.results && response.results.length > 0) {
            const orgId = response.results[0].id || response.results[0].organizationId;
            if (orgId) {
              this.selectAcronym(orgId, fromAccept);
            } else {
              this.acronymRequired = true;
            }
          } else {
            this.acronymRequired = true;
          }
        },
        (error) => {
          this.acronymRequired = true;
        }
      );
  }

  private selectAcronym(organizationId: number, fromAccept: boolean): void {
    this.organisationService.getOrganization(organizationId).subscribe(
      (response: any) => {
        const org = response.organization || response;
        // Normalize organization data structure - same logic as setEditModeWorkerLocation()
        // Map organizationId to id if needed
        if (org.organizationId && !org.id) {
          org.id = org.organizationId;
        }
        
        // Extract businessAreaCode from nested structure if needed
        let businessAreaCode = org.businessAreaCode || '';
        if (!businessAreaCode && org.organizationType?.businessArea?.code) {
          businessAreaCode = org.organizationType.businessArea.code;
          org.businessAreaCode = businessAreaCode;
        }
        
        // Get shortName
        const shortName = org.shortName || '';
        // Construct acronym from businessAreaCode and shortName
        if (businessAreaCode && shortName) {
          org.acronym = `${businessAreaCode.trim()}/${shortName.trim()}`;
        } else {
        }
        this.base.newLocation.workerOrganization = {
          organization: org,
        };
        this.acronymRequired = false;
        if (fromAccept) {
          this.acceptRow();
        }
      },
      (error) => {
        this.acronymRequired = true;
      }
    );
  }

  private acceptRow(): void {
    this.resetValidationFlags();
    if (this.validLocation(this.index)) {
      this.base.newLocation = this.assignPalmLocation(this.base.newLocation);
      // Check if workerBase and workerAssignments exist before accessing
      if (
        this.workerBase &&
        this.workerBase.workerAssignments &&
        Array.isArray(this.workerBase.workerAssignments) &&
        this.workerBase.workerAssignments.length >= 1
      ) {
        this.adjustWorkerLocationIndicator(this.index);
      } else {
        this.base.newLocation.primaryLocationIndicator = true;
        if (this.base.newLocation.workerOrganization) {
          this.base.newLocation.workerOrganization.primaryOrganizationIndicator = true;
        }
      }
      this.acceptLocationAssignments(this.index);
    } else {
    }
  }

  private resetValidationFlags(): void {
    this.locationInvalid = false;
    this.palmLocationLookupNoResults = false;
    this.acronymRequired = false;
    this.mailLocationInvalid = false;
    this.locationRequired = false;
  }

  private assignPalmLocation(location: any): any {
    if (location.palmLocationDetail && location.palmLocationDetail.visualLocationCode) {
      location.palmLocationDetail = JSON.parse(JSON.stringify(location.palmLocationDetail));
    }
    return location;
  }

  private acceptLocationAssignments(index: number): void {
    if (this.base.newLocation.location) {
      // this.validateLocationAssignment(this.base.newLocation).then(
      //   (exactMatch: any) => {
      //     if (exactMatch === 'Not Found') {
      //       this.locationInvalid = true;
      //     } else {
      //       this.locationInvalid = false;
      //       this.base.newLocation = exactMatch;
      //     }
      //     this.acceptMailLocationAssignment(index);
      //   },
      //   () => {
      //     this.locationInvalid = true;
      //     this.acceptMailLocationAssignment(index);
      //   }
      // );
       this.addLocationAssignment(index, this.locationInvalid);
    } else {
      this.acceptMailLocationAssignment(index);
    }
  }

  private acceptMailLocationAssignment(index: number): void {
    if (
      this.base.newLocation.mailStopLocation &&
      this.base.newLocation.mailStopLocation.building &&
      this.base.newLocation.mailStopLocation.building.code
    ) {
      // this.validateMailLocationAssignment(this.base.newLocation).then(
      //   (exactMatch: any) => {
      //     if (exactMatch === 'Not Found') {
      //       this.mailLocationInvalid = true;
      //     } else {
      //       this.mailLocationInvalid = false;
      //       this.base.newLocation = exactMatch;
      //       if (!this.mailLocationInvalid && !this.locationInvalid) {
      //         this.addLocationAssignment(index, this.mailLocationInvalid);
      //       }
      //     }
      //   },
      //   () => {
      //     this.mailLocationInvalid = true;
      //   }
      // );
    this.addLocationAssignment(index, this.mailLocationInvalid);
    } else {
      if (!this.mailLocationInvalid && !this.locationInvalid) {
        this.addLocationAssignment(index, false);
      }
    }
  }

  private validateLocationAssignment(location: any): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!location.location || !location.location.building) {
        reject('Not Found');
        return;
      }

      // Build query parameters matching the API format
      const queryParams = this.buildLocationQueryParams(location.location, false);
      
      this.workerManagementService.validateLocationAssignment(queryParams).subscribe(
        (response: any) => {
          if (response && response.results && response.results.length > 0) {
            // Find exact match
            const exactMatch = this.findExactLocationMatch(location.location, response.results);
            if (exactMatch) {
              location.location = exactMatch;
              if (location.assignmentLocation) {
                location.assignmentLocation.locationId = exactMatch.locationId;
              } else {
                location.assignmentLocation = { locationId: exactMatch.locationId };
              }
              resolve(location);
            } else {
              reject('Not Found');
            }
          } else {
            reject('Not Found');
          }
        },
        (error) => {
          reject('Not Found');
        }
      );
    });
  }

  private validateMailLocationAssignment(location: any): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!location.mailStopLocation || !location.mailStopLocation.building) {
        reject('Not Found');
        return;
      }

      // Build query parameters matching the API format
      const queryParams = this.buildLocationQueryParams(location.mailStopLocation, true);
      
      this.workerManagementService.validateLocationAssignment(queryParams).subscribe(
        (response: any) => {
          if (response && response.results && response.results.length > 0) {
            // Find exact match
            const exactMatch = this.findExactLocationMatch(location.mailStopLocation, response.results);
            if (exactMatch) {
              location.mailStopLocation = exactMatch;
              if (location.mailLocation) {
                location.mailLocation.locationId = exactMatch.locationId;
              } else {
                location.mailLocation = { locationId: exactMatch.locationId };
              }
              resolve(location);
            } else {
              reject('Not Found');
            }
          } else {
            reject('Not Found');
          }
        },
        (error) => {
          reject('Not Found');
        }
      );
    });
  }

  /**
   * Build query parameters for location validation API call
   */
  private buildLocationQueryParams(location: any, mailStopIndicator: boolean): string {
    const params: string[] = [];
    
    if (location.building?.code) {
      params.push(`buildingCode=${encodeURIComponent(location.building.code)}`);
    }
    if (location.building?.floorNumber) {
      params.push(`floorPrefix=${encodeURIComponent(location.building.floorNumber)}`);
    }
    if (location.corridorId) {
      params.push(`corridorPrefix=${encodeURIComponent(location.corridorId)}`);
    }
    if (location.suiteId) {
      params.push(`suitePrefix=${encodeURIComponent(location.suiteId)}`);
    }
    if (location.roomId) {
      params.push(`roomPrefix=${encodeURIComponent(location.roomId)}`);
    }
    if (location.zoneId) {
      params.push(`zonePrefix=${encodeURIComponent(location.zoneId)}`);
    }
    
    params.push(`includeInactive=false`);
    params.push(`mailStopIndicator=${mailStopIndicator}`);
    
    return params.join('&');
  }

  /**
   * Find exact location match from search results
   */
  private findExactLocationMatch(searchLocation: any, results: any[]): any | null {
    if (!results || results.length === 0) {
      return null;
    }

    return results.find((location: any) => {
      const buildingMatch = location.building?.code === searchLocation.building?.code;
      const floorMatch = !searchLocation.building?.floorNumber ||
                        location.building?.floorNumber === searchLocation.building?.floorNumber;
      const corridorMatch = !searchLocation.corridorId || location.corridorId === searchLocation.corridorId;
      const suiteMatch = !searchLocation.suiteId || location.suiteId === searchLocation.suiteId;
      const roomMatch = !searchLocation.roomId || location.roomId === searchLocation.roomId;
      const zoneMatch = !searchLocation.zoneId || location.zoneId === searchLocation.zoneId;

      return buildingMatch && floorMatch && corridorMatch && suiteMatch && roomMatch && zoneMatch;
    }) || null;
  }

  private addLocationAssignment(index: number, invalidLocationAssignment: boolean): void {
    if (!invalidLocationAssignment) {
      if (this.showAddLocationRow) {
        if (!Array.isArray(this.workerBase.workerAssignments)) {
          this.workerBase.workerAssignments = [];
        }
        // Initialize viewMode property for new assignment
        this.base.newLocation.viewMode = 0;
        this.workerBase.workerAssignments.push(this.base.newLocation);
        // Update index to point to the newly added location
        index = this.workerBase.workerAssignments.length - 1;
        
        // Ensure viewMode is explicitly set on the array item
        this.workerBase.workerAssignments[index].viewMode = 0;
        
        this.changeLocationEvent.emit();

        // Trigger change detection
        this.cdr.detectChanges();
      } else {
        // CRITICAL FIX: Preserve workerOrganizationId and organization.name from original assignment
        const originalAssignment = this.workerBase.workerAssignments[index];
        const originalWorkerOrgId = originalAssignment?.workerOrganization?.workerOrganizationId;
        const originalOrgName = originalAssignment?.workerOrganization?.organization?.name;
        const originalWorkerAssignmentId = originalAssignment?.workerAssignmentId;
        const originalAudit = originalAssignment?.audit;
        
        this.workerBase.workerAssignments[index] = JSON.parse(
          JSON.stringify(this.base.newLocation)
        );
        // Initialize viewMode property for updated assignment
        this.workerBase.workerAssignments[index].viewMode = 0;
        
        // Restore critical fields that must be preserved for PUT calls
        if (originalWorkerOrgId) {
          if (!this.workerBase.workerAssignments[index].workerOrganization) {
            this.workerBase.workerAssignments[index].workerOrganization = { organization: {} };
          }
          this.workerBase.workerAssignments[index].workerOrganization.workerOrganizationId = originalWorkerOrgId;
        }
        
        if (originalOrgName) {
          if (!this.workerBase.workerAssignments[index].workerOrganization) {
            this.workerBase.workerAssignments[index].workerOrganization = { organization: {} };
          }
          if (!this.workerBase.workerAssignments[index].workerOrganization.organization) {
            this.workerBase.workerAssignments[index].workerOrganization.organization = {};
          }
          this.workerBase.workerAssignments[index].workerOrganization.organization.name = originalOrgName;
        }
        
        if (originalWorkerAssignmentId) {
          this.workerBase.workerAssignments[index].workerAssignmentId = originalWorkerAssignmentId;
        }
        
        if (originalAudit) {
          this.workerBase.workerAssignments[index].audit = originalAudit;
        }
        // Mark assignment as edited if it has a workerOrganizationId (existing assignment)
        if (this.workerBase.workerAssignments[index].workerOrganization?.workerOrganizationId) {
          this.workerBase.workerAssignments[index].edited = true;
        } else {
        }
        // Trigger change detection
        this.cdr.detectChanges();
      }
      this.updateRoleList();
      // Call cancelAddEdit without parameter to properly hide the add row
      this.cancelAddEdit(null);
      // Ensure the newly added/edited assignment is in collapsed view mode
      if (this.workerBase.workerAssignments[index]) {
        this.workerBase.workerAssignments[index].viewMode = 0;
      }
      
      // Final change detection to ensure template updates
      this.cdr.detectChanges();
    } else {
    }
  }

  private updateRoleList(): void {
    // CRITICAL FIX: Always fetch organization report roles when organization ID is available
    // This is required for validation when adding worker organization location assignments
    // API: GET /organization-report-roles?organizationId={id}&sortColumn=reportRoleValue&sortOrder=asc
    if (this.base.newLocation.workerOrganization?.organization?.id) {
      this.organisationService.getOrganizationReportRoles(this.base.newLocation.workerOrganization.organization.id).subscribe(
        (response: any) => {
          this.workerBase.organizationWorkerRoles = response.results || [];
        },
        (error) => {
          this.workerBase.organizationWorkerRoles = [];
        }
      );
    } else {
    }
  }

  private adjustWorkerLocationIndicator(index: number): void {
    if (this.showAddLocationRow) {
      if (this.base.newLocation.primaryLocationIndicator) {
        this.adjustAlternateToPrimaryIndicator();
      }
      if (
        !this.base.newLocation.primaryLocationIndicator &&
        !this.base.newLocation.hiddenIndicator &&
        !this.base.newLocation.alternateIndicator
      ) {
        this.base.newLocation.alternateIndicator = true;
        if (this.base.newLocation.workerOrganization) {
          this.base.newLocation.workerOrganization.primaryOrganizationIndicator = false;
        }
      }
    } else {
      if (
        this.base.newLocation.primaryLocationIndicator &&
        !this.workerBase.workerAssignments[index]?.primaryLocationIndicator
      ) {
        this.adjustAlternateToPrimaryIndicator();
      } else if (
        !this.base.newLocation.primaryLocationIndicator &&
        this.workerBase.workerAssignments[index]?.primaryLocationIndicator
      ) {
        this.adjustPrimaryToAlternateIndicator();
      }
    }
  }

  private adjustAlternateToPrimaryIndicator(): void {
    if (this.workerBase.workerAssignments) {
      this.workerBase.workerAssignments.forEach((workerLocation: any) => {
        if (workerLocation.primaryLocationIndicator) {
          workerLocation.primaryLocationIndicator = false;
          workerLocation.alternateIndicator = true;
          if (workerLocation.workerOrganization) {
            workerLocation.workerOrganization.primaryOrganizationIndicator = false;
          }
          workerLocation.edited = true;
          if (workerLocation.workerOrganization) {
            workerLocation.workerOrganization.lifecycle = {
              beginDate: new Date().toISOString(),
            };
          }
          workerLocation.lifecycle = {
            beginDate: new Date().toISOString(),
          };
        }
      });
    }
  }

  private adjustPrimaryToAlternateIndicator(): void {
    if (this.workerBase.workerAssignments) {
      for (let count = 0; count < this.workerBase.workerAssignments.length; count++) {
        if (
          !this.workerBase.workerAssignments[count].primaryLocationIndicator &&
          !this.workerBase.workerAssignments[count].hiddenIndicator
        ) {
          this.workerBase.workerAssignments[count].primaryLocationIndicator = true;
          this.workerBase.workerAssignments[count].alternateIndicator = false;
          if (this.workerBase.workerAssignments[count].workerOrganization) {
            this.workerBase.workerAssignments[count].workerOrganization.primaryOrganizationIndicator = true;
          }
          this.workerBase.workerAssignments[count].edited = true;
          if (this.workerBase.workerAssignments[count].workerOrganization) {
            this.workerBase.workerAssignments[count].workerOrganization.lifecycle = {
              beginDate: new Date().toISOString(),
            };
          }
          this.workerBase.workerAssignments[count].lifecycle = {
            beginDate: new Date().toISOString(),
          };
          break;
        }
      }
    }
  }

  confirmDeleteWorkerLocation(index: number): void {
    this.removeWorkerLocation(index);
  }

  private removeWorkerLocation(index: number): void {
    if (this.workerBase.workerAssignments[index]?.primaryLocationIndicator) {
      let primaryCount = 0;
      this.workerBase.workerAssignments.forEach((assignment: any) => {
        if (assignment.primaryLocationIndicator) {
          primaryCount++;
        }
      });
      if (primaryCount === 1) {
        this.base.newLocation.setPrimary = true;
      } else {
        this.base.newLocation.setPrimary = false;
        if (this.workerBase.workerAssignments[index]?.workerAssignmentId) {
          if (!this.workerBase.assignmentsDeleteList) {
            this.workerBase.assignmentsDeleteList = [];
          }
          this.workerBase.assignmentsDeleteList.push(
            this.workerBase.workerAssignments[index]
          );
        }
        if (this.workerBase.workerAssignments[index]?.workerOrganization) {
          this.workerBase.workerAssignments[index].workerOrganization.primaryOrganizationIndicator = false;
        }
        this.workerBase.workerAssignments.splice(index, 1);
      }
    } else {
      if (this.workerBase.workerAssignments[index]?.workerAssignmentId) {
        if (!this.workerBase.assignmentsDeleteList) {
          this.workerBase.assignmentsDeleteList = [];
        }
        this.workerBase.assignmentsDeleteList.push(
          this.workerBase.workerAssignments[index]
        );
      }
      this.workerBase.workerAssignments.splice(index, 1);
    }
  }


  showPalmLocationLookup() {
    // Get the current visual location code value from the form
    const currentVisualLocationCode = this.assignMentWorker.get('visualLocationCode')?.value;
    
    const palmLocationDialogRef = this.dialog.open(PalmLocationLookupComponent, {
      width: '80em',
      height: '75vh',
      data: {
        initialSearchValue: currentVisualLocationCode || ''
      }
    });

    palmLocationDialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        const visualLocationCodeControl = this.assignMentWorker.get('visualLocationCode');
        if (visualLocationCodeControl) {
          visualLocationCodeControl.setValue(result.visualLocationCode);
        }
        this.base.newLocation.palmLocationDetail = result;
        this.assignPalmLocation(this.base.newLocation);
      }
    });
  }

  setMailStopLocation(event: Event) {
    this.base.newLocation.mailLocationIndicator = (event.target as HTMLInputElement).checked;
    
    // Get form controls for all mailstop location fields
    const buildingCodeControl = this.assignMentWorker.get('mailStopLocationcode');
    const floorNumberControl = this.assignMentWorker.get('mailStopLocationFloorNumber');
    const corridorControl = this.assignMentWorker.get('mailStopLocationcorridorId');
    const suiteControl = this.assignMentWorker.get('mailStopLocationsuiteId');
    const roomControl = this.assignMentWorker.get('mailStopLocationroomId');
    const zoneControl = this.assignMentWorker.get('mailStopLocationzoneId');
    
    if (this.base.newLocation.mailLocationIndicator) {
      // Initialize mailStopLocation structure when checkbox is checked
      if (!this.base.newLocation.mailStopLocation) {
        this.base.newLocation.mailStopLocation = {
          building: {
            code: '',
            floorNumber: '',
          },
          corridorId: '',
          suiteId: '',
          roomId: '',
          zoneId: '',
        };
      }
      // Reset mailStopBuildingFloors when checkbox is checked
      this.mailStopBuildingFloors = [];
      
      // Enable all mailstop location form controls
      if (buildingCodeControl) {
        buildingCodeControl.enable();
      }
      if (floorNumberControl) {
        floorNumberControl.enable();
      }
      if (corridorControl) {
        corridorControl.enable();
      }
      if (suiteControl) {
        suiteControl.enable();
      }
      if (roomControl) {
        roomControl.enable();
      }
      if (zoneControl) {
        zoneControl.enable();
      }
    } else {
      // Clear mailStopLocation when checkbox is unchecked
      this.base.newLocation.mailStopLocation = null;
      this.base.newLocation.mailLocation = null;
      this.base.newLocation.mailStopInvalid = false;
      this.mailLocationInvalid = false;
      this.mailStopBuildingFloors = [];
      
      // Disable all mailstop location form controls
      if (buildingCodeControl) {
        buildingCodeControl.disable();
      }
      if (floorNumberControl) {
        floorNumberControl.disable();
      }
      if (corridorControl) {
        corridorControl.disable();
      }
      if (suiteControl) {
        suiteControl.disable();
      }
      if (roomControl) {
        roomControl.disable();
      }
      if (zoneControl) {
        zoneControl.disable();
      }
    }
  }

  private disableMailStopLocationFields(): void {
    // Get form controls for all mailstop location fields
    const buildingCodeControl = this.assignMentWorker.get('mailStopLocationcode');
    const floorNumberControl = this.assignMentWorker.get('mailStopLocationFloorNumber');
    const corridorControl = this.assignMentWorker.get('mailStopLocationcorridorId');
    const suiteControl = this.assignMentWorker.get('mailStopLocationsuiteId');
    const roomControl = this.assignMentWorker.get('mailStopLocationroomId');
    const zoneControl = this.assignMentWorker.get('mailStopLocationzoneId');
    
    // Disable all mailstop location form controls by default
    if (buildingCodeControl) {
      buildingCodeControl.disable();
    }
    if (floorNumberControl) {
      floorNumberControl.disable();
    }
    if (corridorControl) {
      corridorControl.disable();
    }
    if (suiteControl) {
      suiteControl.disable();
    }
    if (roomControl) {
      roomControl.disable();
    }
    if (zoneControl) {
      zoneControl.disable();
    }
  }

  getPalmLocationDescription() {
    // Get the visual location code from the form control
    const visualLocationCode = this.assignMentWorker.get('visualLocationCode')?.value;
    
    if (!visualLocationCode || visualLocationCode.trim().length === 0) {
      this.selectedPalmLocationDescription = '';
      this.selectedPalmLocationArtUnit = '';
      this.palmLocationLookupNoResults = false;
      return;
    }

    const searchCode = visualLocationCode.trim().toUpperCase();
    
    // Set loading state
    this.palmLocationSearchLoading = true;
    this.palmLocationSearchNoResults = false;
    this.selectedPalmLocationDescription = '';
    this.selectedPalmLocationArtUnit = '';

    // Call the palm location service API with the search code
    this.palmLocationService.getPalmLocations(
      false, // includeInactive
      searchCode, // searchText (codePrefix)
      100, // limit
      0, // skip
      'visualLocationCode', // sortColumn
      'asc' // sortOrder
    ).subscribe(
      (response: any) => {
        this.palmLocationSearchLoading = false;
        
        // Check if response contains results
        if (response && response.results && response.results.length > 0) {
          // Find exact match for the visual location code
          const exactMatch = response.results.find((location: any) =>
            location.visualLocationCode &&
            location.visualLocationCode.trim().toUpperCase() === searchCode
          );
          
          if (exactMatch) {
            // Display description in format [description] beside the binoculars button
            this.selectedPalmLocationDescription = '[' + (exactMatch.description || '') + ']';
            this.selectedPalmLocationArtUnit = exactMatch.artUnit || '';
            this.base.newLocation.palmLocationDetail = JSON.parse(JSON.stringify(exactMatch));
            this.palmLocationLookupNoResults = false;
          } else {
            this.palmLocationLookupNoResults = true;
            this.selectedPalmLocationDescription = '';
            this.selectedPalmLocationArtUnit = '';
          }
        } else {
          this.palmLocationLookupNoResults = true;
          this.selectedPalmLocationDescription = '';
          this.selectedPalmLocationArtUnit = '';
        }
        
        this.cdr.detectChanges();
      },
      (error: any) => {
        this.palmLocationSearchLoading = false;
        this.palmLocationLookupNoResults = true;
        this.selectedPalmLocationDescription = '';
        this.selectedPalmLocationArtUnit = '';
        this.cdr.detectChanges();
      }
    );
  }

  validatePalmLocation() {
    // Get the visual location code from the form control
    const visualLocationCode = this.assignMentWorker.get('visualLocationCode')?.value;
    
    this.palmLocationLookupNoResults = false;
    this.selectedPalmLocationDescription = '';
    this.selectedPalmLocationArtUnit = '';
    
    if (!visualLocationCode || visualLocationCode.trim().length === 0) {
      return;
    }
    
    const searchCode = visualLocationCode.trim().toUpperCase();
    
    // Set loading state
    this.palmLocationSearchLoading = true;

    // Call the palm location service API with the search code
    this.palmLocationService.getPalmLocations(
      false, // includeInactive
      searchCode, // searchText (codePrefix)
      100, // limit
      0, // skip
      'visualLocationCode', // sortColumn
      'asc' // sortOrder
    ).subscribe(
      (response: any) => {
        this.palmLocationSearchLoading = false;
        
        // Check if response contains results
        if (response && response.results && response.results.length > 0) {
          // Find exact match for the visual location code
          const exactMatch = response.results.find((location: any) =>
            location.visualLocationCode &&
            location.visualLocationCode.trim().toUpperCase() === searchCode
          );
          
          if (exactMatch) {
            this.base.newLocation.palmLocationDetail = JSON.parse(JSON.stringify(exactMatch));
            this.selectedPalmLocationDescription = '[' + (exactMatch.description || '') + ']';
            this.selectedPalmLocationArtUnit = exactMatch.artUnit || '';
            this.palmLocationLookupNoResults = false;
          } else {
            this.palmLocationLookupNoResults = true;
            this.selectedPalmLocationDescription = '';
            this.selectedPalmLocationArtUnit = '';
          }
        } else {
          this.palmLocationLookupNoResults = true;
          this.selectedPalmLocationDescription = '';
          this.selectedPalmLocationArtUnit = '';
        }
        
        this.cdr.detectChanges();
      },
      (error: any) => {
        this.palmLocationSearchLoading = false;
        this.palmLocationLookupNoResults = true;
        this.selectedPalmLocationDescription = '';
        this.selectedPalmLocationArtUnit = '';
        this.cdr.detectChanges();
      }
    );
  }

  buildingChanged(floorToSet?: any) {
    this.buildingFloors = [];
    if (this.base.newLocation.location && this.base.newLocation.location.building) {
      const buildingCode = this.base.newLocation.location.building.code;
      
      const selectedBuilding = this.buildingsList.find(
        (building) => building.buildingCode === buildingCode
      );
      
      if (selectedBuilding && selectedBuilding.buildingFloors) {
        this.buildingFloors = selectedBuilding.buildingFloors.filter(
          (floor: any) => !floor.lifecycle?.endDate
        );
        if (floorToSet) {
          this.base.newLocation.location.building.floorNumber = floorToSet;
        }
      }
    }
  }

  private getMultipleHiddenIndicator(index: number) {
    let locationTypeCount = 0;
    if (this.workerBase.workerAssignments) {
      for (let counter = 0; counter < this.workerBase.workerAssignments.length; counter++) {
        if (this.workerBase.workerAssignments[counter].hiddenIndicator) {
          locationTypeCount++;
        }
      }
    }
    if (
      (this.showAddLocationRow && this.base.newLocation.hiddenIndicator) ||
      (this.base.newLocation.hiddenIndicator &&
        !this.workerBase.workerAssignments[index]?.hiddenIndicator)
    ) {
      locationTypeCount++;
    }
    if (locationTypeCount > 1) {
      this.base.newLocation.multipleHiddenAssignments = true;
    } else {
      this.base.newLocation.multipleHiddenAssignments = false;
    }
  }

  private validateHiddenIndicator(): boolean {
    if (
      this.base.newLocation.multipleHiddenAssignments ||
      this.base.newLocation.invalidHiddenIndicator
    ) {
      return true;
    } else {
      if (
        !this.base.newLocation.multipleHiddenAssignments &&
        !this.base.newLocation.invalidHiddenIndicator
      ) {
        return false;
      }
    }
    return false;
  }

  private validateLocationIndicator(index: number): boolean {
    this.getMultipleHiddenIndicator(index);
    const invalidHiddenIndicators = this.validateHiddenIndicator();
    return (
      invalidHiddenIndicators ||
      this.base.newLocation.invalidPrimaryIndicator ||
      this.base.newLocation.singlePrimary
    );
  }

  private validateWorkerOrganizationPalmLocation(): boolean {
    if (
      !this.base.newLocation.workerOrganization ||
      !this.base.newLocation.workerOrganization.organization?.acronym
    ) {
      this.acronymRequired = true;
    } else {
    }
    if (this.acronymRequired || this.palmLocationLookupNoResults) {
      return true;
    } else {
      if (!this.acronymRequired && !this.palmLocationLookupNoResults) {
        return false;
      }
    }
    return false;
  }

  private validateMailstopLocation() {
    if (this.base.newLocation.mailLocationIndicator) {
      if (
        !this.base.newLocation.mailStopLocation ||
        !this.base.newLocation.mailStopLocation.building ||
        !this.base.newLocation.mailStopLocation.building.code ||
        !this.base.newLocation.mailStopLocation.building.floorNumber
      ) {
        this.base.newLocation.mailStopInvalid = true;
      } else {
        this.base.newLocation.mailStopInvalid = false;
      }
    }
  }

  private validateWorkerLocation(): boolean {
    if (this.base.newLocation.location) {
      this.locationRequired = false;
      if (
        this.base.newLocation.location.building?.code &&
        !this.base.newLocation.location.building?.floorNumber
      ) {
        this.locationInvalid = true;
      } else {
        this.locationInvalid = false;
      }
    }
    this.validateMailstopLocation();
    if (this.locationRequired || this.locationInvalid) {
      return true;
    } else {
      if (!this.locationRequired && !this.locationInvalid) {
        return false;
      }
    }
    return false;
  }

  private splitValidLocation(): boolean {
    const invalidWorkerLocation = this.validateWorkerLocation();
    if (this.base.newLocation.mailStopInvalid || invalidWorkerLocation) {
      return true;
    } else {
      if (!this.base.newLocation.mailStopInvalid) {
        return false;
      }
    }
    return false;
  }

  private validLocation(index: number): boolean {
    this.locationInvalid = false;
    const invalidWorkerOrganization = this.validateWorkerOrganizationPalmLocation();
    const invalidSplitLocation = this.splitValidLocation();
    const invalidIndicators = this.validateLocationIndicator(index);
    const isValid = !invalidWorkerOrganization && !invalidIndicators && !invalidSplitLocation;
    this.locationInvalid = !isValid;
    return isValid;
  }

  resetPrimarySetAlternateIndicator() {
    this.base.newLocation.primaryLocationIndicator = false;
    if (this.base.newLocation.workerOrganization) {
      this.base.newLocation.workerOrganization.primaryOrganizationIndicator = false;
    }
    this.base.newLocation.hiddenIndicator = false;
    this.base.newLocation.invalidHiddenIndicator = false;
    this.base.newLocation.invalidPrimaryIndicator = false;
    this.base.newLocation.multiplePrimaryAssignments = false;
    this.base.newLocation.multipleHiddenAssignments = false;
    if (this.base.newLocation.edited) {
      if (this.workerBase.workerAssignments?.length === 1) {
        this.base.newLocation.singlePrimary = true;
      } else {
        this.base.newLocation.singlePrimary = false;
      }
    } else {
      this.base.newLocation.singlePrimary = false;
    }
  }

  resetPrimaryIndicator(val: any) {
    if (val) {
      if (val.primaryLocationIndicator) {
        this.base.newLocation.invalidHiddenIndicator = true;
      } else {
        this.base.newLocation.invalidHiddenIndicator = false;
      }
    }
    this.base.newLocation.primaryLocationIndicator = false;
    if (this.base.newLocation.workerOrganization) {
      this.base.newLocation.workerOrganization.primaryOrganizationIndicator = false;
    }
    this.base.newLocation.alternateIndicator = false;
    this.base.newLocation.invalidPrimaryIndicator = false;
    this.base.newLocation.singlePrimary = false;
    this.base.newLocation.noPrimary = false;
  }

  setPrimaryIndicator(val: any) {
    if (val) {
      if (val.hiddenIndicator) {
        this.base.newLocation.invalidPrimaryIndicator = true;
      } else {
        this.base.newLocation.invalidPrimaryIndicator = false;
      }
    }
    this.base.newLocation.alternateIndicator = false;
    this.base.newLocation.hiddenIndicator = false;
    this.base.newLocation.invalidHiddenIndicator = false;
    if (this.base.newLocation.workerOrganization) {
      this.base.newLocation.workerOrganization.primaryOrganizationIndicator = true;
    }
    this.base.newLocation.singlePrimary = false;
    this.base.newLocation.noPrimary = false;
  }

  mailstopBuildingChanged(event: any) {
    this.assignMentWorker.patchValue({ mailStopLocationFloorNumber: '' });
    this.mailStopBuildingFloors = [];
    let selectedBuildingCode: any;
    if (typeof event === 'string') {
      selectedBuildingCode = event;
    } else {
      selectedBuildingCode = (event.target as HTMLInputElement)?.value;
    }
    const selectedBuilding = this.buildingsList.find(
      (building) => building.buildingCode === selectedBuildingCode
    );
    if (selectedBuilding) {
      this.mailStopBuildingFloors = selectedBuilding.buildingFloors || [];
    }
  }

  getBuildingCode() {
    this.organisationService.getBuildings().subscribe(
      (response: any) => {
        if (response && response.results && response.results.length > 0) {
          this.buildingsList = response.results;
        }
      },
      (error: any) => {
      }
    );
  }

  buildingChangedEvent(event: any) {
    this.assignMentWorker.patchValue({ floorNumber: '' });
    this.buildingFloors = [];
    const selectedBuildingCode = event.target.value;
    const selectedBuilding = this.buildingsList.find(
      (building) => building.buildingCode === selectedBuildingCode
    );
    if (selectedBuilding) {
      this.buildingFloors = selectedBuilding.buildingFloors || [];
    }
  }

  /**
   * Check if a building code exists in the buildings list
   */
  isBuildingCodeInList(code: string): boolean {
    if (!code || !this.buildingsList) return false;
    return this.buildingsList.some((b) => b.buildingCode === code);
  }

  /**
   * Check if a floor number exists in the building floors list
   */
  isFloorNumberInList(floorNumber: string): boolean {
    if (!floorNumber || !this.buildingFloors) return false;
    return this.buildingFloors.some((f: any) => f.floorNumber === floorNumber);
  }

  toggleCommunications() {
    this.showAllLocations = !this.showAllLocations;
  }

  setViewMode(workerLocation: any) {
    if (!workerLocation.viewMode || workerLocation.viewMode === 0) {
      workerLocation.viewMode = 1;
    } else if (workerLocation.viewMode === 1) {
      workerLocation.viewMode = 0;
    }
  }

  /**
   * Enter edit mode for a worker location assignment
   * Matches old AngularJS app functionality
   */
  setEditModeWorkerLocation(workerLocation: any, index: number): void {
    if (!this.editAddMode) {
      this.editAddMode = true;
      // Store original values for reset functionality - deep copy to prevent mutations
      this.originalLocation = JSON.parse(JSON.stringify(workerLocation));
      this.base.newLocation = JSON.parse(JSON.stringify(workerLocation));
      this.base.newLocation.edited = true;
      this.index = index;
      // Set to edit mode AFTER deep copy
      workerLocation.viewMode = 2;

      // Ensure all required nested structures exist (preserve existing data)
      if (!this.base.newLocation.workerOrganization) {
        this.base.newLocation.workerOrganization = { organization: {} };
      }
      if (!this.base.newLocation.location) {
        this.base.newLocation.location = { building: {} };
      }
      if (!this.base.newLocation.palmLocationDetail) {
        this.base.newLocation.palmLocationDetail = { visualLocationCode: '' };
      } else if (!this.base.newLocation.palmLocationDetail.visualLocationCode) {
        this.base.newLocation.palmLocationDetail.visualLocationCode = '';
      }
      if (!this.base.newLocation.mailStopLocation) {
        this.base.newLocation.mailStopLocation = { building: {} };
      }

      // Ensure nested organization structure
      if (!this.base.newLocation.workerOrganization.organization) {
        this.base.newLocation.workerOrganization.organization = {};
      }

      // Ensure nested building structures
      if (!this.base.newLocation.location.building) {
        this.base.newLocation.location.building = {};
      }
      if (!this.base.newLocation.mailStopLocation.building) {
        this.base.newLocation.mailStopLocation.building = {};
      }

      // Handle organization data structure - construct acronym and normalize ID field
      // This matches the legacy AngularJS setAcronym() function behavior
      if (this.base.newLocation.workerOrganization?.organization) {
        const org = this.base.newLocation.workerOrganization.organization;
        // Normalize ID field - API returns 'organizationId' but code expects 'id'
        if (org.organizationId && !org.id) {
          org.id = org.organizationId;
        }
        
        // Extract businessAreaCode from nested structure if needed
        let businessAreaCode = org.businessAreaCode || '';
        if (!businessAreaCode && org.organizationType?.businessArea?.code) {
          businessAreaCode = org.organizationType.businessArea.code;
          org.businessAreaCode = businessAreaCode;
        }
        
        // Get shortName
        const shortName = org.shortName || '';
        // Construct acronym from businessAreaCode and shortName
        // This matches legacy AngularJS: WorkerLocationAssignmentControllerHelper.getAcronym()
        if (businessAreaCode && shortName) {
          org.acronym = `${businessAreaCode.trim()}/${shortName.trim()}`;
        } else {
        }
      }

      // Ensure all location fields exist (preserve null/undefined as empty string for binding)
      // Only set to empty string if the value is null or undefined
      if (this.base.newLocation.location.corridorId === null || this.base.newLocation.location.corridorId === undefined) {
        this.base.newLocation.location.corridorId = '';
      }
      if (this.base.newLocation.location.suiteId === null || this.base.newLocation.location.suiteId === undefined) {
        this.base.newLocation.location.suiteId = '';
      }
      if (this.base.newLocation.location.roomId === null || this.base.newLocation.location.roomId === undefined) {
        this.base.newLocation.location.roomId = '';
      }
      if (this.base.newLocation.location.zoneId === null || this.base.newLocation.location.zoneId === undefined) {
        this.base.newLocation.location.zoneId = '';
      }


      // Set mailLocationIndicator if mailLocation exists
      this.base.newLocation.mailLocationIndicator =
        !!(this.base.newLocation.mailLocation && this.base.newLocation.mailLocation.locationId);

      // Set alternateIndicator if not primary and not hidden
      this.base.newLocation.alternateIndicator =
        !this.base.newLocation.primaryLocationIndicator && !this.base.newLocation.hiddenIndicator;

      // Load building floors - this will populate the floor dropdown
      if (this.base.newLocation.location?.building?.code) {
        const tempFloorNum = this.base.newLocation.location.building.floorNumber;
        this.buildingChanged(tempFloorNum);
        // Ensure floor number is preserved after loading floors
        if (tempFloorNum) {
          this.base.newLocation.location.building.floorNumber = tempFloorNum;
        }
      }

      // Load mailstop building floors
      if (this.base.newLocation.mailStopLocation?.building?.code) {
        const tempMailFloorNum = this.base.newLocation.mailStopLocation.building.floorNumber;
        this.mailstopBuildingChanged(tempMailFloorNum);
        if (tempMailFloorNum) {
          this.base.newLocation.mailStopLocation.building.floorNumber = tempMailFloorNum;
        }
      }

      // Get PALM location description
      this.getPalmLocationDescription();

      // Trigger change detection to ensure UI updates
      this.cdr.detectChanges();
    } else {
    }
  }

  /**
   * Search for PALM locations by code prefix
   * Calls the API with the search input value (max 4 characters)
   */
  searchPalmLocations(): void {
    // Validate input
    if (!this.palmLocationSearchInput || this.palmLocationSearchInput.trim().length === 0) {
      this.palmLocationSearchResults = [];
      this.palmLocationSearchNoResults = false;
      this.palmLocationSearchErrorMessage = '';
      return;
    }

    const searchText = this.palmLocationSearchInput.trim().toUpperCase();
    
    // Set loading state
    this.palmLocationSearchLoading = true;
    this.palmLocationSearchNoResults = false;
    this.palmLocationSearchResults = [];
    this.palmLocationSearchErrorMessage = '';

    // Call the palm location service with the search text
    this.palmLocationService.getPalmLocations(
      false, // includeInactive
      searchText, // searchText (codePrefix)
      100, // limit
      0, // skip
      'visualLocationCode', // sortColumn
      'asc' // sortOrder
    ).subscribe(
      (response: any) => {
        this.palmLocationSearchLoading = false;
        
        // Check if response contains an error message
        if (response && response.message) {
          this.palmLocationSearchErrorMessage = response.message;
          this.palmLocationSearchResults = [];
          this.palmLocationSearchNoResults = true;
        } else if (response && response.results && response.results.length > 0) {
          this.palmLocationSearchResults = response.results;
          this.palmLocationSearchNoResults = false;
          this.palmLocationSearchErrorMessage = '';
        } else {
          this.palmLocationSearchResults = [];
          this.palmLocationSearchNoResults = true;
          this.palmLocationSearchErrorMessage = '';
        }
        
        this.cdr.detectChanges();
      },
      (error: any) => {
        this.palmLocationSearchLoading = false;
        this.palmLocationSearchResults = [];
        this.palmLocationSearchNoResults = true;
        this.palmLocationSearchErrorMessage = error?.error?.message || 'An error occurred while searching for PALM locations';
        this.cdr.detectChanges();
      }
    );
  }

  /**
   * Select a PALM location from search results
   * Populates the visualLocationCode field with the selected location
   */
  selectPalmLocationFromSearch(palmLocation: any): void {
    if (palmLocation && palmLocation.visualLocationCode) {
      this.base.newLocation.palmLocationDetail = JSON.parse(JSON.stringify(palmLocation));
      this.selectedPalmLocationDescription = '[' + (palmLocation.description || '') + ']';
      this.selectedPalmLocationArtUnit = palmLocation.artUnit || '';
      this.palmLocationLookupNoResults = false;
      
      // Clear search results and input
      this.palmLocationSearchInput = '';
      this.palmLocationSearchResults = [];
      this.palmLocationSearchNoResults = false;
      this.palmLocationSearchErrorMessage = '';
      
      this.cdr.detectChanges();
    }
  }

}
