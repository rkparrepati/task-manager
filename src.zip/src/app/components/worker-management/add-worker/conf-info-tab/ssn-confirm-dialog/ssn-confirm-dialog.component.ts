import { Component, Inject, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

/**
 * Dialog component for SSN confirmation
 * Requires user to re-enter SSN to verify it matches the original entry
 */
@Component({
  selector: 'app-ssn-confirm-dialog',
  templateUrl: './ssn-confirm-dialog.component.html',
  styleUrls: ['./ssn-confirm-dialog.component.scss']
})
export class SsnConfirmDialogComponent implements OnInit {
  @ViewChild('confirmationInput') confirmationInput!: ElementRef;

  confirmForm!: FormGroup;
  errorMessage: string | null = null;
  originalSSN: string = '';

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<SsnConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.originalSSN = data?.value || '';
  }

  ngOnInit(): void {
    this.initializeForm();
  }

  ngAfterViewInit(): void {
    // Auto-focus on the confirmation input field when dialog opens
    if (this.confirmationInput) {
      setTimeout(() => {
        this.confirmationInput.nativeElement.focus();
      }, 100);
    }
  }

  /**
   * Initialize the confirmation form
   */
  private initializeForm(): void {
    this.confirmForm = this.fb.group({
      confirmSSN: ['', [Validators.required]]
    });
  }

  /**
   * Validate that the re-entered SSN matches the original
   * @returns True if SSNs match, false otherwise
   */
  private validateSSNMatch(): boolean {
    const confirmSSN = this.confirmForm.get('confirmSSN')?.value || '';
    
    // Remove hyphens for comparison
    const originalDigits = this.originalSSN.replace(/\D/g, '');
    const confirmDigits = confirmSSN.replace(/\D/g, '');

    return originalDigits === confirmDigits;
  }

  /**
   * Handle OK button click
   * Validates that SSNs match before closing dialog
   */
  onOkClick(): void {
    if (!this.confirmForm.valid) {
      this.errorMessage = 'Please enter the Social Security Number';
      return;
    }

    if (!this.validateSSNMatch()) {
      this.errorMessage = 'The SSN entered does not match the previously entered value.';
      this.confirmForm.get('confirmSSN')?.reset();
      return;
    }

    // SSNs match, close dialog with success
    this.errorMessage = null;
    this.dialogRef.close(true);
  }

  /**
   * Handle Cancel button click
   */
  onCancelClick(): void {
    this.dialogRef.close(false);
  }

  /**
   * Handle Enter key press in the confirmation input
   * @param event Keyboard event
   */
  onEnterKey(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.onOkClick();
    }
  }

  /**
   * Clear error message when user starts typing
   */
  onConfirmSSNInput(): void {
    if (this.errorMessage) {
      this.errorMessage = null;
    }
  }
}
