import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule,MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SsnConfirmDialogComponent } from './ssn-confirm-dialog.component';
import { SsnFieldDirective } from 'src/app/directives/ssn-field.directive';

describe('SsnConfirmDialogComponent', () => {
  let component: SsnConfirmDialogComponent;
  let fixture: ComponentFixture<SsnConfirmDialogComponent>;
  let mockDialogRef: jasmine.SpyObj<MatDialogRef<SsnConfirmDialogComponent>>;

  beforeEach(async () => {
    mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);

    await TestBed.configureTestingModule({
      declarations: [SsnConfirmDialogComponent, SsnFieldDirective],
      imports: [ReactiveFormsModule,MatDialogModule],
      providers: [
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: { value: '123-45-6789' } }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(SsnConfirmDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with empty confirmSSN control', () => {
    expect(component.confirmForm.get('confirmSSN')).toBeTruthy();
    expect(component.confirmForm.get('confirmSSN')?.value).toBe('');
  });

  it('should set originalSSN from dialog data', () => {
    expect(component.originalSSN).toBe('123-45-6789');
  });

  it('should show error when confirmSSN is empty and OK is clicked', () => {
    component.onOkClick();
    expect(component.errorMessage).toBe('Please enter the Social Security Number');
  });

  it('should show error when SSNs do not match', () => {
    component.confirmForm.get('confirmSSN')?.setValue('987-65-4321');
    component.onOkClick();
    expect(component.errorMessage).toBe('The SSN entered does not match the previously entered value.');
    expect(component.confirmForm.get('confirmSSN')?.value).toBeNull();
  });

  it('should close dialog with true when SSNs match', () => {
    component.confirmForm.get('confirmSSN')?.setValue('123-45-6789');
    component.onOkClick();
    expect(mockDialogRef.close).toHaveBeenCalledWith(true);
    expect(component.errorMessage).toBeNull();
  });

  it('should match SSNs ignoring hyphens', () => {
    component.confirmForm.get('confirmSSN')?.setValue('123456789');
    component.onOkClick();
    expect(mockDialogRef.close).toHaveBeenCalledWith(true);
  });

  it('should close dialog with false on cancel', () => {
    component.onCancelClick();
    expect(mockDialogRef.close).toHaveBeenCalledWith(false);
  });

  it('should call onOkClick when Enter key is pressed', () => {
    spyOn(component, 'onOkClick');
    const event = new KeyboardEvent('keydown', { key: 'Enter' });
    spyOn(event, 'preventDefault');
    component.onEnterKey(event);
    expect(event.preventDefault).toHaveBeenCalled();
    expect(component.onOkClick).toHaveBeenCalled();
  });

  it('should not call onOkClick for non-Enter keys', () => {
    spyOn(component, 'onOkClick');
    const event = new KeyboardEvent('keydown', { key: 'Tab' });
    component.onEnterKey(event);
    expect(component.onOkClick).not.toHaveBeenCalled();
  });

  it('should clear error message when user starts typing', () => {
    component.errorMessage = 'Some error';
    component.onConfirmSSNInput();
    expect(component.errorMessage).toBeNull();
  });

  it('should not clear error message if it is already null', () => {
    component.errorMessage = null;
    component.onConfirmSSNInput();
    expect(component.errorMessage).toBeNull();
  });

  it('should auto-focus confirmation input after view init', (done) => {
    const inputElement = document.createElement('input');
    spyOn(inputElement, 'focus');
    component.confirmationInput = { nativeElement: inputElement };
    
    component.ngAfterViewInit();
    
    setTimeout(() => {
      expect(inputElement.focus).toHaveBeenCalled();
      done();
    }, 150);
  });
});
