import { Component, Input, OnInit, OnChanges, SimpleChanges, ViewChild, ChangeDetectorRef, ChangeDetectionStrategy, NgZone } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { WorkerValidationsService } from '../../worker-validations.service';
import { MatDialog } from '@angular/material/dialog';
import { SsnConfirmDialogComponent } from './ssn-confirm-dialog/ssn-confirm-dialog.component';

@Component({
  selector: 'app-conf-info-tab',
  templateUrl: './conf-info-tab.component.html',
  styleUrls: ['./conf-info-tab.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfInfoTabComponent implements OnInit, OnChanges {
  @Input() confInfoForm!: FormGroup;
  @Input() workerEmploymentType: string = 'E';
  @Input() userRoles: string[] = [];
  @Input() expandAccordion: boolean = false;
  @ViewChild('accordionGroupRef') accordionGroupRef: any;

  public isDisplay = false;
  public states: any = [];
  public countries: any = [];
  public formSubmitted: boolean = false;
  private previousSSNInput: string = '';
  public ssnValidationStatus: 'valid' | 'invalid' | 'pending' | null = null;
  public ssnErrorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private httpService: HttpService,
    private appService: AppService,
    private validationService: WorkerValidationsService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {}

  ngOnInit(): void {
    this.initializeFormControls();
    if (!this.userRoles || this.userRoles.length === 0) {
      this.userRoles = this.appService.getUserData().roles;
    }
    this.getGeoRegions();
    this.getWipoCountries();
    // Trigger initial change detection to ensure dropdown is visible
    this.cdr.markForCheck();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Re-validate when employment type changes
    if (changes['workerEmploymentType']) {
      if (this.confInfoForm) {
        this.updateConditionalValidators();
      }
    }
    // Expand accordion when expandAccordion input changes to true
    if (changes['expandAccordion'] && this.expandAccordion && this.accordionGroupRef) {
      this.accordionGroupRef.isOpen = true;
    }
    
    // Handle form population from parent component (prefill scenario)
    // When the form is populated with values, ensure reference data is available
    // and mark fields as valid to avoid false validation errors
    if (changes['confInfoForm'] && this.confInfoForm) {
      // Wait for reference data to load before processing prefilled values
      setTimeout(() => {
        this.handlePrefillValidation();
      }, 500);
    }
  }

  /**
   * Initialize all form controls with appropriate validators
   */
  private initializeFormControls(): void {
    // Conditional fields - initially without validators
    this.confInfoForm.addControl('ssn', new FormControl(''));
    this.confInfoForm.addControl('dateOfBirth', new FormControl(''));
    this.confInfoForm.addControl('birthCityName', new FormControl(''));
    this.confInfoForm.addControl('birthCountry', new FormControl(''));
    
    // Optional fields
    this.confInfoForm.addControl('birthState', new FormControl(''));
    this.confInfoForm.get('birthState')?.setValue(' ', { emitEvent: false });
    this.confInfoForm.get('birthState')?.updateValueAndValidity({ emitEvent: false });
    
    // Apply conditional validators
    this.updateConditionalValidators();
    
    // Mark all fields as untouched and pristine after initialization
    // Use setTimeout to avoid ExpressionChangedAfterItHasBeenCheckedError
    setTimeout(() => {
      this.confInfoForm.get('ssn')?.markAsUntouched();
      this.confInfoForm.get('ssn')?.markAsPristine();
      this.confInfoForm.get('dateOfBirth')?.markAsUntouched();
      this.confInfoForm.get('dateOfBirth')?.markAsPristine();
      this.confInfoForm.get('birthCityName')?.markAsUntouched();
      this.confInfoForm.get('birthCityName')?.markAsPristine();
      this.confInfoForm.get('birthCountry')?.markAsUntouched();
      this.confInfoForm.get('birthCountry')?.markAsPristine();
      this.confInfoForm.get('birthState')?.markAsUntouched();
      this.confInfoForm.get('birthState')?.markAsPristine();
    });
  }

  /**
   * Update validators for conditional fields based on employment type
   */
  private updateConditionalValidators(): void {
    this.updateFieldValidators('ssn');
    this.updateFieldValidators('dateOfBirth');
    this.updateFieldValidators('birthCityName');
    this.updateFieldValidators('birthCountry');
  }

  /**
   * Update validators for a specific field
   * @param fieldName Name of the field to update
   */
  private updateFieldValidators(fieldName: string): void {
    const control = this.confInfoForm.get(fieldName);
    if (!control) {
      return;
    }

    const validators = this.validationService.getConditionalValidators(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      true // Confidential info is only visible when user can view secure data
    );

    control.setValidators(validators);
    control.updateValueAndValidity({ emitEvent: false });
  }

  /**
   * Check if a field should be visible
   * @param fieldName Name of the field
   * @returns True if field should be visible
   */
  isFieldVisible(fieldName: string): boolean {
    return this.validationService.isFieldVisible(
      fieldName,
      this.workerEmploymentType,
      this.userRoles,
      true // Confidential info is only visible when user can view secure data
    );
  }

  /**
   * Get error message for a field
   * @param fieldName Name of the field
   * @returns Error message string
   */
  getErrorMessage(fieldName: string): string {
    const control = this.confInfoForm.get(fieldName);
    if (!control || !control.errors) {
      return '';
    }

    if (control.errors['required']) {
      return `${this.validationService.getFieldDisplayName(fieldName)} is required`;
    }

    if (fieldName === 'ssn' && control.errors['ssnInvalidLength']) {
      return 'Social security number must be 9 digits';
    }

    if (fieldName === 'dateOfBirth' && control.errors['ageValidator']) {
      return 'Employee must be at least 16 years old';
    }

    return '';
  }

  getGeoRegions() {
    return this.httpService.get('/geoRegions').subscribe((response: any) => {
      if (response) {
        this.states = response;
      }
    });
  }

  setDefaultCountry() {
    const defaultCountry = this.countries.find((country: any) => country.value === 'US');
    if (defaultCountry) {
      this.confInfoForm.get('birthCountry')?.setValue(defaultCountry.value);
    }
  }

  getWipoCountries() {
    return this.httpService.get('/wipocountries').subscribe((response: any) => {
      if (response) {
        this.countries = response;
        this.setDefaultCountry();
        // Trigger change detection after countries are loaded
        this.cdr.markForCheck();
      }
    });
  }

  setBirthCity(event: any) {
    if (event && event.target && event.target.value) {
      this.confInfoForm.get('birthCityName')?.setValue(event.target.value.toUpperCase());
    }
  }

  /**
   * Handle date of birth change from date picker
   * @param date The selected date from the date picker
   */
  onDateOfBirthChange(date: any): void {
    const dateOfBirthControl = this.confInfoForm.get('dateOfBirth');
    if (dateOfBirthControl) {
      dateOfBirthControl.setValue(date);
      dateOfBirthControl.markAsTouched();
    }
  }

  /**
   * Handle SSN field blur event
   * Opens confirmation dialog if SSN has exactly 9 digits and has changed
   */
  onSSNBlur(): void {
    const ssnControl = this.confInfoForm.get('ssn');
    if (!ssnControl) {
      return;
    }

    const currentSSN = ssnControl.value || '';
    const digitsOnly = currentSSN.replace(/\D/g, '');

    // Only trigger confirmation if SSN has exactly 9 digits and has changed
    if (digitsOnly.length === 9 && currentSSN !== this.previousSSNInput) {
      this.previousSSNInput = currentSSN;
      this.openSSNConfirmationDialog(currentSSN);
    }
  }

  /**
   * Open SSN confirmation dialog
   * @param ssn The SSN value to confirm
   */
  private openSSNConfirmationDialog(ssn: string): void {
    const dialogRef = this.dialog.open(SsnConfirmDialogComponent, {
      width: '450px',
      disableClose: true,
      data: { value: ssn }
    });

    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        // User confirmed SSN matches - proceed with backend validation
        this.validateSSNWithBackend();
      } else {
        // User cancelled or SSN didn't match - clear the field
        this.clearSSN();
      }
    });
  }

  /**
     * Validate SSN with backend service
     * Checks for duplicate SSNs
     */
   private validateSSNWithBackend(): void {
      const ssnControl = this.confInfoForm.get('ssn');
      if (!ssnControl || !ssnControl.value) {
        return;
      }

      const ssn = ssnControl.value.replace(/\D/g, '');
      this.ssnValidationStatus = 'pending';
      this.ssnErrorMessage = '';
      this.cdr.markForCheck();

      this.validationService.validateSSN(ssn).subscribe(
        (response: any) => {
          // SSN is valid and unique
          this.ngZone.run(() => {
            ssnControl.setErrors(null);
            ssnControl.markAsTouched();
            ssnControl.markAsPristine();
            this.ssnValidationStatus = 'valid';
            this.ssnErrorMessage = '';
            // Ensure the form control value is properly set and formatted
            const formattedSSN = this.formatSSN(ssn);
            ssnControl.setValue(formattedSSN, { emitEvent: false });
            this.cdr.markForCheck();
            this.cdr.detectChanges();
          });
        },
        (error: any) => {
          // SSN validation failed (duplicate or format error)
          this.ngZone.run(() => {
            const errorMessage = error?.message || 'SSN validation failed';
            ssnControl.setErrors({ 'ssnDuplicate': true });
            ssnControl.markAsTouched();
            this.ssnValidationStatus = 'invalid';
            this.ssnErrorMessage = errorMessage;
            this.cdr.markForCheck();
            this.cdr.detectChanges();
          });
        }
      );
    }

    /**
     * Format SSN value according to the pattern: ###-##-####
     * @param value The SSN value to format (digits only)
     * @returns Formatted SSN string
     */
    private formatSSN(value: string): string {
      if (!value) {
        return '';
      }

      // Ensure we have only digits
      const digitsOnly = value.replace(/\D/g, '').substring(0, 9);

      if (digitsOnly.length <= 3) {
        return digitsOnly;
      } else if (digitsOnly.length <= 5) {
        return digitsOnly.slice(0, 3) + '-' + digitsOnly.slice(3);
      } else {
        return digitsOnly.slice(0, 3) + '-' + digitsOnly.slice(3, 5) + '-' + digitsOnly.slice(5, 9);
      }
    }

  /**
   * Handle validation state for prefilled form data
   * Ensures that prefilled values don't trigger false validation errors
   * and that reference data is properly matched with form values
   */
  private handlePrefillValidation(): void {
    // Check if form has been populated with values (prefill scenario)
    const ssnValue = this.confInfoForm.get('ssn')?.value;
    const dobValue = this.confInfoForm.get('dateOfBirth')?.value;
    const cityValue = this.confInfoForm.get('birthCityName')?.value;
    const countryValue = this.confInfoForm.get('birthCountry')?.value;
    const stateValue = this.confInfoForm.get('birthState')?.value;

    // If any field has a value, we're in prefill scenario
    if (ssnValue || dobValue || cityValue || countryValue || stateValue) {
      // Mark all fields as untouched and pristine to avoid false validation errors
      this.confInfoForm.get('ssn')?.markAsUntouched();
      this.confInfoForm.get('ssn')?.markAsPristine();
      this.confInfoForm.get('dateOfBirth')?.markAsUntouched();
      this.confInfoForm.get('dateOfBirth')?.markAsPristine();
      this.confInfoForm.get('birthCityName')?.markAsUntouched();
      this.confInfoForm.get('birthCityName')?.markAsPristine();
      this.confInfoForm.get('birthCountry')?.markAsUntouched();
      this.confInfoForm.get('birthCountry')?.markAsPristine();
      this.confInfoForm.get('birthState')?.markAsUntouched();
      this.confInfoForm.get('birthState')?.markAsPristine();

      // If SSN is prefilled, mark it as valid to avoid false validation errors
      if (ssnValue) {
        const ssnControl = this.confInfoForm.get('ssn');
        if (ssnControl) {
          ssnControl.setErrors(null);
          this.ssnValidationStatus = 'valid';
          this.previousSSNInput = ssnValue;
        }
      }

      // Trigger change detection to ensure UI updates
      this.cdr.markForCheck();
    }
  }

  /**
   * Clear SSN field and reset validation state
   * Called when user cancels the confirmation dialog
   */
  private clearSSN(): void {
    this.previousSSNInput = '';
    this.ssnValidationStatus = null;
    this.ssnErrorMessage = '';
    const ssnControl = this.confInfoForm.get('ssn');
    if (ssnControl) {
      ssnControl.reset();
      ssnControl.markAsUntouched();
      ssnControl.markAsPristine();
    }
    this.cdr.markForCheck();
  }
}
