import { TestBed } from '@angular/core/testing';
import { WorkerRoleAssignmentService, WorkerRole } from './worker-role-assignment.service';
import { HttpService } from 'src/app/services/http.service';
import { of } from 'rxjs';

describe('WorkerRoleAssignmentService', () => {
  let service: WorkerRoleAssignmentService;
  let mockHttpService: jasmine.SpyObj<HttpService>;

  beforeEach(() => {
    mockHttpService = jasmine.createSpyObj('HttpService', ['get', 'post', 'put', 'delete']);

    TestBed.configureTestingModule({
      providers: [
        WorkerRoleAssignmentService,
        { provide: HttpService, useValue: mockHttpService }
      ]
    });

    service = TestBed.inject(WorkerRoleAssignmentService);
  });

  describe('Service Creation', () => {
    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should have all required methods', () => {
      expect(service.getWorkerTelecommunications).toBeDefined();
      expect(service.getOrganizationReportRoles).toBeDefined();
      expect(service.getPrimaryWorkerOrganizationRoles).toBeDefined();
      expect(service.associateWorkerRole).toBeDefined();
      expect(service.disassociateWorkerRole).toBeDefined();
      expect(service.getWorkerOrganizations).toBeDefined();
      expect(service.getOrganizationRoles).toBeDefined();
    });
  });

  describe('getWorkerTelecommunications', () => {
    it('should call http.get with correct endpoint', () => {
      const workerId = 'worker-123';
      mockHttpService.get.and.returnValue(of({}));

      service.getWorkerTelecommunications(workerId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(`/workers/${workerId}/telecommunications`);
    });

    it('should return observable', (done) => {
      const workerId = 'worker-123';
      const mockResponse = { data: 'test' };
      mockHttpService.get.and.returnValue(of(mockResponse));

      service.getWorkerTelecommunications(workerId).subscribe(result => {
        expect(result).toEqual(mockResponse);
        done();
      });
    });

    it('should handle different worker IDs', () => {
      const workerIds = ['worker-1', 'worker-2', 'worker-abc123'];
      mockHttpService.get.and.returnValue(of({}));

      workerIds.forEach(id => {
        service.getWorkerTelecommunications(id).subscribe();
        expect(mockHttpService.get).toHaveBeenCalledWith(`/workers/${id}/telecommunications`);
      });
    });
  });

  describe('getOrganizationReportRoles', () => {
    it('should call http.get with correct endpoint and organizationId', () => {
      const organizationId = 'org-123';
      mockHttpService.get.and.returnValue(of([]));

      service.getOrganizationReportRoles(organizationId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(
        `/organization-report-roles?organizationId=${organizationId}`
      );
    });

    it('should return observable with roles', (done) => {
      const organizationId = 'org-123';
      const mockRoles = [
        { id: '1', value: 'ROLE1', description: 'Role 1' },
        { id: '2', value: 'ROLE2', description: 'Role 2' }
      ];
      mockHttpService.get.and.returnValue(of(mockRoles));

      service.getOrganizationReportRoles(organizationId).subscribe(result => {
        expect(result).toEqual(mockRoles);
        expect(result.length).toBe(2);
        done();
      });
    });

    it('should handle empty organization ID', () => {
      const organizationId = '';
      mockHttpService.get.and.returnValue(of([]));

      service.getOrganizationReportRoles(organizationId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(
        `/organization-report-roles?organizationId=`
      );
    });

    it('should handle special characters in organizationId', () => {
      const organizationId = 'org-123-abc';
      mockHttpService.get.and.returnValue(of([]));

      service.getOrganizationReportRoles(organizationId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(
        `/organization-report-roles?organizationId=${organizationId}`
      );
    });
  });

  describe('getPrimaryWorkerOrganizationRoles', () => {
    it('should call http.get with correct endpoint', () => {
      const workerId = 'worker-123';
      mockHttpService.get.and.returnValue(of({}));

      service.getPrimaryWorkerOrganizationRoles(workerId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(`/workers/${workerId}/organizations`);
    });

    it('should return observable', (done) => {
      const workerId = 'worker-123';
      const mockResponse = { organizations: [] };
      mockHttpService.get.and.returnValue(of(mockResponse));

      service.getPrimaryWorkerOrganizationRoles(workerId).subscribe(result => {
        expect(result).toEqual(mockResponse);
        done();
      });
    });
  });

  describe('associateWorkerRole', () => {
    it('should create new role when workerReportRoleId is not provided', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };

      mockHttpService.post.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      expect(mockHttpService.post).toHaveBeenCalled();
      const callArgs = mockHttpService.post.calls.mostRecent().args;
      expect(callArgs[0]).toContain(`/workers/${workerId}/orgRoles`);
    });

    it('should update existing role when workerReportRoleId is provided', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      expect(mockHttpService.put).toHaveBeenCalled();
      const callArgs = mockHttpService.put.calls.mostRecent().args;
      expect(callArgs[0]).toContain(`/workers/${workerId}/orgRoles/worker-role-123`);
    });

    it('should include lockControlNumber in URL when audit data is provided', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        },
        audit: {
          lockControlNumber: 'lock-123'
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.put.calls.mostRecent().args;
      expect(callArgs[0]).toContain('lockControlNumber=lock-123');
    });

    it('should set current date in lifecycle.beginDate for new role', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };

      mockHttpService.post.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.post.calls.mostRecent().args;
      const payload = callArgs[1];
      
      // Verify lifecycle has beginDate set to today
      expect(payload.lifecycle).toBeDefined();
      expect(payload.lifecycle.beginDate).toBeDefined();
      expect(payload.lifecycle.endDate).toBeNull();
    });

    it('should set current date in lifecycle.beginDate for update', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.put.calls.mostRecent().args;
      const payload = callArgs[1];
      
      expect(payload.lifecycle).toBeDefined();
      expect(payload.lifecycle.beginDate).toBeDefined();
      expect(payload.lifecycle.endDate).toBeNull();
    });

    it('should preserve organizationReportRole structure', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };

      mockHttpService.post.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.post.calls.mostRecent().args;
      const payload = callArgs[1];
      
      expect(payload.organizationReportRole).toBeDefined();
      expect(payload.organizationReportRole.organizationReportRoleId).toBe('org-role-123');
    });

    it('should handle role without audit data', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.put.calls.mostRecent().args;
      expect(callArgs[0]).not.toContain('lockControlNumber');
    });

    it('should return observable', (done) => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };
      const mockResponse = { id: 'new-role-123' };

      mockHttpService.post.and.returnValue(of(mockResponse));

      service.associateWorkerRole(workerId, workerRole).subscribe(result => {
        expect(result).toEqual(mockResponse);
        done();
      });
    });
  });

  describe('disassociateWorkerRole', () => {
    it('should call http.delete with correct endpoint', () => {
      const workerId = 'worker-123';
      const workerReportRoleId = 'worker-role-123';
      mockHttpService.delete.and.returnValue(of({}));

      service.disassociateWorkerRole(workerId, workerReportRoleId).subscribe();

      expect(mockHttpService.delete).toHaveBeenCalledWith(
        `/workers/${workerId}/orgRoles/${workerReportRoleId}`
      );
    });

    it('should return observable', (done) => {
      const workerId = 'worker-123';
      const workerReportRoleId = 'worker-role-123';
      const mockResponse = { success: true };
      mockHttpService.delete.and.returnValue(of(mockResponse));

      service.disassociateWorkerRole(workerId, workerReportRoleId).subscribe(result => {
        expect(result).toEqual(mockResponse);
        done();
      });
    });

    it('should handle different role IDs', () => {
      const workerId = 'worker-123';
      const roleIds = ['role-1', 'role-2', 'role-abc123'];
      mockHttpService.delete.and.returnValue(of({}));

      roleIds.forEach(roleId => {
        service.disassociateWorkerRole(workerId, roleId).subscribe();
        expect(mockHttpService.delete).toHaveBeenCalledWith(
          `/workers/${workerId}/orgRoles/${roleId}`
        );
      });
    });
  });

  describe('getWorkerOrganizations', () => {
    it('should call http.get with correct endpoint', () => {
      const workerId = 'worker-123';
      mockHttpService.get.and.returnValue(of([]));

      service.getWorkerOrganizations(workerId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(`/workers/${workerId}/organizations`);
    });

    it('should return observable with organizations', (done) => {
      const workerId = 'worker-123';
      const mockOrganizations = [
        { id: 'org-1', name: 'Organization 1' },
        { id: 'org-2', name: 'Organization 2' }
      ];
      mockHttpService.get.and.returnValue(of(mockOrganizations));

      service.getWorkerOrganizations(workerId).subscribe(result => {
        expect(result).toEqual(mockOrganizations);
        expect(result.length).toBe(2);
        done();
      });
    });
  });

  describe('getOrganizationRoles', () => {
    it('should call http.get with correct endpoint', () => {
      const organizationId = 'org-123';
      mockHttpService.get.and.returnValue(of([]));

      service.getOrganizationRoles(organizationId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith(`/organizations/${organizationId}/roles`);
    });

    it('should return observable with roles', (done) => {
      const organizationId = 'org-123';
      const mockRoles = [
        { id: '1', name: 'Role 1' },
        { id: '2', name: 'Role 2' }
      ];
      mockHttpService.get.and.returnValue(of(mockRoles));

      service.getOrganizationRoles(organizationId).subscribe(result => {
        expect(result).toEqual(mockRoles);
        done();
      });
    });

    it('should handle different organization IDs', () => {
      const organizationIds = ['org-1', 'org-2', 'org-abc123'];
      mockHttpService.get.and.returnValue(of([]));

      organizationIds.forEach(id => {
        service.getOrganizationRoles(id).subscribe();
        expect(mockHttpService.get).toHaveBeenCalledWith(`/organizations/${id}/roles`);
      });
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle empty workerId in getWorkerTelecommunications', () => {
      mockHttpService.get.and.returnValue(of({}));

      service.getWorkerTelecommunications('').subscribe();

      expect(mockHttpService.get).toHaveBeenCalledWith('/workers//telecommunications');
    });

    it('should handle null organizationReportRole in associateWorkerRole', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };

      mockHttpService.post.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      const callArgs = mockHttpService.post.calls.mostRecent().args;
      const payload = callArgs[1];
      
      expect(payload.organizationReportRole).toBeDefined();
    });

    it('should handle workerRole with all properties', () => {
      const workerId = 'worker-123';
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        },
        reportRole: {
          id: 'report-role-123',
          value: 'ROLE1',
          description: 'Role 1'
        },
        audit: {
          lockControlNumber: 'lock-123'
        },
        lifecycle: {
          beginDate: '2024-01-01',
          endDate: null
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole(workerId, workerRole).subscribe();

      expect(mockHttpService.put).toHaveBeenCalled();
    });

    it('should handle multiple consecutive calls', () => {
      const workerId = 'worker-123';
      const organizationId = 'org-123';
      
      mockHttpService.get.and.returnValue(of([]));
      mockHttpService.post.and.returnValue(of({}));

      service.getOrganizationReportRoles(organizationId).subscribe();
      service.getWorkerOrganizations(workerId).subscribe();
      service.getOrganizationRoles(organizationId).subscribe();

      expect(mockHttpService.get).toHaveBeenCalledTimes(3);
    });
  });

  describe('Interface Compliance', () => {
    it('should work with WorkerRole interface', () => {
      const workerRole: WorkerRole = {
        workerReportRoleId: 'worker-role-123',
        organizationReportRoleId: 'org-role-123',
        organizationReportRole: {
          organizationReportRoleId: 'org-role-123'
        },
        reportRole: {
          id: 'report-role-123',
          value: 'ROLE1',
          description: 'Role 1'
        },
        audit: {
          lockControlNumber: 'lock-123'
        },
        lifecycle: {
          beginDate: '2024-01-01',
          endDate: null
        }
      };

      mockHttpService.put.and.returnValue(of({}));

      service.associateWorkerRole('worker-123', workerRole).subscribe();

      expect(mockHttpService.put).toHaveBeenCalled();
    });

    it('should work with partial WorkerRole interface', () => {
      const workerRole: WorkerRole = {
        organizationReportRoleId: 'org-role-123'
      };

      mockHttpService.post.and.returnValue(of({}));

      service.associateWorkerRole('worker-123', workerRole).subscribe();

      expect(mockHttpService.post).toHaveBeenCalled();
    });
  });
});
