import { Component, OnInit, Input, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { WorkerRoleAssignmentService } from './worker-role-assignment.service';
import { WorkerManagementService } from '../../worker-management.service';

interface ReportRole {
  id: string;
  value: string;
  description: string;
  displayItem: string;
}

interface OrganizationWorkerRole {
  organizationReportRoleId?: string;
  workerReportRoleId?: string;
  reportRole: ReportRole;
  organizationReportRole?: {
    organizationReportRoleId: string;
  };
  audit?: any;
  lifecycle?: {
    beginDate: string;
    endDate: string | null;
  };
}

interface WorkerAssignment {
  primaryLocationIndicator: boolean;
  organization?: {
    organizationName: string;
  };
  workerOrganization?: {
    organization: {
      id?: string;
      businessAreaCode: string;
      shortName: string;
      artUnitNumber?: string;
      artUnit?: string;
       organizationName: string;
    };
  };
}

@Component({
  selector: 'app-worker-role-assignment',
  templateUrl: './worker-role-assignment.component.html',
  styleUrls: ['./worker-role-assignment.component.scss'],
})
export class WorkerRoleAssignmentComponent implements OnInit, OnChanges {
  @Input() workerId!: string;
  @Input() workerAssignments: WorkerAssignment[] = [];
  
  // Organization info
  organizationName: string = '';
  organizationAcronym: string = '';
  organizationId: string = '';
  artUnitNumber: string = ''; // Art Unit Number
  
  // Role lists
  organizationWorkerRoles: OrganizationWorkerRole[] = []; // Available roles
  workerRoles: OrganizationWorkerRole[] = []; // Assigned roles
  
  // Selected roles
  selectedAvailableRoles: OrganizationWorkerRole[] = [];
  selectedAssignedRoles: OrganizationWorkerRole[] = [];
  
  // UI state
  isLoading: boolean = false;
  errorMessage: string = '';
  
  constructor(
    private workerRoleService: WorkerRoleAssignmentService,
    private workerManagementService: WorkerManagementService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    if (this.workerId && this.workerAssignments && this.workerAssignments.length > 0) {
      this.extractOrganizationInfoFromAssignments();
      this.loadOrganizationRoles();
    }
    
    // CRITICAL FIX: Prevent accordion from scrolling page
    this.disableAccordionScroll();
  }

  /**
   * CRITICAL FIX: Disable scrollIntoView behavior on accordion elements
   */
  private disableAccordionScroll(): void {
    const originalScrollIntoView = (Element.prototype as any).scrollIntoView;
    
    (Element.prototype as any).scrollIntoView = function(options?: boolean | ScrollIntoViewOptions) {
      const isAccordionElement = (this as HTMLElement).closest('accordion-group') !== null;
      
      if (!isAccordionElement) {
        originalScrollIntoView.call(this, options);
      }
    };
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['workerAssignments']) {
      const currentValue = changes['workerAssignments'].currentValue;
      const previousValue = changes['workerAssignments'].previousValue;
      
      // Use the passed workerAssignments data instead of loading from API
      if (Array.isArray(currentValue) && currentValue.length > 0) {
        this.extractOrganizationInfoFromAssignments();
        this.loadOrganizationRoles();
      }
      this.cdr.markForCheck();
    }
  }

  /**
   * Extract organization name, acronym, and Art Unit Number from worker assignments passed as input
   */
  private extractOrganizationInfoFromAssignments(): void {
    if (this.workerAssignments && this.workerAssignments.length > 0) {
      // Find the primary assignment
      const primaryAssignment = this.workerAssignments.find(
        assignment => assignment.primaryLocationIndicator
      );
      if (primaryAssignment) {
        // Extract organization ID, acronym, and Art Unit Number
        if (primaryAssignment.workerOrganization?.organization) {
          const org = primaryAssignment.workerOrganization.organization;
          // Extract organization name from shortName if organizationName is not available
          this.organizationName = primaryAssignment.workerOrganization?.organization?.organizationName || org.shortName || '';
          this.organizationAcronym = `${org.businessAreaCode}/${org.shortName}`;
          this.organizationId = org.id || '';
          // Extract Art Unit Number (artUnitNumber or artUnit property)
          this.artUnitNumber = org.artUnitNumber || org.artUnit || '';
        }
      }
    }
  }

  /**
   * Load organization roles from the API
   */
  private loadOrganizationRoles(): void {
    if (!this.organizationId) {
      return;
    }
    
    this.workerRoleService.getOrganizationReportRoles(this.organizationId).subscribe({
      next: (response: any) => {
        // Handle different response structures
        let allRoles: OrganizationWorkerRole[] = [];
        
        if (response && response.results && Array.isArray(response.results)) {
          // Response format: { results: [...], meta: {...} }
          allRoles = this.buildDisplayOptions(response.results);
        } else if (response && response.organizationReportRoles && Array.isArray(response.organizationReportRoles)) {
          // Response format: { organization: { organizationReportRoles: [...] } }
          allRoles = this.buildDisplayOptions(response.organizationReportRoles);
        } else if (Array.isArray(response)) {
          // Direct array response
          allRoles = this.buildDisplayOptions(response);
        }
        
        if (allRoles.length > 0) {
          // Load worker's current roles
          this.loadWorkerRoles(allRoles);
        } else {
          this.organizationWorkerRoles = [];
          this.isLoading = false;
        }
      },
      error: (error: any) => {
        this.errorMessage = error.error?.message || 'Failed to load organization roles';
        this.isLoading = false;
      }
    });
  }

  /**
   * Load worker's currently assigned roles
   */
  private loadWorkerRoles(allRoles: OrganizationWorkerRole[]): void {
    this.workerManagementService.getWorkerOrganizationRoles(this.workerId).subscribe({
      next: (response: any) => {
        let workerRolesArray: any[] = [];
        
        // Handle different response structures
        if (response && response.results && Array.isArray(response.results)) {
          // Response format: { results: [...], meta: {...} }
          workerRolesArray = response.results;
        } else if (Array.isArray(response)) {
          // Direct array response
          workerRolesArray = response;
        }
        
        console.log('Worker Roles API Response:', workerRolesArray);
        console.log('Available Roles for Matching:', allRoles);
        
        // If no worker roles returned, set empty and use all available roles
        if (!workerRolesArray || workerRolesArray.length === 0) {
          console.log('No worker roles found');
          this.workerRoles = [];
          this.organizationWorkerRoles = allRoles;
          this.isLoading = false;
          return;
        }
        
        // Match worker roles with available roles to get full reportRole details
        const enrichedWorkerRoles = workerRolesArray.map((workerRole: any) => {
          console.log('Processing worker role:', workerRole);
          
          // Extract the ID from the worker role
          const workerRoleId = workerRole.organizationReportRole?.organizationReportRoleId ||
                              workerRole.reportRole?.id ||
                              workerRole.id;
          
          console.log('Worker Role ID to match:', workerRoleId);
          
          // Try to find matching role in allRoles by ID
          const matchedRole = allRoles.find(orgRole => {
            const orgRoleId = orgRole.reportRole?.id || (orgRole as any).id;
            console.log('Comparing:', workerRoleId, 'with', orgRoleId);
            return workerRoleId === orgRoleId;
          });
          
          console.log('Matched role:', matchedRole);
          
          // If we found a match, use its reportRole details
          if (matchedRole && matchedRole.reportRole) {
            return {
              ...workerRole,
              reportRole: matchedRole.reportRole
            };
          }
          
          // Otherwise return the role as-is (it might already have reportRole)
          return workerRole;
        });
        
        console.log('Enriched Worker Roles:', enrichedWorkerRoles);
        
        this.workerRoles = this.buildDisplayOptions(enrichedWorkerRoles);
        
        console.log('Final Worker Roles with Display Options:', this.workerRoles);
        
        // Filter out assigned roles from available roles
        this.organizationWorkerRoles = allRoles.filter(orgRole =>
          !this.workerRoles.some(workerRole =>
            workerRole.reportRole?.id === orgRole.reportRole?.id
          )
        );
        
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error loading worker roles:', error);
        // If no roles assigned yet, all organization roles are available
        this.organizationWorkerRoles = allRoles;
        this.workerRoles = [];
        this.isLoading = false;
      }
    });
  }

  /**
   * Build display options for roles (align role codes with descriptions)
   */
  private buildDisplayOptions(roles: any[]): OrganizationWorkerRole[] {
    const maxLength = 6;
    
    return roles.map(role => {
      // Handle different role data structures
      let reportRole = role.reportRole;
      
      // If role doesn't have reportRole property, it might be the role itself
      if (!reportRole && role.value && role.description) {
        reportRole = role;
      }
      
      // If still no reportRole, create a default structure
      if (!reportRole) {
        reportRole = {
          id: role.id || role.reportRoleId || '',
          value: role.value || role.code || '',
          description: role.description || '',
          displayItem: ''
        };
      }
      
      // Ensure reportRole has required properties
      if (!reportRole.value) {
        reportRole.value = reportRole.code || '';
      }
      if (!reportRole.description) {
        reportRole.description = '';
      }
      if (!reportRole.id) {
        reportRole.id = reportRole.reportRoleId || '';
      }
      
      // Build display item with aligned spacing
      let spaces = '';
      const codeLength = (reportRole.value || '').length;
      for (let i = codeLength; i <= maxLength; i++) {
        spaces += '\u00A0'; // Non-breaking space
      }
      
      reportRole.displayItem = `${reportRole.value}${spaces}  ${reportRole.description}`;
      
      // Ensure the role object has the proper structure
      const processedRole: OrganizationWorkerRole = {
        ...role,
        reportRole: reportRole
      };
      
      return processedRole;
    });
  }

  /**
   * Move selected roles between available and assigned lists
   */
  moveWorkerRole(direction: 'assign' | 'unassign'): void {
    if (direction === 'assign') {
      this.moveRoles(
        this.selectedAvailableRoles,
        this.organizationWorkerRoles,
        this.workerRoles
      );
      this.selectedAvailableRoles = [];
    } else {
      this.moveRoles(
        this.selectedAssignedRoles,
        this.workerRoles,
        this.organizationWorkerRoles
      );
      this.selectedAssignedRoles = [];
    }
  }

  /**
   * Move all roles between available and assigned lists
   */
  moveAllWorkerRoles(direction: 'assign' | 'unassign'): void {
    if (direction === 'assign') {
      this.workerRoles.push(...this.organizationWorkerRoles);
      this.organizationWorkerRoles = [];
      this.selectedAvailableRoles = [];
    } else {
      this.organizationWorkerRoles.push(...this.workerRoles);
      this.workerRoles = [];
      this.selectedAssignedRoles = [];
    }
  }

  /**
   * Helper method to move roles between lists
   */
  private moveRoles(
    selectedRoles: OrganizationWorkerRole[],
    fromList: OrganizationWorkerRole[],
    toList: OrganizationWorkerRole[]
  ): void {
    selectedRoles.forEach(role => {
      // Add to target list
      toList.push(role);
      
      // Remove from source list
      const index = fromList.findIndex(r => r.reportRole.id === role.reportRole.id);
      if (index !== -1) {
        fromList.splice(index, 1);
      }
    });
  }

  /**
   * Save worker role assignments
   */
  saveRoleAssignments(): void {
    if (this.workerRoles.length === 0) {
      return;
    }
    
    this.isLoading = true;
    const savePromises = this.workerRoles.map(role =>
      this.workerRoleService.associateWorkerRole(this.workerId, role).toPromise()
    );
    
    Promise.all(savePromises)
      .then(() => {
        this.isLoading = false;
        // Success handling
      })
      .catch((error) => {
        this.errorMessage = error.error?.message || 'Failed to save role assignments';
        this.isLoading = false;
      });
  }
}
