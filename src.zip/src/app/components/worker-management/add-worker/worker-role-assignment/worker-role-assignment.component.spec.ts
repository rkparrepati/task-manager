import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { WorkerRoleAssignmentComponent } from './worker-role-assignment.component';
import { WorkerRoleAssignmentService } from './worker-role-assignment.service';
import { WorkerManagementService } from '../../worker-management.service';
import { OrderByPipe } from '../../../../pipes/orderby.pipe';
import { of, throwError } from 'rxjs';

describe('WorkerRoleAssignmentComponent', () => {
  let component: WorkerRoleAssignmentComponent;
  let fixture: ComponentFixture<WorkerRoleAssignmentComponent>;
  let mockWorkerRoleService: jasmine.SpyObj<WorkerRoleAssignmentService>;
  let mockWorkerManagementService: jasmine.SpyObj<WorkerManagementService>;

  const mockRole1 = {
    reportRole: { id: '1', value: 'ROLE1', description: 'Role 1', displayItem: 'ROLE1  Role 1' }
  };

  const mockRole2 = {
    reportRole: { id: '2', value: 'ROLE2', description: 'Role 2', displayItem: 'ROLE2  Role 2' }
  };

  const mockRole3 = {
    reportRole: { id: '3', value: 'ROLE3', description: 'Role 3', displayItem: 'ROLE3  Role 3' }
  };

  const mockWorkerAssignment = {
    primaryLocationIndicator: true,
    organization: {
      organizationName: 'Test Organization'
    },
    workerOrganization: {
      organization: {
        id: 'org-123',
        businessAreaCode: 'BA',
        shortName: 'TEST'
      }
    }
  };

  beforeEach(async () => {
    mockWorkerRoleService = jasmine.createSpyObj('WorkerRoleAssignmentService', [
      'getOrganizationReportRoles',
      'associateWorkerRole'
    ]);
    mockWorkerManagementService = jasmine.createSpyObj('WorkerManagementService', [
      'getWorkerOrganizationRoles'
    ]);

    await TestBed.configureTestingModule({
      declarations: [WorkerRoleAssignmentComponent, OrderByPipe],
      imports: [FormsModule, BrowserAnimationsModule, AccordionModule.forRoot()],
      providers: [
        { provide: WorkerRoleAssignmentService, useValue: mockWorkerRoleService },
        { provide: WorkerManagementService, useValue: mockWorkerManagementService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(WorkerRoleAssignmentComponent);
    component = fixture.componentInstance;
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize with empty roles', () => {
      expect(component.organizationWorkerRoles).toEqual([]);
      expect(component.workerRoles).toEqual([]);
      expect(component.selectedAvailableRoles).toEqual([]);
      expect(component.selectedAssignedRoles).toEqual([]);
    });

    it('should initialize with empty organization info', () => {
      expect(component.organizationName).toBe('');
      expect(component.organizationAcronym).toBe('');
      expect(component.organizationId).toBe('');
    });

    it('should initialize with loading false and no error message', () => {
      expect(component.isLoading).toBe(false);
      expect(component.errorMessage).toBe('');
    });
  });

  describe('ngOnInit', () => {
    it('should not load roles if workerId is not provided', () => {
      component.workerId = '';
      component.workerAssignments = [mockWorkerAssignment];
      
      component.ngOnInit();
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).not.toHaveBeenCalled();
    });

    it('should not load roles if workerAssignments is empty', () => {
      component.workerId = 'worker-123';
      component.workerAssignments = [];
      
      component.ngOnInit();
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).not.toHaveBeenCalled();
    });

    it('should load roles if workerId and workerAssignments are provided', () => {
      component.workerId = 'worker-123';
      component.workerAssignments = [mockWorkerAssignment];
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(of([]));
      
      component.ngOnInit();
      
      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationAcronym).toBe('BA/TEST');
      expect(component.organizationId).toBe('org-123');
    });
  });

  describe('ngOnChanges', () => {
    it('should extract organization info when workerAssignments change', () => {
      const changes: any = {
        workerAssignments: {
          currentValue: [mockWorkerAssignment],
          previousValue: undefined,
          firstChange: true,
          isFirstChange: () => true
        }
      };
      
      component.workerId = 'worker-123';
      component.workerAssignments = [mockWorkerAssignment];
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(of([]));
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of([]));
      
      component.ngOnChanges(changes);
      
      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationAcronym).toBe('BA/TEST');
    });

    it('should not process changes if workerAssignments is empty', () => {
      const changes: any = {
        workerAssignments: {
          currentValue: [],
          previousValue: undefined,
          firstChange: true,
          isFirstChange: () => true
        }
      };
      
      component.ngOnChanges(changes);
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).not.toHaveBeenCalled();
    });

    it('should not process changes if workerAssignments is not an array', () => {
      const changes: any = {
        workerAssignments: {
          currentValue: null,
          previousValue: undefined,
          firstChange: true,
          isFirstChange: () => true
        }
      };
      
      component.ngOnChanges(changes);
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).not.toHaveBeenCalled();
    });
  });

  describe('Role Movement - Single Selection', () => {
    it('should move selected available roles to assigned', () => {
      component.organizationWorkerRoles = [mockRole1, mockRole2];
      component.workerRoles = [];
      component.selectedAvailableRoles = [mockRole1];

      component.moveWorkerRole('assign');

      expect(component.workerRoles).toContain(mockRole1);
      expect(component.organizationWorkerRoles).not.toContain(mockRole1);
      expect(component.selectedAvailableRoles).toEqual([]);
    });

    it('should move selected assigned roles to available', () => {
      component.organizationWorkerRoles = [];
      component.workerRoles = [mockRole1];
      component.selectedAssignedRoles = [mockRole1];

      component.moveWorkerRole('unassign');

      expect(component.organizationWorkerRoles).toContain(mockRole1);
      expect(component.workerRoles).not.toContain(mockRole1);
      expect(component.selectedAssignedRoles).toEqual([]);
    });

    it('should move multiple selected available roles to assigned', () => {
      component.organizationWorkerRoles = [mockRole1, mockRole2, mockRole3];
      component.workerRoles = [];
      component.selectedAvailableRoles = [mockRole1, mockRole2];

      component.moveWorkerRole('assign');

      expect(component.workerRoles.length).toBe(2);
      expect(component.organizationWorkerRoles.length).toBe(1);
      expect(component.organizationWorkerRoles).toContain(mockRole3);
    });

    it('should not move roles when no selection', () => {
      component.organizationWorkerRoles = [mockRole1];
      component.workerRoles = [];
      component.selectedAvailableRoles = [];

      component.moveWorkerRole('assign');

      expect(component.organizationWorkerRoles).toContain(mockRole1);
      expect(component.workerRoles.length).toBe(0);
    });
  });

  describe('Role Movement - All Roles', () => {
    it('should move all available roles to assigned', () => {
      component.organizationWorkerRoles = [mockRole1, mockRole2];
      component.workerRoles = [];

      component.moveAllWorkerRoles('assign');

      expect(component.workerRoles.length).toBe(2);
      expect(component.organizationWorkerRoles.length).toBe(0);
      expect(component.selectedAvailableRoles).toEqual([]);
    });

    it('should move all assigned roles to available', () => {
      component.organizationWorkerRoles = [];
      component.workerRoles = [mockRole1, mockRole2];

      component.moveAllWorkerRoles('unassign');

      expect(component.organizationWorkerRoles.length).toBe(2);
      expect(component.workerRoles.length).toBe(0);
      expect(component.selectedAssignedRoles).toEqual([]);
    });

    it('should handle moving all roles when lists are empty', () => {
      component.organizationWorkerRoles = [];
      component.workerRoles = [];

      component.moveAllWorkerRoles('assign');

      expect(component.workerRoles.length).toBe(0);
      expect(component.organizationWorkerRoles.length).toBe(0);
    });
  });

  describe('Role Display', () => {
    it('should highlight assigned roles when they exist', () => {
      component.workerRoles = [mockRole1];

      expect(component.workerRoles.length).toBeGreaterThan(0);
    });

    it('should not highlight assigned roles when empty', () => {
      component.workerRoles = [];

      expect(component.workerRoles.length).toBe(0);
    });

    it('should display correct organization name and acronym', () => {
      component.organizationName = 'Test Organization';
      component.organizationAcronym = 'TEST/ORG';

      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationAcronym).toBe('TEST/ORG');
    });
  });

  describe('Organization Info Extraction', () => {
    it('should extract organization info from primary assignment', () => {
      component.workerAssignments = [mockWorkerAssignment];
      
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationAcronym).toBe('BA/TEST');
      expect(component.organizationId).toBe('org-123');
    });

    it('should handle missing organization name', () => {
      const assignmentWithoutName = {
        primaryLocationIndicator: true,
        organization: {
          organizationName: undefined
        },
        workerOrganization: {
          organization: {
            id: 'org-123',
            businessAreaCode: 'BA',
            shortName: 'TEST'
          }
        }
      } as any;
      
      component.workerAssignments = [assignmentWithoutName];
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationName).toBe('');
      expect(component.organizationAcronym).toBe('BA/TEST');
    });

    it('should handle missing workerOrganization', () => {
      const assignmentWithoutWorkerOrg = {
        primaryLocationIndicator: true,
        organization: {
          organizationName: 'Test Organization'
        }
      } as any;
      
      component.workerAssignments = [assignmentWithoutWorkerOrg];
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationId).toBe('');
      expect(component.organizationAcronym).toBe('');
    });

    it('should find primary assignment when multiple assignments exist', () => {
      const secondaryAssignment = {
        primaryLocationIndicator: false,
        organization: {
          organizationName: 'Secondary Organization'
        },
        workerOrganization: {
          organization: {
            id: 'org-456',
            businessAreaCode: 'BA2',
            shortName: 'SEC'
          }
        }
      };
      
      component.workerAssignments = [secondaryAssignment, mockWorkerAssignment];
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationName).toBe('Test Organization');
      expect(component.organizationId).toBe('org-123');
    });

    it('should handle empty workerAssignments', () => {
      component.workerAssignments = [];
      
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationName).toBe('');
      expect(component.organizationAcronym).toBe('');
      expect(component.organizationId).toBe('');
    });
  });

  describe('Load Organization Roles', () => {
    it('should load organization roles successfully with results format', () => {
      component.organizationId = 'org-123';
      component.workerId = 'worker-123';
      
      const mockResponse = {
        results: [mockRole1, mockRole2]
      };
      
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(of(mockResponse));
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of([]));
      
      component['loadOrganizationRoles']();
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).toHaveBeenCalledWith('org-123');
    });

    it('should load organization roles with direct array response', () => {
      component.organizationId = 'org-123';
      component.workerId = 'worker-123';
      
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(of([mockRole1, mockRole2]));
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of([]));
      
      component['loadOrganizationRoles']();
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).toHaveBeenCalled();
    });

    it('should not load roles if organizationId is empty', () => {
      component.organizationId = '';
      
      component['loadOrganizationRoles']();
      
      expect(mockWorkerRoleService.getOrganizationReportRoles).not.toHaveBeenCalled();
    });

    it('should handle error when loading organization roles', () => {
      component.organizationId = 'org-123';
      
      const mockError = {
        error: { message: 'Failed to load roles' }
      };
      
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(throwError(() => mockError));
      
      component['loadOrganizationRoles']();
      
      expect(component.errorMessage).toBe('Failed to load roles');
      expect(component.isLoading).toBe(false);
    });

    it('should handle error with default message', () => {
      component.organizationId = 'org-123';
      
      mockWorkerRoleService.getOrganizationReportRoles.and.returnValue(throwError(() => ({})));
      
      component['loadOrganizationRoles']();
      
      expect(component.errorMessage).toBe('Failed to load organization roles');
    });
  });

  describe('Load Worker Roles', () => {
    it('should load worker roles successfully', () => {
      component.workerId = 'worker-123';
      
      const allRoles = [mockRole1, mockRole2, mockRole3];
      const workerRolesResponse = [mockRole1];
      
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of(workerRolesResponse));
      
      component['loadWorkerRoles'](allRoles);
      
      expect(component.workerRoles.length).toBe(1);
      expect(component.organizationWorkerRoles.length).toBe(2);
    });

    it('should filter out assigned roles from available roles', () => {
      component.workerId = 'worker-123';
      
      const allRoles = [mockRole1, mockRole2, mockRole3];
      const workerRolesResponse = [mockRole1, mockRole2];
      
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of(workerRolesResponse));
      
      component['loadWorkerRoles'](allRoles);
      
      expect(component.workerRoles.length).toBe(2);
      expect(component.organizationWorkerRoles.length).toBe(1);
      expect(component.organizationWorkerRoles[0].reportRole.id).toBe('3');
    });

    it('should handle error when loading worker roles', () => {
      component.workerId = 'worker-123';
      
      const allRoles = [mockRole1, mockRole2];
      
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(throwError(() => ({})));
      
      component['loadWorkerRoles'](allRoles);
      
      expect(component.organizationWorkerRoles).toEqual(allRoles);
      expect(component.workerRoles).toEqual([]);
      expect(component.isLoading).toBe(false);
    });

    it('should handle response with results format', () => {
      component.workerId = 'worker-123';
      
      const allRoles = [mockRole1, mockRole2];
      const workerRolesResponse = {
        results: [mockRole1]
      };
      
      mockWorkerManagementService.getWorkerOrganizationRoles.and.returnValue(of(workerRolesResponse));
      
      component['loadWorkerRoles'](allRoles);
      
      expect(component.workerRoles.length).toBe(1);
    });
  });

  describe('Build Display Options', () => {
    it('should build display options with proper formatting', () => {
      const roles = [
        { id: '1', value: 'R', description: 'Role 1' },
        { id: '2', value: 'ROLE2', description: 'Role 2' }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result.length).toBe(2);
      expect(result[0].reportRole.displayItem).toContain('R');
      expect(result[1].reportRole.displayItem).toContain('ROLE2');
    });

    it('should handle roles with reportRole property', () => {
      const roles = [
        {
          reportRole: {
            id: '1',
            value: 'ROLE1',
            description: 'Role 1'
          }
        }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result[0].reportRole.id).toBe('1');
      expect(result[0].reportRole.value).toBe('ROLE1');
    });

    it('should handle roles without reportRole property', () => {
      const roles = [
        {
          id: '1',
          value: 'ROLE1',
          description: 'Role 1'
        }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result[0].reportRole.value).toBe('ROLE1');
      expect(result[0].reportRole.description).toBe('Role 1');
    });

    it('should handle roles with missing properties', () => {
      const roles = [
        {
          id: '1'
        }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result[0].reportRole.id).toBe('1');
      expect(result[0].reportRole.value).toBe('');
      expect(result[0].reportRole.description).toBe('');
    });

    it('should use reportRoleId as fallback for id', () => {
      const roles = [
        {
          reportRoleId: 'role-id-123',
          value: 'ROLE1',
          description: 'Role 1'
        }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result[0].reportRole.id).toBe('role-id-123');
    });

    it('should use code as fallback for value', () => {
      const roles = [
        {
          id: '1',
          code: 'CODE1',
          description: 'Role 1'
        }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      expect(result[0].reportRole.value).toBe('CODE1');
    });

    it('should add proper spacing in displayItem', () => {
      const roles = [
        { id: '1', value: 'R', description: 'Role 1' },
        { id: '2', value: 'VERYLONGROLE', description: 'Role 2' }
      ];
      
      const result = component['buildDisplayOptions'](roles);
      
      // Both should have displayItem property with proper formatting
      expect(result[0].reportRole.displayItem).toBeDefined();
      expect(result[1].reportRole.displayItem).toBeDefined();
      expect(result[0].reportRole.displayItem).toContain('R');
      expect(result[1].reportRole.displayItem).toContain('VERYLONGROLE');
    });
  });

  describe('Save Role Assignments', () => {
    it('should not save if no worker roles are assigned', () => {
      component.workerId = 'worker-123';
      component.workerRoles = [];
      
      component.saveRoleAssignments();
      
      expect(mockWorkerRoleService.associateWorkerRole).not.toHaveBeenCalled();
    });

    it('should save worker role assignments successfully', (done) => {
      component.workerId = 'worker-123';
      component.workerRoles = [mockRole1, mockRole2];
      
      mockWorkerRoleService.associateWorkerRole.and.returnValue(of({}));
      
      component.saveRoleAssignments();
      
      setTimeout(() => {
        expect(mockWorkerRoleService.associateWorkerRole).toHaveBeenCalledTimes(2);
        expect(component.isLoading).toBe(false);
        done();
      }, 100);
    });

    it('should handle error when saving role assignments', (done) => {
      component.workerId = 'worker-123';
      component.workerRoles = [mockRole1];
      
      const mockError = {
        error: { message: 'Failed to save' }
      };
      
      mockWorkerRoleService.associateWorkerRole.and.returnValue(throwError(() => mockError));
      
      component.saveRoleAssignments();
      
      setTimeout(() => {
        expect(component.errorMessage).toBe('Failed to save');
        expect(component.isLoading).toBe(false);
        done();
      }, 100);
    });

    it('should handle error with default message when saving', (done) => {
      component.workerId = 'worker-123';
      component.workerRoles = [mockRole1];
      
      mockWorkerRoleService.associateWorkerRole.and.returnValue(throwError(() => ({})));
      
      component.saveRoleAssignments();
      
      setTimeout(() => {
        expect(component.errorMessage).toBe('Failed to save role assignments');
        done();
      }, 100);
    });

    it('should set isLoading to true when saving', () => {
      component.workerId = 'worker-123';
      component.workerRoles = [mockRole1];
      component.isLoading = false;
      
      mockWorkerRoleService.associateWorkerRole.and.returnValue(of({}));
      
      component.saveRoleAssignments();
      
      expect(component.isLoading).toBe(true);
    });
  });

  describe('Edge Cases', () => {
    it('should handle undefined workerAssignments', () => {
      component.workerId = 'worker-123';
      component.workerAssignments = undefined as any;
      
      expect(() => component.ngOnInit()).not.toThrow();
    });

    it('should handle role with missing reportRole.id', () => {
      const roleWithoutId = {
        reportRole: { value: 'ROLE1', description: 'Role 1' }
      };
      
      component.organizationWorkerRoles = [roleWithoutId as any];
      component.workerRoles = [];
      component.selectedAvailableRoles = [roleWithoutId as any];
      
      expect(() => component.moveWorkerRole('assign')).not.toThrow();
    });

    it('should handle empty organization acronym construction', () => {
      const assignmentWithoutOrgData = {
        primaryLocationIndicator: true,
        organization: {
          organizationName: 'Test Org'
        },
        workerOrganization: {
          organization: {
            businessAreaCode: '',
            shortName: ''
          }
        }
      };
      
      component.workerAssignments = [assignmentWithoutOrgData];
      component['extractOrganizationInfoFromAssignments']();
      
      expect(component.organizationAcronym).toBe('/');
    });
  });
});
