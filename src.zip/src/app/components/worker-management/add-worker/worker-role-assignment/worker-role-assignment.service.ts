import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/services/http.service';

export interface Organization {
  primaryOrganizationIndicator: boolean;
  organization: {
    id: string;
  };
}

export interface OrganizationRole {
  id: string;
  name: string;
  value: string;
  description: string;
}

export interface WorkerRole {
  workerReportRoleId?: string;
  organizationReportRoleId?: string;
  organizationReportRole?: {
    organizationReportRoleId: string;
  };
  reportRole?: {
    id: string;
    value: string;
    description: string;
  };
  audit?: {
    lockControlNumber: string;
  };
  lifecycle?: {
    beginDate: string;
    endDate: string | null;
  };
}

@Injectable({
  providedIn: 'root',
})
export class WorkerRoleAssignmentService {
  constructor(private http: HttpService) {}

  /**
   * Get worker telecommunications data
   * This endpoint returns telecommunications data which includes worker assignment information
   */
  getWorkerTelecommunications(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/telecommunications`);
  }

  /**
   * Get organization report roles by organization ID
   * This endpoint returns all available roles for an organization
   */
  getOrganizationReportRoles(organizationId: string): Observable<any> {
    return this.http.get(`/organization-report-roles?organizationId=${organizationId}`);
  }

  /**
   * Get worker's primary organization roles
   */
  getPrimaryWorkerOrganizationRoles(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/organizations`);
  }

  /**
   * Associate worker role (create or update)
   */
  associateWorkerRole(workerId: string, workerRole: WorkerRole): Observable<any> {
    const currentDate = new Date().toISOString().split('T')[0];
    
    if (workerRole.workerReportRoleId) {
      // Update existing role
      const updateObject = {
        workerReportRoleId: workerRole.workerReportRoleId,
        organizationReportRole: {
          organizationReportRoleId: workerRole.organizationReportRole?.organizationReportRoleId
        },
        lifecycle: {
          beginDate: currentDate,
          endDate: null
        }
      };
      
      const params = workerRole.audit?.lockControlNumber
        ? `?lockControlNumber=${workerRole.audit.lockControlNumber}`
        : '';
      
      return this.http.put(
        `/workers/${workerId}/orgRoles/${workerRole.workerReportRoleId}${params}`,
        updateObject
      );
    } else {
      // Create new role
      const createObject = {
        organizationReportRole: {
          organizationReportRoleId: workerRole.organizationReportRoleId
        },
        audit: workerRole.audit,
        lifecycle: {
          beginDate: currentDate,
          endDate: null
        }
      };
      
      return this.http.post(`/workers/${workerId}/orgRoles`, createObject);
    }
  }

  /**
   * Disassociate worker role (delete)
   */
  disassociateWorkerRole(workerId: string, workerReportRoleId: string): Observable<any> {
    return this.http.delete(`/workers/${workerId}/orgRoles/${workerReportRoleId}`);
  }

  /**
   * Get worker organizations
   */
  getWorkerOrganizations(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/organizations`);
  }

  /**
   * Get organization roles
   */
  getOrganizationRoles(organizationId: string): Observable<any> {
    return this.http.get(`/organizations/${organizationId}/roles`);
  }
}
