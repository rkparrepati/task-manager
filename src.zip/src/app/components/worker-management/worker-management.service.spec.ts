import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { WorkerManagementService } from './worker-management.service';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';

describe('WorkerManagementService', () => {
  let service: WorkerManagementService;
  let httpServiceSpy: jasmine.SpyObj<HttpService>;
  let appServiceSpy: jasmine.SpyObj<AppService>;

  beforeEach(() => {
    const httpSpy = jasmine.createSpyObj('HttpService', [
      'get',
      'post',
      'put',
      'delete',
      'getExcelReport',
      'postForCsv',
    ]);
    const appSpy = jasmine.createSpyObj('AppService', ['mergeQueryParams']);

    TestBed.configureTestingModule({
      providers: [
        WorkerManagementService,
        { provide: HttpService, useValue: httpSpy },
        { provide: AppService, useValue: appSpy },
      ],
    });

    service = TestBed.inject(WorkerManagementService);
    httpServiceSpy = TestBed.inject(HttpService) as jasmine.SpyObj<HttpService>;
    appServiceSpy = TestBed.inject(AppService) as jasmine.SpyObj<AppService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // ─── BehaviorSubject Observables ───────────────────────────────────────────

  describe('Observable properties', () => {
    it('should expose hideMessage$ observable with initial value true', (done) => {
      service.hideMessage$.subscribe((val) => {
        expect(val).toBeTrue();
        done();
      });
    });

    it('should expose returnMessage$ observable with initial empty string', (done) => {
      service.returnMessage$.subscribe((val) => {
        expect(val).toBe('');
        done();
      });
    });

    it('should expose returnMessagesArray$ observable with initial empty array', (done) => {
      service.returnMessagesArray$.subscribe((val) => {
        expect(val).toEqual([]);
        done();
      });
    });

    it('should expose returnCode$ observable with initial empty string', (done) => {
      service.returnCode$.subscribe((val) => {
        expect(val).toBe('');
        done();
      });
    });
  });

  // ─── Message Management Methods ────────────────────────────────────────────

  describe('updateHideMessage', () => {
    it('should update hideMessage$ to false', (done) => {
      service.updateHideMessage(false);
      service.hideMessage$.subscribe((val) => {
        expect(val).toBeFalse();
        done();
      });
    });

    it('should update hideMessage$ to true', (done) => {
      service.updateHideMessage(false);
      service.updateHideMessage(true);
      service.hideMessage$.subscribe((val) => {
        expect(val).toBeTrue();
        done();
      });
    });
  });

  describe('updateReturnMessage', () => {
    it('should update returnMessage$ with the given message', (done) => {
      spyOn(service, 'scrolltoTop');
      service.updateReturnMessage('Test message');
      service.returnMessage$.subscribe((val) => {
        expect(val).toBe('Test message');
        done();
      });
    });

    it('should call scrolltoTop when updating return message', () => {
      spyOn(service, 'scrolltoTop');
      service.updateReturnMessage('Test');
      expect(service.scrolltoTop).toHaveBeenCalled();
    });
  });

  describe('updateReturnMessageArray', () => {
    it('should update returnMessagesArray$ with the given array', (done) => {
      const messages = ['Error 1', 'Error 2'];
      service.updateReturnMessageArray(messages);
      service.returnMessagesArray$.subscribe((val) => {
        expect(val).toEqual(messages);
        done();
      });
    });
  });

  describe('updateReturnCode', () => {
    it('should update returnCode$ with a numeric code', (done) => {
      service.updateReturnCode(200);
      service.returnCode$.subscribe((val) => {
        expect(val).toBe(200);
        done();
      });
    });

    it('should update returnCode$ with a string code', (done) => {
      service.updateReturnCode('404');
      service.returnCode$.subscribe((val) => {
        expect(val).toBe('404');
        done();
      });
    });
  });

  describe('scrolltoTop', () => {
    it('should call window.scrollTo with top:0 and smooth behavior', () => {
      const scrollSpy = spyOn(window, 'scrollTo');
      service.scrolltoTop();
      expect(scrollSpy).toHaveBeenCalled();
      const callArgs = scrollSpy.calls.mostRecent().args[0] as ScrollToOptions;
      expect(callArgs.top).toBe(0);
      expect(callArgs.behavior).toBe('smooth');
    });
  });

  describe('showSuccessMessage', () => {
    it('should set code to 200, update message, and show banner', (done) => {
      spyOn(service, 'scrolltoTop');
      service.showSuccessMessage('Success!');
      service.returnCode$.subscribe((code) => {
        expect(code).toBe(200);
      });
      service.returnMessage$.subscribe((msg) => {
        expect(msg).toBe('Success!');
      });
      service.hideMessage$.subscribe((hidden) => {
        expect(hidden).toBeFalse();
        done();
      });
    });
  });

  describe('showErrorMessage', () => {
    it('should set default code 500 and update message', (done) => {
      spyOn(service, 'scrolltoTop');
      service.showErrorMessage('Something went wrong');
      service.returnCode$.subscribe((code) => {
        expect(code).toBe(500);
      });
      service.returnMessage$.subscribe((msg) => {
        expect(msg).toBe('Something went wrong');
      });
      service.hideMessage$.subscribe((hidden) => {
        expect(hidden).toBeFalse();
        done();
      });
    });

    it('should use provided error code', (done) => {
      spyOn(service, 'scrolltoTop');
      service.showErrorMessage('Not found', 404);
      service.returnCode$.subscribe((code) => {
        expect(code).toBe(404);
        done();
      });
    });
  });

  describe('showValidationErrors', () => {
    it('should set code 700, update message and messages array, and show banner', (done) => {
      spyOn(service, 'scrolltoTop');
      const errors = ['Field A is required', 'Field B is invalid'];
      service.showValidationErrors(errors);
      service.returnCode$.subscribe((code) => {
        expect(code).toBe(700);
      });
      service.returnMessage$.subscribe((msg) => {
        expect(msg).toBe('Invalid input was detected. Please correct required/invalid fields.');
      });
      service.returnMessagesArray$.subscribe((arr) => {
        expect(arr).toEqual(errors);
      });
      service.hideMessage$.subscribe((hidden) => {
        expect(hidden).toBeFalse();
        done();
      });
    });

    it('should use provided code for validation errors', (done) => {
      spyOn(service, 'scrolltoTop');
      service.showValidationErrors(['Error'], 422);
      service.returnCode$.subscribe((code) => {
        expect(code).toBe(422);
        done();
      });
    });
  });

  describe('hideMessages', () => {
    it('should hide banner and clear messages', (done) => {
      spyOn(service, 'scrolltoTop');
      service.showSuccessMessage('Test');
      service.hideMessages();
      service.hideMessage$.subscribe((hidden) => {
        expect(hidden).toBeTrue();
      });
      service.returnMessage$.subscribe((msg) => {
        expect(msg).toBe('');
      });
      service.returnMessagesArray$.subscribe((arr) => {
        expect(arr).toEqual([]);
        done();
      });
    });
  });

  // ─── searchCriteriaMap ─────────────────────────────────────────────────────

  describe('searchCriteriaMap', () => {
    it('should have the correct mapping entries', () => {
      expect(service.searchCriteriaMap['workerNumber']).toBe('workerNumberPrefix');
      expect(service.searchCriteriaMap['familyName']).toBe('familyName');
      expect(service.searchCriteriaMap['givenName']).toBe('givenName');
      expect(service.searchCriteriaMap['preferredFirstName']).toBe('preferredFirstName');
      expect(service.searchCriteriaMap['mulWorkerNumber']).toBe('mulWorkerNumber');
      expect(service.searchCriteriaMap['dateOfBirth']).toBe('dateOfBirth');
      expect(service.searchCriteriaMap['contractorSSN']).toBe('contractorSSN');
      expect(service.searchCriteriaMap['classCode']).toBe('classCode');
      expect(service.searchCriteriaMap['firmName']).toBe('firmName');
      expect(service.searchCriteriaMap['firmAdministrator']).toBe('firmAdministrator');
      expect(service.searchCriteriaMap['businessAreaCode']).toBe('businessAreaCode');
      expect(service.searchCriteriaMap['loginWorkerNumber']).toBe('loginWorkerNumber');
      expect(service.searchCriteriaMap['workerAssociatedFirms']).toBe('workerAssociatedFirms');
    });
  });

  // ─── getSearchCriteriaKey ──────────────────────────────────────────────────

  describe('getSearchCriteriaKey', () => {
    it('should return mapped key for known criteria', () => {
      expect(service.getSearchCriteriaKey('workerNumber')).toBe('workerNumberPrefix');
    });

    it('should return the original criteria if not in map', () => {
      expect(service.getSearchCriteriaKey('unknownCriteria')).toBe('unknownCriteria');
    });

    it('should return mapped key for familyName', () => {
      expect(service.getSearchCriteriaKey('familyName')).toBe('familyName');
    });
  });

  // ─── getSearchUrl ──────────────────────────────────────────────────────────

  describe('getSearchUrl', () => {
    it('should build correct search URL segment', () => {
      const result = service.getSearchUrl('workerNumber', '12345');
      expect(result).toBe('&workerNumberPrefix=12345');
    });

    it('should use original criteria if not in map', () => {
      const result = service.getSearchUrl('customField', 'value');
      expect(result).toBe('&customField=value');
    });
  });

  // ─── selectedWorkerDetails ─────────────────────────────────────────────────

  describe('setSelectedWorkerDetails / getWorkerDetails', () => {
    it('should store and retrieve worker details', () => {
      const details = { id: 1, name: 'John Doe' };
      service.setSelectedWorkerDetails(details);
      expect(service.getWorkerDetails()).toEqual(details);
    });

    it('should return undefined when no details set', () => {
      expect(service.getWorkerDetails()).toBeUndefined();
    });
  });

  // ─── validateContractorId ──────────────────────────────────────────────────

  describe('validateContractorId', () => {
    it('should call httpservice.get with correct URL', () => {
      appServiceSpy.mergeQueryParams.and.returnValue(
        'isContractor=true&includeInactive=true&dateOfBirth=1990-01-01&contractorSSN=123456789'
      );
      httpServiceSpy.get.and.returnValue(of({}));
      service.validateContractorId('1990-01-01', '123456789');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?isContractor=true&includeInactive=true&dateOfBirth=1990-01-01&contractorSSN=123456789'
      );
    });
  });

  // ─── getWorkers ────────────────────────────────────────────────────────────

  describe('getWorkers', () => {
    it('should call httpservice.get with correct URL for non-contractor', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkers(false, 'Smith', 'familyName');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?includeInactive=false&familyName=Smith&limit=10&skip=0&sortColumn=familyName&sortOrder=asc'
      );
    });

    it('should append isContractor=true when isContractor is true', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkers(true, 'Smith', 'familyName', true, 20, 5, 'givenName', 'desc');
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('&isContractor=true');
    });

    it('should use workerNumberPrefix for workerNumber criteria', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkers(false, '12345', 'workerNumber');
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('workerNumberPrefix=12345');
    });

    it('should return an Observable', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      const result = service.getWorkers(false, 'test', 'familyName');
      expect(result).toBeDefined();
    });
  });

  // ─── getWorkersForRoles ────────────────────────────────────────────────────

  describe('getWorkersForRoles', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkersForRoles(false, 'Smith', 'familyName', 'familyName', 'asc');
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('/workers?includeInactive=false');
      expect(callArg).toContain('familyName=Smith');
    });

    it('should append isContractor=true when isContractor is true', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkersForRoles(false, 'Smith', 'familyName', 'familyName', 'asc', true);
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('&isContractor=true');
    });
  });

  // ─── getWorkersWithAdvanceSearch ───────────────────────────────────────────

  describe('getWorkersWithAdvanceSearch', () => {
    it('should call httpservice.get with base URL when no queryParameters', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkersWithAdvanceSearch(false, '');
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toBe(
        '/workers?includeInactive=false&limit=10&skip=0&sortColumn=familyName&sortOrder=asc'
      );
    });

    it('should include queryParameters in URL when provided', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkersWithAdvanceSearch(true, '&familyName=Smith', 20, 10);
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('&familyName=Smith');
      expect(callArg).toContain('includeInactive=true');
    });
  });

  // ─── getWorkerAssignments ──────────────────────────────────────────────────

  describe('getWorkerAssignments', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerAssignments(123);
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/123/assignments');
    });
  });

  // ─── workerExcelReport ─────────────────────────────────────────────────────

  describe('workerExcelReport', () => {
    it('should call http.getExcelReport with correct URL', () => {
      httpServiceSpy.getExcelReport.and.returnValue(of(new Blob()));
      service.workerExcelReport(false, '&familyName=Smith', 100);
      expect(httpServiceSpy.getExcelReport).toHaveBeenCalledWith(
        '/workers/workerExcelReport?includeInactive=false&familyName=Smith&limit=100&sortColumn=lastName&sortOrder=asc'
      );
    });
  });

  // ─── getParameters ─────────────────────────────────────────────────────────

  describe('getParameters', () => {
    it('should call httpservice.get with /parameters', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getParameters();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/parameters');
    });
  });

  // ─── canViewSecureData ─────────────────────────────────────────────────────

  describe('canViewSecureData', () => {
    it('should return true for employee with InfraAdmin role', () => {
      expect(service.canViewSecureData(['InfraAdmin'], 'E')).toBeTrue();
    });

    it('should return true for employee with InfraHRAdmin role', () => {
      expect(service.canViewSecureData(['InfraHRAdmin'], 'E')).toBeTrue();
    });

    it('should return true for any employment type with InfraHRViewer role', () => {
      expect(service.canViewSecureData(['InfraHRViewer'], 'C')).toBeTrue();
      expect(service.canViewSecureData(['InfraHRViewer'], 'E')).toBeTrue();
    });

    it('should return true for contractor with InfraAdmin role', () => {
      expect(service.canViewSecureData(['InfraAdmin'], 'C')).toBeTrue();
    });

    it('should return true for contractor with InfraHRAdmin role', () => {
      expect(service.canViewSecureData(['InfraHRAdmin'], 'C')).toBeTrue();
    });

    it('should return true for contractor with InfraContractorAdmin role', () => {
      expect(service.canViewSecureData(['InfraContractorAdmin'], 'C')).toBeTrue();
    });

    it('should return true for contractor with InfraOfficeCoordinator role', () => {
      expect(service.canViewSecureData(['InfraOfficeCoordinator'], 'C')).toBeTrue();
    });

    it('should return false for employee without required roles', () => {
      expect(service.canViewSecureData(['SomeOtherRole'], 'E')).toBeFalse();
    });

    it('should return false for contractor without required roles', () => {
      expect(service.canViewSecureData(['SomeOtherRole'], 'C')).toBeFalse();
    });

    it('should return false for unknown employment type', () => {
      expect(service.canViewSecureData(['InfraAdmin'], 'X')).toBeFalse();
    });
  });

  // ─── Contractor Operations ─────────────────────────────────────────────────

  describe('getContractorStatusValidResponse', () => {
    it('should call httpservice.post with /createValidContractors', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      service.getContractorStatusValidResponse({ data: 'test' });
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/createValidContractors', { data: 'test' });
    });
  });

  describe('getContractorCreationResponse', () => {
    it('should call httpservice.post with /createMultipleContractors', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      service.getContractorCreationResponse({ data: 'test' });
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/createMultipleContractors', { data: 'test' });
    });
  });

  describe('getContractorValidCreationResponse', () => {
    it('should call httpservice.post with /createValidMultipleContractors', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      service.getContractorValidCreationResponse({ data: 'test' });
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/createValidMultipleContractors', { data: 'test' });
    });
  });

  describe('getContractorsByFirmSearch', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorsByFirmSearch('Acme Corp');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmName=Acme Corp'
      );
    });
  });

  describe('moveContractorsList', () => {
    it('should call httpservice.put with /workers/firm/association', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const payload = { firmId: '1', workerIds: [1, 2] };
      service.moveContractorsList(payload);
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/firm/association', payload);
    });
  });

  describe('orgRoles', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.orgRoles('org123');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/org123/orgRoles');
    });
  });

  describe('getWorkerByWorkerNumber', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerByWorkerNumber('W12345');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers?workerNumber=W12345');
    });
  });

  describe('getReportData', () => {
    it('should call httpservice.get with correct URL', () => {
      appServiceSpy.mergeQueryParams.and.returnValue('startDate=2024-01-01&endDate=2024-12-31');
      httpServiceSpy.get.and.returnValue(of({}));
      service.getReportData('statusReport', { startDate: '2024-01-01', endDate: '2024-12-31' });
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers/statusReport?startDate=2024-01-01&endDate=2024-12-31'
      );
    });
  });

  // ─── Worker CRUD Operations ────────────────────────────────────────────────

  describe('getWorkerById', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerById('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1');
    });
  });

  describe('getWorkerByWorkerNumberDetailed', () => {
    it('should call httpservice.get with includeInactive=false by default', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerByWorkerNumberDetailed('W001');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?workerNumber=W001&includeInactive=false'
      );
    });

    it('should call httpservice.get with includeInactive=true when specified', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerByWorkerNumberDetailed('W001', true);
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?workerNumber=W001&includeInactive=true'
      );
    });
  });

  describe('createWorker', () => {
    it('should call httpservice.post with /hrWorkers', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const workerData = { firstName: 'John', lastName: 'Doe' };
      service.createWorker(workerData);
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/hrWorkers', workerData);
    });
  });

  describe('updateWorker', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const workerData = { firstName: 'John' };
      service.updateWorker('worker-1', workerData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/worker-1', workerData);
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const workerData = { firstName: 'John' };
      service.updateWorker('worker-1', workerData, 'lcn-123');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1?lockControlNumber=lcn-123',
        workerData
      );
    });
  });

  describe('deleteWorker', () => {
    it('should call httpservice.delete with correct URL', () => {
      httpServiceSpy.delete.and.returnValue(of({}));
      service.deleteWorker('worker-1');
      expect(httpServiceSpy.delete).toHaveBeenCalledWith('/workers/worker-1');
    });
  });

  // ─── Worker Secure Data Operations ────────────────────────────────────────

  describe('getWorkerSecureData', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerSecureData('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/secure-workers/worker-1');
    });
  });

  describe('updateWorkerSecureData', () => {
    it('should call httpservice.put with correct URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const secureData = { ssn: '123-45-6789' };
      service.updateWorkerSecureData('worker-1', secureData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/worker-1/secure', secureData);
    });
  });

  describe('saveWorkerSecureInformation', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const secureData = { ssn: '123-45-6789' };
      service.saveWorkerSecureInformation('worker-1', secureData, {});
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/secure-workers/worker-1', secureData);
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const secureData = { ssn: '123-45-6789' };
      service.saveWorkerSecureInformation('worker-1', secureData, { lockControlNumber: 'lcn-456' });
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/secure-workers/worker-1?lockControlNumber=lcn-456',
        secureData
      );
    });
  });

  // ─── SSN Validation ────────────────────────────────────────────────────────

  describe('validateSocialSecurity', () => {
    it('should call httpservice.post with correct endpoint and payload', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      service.validateSocialSecurity('123456789');
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/secure-workers', { socialSecurityNumber: '123456789' });
    });
  });

  // ─── Worker Accession Operations ───────────────────────────────────────────

  describe('getWorkerAccession', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerAccession('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/worker-accession?workerID=worker-1');
    });
  });

  describe('addWorkerAccession', () => {
    it('should call httpservice.post without lockControlNumber', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.addWorkerAccession(accessionData, {});
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/worker-accession', accessionData);
    });

    it('should call httpservice.post with lockControlNumber in URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.addWorkerAccession(accessionData, { lockControlNumber: 'lcn-789' });
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/worker-accession?lockControlNumber=lcn-789',
        accessionData
      );
    });
  });

  describe('updateWorkerAccession', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.updateWorkerAccession(accessionData, {});
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/worker-accession', accessionData);
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.updateWorkerAccession(accessionData, { lockControlNumber: 'lcn-789' });
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/worker-accession?lockControlNumber=lcn-789',
        accessionData
      );
    });
  });

  describe('updateWorkerAccessionLegacy', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.updateWorkerAccessionLegacy('worker-1', accessionData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/accession',
        accessionData
      );
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const accessionData = { date: '2024-01-01' };
      service.updateWorkerAccessionLegacy('worker-1', accessionData, 'lcn-abc');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/accession?lockControlNumber=lcn-abc',
        accessionData
      );
    });
  });

  describe('generateAccessionReport', () => {
    it('should call http.getExcelReport with correct URL', () => {
      httpServiceSpy.getExcelReport.and.returnValue(of(new Blob()));
      service.generateAccessionReport(['w1', 'w2', 'w3']);
      expect(httpServiceSpy.getExcelReport).toHaveBeenCalledWith(
        '/workers/accessionReport?workerIds=w1,w2,w3'
      );
    });
  });

  // ─── Worker Assignment Operations ──────────────────────────────────────────

  describe('createWorkerAssignment', () => {
    it('should call httpservice.post with correct URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const assignmentData = { role: 'Developer' };
      service.createWorkerAssignment('worker-1', assignmentData);
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/workers/worker-1/assignments',
        assignmentData
      );
    });
  });

  describe('updateWorkerAssignment', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const assignmentData = { role: 'Developer' };
      service.updateWorkerAssignment('worker-1', 'assign-1', assignmentData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/assignments/assign-1',
        assignmentData
      );
    });

    it('should call httpservice.put with encoded lockControlNumber as audit param', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const assignmentData = { role: 'Developer' };
      const lcn = '{"lockControlNumber":1}';
      service.updateWorkerAssignment('worker-1', 'assign-1', assignmentData, lcn);
      const callArg = httpServiceSpy.put.calls.mostRecent().args[0];
      expect(callArg).toContain('?audit=');
      expect(callArg).toContain(encodeURIComponent(lcn));
    });
  });

  describe('deleteWorkerAssignment', () => {
    it('should call httpservice.delete with correct URL', () => {
      httpServiceSpy.delete.and.returnValue(of({}));
      service.deleteWorkerAssignment('worker-1', 'assign-1');
      expect(httpServiceSpy.delete).toHaveBeenCalledWith(
        '/workers/worker-1/assignments/assign-1'
      );
    });
  });

  // ─── Worker Organization Operations ───────────────────────────────────────

  describe('getWorkerOrganizations', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerOrganizations('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/organizations');
    });
  });

  describe('createWorkerOrganization', () => {
    it('should call httpservice.post with correct URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const orgData = { orgCode: 'ORG001' };
      service.createWorkerOrganization('worker-1', orgData);
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/workers/worker-1/organizations',
        orgData
      );
    });
  });

  describe('updateWorkerOrganization', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const orgData = { orgCode: 'ORG001' };
      service.updateWorkerOrganization('worker-1', 'org-1', orgData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/organizations/org-1',
        orgData
      );
    });

    it('should call httpservice.put with encoded lockControlNumber as audit param', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const orgData = { orgCode: 'ORG001' };
      const lcn = '{"lockControlNumber":2}';
      service.updateWorkerOrganization('worker-1', 'org-1', orgData, lcn);
      const callArg = httpServiceSpy.put.calls.mostRecent().args[0];
      expect(callArg).toContain('?audit=');
      expect(callArg).toContain(encodeURIComponent(lcn));
    });
  });

  // ─── Worker Telecommunication Operations ──────────────────────────────────

  describe('getWorkerTelecommunications', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerTelecommunications('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/telecommunications');
    });
  });

  describe('createWorkerTelecommunication', () => {
    it('should call httpservice.post with correct URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const telecomData = { type: 'phone', value: '555-1234' };
      service.createWorkerTelecommunication('worker-1', telecomData);
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/workers/worker-1/telecommunications',
        telecomData
      );
    });
  });

  describe('createBulkWorkerTelecommunications', () => {
    it('should call httpservice.post with correct URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const telecomList = [{ type: 'phone' }, { type: 'email' }];
      service.createBulkWorkerTelecommunications('worker-1', telecomList);
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/workers/worker-1/assign-bulk-telecommunications',
        telecomList
      );
    });
  });

  describe('updateWorkerTelecommunication', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const telecomData = { value: '555-9999' };
      service.updateWorkerTelecommunication('worker-1', 'telecom-1', telecomData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/telecommunications/telecom-1',
        telecomData
      );
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const telecomData = { value: '555-9999' };
      service.updateWorkerTelecommunication('worker-1', 'telecom-1', telecomData, 'lcn-xyz');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/telecommunications/telecom-1?lockControlNumber=lcn-xyz',
        telecomData
      );
    });
  });

  describe('deleteWorkerTelecommunication', () => {
    it('should call httpservice.delete with correct URL', () => {
      httpServiceSpy.delete.and.returnValue(of({}));
      service.deleteWorkerTelecommunication('worker-1', 'telecom-1');
      expect(httpServiceSpy.delete).toHaveBeenCalledWith(
        '/workers/worker-1/telecommunications/telecom-1'
      );
    });
  });

  // ─── Worker Organization Role Operations ──────────────────────────────────

  describe('getWorkerOrganizationRoles', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerOrganizationRoles('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/orgRoles');
    });
  });

  describe('createWorkerOrganizationRole', () => {
    it('should call httpservice.post with correct URL', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const roleData = { roleCode: 'ADMIN' };
      service.createWorkerOrganizationRole('worker-1', roleData);
      expect(httpServiceSpy.post).toHaveBeenCalledWith('/workers/worker-1/orgRoles', roleData);
    });
  });

  describe('updateWorkerOrganizationRole', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const roleData = { roleCode: 'ADMIN' };
      service.updateWorkerOrganizationRole('worker-1', 'role-1', roleData);
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/orgRoles/role-1',
        roleData
      );
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const roleData = { roleCode: 'ADMIN' };
      service.updateWorkerOrganizationRole('worker-1', 'role-1', roleData, 'lcn-role');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/orgRoles/role-1?lockControlNumber=lcn-role',
        roleData
      );
    });
  });

  describe('deleteWorkerOrganizationRole', () => {
    it('should call httpservice.delete with correct URL', () => {
      httpServiceSpy.delete.and.returnValue(of({}));
      service.deleteWorkerOrganizationRole('worker-1', 'role-1');
      expect(httpServiceSpy.delete).toHaveBeenCalledWith('/workers/worker-1/orgRoles/role-1');
    });
  });

  // ─── Worker Status Operations ──────────────────────────────────────────────

  describe('activateWorker', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      service.activateWorker('worker-1');
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/worker-1/activate', {});
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      service.activateWorker('worker-1', 'lcn-act');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/activate?lockControlNumber=lcn-act',
        {}
      );
    });
  });

  describe('inactivateWorker', () => {
    it('should call httpservice.put without lockControlNumber', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      service.inactivateWorker('worker-1');
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/worker-1/inactivate', {});
    });

    it('should call httpservice.put with lockControlNumber in URL', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      service.inactivateWorker('worker-1', 'lcn-inact');
      expect(httpServiceSpy.put).toHaveBeenCalledWith(
        '/workers/worker-1/inactivate?lockControlNumber=lcn-inact',
        {}
      );
    });
  });

  // ─── Phone Number Details ──────────────────────────────────────────────────

  describe('getPhoneNumberDetail', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getPhoneNumberDetail('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/telecommunications');
    });
  });

  // ─── Advanced Search with SSN ──────────────────────────────────────────────

  describe('getWorkerListWithSSN', () => {
    it('should call httpservice.get with correct URL without isContractor', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerListWithSSN('123-45-6789', false, false, 10, 0);
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/secureWorkers?socialSecurityNumber=123-45-6789&includeInactive=false&limit=10&skip=0&sortColumn=lastName&sortOrder=asc'
      );
    });

    it('should append isContractor=true when isContractor is true', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerListWithSSN('123-45-6789', true, true, 20, 5);
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('&isContractor=true');
    });
  });

  // ─── Contractor Firm Operations ────────────────────────────────────────────

  describe('getContractorsByFirmAdministrator', () => {
    it('should call httpservice.get without workerNumber', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorsByFirmAdministrator('admin@example.com');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmAdministrator=admin@example.com'
      );
    });

    it('should append workerNumber when provided', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorsByFirmAdministrator('admin@example.com', 'W001');
      const callArg = httpServiceSpy.get.calls.mostRecent().args[0];
      expect(callArg).toContain('&workerNumber=W001');
    });
  });

  // ─── Worker Status Reports ─────────────────────────────────────────────────

  describe('getEmployeeStatusReport', () => {
    it('should call http.getExcelReport with correct URL', () => {
      httpServiceSpy.getExcelReport.and.returnValue(of(new Blob()));
      service.getEmployeeStatusReport(['W001', 'W002']);
      expect(httpServiceSpy.getExcelReport).toHaveBeenCalledWith(
        '/workers/employeeStatusReport?workerNumbers=W001,W002'
      );
    });
  });

  describe('getContractorStatusReport', () => {
    it('should call http.getExcelReport with correct URL', () => {
      httpServiceSpy.getExcelReport.and.returnValue(of(new Blob()));
      service.getContractorStatusReport(['C001', 'C002']);
      expect(httpServiceSpy.getExcelReport).toHaveBeenCalledWith(
        '/workers/contractorStatusReport?workerNumbers=C001,C002'
      );
    });
  });

  // ─── Trademark Worker ──────────────────────────────────────────────────────

  describe('getTrademarkWorker', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getTrademarkWorker('EMP001');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/trademarkWorkers/EMP001');
    });
  });

  // ─── Organization Validation ───────────────────────────────────────────────

  describe('validateOrganization', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.validateOrganization('ORG001');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/organizations?orgCode=ORG001');
    });
  });

  // ─── Building and Location Services ───────────────────────────────────────

  describe('getBuildings', () => {
    it('should call httpservice.get with /buildings', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getBuildings();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/buildings');
    });
  });

  describe('getBuilding', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getBuilding('bldg-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/buildings/bldg-1');
    });
  });

  describe('getPalmLocations', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getPalmLocations('A');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/palmlocations?codePrefix=A');
    });
  });

  // ─── Reference Data ────────────────────────────────────────────────────────

  describe('getCountries', () => {
    it('should call httpservice.get with /wipocountries', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getCountries();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/wipocountries');
    });
  });

  describe('getStates', () => {
    it('should call httpservice.get with /geoRegions', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getStates();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/geoRegions');
    });
  });

  describe('getJobClasses', () => {
    it('should call httpservice.get with /references/job-classes', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getJobClasses();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/job-classes');
    });
  });

  describe('getPayPlans', () => {
    it('should call httpservice.get with /references/pay-plans', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getPayPlans();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/pay-plans');
    });
  });

  describe('getGrades', () => {
    it('should call httpservice.get with /references/grades', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getGrades();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/grades');
    });
  });

  describe('getSteps', () => {
    it('should call httpservice.get with /references/steps', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getSteps();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/steps');
    });
  });

  describe('getTeleworkPrograms', () => {
    it('should call httpservice.get with /telework-programs', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getTeleworkPrograms();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/telework-programs');
    });
  });

  describe('getDirectoryTitleTypes', () => {
    it('should call httpservice.get with /references/directory-title-types', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getDirectoryTitleTypes();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/directory-title-types');
    });
  });

  describe('getTelecomAddressTypes', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getTelecomAddressTypes();
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/references/telcom-address-types?includeInactive=false'
      );
    });
  });

  describe('getOccupationalSeries', () => {
    it('should call httpservice.get with /references/occupational-series', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getOccupationalSeries();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/occupational-series');
    });
  });

  // ─── Contractor Firms ──────────────────────────────────────────────────────

  describe('getContractorFirms', () => {
    it('should call httpservice.get with /references/contractor-firms', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorFirms();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/contractor-firms');
    });
  });

  describe('getContractorFirmNames', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorFirmNames('W001', 'CEDR');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/references/contractor-firms?workerNumber=W001&applicationType=CEDR'
      );
    });
  });

  describe('getContractorsByFirm', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getContractorsByFirm('firm-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmId=firm-1'
      );
    });
  });

  describe('moveContractorsToFirm', () => {
    it('should call httpservice.put with /workers/firm/association', () => {
      httpServiceSpy.put.and.returnValue(of({}));
      const moveRequest = { firmId: 'firm-2', workerIds: ['w1', 'w2'] };
      service.moveContractorsToFirm(moveRequest);
      expect(httpServiceSpy.put).toHaveBeenCalledWith('/workers/firm/association', moveRequest);
    });
  });

  // ─── Tour of Duty ──────────────────────────────────────────────────────────

  describe('getToursOfDuty', () => {
    it('should call httpservice.get with /toursOfDuty', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getToursOfDuty();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/toursOfDuty');
    });
  });

  // ─── createMultipleContractors ─────────────────────────────────────────────

  describe('createMultipleContractors', () => {
    it('should delegate to getContractorValidCreationResponse', () => {
      httpServiceSpy.post.and.returnValue(of({}));
      const contractors = [{ name: 'Contractor A' }];
      service.createMultipleContractors(contractors);
      expect(httpServiceSpy.post).toHaveBeenCalledWith(
        '/createValidMultipleContractors',
        contractors
      );
    });
  });

  // ─── Location Details ──────────────────────────────────────────────────────

  describe('getLocationDetails', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getLocationDetails('loc-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/locations/loc-1');
    });
  });

  describe('getPalmLocationDetails', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getPalmLocationDetails('palm-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/palmlocations/palm-1');
    });
  });

  describe('validateLocationAssignment', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.validateLocationAssignment('buildingCode=A&floorPrefix=1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/locations?buildingCode=A&floorPrefix=1');
    });
  });

  // ─── Organization Details ──────────────────────────────────────────────────

  describe('getOrganizationDetails', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getOrganizationDetails('org-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/organizations/org-1');
    });
  });

  // ─── Telecommunication Assignment Details ──────────────────────────────────

  describe('getTelecommunicationAssignmentDetails', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getTelecommunicationAssignmentDetails(123, 'assign-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith(
        '/workers/123/assignments/assign-1/telecommunications'
      );
    });
  });

  // ─── Telecom Types ─────────────────────────────────────────────────────────

  describe('getTelecomTypes', () => {
    it('should call httpservice.get with /references/telcom-address-types?includeInactive=false', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getTelecomTypes();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/telcom-address-types?includeInactive=false');
    });
  });

  // ─── Worker Telework Programs ──────────────────────────────────────────────

  describe('getWorkerTeleworkPrograms', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerTeleworkPrograms('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/teleworkPrograms');
    });
  });

  // ─── Primary Worker Organization Roles ────────────────────────────────────

  describe('getPrimaryWorkerOrganizationRoles', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getPrimaryWorkerOrganizationRoles(123);
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/123/primaryOrgRoles');
    });
  });

  // ─── Worker Organizations Details ─────────────────────────────────────────

  describe('getWorkerOrganizationsDetails', () => {
    it('should call httpservice.get with correct URL', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerOrganizationsDetails('worker-1');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/workers/worker-1/organizationsDetails');
    });
  });

  // ─── Worker Details References ─────────────────────────────────────────────

  describe('getWorkerDetailsReferences', () => {
    it('should call httpservice.get for all reference endpoints', () => {
      httpServiceSpy.get.and.returnValue(of([]));
      service.getWorkerDetailsReferences().subscribe();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/tour-of-duties');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/grades');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/steps');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/pay-plans');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/exam-sigs');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/pos-sens-codes');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/leave-accruals');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/appointment-types');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/occ-codes');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/bus-codes');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/job-classes');
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/title-codes');
    });

    it('should return combined references object', (done) => {
      const mockResponses = [
        { data: [{ id: 1, name: 'Tour 1' }] },
        { data: [{ id: 2, name: 'Grade 1' }] },
        { data: [{ id: 3, name: 'Step 1' }] },
        { data: [{ id: 4, name: 'PayPlan 1' }] },
        { data: [{ id: 5, name: 'ExamSig 1' }] },
        { data: [{ id: 6, name: 'PosSens 1' }] },
        { data: [{ id: 7, name: 'LeaveAccrual 1' }] },
        { data: [{ id: 8, name: 'AppointmentType 1' }] },
        { data: [{ id: 9, name: 'OccCode 1' }] },
        { data: [{ id: 10, name: 'BusCode 1' }] },
        { data: [{ id: 11, name: 'JobClass 1' }] },
        { data: [{ id: 12, name: 'TitleCode 1' }] }
      ];
      httpServiceSpy.get.and.returnValue(of(mockResponses[0]));
      service.getWorkerDetailsReferences().subscribe((result) => {
        expect(result.tourOfDuties).toBeDefined();
        expect(result.grades).toBeDefined();
        expect(result.steps).toBeDefined();
        expect(result.payPlans).toBeDefined();
        expect(result.examSigs).toBeDefined();
        expect(result.posSensCodes).toBeDefined();
        expect(result.leaveAccruals).toBeDefined();
        expect(result.appointmentTypes).toBeDefined();
        expect(result.occCodes).toBeDefined();
        expect(result.busCodes).toBeDefined();
        expect(result.jobClasses).toBeDefined();
        expect(result.titleCodes).toBeDefined();
        done();
      });
    });
  });

  describe('getContractorDetailsReferences', () => {
    it('should call httpservice.get with /references/contractorDetails', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getContractorDetailsReferences();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/contractorDetails');
    });
  });

  describe('getWorkerConfidentialReferences', () => {
    it('should call httpservice.get with /references/workerConfidential', () => {
      httpServiceSpy.get.and.returnValue(of({}));
      service.getWorkerConfidentialReferences();
      expect(httpServiceSpy.get).toHaveBeenCalledWith('/references/workerConfidential');
    });
  });

  // ─── Worker Status Excel Report ────────────────────────────────────────────

  describe('getWorkerStatusExcelReport', () => {
    it('should call http.postForCsv with correct URL and worker numbers', () => {
      httpServiceSpy.postForCsv.and.returnValue(of(new Blob()));
      const workerNumbers = ['W001', 'W002', 'W003'];
      service.getWorkerStatusExcelReport(workerNumbers);
      expect(httpServiceSpy.postForCsv).toHaveBeenCalledWith(
        '/workers/statusExcelReport',
        workerNumbers
      );
    });
  });
});