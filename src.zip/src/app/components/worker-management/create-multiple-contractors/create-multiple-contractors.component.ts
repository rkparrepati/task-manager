import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { WorkerManagementService } from '../worker-management.service';
import { UtilityService } from 'src/app/services/utility.service';

interface ContractorDetail {
  row: number;
  firstName: string;
  middleName: string;
  lastName: string;
  preferredFirstName: string;
  dateOfBirth: string;
  lastTwoDigitsOfSSN: string;
  firmName: string;
  org: string;
  errorMessage: string;
}

interface ParsedObject {
  validRows: ContractorDetail[];
  invalidRows: ContractorDetail[];
}

@Component({
  selector: 'app-create-multiple-contractors',
  templateUrl: './create-multiple-contractors.component.html',
  styleUrls: ['./create-multiple-contractors.component.scss']
})
export class CreateMultipleContractorsComponent implements OnInit {
  moduleName = 'Create Multiple Contractors';
  appTitle = 'Create Multiple Contractors';
  fileToImport = '/assets/uploads/CreateMultipleContractorsTemplate.csv';
  importFile: File | null = null;
  invalidWorkerNumber = false;
  workerNumberErrorMsg = '';
  isProcessing = false;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private workerManagementService: WorkerManagementService,
    private utilityService: UtilityService
  ) {}

  ngOnInit(): void {}

  /**
   * Handle file selection from input
   */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.importFile = input.files[0];
    }
  }

  /**
   * Download the CSV template
   */
  downloadTemplate(): void {
    const link = document.createElement('a');
    link.href = this.fileToImport;
    link.download = 'CreateMultipleContractorsTemplate.csv';
    link.click();
  }

  /**
   * Import and process the CSV file
   */
  importTheFile(): void {
    if (!this.importFile) {
      this.showInvalidFileMessage('Please select a file to import');
      return;
    }

    const suffix = this.importFile.name.substring(
      this.importFile.name.length - 4,
      this.importFile.name.length
    );

    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    this.isProcessing = true;
    const reader = new FileReader();

    reader.onload = (e: ProgressEvent<FileReader>) => {
      const text = e.target?.result as string;
      const parsedObject = this.parsePlanSpreadsheet(text);

      if (parsedObject.validRows.length > 0) {
        this.createMultipleContractors(parsedObject);
      } else {
        this.showImportDialogFailure(parsedObject);
        this.isProcessing = false;
      }
    };

    reader.onerror = () => {
      this.showInvalidFileMessage('Error reading file');
      this.isProcessing = false;
    };

    reader.readAsText(this.importFile);
  }

  /**
   * Create multiple contractors via API
   */
  private createMultipleContractors(parsedObject: ParsedObject): void {
    this.workerManagementService.createMultipleContractors(parsedObject.validRows).subscribe({
      next: (response: any) => {
        const processedRows: ParsedObject = {
          validRows: response.validResponse || [],
          invalidRows: response.invalidResponse || []
        };

        if (processedRows.invalidRows.length > 0) {
          this.showImportDialogFailure(processedRows);
        } else {
          this.showImportDialogSuccess(processedRows.validRows);
        }
        this.isProcessing = false;
      },
      error: (error: any) => {

        this.showInvalidFileMessage('Error creating contractors: ' + (error.message || 'Unknown error'));
        this.isProcessing = false;
      }
    });
  }

  /**
   * Parse the CSV spreadsheet
   */
  private parsePlanSpreadsheet(text: string): ParsedObject {
    const lines = text.split('\n');
    const returnObject: ParsedObject = {
      invalidRows: [],
      validRows: []
    };

    lines.forEach((line, index) => {
      // Skip header row (index 0)
      if (index > 0) {
        const lineInfo = this.parseLine(line, index);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
    });

    return returnObject;
  }

  /**
   * Parse a single line from CSV
   */
  private parseLine(line: string, row: number): ContractorDetail | null {
    const columns = line.split(',').map(col => col.trim());

    // Skip empty lines
    if (columns[0].length === 0 && columns.length === 1) {
      return null;
    }

    // Parse and format date
    const dateStr = columns[4];
    let formattedDate = '';

    if (dateStr) {
      const myDate = new Date(dateStr);
      if (!isNaN(myDate.getTime())) {
        const month = ('0' + (myDate.getMonth() + 1)).slice(-2);
        const day = ('0' + myDate.getDate()).slice(-2);
        const year = myDate.getFullYear();
        formattedDate = `${month}/${day}/${year}`;
      }
    }

    const contractorDetail: ContractorDetail = {
      row: row + 1,
      firstName: (columns[0] || '').toUpperCase(),
      middleName: (columns[1] || '').toUpperCase(),
      lastName: (columns[2] || '').toUpperCase(),
      preferredFirstName: (columns[3] || '').toUpperCase(),
      dateOfBirth: formattedDate,
      lastTwoDigitsOfSSN: columns[5] || '',
      firmName: columns[6] || '',
      org: (columns[7] || '').toUpperCase(),
      errorMessage: ''
    };

    // Validate the contractor details
    contractorDetail.errorMessage = this.validateDetails(
      contractorDetail.firstName,
      contractorDetail.lastName,
      contractorDetail.dateOfBirth,
      contractorDetail.lastTwoDigitsOfSSN,
      contractorDetail.firmName,
      contractorDetail.org
    );

    return contractorDetail;
  }

  /**
   * Validate contractor details
   */
  private validateDetails(
    firstName: string,
    lastName: string,
    dateOfBirth: string,
    lastTwoDigitsOfSSN: string,
    firmName: string,
    org: string
  ): string {
    const hasMinData = firstName && lastName && dateOfBirth && lastTwoDigitsOfSSN && firmName && org;

    if (!hasMinData) {
      let message = '';
      message += this.checkMissingParam('Missing First Name; ', firstName);
      message += this.checkMissingParam('Missing Last Name; ', lastName);
      message += this.checkMissingParam('Missing Date Of Birth; ', dateOfBirth);
      message += this.checkMissingParam('Missing Last Two Digits Of SSN; ', lastTwoDigitsOfSSN);
      message += this.checkMissingParam('Missing Firm Name; ', firmName);
      message += this.checkMissingParam('Missing Org; ', org);
      message += this.validateSSN('SSN should be 2 digits; ', lastTwoDigitsOfSSN);
      return message;
    }

    return '';
  }

  /**
   * Validate SSN format (2 digits)
   */
  private validateSSN(errorMessage: string, value: string): string {
    if (value.length === 0) {
      return '';
    }

    if (value.length === 2 && !isNaN(Number(value))) {
      return '';
    }

    return errorMessage;
  }

  /**
   * Check for missing parameters
   */
  private checkMissingParam(errorMessage: string, value: string): string {
    return !value ? errorMessage : '';
  }

  /**
   * Show invalid file type error
   */
  private invalidFileTypeMessage(): void {
    this.showInvalidFileMessage(
      'The format of the spreadsheet is not expected. Only CSV files can be imported.'
    );
  }

  /**
   * Show generic invalid file message
   */
  private showInvalidFileMessage(message: string): void {
    // Use Material Dialog or similar
    alert(message); // Replace with proper dialog implementation
  }

  /**
   * Show import failure dialog with errors
   */
  private showImportDialogFailure(parsedObject: ParsedObject): void {
    // Open dialog showing invalid rows

    // Build error message
    let errorMsg = 'The following rows have errors:\n\n';
    parsedObject.invalidRows.forEach(row => {
      errorMsg += `Row ${row.row}: ${row.errorMessage}\n`;
    });
    
    if (parsedObject.validRows.length > 0) {
      errorMsg += `\n${parsedObject.validRows.length} valid rows were found.`;
    }
    
    alert(errorMsg); // Replace with proper dialog implementation
  }

  /**
   * Show import success dialog
   */
  private showImportDialogSuccess(validRows: ContractorDetail[]): void {
    const message = `Successfully created ${validRows.length} contractor(s).`;
    alert(message); // Replace with proper dialog implementation
    
    // Navigate back to contractor search
    this.router.navigate(['/worker-management'], { 
      queryParams: { type: 'Contractor' } 
    });
  }

  /**
   * Cancel and go back
   */
  cancel(): void {
    this.router.navigate(['/worker-management'], { 
      queryParams: { type: 'Contractor' } 
    });
  }
}
