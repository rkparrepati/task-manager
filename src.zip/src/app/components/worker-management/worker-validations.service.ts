import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';
import { UtilityService } from 'src/app/services/utility.service';
import { Observable } from 'rxjs';
import { WorkerManagementService } from './worker-management.service';
import { MatDialog } from '@angular/material/dialog';
import { FormGroup } from '@angular/forms';

/**
 * Interface for validation error objects
 */
export interface ValidationError {
  fieldId: string;
  fieldName: string;
  message: string;
  tabName: string;
  severity: 'error' | 'warning';
}

/**
 * Interface for conditional validator configuration
 */
export interface ConditionalValidatorConfig {
  fieldName: string;
  isRequired: boolean;
  validators: any[];
}

@Injectable({
  providedIn: 'root',
})
export class WorkerValidationsService {
  constructor(
    private utilityService: UtilityService,
    private workerManagementService: WorkerManagementService,
    private dialog: MatDialog
  ) {}

  /**
   * Validates SSN and checks for duplicates
   * @param ssn Social Security Number to validate
   * @param originalSSN Original SSN (for update scenarios)
   * @returns Observable with validation result
   */
  validateSSN(ssn: string, originalSSN?: string): Observable<any> {
    return new Observable((observer) => {
      // First validate SSN format
      const ssnError = this.utilityService.validateSSNInput('Social Security Number', ssn, true);
      
      if (ssnError) {
        observer.error({ message: ssnError, type: 'format' });
        observer.complete();
        return;
      }

      // If SSN hasn't changed, no need to check for duplicates
      if (originalSSN && ssn === originalSSN) {
        observer.next({ valid: true });
        observer.complete();
        return;
      }

      // Check for duplicate SSN
      this.workerManagementService.validateSocialSecurity(ssn).subscribe(
        (response: any) => {
          if (response && response.results && response.results.length > 0) {
            // SSN already exists
            const secureWorkerData = response.results[0];
            const existingWorker = secureWorkerData.worker;
            observer.error({
              message: `SSN already exists for worker ${existingWorker.workerNumber}`,
              type: 'duplicate',
              existingWorker: existingWorker
            });
          } else {
            // SSN is valid and unique
            observer.next({ valid: true });
          }
          observer.complete();
        },
        (error: any) => {
          // Check if this is a "not found" response (SSN is unique)
          if (error?.status === 404 || error?.error?.message === 'No secure workers found that match the query') {
            // SSN is valid and unique - this is a success case
            observer.next({ valid: true });
          } else {
            observer.error({ message: 'Error validating SSN', type: 'server', error });
          }
          observer.complete();
        }
      );
    });
  }

  /**
   * Validates contractor ID (DOB + Last 2 SSN)
   * @param dateOfBirth Date of birth
   * @param last2SSN Last 2 digits of SSN
   * @returns Observable with validation result
   */
  validateContractorId(dateOfBirth: string, last2SSN: string): Observable<any> {
    return new Observable((observer) => {
      // Validate date of birth format
      const dobError = this.utilityService.validateDateOfBirth('Date of Birth', dateOfBirth, true);
      if (dobError) {
        observer.error({ message: dobError, type: 'format', field: 'dob' });
        observer.complete();
        return;
      }

      // Validate last 2 SSN format
      const ssnError = this.utilityService.validateLastTwoSSNInput('Last 2 SSN', last2SSN, true);
      if (ssnError) {
        observer.error({ message: ssnError, type: 'format', field: 'ssn' });
        observer.complete();
        return;
      }

      // Check for duplicate contractor ID
      this.workerManagementService.validateContractorId(dateOfBirth, last2SSN).subscribe(
        (response: any) => {
          if (response && response.workerNumber) {
            // Contractor ID already exists
            observer.error({
              message: `Contractor ID (DOB + Last 2 SSN) already exists for contractor ${response.workerNumber}`,
              type: 'duplicate',
              existingWorker: response
            });
          } else {
            // Contractor ID is valid and unique
            observer.next({ valid: true });
          }
          observer.complete();
        },
        (error: any) => {
          if (error.status === 404) {
            // No duplicate found - this is good
            observer.next({ valid: true });
            observer.complete();
          } else {
            observer.error({ message: 'Error validating contractor ID', type: 'server', error });
            observer.complete();
          }
        }
      );
    });
  }

  /**
   * Validates organization code
   * @param orgCode Organization code to validate
   * @returns Observable with validation result
   */
  validateOrganizationCode(orgCode: string): Observable<any> {
    return new Observable((observer) => {
      if (!orgCode || orgCode.trim() === '') {
        observer.error({ message: 'Organization code is required', type: 'required' });
        observer.complete();
        return;
      }

      this.workerManagementService.validateOrganization(orgCode).subscribe(
        (response: any) => {
          if (response && response.id) {
            // Organization code is valid
            observer.next({ valid: true, organization: response });
          } else {
            observer.error({ message: 'Invalid organization code', type: 'invalid' });
          }
          observer.complete();
        },
        (error: any) => {
          observer.error({
            message: 'Organization code not found or invalid',
            type: 'notfound',
            error
          });
          observer.complete();
        }
      );
    });
  }
  workerDetailsInfomationInvalid(
    validationBooleans: any,
    worker: any,
    userRoles: any,
    workerEmploymentType: string,
    workerAccession: any
  ) {
    let workerDetailsInfomationInvalidBoolean = false;
    if (workerEmploymentType === 'C') {
      validationBooleans.invalidFirmName = !!worker.contractorFirm ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidFirmName
        ? true
        : workerDetailsInfomationInvalidBoolean;
    }
    validationBooleans.invalidJobClassCode = !!worker.jobClass ? false : true;
    workerDetailsInfomationInvalidBoolean = validationBooleans.invalidJobClassCode
      ? true
      : workerDetailsInfomationInvalidBoolean;

    workerDetailsInfomationInvalidBoolean = this.validateOrgCode(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    workerDetailsInfomationInvalidBoolean = this.validateEmployeeOnly(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    workerDetailsInfomationInvalidBoolean = this.validateNonCoordinatorBoolean(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles
    );

    workerDetailsInfomationInvalidBoolean = this.validateAccessionDate(
      validationBooleans,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerAccession,
      workerEmploymentType
    );

    validationBooleans.invalidTourOfDuty = !!worker.standardTourOfDuty ? false : true;
    workerDetailsInfomationInvalidBoolean = validationBooleans.invalidTourOfDuty
      ? true
      : workerDetailsInfomationInvalidBoolean;

    workerDetailsInfomationInvalidBoolean = this.validateSeriesCode(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    return workerDetailsInfomationInvalidBoolean;
  }
  primaryInfomationInvalid(
    validationBooleans: any,
    worker: any,
    userRoles: any,
    workerEmploymentType: string,
    legacyData: any
  ) {
    validationBooleans.invalidLastName = !worker.familyName;
    let primaryInfomationInvalidBoolean = !worker.familyName;
    if (!worker.givenName) {
      validationBooleans.invalidFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidFirstName = false;
    }
    if (!worker.preferredFirstName) {
      validationBooleans.invalidPreferredFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidPreferredFirstName = false;
    }
    // if (this.workerManagementService.canViewSecureData(userRoles, workerEmploymentType) && workerEmploymentType === 'C') {
    //     if (worker.birthDate === '01/01/0001') {
    //         validationBooleans.birthDateErrorMessage = null;
    //         validationBooleans.invalidBirthDate = false;
    //     } else {
    //         validationBooleans.birthDateErrorMessage = this.utilityService.validateDateOfBirth('Date of birth',
    //             worker.birthDate, true);
    //     }
    //     if (!!validationBooleans.birthDateErrorMessage) {
    //         validationBooleans.invalidBirthDate = true;
    //         primaryInfomationInvalidBoolean = true;
    //     }

    //     /** If legacy data is present and last 2 digits is not entered by user, then data is valid.
    //      If there is legacy data and user entered value then we validiate as before.
    //      If no legqacy data then field is required.*/
    //     if (legacyData && !worker.ssnLast2Digits) {
    //         validationBooleans.lastTwoSSNErrorMessage = false;
    //     } else {
    //         validationBooleans.lastTwoSSNErrorMessage = this.utilityService.validateLastTwoSSNInput('SSN (last 2 digits)',
    //             worker.ssnLast2Digits, true);
    //     }
    //     if (!!validationBooleans.lastTwoSSNErrorMessage) {
    //         validationBooleans.invalidLastTwoSSN = true;
    //         primaryInfomationInvalidBoolean = true;
    //     } else {
    //         validationBooleans.invalidLastTwoSSN = false;
    //     }
    // }

    return primaryInfomationInvalidBoolean;
  }
  validateOrgCode(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      workerEmploymentType === 'E'
    ) {
      if (!!validationBooleans.invalidOrgCodeErrorMsg) {
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        if (!worker.positionOrganizationListing) {
          validationBooleans.invalidOrgCodeErrorMsg = 'Org code is required';
          validationBooleans.invalidOrgCode = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidOrgCodeErrorMsg = '';
          validationBooleans.invalidOrgCode = false;
        }
      }
    }
    return workerDetailsInfomationInvalidBoolean;
  }
  validateEmployeeOnly(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraContractorAdmin') < 0 && workerEmploymentType === 'E') {
      validationBooleans.invalidGrade = !!worker.grade ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidGrade
        ? true
        : workerDetailsInfomationInvalidBoolean;
      validationBooleans.invalidGradeStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Grade start date',
          worker.gradeStartDate,
          true
        );
      if (!!validationBooleans.invalidGradeStartDateErrorMsg) {
        validationBooleans.invalidGradeStartDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidGradeStartDate = false;
      }

      validationBooleans.invalidStep = !!worker.step ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidStep
        ? true
        : workerDetailsInfomationInvalidBoolean;
      validationBooleans.invalidStepStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput('Step start date', worker.stepStartDate, true);
      if (!!validationBooleans.invalidStepStartDateErrorMsg) {
        validationBooleans.invalidStepStartDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidStepStartDate = false;
      }
      // validationBooleans.invalidTypeAppointment = !!worker.TypeAppointment ? false : true;
      // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidTypeAppointment ?
      //         true : workerDetailsInfomationInvalidBoolean;
      if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
        if (!worker.appointmentType) {
          validationBooleans.invalidTypeAppointment = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidTypeAppointment = false;
        }
        // validationBooleans.invalidPositionSensitivity = !!worker.PositionSensitivity ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidPositionSensitivity ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.positionSensitivity) {
          validationBooleans.invalidPositionSensitivity = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidPositionSensitivity = false;
        }
        // validationBooleans.invalidLeaveAccrual = !!worker.LeaveAccural ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidLeaveAccrual ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.leaveAccrual) {
          validationBooleans.invalidLeaveAccural = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidLeaveAccural = false;
        }
        // validationBooleans.invalidBusCode = !!worker.BusCode ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidBusCode ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.bargainUnitType) {
          validationBooleans.invalidBusCode = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidBusCode = false;
        }
      }
      if (!worker.payplan) {
        validationBooleans.invalidPayPlan = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidPayPlan = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }
  validateNonCoordinatorBoolean(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
      validationBooleans.invalidEntranceDutyDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Entrance on duty date',
          worker.lifecycle.beginDate,
          true
        );
      if (!!validationBooleans.invalidEntranceDutyDateErrorMsg) {
        validationBooleans.invalidEntranceDutyDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEntranceDutyDate = false;
      }
      validationBooleans.invalidEndDutyDateErrorMsg = this.utilityService.validateEndOfDutyDate(
        worker.lifecycle.beginDate,
        !!worker.lifecycle.endDate ? worker.lifecycle.endDate : null
      );
      if (!!validationBooleans.invalidEndDutyDateErrorMsg) {
        validationBooleans.invalidEndDutyDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEndDutyDate = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }
  validateAccessionDate(
    validationBooleans: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerAccession: any,
    workerEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0 && workerEmploymentType === 'E') {
      validationBooleans.invalidAccessionDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Accession date',
          workerAccession.accessionDt,
          true
        );
      if (!!validationBooleans.invalidAccessionDateErrorMsg) {
        validationBooleans.invalidAccessionDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidAccessionDate = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }

  validateSeriesCode(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      workerEmploymentType === 'E'
    ) {
      validationBooleans.invalidOccSeriesCode = !!worker.occupationalSeries ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidOccSeriesCode
        ? true
        : workerDetailsInfomationInvalidBoolean;
      if (validationBooleans.occSeriesCodeLookupNoResults) {
        workerDetailsInfomationInvalidBoolean = true;
      }
      if (!worker.occupationalSeriesTitle) {
        validationBooleans.invalidTitleCode = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidTitleCode = false;
      }
      if (validationBooleans.titleCodeLookupNoResults) {
        workerDetailsInfomationInvalidBoolean = true;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }

  /**
   * Validates mandatory fields for worker details on save
   * Follows the old AngularJS pattern from workerUpdate.controller.js
   * Returns validation result with error messages
   * Includes all fields from WORKER_VALIDATION_IMPLEMENTATION_PLAN.md
   */
  validateWorkerDetailsOnSave(
    worker: any,
    userRoles: any,
    workerEmploymentType: string,
    validationBooleans: any
  ): { isValid: boolean; errorMessages: string[] } {
    const errorMessages: string[] = [];



    // Helper function to check if user has a specific role
    const hasRole = (roleName: string): boolean => userRoles.indexOf(roleName) >= 0;

    // PRIMARY INFO VALIDATION (from old AngularJS code)
    // Last Name is always required
    if (!worker.familyName) {

      errorMessages.push('Last name is required');
      validationBooleans.invalidLastName = true;
    } else {
      validationBooleans.invalidLastName = false;
    }

    // First Name is always required
    if (!worker.givenName) {

      errorMessages.push('First name is required');
      validationBooleans.invalidFirstName = true;
    } else {
      validationBooleans.invalidFirstName = false;
    }

    // Preferred First Name is always required
    if (!worker.preferredFirstName) {

      errorMessages.push('Preferred first name is required');
      validationBooleans.invalidPreferredFirstName = true;
    } else {
      validationBooleans.invalidPreferredFirstName = false;
    }

    // DETAILS INFO VALIDATION
    // Job Class is mandatory for all workers (employees and contractors)
    if (!worker.jobClass) {

      errorMessages.push('Position title is required');
      validationBooleans.invalidJobClassCode = true;
    } else {
      validationBooleans.invalidJobClassCode = false;
    }

    // Tour of Duty is mandatory for all workers
    if (!worker.standardTourOfDuty) {

      errorMessages.push('Tour of duty is required');
      validationBooleans.invalidTourOfDuty = true;
    } else {
      validationBooleans.invalidTourOfDuty = false;
    }

    // EMPLOYEE-SPECIFIC FIELDS
    if (workerEmploymentType === 'E') {

      // Grade - required for employees except InfraContractorAdmin
      if (!hasRole('InfraContractorAdmin')) {
        if (!worker.grade) {

          errorMessages.push('Grade is required');
          validationBooleans.invalidGrade = true;
        } else {
          validationBooleans.invalidGrade = false;
        }
      }

      // Grade Start Date - validated by UtilitiesService in old code
      // Only set error if explicitly marked as invalid
      if (!validationBooleans.invalidGradeStartDateErrorMsg) {
        validationBooleans.invalidGradeStartDate = false;
      }

      // Step - required for employees except InfraContractorAdmin
      if (!hasRole('InfraContractorAdmin')) {
        if (!worker.step) {

          errorMessages.push('Step is required');
          validationBooleans.invalidStep = true;
        } else {
          validationBooleans.invalidStep = false;
        }
      }

      // Step Start Date - validated by UtilitiesService in old code
      // Only set error if explicitly marked as invalid
      if (!validationBooleans.invalidStepStartDateErrorMsg) {
        validationBooleans.invalidStepStartDate = false;
      }

      // Pay Plan - required for employees except InfraContractorAdmin
      if (!hasRole('InfraContractorAdmin')) {
        if (!worker.payplan) {

          errorMessages.push('Pay plan is required');
          validationBooleans.invalidPayPlan = true;
        } else {
          validationBooleans.invalidPayPlan = false;
        }
      }

      // Org Code - required for employees except InfraOfficeCoordinator and InfraContractorAdmin
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraContractorAdmin')) {
        if (!worker.positionOrganizationListing) {

          errorMessages.push('Org code is required');
          validationBooleans.invalidOrgCode = true;
        } else {
          validationBooleans.invalidOrgCode = false;
        }
      }

      // Entrance on Duty Date - required for employees except InfraOfficeCoordinator
      if (!hasRole('InfraOfficeCoordinator')) {
        if (!worker.lifecycle || !worker.lifecycle.beginDate) {

          errorMessages.push('Entrance on duty date is required');
          validationBooleans.invalidEntranceDutyDate = true;
        } else {
          validationBooleans.invalidEntranceDutyDate = false;
        }
      }

      // OCC Services Code - required for employees except InfraOfficeCoordinator and InfraContractorAdmin
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraContractorAdmin')) {
        if (!worker.occupationalSeries) {

          errorMessages.push('OCC series code is required');
          validationBooleans.invalidOccSeriesCode = true;
        } else {
                                                                     validationBooleans.invalidOccSeriesCode = false;
        }
      }

      // Title Code - required for employees except InfraOfficeCoordinator and InfraContractorAdmin
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraContractorAdmin')) {
        if (!worker.occupationalSeriesTitle) {

          errorMessages.push('Title code is required');
          validationBooleans.invalidTitleCode = true;
        } else {
          validationBooleans.invalidTitleCode = false;
        }
      }

      // Type of Appointment - required for employees except InfraOfficeCoordinator and InfraRoomCoordinator
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraRoomCoordinator')) {
        if (!worker.appointmentType) {

          errorMessages.push('Type of appointment is required');
          validationBooleans.invalidTypeAppointment = true;
        } else {
          validationBooleans.invalidTypeAppointment = false;
        }
      }

      // Position Sensitivity - required for employees except InfraOfficeCoordinator and InfraRoomCoordinator
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraRoomCoordinator')) {
        if (!worker.positionSensitivity) {

          errorMessages.push('Position sensitivity is required');
          validationBooleans.invalidPositionSensitivity = true;
        } else {
          validationBooleans.invalidPositionSensitivity = false;
        }
      }

      // Leave Accrual - required for employees except InfraOfficeCoordinator and InfraRoomCoordinator
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraRoomCoordinator')) {
        if (!worker.leaveAccrual) {

          errorMessages.push('Leave accrual is required');
          validationBooleans.invalidLeaveAccural = true;
        } else {
          validationBooleans.invalidLeaveAccural = false;
        }
      }

      // Business Unit Code - required for employees except InfraOfficeCoordinator and InfraRoomCoordinator
      if (!hasRole('InfraOfficeCoordinator') && !hasRole('InfraRoomCoordinator')) {
        if (!worker.bargainUnitType) {

          errorMessages.push('BUS code is required');
          validationBooleans.invalidBusCode = true;
        } else {
          validationBooleans.invalidBusCode = false;
        }
      }
    } else {

    }

    // CONTRACTOR-SPECIFIC FIELDS
    if (workerEmploymentType === 'C') {
      // Contractor Firm is mandatory for contractors
      if (!worker.contractorFirm) {

        errorMessages.push('Firm name is required');
        validationBooleans.invalidFirmName = true;
      } else {
        validationBooleans.invalidFirmName = false;
      }
    }

    return {
      isValid: errorMessages.length === 0,
      errorMessages: errorMessages
    };
  }
  confidentialInfomationInvalid(validationBooleans: any, workerSecure: any) {
    let confidentialInformationInvalid = false;
    if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
      confidentialInformationInvalid = true;
    } else {
      if (workerSecure) {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          this.utilityService.validateSSNInput(
            'Social security number',
            workerSecure.employeeSocialSecurity,
            true
          );
      } else {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          'Social security number is required';
      }

      if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
        validationBooleans.invalidEmployeeSocialSecurity = true;
        confidentialInformationInvalid = true;
      } else {
        validationBooleans.invalidEmployeeSocialSecurity = false;
      }
    }

    if (workerSecure.birthDate === '01/01/0001') {
      validationBooleans.invalidDateOfBirthErrorMsg = null;
    } else {
      validationBooleans.invalidDateOfBirthErrorMsg = this.utilityService.validateDateOfBirth(
        'Date of birth',
        workerSecure.birthDate,
        true
      );
    }
    if (!!validationBooleans.invalidDateOfBirthErrorMsg) {
      validationBooleans.invalidDateOfBirth = true;
      confidentialInformationInvalid = true;
    } else {
      validationBooleans.invalidDateOfBirth = false;
    }

    return confidentialInformationInvalid;
  }
  getWorkerAddObject(workerObj: any, employmentTypes: any) {
    let worker = this.getWorkerPrimaryAndDetails(workerObj);
    /**
     * Set employment type
     */
    if (worker.employmentType) {
      employmentTypes.map(function (employmentType: any) {
        if (employmentType.value === worker.employmentType) {
          worker.employmentType = {
            id: employmentType.id,
            value: employmentType.value,
            description: employmentType.description,
          };
        }
      });
    }

    return worker;
  }
  getWorkerPrimaryAndDetails(worker: any) {
    let teleworkProgram;
    if (worker.teleworkProgram && worker.teleworkProgram.id) {
      teleworkProgram = {
        teleworkProgramId: worker.teleworkProgram.id,
        hotelingIndicator: worker.teleworkProgram.hotelingIndicator,
      };
    }
    worker.teleworkProgram = teleworkProgram || null;
    worker.lifecycle = {
      beginDate: !!worker.lifecycle.beginDate
        ? this.utilityService.adjustDateFormatter(
            this.utilityService.dateFormatter(new Date(worker.lifecycle.beginDate))
          )
        : null,
      endDate: !!worker.lifecycle.endDate
        ? this.utilityService.adjustEndDateFormatter(
            this.utilityService.dateFormatterEndDate(new Date(worker.lifecycle.endDate))
          )
        : null,
    };

    /**
     * if lifecycle.endDate exists, use that value and set to organization.lifecycle.endDate
     */
    if (worker.lifecycle.endDate != undefined && worker.lifecycle.endDate != '') {
      if (worker.organizationHistory != undefined && worker.organizationHistory.length > 0) {
        worker.organizationHistory.map(function (organizationData: any, index: number) {
          organizationData.primaryOrganizationIndicator = false;
          if (
            organizationData.locationSummary != undefined &&
            organizationData.locationSummary.length > 0
          ) {
            organizationData.locationSummary[0].primaryLocationIn = false;
          }
          organizationData.lifecycle.endDate = worker.lifecycle.endDate + '.000Z';
        });
      }
    }
    if (worker.gradeStartDate) {
      worker.gradeStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(worker.gradeStartDate))
      );
    } else {
      worker.gradeStartDate = null;
    }

    if (worker.stepStartDate) {
      worker.stepStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(worker.stepStartDate))
      );
    } else {
      worker.stepStartDate = null;
    }
    worker.supervisorIndicator = worker.supervisorIndicator ? worker.supervisorIndicator : false;

    if (!worker.activeEmploymentIndicator) {
      worker.activeEmploymentIndicator = false;
    } else {
      worker.activeEmploymentIndicator = true;
    }
    worker.occupationalSeriesTitle = this.getOccupationalSeries(worker.occupationalSeriesTitle);
    worker.directoryTitleType = this.getDirectoryTitleType(worker.directoryTitleType);

    return worker;
  }
  getOccupationalSeries(occupationalSeriesTitle: any) {
    let newOccupationalSeriesTitle;

    if (occupationalSeriesTitle && occupationalSeriesTitle.id) {
      newOccupationalSeriesTitle = {
        occupationalSeriesTitleId: occupationalSeriesTitle.id,
      };
    } else {
    }
    return newOccupationalSeriesTitle;
  }
  getDirectoryTitleType(directoryTitleType: any) {
    let newDirectoryTitleType: any;
    if (directoryTitleType && directoryTitleType.id) {
      newDirectoryTitleType = {
        id: directoryTitleType.id,
      };
    }
    return newDirectoryTitleType;
  }

  /**
   * Aggregates validation errors from multiple forms
   * @param forms Array of FormGroup objects to validate
   * @param tabNames Map of form to tab name for error display
   * @returns Array of ValidationError objects
   */
  aggregateFormErrors(forms: FormGroup[], tabNames: Map<FormGroup, string>): ValidationError[] {
    const errors: ValidationError[] = [];

    forms.forEach((form) => {
      if (form && form.invalid) {
        const tabName = tabNames.get(form) || 'Unknown Tab';
        Object.keys(form.controls).forEach((controlName) => {
          const control = form.get(controlName);
          if (control && control.invalid && control.touched) {
            const fieldName = this.getFieldDisplayName(controlName);
            const errorMessage = this.getErrorMessage(controlName, control.errors);
            errors.push({
              fieldId: controlName,
              fieldName: fieldName,
              message: `${fieldName}: ${errorMessage}`,
              tabName: tabName,
              severity: 'error'
            });
          }
        });
      }
    });

    return errors;
  }

  /**
   * Gets conditional validators based on employment type, roles, and secure data access
   * @param fieldName Name of the field
   * @param employmentType Employment type (E or C)
   * @param userRoles Array of user roles
   * @param canViewSecureData Whether user can view secure data
   * @returns Array of validators to apply
   */
  getConditionalValidators(
    fieldName: string,
    employmentType: string,
    userRoles: string[],
    canViewSecureData: boolean
  ): any[] {
    const validators: any[] = [];

    // Check if field should be required based on conditions
    if (this.shouldFieldBeRequired(fieldName, employmentType, userRoles, canViewSecureData)) {
      validators.push(Validators.required);
    }

    // Add SSN-specific validators
    if (fieldName === 'ssn') {
      validators.push(this.ssnValidator());
    }

    // Add date of birth validators
    if (fieldName === 'dateOfBirth') {
      validators.push(this.ageValidator());
    }

    return validators;
  }

  /**
   * Determines if a field should be required based on employment type and roles
   * @param fieldName Name of the field
   * @param employmentType Employment type (E or C)
   * @param userRoles Array of user roles
   * @param canViewSecureData Whether user can view secure data
   * @returns True if field should be required
   */
  private shouldFieldBeRequired(
    fieldName: string,
    employmentType: string,
    userRoles: string[],
    canViewSecureData: boolean
  ): boolean {
    // Always required fields
    const alwaysRequired = ['firstName', 'lastName', 'preferredFirstName', 'positionTitle', 'entranceDutyDate', 'tourDuty'];
    if (alwaysRequired.includes(fieldName)) {
      return true;
    }

    // Contractor-specific fields
    if (employmentType === 'C') {
      const contractorFields = ['birthDate', 'ssnLast2Digits', 'firmName'];
      if (contractorFields.includes(fieldName)) {
        if (fieldName === 'birthDate' || fieldName === 'ssnLast2Digits') {
          return canViewSecureData;
        }
        return true;
      }
    }

    // Employee-specific fields
    if (employmentType === 'E') {
      // Confidential info fields
      const confidentialFields = ['ssn', 'dateOfBirth', 'birthCityName', 'birthCountry'];
      if (confidentialFields.includes(fieldName)) {
        return true;
      }

      // Details info fields with role exclusions
      const detailsFields = {
        'orgCode': ['InfraOfficeCoordinator', 'InfraContractorAdmin'],
        'grade': ['InfraContractorAdmin'],
        'gradeStartDate': ['InfraContractorAdmin'],
        'step': ['InfraContractorAdmin'],
        'stepStartDate': ['InfraContractorAdmin'],
        'payPlan': ['InfraContractorAdmin'],
        'accessionDate': ['InfraOfficeCoordinator', 'InfraRoomCoordinator'],
        'occServicesCode': ['InfraOfficeCoordinator', 'InfraContractorAdmin'],
        'titleCode': ['InfraOfficeCoordinator', 'InfraContractorAdmin'],
        'typeAppointment': ['InfraOfficeCoordinator', 'InfraRoomCoordinator'],
        'positionSensitivity': ['InfraOfficeCoordinator', 'InfraRoomCoordinator'],
        'leaveAccrual': ['InfraOfficeCoordinator', 'InfraRoomCoordinator'],
        'busCode': ['InfraOfficeCoordinator', 'InfraRoomCoordinator']
      };

      if (fieldName in detailsFields) {
        const excludedRoles = detailsFields[fieldName as keyof typeof detailsFields];
        const isUserExcluded = userRoles.some(role => excludedRoles.includes(role));
        return !isUserExcluded;
      }
    }

    return false;
  }

  /**
   * Checks if a field should be visible based on employment type and roles
   * @param fieldName Name of the field
   * @param employmentType Employment type (E or C)
   * @param userRoles Array of user roles
   * @param canViewSecureData Whether user can view secure data
   * @returns True if field should be visible
   */
  isFieldVisible(
    fieldName: string,
    employmentType: string,
    userRoles: string[],
    canViewSecureData: boolean
  ): boolean {
    // Confidential info fields are only visible for employees
    const confidentialFields = ['ssn', 'dateOfBirth', 'birthCityName', 'birthCountry'];
    if (confidentialFields.includes(fieldName)) {
      return employmentType === 'E' && canViewSecureData;
    }

    // Contractor-specific secure fields (birthDate and ssnLast2Digits)
    // Only visible for contractors AND only for specific roles
    if (fieldName === 'birthDate' || fieldName === 'ssnLast2Digits') {
      if (employmentType !== 'C') {
        return false;
      }
      // Check if user has one of the allowed roles for contractors
      const allowedRoles = ['InfraAdmin', 'InfraHRAdmin', 'InfraOfficeCoordinator', 'InfraContractorAdmin'];
      return allowedRoles.some(role => userRoles.includes(role));
    }

    // Contractor-only fields
    if (fieldName === 'firmName') {
      return employmentType === 'C';
    }

    // Employee-only fields
    const employeeOnlyFields = ['orgCode', 'grade', 'gradeStartDate', 'step', 'stepStartDate', 'payPlan', 'accessionDate', 'occServicesCode', 'titleCode', 'typeAppointment', 'positionSensitivity', 'leaveAccrual', 'busCode'];
    if (employeeOnlyFields.includes(fieldName)) {
      return employmentType === 'E';
    }

    // All other fields are visible
    return true;
  }

  /**
   * Checks if a field should be readonly based on employment type and roles
   * @param fieldName Name of the field
   * @param employmentType Employment type (E or C)
   * @param userRoles Array of user roles
   * @returns True if field should be readonly
   */
  isFieldReadonly(
    fieldName: string,
    employmentType: string,
    userRoles: string[]
  ): boolean {
    // For contractor-specific fields (birthDate and ssnLast2Digits)
    // InfraOfficeCoordinator and InfraHRAdmin can view but not edit (readonly)
    if ((fieldName === 'birthDate' || fieldName === 'ssnLast2Digits') && employmentType === 'C') {
      const readonlyRoles = ['InfraOfficeCoordinator', 'InfraHRAdmin'];
      return readonlyRoles.some(role => userRoles.includes(role));
    }

    return false;
  }

  /**
   * Gets user-friendly display name for a field ID
   * @param fieldId Field identifier
   * @returns User-friendly field name
   */
  getFieldDisplayName(fieldId: string): string {
    const fieldNameMap: { [key: string]: string } = {
      'firstName': 'First name',
      'lastName': 'Last name',
      'preferredFirstName': 'Preferred first name',
      'birthDate': 'Date of birth',
      'ssnLast2Digits': 'SSN (last 2 digits)',
      'ssn': 'Social security number',
      'dateOfBirth': 'Date of birth',
      'birthCityName': 'City of birth',
      'birthCountry': 'Country of birth',
      'firmName': 'Firm name',
      'positionTitle': 'Position title',
      'orgCode': 'Org code',
      'grade': 'Grade',
      'gradeStartDate': 'Grade start date',
      'step': 'Step',
      'stepStartDate': 'Step start date',
      'payPlan': 'Pay plan',
      'entranceDutyDate': 'Entrance on duty date',
      'accessionDate': 'Accession date',
      'tourDuty': 'Tour of duty',
      'occServicesCode': 'OCC series code',
      'titleCode': 'Title code',
      'typeAppointment': 'Type of appointment',
      'positionSensitivity': 'Position sensitivity',
      'leaveAccrual': 'Leave accrual',
      'busCode': 'BUS code'
    };

    return fieldNameMap[fieldId] || fieldId;
  }

  /**
   * Gets error message for a form control
   * @param fieldId Field identifier
   * @param errors Error object from form control
   * @returns Error message string
   */
  private getErrorMessage(fieldId: string, errors: any): string {
    if (!errors) {
      return '';
    }

    if (errors['required']) {
      return `${this.getFieldDisplayName(fieldId)} is required`;
    }

    if (errors['ageValidator']) {
      return `Employee must be at least 16 years old`;
    }

    if (errors['pattern']) {
      return `${this.getFieldDisplayName(fieldId)} has invalid format`;
    }

    if (errors['minlength']) {
      return `${this.getFieldDisplayName(fieldId)} is too short`;
    }

    if (errors['maxlength']) {
      return `${this.getFieldDisplayName(fieldId)} is too long`;
    }

    if (errors['email']) {
      return `${this.getFieldDisplayName(fieldId)} must be a valid email`;
    }

    return `${this.getFieldDisplayName(fieldId)} is invalid`;
  }

  /**
   * Custom validator for SSN format
   * Validates that SSN has exactly 9 digits (ignoring hyphens)
   * @returns Validator function
   */
  private ssnValidator() {
    return (control: any) => {
      if (!control.value) {
        return null; // Don't validate empty values
      }

      // Remove hyphens to get just the digits
      const digitsOnly = control.value.replace(/\D/g, '');

      // Check if we have exactly 9 digits
      if (digitsOnly.length !== 9) {
        return { ssnInvalidLength: { value: control.value } };
      }

      return null;
    };
  }

  /**
   * Custom validator for date of birth
   * Validates that the person is at least 16 years old
   * @returns Validator function
   */
  ageValidator() {
    return (control: any) => {
      if (!control.value) {
        return null; // Don't validate empty values
      }

      try {
        // Parse the date - handle various date formats
        let birthDate: Date;
        
        if (control.value instanceof Date) {
          birthDate = control.value;
        } else if (typeof control.value === 'string') {
          // Try to parse string date (MM/DD/YYYY or other formats)
          birthDate = new Date(control.value);
        } else {
          return null;
        }

        // Check if date is valid
        if (isNaN(birthDate.getTime())) {
          return null;
        }

        // Calculate age
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        
        // Adjust age if birthday hasn't occurred this year
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }

        // Check if person is at least 16 years old
        if (age < 16) {
          return { ageValidator: { value: control.value, requiredAge: 16, actualAge: age } };
        }

        return null;
      } catch (error) {
        return null;
      }
    };
  }

  /**
   * Builds error message array from validation errors
   * @param errors Array of ValidationError objects
   * @returns Array of formatted error message strings
   */
  buildErrorMessages(errors: ValidationError[]): string[] {
    return errors.map(error => `${error.tabName} - ${error.message}`);
  }
}
