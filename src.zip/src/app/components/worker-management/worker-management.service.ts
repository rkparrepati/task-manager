import { Injectable } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { Observable, BehaviorSubject, forkJoin, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class WorkerManagementService {
  // Toast message management for ACME navbar component (following contractor-management pattern)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();

  readonly searchCriteriaMap: any = {
    workerNumber: 'workerNumberPrefix',
    familyName: 'familyName',
    givenName: 'givenName',
    preferredFirstName: 'preferredFirstName',
    mulWorkerNumber: 'mulWorkerNumber',
    dateOfBirth: 'dateOfBirth',
    contractorSSN: 'contractorSSN',
    classCode: 'classCode',
    firmName: 'firmName',
    firmAdministrator: 'firmAdministrator',
    businessAreaCode: 'businessAreaCode',
    loginWorkerNumber: 'loginWorkerNumber',
    workerAssociatedFirms: 'workerAssociatedFirms',
  };
  selectedWorkerDetails: any;
  constructor(
    private httpservice: HttpService,
    private appservice: AppService,
    private http: HttpService
  ) {}

  // Methods to update toast messages for ACME navbar (following contractor-management pattern)
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.scrolltoTop();
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /**
   * Display success message via acme-navbar
   * @param message Success message to display
   */
  showSuccessMessage(message: string) {
    this.updateReturnCode(200);
    this.updateReturnMessage(message);
    this.updateHideMessage(false);
  }

  /**
   * Display error message via acme-navbar
   * @param message Error message to display
   * @param code Optional error code (default: 500)
   */
  showErrorMessage(message: string, code: string | number = 500) {
    this.updateReturnCode(code);
    this.updateReturnMessage(message);
    this.updateHideMessage(false);
  }

  /**
   * Display multiple validation error messages via acme-navbar
   * @param messages Array of error messages
   * @param code Optional error code (default: 700 for validation errors)
   */
  showValidationErrors(messages: string[], code: string | number = 700) {
    this.updateReturnCode(code);
    this.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
    this.updateReturnMessageArray(messages);
    this.updateHideMessage(false);
  }

  /**
   * Hide the message banner
   */
  hideMessages() {
    this.updateHideMessage(true);
    this.updateReturnMessage('');
    this.updateReturnMessageArray([]);
  }

  public getSearchCriteriaKey(searchCriteria: string): string {
    const key = this.searchCriteriaMap[searchCriteria];
    return key ? key : searchCriteria;
  }

  validateContractorId(dateOfBirth: string, contractorSSN: string) {
    const url = 'workers';
    const params = {
      isContractor: true,
      includeInactive: true,
      dateOfBirth: dateOfBirth,
      contractorSSN: contractorSSN,
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const _url = `/${url}?${queryParams}`;
    return this.httpservice.get(_url);
  }

  public getWorkers(
    showAll: boolean,
    searchText: string,
    searchCriteria: string,
    isContractor: boolean = false,
    limit: number = 10,
    skip: number = 0,
    sortColumn: string = 'familyName',
    sortOrder: string = 'asc'
  ): Observable<any> {
    let url = `/workers?includeInactive=${showAll}&${this.getSearchCriteriaKey(
      searchCriteria
    )}=${searchText}&limit=${limit}&skip=${skip}&sortColumn=${sortColumn}&sortOrder=${sortOrder}`;
    if (isContractor) {
      url += `&isContractor=true`;
    }
    return this.httpservice.get(url);
  }

  public getWorkersForRoles(
    showAll: boolean,
    searchText: string,
    searchCriteria: string,
    sortColumn: string,
    sortDirection: string,
    isContractor: boolean = false,
    limit: number = 10,
    skip: number = 0
  ): Observable<any> {
    let url = `/workers?includeInactive=${showAll}&${this.getSearchCriteriaKey(
      searchCriteria
    )}=${searchText}&limit=${limit}&skip=${skip}&sortColumn=${sortColumn}&sortOrder=${sortDirection}`;
    if (isContractor) {
      url += `&isContractor=true`;
    }
    return this.httpservice.get(url);
  }

  getSearchUrl(searchCriteria: string, searchText: string): string {
    return `&${this.getSearchCriteriaKey(searchCriteria)}=${searchText}`;
  }

  public getWorkersWithAdvanceSearch(
    showAll: boolean,
    queryParameters: string,
    limit: number = 10,
    skip: number = 0,
    sortColumn: string = 'familyName',
    sortOrder: string = 'asc'
  ): Observable<any> {
    let url = `/workers?includeInactive=${showAll}&limit=${limit}&skip=${skip}&sortColumn=${sortColumn}&sortOrder=${sortOrder}`;
    if (queryParameters) {
      url = `/workers?includeInactive=${showAll}${queryParameters}&limit=${limit}&skip=${skip}&sortColumn=${sortColumn}&sortOrder=${sortOrder}`;
    }

    return this.httpservice.get(url);
  }

  public getWorkerAssignments(workerId: number): Observable<any> {
    let url = `/workers/${workerId}/assignments`;
    return this.httpservice.get(url);
  }

  public setSelectedWorkerDetails(workerDetails: any): void {
    this.selectedWorkerDetails = workerDetails;
  }
  public getWorkerDetails(): any {
    return this.selectedWorkerDetails;
  }

  public workerExcelReport(
    showAll: boolean,
    queryParameters: string,
    totalrecords: number
  ): Observable<Blob> {
    const headers = new HttpHeaders().set('Accept', 'application/vnd.ms-excel');

    let url = `/workers/workerExcelReport?includeInactive=${showAll}${queryParameters}&limit=${totalrecords}&sortColumn=lastName&sortOrder=asc`;
    return this.http.getExcelReport(url);
  }

  public getParameters(): Observable<any> {
    return this.httpservice.get('/parameters');
  }

  canViewSecureData(userRoles: any, employmentType: string) {
    if (
      (employmentType === 'E' &&
        (userRoles.indexOf('InfraAdmin') >= 0 || userRoles.indexOf('InfraHRAdmin') >= 0)) ||
      userRoles.indexOf('InfraHRViewer') >= 0
    ) {
      return true;
    }

    const canViewContractorSecure =
      userRoles.indexOf('InfraAdmin') >= 0 ||
      userRoles.indexOf('InfraHRAdmin') >= 0 ||
      userRoles.indexOf('InfraContractorAdmin') >= 0 ||
      userRoles.indexOf('InfraOfficeCoordinator') >= 0;

    return employmentType === 'C' && canViewContractorSecure;
  }

  getContractorStatusValidResponse(validRequests: any) {
    return this.httpservice.post('/createValidContractors', validRequests);
  }

  /**
   * Create valid workers via the infra-services endpoint
   * @param validRequests Array of worker objects with row, workerNumber, and errorMessage
   */
  createValidWorkers(validRequests: any) {
    return this.httpservice.post('/createValidWorkers', validRequests);
  }

  /**
   * Transform employee status API response to standardized format
   * Ensures validResponse contains full worker data with row and contractorNumber
   * @param response Raw API response
   * @returns Transformed response with standardized structure
   */
  private transformEmployeeStatusResponse(response: any): any {
    // If response already has the expected structure with both validResponse and invalidResponse, return as-is
    if (response?.validResponse !== undefined && response?.invalidResponse !== undefined) {
      return response;
    }

    // Helper function to transform individual items for validResponse (row is null)
    const transformValidItem = (item: any) => ({
      row: null,
      contractorNumber: item?.contractorNumber || item?.workerNumber,
      workerNumber: item?.workerNumber,
      worker: item?.worker || item,
      errorMessage: item?.errorMessage || ''
    });

    // Helper function to transform individual items for invalidResponse (row is provided)
    const transformInvalidItem = (item: any, index: number) => ({
      row: item?.row || index + 1,
      contractorNumber: item?.contractorNumber || item?.workerNumber,
      workerNumber: item?.workerNumber,
      errorMessage: item?.errorMessage || '',
      worker: null
    });

    // If response is an array, transform it to validResponse format
    if (Array.isArray(response)) {
      return {
        validResponse: response.map((item: any) => transformValidItem(item)),
        invalidResponse: []
      };
    }

    // If response has results property, transform it
    if (response?.results && Array.isArray(response.results)) {
      return {
        validResponse: response.results.map((item: any) => transformValidItem(item)),
        invalidResponse: []
      };
    }

    // If response has validResponse property but not invalidResponse, add empty invalidResponse
    if (response?.validResponse && Array.isArray(response.validResponse)) {
      return {
        validResponse: response.validResponse.map((item: any) => transformValidItem(item)),
        invalidResponse: response?.invalidResponse || []
      };
    }

    // If response has invalidResponse property but not validResponse, add empty validResponse
    if (response?.invalidResponse && Array.isArray(response.invalidResponse)) {
      return {
        validResponse: response?.validResponse || [],
        invalidResponse: response.invalidResponse.map((item: any, index: number) => transformInvalidItem(item, index))
      };
    }

    // Fallback: wrap single object or array in validResponse
    if (response) {
      const items = Array.isArray(response) ? response : [response];
      return {
        validResponse: items.map((item: any) => transformValidItem(item)),
        invalidResponse: []
      };
    }

    // If response is null/undefined, return empty structure
    return {
      validResponse: [],
      invalidResponse: []
    };
  }
  getContractorCreationResponse(validRequests: any) {
    return this.httpservice.post('/createMultipleContractors', validRequests);
  }

  getContractorValidCreationResponse(validRequests: any) {
    return this.httpservice.post('/createValidMultipleContractors', validRequests);
  }

  getContractorsByFirmSearch(firmName: string) {
    const url = `/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmName=${firmName}`;
    return this.httpservice.get(url);
  }

  moveContractorsList(servicesObject: any) {
    return this.httpservice.put('/workers/firm/association', servicesObject);
  }

  orgRoles(orgId: string) {
    const url = '/workers/' + orgId + '/orgRoles';
    return this.httpservice.get(url);
  }

  getWorkerByWorkerNumber(workerNumber: string): Observable<any> {
    const url = `/workers?workerNumber=${workerNumber}`;
    return this.httpservice.get(url);
  }

  getReportData(reportType: string, params: any): Observable<any> {
    const queryParams = this.appservice.mergeQueryParams(params);
    const url = `/workers/${reportType}?${queryParams}`;
    return this.httpservice.get(url);
  }

  // Worker CRUD Operations
  public getWorkerById(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}`);
  }

  public getWorkerByWorkerNumberDetailed(workerNumber: string, includeInactive: boolean = false): Observable<any> {
    return this.httpservice.get(`/workers?workerNumber=${workerNumber}&includeInactive=${includeInactive}`);
  }

  public createWorker(workerData: any): Observable<any> {
    return this.httpservice.post('/hrWorkers', workerData);
  }

  public updateWorker(workerId: string, workerData: any, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}`;
    return this.httpservice.put(url, workerData);
  }

  public deleteWorker(workerId: string): Observable<any> {
    return this.httpservice.delete(`/workers/${workerId}`);
  }

  // Worker Secure Data Operations
  public getWorkerSecureData(workerId: string): Observable<any> {
    return this.httpservice.get(`/secure-workers/${workerId}`);
  }

  public updateWorkerSecureData(workerId: string, secureData: any): Observable<any> {
    return this.httpservice.put(`/workers/${workerId}/secure`, secureData);
  }

  public saveWorkerSecureInformation(workerId: string, secureData: any, updateParams: any): Observable<any> {
    const url = updateParams?.lockControlNumber
      ? `/secure-workers/${workerId}?lockControlNumber=${updateParams.lockControlNumber}`
      : `/secure-workers/${workerId}`;
    return this.httpservice.put(url, secureData);
  }

  // SSN Validation
  public validateSocialSecurity(ssn: string): Observable<any> {
    return this.httpservice.post(`/secure-workers`, { socialSecurityNumber: ssn });
  }

  // Worker Accession Operations
  public getWorkerAccession(workerId: string): Observable<any> {
    return this.httpservice.get(`/worker-accession?workerID=${workerId}`);
  }

  public addWorkerAccession(accessionData: any, updateParams: any): Observable<any> {
    const url = updateParams?.lockControlNumber
      ? `/worker-accession?lockControlNumber=${updateParams.lockControlNumber}`
      : `/worker-accession`;
    return this.httpservice.post(url, accessionData);
  }

  public updateWorkerAccession(accessionData: any, updateParams: any): Observable<any> {
    const url = updateParams?.lockControlNumber
      ? `/worker-accession?lockControlNumber=${updateParams.lockControlNumber}`
      : `/worker-accession`;
    return this.httpservice.put(url, accessionData);
  }

  public updateWorkerAccessionLegacy(workerId: string, accessionData: any, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}/accession?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}/accession`;
    return this.httpservice.put(url, accessionData);
  }

  public generateAccessionReport(workerIds: string[]): Observable<Blob> {
    const url = `/workers/accessionReport?workerIds=${workerIds.join(',')}`;
    return this.http.getExcelReport(url);
  }

  // Worker Assignment Operations
  public createWorkerAssignment(workerId: string, assignmentData: any): Observable<any> {
    return this.httpservice.post(`/workers/${workerId}/assignments`, assignmentData);
  }

  public updateWorkerAssignment(workerId: string, assignmentId: string, assignmentData: any, lockControlNumber?: string): Observable<any> {
    // CRITICAL FIX: lockControlNumber parameter is now a JSON string: {"lockControlNumber":1}
    // It needs to be passed as the 'audit' query parameter
    const url = lockControlNumber
      ? `/workers/${workerId}/assignments/${assignmentId}?audit=${encodeURIComponent(lockControlNumber)}`
      : `/workers/${workerId}/assignments/${assignmentId}`;
    return this.httpservice.put(url, assignmentData);
  }

  public deleteWorkerAssignment(workerId: string, assignmentId: string): Observable<any> {
    return this.httpservice.delete(`/workers/${workerId}/assignments/${assignmentId}`);
  }

  // Worker Organization Operations
  public getWorkerOrganizations(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/organizations`);
  }

  public createWorkerOrganization(workerId: string, organizationData: any): Observable<any> {
    return this.httpservice.post(`/workers/${workerId}/organizations`, organizationData);
  }

  public updateWorkerOrganization(workerId: string, organizationId: string, organizationData: any, lockControlNumber?: string): Observable<any> {
    // CRITICAL FIX: lockControlNumber parameter is now a JSON string: {"lockControlNumber":1}
    // It needs to be passed as the 'audit' query parameter
    const url = lockControlNumber
      ? `/workers/${workerId}/organizations/${organizationId}?audit=${encodeURIComponent(lockControlNumber)}`
      : `/workers/${workerId}/organizations/${organizationId}`;
    return this.httpservice.put(url, organizationData);
  }

  // Worker Telecommunication Operations
  public getWorkerTelecommunications(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/telecommunications`);
  }

  public createWorkerTelecommunication(workerId: string, telecomData: any): Observable<any> {
    return this.httpservice.post(`/workers/${workerId}/telecommunications`, telecomData);
  }

  public createBulkWorkerTelecommunications(workerId: string, telecomList: any[]): Observable<any> {
    return this.httpservice.post(`/workers/${workerId}/assign-bulk-telecommunications`, telecomList);
  }

  public updateWorkerTelecommunication(workerId: string, telecomId: string, telecomData: any, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}/telecommunications/${telecomId}?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}/telecommunications/${telecomId}`;
    return this.httpservice.put(url, telecomData);
  }

  public deleteWorkerTelecommunication(workerId: string, telecomId: string): Observable<any> {
    return this.httpservice.delete(`/workers/${workerId}/telecommunications/${telecomId}`);
  }

  // Worker Organization Role Operations
  public getWorkerOrganizationRoles(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/orgRoles`);
  }

  // Get available organization report roles for an organization
  public getOrganizationReportRoles(organizationId: string): Observable<any> {
    const url = `/organization-report-roles?organizationId=${organizationId}`;
    return this.httpservice.get(url);
  }

  public createWorkerOrganizationRole(workerId: string, roleData: any): Observable<any> {
    return this.httpservice.post(`/workers/${workerId}/orgRoles`, roleData);
  }

  public updateWorkerOrganizationRole(workerId: string, roleId: string, roleData: any, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}/orgRoles/${roleId}?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}/orgRoles/${roleId}`;
    return this.httpservice.put(url, roleData);
  }

  public deleteWorkerOrganizationRole(workerId: string, roleId: string): Observable<any> {
    return this.httpservice.delete(`/workers/${workerId}/orgRoles/${roleId}`);
  }

  // Worker Status Operations
  public activateWorker(workerId: string, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}/activate?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}/activate`;
    return this.httpservice.put(url, {});
  }

  public inactivateWorker(workerId: string, lockControlNumber?: string): Observable<any> {
    const url = lockControlNumber
      ? `/workers/${workerId}/inactivate?lockControlNumber=${lockControlNumber}`
      : `/workers/${workerId}/inactivate`;
    return this.httpservice.put(url, {});
  }

  // Phone Number Details
  public getPhoneNumberDetail(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/telecommunications`);
  }

  // Advanced Search with SSN
  public getWorkerListWithSSN(ssn: string, includeInactive: boolean, isContractor: boolean, limit: number, skip: number): Observable<any> {
    let url = `/secureWorkers?socialSecurityNumber=${ssn}&includeInactive=${includeInactive}&limit=${limit}&skip=${skip}&sortColumn=lastName&sortOrder=asc`;
    if (isContractor) {
      url += `&isContractor=true`;
    }
    return this.httpservice.get(url);
  }

  // Contractor Firm Operations
  public getContractorsByFirmAdministrator(firmAdmin: string, workerNumber?: string): Observable<any> {
    let url = `/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmAdministrator=${firmAdmin}`;
    if (workerNumber) {
      url += `&workerNumber=${workerNumber}`;
    }
    return this.httpservice.get(url);
  }

  // Worker Status Reports
  public getEmployeeStatusReport(workerNumbers: string[]): Observable<Blob> {
    const url = `/workers/employeeStatusReport?workerNumbers=${workerNumbers.join(',')}`;
    return this.http.getExcelReport(url);
  }

  public getContractorStatusReport(workerNumbers: string[]): Observable<Blob> {
    const url = `/workers/contractorStatusReport?workerNumbers=${workerNumbers.join(',')}`;
    return this.http.getExcelReport(url);
  }

  // Trademark Worker
  public getTrademarkWorker(employeeNumber: string): Observable<any> {
    return this.httpservice.get(`/trademarkWorkers/${employeeNumber}`);
  }

  // Organization Validation
  public validateOrganization(orgCode: string): Observable<any> {
    return this.httpservice.get(`/organizations?orgCode=${orgCode}`);
  }

  // Building and Location Services
  public getBuildings(): Observable<any> {
    return this.httpservice.get('/buildings');
  }

  public getBuilding(buildingId: string): Observable<any> {
    return this.httpservice.get(`/buildings/${buildingId}`);
  }

  // PALM Location Services
  public getPalmLocations(codePrefix: string): Observable<any> {
    return this.httpservice.get(`/palmlocations?codePrefix=${codePrefix}`);
  }

  // Reference Data
  public getCountries(): Observable<any> {
    return this.httpservice.get('/wipocountries');
  }

  public getStates(): Observable<any> {
    return this.httpservice.get('/geoRegions');
  }

  public getJobClasses(): Observable<any> {
    return this.httpservice.get('/references/job-classes');
  }

  public getPayPlans(): Observable<any> {
    return this.httpservice.get('/references/pay-plans');
  }

  public getGrades(): Observable<any> {
    return this.httpservice.get('/references/grades');
  }

  public getSteps(): Observable<any> {
    return this.httpservice.get('/references/steps');
  }

  public getTeleworkPrograms(): Observable<any> {
    return this.httpservice.get('/telework-programs');
  }

  public getDirectoryTitleTypes(): Observable<any> {
    return this.httpservice.get('/references/directory-title-types');
  }

  public getTelecomAddressTypes(): Observable<any> {
    return this.httpservice.get('/references/telcom-address-types?includeInactive=false');
  }

  public getOccupationalSeries(): Observable<any> {
    return this.httpservice.get('/references/occupational-series');
  }

  // Contractor Firms
  public getContractorFirms(): Observable<any> {
    return this.httpservice.get('/references/contractor-firms');
  }

  public getContractorFirmNames(workerNumber: string, applicationType: string): Observable<any> {
    const url = `/references/contractor-firms?workerNumber=${workerNumber}&applicationType=${applicationType}`;
    return this.httpservice.get(url);
  }

  public getContractorsByFirm(firmId: string): Observable<any> {
    const url = `/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmId=${firmId}`;
    return this.httpservice.get(url);
  }

  public moveContractorsToFirm(moveRequest: any): Observable<any> {
    return this.httpservice.put('/workers/firm/association', moveRequest);
  }

  // Tour of Duty
  public getToursOfDuty(): Observable<any> {
    return this.httpservice.get('/toursOfDuty');
  }

  // Create Multiple Contractors (wrapper method for component use)
  public createMultipleContractors(contractors: any[]): Observable<any> {
    return this.getContractorValidCreationResponse(contractors);
  }

  // Location Details
  public getLocationDetails(locationId: string): Observable<any> {
    return this.httpservice.get(`/locations/${locationId}`);
  }

  // PALM Location Details
  public getPalmLocationDetails(palmLocationId: string): Observable<any> {
    return this.httpservice.get(`/palmlocations/${palmLocationId}`);
  }

  // Validate Location Assignment via API
  // API Call: GET /locations?buildingCode=X&corridorPrefix=X&floorPrefix=X&roomPrefix=X&suitePrefix=X&zonePrefix=X&includeInactive=false&mailStopIndicator=false
  public validateLocationAssignment(queryParams: string): Observable<any> {
    return this.httpservice.get(`/locations?${queryParams}`);
  }

  // Organization Details
  public getOrganizationDetails(organizationId: string): Observable<any> {
    return this.httpservice.get(`/organizations/${organizationId}`);
  }


  // Telecommunication Assignment Details
  public getTelecommunicationAssignmentDetails(workerId: number, assignmentId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/assignments/${assignmentId}/telecommunications`);
  }

  // Telecom Types
  public getTelecomTypes(): Observable<any> {
    return this.httpservice.get('/references/telcom-address-types?includeInactive=false');
  }

  // Worker Telework Programs
  public getWorkerTeleworkPrograms(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/teleworkPrograms`);
  }

  // Primary Worker Organization Roles
  public getPrimaryWorkerOrganizationRoles(workerId: number): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/primaryOrgRoles`);
  }

  // Worker Organizations (alternative endpoint)
  public getWorkerOrganizationsDetails(workerId: string): Observable<any> {
    return this.httpservice.get(`/workers/${workerId}/organizationsDetails`);
  }

  // Worker Details References
  public getWorkerDetailsReferences(): Observable<any> {
    // Make parallel calls to all reference endpoints (following legacy pattern)
    // All endpoints return { meta: {...}, results: [...] } structure
    // NOTE: Endpoint names must match ReferenceController TYPES map exactly
    const references$ = [
      this.httpservice.get('/references/tour-of-duties'),
      this.httpservice.get('/references/grades'),
      this.httpservice.get('/references/steps'),
      this.httpservice.get('/references/pay-plans'),
      this.httpservice.get('/references/signatory-authorities'),  // Was: exam-sigs
      this.httpservice.get('/references/position-sensitivities'),  // Was: pos-sens-codes
      this.httpservice.get('/references/leave-accruals'),
      this.httpservice.get('/references/appointment-types'),
      this.httpservice.get('/references/occupational-series'),  // Was: occ-codes
      this.httpservice.get('/references/job-classes'),  // Removed: bus-codes (not in controller)
      this.getOccupationalSeriesTitles('')  // Use dedicated endpoint for title codes
    ];

    return forkJoin(references$).pipe(
      map((responses: any[]) => ({
        tourOfDuties: responses[0]?.results || responses[0]?.data || [],
        grades: responses[1]?.results || responses[1]?.data || [],
        steps: responses[2]?.results || responses[2]?.data || [],
        payPlans: responses[3]?.results || responses[3]?.data || [],
        examSigs: responses[4]?.results || responses[4]?.data || [],  // signatory-authorities
        posSensCodes: responses[5]?.results || responses[5]?.data || [],  // position-sensitivities
        leaveAccruals: responses[6]?.results || responses[6]?.data || [],
        appointmentTypes: responses[7]?.results || responses[7]?.data || [],
        occCodes: responses[8]?.results || responses[8]?.data || [],  // occupational-series
        busCodes: [],  // bus-codes endpoint does not exist in ReferenceController
        jobClasses: responses[9]?.results || responses[9]?.data || [],
        titleCodes: responses[10]?.results || responses[10]?.data || []  // from getOccupationalSeriesTitles
      })),
      catchError((error: any) => {
        console.error('Error loading worker details references:', error);
        return of({
          tourOfDuties: [],
          grades: [],
          steps: [],
          payPlans: [],
          examSigs: [],
          posSensCodes: [],
          leaveAccruals: [],
          appointmentTypes: [],
          occCodes: [],
          busCodes: [],
          jobClasses: [],
          titleCodes: []
        });
      })
    );
  }

  // Contractor Details References
  public getContractorDetailsReferences(): Observable<any> {
    return this.httpservice.get('/references/contractorDetails');
  }

  // Worker Confidential References
  public getWorkerConfidentialReferences(): Observable<any> {
    return this.httpservice.get('/references/workerConfidential');
  }

  // Worker Status Excel Report - POST endpoint for CSV download
  public getWorkerStatusExcelReport(workerNumbers: string[]): Observable<Blob> {
    const url = '/workers/statusExcelReport';
    return this.http.postForCsv(url, workerNumbers);
  }

  // Worker Override Operations
  public getWorkerOverrides(workerId: string, includeInactive: boolean = false, useCache: boolean = true): Observable<any> {
    // GET /worker-override/{workerId}?includeInactive=false
    const url = `/worker-override/${workerId}?includeInactive=${includeInactive}`;
    return this.httpservice.get(url, useCache);
  }

  public createOverride(workerId: string, overrideData: any): Observable<any> {
    // POST /worker-override - workerId is in the payload, not URL
    const url = `/worker-override`;
    return this.httpservice.post(url, overrideData);
  }

  public updateOverride(overrideData: any): Observable<any> {
    // PUT /worker-override/{workerOverrideId} - use updateOverrideId instead
    const url = `/worker-override`;
    return this.httpservice.post(url, overrideData);
  }

  public updateOverrideId(workerOverrideId: string, overrideData: any): Observable<any> {
    // PUT /worker-override/{workerOverrideId}
    const url = `/worker-override/${workerOverrideId}`;
    return this.httpservice.put(url, overrideData);
  }

  public deleteOverride(workerOverrideId: string, overrideData: any): Observable<any> {
    // PUT /worker-override/{workerOverrideId} with isActive: false
    const url = `/worker-override/${workerOverrideId}`;
    return this.httpservice.put(url, overrideData);
  }

  public getOverrideProperties(): Observable<any> {
    const url = `/worker-override-property/`;
    return this.httpservice.get(url);
  }

  public getOccupationalSeriesTitles(occupationalSeriesId: string): Observable<any> {
    const url = `/occupational-series-titles?includeInactive=true&occupationalSeriesId=${occupationalSeriesId}`;
    return this.httpservice.get(url);
  }
}
