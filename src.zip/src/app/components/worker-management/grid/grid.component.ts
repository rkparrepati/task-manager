import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AppService } from 'src/app/services/app.service';
import { MatSort } from '@angular/material/sort';
import { WorkerManagementService } from '../worker-management.service';
/**
 * @title Table with expandable rows
 */
@Component({
  selector: 'app-grid',
  styleUrls: ['grid.component.scss'],
  templateUrl: 'grid.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class GridComponent implements OnInit, OnChanges {
  @Input() dataSource: any = { meta: {}, results: [] };
  @Input() userRoles: any = [];
  @Input() applicationType: String = 'Worker';
  @Input() isContractor: boolean = false;
  @Input() jobClassMap: any = {}; // Map of job class codes to descriptions
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  total: any;
  sortColumn: any = 'lastName';
  sortDirection: any = 'asc';
  resort: any;
  updateWorkerButton: any;
  workerModel: any = { workerList: [], selectedWorker: {} };
  userInfo: any;
  worker: any = {};
  phoneNumberDetail: any = {};
  expandedElement: any | null;
  @Output() sortChange: EventEmitter<any> = new EventEmitter();
  
  ngOnInit(): void {}
  
  displayedColumns: string[] = [
    'status',
    'applicationTypeNumber',
    'lastName',
    'firstName',
    'preferredFirstName',
    'loginId',
    'acronym',
    'building',
    'location',
    'jobClass',
    'firmName',
    'phoneNumber',
    'actions',
  ];

  constructor(
    private appService: AppService,
    private workerService: WorkerManagementService
  ) {}
  
  ngOnChanges(changes: SimpleChanges) {
    // No need to create MatTableDataSource - we'll use dataSource.results directly in template
  }

  /**
   * Navigate to worker edit page with appropriate edit mode
   * @param worker Worker object to edit
   * @param type Edit mode: 'A' (Admin), 'O' (Office Coordinator), 'N' (Normal/View)
   */
  getWorkerUpdateObject(worker: any, type: string = ''): void {
    if (!type && this.userRoles && this.userRoles.indexOf('InfraAdmin') !== -1) {
      type = 'A';
    } else if (!type) {
      type = 'N';
    }
    this.workerService.setSelectedWorkerDetails(worker);
    this.appService.changePage(
      '/app/workerUpdate/' +
        worker.workerId +
        '/' +
        worker.workerNumber +
        '/' +
        this.applicationType +
        '/' +
        type
    );
  }


  getTemplateWorkerSearch(worker: any) {
    if (
      worker &&
      this.workerModel &&
      this.workerModel.selectedWorker &&
      this.workerModel.selectedWorker.workerId &&
      worker.workerId === this.workerModel.selectedWorker.workerId
    ) {
      return 'detail';
    } else {
      return 'view';
    }
  }

  /**
   * Expand row to show phone number and location details
   * Calls the worker telecommunications API endpoint to fetch primary communication data
   * Filters to show only the record with primaryIndicator: true
   */
  expandPhoneNumber(worker: any): void {
    this.phoneNumberDetail = null;
    this.workerModel.selectedWorker = worker;
    // Call the API to fetch worker telecommunications and filter for primary indicator
    this.workerService.getWorkerTelecommunications(worker.workerId).subscribe(
      (response) => {
        // Filter to get only the record with primaryIndicator: true
        const results = response?.results || response;
        const primaryTelecom = Array.isArray(results)
          ? results.find((telecom: any) => telecom.primaryIndicator === true)
          : results;
        this.phoneNumberDetail = primaryTelecom || (Array.isArray(results) ? results[0] : results);
      },
      (error) => {
        console.error('Error fetching worker telecommunications:', error);
      }
    );
  }

  clickedOnSort(event: any): void {
    this.sortChange.emit(event);
  }

  /**
   * Toggle sort direction for last name column
   */
  toggleLastNameSort(): void {
    // Cycle through: asc -> desc -> asc
    if (this.sortDirection === 'asc') {
      this.sortDirection = 'desc';
    } else {
      this.sortDirection = 'asc';
    }
    
    // Emit sort change event with proper format
    // Note: 'active' should be the column name, not the API field name
    // The parent component will handle the mapping
    const sortEvent = {
      active: 'lastName',
      direction: this.sortDirection
    };
    this.sortChange.emit(sortEvent);
  }

  /**
   * Extract primary organization acronym from organization history
   */
  getPrimaryOrganization(organizationHistory: Array<any>): string {
    if (!organizationHistory || organizationHistory.length === 0) {
      return '';
    }

    let acronym = '';
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organization = organizationHistory[i];
      if (organization.primaryOrganizationIndicator && organization.organization) {
        acronym =
          organization.organization.businessAreaCode + '/' + organization.organization.shortName;
        break;
      }
    }
    return acronym;
  }

  /**
   * Extract building code from organization location summary
   */
  getBuildingData(organizationHistory: Array<any>): string {
    if (!organizationHistory || organizationHistory.length === 0) {
      return '';
    }

    let building = '';
    let position = -1;
    const len = organizationHistory.length;
    
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary &&
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
        break;
      }
    }

    if (position >= 0 && organizationHistory[position].locationSummary) {
      const locationSummary = organizationHistory[position].locationSummary[0]?.locationSummary;
      if (locationSummary && locationSummary.building) {
        building = locationSummary.building.code || '';
      }
    }
    return building;
  }

  /**
   * Build formatted location string from location components
   */
  getLocation(organizationHistory: Array<any>): string {
    if (!organizationHistory || organizationHistory.length === 0) {
      return '';
    }

    let location = '';
    let position = -1;
    const len = organizationHistory.length;
    
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary &&
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
        break;
      }
    }

    if (position >= 0 && organizationHistory[position].locationSummary) {
      const locationSummary = organizationHistory[position].locationSummary[0]?.locationSummary;
      if (locationSummary) {
        let floor = locationSummary.building?.floorNumber || '';
        let corridor = locationSummary.corridorId || null;
        let room = locationSummary.roomId || null;
        let zone = locationSummary.zoneId || null;
        let suite = locationSummary.suiteId || null;

        if (corridor == null && room == null && zone == null && suite == null) {
          location = floor;
        } else if (corridor == null && zone == null && suite == null) {
          location = floor + '/' + room;
        } else if (room == null && zone == null && suite == null) {
          location = floor + '/' + corridor;
        } else if (zone == null && suite == null) {
          location = floor + '/' + corridor + room;
        } else if (suite == null) {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '/' + corridor + room + zone;
        } else {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '-' + suite + '/' + corridor + room + zone;
        }
      }
    }
    return location;
  }

  /**
   * Get supervisor indicator from worker data
   */
  getSupervisorIndicator(worker: any): string {
    return worker.supervisorIndicator ? 'Y' : 'N';
  }

  /**
   * Get job class display with description
   * Handles different data structures (string, object with value, object with description)
   */
  getJobClassDisplay(jobClass: any): string {
    if (!jobClass) {
      return '';
    }
    // If jobClass has a description, use it
    if (jobClass.description) {
      return jobClass.description;
    }
    // If jobClass has a value, use it
    if (jobClass.value) {
      return jobClass.value;
    }
    // If jobClass is a string, use it directly
    if (typeof jobClass === 'string') {
      return jobClass;
    }
    return '';
  }

  /**
   * Format phone number with tel format
   */
  formatPhoneNumber(phoneNumber: string): string {
    if (!phoneNumber) {
      return '';
    }
    // Remove all non-digit characters
    const cleaned = phoneNumber.replace(/\D/g, '');
    // Format as (XXX) XXX-XXXX
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phoneNumber;
  }

  collapsePhoneNumber(): void {
    this.workerModel.selectedWorker = {};
  }
}
