import { Component, Inject, ChangeDetectorRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { WorkerManagementService } from '../worker-management.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-accession-select-dialog',
  templateUrl: './accession-select-dialog.component.html',
  styleUrls: ['./accession-select-dialog.component.scss'],
})
export class AccessionSelectDialogComponent {
  worker: any;
  workerNumber: string = '';
  generateMode: boolean = false;
  selectPrintBy: string = 'workerNumber';
  selectWorkerType: string = 'employee';
  invalidWorkerNumber: boolean = false;
  workerNumberErrorMsg: string = '';
  invalidStartDate: boolean = false;
  invalidEndDate: boolean = false;
  noDateFound: boolean = false;
  beginDateErrorMessage: string = '';
  endDateErrorMessage: string = '';
  fromDate: any;
  toDate: any;
  showWait: boolean = false;
  workerId: string = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<AccessionSelectDialogComponent>,
    private router: Router,
    private workerManagementService: WorkerManagementService,
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private utilityService: UtilityService,
    private httpService: HttpService
  ) {
    this.worker = this.data;
    this.generateMode = !this.worker;

    if (this.worker) {
      this.workerNumber = this.worker.workerNumber;
      this.workerId = this.worker.workerId;
    }
  }

  fullReport(page: string): void {


    this.router.navigate(['/app/workerForms']).then(
      (success) => {

        this.dialogRef.close('upload');
      },
      (error) => {

      }
    );
  }

  getReport(type: string): void {
    if (this.selectPrintBy === 'workerNumber') {
      this.printByWorkerNumber(type);
    } else {
      this.printByDateRange(type);
    }
  }

  private printByWorkerNumber(type: string): void {
    this.workerNumberErrorMsg = '';
    this.invalidWorkerNumber = false;
    const workerNotFound: string[] = [];

    if (!this.workerNumber) {
      this.invalidWorkerNumber = true;
      this.workerNumberErrorMsg = 'Please enter a worker number';
      this.cdr.detectChanges();
      return;
    }

    if (this.workerId) {
      // Single worker from worker details page - open report with authentication
      this.openPdfInNewTab(`/workers/${this.workerId}/${type}`);
    } else {
      // Multiple workers by worker numbers
      const split = this.workerNumber.split(',');
      const promises: Promise<any>[] = [];

      for (let i = 0; i < split.length; i++) {
        const workerNum = split[i].trim();
        if (workerNum) {
          promises.push(
            this.workerManagementService.getWorkerByWorkerNumber(workerNum).toPromise()
          );
        }
      }

      Promise.allSettled(promises).then((responses) => {
        let workerList = '';
        const users: any[] = [];

        for (let i = 0; i < responses.length; i++) {
          if (responses[i].status === 'fulfilled') {
            const result = (responses[i] as PromiseFulfilledResult<any>).value;
            if (result && result.results && result.results.length > 0) {
              users.push(result.results[0]);
              if (workerList !== '') {
                workerList = workerList + ',' + result.results[0].workerId;
              } else {
                workerList = result.results[0].workerId;
              }
            } else {
              // Worker number returned but no results found
              workerNotFound.push(split[i].trim());
            }
          } else {
            // Request failed - worker not found
            const reason = (responses[i] as PromiseRejectedResult).reason;
            // Extract worker number from the split array based on index
            workerNotFound.push(split[i].trim());
          }
        }

        // Display error message if any worker numbers were not found
        if (workerNotFound.length > 0) {
          this.invalidWorkerNumber = true;
          this.workerNumberErrorMsg = workerNotFound.join(', ') + ' Worker number(s) not found';
          this.cdr.detectChanges();
        }

        // Open the report in a new tab only if we have valid worker IDs
        if (workerList) {
          this.openPdfInNewTab(`/workers/${workerList}/${type}`);
        }
      });
    }
  }

  private printByDateRange(type: string): void {
    this.workerNumberErrorMsg = '';
    this.invalidStartDate = false;
    this.invalidEndDate = false;
    this.noDateFound = false;
    this.showWait = true;

    this.validateDates();

    if (this.invalidStartDate || this.invalidEndDate) {
      this.showWait = false;
      this.cdr.detectChanges();
      return;
    }

    if (this.compareDates(new Date(this.fromDate), new Date(this.toDate)) >= 0) {
      this.endDateErrorMessage = 'To date must be after From date';
      this.invalidEndDate = true;
      this.showWait = false;
      this.cdr.detectChanges();
      return;
    }

    this.sendPrint(type);
  }

  private validateDates(): void {
    if (!this.fromDate) {
      this.beginDateErrorMessage = 'From date is required';
      this.invalidStartDate = true;
    }

    if (!this.toDate) {
      this.invalidEndDate = true;
      this.endDateErrorMessage = 'To date is required';
    }
    
    this.cdr.detectChanges();
  }

  private compareDates(date1: Date, date2: Date): number {
    const time1 = date1.getTime();
    const time2 = date2.getTime();
    if (time1 < time2) return -1;
    if (time1 > time2) return 1;
    return 0;
  }

  private sendPrint(type: string): void {
    const fromDateStr = this.fromDate.substring(0, this.fromDate.indexOf('T'));
    const toDateStr = this.toDate.substring(0, this.toDate.indexOf('T'));
    const isContractorInd = this.selectWorkerType === 'employee' ? 'false' : 'true';

    // Download the Excel file directly - need full URL with domain
    const url = `${this.httpService.DOMAIN}/workers/${type}?fromDate=${fromDateStr}&toDate=${toDateStr}&isContractor=${isContractorInd}`;
    const fileName = `${type}.xls`;
    const fileType = 'application/vnd.ms-excel';
    
    this.utilityService.exportTableService(url, fileName, fileType);
    
    this.showWait = false;
    this.cdr.detectChanges();
  }

  /**
   * Opens a PDF report in a new tab using blob URL with authentication
   * @param path - The API path for the PDF report
   */
  private openPdfInNewTab(path: string): void {
    const url = `${this.httpService.DOMAIN}${path}`;
    
    this.httpService.getExcelReport(url).subscribe({
      next: (blob: Blob) => {
        const blobUrl = URL.createObjectURL(blob);
        const newWindow = window.open(blobUrl, '_blank');
        
        // Clean up the blob URL after a delay to ensure it loads
        if (newWindow) {
          setTimeout(() => {
            URL.revokeObjectURL(blobUrl);
          }, 100);
        }
      },
      error: (error) => {

        this.invalidWorkerNumber = true;
        this.workerNumberErrorMsg = 'Error loading report. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  closeWorkerDialog(message: string): void {
    this.dialogRef.close(message);
  }
}
