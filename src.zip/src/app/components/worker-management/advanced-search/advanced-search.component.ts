import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Building, BuildingResults } from 'src/app/shared/interfaces/models';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { WorkerManagementService } from '../worker-management.service';

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  styleUrls: ['./advanced-search.component.scss'],
})
export class AdvancedSearchComponent implements OnInit {
  ssnMask = { mask: '000-00-0000' };
  @Output() public advanceSearch = new EventEmitter();
  constructor(
    private organizationService: OrganizationService,
    private workerManagementService: WorkerManagementService
  ) {}

  ngOnInit(): void {
    this.organizationService.getBuildings().subscribe((res: any) => {
      this.buildingCodeList = res.results as BuildingResults[];
    });

    this.organizationService.getFirms().subscribe((res: any) => {
      this.contractorFirmNames = res.results;
    });

    this.workerManagementService.getJobClasses().subscribe((res: any) => {
      this.jobClassCodeList = res.results || res;
    });
  }
  workerModel: any;
  basicSearch: any;
  savedSearchCriteria: any;
  basicSearchText: any;
  selectedSearchCriteria: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  searchResultsCount: any;
  basicSearchAcronym: any;
  basicSearchCriteria: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchSSNDiv: any;
  basicSearchFirmnameDiv: any;
  basicSearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  basicSearchDOBDiv: any;
  basicSearchLoginDiv: any;
  userInfo: any;
  workerNumber: any = 123;
  addWorkerButton: any;
  buildingFloors: any;
  userRoles: any = ['InfraAdmin'];
  isContractor: any;
  hideSSN: any;
  applicationType: any;
  hideFirms: any;
  cedrRoleSearch: any;
  invalidBirthDate: any;
  birthDateErrorMessage: any;
  hideBuildingSearch: any;
  acronymInvalid: any;
  acronymEnter: any;
  advanceSearchAcronym: any;
  invalidAdvancedAcronym: any;
  hidePhoneNumberSearch: any;
  jobClassCodeList: any;
  buildingCodeList: any[] = [];
  contractorFirmNames: any[] = [];
  status: boolean = true;
  advanceSearchOptions = {
    ssn: {
      value: 'socialSecurityNumber',
      description: '',
    },
    workerNumber: {
      value: 'workerNumber',
      description: '',
    },
    lastName: {
      value: 'familyName',
      description: '',
    },
    firstName: {
      value: 'givenName',
      description: '',
    },
    preferredFirstName: {
      value: 'preferredFirstName',
      description: '',
    },
    loginId: {
      value: 'loginId',
      description: '',
    },
    ssn2: {
      value: 'ssn2',
      description: '',
    },
    birthDate: {
      value: 'birthDate',
      description: '',
    },
    classCode: {
      value: 'classCode',
      description: '',
    },
    firmName: {
      value: 'firmName',
      description: '',
    },
    firmAdministrator: {
      value: 'firmAdministrator',
      description: '',
    },
    businessAreaCode: {
      value: 'businessAreaCode',
      description: '',
    },
    shortName: {
      value: 'shortName',
      description: '',
    },
    workerAssociatedFirms: {
      value: 'workerAssociatedFirms',
      description: true,
    },
    loginWorkerNumber: {
      value: 'loginWorkerNumber',
      description: this.workerNumber,
    },
    phoneNumber: {
      value: 'phoneNumber',
      description: '',
    },
    buildingCode: {
      value: 'buildingCode',
      description: '',
    },
    floorNumber: {
      value: 'floorNumber',
      description: '',
    },
    corridorId: {
      value: 'corridorId',
      description: '',
    },
    roomId: {
      value: 'roomId',
      description: '',
    },
    suiteId: {
      value: 'suiteId',
      description: '',
    },
    zoneId: {
      value: 'zoneId',
      description: '',
    },
    cedrRoles: {
      value: 'cedrRoles',
      description: '',
    },
  };
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
  setSearchType(searchType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria?.value || this.selectedSearchCriteria,
        },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo?.workerNumber,
      };
      this.clearAdvanvedSearch();
    } else {
      if (this.checkBlankAdvanceSearch()) {
        this.searchResultsCount = '';
        return;
      }
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchAcronym = '';
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
    }

    this.advanceSearch.emit(this.advanceSearchOptions);
  }
  checkBlankAdvanceSearch() {
    if (
      this.advanceSearchOptions.ssn2.description ||
      this.advanceSearchOptions.birthDate.description ||
      this.advanceSearchOptions.classCode.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firmName.description ||
      this.advanceSearchOptions.businessAreaCode ||
      this.advanceSearchOptions.shortName.description ||
      this.advanceSearchOptions.firmAdministrator.description ||
      this.advanceSearchOptions.cedrRoles.description
    ) {
      return false;
    }

    return this.checkBlankAdvanceSearchHelper();
  }
  checkBlankAdvanceSearchHelper() {
    if (
      this.advanceSearchOptions.ssn.description ||
      this.advanceSearchOptions.workerNumber.description ||
      this.advanceSearchOptions.lastName.description ||
      this.advanceSearchOptions.phoneNumber.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firstName.description ||
      this.advanceSearchOptions.preferredFirstName.description ||
      this.advanceSearchOptions.loginId.description ||
      this.advanceSearchOptions.buildingCode.description
    ) {
      return false;
    }
    return true;
  }
  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }
  buildingChanged() {
    this.buildingFloors = [];
    const index = this.buildingCodeList.findIndex(
      (x) => this.advanceSearchOptions.buildingCode.description === x.buildingDescription
    );
    this.buildingFloors = this.buildingCodeList[index].buildingFloors;
  }
  clearAdvanvedSearch() {
    this.setAdvanceSearchOptions();
    this.advanceSearchAcronym = '';
    this.invalidAdvancedAcronym = false;
    this.acronymInvalid = false;
  }
  setAdvanceSearchOptions() {
    this.advanceSearchOptions = {
      ssn: {
        value: 'socialSecurityNumber',
        description: '',
      },
      workerNumber: {
        value: 'workerNumber',
        description: '',
      },
      lastName: {
        value: 'familyName',
        description: '',
      },
      firstName: {
        value: 'givenName',
        description: '',
      },
      preferredFirstName: {
        value: 'preferredFirstName',
        description: '',
      },
      loginId: {
        value: 'loginId',
        description: '',
      },
      ssn2: {
        value: 'ssn2',
        description: '',
      },
      birthDate: {
        value: 'birthDate',
        description: '',
      },
      classCode: {
        value: 'classCode',
        description: '',
      },
      firmName: {
        value: 'firmName',
        description: '',
      },
      firmAdministrator: {
        value: 'firmAdministrator',
        description: '',
      },
      businessAreaCode: {
        value: 'businessAreaCode',
        description: '',
      },
      shortName: {
        value: 'shortName',
        description: '',
      },
      workerAssociatedFirms: {
        value: 'workerAssociatedFirms',
        description: true,
      },
      loginWorkerNumber: {
        value: 'loginWorkerNumber',
        description: '',
        //description : this.userInfo.workerNumber
      },
      phoneNumber: {
        value: 'phoneNumber',
        description: '',
      },
      buildingCode: {
        value: 'buildingCode',
        description: '',
      },
      floorNumber: {
        value: 'floorNumber',
        description: '',
      },
      corridorId: {
        value: 'corridorId',
        description: '',
      },
      roomId: {
        value: 'roomId',
        description: '',
      },
      suiteId: {
        value: 'suiteId',
        description: '',
      },
      zoneId: {
        value: 'zoneId',
        description: '',
      },
      cedrRoles: {
        value: 'cedrRoles',
        description: '',
      },
    };
  }
}
