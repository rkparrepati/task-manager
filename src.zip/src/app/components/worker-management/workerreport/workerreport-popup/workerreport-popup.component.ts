import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  AfterViewInit,
  NgZone,
  ChangeDetectorRef,
} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { HttpService } from 'src/app/services/http.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { DatePipe } from '@angular/common';
import jspdf, { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
// import jsPDF from 'jspdf';
// import autoTable from 'jspdf-autotable';
interface workerreport {
  selectWorkerType: string;
  workerNumber: string;
  selectPrintBy: string;
  showWait: boolean;
  invalidWorkerNumber: boolean;
  generateMode: boolean;
  invalidStartDate: boolean;
  invalidEndDate: boolean;
  noDateFound: boolean;
  endDateErrorMessage: string;
  beginDateErrorMessage: string;
  fromDate: any;
  toDate: any;
}
interface pdfReport {
  name: string;
  emplid: string;
  organizationalCode: string;
  eodDate: string;
  typeOfAppointmen: string;
  payPlan: string;
  tourOfDuty: string;
  leaveAccrual: string;
  title: boolean;
}
@Component({
  selector: 'app-workerreport-popup',
  templateUrl: './workerreport-popup.component.html',
  styleUrls: ['./workerreport-popup.component.scss'],
})
export class WorkerreportPopupComponent implements OnInit, AfterViewInit {
  @ViewChild('contentToConvert') contentToConvert!: ElementRef;

  workerreport: workerreport = {
    selectWorkerType: 'employee',
    workerNumber: '',
    selectPrintBy: 'workerNumber',
    showWait: false,
    invalidWorkerNumber: false,
    generateMode: true,
    invalidStartDate: false,
    invalidEndDate: false,
    noDateFound: false,
    endDateErrorMessage: '',
    beginDateErrorMessage: '',
    fromDate: undefined,
    toDate: undefined,
  };
  pdfReport: pdfReport = {
    name: '',
    emplid: '',
    organizationalCode: '',
    eodDate: '',
    typeOfAppointmen: '',
    payPlan: '',
    tourOfDuty: '',
    leaveAccrual: '',
    title: false,
  };
  userInfo: any;
  pdfUrl: string | null = null;
  reportData: any = null;
  constructor(
    private router: Router,
    private httpService: HttpService,
    public dialogRef: MatDialogRef<WorkerreportPopupComponent>,
    private reportserviceService: ReportserviceService,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {}
  closeWorkerDialog(message: string) {
    this.dialogRef.close(message);
  }
  fUrl: string | null = null; // To store the generated PDF blob URL
  ngAfterViewInit() {
    if (this.contentToConvert) {
      // Always a good practice to check for existence

      if (this.pdfReport.payPlan != '' && this.pdfReport.payPlan != null) {
      }
      // Your logic here
    }
  }
  formatDate(inputDateString: string): string {
    const dateObject = new Date(inputDateString);
    let dateVal = this.datePipe.transform(dateObject, 'dd/MM/yyyy');
    if (dateVal == null) {
      dateVal = '';
    }
    return dateVal;
  }
  getReport(reportType: string) {
    if (this.workerreport.workerNumber == '' || this.workerreport.workerNumber == null) {
      return;
    }
    this.reportserviceService
      .getworkerByNumber(this.workerreport.workerNumber)
      .subscribe((res: any) => {
        if (res.results.length > 0) {
          this.pdfReport.name = res.results[0].familyName + ',' + res.results[0].givenName;
          this.pdfReport.emplid = res.results[0].workerNumber;
          this.pdfReport.organizationalCode = res.results[0].positionOrganizationListing;
          this.pdfReport.eodDate = this.formatDate(res.results[0].lifecycle.beginDate);
          this.pdfReport.typeOfAppointmen = res.results[0].appointmentType.description;
          this.pdfReport.tourOfDuty = res.results[0].standardTourOfDuty.description;
          this.pdfReport.leaveAccrual = res.results[0].leaveAccrual.description;
          this.pdfReport.title = res.results[0].occupationalSeries.description;
          this.pdfReport.payPlan = res.results[0].payPlan.currentPayPlan.value; //+"/"+res.results[0].currentGrade.description+"/"+res.results[0].currentStep.description;

          // var url =
          //   environment.OAUTH2_REDIRECT_URI +
          //   this.httpService.DOMAIN +
          //   '/workers/' +
          //   res.results[0].workerId +
          //   '/' +
          //   reportType;
          this.cdr.detectChanges();
          this.generateAndPreviewPdf();
        }
      });
  }

  public generateAndPreviewPdf(): void {
    const data = this.contentToConvert.nativeElement;
    html2canvas(data).then((canvas) => {
      // Few necessary setting options
      const imgWidth = 280; // A4 width in mm
      const pageHeight = 295; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      const contentDataURL = canvas.toDataURL('image/png');

      // Create a new jsPDF instance (A4 size, portrait orientation)
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: [310, 297], // Custom width and height
      });
      let position = 0;

      // Add the image to the PDF
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);

      // To preview and print in a new tab:
      // 1. Generate the PDF as a Data URI string
      const pdfDataUri = pdf.output('datauristring');

      // 2. Open a new window
      const newWindow = window.open('', '_blank');

      if (newWindow) {
        // 3. Write an iframe into the new window's document to display the PDF
        newWindow.document.write(`
          <html>
          <head>
            <title>PDF Preview</title>
            <style>
              body { margin: 0; padding: 0; height: 100vh; }
              iframe { width: 100%; height: 100%; border: none; }
            </style>
          </head>
          <body>
            <!-- The Data URI is set as the source of the iframe -->
            <iframe src="${pdfDataUri}"></iframe>
            <script>
              // Optional: Automatically trigger the print dialog once loaded
              // Note: Modern browser popup blockers might interfere with auto-print
              // window.onload = function() {
              //   setTimeout(() => window.print(), 1000); 
              // }
            </script>
          </body>
          </html>
        `);
        newWindow.document.close();
      } else {
        alert('Please allow popups for preview functionality.');
      }
    });
  }
}
