import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import * as XLSX from 'xlsx';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-workerreport',
  templateUrl: './workerreport.component.html',
  styleUrls: ['./workerreport.component.scss'],
})
export class WorkerreportComponent implements OnInit {
  importFile: File | null = null;
  workerNumbers: string[] = [];
  invalidWorkerNumber: boolean = false;
  workerNumberErrorMsg: string = '';
  isAccession: boolean = false;
  isAffidavit: boolean = false;

  constructor(
    private reportserviceService: ReportserviceService,
    private appService: AppService,
    private httpService: HttpService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {}

  downloadTemplate(): void {
    const link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/uploads/AccessionAffidavitFormsTemplate.xls';
    link.download = 'AccessionAffidavitFormsTemplate.xls';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  onFileChange(event: any): void {
    this.importFile = event.target.files[0];
    this.invalidWorkerNumber = false;
    this.workerNumberErrorMsg = '';
    this.isAccession = false;
    this.isAffidavit = false;
  }

  processExcelFile(type: string): void {
    if (!this.importFile) {
      return;
    }

    // Set report type flags
    if (type === 'accessionreport') {
      this.isAccession = true;
      this.isAffidavit = false;
    } else {
      this.isAffidavit = true;
      this.isAccession = false;
    }

    const regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xls|.xlsx)$/;
    if (!regex.test(this.importFile.name.toLowerCase())) {
      this.invalidWorkerNumber = true;
      this.workerNumberErrorMsg = 'Invalid file format. Please upload an Excel file (.xls or .xlsx)';
      return;
    }

    const reader = new FileReader();
    reader.onload = (e: any) => {
      try {
        const bufferArray = e.target.result;
        const workbook: XLSX.WorkBook = XLSX.read(bufferArray, { type: 'array' });

        // Get the first sheet
        const sheetName: string = workbook.SheetNames[0];
        const worksheet: XLSX.WorkSheet = workbook.Sheets[sheetName];

        // Convert to JSON
        const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, { raw: true });

        // Extract worker numbers from "Emp Id" column
        this.workerNumbers = [];
        jsonData.forEach((row: any) => {
          const id = row['Emp Id'];
          if (id) {
            this.workerNumbers.push(id.toString());
          }
        });

        if (this.workerNumbers.length === 0) {
          this.invalidWorkerNumber = true;
          this.workerNumberErrorMsg = 'No worker numbers found in the uploaded file';
          return;
        }

        // Validate worker numbers and generate report
        this.printByWorkerNumber(type);
      } catch (error) {

        this.invalidWorkerNumber = true;
        this.workerNumberErrorMsg = 'Error reading Excel file. Please check the file format.';
      }
    };

    reader.onerror = (error) => {

      this.invalidWorkerNumber = true;
      this.workerNumberErrorMsg = 'Error reading file';
    };

    reader.readAsArrayBuffer(this.importFile);
  }

  printByWorkerNumber(type: string): void {
    this.invalidWorkerNumber = false;
    this.workerNumberErrorMsg = '';

    if (this.workerNumbers.length === 0) {
      this.invalidWorkerNumber = true;
      this.workerNumberErrorMsg = 'No worker numbers to process';
      return;
    }

    // Create promises for all worker lookups
    const promises = this.workerNumbers.map((workerNumber) =>
      this.reportserviceService.getWorkerByWorkerNumber(workerNumber, true).toPromise()
    );

    Promise.allSettled(promises).then((responses) => {
      const workerList: string[] = [];
      const workerNotFound: string[] = [];

      responses.forEach((response, index) => {
        if (response.status === 'fulfilled') {
          const data = response.value;
          if (data && data.results && data.results.length > 0) {
            workerList.push(data.results[0].workerId);
          } else {
            workerNotFound.push(this.workerNumbers[index]);
          }
        } else {
          workerNotFound.push(this.workerNumbers[index]);
        }
      });

      if (workerNotFound.length > 0) {
        this.invalidWorkerNumber = true;
        this.workerNumberErrorMsg = `${workerNotFound.join(', ')} Worker number(s) not found`;
        this.cdr.detectChanges();
      }

      if (workerList.length > 0) {
        const workerIds = workerList.join(',');
        // Use blob-based approach for authenticated PDF/Excel preview
        this.openReportInNewTab(`/workers/${workerIds}/${type}`);
      }
    });
  }

  /**
   * Opens a PDF/Excel report in a new tab using blob URL with authentication
   * This method follows the same pattern as accession-select-dialog component
   * @param path - The API path for the report (e.g., '/workers/{ids}/accessionreport')
   */
  private openReportInNewTab(path: string): void {
    const url = `${this.httpService.DOMAIN}${path}`;
    
    this.httpService.getExcelReport(url).subscribe({
      next: (blob: Blob) => {
        // Create a blob URL from the response
        const blobUrl = URL.createObjectURL(blob);
        
        // Open the blob URL in a new tab
        const newWindow = window.open(blobUrl, '_blank');
        
        // Clean up the blob URL after a delay to ensure it loads
        if (newWindow) {
          setTimeout(() => {
            URL.revokeObjectURL(blobUrl);
          }, 100);
        } else {
          // If popup was blocked, clean up immediately
          URL.revokeObjectURL(blobUrl);
          this.invalidWorkerNumber = true;
          this.workerNumberErrorMsg = 'Please allow popups to view the report.';
          this.cdr.detectChanges();
        }
      },
      error: (error) => {

        this.invalidWorkerNumber = true;
        this.workerNumberErrorMsg = 'Error loading report. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }
}
