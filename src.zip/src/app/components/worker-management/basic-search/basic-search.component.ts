import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-search',
  templateUrl: './basic-search.component.html',
  styleUrls: ['./basic-search.component.scss'],
})
export class BasicSearchComponent implements OnInit {
  @Input() applicationTypeLowerCase: string = '';
  @Input() basicSearchCriteria: any[] = [];
  @Output() search: EventEmitter<any> = new EventEmitter();

  workerModel: any;
  basicSearch: any;
  savedSearchCriteria: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  basicSearchText: any;
  selectedSearchCriteria: any;
  clearAdvanvedSearch: any;
  checkBlankAdvanceSearch: any;
  userInfo: any;
  searchResultsCount: any;
  basicSearchAcronym: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchSSNDiv: any;
  basicSearchFirmnameDiv: any;
  basicSearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  basicSearchDOBDiv: any;
  basicSearchLoginDiv: any;
  invalidBasicSearchText: any;
  invalidAcronym: any;
  basicSearchfirmAdministratorDiv: any;
  
  constructor() {
    this.selectedSearchCriteria = 'workerNumber';
  }

  ngOnInit() {
    // Set default criteria if not provided via @Input
    if (!this.basicSearchCriteria || this.basicSearchCriteria.length === 0) {
      this.basicSearchCriteria = [
        { value: 'workerNumber', description: 'Worker number' },
        { value: 'familyName', description: 'Last name' },
        { value: 'givenName', description: 'First name' },
        { value: 'preferredFirstName', description: 'Preferred first name' },
        { value: 'mulWorkerNumber', description: 'Worker numbers (comma-separated)' },
      ];
    }
  }

  setSearchType() {
    // Handle multiple worker numbers
    let searchCriteria = this.selectedSearchCriteria?.value || this.selectedSearchCriteria;
    let searchText = this.basicSearchText;

    // For multiple worker numbers, convert comma-separated to proper format
    if (searchCriteria === 'mulWorkerNumber' && searchText) {
      searchCriteria = 'mulWorkerNumber';
    }

    this.search.emit({
      searchType: searchCriteria,
      searchText: searchText,
      searchCriteria: searchCriteria,
    });
  }

  setBasicSearchInputBox() {
    this.invalidBasicSearchText = false;
    this.invalidAcronym = false;
    if (this.selectedSearchCriteria.value === 'acronym') {
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = true;
      this.basicSearchText = '';
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchfirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
    } else {
      if (this.selectedSearchCriteria.value === 'SSN') {
        this.basicSearchSSNDiv = true;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchLoginDiv = false;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.basicSearchText = '';
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'firmName') {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = true;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.basicSearchLoginDiv = false;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
        this.basicSearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'firmAdministrator') {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchfirmAdministratorDiv = true;
        this.cedrRolesDiv = false;
        this.basicSearchLoginDiv = false;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
        this.basicSearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'cedrRoles') {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = true;
        this.basicSearchLoginDiv = false;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
        this.basicSearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'birthDate') {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.basicSearchLoginDiv = false;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
        this.basicSearchDOBDiv = true;
      } else if (this.selectedSearchCriteria.value === 'loginId') {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = false;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.basicSearchDOBDiv = false;
        this.basicSearchLoginDiv = true;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
      } else {
        this.basicSearchSSNDiv = false;
        this.basicSearchDiv = true;
        this.basicSearchAcronymDiv = false;
        this.basicSearchFirmnameDiv = false;
        this.basicSearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.basicSearchLoginDiv = false;
        this.basicSearchBusinessAreaCode = '';
        this.basicSearchShortName = '';
        this.basicSearchText = '';
        this.basicSearchDOBDiv = false;
      }
    }
  }
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType();
    }
  }
}
