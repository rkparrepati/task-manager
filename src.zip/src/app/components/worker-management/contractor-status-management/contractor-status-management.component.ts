import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { WorkerManagementService } from '../worker-management.service';
import { UtilityService } from 'src/app/services/utility.service';

interface ContractorStatusDetail {
  row: number;
  workerNumber: string;
  errorMessage: string;
}

interface ParsedObject {
  validRows: ContractorStatusDetail[];
  invalidRows: ContractorStatusDetail[];
}

interface ProcessedRows {
  validRows: any[];
  invalidRows: any[];
}

@Component({
  selector: 'app-contractor-status-management',
  templateUrl: './contractor-status-management.component.html',
  styleUrls: ['./contractor-status-management.component.scss']
})
export class ContractorStatusManagementComponent implements OnInit {
  moduleName = 'Contractor Status Management';
  appTitle = 'Contractor Status Management';
  fileToImport = '/assets/uploads/ContractorStatusMassUpload.csv';
  importFile: File | null = null;
  workersList: string[] = [];
  workerModel: any = null;
  isProcessing = false;
  showResults = false;
  validContractors: any[] = [];
  invalidContractors: any[] = [];

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private workerManagementService: WorkerManagementService,
    private utilityService: UtilityService
  ) {}

  ngOnInit(): void {}

  /**
   * Handle file selection from input
   */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.importFile = input.files[0];
      this.workersList = [];
      this.showResults = false;
    }
  }

  /**
   * Download the CSV template
   */
  downloadTemplate(): void {
    const link = document.createElement('a');
    link.href = this.fileToImport;
    link.download = 'ContractorStatusMassUpload.csv';
    link.click();
  }

  /**
   * Import and process the CSV file
   */
  importTheFile(): void {
    if (!this.importFile) {
      this.showInvalidFileMessage('Please select a file to import');
      return;
    }

    const suffix = this.importFile.name.substring(
      this.importFile.name.length - 4,
      this.importFile.name.length
    );

    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    this.isProcessing = true;
    const reader = new FileReader();

    reader.onload = (e: ProgressEvent<FileReader>) => {
      const text = e.target?.result as string;
      const parsedObject = this.parsePlanSpreadsheet(text);

      if (parsedObject.validRows.length > 0) {
        this.validateContractorStatus(parsedObject);
      } else {
        this.showImportDialogFailure(parsedObject);
        this.isProcessing = false;
      }
    };

    reader.onerror = () => {
      this.showInvalidFileMessage('Error reading file');
      this.isProcessing = false;
    };

    reader.readAsText(this.importFile);
  }

  /**
   * Validate contractor status via API
   */
  private validateContractorStatus(parsedObject: ParsedObject): void {
    this.workerManagementService.getContractorStatusValidResponse(parsedObject.validRows).subscribe({
      next: (response: any) => {
        const processedRows: ProcessedRows = {
          validRows: response.validResponse || [],
          invalidRows: response.invalidResponse || []
        };

        if (processedRows.invalidRows.length > 0) {
          this.showImportDialogFailure({
            validRows: processedRows.validRows,
            invalidRows: processedRows.invalidRows
          });
        } else {
          // Build worker list
          const list: string[] = [];
          const responseWorkersList: any[] = [];
          
          processedRows.validRows.forEach((item: any) => {
            list.push(item.contractorNumber);
            responseWorkersList.push(item.worker);
          });

          this.workersList = list;
          this.workerModel = {
            workerList: responseWorkersList,
            selectedWorker: {},
            newWorker: {}
          };

          this.validContractors = processedRows.validRows;
          this.showResults = true;
          this.showImportDialogSuccess(processedRows);
        }
        this.isProcessing = false;
      },
      error: (error: any) => {

        this.showInvalidFileMessage('Error validating contractor status: ' + (error.message || 'Unknown error'));
        this.isProcessing = false;
      }
    });
  }

  /**
   * Parse the CSV spreadsheet
   */
  private parsePlanSpreadsheet(text: string): ParsedObject {
    const lines = text.split('\n');
    const returnObject: ParsedObject = {
      invalidRows: [],
      validRows: []
    };

    lines.forEach((line, index) => {
      // Skip header row (index 0)
      if (index > 0) {
        const lineInfo = this.parseLine(line, index);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
    });

    return returnObject;
  }

  /**
   * Parse a single line from CSV
   */
  private parseLine(line: string, row: number): ContractorStatusDetail | null {
    const columns = line.split(',').map(col => col.trim());

    // Skip empty lines
    if (columns[0].length === 0 && columns.length === 1) {
      return null;
    }

    const contractorDetail: ContractorStatusDetail = {
      row: row + 1,
      workerNumber: columns[0].toUpperCase(),
      errorMessage: ''
    };

    // Validate worker number
    if (!contractorDetail.workerNumber) {
      contractorDetail.errorMessage = 'Missing Worker Number';
    }

    return contractorDetail;
  }

  /**
   * Get building data from organization history
   */
  getBuildingData(organizationHistory: any[]): string {
    let building = '';
    let position = -1;

    organizationHistory.forEach((organizationData, index) => {
      if (
        organizationData.locationSummary &&
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = index;
      }
    });

    if (
      position >= 0 &&
      organizationHistory[position].locationSummary[0].locationSummary != null
    ) {
      building = organizationHistory[position].locationSummary[0].locationSummary.building.code;
    }

    return building;
  }

  /**
   * Export status list (navigate to report generation)
   */
  exportStatusList(): void {
    if (this.workersList.length > 0) {
      // Navigate to contractor status report with worker list
      this.router.navigate(['/worker-management/contractor-status-report'], {
        state: { workerNumbers: this.workersList }
      });
    }
  }

  /**
   * Show invalid file type error
   */
  private invalidFileTypeMessage(): void {
    this.showInvalidFileMessage(
      'The format of the spreadsheet is not expected. Only CSV files can be imported.'
    );
  }

  /**
   * Show generic invalid file message
   */
  private showInvalidFileMessage(message: string): void {
    alert(message); // Replace with proper Material Dialog
  }

  /**
   * Show import failure dialog with errors
   */
  private showImportDialogFailure(parsedObject: any): void {

    let errorMsg = 'The following contractor numbers have errors:\n\n';
    parsedObject.invalidRows.forEach((row: any) => {
      errorMsg += `Row ${row.row}: ${row.workerNumber} - ${row.errorMessage || 'Invalid contractor'}\n`;
    });
    
    if (parsedObject.validRows && parsedObject.validRows.length > 0) {
      errorMsg += `\n${parsedObject.validRows.length} valid contractor(s) were found.`;
    }
    
    alert(errorMsg); // Replace with proper Material Dialog
  }

  /**
   * Show import success dialog
   */
  private showImportDialogSuccess(processedRows: ProcessedRows): void {
    const message = `Successfully validated ${processedRows.validRows.length} contractor(s) for status update.`;
    alert(message); // Replace with proper Material Dialog
  }

  /**
   * Cancel and go back
   */
  cancel(): void {
    this.router.navigate(['/worker-management'], { 
      queryParams: { type: 'Contractor' } 
    });
  }

  /**
   * Reset the form
   */
  reset(): void {
    this.importFile = null;
    this.workersList = [];
    this.workerModel = null;
    this.showResults = false;
    this.validContractors = [];
    this.invalidContractors = [];
  }
}
