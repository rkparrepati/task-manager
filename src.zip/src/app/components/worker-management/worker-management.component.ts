import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { WorkerManagementService } from './worker-management.service';
import { MatDialog } from '@angular/material/dialog';
import { AccessionSelectDialogComponent } from './accession-select-dialog/accession-select-dialog.component';
import { EmployeeStatusDialogComponent } from './employee-status-dialog/employee-status-dialog.component';
import { AdvanceSearchOptions } from 'src/app/shared/interfaces/models';
import { NotificationService } from 'src/app/services/notification.service';
import { combineLatest, skipWhile } from 'rxjs';

@Component({
  selector: 'app-worker-management',
  templateUrl: './worker-management.component.html',
  styleUrls: ['./worker-management.component.scss'],
})
export class WorkerManagementComponent implements OnInit {
  public workerRecords: any = { meta: {}, results: [] };
  disableShowRadioButton: any;
  showType: any = 'active';
  searchResultsCount: any;
  showWait: boolean = false;
  savedSearchCriteria: any;
  activeWorker: any;
  basicSearch: any;
  sortColumn: string = 'lastName';
  sortDirection: string = 'asc';
  userRoles: any = [
    'InfraAdmin',
    'InfraHRAdmin',
    'InfraOfficeCoordinator',
    'InfraRoomCoordinator',
    'InfraContractorAdmin',
    'InfraViewer',
    'InfraHRViewer',
    'InfraViewerWorkerMgmt',
    'InfraHRWorkerReports'
  ];
  isContractor: boolean = false;
  canAdd: boolean = true;
  workerModel: any = { workerList: [] };
  WorkerSearchService: any;
  buildBasicWorkerSearchExportQuery: any;
  applicationType: string = 'Worker';
  total: number = 0;
  workerEmploymentType: any;
  showWaitWorkerSearch: any;
  addWorkerButton: any;
  applicationTypeLowerCase: string = 'worker';
  loadingMessage: string = '';
  appTitle: any;
  buildAdvancedWorkerSearchExportQueryParamOne: any;
  otherSearchView: string = 'advanced';
  moduleName: string = 'Worker Management';
  limit: number = 10;
  jobClassMap: any = {}; // Map of job class codes to descriptions
  private selectedData: any;
  
  // Success message display
  successMessage: string = '';
  showSuccessBanner: boolean = false;
  successStatus: string = ''; // 'created' or 'updated'
  private successMessageProcessed: boolean = false; // Guard to prevent infinite loop
  
  constructor(
    private appService: AppService,
    private localStorageService: LocalStorageService,
    private workerManagementService: WorkerManagementService,
    private dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    private notificationService: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadJobClassReferences();
    
    this.route.url.subscribe(urlSegments => {
      const path = urlSegments.map(segment => segment.path).join('/');
      
      if (path.includes('Contractor')) {
        this.isContractor = true;
        this.workerEmploymentType = 'C';
        this.applicationTypeLowerCase = 'contractor';
        this.moduleName = 'Contractor Management';
        this.appTitle = 'Contractor Management';
      } else {
        this.isContractor = false;
        this.workerEmploymentType = 'E';
        this.applicationTypeLowerCase = 'worker';
        this.moduleName = 'Worker Management';
        this.appTitle = 'Worker Management';
      }
    });
    
    combineLatest([this.route.paramMap, this.notificationService.getSuccessMessageData()])
      .pipe(
        skipWhile(([paramMap, successData]) => {
          const status = paramMap.get('status');

          return !status || (status !== 'created' && status !== 'updated');
        })
      )
      .subscribe(([paramMap, successData]) => {
       

      const params = {
        status: paramMap.get('status'),
        workerId: paramMap.get('workerId')
      };
      
      if (this.successMessageProcessed) {

        return;
      }
      
      if (params['status'] && (params['status'] === 'created' || params['status'] === 'updated')) {
        const workerId = params['workerId'];
        this.successStatus = params['status'];
        this.successMessageProcessed = true;


        if (successData && successData.lastName && successData.lastName.trim() && successData.workerNo && successData.workerNo.trim()) {
          const actionText = params['status'] === 'created' ? 'created' : 'updated';
          this.successMessage = `Successfully ${actionText} ${successData.workerType.toLowerCase()}: ${successData.lastName} (Worker number:${successData.workerNo})`;

        } else {
          const workerType = this.isContractor ? 'Contractor' : 'Worker';
          const actionText = params['status'] === 'created' ? 'created' : 'updated';
          this.successMessage = `${workerType} ${workerId} has been ${actionText} successfully.`;

        }

        this.showSuccessBanner = true;
        this.cdr.detectChanges();
        
        // Prevent page scroll to bottom by scrolling to top
        setTimeout(() => {
          window.scrollTo(0, 0);
        }, 0);
        this.notificationService.showSuccess(
          this.successMessage,
          '200',
          5000
        );
      } else {

        this.showSuccessBanner = false;
        this.successMessage = '';
      }
    });
  }

  closeBanner(): void {
    this.showSuccessBanner = false;
    this.successMessage = '';
    // DO NOT reset successMessageProcessed - keep it true to prevent re-triggering
    // This ensures the banner won't reappear when clicking the X button
    this.notificationService.clearSuccessMessageData();
  }

  toggleSearchView() {
    if (this.otherSearchView === 'basic') {
      this.otherSearchView = 'advanced';
    } else {
      this.otherSearchView = 'basic';
    }
  }
  buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria: any, url: any) {
    url += savedSearchCriteria.classCode.description
      ? '&' + savedSearchCriteria.classCode.value + '=' + savedSearchCriteria.classCode.description
      : '';
    url += savedSearchCriteria.firmName.description
      ? '&' + savedSearchCriteria.firmName.value + '=' + savedSearchCriteria.firmName.description
      : '';
    url += savedSearchCriteria.firmAdministrator.description
      ? '&' +
        savedSearchCriteria.firmAdministrator.value +
        '=' +
        savedSearchCriteria.firmAdministrator.description
      : '';
    url += savedSearchCriteria.businessAreaCode.description
      ? '&' +
        savedSearchCriteria.businessAreaCode.value +
        '=' +
        savedSearchCriteria.businessAreaCode.description
      : '';
    url += savedSearchCriteria.shortName.description
      ? '&' + savedSearchCriteria.shortName.value + '=' + savedSearchCriteria.shortName.description
      : '';
    if (!savedSearchCriteria.allFirms) {
      url += savedSearchCriteria.loginWorkerNumber.description
        ? '&' +
          savedSearchCriteria.loginWorkerNumber.value +
          '=' +
          savedSearchCriteria.loginWorkerNumber.description
        : '';
      url += savedSearchCriteria.workerAssociatedFirms.description
        ? '&' +
          savedSearchCriteria.workerAssociatedFirms.value +
          '=' +
          savedSearchCriteria.workerAssociatedFirms.description
        : '';
    }
    url += savedSearchCriteria.buildingCode.description
      ? '&' +
        savedSearchCriteria.buildingCode.value +
        '=' +
        savedSearchCriteria.buildingCode.description
      : '';
    url += savedSearchCriteria.floorNumber.description
      ? '&' +
        savedSearchCriteria.floorNumber.value +
        '=' +
        savedSearchCriteria.floorNumber.description
      : '';
    url += savedSearchCriteria.corridorId.description
      ? '&' +
        savedSearchCriteria.corridorId.value +
        '=' +
        savedSearchCriteria.corridorId.description
      : '';
    url += savedSearchCriteria.roomId.description
      ? '&' + savedSearchCriteria.roomId.value + '=' + savedSearchCriteria.roomId.description
      : '';
    url += savedSearchCriteria.suiteId.description
      ? '&' + savedSearchCriteria.suiteId.value + '=' + savedSearchCriteria.suiteId.description
      : '';
    url += savedSearchCriteria.zoneId.description
      ? '&' + savedSearchCriteria.zoneId.value + '=' + savedSearchCriteria.zoneId.description
      : '';
    url += savedSearchCriteria.phoneNumber.description
      ? '&' +
        savedSearchCriteria.phoneNumber.value +
        '=' +
        savedSearchCriteria.phoneNumber.description
      : '';
    return url;
  }
  workerAdd(isTrademarkWorker: boolean = false) {
    this.localStorageService.removeItem('isTrademarkWorker');
    isTrademarkWorker = isTrademarkWorker || false;
    this.localStorageService.setItem('isTrademarkWorker', isTrademarkWorker.toString());
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/app/add-worker/contractor');
    } else {
      this.appService.changePage('/app/workerAdd/Worker');
    }
  }
  employeeStatus() {
    const dialogRef = this.dialog.open(EmployeeStatusDialogComponent, {
      width: '600px',
      height: 'auto',
      maxHeight: '800px',
      autoFocus: false,
      disableClose: false,
      data: null,
      panelClass: 'employee-status-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {
      // Dialog closed, no additional action needed
    });
  }
  contractorStatus() {
    // ngDialog.openConfirm({
    //     template : 'app/workerManagement/multiContractorStatus.html',
    //     controller : 'MultiContractorStatusDialogController',
    //     data : null,
    //     controllerAs : 'vm'
    // // }).then(function(confirmSaveExit) {
    // }).then(function(workersList) {
    //     var promises = [];
    //     vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilityService.exportTableServicePOST(url, 'ContractorStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    // }, function() {
    // });
  }
  public generateReports() {
    const dialogRef = this.dialog.open(AccessionSelectDialogComponent, {
      width: '504px',
      height: 'auto',
      maxHeight: '800px',
      autoFocus: false,
      disableClose: true,
      data: null,
      panelClass: 'worker-reports-dialog',
      position: { top: '90px' }
    });
    dialogRef.afterClosed().subscribe((result) => {

      if (result === 'upload') {

        this.router.navigate(['/app/workerForms']);
      }
    });
  }
  workerAddmultipleContractor() {
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/createMultipleContractors/Contractor');
    }
    //  else {
    //     vm.gotoPage("/workerAdd/Worker");
    // }
  }

  public setActiveWorkerList(showInactive: boolean) {
    if (this.selectedData) {
      this.searchWorkers(this.selectedData);
    }
  }

  public searchWorkers(data: any): void {
    this.selectedData = data;
    this.basicSearch = true;
    this.showWait = true;
    this.loadingMessage = 'Loading Worker data...';
    
    this.workerManagementService
      .getWorkers(
        this.showType === 'active' ? false : true,
        this.selectedData.searchText,
        this.selectedData.searchCriteria,
        this.isContractor,
        this.limit,
        0,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response) => {
          this.showWait = false;
          this.workerRecords = response;
          this.total = response.meta?.total || 0;
          this.updateSearchResultsCount();
          this.processWorkerData(this.workerRecords.results);
        },
        (error) => {
          this.showWait = false;
          this.workerRecords = { meta: {}, results: [] };
          this.total = 0;
          this.searchResultsCount = 'No workers have been found with the entered search criteria.';

        }
      );
  }

  /**
   * Handle page size change event from pagination component
   * Resets to page 1 when page size changes
   */
  public pageSizeChangedEvent(limit: number): void {
    this.limit = limit;
    // Re-run the search with the new page size, starting from page 1 (skip=0)
    if (this.selectedData) {
      if (this.basicSearch) {
        this.searchWorkers(this.selectedData);
      } else {
        this.performAdvancedSearch(0);
      }
    }
  }

  /**
   * Handle page change event from pagination component
   */
  public onPageChanged(pageNumber: number): void {
    const skip = (pageNumber - 1) * this.limit;
    this.showWait = true;
    this.loadingMessage = 'Loading Worker data...';
    
    if (this.selectedData) {
      // Check if it's basic or advanced search
      if (this.basicSearch) {
        this.workerManagementService
          .getWorkers(
            this.showType === 'active' ? false : true,
            this.selectedData.searchText,
            this.selectedData.searchCriteria,
            this.isContractor,
            this.limit,
            skip,
            this.sortColumn,
            this.sortDirection
          )
          .subscribe(
            (response) => {
              this.showWait = false;
              this.workerRecords = response;
              this.total = response.meta?.total || 0;
              this.processWorkerData(this.workerRecords.results);
            },
            (error) => {
              this.showWait = false;

            }
          );
      } else {
        // Advanced search with pagination
        this.performAdvancedSearch(skip);
      }
    }
  }

  public handleAdvanceSearch(data: AdvanceSearchOptions): void {
    this.selectedData = data;
    this.basicSearch = false;
    this.performAdvancedSearch(0);
  }

  public handleSortChange(event: any): void {
    // Map column names to API field names
    const columnToFieldMap: { [key: string]: string } = {
      'lastName': 'familyName',
      'firstName': 'givenName',
      'preferredFirstName': 'preferredFirstName',
      'applicationTypeNumber': 'workerNumber'
    };
    
    this.sortColumn = columnToFieldMap[event.active] || event.active || 'familyName';
    this.sortDirection = event.direction || 'asc';
    
    if (this.selectedData) {
      if (this.basicSearch) {
        // Re-run basic search with new sort
        this.searchWorkers(this.selectedData);
      } else {
        // Re-run advanced search with new sort
        this.performAdvancedSearch(0);
      }
    }
  }

  private url: string = '';
  
  private buildUrl(data: AdvanceSearchOptions): string {
    let url = '';
    if (data.birthDate.description) {
      url += `&${data.birthDate.value}=${data.birthDate.description}`;
    }
    if (data.buildingCode.description) {
      url += `&${data.buildingCode.value}=${data.buildingCode.description}`;
    }
    if (data.businessAreaCode.description) {
      url += `&${data.businessAreaCode.value}=${data.businessAreaCode.description}`;
    }
    if (data.cedrRoles.description) {
      url += `&${data.cedrRoles.value}=${data.cedrRoles.description}`;
    }
    if (data.classCode.description) {
      url += `&${data.classCode.value}=${data.classCode.description}`;
    }
    if (data.corridorId.description) {
      url += `&${data.corridorId.value}=${data.corridorId.description}`;
    }
    if (data.firmAdministrator.description) {
      url += `&${data.firmAdministrator.value}=${data.firmAdministrator.description}`;
    }

    if (data.firmName.description) {
      url += `&${data.firmName.value}=${data.firmName.description}`;
    }
    if (data.firstName.description) {
      url += `&${data.firstName.value}=${data.firstName.description}`;
    }
    if (data.floorNumber.description) {
      url += `&${data.floorNumber.value}=${data.floorNumber.description}`;
    }
    if (data.lastName.description) {
      url += `&${data.lastName.value}=${data.lastName.description}`;
    }
    if (data.loginId.description) {
      url += `&${data.loginId.value}=${data.loginId.description}`;
    }
    if (data.phoneNumber.description) {
      url += `&${data.phoneNumber.value}=${data.phoneNumber.description}`;
    }
    if (data.preferredFirstName.description) {
      url += `&${data.preferredFirstName.value}=${data.preferredFirstName.description}`;
    }
    if (data.roomId.description) {
      url += `&${data.roomId.value}=${data.roomId.description}`;
    }
    if (data.shortName.description) {
      url += `&${data.shortName.value}=${data.shortName.description}`;
    }
    if (data.ssn.description) {
      url += `&${data.ssn.value}=${data.ssn.description}`;
    }
    if (data.ssn2.description) {
      url += `&${data.ssn2.value}=${data.ssn2.description}`;
    }
    if (data.suiteId.description) {
      url += `&${data.suiteId.value}=${data.suiteId.description}`;
    }
    if (data.workerNumber.description) {
      url += `&workerNumberPrefix=${data.workerNumber.description}`;
    }
    if (data.zoneId.description) {
      url += `&${data.zoneId.value}=${data.zoneId.description}`;
    }

    return url;
  }

  private performAdvancedSearch(skip: number = 0): void {
    this.showWait = true;
    this.loadingMessage = 'Loading Worker data...';
    
    const url = this.buildUrl(this.selectedData);
    this.url = url;

    this.workerManagementService
      .getWorkersWithAdvanceSearch(
        this.showType === 'active' ? false : true,
        url,
        this.limit,
        skip,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response) => {
          this.showWait = false;
          this.workerRecords = response;
          this.total = response.meta?.total || 0;
          this.updateSearchResultsCount();
          this.processWorkerData(this.workerRecords.results);
        },
        (error) => {
          this.showWait = false;
          this.workerRecords = { meta: {}, results: [] };
          this.total = 0;
          this.searchResultsCount = 'No workers have been found with the entered search criteria.';

        }
      );
  }

  exportDataCallback(): void {
    this.showWait = true;
    this.loadingMessage = 'Exporting Worker data...';

    // Build export URL with sort parameters
    let exportUrl = this.url;
    exportUrl += `&sortColumn=${this.sortColumn}&sortOrder=${this.sortDirection}`;
    exportUrl += `&limit=${this.workerRecords.meta?.total || this.total}`;

    this.workerManagementService
      .workerExcelReport(
        this.showType === 'active' ? false : true,
        exportUrl,
        this.workerRecords.meta?.total || this.total
      )
      .subscribe(
        (response: Blob) => {
          this.showWait = false;
          // Create a download link
          const downloadUrl = window.URL.createObjectURL(response);

          // Create an anchor element and trigger the download
          const a = document.createElement('a');
          a.href = downloadUrl;
          // Set filename based on employment type (contractor or worker)
          const exportType = this.isContractor ? 'Contractor' : 'Worker';
          a.download = `${exportType}SearchExport.xlsx`;
          a.click();

          // Clean up the object URL
          window.URL.revokeObjectURL(downloadUrl);
        },
        (error) => {
          this.showWait = false;

        }
      );
  }
  redirectToMoveContractors() {
    this.appService.changePage('/app/contractor-management/move-contractors');
  }

  private updateSearchResultsCount(): void {
    if (this.total === 1) {
      this.searchResultsCount = `${this.total} worker has been found with the entered search criteria.`;
    } else if (this.total > 1) {
      this.searchResultsCount = `${this.total} worker(s) have been found with the entered search criteria.`;
    } else {
      this.searchResultsCount = 'No workers have been found with the entered search criteria.';
    }
  }

  private processWorkerData(workers: any[]): void {
    if (!workers || workers.length === 0) {
      return;
    }
    workers.forEach((worker: any) => {
      worker.primaryOrganization =
        worker.organizationHistory?.find(
          (organization: any) => organization.primaryOrganizationIndicator
        ) || {};
      worker.primaryCommunication =
        worker.communicationHistory?.find(
          (communication: any) => communication.primaryIndicator
        ) || {};
      // Enrich job class with description from reference data
      this.enrichJobClassDescription(worker);
    });
  }

  /**
   * Enrich worker job class with description from reference data
   * Maps job class code to description using the jobClassMap
   */
  private enrichJobClassDescription(worker: any): void {
    if (worker && worker.jobClass) {
      const jobClassCode = worker.jobClass.value || worker.jobClass;
      
      if (this.jobClassMap && this.jobClassMap[jobClassCode]) {
        // Ensure jobClass is an object
        if (typeof worker.jobClass === 'string') {
          worker.jobClass = { value: worker.jobClass };
        }
        worker.jobClass.description = this.jobClassMap[jobClassCode];
      }
    }
  }

  /**
   * Load job class reference data and build map
   */
  private loadJobClassReferences(): void {
    this.workerManagementService.getJobClasses().subscribe(
      (response: any) => {
        if (response && response.results) {
          // Build job class map for enriching worker data
          this.jobClassMap = {};
          response.results.forEach((jobClass: any) => {
            this.jobClassMap[jobClass.value] = jobClass.description;
          });

        }
      },
      (error) => {

      }
    );
  }

  /**
   * Show success notification message
   * Equivalent to old: setMessage("200", "Success message")
   */
  showSuccessNotification(message: string, code: string = '200', duration: number = 4000): void {
    this.notificationService.showSuccess(message, code, duration);
  }

  /**
   * Show error notification message
   * Equivalent to old: setMessage("700", "Error message")
   */
  showErrorNotification(message: string, code: string = '700', duration: number = 5000): void {
    this.notificationService.showError(message, code, duration);
  }

  /**
   * Show warning notification message
   * Equivalent to old: setMessage("100", "Warning message")
   */
  showWarningNotification(message: string, code: string = '100', duration: number = 4000): void {
    this.notificationService.showWarning(message, code, duration);
  }

  /**
   * Show info notification message
   */
  showInfoNotification(message: string, code: string = '300', duration: number = 4000): void {
    this.notificationService.showInfo(message, code, duration);
  }
}
