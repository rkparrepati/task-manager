import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WorkerManagementService } from '../worker-management.service';
import { MatDialog } from '@angular/material/dialog';

interface Contractor {
  workerId: string;
  workerNumber: string;
  lastName: string;
  preferredFirstName: string;
  displayItem: string;
}

interface Firm {
  id: string;
  value: string;
  description: string;
  firmDisplay: string;
}

@Component({
  selector: 'app-contractor-firm-movement',
  templateUrl: './contractor-firm-movement.component.html',
  styleUrls: ['./contractor-firm-movement.component.scss']
})
export class ContractorFirmMovementComponent implements OnInit {
  // Firm selection
  contractorFirmNames: Firm[] = [];
  selectedFirmName: string = '';
  newContractorFirm: Firm | null = null;
  
  // Contractor lists
  contractorsInFirm: Contractor[] = [];
  currentContractorsInFirm: Contractor[] = [];
  newFirmContractors: Contractor[] = [];
  
  // Selected contractors for moving
  selectedContractors: Contractor[] = [];
  selectedFromContractors: Contractor[] = [];
  
  // UI state
  showMoveContractors: boolean = false;
  hideMessage: boolean = true;
  returnMessage: string = '';
  returnCode: number = 0;
  isLoading: boolean = false;
  isSaving: boolean = false;

  constructor(
    private workerManagementService: WorkerManagementService,
    private router: Router,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadContractorFirms();
  }

  /**
   * Load all contractor firms
   */
  private loadContractorFirms(): void {
    this.isLoading = true;
    this.workerManagementService.getContractorFirmNames('', 'Contractor').subscribe({
      next: (response: any) => {
        this.contractorFirmNames = response.firms.map((firm: any) => ({
          id: firm.id,
          value: firm.value,
          description: firm.description,
          firmDisplay: `${firm.value} - ${firm.description}`
        }));
        this.isLoading = false;
      },
      error: (error: any) => {
        this.hideMessage = false;
        this.returnMessage = error.error?.message || 'Failed to load contractor firms';
        this.returnCode = error.status;
        this.isLoading = false;
      }
    });
  }

  /**
   * Show contractors for selected firm
   */
  showFirmContractors(): void {
    if (!this.selectedFirmName) {
      return;
    }

    this.isLoading = true;
    this.hideMessage = true;

    // Find the selected firm
    const selectedFirm = this.contractorFirmNames.find(
      firm => firm.value === this.selectedFirmName
    );

    if (!selectedFirm) {
      this.hideMessage = false;
      this.returnMessage = 'Selected firm not found';
      this.isLoading = false;
      return;
    }

    // Get contractors for the selected firm
    this.workerManagementService.getContractorsByFirm(selectedFirm.id).subscribe({
      next: (contractors: any[]) => {
        this.contractorsInFirm = contractors.map(contractor => ({
          workerId: contractor.workerId,
          workerNumber: contractor.workerNumber,
          lastName: contractor.lastName,
          preferredFirstName: contractor.preferredFirstName,
          displayItem: `${contractor.lastName}, ${contractor.preferredFirstName}, ${contractor.workerNumber}`
        }));
        this.currentContractorsInFirm = [...this.contractorsInFirm];
        this.newFirmContractors = [];
        this.showMoveContractors = true;
        this.isLoading = false;
      },
      error: (error: any) => {
        this.hideMessage = false;
        this.returnMessage = error.error?.message || 'Failed to load contractors for firm';
        this.returnCode = error.status;
        this.isLoading = false;
      }
    });
  }

  /**
   * Move contractors between lists
   * @param moveAll - Whether to move all contractors or just selected ones
   * @param direction - 'add' to move to new firm, 'remove' to move back
   */
  moveContractors(moveAll: boolean, direction: 'add' | 'remove'): void {
    let fromList: Contractor[];
    let toList: Contractor[];
    let moveList: Contractor[];

    if (direction === 'add') {
      fromList = this.contractorsInFirm;
      toList = this.newFirmContractors;
      moveList = moveAll ? [...this.contractorsInFirm] : this.selectedContractors;
    } else {
      fromList = this.newFirmContractors;
      toList = this.contractorsInFirm;
      moveList = moveAll ? [...this.newFirmContractors] : this.selectedFromContractors;
    }

    if (!moveList || moveList.length === 0) {
      return;
    }

    // Move contractors
    moveList.forEach(contractor => {
      // Add to target list if not already there
      if (!toList.find(c => c.workerNumber === contractor.workerNumber)) {
        toList.push(contractor);
      }
      
      // Remove from source list
      const index = fromList.findIndex(c => c.workerNumber === contractor.workerNumber);
      if (index !== -1) {
        fromList.splice(index, 1);
      }
    });

    // Clear selections
    this.selectedContractors = [];
    this.selectedFromContractors = [];
  }

  /**
   * Save contractor move to new firm
   */
  saveContractorMove(): void {
    if (!this.newContractorFirm || this.newFirmContractors.length === 0) {
      return;
    }

    this.isSaving = true;
    this.hideMessage = true;

    const workerIds = this.newFirmContractors.map(contractor => contractor.workerId);
    const moveRequest = {
      workerId: workerIds,
      firm: {
        id: this.newContractorFirm.id
      }
    };

    this.workerManagementService.moveContractorsToFirm(moveRequest).subscribe({
      next: (response: any) => {
        this.hideMessage = false;
        this.returnMessage = `Successfully moved ${this.newFirmContractors.length} contractor(s) to ${this.newContractorFirm!.description}`;
        this.returnCode = 200;
        this.isSaving = false;
        
        // Reset the view after successful save
        setTimeout(() => {
          this.resetView();
        }, 2000);
      },
      error: (error: any) => {
        this.hideMessage = false;
        this.returnMessage = error.error?.message || 'Failed to move contractors';
        this.returnCode = error.status;
        this.isSaving = false;
      }
    });
  }

  /**
   * Cancel and reset the view
   */
  cancelMove(): void {
    this.showMoveContractors = false;
    this.newFirmContractors = [];
    this.contractorsInFirm = [];
    this.selectedContractors = [];
    this.selectedFromContractors = [];
    this.newContractorFirm = null;
  }

  /**
   * Reset entire view
   */
  resetView(): void {
    this.showMoveContractors = false;
    this.selectedFirmName = '';
    this.newContractorFirm = null;
    this.contractorsInFirm = [];
    this.currentContractorsInFirm = [];
    this.newFirmContractors = [];
    this.selectedContractors = [];
    this.selectedFromContractors = [];
    this.hideMessage = true;
  }

  /**
   * Navigate back to contractor management search
   */
  backToContractorMgmt(): void {
    this.router.navigate(['/contractor-management']);
  }

  /**
   * Check if a firm should be disabled in the new firm dropdown
   */
  isFirmDisabled(firm: Firm): boolean {
    return firm.description === this.selectedFirmName;
  }

  /**
   * Get button disabled state
   */
  get canMoveToNew(): boolean {
    return this.selectedContractors.length === 0 || this.contractorsInFirm.length === 0;
  }

  get canMoveAllToNew(): boolean {
    return this.contractorsInFirm.length === 0;
  }

  get canMoveFromNew(): boolean {
    return this.selectedFromContractors.length === 0 || this.newFirmContractors.length === 0;
  }

  get canMoveAllFromNew(): boolean {
    return this.newFirmContractors.length === 0;
  }

  get canSave(): boolean {
    return !this.newFirmContractors || this.newFirmContractors.length === 0 || !this.newContractorFirm;
  }
}
