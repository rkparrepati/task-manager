import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EmployeeStatusDialogComponent } from './employee-status-dialog.component';
import { WorkerManagementService } from '../worker-management.service';
import { of, throwError } from 'rxjs';

describe('EmployeeStatusDialogComponent', () => {
  let component: EmployeeStatusDialogComponent;
  let fixture: ComponentFixture<EmployeeStatusDialogComponent>;
  let mockDialogRef: jasmine.SpyObj<MatDialogRef<EmployeeStatusDialogComponent>>;
  let mockWorkerManagementService: jasmine.SpyObj<WorkerManagementService>;

  beforeEach(async () => {
    mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['close', 'updateSize']);
    mockWorkerManagementService = jasmine.createSpyObj('WorkerManagementService', [
      'getContractorStatusValidResponse',
      'getWorkerStatusExcelReport'
    ]);

    await TestBed.configureTestingModule({
      declarations: [EmployeeStatusDialogComponent],
      providers: [
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: WorkerManagementService, useValue: mockWorkerManagementService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(EmployeeStatusDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('sendFile', () => {
    it('should set importedFile when file is selected', () => {
      const mockFile = new File(['test'], 'test.csv', { type: 'text/csv' });
      const event = {
        currentTarget: {
          files: [mockFile]
        }
      } as any;

      component.sendFile(event);

      expect(component.importedFile).toBe(mockFile);
      expect(component.workersList).toEqual([]);
      expect(component.errorMessage).toBe('');
    });

    it('should handle null files', () => {
      const event = {
        currentTarget: {
          files: null
        }
      } as any;

      component.sendFile(event);

      expect(component.importedFile).toBeNull();
    });
  });

  describe('downloadTemplate', () => {
    it('should create and click download link', () => {
      spyOn(document.body, 'appendChild');
      spyOn(document.body, 'removeChild');
      const linkElement = document.createElement('a');
      spyOn(document, 'createElement').and.returnValue(linkElement);
      spyOn(linkElement, 'click');

      component.downloadTemplate();

      expect(document.createElement).toHaveBeenCalledWith('a');
      expect(linkElement.href).toContain('WorkerStatusMassUpload.csv');
      expect(linkElement.download).toBe('WorkerStatusMassUpload.csv');
      expect(linkElement.click).toHaveBeenCalled();
    });
  });

  describe('parseLine', () => {
    it('should parse a valid CSV line', () => {
      const line = 'W123456,Smith,John';
      const result = component.parseLine(line, 1);

      expect(result).toBeTruthy();
      expect(result.workerNumber).toBe('W123456');
      expect(result.row).toBe(1);
    });

    it('should return null for empty line', () => {
      const line = '';
      const result = component.parseLine(line, 1);

      expect(result).toBeNull();
    });

    it('should uppercase worker number', () => {
      const line = 'w123456,smith,john';
      const result = component.parseLine(line, 1);

      expect(result.workerNumber).toBe('W123456');
    });
  });

  describe('parsePlanSpreadsheet', () => {
    it('should parse valid CSV content', () => {
      const csvContent = 'W123456,Smith,John\nW234567,Doe,Jane';
      const result = component.parsePlanSpreadsheet(csvContent);

      expect(result.validRows.length).toBe(2);
      expect(result.invalidRows.length).toBe(0);
    });

    it('should skip header row', () => {
      const csvContent = 'WorkerNumber,LastName,FirstName\nW123456,Smith,John';
      const result = component.parsePlanSpreadsheet(csvContent);

      expect(result.validRows.length).toBe(1);
    });
  });

  describe('isValidFileType', () => {
    it('should return true for CSV file', () => {
      component.importedFile = new File(['test'], 'test.csv', { type: 'text/csv' });
      expect(component.isValidFileType()).toBe(true);
    });

    it('should return false for non-CSV file', () => {
      component.importedFile = new File(['test'], 'test.xlsx', { type: 'application/vnd.ms-excel' });
      expect(component.isValidFileType()).toBe(false);
      expect(component.errorMessage).toContain('Only CSV files can be imported');
    });

    it('should return false when no file is selected', () => {
      component.importedFile = null;
      expect(component.isValidFileType()).toBe(false);
      expect(component.errorMessage).toContain('Please select a file first');
    });
  });

  describe('importFile', () => {
    it('should read file and process it', (done) => {
      const mockFile = new File(['W123456,Smith,John'], 'test.csv', { type: 'text/csv' });
      component.importedFile = mockFile;

      spyOn(component, 'fileReader');

      component.importFile();

      // Wait for FileReader to complete
      setTimeout(() => {
        expect(component.fileReader).toHaveBeenCalled();
        done();
      }, 100);
    });

    it('should set error message for invalid file type', () => {
      component.importedFile = new File(['test'], 'test.xlsx', { type: 'application/vnd.ms-excel' });

      component.importFile();

      expect(component.errorMessage).toContain('Only CSV files can be imported');
    });
  });

  describe('getResponseForEmployeeStatusUpdate', () => {
    it('should process valid response', () => {
      const mockResponse = {
        validResponse: [
          { workerNumber: 'W123456', worker: { id: 1, name: 'Smith' } }
        ],
        invalidResponse: []
      };

      mockWorkerManagementService.getContractorStatusValidResponse.and.returnValue(of(mockResponse));
      spyOn(component, 'exportStatusList');

      component.getResponseForEmployeeStatusUpdate([{ workerNumber: 'W123456' }]);

      expect(component.isFileImported).toBe(true);
      expect(component.workersList.length).toBe(1);
      expect(component.successMessage).toContain('Successfully processed');
      expect(component.exportStatusList).toHaveBeenCalled();
    });

    it('should handle error response', () => {
      mockWorkerManagementService.getContractorStatusValidResponse.and.returnValue(
        throwError(() => new Error('API Error'))
      );

      component.getResponseForEmployeeStatusUpdate([{ workerNumber: 'W123456' }]);

      expect(component.showWait).toBe(false);
      expect(component.errorMessage).toContain('Error processing file');
    });
  });

  describe('exportStatusList', () => {
    it('should download status report', () => {
      const mockBlob = new Blob(['test data']);
      mockWorkerManagementService.getWorkerStatusExcelReport.and.returnValue(of(mockBlob));

      spyOn(window.URL, 'createObjectURL').and.returnValue('blob:mock-url');
      spyOn(window.URL, 'revokeObjectURL');
      const linkElement = document.createElement('a');
      spyOn(document, 'createElement').and.returnValue(linkElement);
      spyOn(linkElement, 'click');

      component.exportStatusList();

      expect(mockWorkerManagementService.getWorkerStatusExcelReport).toHaveBeenCalled();
      expect(linkElement.download).toBe('EmployeeStatusReport.csv');
    });
  });

  describe('closeThisDialog', () => {
    it('should close dialog and reset state', () => {
      component.isFileImported = true;

      component.closeThisDialog();

      expect(component.isFileImported).toBe(false);
      expect(mockDialogRef.close).toHaveBeenCalled();
    });
  });
});
