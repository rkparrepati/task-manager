import { Component, Inject, ChangeDetectorRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { WorkerManagementService } from '../worker-management.service';

@Component({
  selector: 'app-employee-status-dialog',
  templateUrl: './employee-status-dialog.component.html',
  styleUrls: ['./employee-status-dialog.component.scss'],
})
export class EmployeeStatusDialogComponent {
  workersList: any = [];
  importedFile: File | null = null;
  isFileImported = false;
  applicationType = 'Worker';
  fileToImport = '/ui/uploads/WorkerStatusMassUpload.csv';
  loadingMessage = 'Processing file...';
  showWait = false;
  errorMessage = '';
  successMessage = '';
  validWorkers: any[] = [];
  executeResponseData: any = null;
  validResponseWorkers: any[] = [];
  invalidResponseWorkers: any[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<EmployeeStatusDialogComponent>,
    private workerManagementService: WorkerManagementService,
    private cdr: ChangeDetectorRef
  ) { }

  /**
   * Handle file selection from input
   */
  sendFile(event: Event): void {
    const element = event.currentTarget as HTMLInputElement;
    const file: any = element?.files ? element.files[0] : null;
    this.workersList = [];
    this.importedFile = file;
    this.errorMessage = '';
    this.successMessage = '';
  }

  /**
   * Download the template file for employee status import
   */
  downloadTemplate(): void {
    const link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/uploads/WorkerStatusMassUpload.csv';
    link.download = 'WorkerStatusMassUpload.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  /**
   * Parse a single line from CSV file
   */
  parseLine(line: string, row: number): any {
    const columns = line.split(',');
    if (columns[0].length === 0) {
      return null;
    }

    // Trim and uppercase the relevant columns
    for (let index = 0; index < Math.min(3, columns.length); index++) {
      if (columns[index]) {
        columns[index] = columns[index].toUpperCase().trim();
      }
    }

    const workerDetails = {
      row: row,
      workerNumber: columns[0],
      errorMessage: '',
    };
    return workerDetails;
  }

  /**
   * Parse the entire CSV spreadsheet
   */
  parsePlanSpreadsheet(text: string): any {
    const lines = text.split('\n');
    let dataRow = 0;
    const returnObject: { invalidRows: any[]; validRows: any[] } = {
      invalidRows: [],
      validRows: [],
    };

    lines.forEach((value) => {
      if (dataRow > 0) {
        const lineInfo: any = this.parseLine(value, dataRow);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }

      dataRow++;
    });

    return returnObject;
  }

  /**
   * Validate file type - only CSV files allowed
   */
  isValidFileType(): boolean {
    if (!this.importedFile) {
      this.errorMessage = 'Please select a file first.';
      return false;
    }

    const suffix = this.importedFile.name.substring(
      this.importedFile.name.length - 4,
      this.importedFile.name.length
    );

    if (suffix !== '.csv') {
      this.errorMessage = 'The format of the spreadsheet is not expected. Only CSV files can be imported.';
      return false;
    }

    return true;
  }

  /**
   * Import the selected file
   */
  importFile(): void {
    if (!this.isValidFileType()) {
      return;
    }

    this.showWait = true;
    this.loadingMessage = 'Processing file...';
    this.errorMessage = '';

    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result;
      this.fileReader(text);
    };

    reader.onerror = () => {
      this.showWait = false;
      this.errorMessage = 'Error reading file. Please try again.';
    };

    reader.readAsText(this.importedFile as any);
  }

  /**
   * Process the file content
   */
  fileReader(text: any): void {
    const parsedObject = this.parsePlanSpreadsheet(text);

    if (parsedObject.validRows && parsedObject.validRows.length > 0) {
      this.getResponseForEmployeeStatusUpdate(parsedObject.validRows);
    } else {
      this.showWait = false;
      this.errorMessage = 'No valid rows found in the file. Please check the file format.';
    }
  }

  /**
   * Send valid rows to backend for processing
   */
  getResponseForEmployeeStatusUpdate(validRequests: any): void {
    this.workerManagementService
      .createValidWorkers(validRequests)
      .subscribe(
        (response: any) => {
          this.showWait = false;
          const returnedData = response;
          // Handle both response structures: validResponse/invalidResponse and validArray/invalidArray
          const processedRows = {
            validRows: returnedData.validResponse || returnedData.validArray || [],
            invalidRows: returnedData.invalidResponse || returnedData.invalidArray || [],
          };

          this.isFileImported = true;
          this.dialogRef.updateSize('95em');

          if (processedRows.validRows.length > 0) {
            // Extract worker numbers from valid rows
            this.workersList = [];
            const list = [];
            const responseWorkersList = [];
            for (let counter = 0; counter < processedRows.validRows.length; counter++) {
              if (processedRows.validRows[counter].worker?.workerNumber) {
                list.push(processedRows.validRows[counter].worker?.workerNumber);
              }
              const worker = processedRows.validRows[counter].worker;
              responseWorkersList.push(worker);
            }
            this.workersList = list;
            // Map valid response to format needed for createValidWorkers API
            this.executeResponseData = true;
            this.validWorkers = this.mapToCreateValidWorkersFormat(processedRows.validRows);
            this.validResponseWorkers = this.validWorkers;

            // this.successMessage = `Successfully processed ${processedRows.validRows.length} worker(s).`;

            // Export the status list
            this.exportStatusList();
          }

          if (processedRows.invalidRows.length > 0) {
             this.executeResponseData = true;
            this.invalidResponseWorkers = processedRows.invalidRows || [];
            // this.errorMessage = `${processedRows.invalidRows.length} row(s) had errors and were not processed.`;
          }
        },
        (error: any) => {
          this.showWait = false;
          this.errorMessage = 'Error processing file. Please try again.';
        }
      );
  }

  /**
   * Map response data to the format required by createValidWorkers API
   * The API expects the full response objects with worker details
   * Format: { row, contractorNumber, worker, errorMessage }
   */
  private mapToCreateValidWorkersFormat(responseData: any[]): any[] {
    return responseData.map((item: any) => {
      // Send the complete worker object along with metadata
      // The API validates the full worker object to ensure all required fields are present
      return {
        row: item.row,
        contractorNumber: item.contractorNumber || item.workerNumber,
        workerNumber: item.workerNumber,
        worker: item.worker,
        errorMessage: item.errorMessage || ''
      };
    });
  }

  /**
   * Execute the createValidWorkers API call
   * Sends the valid workers data to the backend for processing
   * Displays response in grid format with valid and invalid workers
   */
  executeCreateValidWorkers(): void {
    console.log('executeCreateValidWorkers() method called');
    console.log('validWorkers:', this.validWorkers);

    if (!this.validWorkers || this.validWorkers.length === 0) {
      this.errorMessage = 'No valid workers to process.';
      console.warn('No valid workers to process');
      return;
    }

    this.showWait = true;
    this.loadingMessage = 'Creating valid workers...';
    this.errorMessage = '';
    this.successMessage = '';

    this.workerManagementService
      .createValidWorkers(this.validWorkers)
      .subscribe(
        (response: any) => {
          this.showWait = false;

          // Log raw API response to debug discrepancies between Postman and browser console
          console.log('RAW API RESPONSE (before normalization):', response);

          // Validate and normalize response structure
          // Ensure validResponse and invalidResponse are always arrays
          const normalizedResponse = this.normalizeApiResponse(response);

          console.log('NORMALIZED RESPONSE (after normalization):', normalizedResponse);

          // Store the complete response for grid display
          this.executeResponseData = normalizedResponse;

          // Extract valid and invalid responses
          this.validResponseWorkers = normalizedResponse.validResponse || [];
          this.invalidResponseWorkers = normalizedResponse.invalidResponse || [];

          const successCount = this.validResponseWorkers.length;
          const failureCount = this.invalidResponseWorkers.length;

          // Collect error messages from invalid responses
          const errorMessages = this.invalidResponseWorkers
            .map((item: any) => `Row ${item.row}: ${item.workerNumber} - ${item.errorMessage}`)
            .slice(0, 5); // Show first 5 errors

          console.log('Normalized API Response:', normalizedResponse);
          console.log('Success Count:', successCount, 'Failure Count:', failureCount);
          console.log('Valid Response Workers:', this.validResponseWorkers);
          console.log('Invalid Response Workers:', this.invalidResponseWorkers);
          console.log('Error Messages:', errorMessages);

          if (failureCount > 0 && successCount === 0) {
            // All workers failed
            this.errorMessage = `All ${failureCount} worker(s) failed to create:\n${errorMessages.join('\n')}`;
            this.workerManagementService.showErrorMessage(
              `Failed to create workers: ${errorMessages[0]}`
            );
          } else if (failureCount > 0 && successCount > 0) {
            // Partial success
            this.errorMessage = `${failureCount} worker(s) failed:\n${errorMessages.join('\n')}`;
            this.successMessage = `Successfully created ${successCount} worker(s).`;
            this.workerManagementService.showErrorMessage(
              `Partial success: ${successCount} created, ${failureCount} failed.`
            );
          } else if (successCount > 0) {
            // All succeeded
            this.successMessage = `Successfully created ${successCount} worker(s) in the system.`;
            this.workerManagementService.showSuccessMessage(
              `All ${successCount} worker(s) have been successfully created.`
            );
          } else {
            // No data
            this.successMessage = 'Workers processing completed.';
            this.workerManagementService.showSuccessMessage('Workers have been processed successfully.');
          }

          // Trigger change detection to ensure template updates
          this.cdr.detectChanges();
        },
        (error: any) => {
          this.showWait = false;
          this.errorMessage = 'Error creating workers. Please try again.';
          this.workerManagementService.showErrorMessage(
            'Failed to create workers. Please check the data and try again.'
          );
          console.error('Error creating valid workers:', error);

          // Trigger change detection to ensure template updates
          this.cdr.detectChanges();
        }
      );
  }

  /**
   * Normalize API response to ensure proper structure
   * Ensures validResponse and invalidResponse are always arrays
   * Handles both response structures: validResponse/invalidResponse and validArray/invalidArray
   * @param response Raw API response
   * @returns Normalized response with guaranteed array structure
   */
  private normalizeApiResponse(response: any): any {
    return {
      validResponse: this.ensureArray(response?.validResponse || response?.validArray),
      invalidResponse: this.ensureArray(response?.invalidResponse || response?.invalidArray)
    };
  }

  /**
   * Ensure a value is an array
   * @param value Value to check
   * @returns Array or empty array
   */
  private ensureArray(value: any): any[] {
    if (Array.isArray(value)) {
      return value;
    }
    return [];
  }

  /**
   * Export the status list as CSV
   */
  exportStatusList(): void {
    this.workerManagementService
      .getWorkerStatusExcelReport(this.workersList)
      .subscribe(
        (blob: Blob) => {
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'EmployeeStatusReport.csv';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
        },
        (error: any) => {
          console.error('Error exporting status list:', error);
        }
      );
  }

  /**
   * Close the dialog
   */
  closeThisDialog(): void {
    this.isFileImported = false;
    this.dialogRef.close();
  }
}
