import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { FormsModule, FormBuilder, FormGroup } from '@angular/forms';

import { AuthorizationService } from 'src/app/services/authorization.service';
import { HttpParams } from '@angular/common/http';
import { TransferSearchService } from '../transfer-search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnChanges {
  //form: FormGroup;
  @Input() limit: number = 10;
  @Input() skip: number = 0;
  @Input() sortColumn: string = 'workerNumber';
  @Input() sortOrder: string = 'asc';
  @Input() showAll: boolean = false;
  @Input() prefillWorkerNumber: string = '';
  @Input() prefillFamilyName: string = '';
  @Input() prefillGivenName: string = '';
  @Input() prefillArtClassNo: string = '';

  @Output() dataEvent = new EventEmitter<any>();
  @Output() clearEvent = new EventEmitter<void>();
  @Output() clearToastEvent = new EventEmitter<void>();
  @Output() searchStartEvent = new EventEmitter<void>();
  artClassNo: string = '';

  disableShowRadioButton: boolean = false;
  showType: any = 'active';
  artUnit: string = '';
  workerModel: any;
  Search: any;
  savedSearchCriteria: any;
  SearchBusinessAreaCode: any;
  SearchShortName: any;
  searchOptions: any;

  loadingMessage: any;
  SearchText: any;
  searchPurpose: any;
  selectedSearchCriteria: any;
  clearAdvanvedSearch: any;
  checkBlankAdvanceSearch: any;
  userInfo: any;
  searchResultsCount: any;
  SearchAcronym: any;
  SearchDiv: any;
  SearchAcronymDiv: any;
  SearchSSNDiv: any;
  SearchFirmnameDiv: any;
  SearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  SearchDOBDiv: any;
  SearchLoginDiv: any;
  invalidSearchText: any;
  invalidAcronym: any;
  SearchfirmAdministratorDiv: any;
  applicationTypeLowerCase: any;
  SearchCriteria: any;
  classDescription: string = '';
  workerNumber: string = '';
  familyName: string = '';
  givenName: string = '';
  searchObject: any = {};
  searchResults: any = {};
  theParams: string = '';
  parentData = 'Hhello';
  total: number = 0;

  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private localStorageService: LocalStorageService,
    private transferSearchService: TransferSearchService,
    private authorizationService: AuthorizationService,
    private fb: FormBuilder
  ) {}

  sendData() {
    // Emit the API results with pagination information
    const dataToEmit = {
      results: this.searchResults,
      total: this.total,
      params: this.theParams,
      pagination: {
        limit: this.limit,
        skip: this.skip,
        sortColumn: this.sortColumn,
        sortOrder: this.sortOrder,
        showAll: this.showAll,
      },
    };
    this.transferSearchService.changeTabData(dataToEmit);
    this.dataEvent.emit(dataToEmit);
  }
  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    // Handle prefill values from parent (matching legacy lines 703-711)
    if (changes['prefillWorkerNumber'] && changes['prefillWorkerNumber'].currentValue) {
      this.workerNumber = changes['prefillWorkerNumber'].currentValue;
    }
    if (changes['prefillFamilyName'] && changes['prefillFamilyName'].currentValue) {
      this.familyName = changes['prefillFamilyName'].currentValue;
    }
    if (changes['prefillGivenName'] && changes['prefillGivenName'].currentValue) {
      this.givenName = changes['prefillGivenName'].currentValue;
    }
    if (changes['prefillArtClassNo'] && changes['prefillArtClassNo'].currentValue) {
      this.artClassNo = changes['prefillArtClassNo'].currentValue;
    }
    
    // If any prefill values were set, trigger search automatically (matching legacy line 711)
    if ((changes['prefillWorkerNumber'] || changes['prefillFamilyName'] ||
         changes['prefillGivenName'] || changes['prefillArtClassNo']) &&
        (this.workerNumber || this.familyName || this.givenName || this.artClassNo)) {
      // Trigger search after prefill
      setTimeout(() => this.search(), 100);
    }
    
    // Check if skip input has changed and it's not the first change
    if (changes['skip'] && !changes['skip'].firstChange) {
      // Call the search API when skip changes
      this.search();
    }
  }
  searchKeyEventHandler(event: KeyboardEvent) {
    const input = (event.target as HTMLInputElement).value;
    this.artClassNo = input;
  }

  clearSearchValue() {
    // this.workerNumber.length
    this.familyName = '';
    this.workerNumber = '';
    this.givenName = '';
    this.artClassNo = '';
    this.artUnit = '';
    this.classDescription = '';
    //this.searchResults = '';
    this.searchResults = [];
    this.total = 0;
    this.sendData();
    this.sentClearData();
  }

  sentClearData() {
    this.clearEvent.emit();
  }

  onArtUnitChange(event: KeyboardEvent) {
    const input = (event.target as HTMLInputElement).value;
    this.artUnit = input;
  }
  transformToUppercase(): void {
    if (this.familyName.length > 0) {
      this.familyName = this.familyName.toUpperCase();
    }
    if (this.givenName.length > 0) {
      this.givenName = this.givenName.toUpperCase();
    }
    if (this.artClassNo.length > 0) {
      this.artClassNo = this.artClassNo.toUpperCase();
    }
    if (this.artUnit.length > 0) {
      this.artUnit = this.artUnit.toUpperCase();
    }
    if (this.classDescription.length > 0) {
      this.classDescription = this.classDescription.toUpperCase();
    }
  }

  exportDataCallback() {
    var url = '/transfer-searches/excelReport?';
    this.theParams = '';
    if (this.workerNumber.length > 0) {
      this.theParams = 'workerNumber=' + this.workerNumber;
    }
    if (this.familyName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams = 'familyName=' + this.familyName;
    }
    if (this.givenName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'givenName=' + this.givenName;
    }
    if (this.artClassNo.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artClassNo=' + this.artClassNo;
    }
    if (this.artUnit.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artUnit=' + this.artUnit;
    }
    if (this.classDescription.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'titleText=' + this.classDescription;
    }
    if (this.theParams.length > 0) {
      this.theParams += '&limit=1000&showAll=true&sortColumn=workerNumber&sortOrder=asc';
    }

    alert(url + this.theParams);
    this.httpService.get(url + this.theParams).subscribe((response: any) => {
      var data = response.data;

      var url = URL.createObjectURL(new Blob([data]));
      var a = document.createElement('a');
      a.href = url;
      a.download = 'transfer-search.xls';
      a.target = '_blank';
      a.click();
      alert('export::::' + a);
    });
  }
  search() {
    // Emit event to notify parent that search has started
    this.searchStartEvent.emit();
    this.clearToastEvent.emit();

    let responseCreate;
    this.theParams = '';
    if (this.workerNumber.length > 0) {
      this.theParams = 'workerNumber=' + this.workerNumber;
    }
    if (this.familyName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams = 'familyName=' + this.familyName;
    }
    if (this.givenName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'givenName=' + this.givenName;
    }
    if (this.artClassNo.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artClassNo=' + this.artClassNo;
    }
    if (this.artUnit.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artUnit=' + this.artUnit;
    }
    if (this.classDescription.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'titleText=' + this.classDescription;
    }
    if (this.theParams.length > 0) {
      this.theParams += `&limit=${this.limit}&skip=${this.skip}&sortColumn=${this.sortColumn}&sortOrder=${this.sortOrder}`;
    }

    return this.httpService
      .get('/transfer-searches?' + this.theParams + `&showAll=${this.showAll}`)
      .toPromise()
      .then(
        (response: any) => {
          responseCreate = {
            worker: response.results,
            status: response.status,
            statusText: 'Created',
          };
          this.total = response.meta.total;
          this.searchResults = response.results;
          response.results.forEach((transferSearchAssignment: any, assignmentIndex: number) => {
            const url = `/workers/${transferSearchAssignment.worker.workerId}/telecommunications`;

            this.httpService.get(url).subscribe((response1: any) => {
              response1.results.forEach((telephone: any) => {
                if (this.searchResults[assignmentIndex] != null && telephone.primaryIndicator) {
                  this.searchResults[assignmentIndex].telephoneNo = telephone.telephoneNo;
                }
              });
            });

            const url1 = `/workers/${transferSearchAssignment.worker.workerId}/assignments`;

            this.httpService.get(url1).subscribe((response1: any) => {
              response1.results.forEach((location: any) => {
                if (
                  this.searchResults[assignmentIndex] != null &&
                  location.primaryLocationIndicator
                ) {
                  this.searchResults[assignmentIndex].location =
                    location.assignmentLocation.building.code +
                    '-' +
                    location.assignmentLocation.building.floorNumber +
                    location.assignmentLocation.corridorId +
                    location.assignmentLocation.roomId;
                }
              });
            });
          });
          this.sendData();
          return responseCreate;
        },
        (response) => {
          this.searchResults = [];
          this.sendData();
        }
      )
      .catch((response) => {
        this.searchResults = [];
        return Promise.reject(response);
      });
  }

  searchAll() {
    let responseCreate;
    this.theParams = '';
    if (this.workerNumber.length > 0) {
      this.theParams = 'workerNumber=' + this.workerNumber;
    }
    if (this.familyName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams = 'familyName=' + this.familyName;
    }
    if (this.givenName.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'givenName=' + this.givenName;
    }
    if (this.artClassNo.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artClassNo=' + this.artClassNo;
    }
    if (this.artUnit.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'artUnit=' + this.artUnit;
    }
    if (this.classDescription.length > 0) {
      if (this.theParams.length > 0) {
        this.theParams += '&';
      }
      this.theParams += 'titleText=' + this.classDescription;
    }
    if (this.theParams.length > 0) {
      this.theParams += `&limit=${this.limit}&skip=${this.skip}&sortColumn=${this.sortColumn}&sortOrder=${this.sortOrder}&showAll=true`;
    }
    return this.httpService.get('/transfer-searches?' + this.theParams).subscribe(
      (response: any) => {
        responseCreate = {
          worker: response.results,
          status: response.status,
          statusText: 'Created',
        };
        this.searchResults = response.results;
        response.results.forEach((transferSearchAssignment: any, assignmentIndex: number) => {
          const url = `/workers/${transferSearchAssignment.worker.workerId}/telecommunications`;

          this.httpService.get(url).subscribe((response1: any) => {
            response1.results.forEach((telephone: any) => {
              if (telephone.primaryIndicator) {
                this.searchResults[assignmentIndex].telephoneNo = telephone.telephoneNo;
              }
            });
          });

          const url1 = `/workers/${transferSearchAssignment.worker.workerId}/assignments`;

          this.httpService.get(url1).subscribe((response1: any) => {
            response1.results.forEach((location: any) => {
              if (location.primaryLocationIndicator) {
                this.searchResults[assignmentIndex].location =
                  location.assignmentLocation.building.code +
                  '-' +
                  location.assignmentLocation.building.floorNumber +
                  location.assignmentLocation.corridorId +
                  location.assignmentLocation.roomId;
              }
            });
          });
        });
        this.sendData();
        return responseCreate;
      },
      (response) => {
        return;
      }
    );
  }
  setSearchType(searchType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.Search = searchType;

    if (this.Search) {
      this.savedSearchCriteria = {
        SearchText: this.SearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria.value,
        },
        SearchBusinessAreaCode: this.SearchBusinessAreaCode,
        SearchShortName: this.SearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo.workerNumber,
      };
      this.clearAdvanvedSearch();
      //firstPage();
    } else {
      if (this.checkBlankAdvanceSearch()) {
        this.searchResultsCount = '';
        return;
      }
      //this.savedSearchCriteria = angular.copy(advanceSearchOptions);
      this.SearchText = '';
      this.SearchBusinessAreaCode = '';
      this.SearchShortName = '';
      this.SearchAcronym = '';
      // begin set default basic search to Last Name
      // angular.forEach(SearchCriteria, function(Search) {
      //     if (Search.value === 'workerNumber' && Search.description === 'Worker number') {
      //         selectedSearchCriteria = Search;
      //     }
      // });
      // end set default to Last Name
      this.SearchDiv = true;
      this.SearchAcronymDiv = false;
      this.SearchSSNDiv = false;
      this.SearchFirmnameDiv = false;
      this.SearchFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.SearchDOBDiv = false;
      this.SearchLoginDiv = false;

      // }
    }
  }
  setSearchInputBox() {
    this.invalidSearchText = false;
    this.invalidAcronym = false;
    if (this.selectedSearchCriteria.value === 'acronym') {
      this.SearchDiv = false;
      this.SearchAcronymDiv = true;
      this.SearchText = '';
      this.SearchSSNDiv = false;
      this.SearchFirmnameDiv = false;
      this.SearchfirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.SearchDOBDiv = false;
      this.SearchLoginDiv = false;
    } else {
      if (this.selectedSearchCriteria.value === 'SSN') {
        this.SearchSSNDiv = true;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchLoginDiv = false;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.SearchText = '';
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'firmName') {
        this.SearchSSNDiv = false;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = true;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.SearchLoginDiv = false;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
        this.SearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'firmAdministrator') {
        this.SearchSSNDiv = false;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchfirmAdministratorDiv = true;
        this.cedrRolesDiv = false;
        this.SearchLoginDiv = false;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
        this.SearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'cedrRoles') {
        this.SearchSSNDiv = false;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = true;
        this.SearchLoginDiv = false;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
        this.SearchDOBDiv = false;
      } else if (this.selectedSearchCriteria.value === 'birthDate') {
        this.SearchSSNDiv = false;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.SearchLoginDiv = false;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
        this.SearchDOBDiv = true;
      } else if (this.selectedSearchCriteria.value === 'loginId') {
        this.SearchSSNDiv = false;
        this.SearchDiv = false;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.SearchDOBDiv = false;
        this.SearchLoginDiv = true;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
      } else {
        this.SearchSSNDiv = false;
        this.SearchDiv = true;
        this.SearchAcronymDiv = false;
        this.SearchFirmnameDiv = false;
        this.SearchfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.SearchLoginDiv = false;
        this.SearchBusinessAreaCode = '';
        this.SearchShortName = '';
        this.SearchText = '';
        this.SearchDOBDiv = false;
      }
    }
  }
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
}
