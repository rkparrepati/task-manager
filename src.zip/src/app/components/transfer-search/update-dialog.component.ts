import {
  Component,
  ComponentRef,
  Inject,
  Input,
  OnInit,
  ViewChild,
  ElementRef,
  ViewContainerRef,
  Output,
  EventEmitter,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { FlatTreeControl } from '@angular/cdk/tree';

import { HttpService } from 'src/app/services/http.service';
import { TransferSearchService } from 'src/app/components/transfer-search/transfer-search.service';
/**
 * data with nested structure.
 * Each node has a name and an optiona list of children.
 */

interface FoodNode {
  name: string;
  organizationId: string;
  children?: FoodNode[];
}

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  node: any;
  organizationId: string;
  level: number;
}

@Component({
  templateUrl: './update-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
})
export class UpdateDialogComponent implements OnInit {
  dialogInfo: any;
  searchPurpose: any;
  transferSearchReferenceList: any = {};
  selected: string = '';
  selectedSearchCriteria: any;

  @ViewChild('updateRoleAssisatnceType') updateRoleAssisatnceType!: ElementRef<HTMLSelectElement>;
  public constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<UpdateDialogComponent>,
    private transferSearchService: TransferSearchService,
    private httpService: HttpService
  ) {
    this.dialogInfo = data;
    //  this.selectedSearchCriteria = data.searchPurpose.description;
  }

  public handleSelectedNode(node: any): void {
    this.dialogRef.close(node.node);
  }

  search() {}
  ngOnInit(): void {}

  public clearSearchResults(): void {}
  setBasicSearchInputBox() {
    this.data.searchPurpose.description = this.updateRoleAssisatnceType.nativeElement.value;
  }

  onConfirm(updatedDialogInfo: any): void {
    if (updatedDialogInfo) {
      const url = `/transfer-searches/${updatedDialogInfo.workerUspcArtClassId}?lockControlNumber=0`;

      this.httpService.put(url, updatedDialogInfo).subscribe({
        next: (response: any) => {
          // Use a Bootstrap-friendly alert or snackbar instead of native alert
          this.dialogRef.close({ confirmed: true, data: updatedDialogInfo });
        }
      });
    }
  }
  onCancel(): void {
    this.dialogRef.close(false);
  }
  public confirm(data: any) {}

  public closeThisDialog(data: string): void {}

  public searchResults(): void {}
}
