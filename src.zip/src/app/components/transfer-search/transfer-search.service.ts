import { Injectable } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { TransferValidationsService } from './transfer-validations.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TransferSearchService {
  private tabDataSource = new BehaviorSubject<any>({});
  currentTabData = this.tabDataSource.asObservable();

  // Toast message management (similar to AuditTrailReportService)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();

  changeTabData(data: any) {
    this.tabDataSource.next(data);
  }

  // Methods to update toast messages
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }
  constructor(
    private httpservice: HttpService,
    private appservice: AppService,
    private transferValidationsService: TransferValidationsService
  ) {}
  validateContractorId(dateOfBirth: string, contractorSSN: string) {
    const url = '/workers';
    const params = {
      isContractor: true,
      includeInactive: true,
      dateOfBirth: dateOfBirth,
      contractorSSN: contractorSSN,
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const _url = `${url}?${queryParams}`;
    return this.httpservice.get(_url);
  }
  canViewSecureData(userRoles: any, employmentType: string) {
    if (
      (employmentType === 'E' &&
        (userRoles.indexOf('InfraAdmin') >= 0 || userRoles.indexOf('InfraHRAdmin') >= 0)) ||
      userRoles.indexOf('InfraHRViewer') >= 0
    ) {
      return true;
    }

    const canViewContractorSecure =
      userRoles.indexOf('InfraAdmin') >= 0 ||
      userRoles.indexOf('InfraHRAdmin') >= 0 ||
      userRoles.indexOf('InfraContractorAdmin') >= 0 ||
      userRoles.indexOf('InfraOfficeCoordinator') >= 0;

    return employmentType === 'C' && canViewContractorSecure;
  }

  /**
   * GET operation to fetch art classes based on art class No.
   */
  getArtClassInformation(artClassNo: string, limit?: number, skip?: number) {
    const params = {
      artClassNo: artClassNo,
      ...(limit !== undefined && { limit }),
      ...(skip !== undefined && { skip }),
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const url = `/art-classes?${queryParams}`;
    return this.httpservice.get(url);
  }

  /**
   * GET operation to fetch worker information by worker number prefix
   */
  getWorkerInformationPrefix(searchOptions: any) {
    const params = {
      includeInactive: false,
      workerNumber: searchOptions.workerNumber,
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const url = `/workers?${queryParams}`;
    return this.httpservice.get(url);
  }

  /**
   * GET operation to fetch associated location assignments for a worker
   */
  getAssociatedLocationAssignments(workerId: string) {
    const url = `/workers/${workerId}/assignments`;
    return this.httpservice.get(url);
  }
}
