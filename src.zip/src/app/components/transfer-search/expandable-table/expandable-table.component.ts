import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-expandable-table',
  templateUrl: './expandable-table.component.html',
  styleUrls: ['./expandable-table.component.scss'],
  //   standalone: true,
  // imports: [CommonModule]
})
export class ExpandableTableComponent {
  @Input() rows: { workerNumber: string; familyName: string }[] = [];

  expandedRowId: number | null = null;
  //rows = input<{ id: number; name: string; details: string }[]>(); expandedRowId: number | null = null;
  toggleExpand(rowId: number): void {
    this.expandedRowId = this.expandedRowId === rowId ? null : rowId;
  }

  isRowExpanded(rowId: number): boolean {
    return this.expandedRowId === rowId;
  }
}
