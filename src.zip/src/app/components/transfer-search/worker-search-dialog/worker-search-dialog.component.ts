import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpService } from 'src/app/services/http.service';
import { TransferSearchService } from '../transfer-search.service';

@Component({
  selector: 'app-worker-search-dialog',
  templateUrl: './worker-search-dialog.component.html',
  styleUrls: ['./worker-search-dialog.component.scss'],
})
export class WorkerSearchDialogComponent implements OnInit {
  workerNumberWizard: string = '';
  workerNumberResults: boolean = false;
  showWorkerMessage: boolean = false;
  returnMessage: string = '';
  total: number = 0;
  workerInfo: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<WorkerSearchDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private httpService: HttpService,
    private transferSearchService: TransferSearchService
  ) {
    if (data && data.content) {
      this.workerNumberWizard = data.content;
    }
  }

  ngOnInit(): void {
    // Initialize if needed
  }

  clear(): void {
    this.workerNumberWizard = '';
    this.total = 0;
    this.workerInfo = [];
    this.workerNumberResults = false;
  }

  populateWorkerInformation(): void {
    if (!this.workerNumberWizard) {
      return;
    }

    // Check if worker number length is less than 5 to use prefix search
    const usesPrefixSearch = this.workerNumberWizard.length < 5;
    
    // Build URL based on search type
    const url = usesPrefixSearch
      ? `/workers?includeInactive=false&workerNumberPrefix=${this.workerNumberWizard}`
      : `/workers?includeInactive=false&workerNumber=${this.workerNumberWizard}`;

    this.httpService.get(url).subscribe(
      (response: any) => {
        this.workerInfo = response.results;
        this.total = response.meta?.total || response.results.length;
        this.workerNumberResults = true;
        this.showWorkerMessage = false;

        // Fetch location details for each worker
        this.workerInfo.forEach((worker, index) => {
          this.getWorkerLocation(worker.workerId, index);
        });
      },
      (error: any) => {
        this.total = 0;
        this.workerInfo = [];
        this.showWorkerMessage = true;
        this.returnMessage = 'No workers found that match the query';
        this.workerNumberResults = false;
      }
    );
  }

  getWorkerLocation(workerId: string, index: number): void {
    const url = `/workers/${workerId}/assignments`;

    this.httpService.get(url).subscribe(
      (response: any) => {
        const locations = response.results;
        const primaryLocation = locations.find((loc: any) => loc.primaryLocationIndicator);

        if (primaryLocation && primaryLocation.assignmentLocation) {
          const locationId = primaryLocation.assignmentLocation.locationId;

          // Fetch full location details
          this.httpService.get(`/locations/${locationId}`).subscribe(
            (locationResponse: any) => {
              this.workerInfo[index].location = locationResponse;
            },
            (error) => {            }
          );
        }
      },
      (error) => {      }
    );
  }

  hideWorkerMessage(): void {
    this.showWorkerMessage = false;
  }

  onSelect(worker: any): void {
    const result = {
      workerNumber: worker.workerNumber,
      familyName: worker.familyName,
      givenName: worker.givenName,
      workerId: worker.workerId,
    };
    this.dialogRef.close(result);
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }
}
