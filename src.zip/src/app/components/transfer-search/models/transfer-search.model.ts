export interface SearchResultItem {
  telephoneNo?: string;
  location?: string;
  worker?: any;
  organization?: any;
  artClass?: any;
  audit?: any;
  subclassRangeText?: string;
}

export interface TransferSearchResult {
  params?: string;
  length?: number;
  results: SearchResultItem[];
  [index: number]: SearchResultItem;
}
