import {
  Component,
  ComponentRef,
  Output,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  ViewChild,
  ElementRef,
  ViewContainerRef,
  ChangeDetectorRef,
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { FormsModule, FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { HttpParams } from '@angular/common/http';
import { TransferSearchService } from '../transfer-search.service';
import { WorkerSearchDialogComponent } from '../worker-search-dialog/worker-search-dialog.component';
import { ArtClassSearchDialogComponent } from '../art-class-search-dialog/art-class-search-dialog.component';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss'],
  providers: [DatePipe],
})
export class CreateComponent {
  //form: FormGroup;
  @Output() dataEvent = new EventEmitter<string>();
  workerNameDetails: string = '';
  searchPurpose: any;
  transferSearchReferenceList: any = [];
  selected: string = '';
  selectedSearchCriteria: any;
  invalidRoleAssisatnceType: string = '';
  subclassRangeText: string = '';
  titleText: boolean = false;

  // artClassInvalidMessage: string = '';

  artClassTitleText: string = '';
  artClassNo: string = '';
  invalidSubClasses: string = '';
  artUnit: string = '';
  workerModel: any;
  savedcreateCriteria: any;
  createBusinessAreaCode: any;
  createShortName: any;
  createOptions: any;
  createText: any;
  createPurpose: any;
  selectedcreateCriteria: any;
  clearAdvanvedcreate: any;
  checkBlankAdvancecreate: any;
  userInfo: any;
  createResultsCount: any;
  createAcronym: any;
  createDiv: any;
  createAcronymDiv: any;
  createSSNDiv: any;
  createFirmnameDiv: any;
  createFirmAdministratorDiv: any;
  create: any;
  cedrRolesDiv: any;
  createDOBDiv: any;
  createLoginDiv: any;
  invalidcreateText: any;
  invalidAcronym: any;
  createfirmAdministratorDiv: any;
  applicationTypeLowerCase: any;
  createCriteria: any;
  classDescription: string = '';
  workerNumber: string = '';
  familyName: string = '';
  givenName: string = '';
  createObject: any = {};
  createResults: any = { };//worker: null 
  searchResults: any = {};
  theParams: string = '';
  parentData = 'Hhello';
  artClassId: string = '';
  workerId: string = '';
  @ViewChild('roleAssisatnceType') roleAssisatnceType!: ElementRef<HTMLSelectElement>;
  @ViewChild('artClass') artClassControl: any;
  @ViewChild('workerNum') workerNumControl: any;
  invalidWorkerNumber: boolean = false;
  invalidRole: boolean = false;
  invalidArtClass: boolean = false;
  invalidSubclass: boolean = false;
  @ViewChild('assistanceForm') assistanceForm!: NgForm;

  // Validation Messages
  artClassInvalidMessage: string = 'Art Class not found';
  artClassRequiredMessage: string = 'Art Class is required';
  artClassMinLengthMessage: string = 'Art Class should be minimum 3 characters';
  workerNumberRequiredMessage: string = 'Worker number is required';
  workerNumberInvalidMessage: string = 'No workers found that match the query';
  subclassRequiredMessage: string = 'Subclasses are required';

  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private localStorageService: LocalStorageService,
    private transferSearchService: TransferSearchService,
    private authorizationService: AuthorizationService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}
  setBasicSearchInputBox() {
    this.searchPurpose = this.roleAssisatnceType.nativeElement.value;
    // this.data.workerUspcArtClassId = this.selectedSearchCriteria ;
  }
  searchKeyEventHandler(event: KeyboardEvent) {
    const input = (event.target as HTMLInputElement).value;
    this.artClassNo = input;
  }
  setTitleText() {}

  /**
   * Validates art class by calling the API
   * Called when user leaves the art class input field
   */
  validateArtClass(): void {
    // Mark field as touched to ensure validation messages display
    if (this.artClassControl) {
      this.artClassControl.control.markAsTouched();
    }

    // Clear previous validation state
    this.invalidArtClass = false;
    this.artClassTitleText = '';
    this.artClassId = '';

    // Don't validate if field is empty (required validation will handle it)
    if (!this.artClassNo || this.artClassNo.trim().length === 0) {
      return;
    }

    // Don't validate if less than 3 characters (minlength validation will handle it)
    if (this.artClassNo.length < 3) {
      return;
    }

    const params = new HttpParams().set('artClassNo', this.artClassNo);
    const url = `/art-classes`;

    this.httpService.getData(url, params).subscribe(
      (response: any) => {
        if (response.results && response.results.length > 0) {
          // Art class found - populate the information
          const artClass = response.results[0];
          this.artClassId = artClass.artClassId;
          this.artClassTitleText = '[' + artClass.titleText + ']';
          this.invalidArtClass = false;
          this.titleText = true;
        } else {
          // Art class not found
          this.invalidArtClass = true;
          this.artClassTitleText = '';
          this.artClassId = '';
        }
        // Manually trigger change detection to update the view immediately
        this.cdr.detectChanges();
      },
      (error: any) => {
        // Error occurred - art class not found (including 404)
        this.invalidArtClass = true;
        this.artClassTitleText = '';
        this.artClassId = '';
        // Manually trigger change detection to update the view immediately
        this.cdr.detectChanges();
      }
    );
  }

  /**
   * Validates worker number by calling the API
   * Called when user leaves the worker number input field
   */
  setWorkerName(): void {
    // Mark field as touched to ensure validation messages display
    if (this.workerNumControl) {
      this.workerNumControl.control.markAsTouched();
    }

    // Clear previous validation state
    this.invalidWorkerNumber = false;
    this.workerNameDetails = '';
    this.workerId = '';
    this.familyName = '';
    this.givenName = '';

    // Don't validate if field is empty (required validation will handle it)
    if (!this.workerNumber || this.workerNumber.trim().length === 0) {
      return;
    }

    // Don't validate if less than 3 characters (minlength validation will handle it)
    if (this.workerNumber.length < 3) {
      return;
    }

    const url1 = `/workers?includeInactive=false&workerNumber=${this.workerNumber}`;

    this.httpService.get(url1).subscribe(
      (response1: any) => {
        if (response1.results && response1.results.length > 0) {
          // Worker found - populate the information
          const worker = response1.results[0];
          this.workerId = worker.workerId;
          this.familyName = worker.familyName;
          this.givenName = worker.givenName;
          this.workerNameDetails = '[' + worker.familyName + ',' + worker.givenName + ']';
          this.invalidWorkerNumber = false;
        } else {
          // Worker not found
          this.invalidWorkerNumber = true;
          this.workerNameDetails = '';
          this.workerId = '';
          this.familyName = '';
          this.givenName = '';
        }
        // Manually trigger change detection to update the view immediately
        this.cdr.detectChanges();
      },
      (error: any) => {
        // Error occurred - worker not found (including 404)
        this.invalidWorkerNumber = true;
        this.workerNameDetails = '';
        this.workerId = '';
        this.familyName = '';
        this.givenName = '';
        // Manually trigger change detection to update the view immediately
        this.cdr.detectChanges();
      }
    );
  }
  searchArtClass() {
    // Open the art class search dialog
    const dialogRef = this.dialog.open(ArtClassSearchDialogComponent, {
      width: '1200px',
      disableClose: true,
      data: {
        content: this.artClassNo,
        title: 'Art Class Search',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.artClassNo = result.artClassNo;
        this.artClassTitleText = '[' + result.titleText + ']';
        this.artClassId = result.artClassId;
        this.invalidArtClass = false;
        this.titleText = true;
        // Manually trigger change detection to update the view immediately
        this.cdr.detectChanges();
      }
    });
  }
  sendData() {
    this.transferSearchService.changeTabData(this.createResults);
    this.dataEvent.emit(this.createResults);
    this.assistanceForm.resetForm({
        // We pass the defaults here so resetForm doesn't make them null
        artClassNo: '',
        workerNumber: '',
        subClasses: '',
        roleAssisatnceType: '',
      });
      this.artClassTitleText = '';
      this.workerNameDetails = '';
      this.invalidArtClass = false;
      this.invalidWorkerNumber = false;
  }


  createTransfer() {
    // Validate form before submission
    if (this.assistanceForm && this.assistanceForm.invalid) {
      // Mark all fields as touched to show validation errors
      Object.keys(this.assistanceForm.controls).forEach((key) => {
        this.assistanceForm.controls[key].markAsTouched();
      });

      // Collect validation error messages
      const errorMessages: string[] = [];

      // Check Art Class validation
      const artClassControl = this.assistanceForm.controls['artClassNo'];
      if (artClassControl) {
        if (artClassControl.errors?.['required']) {
          errorMessages.push(this.artClassRequiredMessage);
        } else if (artClassControl.errors?.['minlength']) {
          errorMessages.push(this.artClassMinLengthMessage);
        }
      }
      if (this.invalidArtClass) {
        errorMessages.push(this.artClassInvalidMessage);
      }

      // Check Worker Number validation
      const workerNumControl = this.assistanceForm.controls['workerNumber'];
      if (workerNumControl) {
        if (workerNumControl.errors?.['required']) {
          errorMessages.push(this.workerNumberRequiredMessage);
        }else if (workerNumControl.errors?.['minlength']) {
          errorMessages.push(this.workerNumberInvalidMessage);
        }
      }
      if (this.invalidWorkerNumber) {
        errorMessages.push(this.workerNumberInvalidMessage);
      }

      // Check Subclasses validation
      const subClassesControl = this.assistanceForm.controls['subClasses'];
      if (subClassesControl && subClassesControl.errors?.['required']) {
        errorMessages.push(this.subclassRequiredMessage);
      }

      // Send validation errors as an array to the acme toast component with return code 700
      if (errorMessages.length > 0) {
        this.transferSearchService.updateReturnCode('700');
        this.transferSearchService.updateReturnMessage(
          'Invalid input was detected. Please correct required/invalid fields.'
        );
        this.transferSearchService.updateReturnMessageArray(errorMessages);
        this.transferSearchService.updateHideMessage(false);
      }

      return;
    }


    const searchItem = this.transferSearchReferenceList.filter(
      (item1: { value: any }) => item1.value === this.searchPurpose
    );
    
    // Safety check: ensure searchItem exists
    if (!searchItem || searchItem.length === 0) {
      this.transferSearchService.updateReturnCode('error');
      this.transferSearchService.updateReturnMessageArray(['Invalid search purpose selected']);
      this.transferSearchService.updateHideMessage(false);
      return;
    }
    
    const dt = this.datePipe.transform(new Date(), 'yyyy-MM-ddThh:mm:ss');

    this.createOptions = {
      worker: {
        workerId: this.workerId,
      },
      artClass: {
        artClassId: this.artClassId,
      },
      searchPurpose: {
        id: searchItem[0].id,
      },
      subclassRangeText: this.subclassRangeText,
      lifecycle: {
        beginDate: dt,
        endDate: null,
      },
    };
    this.httpService.post('/transfer-searches', this.createOptions).subscribe({
      next: (response1: any) => {
        // Store the created transfer search record (matching legacy line 360)
        this.createResults = response1;

        // Fetch telecommunications data for the worker (matching legacy lines 674-678)
        this.httpService.get(`/workers/${response1.worker.workerId}/telecommunications`).subscribe({
          next: (telecomResponse: any) => {
            // Find and set primary telephone number (matching legacy lines 716-720)
            if (telecomResponse.results && telecomResponse.results.length > 0) {
              telecomResponse.results.forEach((telephone: any) => {
                if (telephone.primaryIndicator) {
                  this.createResults.telephoneNo = telephone.telephoneNo;
                }
              });
            }
          },
          error: (telecomError: any) => {
            // Log error but don't block the creation process
          }
        });

        // Fetch location assignments for the worker (matching legacy lines 680-693)
        this.httpService.get(`/workers/${response1.worker.workerId}/assignments`).subscribe({
          next: (locationResponse: any) => {
            // Find and set primary location (matching legacy lines 684-692)
            if (locationResponse.results && locationResponse.results.length > 0) {
              locationResponse.results.forEach((location: any) => {
                if (location.primaryLocationIndicator) {
                  this.createResults.location =
                    location.assignmentLocation.building.code +
                    '-' +
                    location.assignmentLocation.building.floorNumber +
                    location.assignmentLocation.corridorId +
                    location.assignmentLocation.roomId;
                }
              });
            }
          },
          error: (locationError: any) => {
            // Legacy checks for timeout/403 issues (lines 693-695)
            if (locationError.status === 403) {
              const errorMessages: string[] = ['Access denied to location information'];
              this.transferSearchService.updateHideMessage(false);
              this.transferSearchService.updateReturnCode(locationError.status);
              this.transferSearchService.updateReturnMessage(
                'Failed to retrieve location information'
              );
              this.transferSearchService.updateReturnMessageArray(errorMessages);
            }
          }
        });

        // Send success message with return code 200 (matching legacy lines 348-352)
        const returnMessage =
          'Successfully created  assignment for worker number ' + response1.worker.workerNumber;
        this.transferSearchService.updateReturnCode(200);
        this.transferSearchService.updateReturnMessage(returnMessage);
        this.transferSearchService.updateReturnMessageArray([]); // Clear any previous error arrays
        this.transferSearchService.updateHideMessage(false);

        // Matching legacy lines 697-712: If no existing assignments, fetch the created record from server
        // This ensures we get the complete record with correct worker status
        const searchUrl = `/transfer-searches?workerNumber=${response1.worker.workerNumber}&familyName=${response1.worker.familyName}&givenName=${response1.worker.givenName}&artClassNo=${response1.artClass.artClassNo}&limit=10&showAll=false&sortColumn=workerNumber&sortOrder=asc`;
        
        this.httpService.get(searchUrl).subscribe({
          next: (searchResponse: any) => {
            if (searchResponse.results && searchResponse.results.length > 0) {
              // Use the fetched record which has correct worker status
              this.createResults = searchResponse.results[0];
              
              // Re-fetch telecommunications and location for the fetched record
              this.httpService.get(`/workers/${this.createResults.worker.workerId}/telecommunications`).subscribe({
                next: (telecomResponse: any) => {
                  if (telecomResponse.results && telecomResponse.results.length > 0) {
                    telecomResponse.results.forEach((telephone: any) => {
                      if (telephone.primaryIndicator) {
                        this.createResults.telephoneNo = telephone.telephoneNo;
                      }
                    });
                  }
                }
              });

              this.httpService.get(`/workers/${this.createResults.worker.workerId}/assignments`).subscribe({
                next: (locationResponse: any) => {
                  if (locationResponse.results && locationResponse.results.length > 0) {
                    locationResponse.results.forEach((location: any) => {
                      if (location.primaryLocationIndicator) {
                        this.createResults.location =
                          location.assignmentLocation.building.code +
                          '-' +
                          location.assignmentLocation.building.floorNumber +
                          location.assignmentLocation.corridorId +
                          location.assignmentLocation.roomId;
                      }
                    });
                  }
                }
              });

              // Emit the fetched and enriched createResults
              this.sendData();
            }
          },
          error: (searchError: any) => {
            // If search fails, still emit the original response
            this.sendData();
          }
        });
      },
      error: (error: any) => {
        // Handle error response - matching audit-trail-report pattern
        const errorMessages: string[] = [];
        
        // Determine error message based on status code
        if (error.status === 409 || error.status === 400) {
          errorMessages.push('Record already exists with given criteria');
        } else if (error.status === 403) {
          errorMessages.push('Access denied. You do not have permission to create this assignment');
        } else if (error.status === 404) {
          errorMessages.push('Resource not found. Please verify the worker and art class information');
        } else {
          errorMessages.push(error.error?.message || 'An error occurred while creating the assignment');
        }
        
        this.createResults = {};

        // Send error message with appropriate return code - matching audit-trail-report pattern
        this.transferSearchService.updateReturnCode(error.status || 500);
        this.transferSearchService.updateReturnMessage(
          'Failed to create assignment. Please review the errors below.'
        );
        this.transferSearchService.updateReturnMessageArray(errorMessages);
        this.transferSearchService.updateHideMessage(false);

        // Don't call sendData on error - legacy doesn't add failed records
      }
    });
      
  }


  ngOnInit() {
    const url = '/references/search-purposes?includeInactive=false';
    this.httpService.get(url).subscribe((response1: any) => {
      this.transferSearchReferenceList = response1.results;
      // Set default searchPurpose to 'Search' - find the matching object (matching legacy lines 594-608)
      const defaultPurpose = response1.results.find((item: any) => item.value === 'Search');
      if (defaultPurpose) {
        this.searchPurpose = defaultPurpose.value;
      } else {
        // Fallback to first item if 'Search' not found
        this.searchPurpose = response1.results[0]?.value || 'Search';
      }
      this.dataEvent.emit(this.transferSearchReferenceList);
    });
  }
  createKeyEventHandler(event: KeyboardEvent) {
    const input = (event.target as HTMLInputElement).value;
    this.artClassNo = input;
  }

  clearCreateValue() {
    // this.workerNumber.length
    this.familyName = '';
    this.workerNumber = '';
    this.givenName = '';
    this.artClassNo = '';
    this.artUnit = '';
    this.classDescription = '';
    this.createResults = '';
    this.subclassRangeText = '';

    this.invalidArtClass = false;
    this.invalidWorkerNumber = false;
    this.artClassTitleText = '';
    this.workerNameDetails = '';

    // 3. Reset Angular's Form State (removes 'has-error' classes and 'submitted' status)
    if (this.assistanceForm) {
      this.assistanceForm.resetForm({
        // We pass the defaults here so resetForm doesn't make them null
        artClassNo: '',
        workerNumber: '',
        subClasses: '',
        roleAssisatnceType: 'Search',
      });
    }

    // Clear toast message
    this.transferSearchService.updateHideMessage(true);
    this.transferSearchService.updateReturnMessage('');
    this.transferSearchService.updateReturnMessageArray([]);
    this.transferSearchService.updateReturnCode('');
  }
  onArtUnitChange(event: KeyboardEvent) {
    const input = (event.target as HTMLInputElement).value;
    this.artUnit = input;
  }
  transformToUppercase(): void {
    if (this.familyName.length > 0) {
      this.familyName = this.familyName.toUpperCase();
    }
    if (this.givenName.length > 0) {
      this.givenName = this.givenName.toUpperCase();
    }
    if (this.artClassNo.length > 0) {
      this.artClassNo = this.artClassNo.toUpperCase();
    }
    if (this.artUnit.length > 0) {
      this.artUnit = this.artUnit.toUpperCase();
    }
    if (this.classDescription.length > 0) {
      this.classDescription = this.classDescription.toUpperCase();
    }
  }
  searchWorker() {
    // Open the worker search dialog only when button is clicked
    const dialogRef = this.dialog.open(WorkerSearchDialogComponent, {
      width: '1200px',
      disableClose: true,
      data: {
        content: this.workerNumber,
        title: 'Worker Number Search',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.workerNumber = result.workerNumber;
        this.familyName = result.familyName;
        this.givenName = result.givenName;
        this.workerId = result.workerId;
        this.workerNameDetails = '[' + result.familyName + ',' + result.givenName + ']';
        this.invalidWorkerNumber = false;
        this.cdr.detectChanges();
      }
    });
  }
  setcreateType(createType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.create = createType;

    if (this.create) {
      this.savedcreateCriteria = {
        createText: this.createText,
        selectedcreateCriteria: {
          value: this.selectedcreateCriteria.value,
        },
        createBusinessAreaCode: this.createBusinessAreaCode,
        createShortName: this.createShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo.workerNumber,
      };
      this.clearAdvanvedcreate();
      //firstPage();
    } else {
      if (this.checkBlankAdvancecreate()) {
        this.createResultsCount = '';
        return;
      }
      //this.savedcreateCriteria = angular.copy(advancecreateOptions);
      this.createText = '';
      this.createBusinessAreaCode = '';
      this.createShortName = '';
      this.createAcronym = '';
      // begin set default basic create to Last Name
      // angular.forEach(createCriteria, function(create) {
      //     if (create.value === 'workerNumber' && create.description === 'Worker number') {
      //         selectedcreateCriteria = create;
      //     }
      // });
      // end set default to Last Name
      this.createDiv = true;
      this.createAcronymDiv = false;
      this.createSSNDiv = false;
      this.createFirmnameDiv = false;
      this.createFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.createDOBDiv = false;
      this.createLoginDiv = false;

      // }
    }
  }
  setcreateInputBox() {
    this.invalidcreateText = false;
    this.invalidAcronym = false;
    if (this.selectedcreateCriteria.value === 'acronym') {
      this.createDiv = false;
      this.createAcronymDiv = true;
      this.createText = '';
      this.createSSNDiv = false;
      this.createFirmnameDiv = false;
      this.createfirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.createDOBDiv = false;
      this.createLoginDiv = false;
    } else {
      if (this.selectedcreateCriteria.value === 'SSN') {
        this.createSSNDiv = true;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createLoginDiv = false;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.createText = '';
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createDOBDiv = false;
      } else if (this.selectedcreateCriteria.value === 'firmName') {
        this.createSSNDiv = false;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = true;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.createLoginDiv = false;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
        this.createDOBDiv = false;
      } else if (this.selectedcreateCriteria.value === 'firmAdministrator') {
        this.createSSNDiv = false;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createfirmAdministratorDiv = true;
        this.cedrRolesDiv = false;
        this.createLoginDiv = false;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
        this.createDOBDiv = false;
      } else if (this.selectedcreateCriteria.value === 'cedrRoles') {
        this.createSSNDiv = false;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = true;
        this.createLoginDiv = false;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
        this.createDOBDiv = false;
      } else if (this.selectedcreateCriteria.value === 'birthDate') {
        this.createSSNDiv = false;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.createLoginDiv = false;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
        this.createDOBDiv = true;
      } else if (this.selectedcreateCriteria.value === 'loginId') {
        this.createSSNDiv = false;
        this.createDiv = false;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.createDOBDiv = false;
        this.createLoginDiv = true;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
      } else {
        this.createSSNDiv = false;
        this.createDiv = true;
        this.createAcronymDiv = false;
        this.createFirmnameDiv = false;
        this.createfirmAdministratorDiv = false;
        this.cedrRolesDiv = false;
        this.createLoginDiv = false;
        this.createBusinessAreaCode = '';
        this.createShortName = '';
        this.createText = '';
        this.createDOBDiv = false;
      }
    }
  }
  createKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setcreateType(true);
    }
  }
}
