import {
  Component,
  OnInit,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  SimpleChanges,
  ViewChild,
  OnDestroy,
} from '@angular/core';

import { DatePipe } from '@angular/common';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';

import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { PaginationService } from 'src/app/components/core/pagination/pagination.service';
import { ConfirmDialogComponent } from 'src/app/components/transfer-search/confirm-dialog.component';
import { UpdateDialogComponent } from 'src/app/components/transfer-search/update-dialog.component';
//'./components/firm-dialog/confirm-dialog.component';

import { MatDialog } from '@angular/material/dialog';
import { TransferSearchService } from './transfer-search.service';
import { OnSameUrlNavigation } from '@angular/router';

@Component({
  selector: 'app-transfer-search',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './transfer-search.component.html',
  styleUrls: ['./transfer-search.component.scss'],
  providers: [DatePipe],
})
export class TransferSearchComponent implements OnInit, OnDestroy {
  receivedData1: string = '';
  workerRecords: any = { meta: {}, results: [] };
  searchurl: string = '';
  
  // Flag to track if create form has been cleared - prevents persisting cleared session data in search tab
  isCreateFormCleared: boolean = false;
  
  // Unified data model matching legacy: vm.transferSearchModel.transferSearchAssignments
  transferSearchAssignments: any[] = [];
  
  // Keep these for backward compatibility but they'll reference the unified array
  searchResults: any = {};
  createResults: any = { worker: null };
  rows = [];

  // Cache for worker phone numbers and locations indexed by workerId
  workerPhoneLocationCache: Map<number, { phones: any[]; locations: any[] }> = new Map();

  // Pagination parameters for search component bindings
  searchLimit: number = 10;
  searchSkip: number = 0;
  searchSortColumn: string = 'workerNumber';
  searchSortOrder: string = 'asc';
  searchShowAll: boolean = false;
  currentPage: number = 1;
  skip: number = 0;
  limit: number = 10;
  
  // Prefill values for search inputs (matching legacy lines 703-708)
  prefillWorkerNumber: string = '';
  prefillFamilyName: string = '';
  prefillGivenName: string = '';
  prefillArtClassNo: string = '';
  
  // Flag to track if prefilled data from create tab has been cleared in search tab
  isPrefillDataCleared: boolean = false;

  // Toast message properties for app-acme-navbar-component
  main = { creationDate: new Date() };
  moduleName = 'USPC Challenge Assistance';
  appTitle = 'USPC Challenge Assistance';
  hideMessage = true;
  returnMessage = '';
  returnCode: string | number = '';
  accessDenied = false;
  resetTimeout = null;

  onSearchStart() {
    // Show loading message when search starts
    this.showWait = true;
    this.cdr.detectChanges();
  }

  receivedData(data: any) {
    // Hide loading message when data is received
    this.showWait = false;

    // Handle data structure with pagination from search component
    if (data.results !== undefined && data.pagination) {
      // Data from search component with pagination - update unified array
      this.transferSearchAssignments = data.results;
      this.searchResults = data.results; // Keep for backward compatibility
      this.searchurl = data.params || '';

      // Update pagination parameters from the emitted data
      if (data.pagination) {
        this.searchLimit = data.pagination.limit || 10;
        this.searchSkip = data.pagination.skip || 0;
        this.searchSortColumn = data.pagination.sortColumn || 'workerNumber';
        this.searchSortOrder = data.pagination.sortOrder || 'asc';
        this.searchShowAll = data.pagination.showAll || false;
      }

      this.total = data.total;

      if (this.transferSearchAssignments.length > 0) {
        this.searchResultsCount =
          data.total + ' Search record(s) found with the entered search criteria';
      } else {
        this.searchResultsCount = ' 0 Search record(s) found with the entered search criteria';
      }
    } else if (data.worker != null) {
      // Handle create result from create component (matching legacy lines 672-713)
      this.createResults = data;
      
      // Reset prefill cleared flag when new data is created
      this.isPrefillDataCleared = false;
       
       // Add to unified array - matching legacy line 696: vm.transferSearchAssignments.splice(0, 0, transferSearchAssignments)
       // Initialize array if it doesn't exist
       if (!this.transferSearchAssignments) {
         this.transferSearchAssignments = [];
       }
       
       // Add created record to beginning of array
       this.transferSearchAssignments.unshift(data);
       this.total = this.transferSearchAssignments.length;
       this.searchResultsCount = this.total + ' Search record(s) found with the entered search criteria';
       
       // Set prefill values for search inputs (matching legacy lines 703-708)
       // Only set if prefill data hasn't been cleared
       if (!this.isPrefillDataCleared) {
         this.prefillWorkerNumber = data.worker.workerNumber;
         this.prefillFamilyName = data.worker.familyName;
         this.prefillGivenName = data.worker.givenName;
         this.prefillArtClassNo = data.artClass.artClassNo;
       }
      
      this.rows = data.worker;
      this.workerRecords = data;
      this.receivedData1 =
        'Successfully created  assignment for worker number ' + data.worker.workerNumber;

      // Show success message for create using service
      this.transferSearchService.updateHideMessage(false);
      this.returnCode = 200;
      this.returnMessage = `Successfully created assignment for worker number ${data.worker.workerNumber}`;
      this.transferSearchService.updateReturnMessage(this.returnMessage);

      const url = `/workers/${data.worker.workerId}/telecommunications`;

      this.httpService.get(url).subscribe((response1: any) => {
        // Store all phones in cache
        this.workerPhoneLocationCache.set(data.worker.workerId, {
          phones: response1.results,
          locations: this.workerPhoneLocationCache.get(data.worker.workerId)?.locations || [],
        });

        response1.results.forEach((telephone: any, index: number) => {
          if (telephone.primaryIndicator) {
            this.createResults.telephoneNo = telephone.telephoneNo;
            // Update in unified array if it exists there
            const idx = this.transferSearchAssignments.findIndex(
              (a: any) => a.workerUspcArtClassId === data.workerUspcArtClassId
            );
            if (idx >= 0) {
              this.transferSearchAssignments[idx].telephoneNo = telephone.telephoneNo;
            }
          }
        });
        this.cdr.detectChanges();
      });

      const url1 = `/workers/${data.worker.workerId}/assignments`;

      this.httpService.get(url1).subscribe((response1: any) => {
        // Store all locations in cache
        const existingCache = this.workerPhoneLocationCache.get(data.worker.workerId);
        this.workerPhoneLocationCache.set(data.worker.workerId, {
          phones: existingCache?.phones || [],
          locations: response1.results,
        });

        response1.results.forEach((location: any, index: number) => {
          if (location.primaryLocationIndicator) {
            const locationStr =
              location.assignmentLocation.building.code +
              '-' +
              location.assignmentLocation.building.floorNumber +
              location.assignmentLocation.corridorId +
              location.assignmentLocation.roomId;
            this.createResults.location = locationStr;
            // Update in unified array if it exists there
            const idx = this.transferSearchAssignments.findIndex(
              (a: any) => a.workerUspcArtClassId === data.workerUspcArtClassId
            );
            if (idx >= 0) {
              this.transferSearchAssignments[idx].location = locationStr;
            }
          }
        });
        this.cdr.detectChanges();
      });

      this.cdr.detectChanges();
    } else {
      // Handle empty or cleared data
      this.total = 0;
      // Don't display error message when switching tabs
    }
  }

  clearToast() {
    // Reset toast message using service
    this.transferSearchService.updateHideMessage(true);
    this.transferSearchService.updateReturnMessage('');
    this.returnCode = '';
  }

  clearData() {
    this.searchResultsCount = '';
    this.showType = 'active';
    // Hide loading message when clearing data
    this.showWait = false;
    // Reset toast message using service
    this.transferSearchService.updateHideMessage(true);
    this.transferSearchService.updateReturnMessage('');
    this.returnCode = '';
    // Mark prefill data as cleared - prevents re-displaying cleared prefill values from create tab
    this.isPrefillDataCleared = true;
    // Clear the prefill values
    this.prefillWorkerNumber = '';
    this.prefillFamilyName = '';
    this.prefillGivenName = '';
    this.prefillArtClassNo = '';
  }

  disableShowRadioButton: any;
  showType: any = 'active';
  setActiveWorkerList: any;
  total: any;
  _totalRecordsCount: number = 0;

  @Input() set totalRecordsCount(value: number) {
    this._totalRecordsCount = value;
  }
  @Output() pageChange: EventEmitter<PageEvent> = new EventEmitter();

  pageSize: number = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25, 50];

  pageEvent: PageEvent = new PageEvent();
  sortColumn: string = 'workerNumber';
  sortDirection: string = 'asc';
  //userRoles: any;

  loadingMessage: string = 'Loading search results..';
  userRoles = ['InfraAdmin'];
  updateWorkerButton: any;
  workerModel: any = { workerList: [] };
  userInfo: any;
  worker: any = {};
  searchResultsCount: string = '';
  otherSearchView: string = 'search';
  tabs: string[] = ['Search', 'Create'];
  selected: any;
  expandedAssignment: any | null = null;
  activatedTabIndex: number = 0;
  transferSearchAssignment: any;
  htmlContent: string = '';
  expandedIndex: number | null = null;
  showWait = false;
  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private utilitiesService: UtilityService,
    private localStorageService: LocalStorageService,
    public transferSearchService: TransferSearchService,
    private paginationService: PaginationService,
    private dialog: MatDialog,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef
  ) {}

  callBack(event: any) {
    // Callback for navbar component events
  }

  openConfirmDialog(transferSearchAssignment: any) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '450px',
      disableClose: true,
      data: {
        worker: transferSearchAssignment.worker, // Ensure these match your actual data structure
        artClass: transferSearchAssignment.artClass,
        title: 'Delete Assignment?',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.scrolltoTop();
      if (result) {
        const url = `/transfer-searches/${transferSearchAssignment.workerUspcArtClassId}`;

        this.httpService.delete(url).subscribe({
          next: (response1: any) => {
            // Show success message using service
            this.transferSearchService.updateHideMessage(false);
            this.returnCode = 200;
            this.returnMessage = `Successfully deleted assignment for worker number ${transferSearchAssignment.worker.workerNumber}`;
            this.transferSearchService.updateReturnMessage(this.returnMessage);

            // Refresh the table with newly called data from the server
            this.showWait = true;
            this.cdr.detectChanges();

            // Determine showAll based on current showType
            const activestatus = this.showType === 'all';

            // Build the search URL with current parameters
            let baseParams = this.searchurl;
            baseParams = baseParams.replace(/&?limit=\d+/g, '');
            baseParams = baseParams.replace(/&?skip=\d+/g, '');
            baseParams = baseParams.replace(/&?sortColumn=[^&]*/g, '');
            baseParams = baseParams.replace(/&?sortOrder=[^&]*/g, '');
            baseParams = baseParams.replace(/&?showAll=(true|false)/g, '');
            baseParams = baseParams.replace(/^&+|&+$/g, '');

            const refreshUrl =
              '/transfer-searches?' +
              baseParams +
              '&limit=' +
              this.limit +
              '&skip=' +
              this.skip +
              '&showAll=' +
              activestatus +
              '&sortColumn=' +
              this.searchSortColumn +
              '&sortOrder=' +
              this.searchSortOrder;

            this.httpService.get(refreshUrl).subscribe({
              next: (response: any) => {
                // Update both unified array and searchResults
                this.transferSearchAssignments = response.results;
                this.searchResults = response.results;
                this.total = response.results.length;
                this.searchResultsCount =
                  this.total + ' Search record(s) found with the entered search criteria';
                // Fetch phone and location data for each assignment
                response.results.forEach((assignment: any, assignmentIndex: number) => {
                  const workerId = assignment.worker.workerId;

                  // Fetch telephone information
                  const telUrl = `/workers/${workerId}/telecommunications`;
                  this.httpService.get(telUrl).subscribe((telResponse: any) => {
                    this.workerPhoneLocationCache.set(workerId, {
                      phones: telResponse.results,
                      locations: this.workerPhoneLocationCache.get(workerId)?.locations || [],
                    });

                    telResponse.results.forEach((telephone: any) => {
                      if (telephone.primaryIndicator) {
                        this.searchResults[assignmentIndex].telephoneNo = telephone.telephoneNo;
                        this.transferSearchAssignments[assignmentIndex].telephoneNo =
                          telephone.telephoneNo;
                      }
                    });
                    if (!this.searchResults[assignmentIndex].telephoneNo) {
                      this.searchResults[assignmentIndex].telephoneNo = '';
                      this.transferSearchAssignments[assignmentIndex].telephoneNo = '';
                    }
                    this.cdr.detectChanges();
                  });

                  // Fetch location information
                  const locUrl = `/workers/${workerId}/assignments`;
                  this.httpService.get(locUrl).subscribe((locResponse: any) => {
                    const existingCache = this.workerPhoneLocationCache.get(workerId);
                    this.workerPhoneLocationCache.set(workerId, {
                      phones: existingCache?.phones || [],
                      locations: locResponse.results,
                    });

                    locResponse.results.forEach((location: any) => {
                      if (location.primaryLocationIndicator) {
                        const locationStr =
                          location.assignmentLocation.building.code +
                          '-' +
                          location.assignmentLocation.building.floorNumber +
                          location.assignmentLocation.corridorId +
                          location.assignmentLocation.roomId;
                        this.searchResults[assignmentIndex].location = locationStr;
                        this.transferSearchAssignments[assignmentIndex].location = locationStr;
                      }
                    });
                    if (!this.searchResults[assignmentIndex].location) {
                      this.searchResults[assignmentIndex].location = '';
                      this.transferSearchAssignments[assignmentIndex].location = '';
                    }
                    this.cdr.detectChanges();
                  });
                });

                this.showWait = false;
                this.cdr.detectChanges();
              },
              error: (refreshError: any) => {
                // If refresh fails, fall back to local filtering
                this.searchResults = this.searchResults.filter(
                  (assignment: any) =>
                    assignment.workerUspcArtClassId !== transferSearchAssignment.workerUspcArtClassId
                );
                this.transferSearchAssignments = this.transferSearchAssignments.filter(
                  (assignment: any) =>
                    assignment.workerUspcArtClassId !== transferSearchAssignment.workerUspcArtClassId
                );
                this.total = this.searchResults.length;
                this.searchResultsCount =
                  this.total + ' Search record(s) found with the entered search criteria';
                this.showWait = false;
                this.cdr.detectChanges();
              },
            });
          },
          error: (error: any) => {
            // Show error message using service
            this.transferSearchService.updateHideMessage(false);
            this.returnCode = error.status || 500;
            this.returnMessage = error.error?.message || 'Failed to delete assignment';
            this.transferSearchService.updateReturnMessage(this.returnMessage);
            this.cdr.detectChanges();
          },
        });
      }
    });
  }
  updateDialog(transferSearchAssignment: any) {
    //     dialogInfo= transferSearchAssignment;
    const url = '/references/search-purposes?includeInactive=false';

    this.httpService.get(url).subscribe({
      next: (response1: any) => {
        // Inject the reference list into the data object for the dialog dropdowns
        transferSearchAssignment.transferSearchReferenceList = response1.results;

        const updateDialogRef = this.dialog.open(UpdateDialogComponent, {
          disableClose: true,
          width: '800px', // Matches Bootstrap's modal-lg approximate width
          height: '400px',
          data: { ...transferSearchAssignment }, // Pass a shallow copy to prevent accidental mutations
        });

        updateDialogRef.afterClosed().subscribe((result) => {
          this.scrolltoTop();
          this.expandedAssignment = null;
          if (result && result.confirmed) {
            // Show success message toast using service
            this.transferSearchService.updateHideMessage(false);
            this.returnCode = 200;
            this.returnMessage = `Successfully updated assignment for worker number ${result.data.worker.workerNumber}`;
            this.transferSearchService.updateReturnMessage(this.returnMessage);

            // Refresh the table data by calling search with preserveToast = true
            const activestatus = this.showType === 'all';
            this.search(activestatus, true);

            this.cdr.detectChanges();
          }
        });
      },
      error: (error: any) => {
        // Show error message for reference list fetch using service
        this.transferSearchService.updateHideMessage(false);
        this.returnCode = error.status || 500;
        this.returnMessage = error.error?.message || 'Failed to load search purposes';
        this.transferSearchService.updateReturnMessage(this.returnMessage);
        this.cdr.detectChanges();
      },
    });
  }
  selectedOptionChanged() {}
  ngOnInit() {
    this.showWait = true;
    this.transferSearchService.updateHideMessage(true);

    // Set default sort to workerNumber ascending
    this.sortColumn = 'workerNumber';
    this.sortDirection = 'asc';
    this.searchSortColumn = 'workerNumber';
    this.searchSortOrder = 'asc';

    // Subscribe to toast message observables from service
    this.transferSearchService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
      this.cdr.detectChanges();
    });

    this.transferSearchService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
      this.cdr.detectChanges();
    });

    this.transferSearchService.returnCode$.subscribe((code) => {
      this.returnCode = code;
      this.cdr.detectChanges();
    });

    this.transferSearchService.currentTabData.subscribe((data: any) => {
      if (data && data.results) {
        this.searchResults = data.results;
        this.searchurl = data.params || '';

        // Update pagination parameters if provided
        if (data.pagination) {
          this.searchLimit = data.pagination.limit || 10;
          this.searchSkip = data.pagination.skip || 0;
          this.searchSortColumn = data.pagination.sortColumn || 'workerNumber';
          this.searchSortOrder = data.pagination.sortOrder || 'asc';
          this.searchShowAll = data.pagination.showAll || false;
        }

        // Ensure sort is set to workerNumber after receiving data
        this.sortColumn = 'workerNumber';
        this.sortDirection = 'asc';

        this.total = data.total;
        if (this.total > 0) {
          this.searchResultsCount =
            this.total + ' Search record(s) found with the entered search criteria';
        }
      }
      this.showWait = false;
    });
  }
  ngOnDestroy() {
    this.transferSearchService.changeTabData('');
  }

  convertTelephone(inputTelephone: string): string {
    if (!inputTelephone) {
      return inputTelephone;
    }

    // Remove all non-digit characters
    const digits = inputTelephone.replace(/\D/g, '');

    if (digits.length !== 10) {
      return inputTelephone;
    }

    // Format as (XXX) XXX-XXXX
    return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
  }

  formatDate(lastModifiedDate: string) {
    return this.datePipe.transform(lastModifiedDate, 'yyyy-MM-ddThh:mm:ss');
  }
  search(activestatus: boolean, preserveToast: boolean = false) {
    let responseCreate;

    // Show loading indicator when search starts
    this.showWait = true;
    this.cdr.detectChanges();

    // Reset sort to workerNumber ascending on new search
    this.sortColumn = 'workerNumber';
    this.sortDirection = 'asc';
    this.searchSortColumn = 'workerNumber';
    this.searchSortOrder = 'asc';

    // Parse the searchurl to remove existing showAll, sortColumn, sortOrder, limit, skip params
    // and rebuild with fresh values
    let baseParams = this.searchurl;

    // Remove existing pagination and sort parameters if they exist
    baseParams = baseParams.replace(/&?limit=\d+/g, '');
    baseParams = baseParams.replace(/&?skip=\d+/g, '');
    baseParams = baseParams.replace(/&?sortColumn=[^&]*/g, '');
    baseParams = baseParams.replace(/&?sortOrder=[^&]*/g, '');
    baseParams = baseParams.replace(/&?showAll=(true|false)/g, '');

    // Clean up any leading/trailing ampersands
    baseParams = baseParams.replace(/^&+|&+$/g, '');
    // Build the search URL with clean parameters
    const searchurl =
      '/transfer-searches?' +
      baseParams +
      '&limit=' +
      this.limit +
      '&showAll=' +
      activestatus +
      '&sortColumn=workerNumber&sortOrder=asc';
    this.httpService.get(searchurl).subscribe({
      next: (response: any) => {
        responseCreate = {
          worker: response.results,
          status: response.status,
          statusText: 'Created',
        };
        let totaltemp=response.meta.total;
        // Update unified array
        this.transferSearchAssignments = response.results;
        this.searchResults = response.results; // Keep for backward compatibility
        response.results.forEach((transferSearchAssignment: any, assignmentIndex: number) => {
          const workerId = transferSearchAssignment.worker.workerId;
          const url = `/workers/${workerId}/telecommunications`;

          this.httpService.get(url).subscribe((response1: any) => {
            // Store all phones in cache
            this.workerPhoneLocationCache.set(workerId, {
              phones: response1.results,
              locations: this.workerPhoneLocationCache.get(workerId)?.locations || [],
            });

            response1.results.forEach((telephone: any) => {
              if (telephone.primaryIndicator) {
                this.searchResults[assignmentIndex].telephoneNo = telephone.telephoneNo;
              }
            });
            // Set empty string if no primary phone found
            if (!this.searchResults[assignmentIndex].telephoneNo) {
              this.searchResults[assignmentIndex].telephoneNo = '';
            }
            this.cdr.detectChanges();
          });

          const url1 = `/workers/${workerId}/assignments`;

          this.httpService.get(url1).subscribe((response1: any) => {
            // Store all locations in cache
            const existingCache = this.workerPhoneLocationCache.get(workerId);
            this.workerPhoneLocationCache.set(workerId, {
              phones: existingCache?.phones || [],
              locations: response1.results,
            });

            response1.results.forEach((location: any) => {
              if (location.primaryLocationIndicator) {
                this.searchResults[assignmentIndex].location =
                  location.assignmentLocation.building.code +
                  '-' +
                  location.assignmentLocation.building.floorNumber +
                  location.assignmentLocation.corridorId +
                  location.assignmentLocation.roomId;
              }
            });
            // Set empty string if no primary location found
            if (!this.searchResults[assignmentIndex].location) {
              this.searchResults[assignmentIndex].location = '';
            }
            this.cdr.detectChanges();
          });
          this.total = totaltemp;
          this.searchResultsCount =
            this.total + ' Search record(s) found with the entered search criteria';
          this.showWait = false;
        });

        // Don't show toast message for radio button switches (unless preserveToast is true)
        if (!preserveToast) {
          this.transferSearchService.updateHideMessage(true);
          this.returnMessage = '';
          this.transferSearchService.updateReturnMessage('');
        }
        this.cdr.detectChanges();
      },
      error: (error: any) => {
        this.showWait = false;
        // Show error message using service
        this.transferSearchService.updateHideMessage(false);
        this.returnCode = error.status || 500;
        this.returnMessage = error.error?.message || 'Failed to search records';
        this.transferSearchService.updateReturnMessage(this.returnMessage);
        this.cdr.detectChanges();
      },
    });
  }

  exportDataCallback(): void {
    // Determine showAll based on current showType
    const activestatus = this.showType === 'all';
    
    // Build URL with query parameters - matching assign-role component format
    const url = `/transfer-searches/excelReport?${this.searchurl}&showAll=${activestatus}`;
    
    const fileName = 'TransferSearch.xls';
    
    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';
          a.click();
          
          // Clean up the URL object
          URL.revokeObjectURL(blobUrl);
        }
      },
      error: (error) => {
        // Show error message using service
        this.transferSearchService.updateHideMessage(false);
        this.returnCode = error.status || 500;
        this.returnMessage = error.error?.message || 'Failed to download Excel report';
        this.transferSearchService.updateReturnMessage(this.returnMessage);
        this.cdr.detectChanges();
      }
    });
  }
  toggle(transferSearchAssignment: any) {
    this.expandedIndex =
      this.expandedIndex === transferSearchAssignment.worker.workerNumber
        ? null
        : transferSearchAssignment.worker.workerNumber;
  }
  setshowMode(transferSearchAssignment: any) {
    this.expandedIndex = transferSearchAssignment.worker.workerNumber;

    // For Create tab (activatedTabIndex == 1), use createResults
    // For Search tab (activatedTabIndex == 0), find the assignment in searchResults array to get phone and location
    if (this.activatedTabIndex == 1) {
      const shName =
        this.createResults.organization != null ? this.createResults.organization.shortName : '';
      const phone = this.createResults.telephoneNo || '';
      const location = this.createResults.location || '';
      const lastModifiedUser = this.createResults.audit?.lastModifiedLoginId || '';

      this.htmlContent =
        '<tr>' +
        ' <td><dl class="dl-horizontal">' +
        '<dt>Art unit</dt><dd>' +
        shName +
        '</dd>' +
        '<dt>Class</dt><dd>' +
        this.createResults.artClass.artClassNo +
        '</dd>' +
        '<dt>Class description</dt><dd>' +
        this.createResults.artClass.titleText +
        '</dd>' +
        '</dl></td>' +
        '<td><dl class="dl-horizontal">' +
        '<dt>Sub classes</dt><dd>' +
        this.createResults.subclassRangeText +
        '</dd>' +
        '<dt>Primary phone</dt><dd>' +
        phone +
        '</dd>' +
        '<dt>Location</dt><dd>' +
        location +
        '</dd></dl>' +
        '</td>' +
        '<td><label>Last modified by </label> ' +
        lastModifiedUser +
        ' <label>Last modified date </label> ' +
        this.datePipe.transform(this.createResults.audit.lastModifiedDate, 'yyyy-MM-ddThh:mm:ss') +
        '</td>' +
        '  </tr>';
    } else {
      // Search tab - retrieve phone and location from cache
      const workerId = transferSearchAssignment.worker.workerId;
      const cachedData = this.workerPhoneLocationCache.get(workerId);

      let phone = '';
      let location = '';

      if (cachedData) {
        // Get primary phone from cache
        const primaryPhone = cachedData.phones.find((p: any) => p.primaryIndicator);
        phone = primaryPhone ? primaryPhone.telephoneNo : '';

        // Get primary location from cache
        const primaryLocation = cachedData.locations.find((l: any) => l.primaryLocationIndicator);
        if (primaryLocation) {
          location =
            primaryLocation.assignmentLocation.building.code +
            '-' +
            primaryLocation.assignmentLocation.building.floorNumber +
            primaryLocation.assignmentLocation.corridorId +
            primaryLocation.assignmentLocation.roomId;
        }
      }

      this.htmlContent =
        '<tr><td colspan="9">' +
        '<div class="relocationDetailsDiv">' +
        '    <table width="100%" ><tr> ' +
        ' <td><dl class="dl-horizontal">' +
        '<dt>Art unit</dt><dd>' +
        (transferSearchAssignment.organization?.shortName || '') +
        '</dd>' +
        '<dt>Class</dt><dd>' +
        transferSearchAssignment.artClass.artClassNo +
        '</dd>' +
        '<dt>Class description</dt><dd>' +
        transferSearchAssignment.artClass.titleText +
        '</dd>' +
        '</dl></td>  <td><dl class="dl-horizontal">' +
        '<dt>Sub classes</dt><dd>' +
        transferSearchAssignment.subclassRangeText +
        '</dd>' +
        '<dt>Primary phone</dt><dd>' +
        phone +
        '</dd>' +
        '<dt>Location</dt><dd>' +
        location +
        '</dd></dl>' +
        '</td>' +
        '</tr> <tr><td> </td> <td> <label>Last modified by </label> ' +
        transferSearchAssignment.audit.lastModifiedLoginId +
        ' <label>Last modified date </label> ' +
        this.datePipe.transform(
          transferSearchAssignment.audit.lastModifiedDate,
          'yyyy-MM-ddThh:mm:ss'
        ) +
        '</td>' +
        '  </tr>  </table></div></td></tr>';
    }
  }
  deleteTransferSearchAssignment(transferSearchAssignment: any) {
    this.openConfirmDialog(transferSearchAssignment);
  }

  updateTransferSearchAssignment(transferSearchAssignment: any) {
    // Expand the details row when edit button is clicked
    this.expandedAssignment = transferSearchAssignment;

    this.updateDialog(transferSearchAssignment);
  }
  // Function to toggle the expansion state

  // Helper method for admin access check

  hasAdminAccess(): boolean {
    const adminRoles = ['InfraAdmin', 'InfraUSPCChallengeAssistance', 'InfraSupervisorAdmin'];

    return this.userRoles.some((role) => adminRoles.includes(role));
  }

  toggleRowDetails(assignment: any): void {
    this.expandedAssignment = this.expandedAssignment === assignment ? null : assignment;
  }

  // Function to check if a row is expanded

  isExpanded(assignment: any): boolean {
    return this.expandedAssignment === assignment;
  }
  tabChange(tabIndex: number) {
    this.activatedTabIndex = tabIndex;
    // Don't clear searchResultsCount when switching tabs - preserve it for display
    this.searchResults = {};
  }

  /**
   * Resort method to handle sorting events from app-sort-button component
   */
  resort(event: { columnName: string; sortOrder: string; sortId: string }): void {
    // Update local sorting state
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;

    // Update the search parameters with new sorting
    this.searchSortColumn = event.columnName;
    this.searchSortOrder = event.sortOrder;

    // Reset to first page when sorting changes
    this.currentPage = 1;
    this.skip = 0;
    this.searchSkip = 0;

    // Trigger search with updated sorting by updating the bindings
    this.bindPaginationParamsToSearch(this.limit, this.skip);

    // If we have search results, re-fetch with new sort order
    if (this.searchResults && this.searchResults.length > 0) {
      this.showWait = true;
      this.cdr.detectChanges();

      // Build the search URL with updated sort parameters
      const showAllParam = this.showType === 'all';
      let searchUrl = '/transfer-searches?' + this.searchurl;

      // Remove old sort parameters if they exist
      searchUrl = searchUrl.replace(/&?sortColumn=[^&]*/, '').replace(/&?sortOrder=[^&]*/, '');

      // Add new sort parameters
      searchUrl += `&sortColumn=${event.columnName}&sortOrder=${event.sortOrder}&showAll=${showAllParam}&limit=${this.limit}&skip=${this.skip}`;

      this.httpService.get(searchUrl).subscribe({
        next: (response: any) => {
          // Update both unified array and searchResults
          this.transferSearchAssignments = response.results;
          this.searchResults = response.results;
          this.total = response.meta?.total || response.results.length;


          // Trigger change detection after updating results
          this.cdr.detectChanges();

          // Fetch additional details for each result
          response.results.forEach((transferSearchAssignment: any, assignmentIndex: number) => {
            const workerId = transferSearchAssignment.worker.workerId;

            // Fetch telephone information
            const telUrl = `/workers/${workerId}/telecommunications`;
            this.httpService.get(telUrl).subscribe((telResponse: any) => {
              // Store all phones in cache
              this.workerPhoneLocationCache.set(workerId, {
                phones: telResponse.results,
                locations: this.workerPhoneLocationCache.get(workerId)?.locations || [],
              });

              telResponse.results.forEach((telephone: any) => {
                if (telephone.primaryIndicator) {
                  this.searchResults[assignmentIndex].telephoneNo = telephone.telephoneNo;
                  this.transferSearchAssignments[assignmentIndex].telephoneNo = telephone.telephoneNo;
                }
              });
              // Set empty string if no primary phone found
              if (!this.searchResults[assignmentIndex].telephoneNo) {
                this.searchResults[assignmentIndex].telephoneNo = '';
                this.transferSearchAssignments[assignmentIndex].telephoneNo = '';
              }
              this.cdr.detectChanges();
            });

            // Fetch location information
            const locUrl = `/workers/${workerId}/assignments`;
            this.httpService.get(locUrl).subscribe((locResponse: any) => {
              // Store all locations in cache
              const existingCache = this.workerPhoneLocationCache.get(workerId);
              this.workerPhoneLocationCache.set(workerId, {
                phones: existingCache?.phones || [],
                locations: locResponse.results,
              });

              locResponse.results.forEach((location: any) => {
                if (location.primaryLocationIndicator) {
                  const locationStr =
                    location.assignmentLocation.building.code +
                    '-' +
                    location.assignmentLocation.building.floorNumber +
                    location.assignmentLocation.corridorId +
                    location.assignmentLocation.roomId;
                  this.searchResults[assignmentIndex].location = locationStr;
                  this.transferSearchAssignments[assignmentIndex].location = locationStr;
                }
              });
              // Set empty string if no primary location found
              if (!this.searchResults[assignmentIndex].location) {
                this.searchResults[assignmentIndex].location = '';
                this.transferSearchAssignments[assignmentIndex].location = '';
              }
              this.cdr.detectChanges();
            });
          });

          this.searchResultsCount =
            this.total + ' Search record(s) found with the entered search criteria';
          this.showWait = false;
          this.cdr.detectChanges();
        },
        error: (error) => {
          // Show error message using service
          this.transferSearchService.updateHideMessage(false);
          this.returnCode = error.status || 500;
          this.returnMessage = error.error?.message || 'Failed to sort records';
          this.transferSearchService.updateReturnMessage(this.returnMessage);
          this.showWait = false;
          this.cdr.detectChanges();
        }
      });
    }
  }

  clickedOnSort(event: any) {}
  toggleSearchView() {
    if (this.otherSearchView === 'search') {
      this.otherSearchView = 'create';
    } else {
      this.otherSearchView = 'search';
    }
  }

  onPageChanged(page: number): void {
    this.currentPage = page;
    this.skip = (this.currentPage - 1) * this.limit;

    // Call your search with new skip, keeping the current limit
    this.bindPaginationParamsToSearch(this.limit, this.skip);
  }

  /**
   * Triggered when the "Items per page" dropdown changes
   */
  onPageSizeChanged(size: number): void {
    this.limit = size;
    this.currentPage = 1; // Reset to page 1 for new sizes
    this.skip = 0; // Reset skip to 0

    // Call search with new limit and reset skip
    this.bindPaginationParamsToSearch(this.limit, this.skip);
    
    // Reload data with new page size
    const activestatus = this.showType === 'all';
    this.search(activestatus);
  }

  bindPaginationParamsToSearch(limit: number, skip: number): void {
    this.searchLimit = limit;
    this.searchSkip = skip;
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
