import { Injectable } from '@angular/core';
import { UtilityService } from 'src/app/services/utility.service';
@Injectable({
  providedIn: 'root',
})
export class TransferValidationsService {
  constructor(private utilityService: UtilityService) {}
  workerDetailsInfomationInvalid(
    validationBooleans: any,
    worker: any,
    userRoles: any,
    workerEmploymentType: string,
    workerAccession: any
  ) {
    let workerDetailsInfomationInvalidBoolean = false;
    if (workerEmploymentType === 'C') {
      validationBooleans.invalidFirmName = !!worker.contractorFirm ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidFirmName
        ? true
        : workerDetailsInfomationInvalidBoolean;
    }
    validationBooleans.invalidJobClassCode = !!worker.jobClass ? false : true;
    workerDetailsInfomationInvalidBoolean = validationBooleans.invalidJobClassCode
      ? true
      : workerDetailsInfomationInvalidBoolean;

    workerDetailsInfomationInvalidBoolean = this.validateOrgCode(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    workerDetailsInfomationInvalidBoolean = this.validateEmployeeOnly(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    workerDetailsInfomationInvalidBoolean = this.validateNonCoordinatorBoolean(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles
    );

    workerDetailsInfomationInvalidBoolean = this.validateAccessionDate(
      validationBooleans,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerAccession,
      workerEmploymentType
    );

    validationBooleans.invalidTourOfDuty = !!worker.standardTourOfDuty ? false : true;
    workerDetailsInfomationInvalidBoolean = validationBooleans.invalidTourOfDuty
      ? true
      : workerDetailsInfomationInvalidBoolean;

    workerDetailsInfomationInvalidBoolean = this.validateSeriesCode(
      validationBooleans,
      worker,
      workerDetailsInfomationInvalidBoolean,
      userRoles,
      workerEmploymentType
    );

    return workerDetailsInfomationInvalidBoolean;
  }
  primaryInfomationInvalid(
    validationBooleans: any,
    worker: any,
    userRoles: any,
    workerEmploymentType: string,
    legacyData: any
  ) {
    validationBooleans.invalidLastName = !worker.familyName;
    let primaryInfomationInvalidBoolean = !worker.familyName;
    if (!worker.givenName) {
      validationBooleans.invalidFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidFirstName = false;
    }
    if (!worker.preferredFirstName) {
      validationBooleans.invalidPreferredFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidPreferredFirstName = false;
    }
    // if (this.workerManagementService.canViewSecureData(userRoles, workerEmploymentType) && workerEmploymentType === 'C') {
    //     if (worker.birthDate === '01/01/0001') {
    //         validationBooleans.birthDateErrorMessage = null;
    //         validationBooleans.invalidBirthDate = false;
    //     } else {
    //         validationBooleans.birthDateErrorMessage = this.utilityService.validateDateOfBirth('Date of birth',
    //             worker.birthDate, true);
    //     }
    //     if (!!validationBooleans.birthDateErrorMessage) {
    //         validationBooleans.invalidBirthDate = true;
    //         primaryInfomationInvalidBoolean = true;
    //     }

    //     /** If legacy data is present and last 2 digits is not entered by user, then data is valid.
    //      If there is legacy data and user entered value then we validiate as before.
    //      If no legqacy data then field is required.*/
    //     if (legacyData && !worker.ssnLast2Digits) {
    //         validationBooleans.lastTwoSSNErrorMessage = false;
    //     } else {
    //         validationBooleans.lastTwoSSNErrorMessage = this.utilityService.validateLastTwoSSNInput('SSN (last 2 digits)',
    //             worker.ssnLast2Digits, true);
    //     }
    //     if (!!validationBooleans.lastTwoSSNErrorMessage) {
    //         validationBooleans.invalidLastTwoSSN = true;
    //         primaryInfomationInvalidBoolean = true;
    //     } else {
    //         validationBooleans.invalidLastTwoSSN = false;
    //     }
    // }

    return primaryInfomationInvalidBoolean;
  }
  validateOrgCode(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      workerEmploymentType === 'E'
    ) {
      if (!!validationBooleans.invalidOrgCodeErrorMsg) {
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        if (!worker.positionOrganizationListing) {
          validationBooleans.invalidOrgCodeErrorMsg = 'Org code is required';
          validationBooleans.invalidOrgCode = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidOrgCodeErrorMsg = '';
          validationBooleans.invalidOrgCode = false;
        }
      }
    }
    return workerDetailsInfomationInvalidBoolean;
  }
  validateEmployeeOnly(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraContractorAdmin') < 0 && workerEmploymentType === 'E') {
      validationBooleans.invalidGrade = !!worker.grade ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidGrade
        ? true
        : workerDetailsInfomationInvalidBoolean;
      validationBooleans.invalidGradeStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Grade start date',
          worker.gradeStartDate,
          true
        );
      if (!!validationBooleans.invalidGradeStartDateErrorMsg) {
        validationBooleans.invalidGradeStartDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidGradeStartDate = false;
      }

      validationBooleans.invalidStep = !!worker.step ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidStep
        ? true
        : workerDetailsInfomationInvalidBoolean;
      validationBooleans.invalidStepStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput('Step start date', worker.stepStartDate, true);
      if (!!validationBooleans.invalidStepStartDateErrorMsg) {
        validationBooleans.invalidStepStartDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidStepStartDate = false;
      }
      // validationBooleans.invalidTypeAppointment = !!worker.TypeAppointment ? false : true;
      // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidTypeAppointment ?
      //         true : workerDetailsInfomationInvalidBoolean;
      if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
        if (!worker.appointmentType) {
          validationBooleans.invalidTypeAppointment = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidTypeAppointment = false;
        }
        // validationBooleans.invalidPositionSensitivity = !!worker.PositionSensitivity ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidPositionSensitivity ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.positionSensitivity) {
          validationBooleans.invalidPositionSensitivity = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidPositionSensitivity = false;
        }
        // validationBooleans.invalidLeaveAccrual = !!worker.LeaveAccural ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidLeaveAccrual ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.leaveAccrual) {
          validationBooleans.invalidLeaveAccural = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidLeaveAccural = false;
        }
        // validationBooleans.invalidBusCode = !!worker.BusCode ? false : true;
        // workerDetailsInfomationInvalidBoolean = validationBooleans.invalidBusCode ?
        //         true : workerDetailsInfomationInvalidBoolean;
        if (!worker.bargainUnitType) {
          validationBooleans.invalidBusCode = true;
          workerDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidBusCode = false;
        }
      }
      if (!worker.payplan) {
        validationBooleans.invalidPayPlan = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidPayPlan = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }
  validateNonCoordinatorBoolean(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
      validationBooleans.invalidEntranceDutyDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Entrance on duty date',
          worker.lifecycle.beginDate,
          true
        );
      if (!!validationBooleans.invalidEntranceDutyDateErrorMsg) {
        validationBooleans.invalidEntranceDutyDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEntranceDutyDate = false;
      }
      validationBooleans.invalidEndDutyDateErrorMsg = this.utilityService.validateEndOfDutyDate(
        worker.lifecycle.beginDate,
        !!worker.lifecycle.endDate ? worker.lifecycle.endDate : null
      );
      if (!!validationBooleans.invalidEndDutyDateErrorMsg) {
        validationBooleans.invalidEndDutyDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEndDutyDate = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }
  validateAccessionDate(
    validationBooleans: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerAccession: any,
    workerEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0 && workerEmploymentType === 'E') {
      validationBooleans.invalidAccessionDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Accession date',
          workerAccession.accessionDt,
          true
        );
      if (!!validationBooleans.invalidAccessionDateErrorMsg) {
        validationBooleans.invalidAccessionDate = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidAccessionDate = false;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }

  validateSeriesCode(
    validationBooleans: any,
    worker: any,
    workerDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    workerEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      workerEmploymentType === 'E'
    ) {
      validationBooleans.invalidOccSeriesCode = !!worker.occupationalSeries ? false : true;
      workerDetailsInfomationInvalidBoolean = validationBooleans.invalidOccSeriesCode
        ? true
        : workerDetailsInfomationInvalidBoolean;
      if (validationBooleans.occSeriesCodeLookupNoResults) {
        workerDetailsInfomationInvalidBoolean = true;
      }
      if (!worker.occupationalSeriesTitle) {
        validationBooleans.invalidTitleCode = true;
        workerDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidTitleCode = false;
      }
      if (validationBooleans.titleCodeLookupNoResults) {
        workerDetailsInfomationInvalidBoolean = true;
      }
    }

    return workerDetailsInfomationInvalidBoolean;
  }
  confidentialInfomationInvalid(validationBooleans: any, workerSecure: any) {
    let confidentialInformationInvalid = false;
    if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
      confidentialInformationInvalid = true;
    } else {
      if (workerSecure) {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          this.utilityService.validateSSNInput(
            'Social security number',
            workerSecure.employeeSocialSecurity,
            true
          );
      } else {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          'Social security number is required';
      }

      if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
        validationBooleans.invalidEmployeeSocialSecurity = true;
        confidentialInformationInvalid = true;
      } else {
        validationBooleans.invalidEmployeeSocialSecurity = false;
      }
    }

    if (workerSecure.birthDate === '01/01/0001') {
      validationBooleans.invalidDateOfBirthErrorMsg = null;
    } else {
      validationBooleans.invalidDateOfBirthErrorMsg = this.utilityService.validateDateOfBirth(
        'Date of birth',
        workerSecure.birthDate,
        true
      );
    }
    if (!!validationBooleans.invalidDateOfBirthErrorMsg) {
      validationBooleans.invalidDateOfBirth = true;
      confidentialInformationInvalid = true;
    } else {
      validationBooleans.invalidDateOfBirth = false;
    }

    return confidentialInformationInvalid;
  }
  getWorkerAddObject(workerObj: any, employmentTypes: any) {
    let worker = this.getWorkerPrimaryAndDetails(workerObj);
    /**
     * Set employment type
     */
    if (worker.employmentType) {
      employmentTypes.map(function (employmentType: any) {
        if (employmentType.value === worker.employmentType) {
          worker.employmentType = {
            id: employmentType.id,
            value: employmentType.value,
            description: employmentType.description,
          };
        }
      });
    }

    return worker;
  }
  getWorkerPrimaryAndDetails(worker: any) {
    let teleworkProgram;
    if (worker.teleworkProgram && worker.teleworkProgram.id) {
      teleworkProgram = {
        teleworkProgramId: worker.teleworkProgram.id,
        hotelingIndicator: worker.teleworkProgram.hotelingIndicator,
      };
    }
    worker.teleworkProgram = teleworkProgram || null;
    worker.lifecycle = {
      beginDate: !!worker.lifecycle.beginDate
        ? this.utilityService.adjustDateFormatter(
            this.utilityService.dateFormatter(new Date(worker.lifecycle.beginDate))
          )
        : null,
      endDate: !!worker.lifecycle.endDate
        ? this.utilityService.adjustEndDateFormatter(
            this.utilityService.dateFormatterEndDate(new Date(worker.lifecycle.endDate))
          )
        : null,
    };

    /**
     * if lifecycle.endDate exists, use that value and set to organization.lifecycle.endDate
     */
    if (worker.lifecycle.endDate != undefined && worker.lifecycle.endDate != '') {
      if (worker.organizationHistory != undefined && worker.organizationHistory.length > 0) {
        worker.organizationHistory.map(function (organizationData: any, index: number) {
          organizationData.primaryOrganizationIndicator = false;
          if (
            organizationData.locationSummary != undefined &&
            organizationData.locationSummary.length > 0
          ) {
            organizationData.locationSummary[0].primaryLocationIn = false;
          }
          organizationData.lifecycle.endDate = worker.lifecycle.endDate + '.000Z';
        });
      }
    }
    if (worker.gradeStartDate) {
      worker.gradeStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(worker.gradeStartDate))
      );
    } else {
      worker.gradeStartDate = null;
    }

    if (worker.stepStartDate) {
      worker.stepStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(worker.stepStartDate))
      );
    } else {
      worker.stepStartDate = null;
    }
    worker.supervisorIndicator = worker.supervisorIndicator ? worker.supervisorIndicator : false;

    if (!worker.activeEmploymentIndicator) {
      worker.activeEmploymentIndicator = false;
    } else {
      worker.activeEmploymentIndicator = true;
    }
    worker.occupationalSeriesTitle = this.getOccupationalSeries(worker.occupationalSeriesTitle);
    worker.directoryTitleType = this.getDirectoryTitleType(worker.directoryTitleType);

    return worker;
  }
  getOccupationalSeries(occupationalSeriesTitle: any) {
    let newOccupationalSeriesTitle;

    if (occupationalSeriesTitle && occupationalSeriesTitle.id) {      newOccupationalSeriesTitle = {
        occupationalSeriesTitleId: occupationalSeriesTitle.id,
      };
    } else {    }
    return newOccupationalSeriesTitle;
  }
  getDirectoryTitleType(directoryTitleType: any) {
    let newDirectoryTitleType: any;
    if (directoryTitleType && directoryTitleType.id) {
      newDirectoryTitleType = {
        id: directoryTitleType.id,
      };
    }
    return newDirectoryTitleType;
  }
}
