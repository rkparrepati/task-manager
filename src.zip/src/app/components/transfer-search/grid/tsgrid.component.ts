import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AppService } from 'src/app/services/app.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { TransferSearchService } from '../transfer-search.service';

/**
 * @title Table with expandable rows
 */
@Component({
  selector: 'app-tsgrid',
  styleUrls: ['tsgrid.component.scss'],
  templateUrl: 'tsgrid.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class GridTransferSearchComponent implements OnChanges {
  @Input() dataSource: any = { meta: {}, results: [] };

  applicationType: String = 'Worker';
  total: any;
  sortColumn: any;
  sortDirection: any;
  resort: any;
  userRoles: any = [];
  updateWorkerButton: any;
  workerModel: any = { workerList: [] };
  userInfo: any;
  worker: any = {};
  phoneNumberDetail: any = {};
  matdataSource!: MatTableDataSource<any>;
  expandedElement: any | null;
  @Output() pageChange: EventEmitter<PageEvent> = new EventEmitter();

  displayedColumns: string[] = [
    'status',
    'applicationTypeNumber',
    'lastName',
    'firstName',
    'assistanceType',
    'artUnit',
    'class',
    'classDescription',
    'actions',
  ];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private appService: AppService,
    private transferSearchService: TransferSearchService
  ) {}
  ngOnChanges(changes: SimpleChanges) {
    if (changes.dataSource && changes.dataSource.currentValue) {
      this.matdataSource = new MatTableDataSource<any>(changes.dataSource.currentValue.results);
      this.matdataSource.paginator = this.paginator;
    }
  }

  getWorkerUpdateObject(worker: any, type: string = '') {
    if (!type && this.userInfo.roles.indexOf('InfraAdmin') !== -1) {
      type = 'A';
    } else if (!type) {
      type = 'N';
    }
    this.appService.changePage(
      '/workerUpdate/' +
        worker.workerId +
        '/' +
        worker.workerNumber +
        '/' +
        this.applicationType +
        '/' +
        type
    );
  }
  getTemplateWorkerSearch(worker: any) {
    if (
      worker &&
      this.workerModel &&
      this.workerModel.selectedWorker &&
      this.workerModel.selectedWorker.workerId &&
      worker.workerId === this.workerModel.selectedWorker.workerId
    ) {
      return 'detail';
    } else {
      return 'view';
    }
  }
  expandPhoneNumber(worker: any) {
    this.phoneNumberDetail = null;
    this.workerModel.selectedWorker = worker;
    if (this.expandedElement) {
      alert('inside expand::');
      // this.transferSearchService.getWorkerAssignments(worker.workerId).subscribe(
      //   (response) => {
      //     this.phoneNumberDetail = response;
      //   },
      //   function () {}
      // );
    }
  }
  clickedOnSort(event: any) {}

  // loadWorkers() {
  //   const params = {
  //     page: this.pageIndex + 1,
  //     pageSize: this.pageSize,
  //     sortColumn: this.sortColumn,
  //     sortDirection: this.sortDirection
  //   };

  //   this.TransferSearchService.getWorkers(params).subscribe((response: any) => {
  //     this.matdataSource = new MatTableDataSource<any>(response.results);
  //     this.total = response.meta.totalRecords;
  //     this.matdataSource.paginator = this.paginator;
  //     this.matdataSource.sort = this.sort;
  //   });
  // }
  // onPaginateChange(event: PageEvent) {
  //   this.pageIndex = event.pageIndex;
  //   this.pageSize = event.pageSize;
  //   this.loadWorkers();
  // }

  getPrimaryOrganization(organizationHistory: Array<any>) {
    let acronym;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organization = organizationHistory[i];
      if (organization.primaryOrganizationIndicator) {
        acronym =
          organization.organization.businessAreaCode + '/' + organization.organization.shortName;
      }
    }
    return acronym;
  }
  getBuildingData(organizationHistory: Array<any>) {
    let building = '';
    let position = -1;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    const locationSummary = organizationHistory[position].locationSummary[0].locationSummary;
    if (position >= 0 && locationSummary != null) {
      building = locationSummary.building.code;
    }
    return building;
  }
  getLocation = function (organizationHistory: Array<any>) {
    let location = '';
    let position = -1;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    const locationSummary = organizationHistory[position].locationSummary[0].locationSummary;
    if (position >= 0 && locationSummary != null) {
      let floor = locationSummary.building.floorNumber;
      let corridor = locationSummary.corridorId;
      let room = locationSummary.roomId;
      let zone = locationSummary.zoneId;
      let suite = locationSummary.suiteId;
      if (corridor == null && room == null && zone == null && suite == null) {
        location = floor;
      } else if (corridor == null && zone == null && suite == null) {
        location = floor + '/' + room;
      } else if (room == null && zone == null && suite == null) {
        location = floor + '/' + corridor;
      } else if (zone == null && suite == null) {
        location = floor + '/' + corridor + room;
      } else if (suite == null) {
        corridor = corridor == null ? ' ' : corridor;
        room = room == null ? ' ' : room;
        zone = zone == null ? ' ' : '/' + zone;
        location = floor + '/' + corridor + room + zone;
      } else {
        corridor = corridor == null ? ' ' : corridor;
        room = room == null ? ' ' : room;
        zone = zone == null ? ' ' : '/' + zone;
        location = floor + '-' + suite + '/' + corridor + room + zone;
      }
    }
    return location;
  };
  collapsePhoneNumber() {
    this.workerModel.selectedWorker = {};
  }
  pageSizeChangedEvent(pageSize: number) {}

  public onPageChange(event: PageEvent): void {}
}
