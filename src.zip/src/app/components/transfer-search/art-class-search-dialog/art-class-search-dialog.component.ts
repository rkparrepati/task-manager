import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpParams } from '@angular/common/http';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-art-class-search-dialog',
  templateUrl: './art-class-search-dialog.component.html',
  styleUrls: ['./art-class-search-dialog.component.scss'],
})
export class ArtClassSearchDialogComponent implements OnInit {
  artClassNoWizard: string = '';
  artClassResults: boolean = false;
  showArtClassMessage: boolean = false;
  returnMessage: string = '';
  total: number = 0;
  artClassInfo: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<ArtClassSearchDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private httpService: HttpService
  ) {
    if (data && data.content) {
      this.artClassNoWizard = data.content;
    }
  }

  ngOnInit(): void {
    // Initialize if needed
  }

  clear(): void {
    this.artClassNoWizard = '';
    this.total = 0;
    this.artClassInfo = [];
    this.artClassResults = false;
  }

  populateArtClassInformation(): void {
    if (!this.artClassNoWizard) {
      return;
    }

    const params = new HttpParams().set('artClassNo', this.artClassNoWizard);
    this.httpService.getData('/art-classes', params).subscribe(
      (response: any) => {
        this.artClassInfo = response.results;
        this.total = response.meta?.total || response.results.length;
        this.artClassResults = true;
        this.showArtClassMessage = false;
      },
      (error: any) => {
        this.total = 0;
        this.artClassInfo = [];
        this.showArtClassMessage = true;
        this.returnMessage = 'Art Class not found';
        this.artClassResults = false;
      }
    );
  }

  hideArtClassMessage(): void {
    this.showArtClassMessage = false;
  }

  onSelect(artClass: any): void {
    const result = {
      artClassNo: artClass.artClassNo,
      titleText: artClass.titleText,
      artClassId: artClass.artClassId,
    };
    this.dialogRef.close(result);
  }

  onCancel(): void {
    this.dialogRef.close(null);
  }
}
