import { Component, ComponentRef, Inject, Input, OnInit, ViewContainerRef } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { FlatTreeControl } from '@angular/cdk/tree';
import { TransferSearchService } from 'src/app/components/transfer-search/transfer-search.service';
/**
 * Food data with nested structure.
 * Each node has a name and an optiona list of children.
 */

interface FoodNode {
  name: string;
  organizationId: string;
  children?: FoodNode[];
}

/** Flat node with expandable and level information */
interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  node: any;
  organizationId: string;
  level: number;
}

@Component({
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
})
export class ConfirmDialogComponent implements OnInit {
  private _transformer = (node: any, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.organizationName,
      organizationId: node.organizationId,
      level: level,
      node: node,
    };
  };

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    (node) => node.level,
    (node) => node.expandable
  );

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    (node) => node.level,
    (node) => node.expandable,
    (node) => node.children
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  selectOrganizationInfo: { button: string; title: string } = { button: 'Update', title: 'Test' };
  hideResultMessage = false;
  searchResultsMode = 0;
  updateButtonDisabled = false;
  message: string = '';
  cancelButtonText = 'Cancel';
  acronym: string[] = [];

  public constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ConfirmDialogComponent>,
    private transferSearchService: TransferSearchService
  ) {
    if (data) {
      this.message = data.message || this.message;
      if (data.buttonText) {
        this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
      }
    }
  }

  public handleSelectedNode(node: any): void {
    // this.organizationService.getChildOrganizations(+node.organizationId).subscribe((child: any) => {
    //   Object.assign(node, { children: child.results })
    //   // this.dataSource.data = response.results;
    //   this.treeControl.expandAll();
    // });
    this.dialogRef.close(node.node);
  }

  search() {}
  ngOnInit(): void {
    // this.organizationService.getOrganizations().subscribe((response: any) => {
    //   this.organizationService.getChildOrganizations(+response.results[0].organizationId).subscribe((child: any) => {
    //     Object.assign(response.results[0], { children: child.results })
    //     this.dataSource.data = response.results;
    //     this.treeControl.expandAll();
    //   });
    // });
  }

  public clearSearchResults(): void {}

  onConfirm(): void {
    this.dialogRef.close(true);
  }
  onCancel(): void {
    this.dialogRef.close(false);
  }
  public confirm(data: any) {}

  public closeThisDialog(data: string): void {}

  public searchResults(): void {}

  // public searchResultsMode() {

  // }
}
