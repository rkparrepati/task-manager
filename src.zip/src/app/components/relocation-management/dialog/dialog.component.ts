import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss'],
})
export class DialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<DialogComponent>) {}

  confirm(message: any) {
    this.dialogRef.close(true);
  }

  cancel(message: any) {
    this.dialogRef.close(false);
  }
  exit(message: any) {
    this.dialogRef.close('exit');
  }
}
