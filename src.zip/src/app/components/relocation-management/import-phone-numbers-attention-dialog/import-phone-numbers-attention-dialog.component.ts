import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-import-phone-numbers-attention-dialog',
  templateUrl: './import-phone-numbers-attention-dialog.component.html',
  styleUrls: ['./import-phone-numbers-attention-dialog.component.scss'],
})
export class ImportPhoneNumbersAttentionDialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  
  constructor(
    private dialogRef: MatDialogRef<ImportPhoneNumbersAttentionDialogComponent>
  ) {}

  confirm(message: any) {
    this.dialogRef.close(message);
  }

  cancel(message: any) {
    this.dialogRef.close(message);
  }
}
