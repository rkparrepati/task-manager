import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-import-role-code-attention-dialog',
  templateUrl: './import-role-code-attention-dialog.component.html',
  styleUrls: ['./import-role-code-attention-dialog.component.scss'],
})
export class ImportRoleCodeAttentionDialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  
  constructor(
    private dialogRef: MatDialogRef<ImportRoleCodeAttentionDialogComponent>
  ) {}

  confirm(message: any) {
    this.dialogRef.close(message);
  }

  cancel(message: any) {
    this.dialogRef.close(message);
  }
}
