import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-relocation-delete-confirm-dialog',
  templateUrl: './relocation-delete-confirm-dialog.component.html',
  styleUrls: ['./relocation-delete-confirm-dialog.component.scss'],
})
export class RelocationDeleteConfirmDialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<RelocationDeleteConfirmDialogComponent>) {}

  confirm(message: any) {
    this.dialogRef.close(message);
  }
  cancel(message: any) {
    this.dialogRef.close(message);
  }

  closeThisDialog(message: any ) {
    this.dialogRef.close(message?message:null);
  }
}
