import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-move-employee-location-attention-dialog',
  templateUrl: './move-employee-location-attention-dialog.component.html',
  styleUrls: ['./move-employee-location-attention-dialog.component.scss'],
})
export class MoveEmployeeLocationAttentionDialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  
  constructor(
    private dialogRef: MatDialogRef<MoveEmployeeLocationAttentionDialogComponent>
  ) {}

  confirm(message: any) {
    this.dialogRef.close(message);
  }

  cancel(message: any) {
    this.dialogRef.close(message);
  }
}
