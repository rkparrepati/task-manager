import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-relocate-worker-gau-immediate',
  templateUrl: './relocate-worker-gau-immediate.component.html',
  styleUrls: ['./relocate-worker-gau-immediate.component.scss'],
})
export class RelocateWorkerGauImmediateComponent {
  constructor(private dialogRef: MatDialogRef<RelocateWorkerGauImmediateComponent>) {}
  confirm() {
    this.dialogRef.close(true);
  }

  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
