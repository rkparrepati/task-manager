import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { RelocationService } from '../relocation.service';
import { WorkerService } from '../worker.service';

@Injectable({
  providedIn: 'root',
})
export class GauMoveService {
  constructor(
    private organizationService: OrganizationService,
    private workerSearchService: WorkerService,
    private relocationService: RelocationService
  ) {}

  private messages = {
    newGAUMismatchWithSPE: 'NEW GAU does not match with SPE GAU.\n',
    workerisexistinQueue: 'Worker already exists in Queue.\n',
    firstNameMissing: 'First name is missing.\n',
    lastNameMissing: 'Last name is missing.\n',
    workerNumberMissing: 'Employee number is missing.\n',
    speFirstNameMissing: 'SPE First name is missing.\n',
    speLastNameMissing: 'SPE Last name is missing.\n',
    speEmpNumberMissing: 'SPE Employee number is missing.\n',
    oldAcronymMissing: 'Old acronym is missing.\n',
    newAcronymMissing: 'New acronym is missing.\n',
    workerNumberInvalid: 'Employee id is not valid.\n',
    workerNameMismatch: 'Employee name does not belong to Employee number.\n',
    workerAcronymMismatch: 'Employee does not belong to the old acronym.\n',
    workerNotActive: 'Employee is not active.\n',
    workerDuplicate: 'This employee id is duplicated.\n',
    newAcronymDoesNotExist: 'The new acronym does not exist.\n',
    newAcronymNotActive: 'The new acronym is not active.\n',
    formatInvalid: 'The format of the spreadsheet is not expected.\n',
    invalidDate: ' is Invalid Date. Date must be today or in the future\n',
    invalidDayDate: ' is Invalid Date. Date must be a biweekly date\n',
    dateMissing: 'Date is missing.\n',
    speWorkerNumberInvalid: 'SPE Employee no. is not valid.\n',
    speWorkerNameMismatch: 'SPE Employee name does not belong to SPE Employee number.\n',
    speWorkerNotActive: 'SPE is not active.\n',
  };

  async deleteMove(validRows: any[]): Promise<any[]> {
    const processList: any[] = [];
    const promises = validRows.map(async (planRow) => {      const newOrg: any = await firstValueFrom(
        this.organizationService.getOrganizationByAcronym(
          planRow.newGAU.organization.acronym,
          true
        )
      );      if (newOrg && newOrg.results && newOrg.results.length > 0) {
        planRow.newGAU.organization = newOrg.results[0];
      }      const oldOrg: any = await firstValueFrom(
        this.organizationService.getOrganizationByAcronym(
          planRow.oldGAU.organization.acronym,
          true
        )
      );      if (oldOrg && oldOrg.results && oldOrg.results.length > 0) {
        planRow.oldGAU.organization = oldOrg.results[0];
      }

      processList.push(planRow);
    });

    await Promise.all(promises);    return processList;
  }

  parsePlanSpreadsheet(text: string): any {
    const lines = text.split('\n');
    const returnObject: any = {
      invalidRows: [],
      validRows: [],
    };

    const message = this.parseHeader(lines);
    if (message) {
      return null;
    }

    lines.forEach((value, index) => {
      if (index > 0) {
        const lineInfo: any = this.parseLine(value, index);
        if (lineInfo && lineInfo.worker) {
          const workerMessage = this.checkDuplicateWorkerNumber(
            returnObject,
            lineInfo.worker.workerNumber
          );
          if (workerMessage) {
            lineInfo.errorMessage += this.messages.workerDuplicate;
          }

          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
    });

    return returnObject;
  }

  private checkDuplicateWorkerNumber(parsedRows: any, workerNumber: string): boolean {
    let workerDuplicate = false;
    if (!workerNumber) {
      return workerDuplicate;
    }

    parsedRows.validRows.forEach((planRow: any) => {
      if (planRow.worker.workerNumber === workerNumber) {
        workerDuplicate = true;
      }
    });

    parsedRows.invalidRows.forEach((planRow: any) => {
      if (planRow.worker.workerNumber === workerNumber) {
        workerDuplicate = true;
      }
    });

    return workerDuplicate;
  }

  private parseHeader(lines: string[]): string | null {
    if (lines.length === 0) {
      return null;
    }

    const line = lines[0];
    const columns = line.split(',');

    const invalidColumnGAU = columns[0] !== 'OLD GAU*' || columns[1] !== 'NEW GAU*';
    const invalidColumnWorker =
      columns[2] !== 'LAST NAME*' ||
      columns[3] !== 'FIRST NAME*' ||
      columns[4] !== 'EMP ID NUMBER*' ||
      columns[6] !== 'SPE LAST NAME*' ||
      columns[7] !== 'SPE FIRST NAME*' ||
      columns[8] !== 'SPE EMP NUMBER*\r';

    if (invalidColumnGAU || invalidColumnWorker) {
      return this.messages.formatInvalid;
    } else {
      return null;
    }
  }

  private parseLine(line: string, row: number): any {
    const columns = line.split(',');
    if (columns[0].length === 0 && columns.length === 1) {
      return null;
    }

    for (let index = 0; index < 9; index++) {
      if (columns[index]) {
        columns[index] = columns[index].toUpperCase().trim();
      }
    }

    const oldGAU = this.convertAcronym(columns[0]);
    const newGAU = this.convertAcronym(columns[1]);

    const relocationDetail: any = {
      row: row + 1,
      worker: {
        givenName: columns[3],
        familyName: columns[2],
        workerNumber: columns[4],
        speLastName: columns[6],
        speFirstName: columns[7],
        speEmpNumber: columns[8],
      },
      oldGAU: {
        organization: oldGAU,
      },
      newGAU: {
        organization: newGAU,
      },
      date: columns[5],
      message: '',
    };

    relocationDetail.errorMessage = this.validateDetails(
      columns[0],
      columns[1],
      columns[2],
      columns[3],
      columns[4],
      columns[5],
      columns[6],
      columns[7],
      columns[8]
    );
    return relocationDetail;
  }

  private convertAcronym(text: string): any {
    if (text.length === 0) {
      return null;
    }

    const org: any = {
      acronym: text,
      organizationType: {
        businessArea: {
          value: text.substring(0, 1),
        },
      },
    };

    if (text.length > 2) {
      org.shortName = text.substring(2);
    }

    return org;
  }

  private validateDetails(
    oldGAU: string,
    newGAU: string,
    lastName: string,
    firstName: string,
    workerNumber: string,
    date: string,
    speLastName: string,
    speFirstName: string,
    speEmpNumber: string
  ): string {
    const hasWorkerData =
      workerNumber && firstName && lastName && speLastName && speFirstName && speEmpNumber;
    const hasMinData = oldGAU && newGAU && date && hasWorkerData;
    if (!hasMinData) {
      let message = '';

      message += this.checkMissingData(message, firstName, this.messages.firstNameMissing);
      message += this.checkMissingData(message, lastName, this.messages.lastNameMissing);
      message += this.checkMissingData(message, workerNumber, this.messages.workerNumberMissing);
      message += this.checkMissingData(message, oldGAU, this.messages.oldAcronymMissing);
      message += this.checkMissingData(message, newGAU, this.messages.newAcronymMissing);
      message += this.checkMissingData(message, date, this.messages.dateMissing);
      message += this.checkMissingData(message, speFirstName, this.messages.speFirstNameMissing);
      message += this.checkMissingData(message, speLastName, this.messages.speLastNameMissing);
      message += this.checkMissingData(message, speEmpNumber, this.messages.speEmpNumberMissing);

      return message;
    } else {
      return '';
    }
  }

  private checkMissingData(message: string, value: string, errorMessage: string): string {
    if (!value) {
      return message + errorMessage;
    }

    return '';
  }

  async moveSuccessful(massUploadList: any[]): Promise<any> {
    const processList = massUploadList.map((item) => ({
      currentOrganizationId: item.databaseWorker.organizationHistory[0].organization.id,
      plannedOrganizationId: item.newGAU.organization.organizationId,
      firstName: item.worker.givenName,
      lastName: item.worker.familyName,
      workerId: item.databaseWorker.workerId,
      speFirstName: item.worker.speFirstName,
      speLastName: item.worker.speLastName,
      speEmpNumber: item.worker.speEmpNumber,
      beginEffectiveDt: new Date(item.date).toISOString(),
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lastModifiedUser: '',
        lockControlNumber: '',
      },
    }));

    try {
      const response = await this.relocationService.executeGAUMove(processList);
      return response;
    } catch (error) {
      throw error;
    }
  }

  async moveDeleteSuccessful(massUploadList: any[]): Promise<any> {
    const processList = massUploadList.map((item) => {
      // Format date as MM/dd/yyyy
      const dateObj = new Date(item.date);
      const month = String(dateObj.getMonth() + 1).padStart(2, '0');
      const day = String(dateObj.getDate()).padStart(2, '0');
      const year = dateObj.getFullYear();
      const formattedDate = `${month}/${day}/${year}`;      return {
        currentOrganizationId: item.oldGAU.organization.organizationId,
        workerNumber: item.worker.workerNumber,
        beginEffectiveDt: formattedDate,
      };
    });    try {
      // Convert Observable to Promise using firstValueFrom
      const response = await firstValueFrom(this.relocationService.executeGAUMoveDelete(processList));      return response;
    } catch (error) {      throw error;
    }
  }

  moveSuccessfulMass(massUploadList: any[]) {
    const processList = massUploadList.map((item) => {
      const processItem: any = {
        workerOrganizationQueue: {
          lastName: item.worker.familyName,
          firstName: item.worker.givenName,
          speEmpNumber: item.worker.speEmpNumber,
          speFirstName: item.worker.speFirstName,
          speLastName: item.worker.speLastName,
          workerNumber: item.worker.workerNumber,
        },
        organization: {
          id: item.newGAU.organization.organizationId,
          shortName: item.newGAU.organization.shortName,
          name: item.newGAU.organization.organizationName,
          businessAreaCode: item.newGAU.organization.organizationType.businessArea.code,
        },
        lifecycle: {
          beginDate: new Date(item.date).toISOString(),
        },
        primaryOrganizationIndicator: true,
        organizationStatusCurrent: 'P',
      };

      const primaryOrg = item.databaseWorker.organizationHistory.find(
        (workerOrganization: any) => workerOrganization.primaryOrganizationIndicator
      );
      if (primaryOrg) {
        processItem.workerOrganizationId = primaryOrg.workerOrganizationId;
      }

      return processItem;
    });

    try {
      return this.relocationService.executeGAUMoveMass(processList);
    } catch (error) {
      throw error;
    }
  }

  async validateSpreadSheet(
    validRows: any[],
    biweekDateInfo: string[],
    selectedTool: string
  ): Promise<any> {
    let returnObject: any = {
      invalidRows: [],
      validRows: [],
    };

    const promises = validRows.map(async (planRow) => {
      planRow.errorMessage = '';
      let workerExists = false;

      try {
        const queueResponse: any = await firstValueFrom(
          this.workerSearchService.getWorkerFromQueueByWorkerNumber(planRow.worker.workerNumber, true)
        );
        
        // Handle different response formats
        let queueCount = 0;
        if (typeof queueResponse === 'number') {
          queueCount = queueResponse;
        } else if (queueResponse?.data?.results) {
          queueCount = queueResponse.data.results.length;
        } else if (queueResponse?.results) {
          queueCount = queueResponse.results.length;
        } else if (queueResponse?.data?.count !== undefined) {
          queueCount = queueResponse.data.count;
        } else if (queueResponse?.count !== undefined) {
          queueCount = queueResponse.count;
        }
        
        if (queueCount > 0) {
          workerExists = true;
          planRow.errorMessage = this.messages.workerisexistinQueue;
        }
      } catch (error) {
        throw error;
      }

      const speEmpNumber = planRow.worker.speEmpNumber.replace('\r', '');
      try {
        const speResponse: any = await firstValueFrom(
          this.relocationService.getWorkerByWorkerNumber(speEmpNumber, true)
        );
        const speResults = speResponse?.results || [];
        if (speResults.length > 0) {
          const invalidSpeNameMessage = this.validateSpeNameInfo(speResults[0], planRow);
          planRow = this.validateSpeWorkerInfo(planRow, invalidSpeNameMessage);
        } else {
          planRow.errorMessage += this.messages.speWorkerNumberInvalid;
        }
      } catch {
        planRow.errorMessage += this.messages.speWorkerNumberInvalid;
      }

      // Fetch worker information
      try {
        const workerResponse: any = await firstValueFrom(
          this.relocationService.getWorkerByWorkerNumber(planRow.worker.workerNumber, true)
        );
        const workerResults = workerResponse?.results || [];
        if (workerResults.length > 0) {
          const invalidNameMessage = this.validateNameInfo(workerResults[0], planRow);
          planRow.databaseWorker = workerResults[0];
          planRow = this.validateWorkerInfo(planRow, invalidNameMessage);

          const primaryOrg = this.getPrimaryOrganization(planRow.databaseWorker);
          planRow.databaseWorker.acronym = primaryOrg;
          planRow.oldGAU.acronym = planRow.oldGAU.organization.acronym;

          if (planRow.oldGAU.organization.acronym !== primaryOrg) {
            planRow.errorMessage += this.messages.workerAcronymMismatch;
          }
        } else {
          planRow.errorMessage += this.messages.workerNumberInvalid;
        }
      } catch (error) {
        planRow.errorMessage += this.messages.workerNumberInvalid;
      }

      // Date validation for both selectedTool '3' and '5'
      if (selectedTool === '3' || selectedTool === '5') {
        let isDateError = false;
        const currentDateObj = new Date();
        currentDateObj.setHours(0, 0, 0, 0);
        const dateInputObj = new Date(planRow.date);
        dateInputObj.setHours(0, 0, 0, 0);
        
        // Check if date is in the past (future count day validation)
        if (dateInputObj < currentDateObj) {
          const formattedDate = this.formatDate(new Date(planRow.date), 'MM/dd/yyyy');
          planRow.errorMessage += formattedDate + this.messages.invalidDate;
          isDateError = true;
        }

        // Format date if it contains 'T'
        let planDt = planRow.date;
        if (planDt.indexOf('T') !== -1) {
          const dateObject = new Date(planDt);
          const day = ('0' + dateObject.getDate()).slice(-2);
          const month = ('0' + (dateObject.getMonth() + 1)).slice(-2);
          const year = dateObject.getFullYear();
          planRow.date = month + '/' + day + '/' + year;
          planDt = planRow.date;
        }

        // Check biweekly date for Patent organizations
        if (
          (planRow.newGAU.organization.acronym &&
            planRow.newGAU.organization.organizationType.businessArea.value.includes('P')) ||
          (planRow.oldGAU.organization.acronym &&
            planRow.oldGAU.organization.organizationType.businessArea.value.includes('P'))
        ) {
          const dateInput = this.formatDate(new Date(planRow.date), 'MMddyyyy');
          if (!biweekDateInfo.includes(dateInput)) {
            const adjustedDate = new Date(new Date(planRow.date).getTime() - 86400000); // Subtract 1 day
            const adjustedDateInput = this.formatDate(adjustedDate, 'MMddyyyy');
            planRow.date = this.formatDate(adjustedDate, 'MM/dd/yyyy');
            if (!biweekDateInfo.includes(adjustedDateInput) && !isDateError) {
              planRow.errorMessage += planDt + this.messages.invalidDayDate;
            }
          }
        }
      }

      // Fetch old organization (for selectedTool '3')
      if (selectedTool === '3') {
        try {
          const oldOrgResponse: any = await firstValueFrom(
            this.organizationService.getOrganizationByAcronym(
              planRow.oldGAU.organization.acronym,
              true
            )
          );
          if (oldOrgResponse?.results?.[0]) {
            planRow.oldGAU.organization = oldOrgResponse.results[0];
          }
        } catch (error: any) {        }
      }

      // Fetch new organization (always, for both selectedTool '3' and '5')
      try {
        const newOrgResponse: any = await firstValueFrom(
          this.organizationService.getOrganizationByAcronym(
            planRow.newGAU.organization.acronym,
            true
          )
        );
        planRow.newGAU.acronym = planRow.newGAU.organization.acronym;
        if (newOrgResponse?.results?.[0]) {
          planRow.newGAU.organization = newOrgResponse.results[0];
        } else {
          planRow.errorMessage += this.messages.newAcronymDoesNotExist;
        }
      } catch (error: any) {        const errorMsg = error?.error?.message || 'No Organizations found that match the query';
        planRow.errorMessage += errorMsg + '\n';
      }

      // Always call validateGAU to add the row to the appropriate array
      returnObject = this.validateGAU(planRow, returnObject);
    });

    await Promise.all(promises);
    
    // Post-process: Re-sort all rows based on errorMessage (matching legacy behavior)    const allRows = returnObject.validRows.concat(returnObject.invalidRows);    // Sort all rows by row number to maintain CSV order
    allRows.sort((a: any, b: any) => (a.row || 0) - (b.row || 0));
    
    const finalObject = {
      invalidRows: [] as any[],
      validRows: [] as any[],
    };
    
    for (let i = 0; i < allRows.length; i++) {
      if (allRows[i].errorMessage) {        finalObject.invalidRows.push(allRows[i]);
      } else {        finalObject.validRows.push(allRows[i]);
      }
    }    return finalObject;
  }

  validateSpeNameInfo(worker: any, rowData: any): string {
    const orgCode = `${worker.organizationHistory[0].organization.businessAreaCode}/${worker.organizationHistory[0].organization.shortName}`;
    let errorMessage = '';

    if (
      (rowData.worker.familyName.length > 0 &&
        worker.familyName !== undefined &&
        rowData.worker !== undefined &&
        worker.familyName.trim() !== rowData.worker.speLastName) ||
      worker.givenName.trim() !== rowData.worker.speFirstName
    ) {
      errorMessage = this.messages.speWorkerNameMismatch;
    } else if (orgCode !== rowData.newGAU.organization.acronym) {
      // Additional validation logic can be added here if needed
    }

    return errorMessage;
  }
  validateGAU(planRow: any, returnObject: any) {
    if (planRow.newGAU.organization.lifecycle.endDate) {
      planRow.errorMessage += this.messages.newAcronymNotActive;
    }

    if (!planRow.errorMessage) {
      returnObject.validRows.push(planRow);
    } else {
      returnObject.invalidRows.push(planRow);
    }
    return returnObject;
  }
  validateWorkerInfo(planRow: any, invalidNameMessage: any) {
    if (invalidNameMessage) {
      planRow.errorMessage += invalidNameMessage;
    }

    if (!planRow.databaseWorker.activeEmploymentIndicator) {
      planRow.errorMessage += this.messages.workerNotActive;
    }

    return planRow;
  }
  validateSpeWorkerInfo(planRow: any, invalidNameMessage: any) {
    if (invalidNameMessage) {
      planRow.errorMessage += invalidNameMessage;
    }

    if (
      planRow.databaseWorker !== '' &&
      planRow.databaseWorker !== undefined &&
      planRow.databaseWorker !== null &&
      planRow.databaseWorker !== 'undefined' &&
      !planRow.databaseWorker.activeEmploymentIndicator
    ) {
      planRow.errorMessage += this.messages.speWorkerNotActive;
    }

    return planRow;
  }

  validateNameInfo(worker: any, rowData: any) {
    let errorMessage = '';
    if (
      rowData.worker.familyName !== '' &&
      (worker.familyName.trim() !== rowData.worker.familyName ||
        worker.givenName.trim() !== rowData.worker.givenName)
    ) {
      errorMessage = this.messages.workerNameMismatch;
    }
    return errorMessage;
  }

  getPrimaryOrganization(worker: any) {
    let thePrimaryOrg = 'none';
    worker.organizationHistory.forEach((anOrg: any) => {
      if (anOrg.primaryOrganizationIndicator) {
        thePrimaryOrg = anOrg.organization.businessAreaCode + '/' + anOrg.organization.shortName;
      }
    });
    return thePrimaryOrg;
  }

  /**
   * Format a date object to a specific format string
   * @param date - The date to format
   * @param format - The format string (e.g., 'MM/dd/yyyy', 'MMddyyyy')
   * @returns Formatted date string
   */
  private formatDate(date: Date, format: string): string {
    const day = ('0' + date.getDate()).slice(-2);
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const year = date.getFullYear();

    if (format === 'MM/dd/yyyy') {
      return `${month}/${day}/${year}`;
    } else if (format === 'MMddyyyy') {
      return `${month}${day}${year}`;
    }
    
    // Default format
    return `${month}/${day}/${year}`;
  }
}
