import { Component, OnInit } from '@angular/core';
import { RelocationService } from '../relocation.service';
import { UtilityService } from 'src/app/services/utility.service';
import { GauMoveService } from './gau-move.service';
import { AppService } from 'src/app/services/app.service';
import { MatDialog } from '@angular/material/dialog';
import { RelocationGauAttentionDialogComponent } from '../relocation-gau-attention-dialog/relocation-gau-attention-dialog.component';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-relocate-worker-gau',
  templateUrl: './relocate-worker-gau.component.html',
  styleUrls: ['./relocate-worker-gau.component.scss'],
})
export class RelocateWorkerGauComponent implements OnInit {
  importedFile: File | undefined;
  private biweeklyDateInfo: string[] = [];
  private selectedTool = '5';
  returnCode: any = '';
  hideMessage: boolean = true;
  returnMessage: string = '';
  accessDenied: any;

  constructor(
    private dialog: MatDialog,
    public relocationService: RelocationService,
    private utilityService: UtilityService,
    private gauMoveService: GauMoveService,
    private appService: AppService
  ) {
    // Constructor logic here
  }

  ngOnInit(): void {
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });

    this.getBiweeklyDates();
  }
  downloadTemplate(): void {
    this.relocationService.downloadTemplate('GAUMassUploadTemplate.csv');
  }
  sendFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.importedFile = input.files[0];
    }
  }

  getBiweeklyDates(): void {
    this.relocationService.getDateInfo().subscribe({
      next: (response: any) => {
        const payPeriodData = response?.response?.[0]?.payPeriodData;
        this.biweeklyDateInfo = [];

        if (payPeriodData) {
          payPeriodData.forEach((biweekdate: any) => {
            this.biweeklyDateInfo.push(
              this.utilityService.formatDate(new Date(biweekdate.payPeriodEndDate), 'MMddyyyy')
            );
          });
        }
      },
      error: (error) => {        this.biweeklyDateInfo = [];
      }
    });
  }

  importFile(): void {
    if (!this.importedFile) {      return;
    }

    const suffix = this.importedFile.name.substring(this.importedFile.name.length - 4);
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      let text = reader.result as string;
      text = text.replace('SPE EMP NUMBER*,', 'SPE EMP NUMBER*').trim();

      const parsedObject = this.gauMoveService.parsePlanSpreadsheet(text);
      if (parsedObject && parsedObject.validRows && parsedObject.validRows.length > 0) {
        this.gauMoveService
          .validateSpreadSheet(parsedObject.validRows, this.biweeklyDateInfo, this.selectedTool)
          .then(
            (processedRows: any) => {
              // Merge parsing invalid rows with validation invalid rows
              const mergedData = {
                validRows: processedRows.validRows || [],
                invalidRows: [...(parsedObject.invalidRows || []), ...(processedRows.invalidRows || [])]
              };
              
              if (mergedData.invalidRows.length > 0) {
                this.showImportRelocationDialogFailure(mergedData);
              } else {
                this.saveTheValidDetails(mergedData.validRows);
              }
            },
            (error: any) => {              // Show validation errors through attention dialog
              const errorData = this.createErrorData(
                parsedObject.validRows,
                error?.message || 'Failed to validate GAU data. Please try again.'
              );
              this.showImportRelocationDialogFailure(errorData);
            }
          );
      } else if (parsedObject) {
        // No valid rows from parsing, show dialog with only invalid rows
        this.showImportRelocationDialogFailure(parsedObject);
      } else {
        // Invalid format
        this.invalidFileTypeMessage();
      }
    };

    reader.readAsText(this.importedFile);

    this.importedFile = undefined;
    const importExcelGAU = document.getElementById('importExcelGAU') as HTMLInputElement;
    if (importExcelGAU) {
      importExcelGAU.value = '';
    }
  }
  saveTheValidDetails(validRows: any) {
    this.gauMoveService.moveSuccessfulMass(validRows).subscribe({
      next: (response: any) => {        // Only show success through Dialog component
        this.handleUploadCompletion({ validRows, invalidRows: [] });
      },
      error: (error: any) => {        // Show API save errors through attention dialog
        const errorMessage = error?.error?.message || error?.message || error?.accessDenied || 'Failed to save GAU data. Please try again.';
        const errorData = this.createErrorData(validRows, errorMessage);
        this.showImportRelocationDialogFailure(errorData);
      },
    });
  }

  invalidFileTypeMessage() {
    // Show file type errors through attention dialog
    const errorData = {
      validRows: [],
      invalidRows: [{
        row: 0,
        worker: {
          givenName: '',
          familyName: '',
          workerNumber: '',
          speLastName: '',
          speFirstName: '',
          speEmpNumber: ''
        },
        oldGAU: {
          organization: { acronym: '' },
          acronym: ''
        },
        newGAU: {
          organization: { acronym: '' },
          acronym: ''
        },
        errorMessage: 'The format of the spreadsheet is not expected. Only CSV files can be imported.'
      }]
    };
    this.showImportRelocationDialogFailure(errorData);
  }

  createErrorData(validRows: any[], errorMessage: string) {
    return {
      validRows: [],
      invalidRows: validRows.map((row: any) => ({
        ...row,
        errorMessage: errorMessage
      }))
    };
  }

  handleUploadCompletion(rows: { validRows: any[]; invalidRows: any[] }): void {
    // Only show success messages through Dialog component
    if (rows.validRows.length > 0 && rows.invalidRows.length === 0) {
      const modalData = {
        titleType: 'text-success',
        content: rows.validRows.length + ' employee(s) moved',
        primaryButton: 'OK',
        primaryButtonType: 'success',
        title: 'Mass move execution Successful!',
      };
      
      // Navigate first, then show dialog
      this.appService.changePage('/app/relocation');
      
      // Show success dialog after navigation with a slight delay to ensure the page is loaded
      setTimeout(() => {
        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalData,
          disableClose: true,
        });
      }, 100);
    }
    // Error cases are now handled through attention dialog, not here
  }
  showImportRelocationDialogFailure(processedRows: any) {
    const dialogRef = this.dialog.open(RelocationGauAttentionDialogComponent, {
      width: '80vw',
      height: '70vh',
      data: {
        data: processedRows,
        title: 'Mass GAU Move Errors Summary'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result === 'continue' && processedRows.validRows && processedRows.validRows.length > 0) {
        this.saveTheValidDetails(processedRows.validRows);
      }
      // If cancelled or no valid rows, do nothing
    });
  }
}
