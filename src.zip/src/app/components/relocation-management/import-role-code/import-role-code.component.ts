import { Component, OnInit } from '@angular/core';
import { RelocationService } from '../relocation.service';
import { DialogComponent } from '../dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'src/app/services/app.service';
import { ImportRoleCodeAttentionDialogComponent } from '../import-role-code-attention-dialog/import-role-code-attention-dialog.component';

@Component({
  selector: 'app-import-role-code',
  templateUrl: './import-role-code.component.html',
  styleUrls: ['./import-role-code.component.scss'],
})
export class ImportRoleCodeComponent implements OnInit {
  importedFile: File | null = null;
  returnCode: any = '';
  hideMessage: boolean = true;
  returnMessage: string = '';
  accessDenied: any;
  
  messages = {
    firstNameMissing: 'First name is missing. ',
    lastNameMissing: 'Last name is missing. ',
    workerNumberMissing: 'Employee number is missing. ',
    workerNumberInvalid: 'Employee number is not valid. ',
    workerNameMismatch: 'Employee name does not belong to Employee number. ',
    workerAcronymMismatch: 'Employee does not belong to the acronym. ',
    workerNotActive: 'Employee is not active. ',
    workerDuplicate: 'This Employee number is duplicated. ',
    formatInvalid: 'The format of the spreadsheet is not expected. ',
    acronymMissing: 'Acronym is missing. ',
    acronymInvalid: 'Acronym is not valid. ',
    workerRoleMissing: 'Worker role is missing. ',
    workerRoleInvalid: 'Worker role is not valid. ',
  };

  constructor(
    public relocationService: RelocationService,
    private appService: AppService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });
  }

  downloadTemplate(): void {
    this.relocationService.downloadTemplate('UploadEmployeeRoleCodeTemplate.csv');
  }

  sendFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.importedFile = input.files[0];
    }
  }

  importFile(): void {
    if (!this.importedFile) return;

    const suffix = this.importedFile.name.slice(-4);
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    this.processFile();
  }

  private processFile(): void {
    if (!this.importedFile) return;

    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      const parsedObject = this.parsePlanSpreadsheet(text);      if (parsedObject.validRows && parsedObject.validRows.length > 0) {        // Call API validation - API returns both validRows and invalidRows
        this.relocationService
          .getUploadEmployeeRoleCodeResponse(parsedObject.validRows)
          .subscribe({
            next: (responses: any) => {              const returnedData = responses;

              if (returnedData) {
                // Merge parsing invalid rows with API invalid rows
                const processedRows = {
                  validRows: returnedData.validRows || [],
                  invalidRows: [...(parsedObject.invalidRows || []), ...(returnedData.invalidRows || [])],
                };                // Show attention dialog if there are any invalid rows
                if (processedRows.invalidRows.length > 0) {
                  this.showRoleCodeImportDialogFailure(processedRows);
                } else {
                  // All valid, proceed with save
                  this.openUploadEmployeeRoleCodeSuccess(processedRows.validRows);
                }
              }
            },
            error: (err) => {              // Show API validation errors through attention dialog
              const errorData = {
                validRows: [],
                invalidRows: [{
                  row: 0,
                  workerNumber: '',
                  workerLastName: '',
                  workerFirstName: '',
                  acronym: '',
                  workerRole: '',
                  errorMessage: err?.error?.message || err?.message || 'Failed to validate role code data. Please try again.'
                }]
              };
              this.showRoleCodeImportDialogFailure(errorData);
            }
          });
      } else {
        // No valid rows from parsing, show dialog with only invalid rows
        this.showRoleCodeImportDialogFailure(parsedObject);
      }
    };

    reader.readAsText(this.importedFile);
  }

  showRoleCodeImportDialogFailure(parsedObject: any) {
    const dialogRef = this.dialog.open(ImportRoleCodeAttentionDialogComponent, {
      width: '80vw',
      height: '70vh',
      data: {
        data: parsedObject,
        title: 'Mass Upload Employee Role Code Errors Summary'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'continue' && parsedObject.validRows && parsedObject.validRows.length > 0) {
        // Validation already happened, proceed to execute with valid rows only
        this.openUploadEmployeeRoleCodeSuccess(parsedObject.validRows);
      }
      // If cancelled or no valid rows, do nothing
    });
  }

  invalidFileTypeMessage() {
    // Show file type errors through attention dialog
    const errorData = {
      validRows: [],
      invalidRows: [{
        row: 0,
        workerNumber: '',
        workerLastName: '',
        workerFirstName: '',
        acronym: '',
        workerRole: '',
        errorMessage: 'The format of the spreadsheet is not expected. Only CSV files can be imported.'
      }]
    };
    this.showRoleCodeImportDialogFailure(errorData);
  }

  parsePlanSpreadsheet(text: string): { invalidRows: any[]; validRows: any[] } {
    const lines = text.split('\n');
    const returnObject: { invalidRows: any[]; validRows: any[] } = { invalidRows: [], validRows: [] };

    // Parse all lines (skip header row at index 0) - matching legacy behavior
    lines.forEach((line, index) => {
      if (index > 0) {
        const lineInfo = this.parseLine(line, index);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
    });

    return returnObject;
  }

  parseLine(line: string, row: number): any | null {
    const columns = line.split(',').map((col) => col.trim());
    if (columns.length < 5 || (columns.length === 1 && !columns[0])) return null;

    return {
      row: row + 1,
      workerNumber: columns[0],
      workerLastName: columns[1],
      workerFirstName: columns[2],
      acronym: columns[3],
      workerRole: columns[4],
      errorMessage: this.validateDetails(
        columns[0],
        columns[1],
        columns[2],
        columns[3],
        columns[4]
      ),
    };
  }

  validateDetails(
    workerNumber: string,
    lastName: string,
    firstName: string,
    acronym: string,
    workerRole: string
  ): string {
    let message = '';
    message = this.addMessage(workerNumber, message, this.messages.workerNumberMissing);
    message = this.addMessage(lastName, message, this.messages.lastNameMissing);
    message = this.addMessage(firstName, message, this.messages.firstNameMissing);
    message = this.addMessage(acronym, message, this.messages.acronymMissing);
    message = this.addMessage(workerRole, message, this.messages.workerRoleMissing);
    return message;
  }

  addMessage(value: string, message: string, invalidMessage: string): string {
    return value ? message : message + invalidMessage;
  }

  openUploadEmployeeRoleCodeSuccess(validRows: any) {
    this.relocationService.saveUploadEmployeeRoleCodeResponse(validRows).subscribe(
      (responses: any) => {        // Only show success through Dialog component
        this.handleUploadCompletion({ validRows: validRows, invalidRows: [] });
      },
      (error: any) => {        // Show API save errors through attention dialog
        const errorMessage = error?.error?.message || error?.message || error?.accessDenied || 'Failed to save role code data. Please try again.';
        const errorData = {
          validRows: [],
          invalidRows: validRows.map((row: any) => ({
            ...row,
            errorMessage: errorMessage
          }))
        };
        this.showRoleCodeImportDialogFailure(errorData);
      }
    );
  }

  handleUploadCompletion(rows: { validRows: any[]; invalidRows: any[] }): void {
    // Only show success messages through Dialog component
    if (rows.validRows.length > 0 && rows.invalidRows.length === 0) {
      const modalData = {
        titleType: 'text-success',
        content: rows.validRows.length + ' employee(s) role code uploaded',
        primaryButton: 'OK',
        primaryButtonType: 'success',
        title: 'Mass upload Successful!',
      };
      
      // Navigate first, then show dialog
      this.appService.changePage('/app/relocation');
      
      // Show success dialog after navigation with a slight delay to ensure the page is loaded
      setTimeout(() => {
        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalData,
          disableClose: true,
        });
      }, 100);
    }
    // Error cases are now handled through attention dialog, not here
  }
}
