import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { RelocationService } from '../relocation.service';
import { LocationselectDialogComponent } from '../../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';

export interface WizardDialogData {
  workerResults?: any[];
  locationResults?: any[];
  jobClassCodes?: any[];
}

@Component({
  selector: 'app-add-worker-wizard-dialog',
  templateUrl: './add-worker-wizard-dialog.component.html',
  styleUrls: ['./add-worker-wizard-dialog.component.scss']
})
export class AddWorkerWizardDialogComponent implements OnInit {
  currentPage: 'worker' | 'location' | 'acronym' = 'worker';
  
  dialogData: {
    workers: any[];
    locations: any[];
    selectedWorker: any;
    selectedLocation: any;
  };

  dialogInfo: {
    content?: string;
  } = {};

  jobClassCodes: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<AddWorkerWizardDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: WizardDialogData,
    private relocationService: RelocationService,
    private dialog: MatDialog
  ) {
    this.dialogData = {
      workers: data.workerResults || [],
      locations: data.locationResults || [],
      selectedWorker: {},
      selectedLocation: {}
    };
    this.jobClassCodes = data.jobClassCodes || [];
  }

  ngOnInit(): void {
    // Load job class codes if not provided
    if (!this.jobClassCodes || this.jobClassCodes.length === 0) {
      this.loadJobClassCodes();
    }
  }

  /**
   * Load job class codes from service
   */
  loadJobClassCodes(): void {
    this.relocationService.getJobCodeClasses().subscribe({
      next: (response: any) => {
        this.jobClassCodes = response.results || [];
      },
      error: (error) => {        this.jobClassCodes = [];
      }
    });
  }

  /**
   * Navigate to the previous page (worker selection)
   */
  goToPreviousPage(): void {
    this.currentPage = 'worker';
  }

  /**
   * Navigate to the next page (location selection)
   * Opens the location picker dialog
   */
  goToNextPage(): void {    this.openLocationPickerDialog();
    
  }

  /**
   * Open the location picker dialog
   */
  openLocationPickerDialog(): void {
    const dialogData = {
      mailStopIndicator: false,
      searchTitle: 'Select location'
    };

    const dialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '80vw',
      maxWidth: '1200px',
      height: '80vh',
      data: dialogData,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((location: any) => {
      if (location) {
        this.dialogData.selectedLocation = location;
        // Switch to location page to show the selected location
        this.currentPage = 'location';
      }
    });
  }

  /**
   * Close dialog and return to import mode
   */
  switchToImport(): void {
    this.dialogRef.close('import');
  }

  /**
   * Cancel and close the dialog
   */
  cancel(): void {
    this.dialogRef.close();
  }

  /**
   * Confirm selection and close dialog with data
   */
  addEntry(): void {
    if (this.isValidSelection()) {
      this.dialogRef.close(this.dialogData);
    }
  }

  /**
   * Check if both worker and location are selected
   */
  isValidSelection(): boolean {
    return !!(
      this.dialogData.selectedWorker &&
      this.dialogData.selectedWorker.workerId &&
      this.dialogData.selectedLocation &&
      this.dialogData.selectedLocation.building
    );
  }

  /**
   * Check if next button should be enabled
   */
  canGoNext(): boolean {
    return !!(this.dialogData.selectedWorker && this.dialogData.selectedWorker.workerId);
  }

  /**
   * Handle worker selection from worker picker
   */
  onWorkerSelected(worker: any): void {
    this.dialogData.selectedWorker = worker;
  }

  /**
   * Handle location selection from location picker
   */
  onLocationSelected(location: any): void {
    this.dialogData.selectedLocation = location;
  }

  /**
   * Update function for location picker component
   */
  updateFn(): void {
    // This function can be used by the location picker to trigger updates
    // Implementation depends on location picker component requirements
  }
}
