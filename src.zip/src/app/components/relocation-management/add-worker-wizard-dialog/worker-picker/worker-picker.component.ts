import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { OrganizationService } from 'src/app/shared/services/organizations.services';

@Component({
  selector: 'app-worker-picker',
  templateUrl: './worker-picker.component.html',
  styleUrls: ['./worker-picker.component.scss']
})
export class WorkerPickerComponent implements OnInit, OnChanges {
  @Input() workers: any[] = [];
  @Input() selectedWorker: any = {};
  @Input() selectedLocation: any = {};
  @Input() jobClassCodes: any[] = [];
  @Output() selectedWorkerChange = new EventEmitter<any>();
  @Output() selectedLocationChange = new EventEmitter<any>();

  buildingCodeList: any[] = [];
  buildingsList: any[] = []; // Store full building objects with floors
  floorList: any[] = [];
  workerSearch: any = {
    acronym: '',
    firstName: '',
    lastName: '',
    employeeID: '',
    jobClass: '',
    preferredName: '',
    buildingCodeSearch: '',
    floorSearch: ''
  };

  filteredWorkers: any[] = [];

  constructor(
    private dialog: MatDialog,
    private organizationService: OrganizationService
  ) {}

  ngOnInit(): void {
    this.filteredWorkers = this.workers || [];
    this.loadBuildingCodes();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['workers'] && !changes['workers'].firstChange) {
      this.filteredWorkers = this.workers || [];
    }
  }

  loadBuildingCodes(): void {
    this.organizationService.getBuildings().subscribe({
      next: (response: any) => {
        this.buildingsList = (response.results || [])
          .sort((a: any, b: any) => a.buildingCode.localeCompare(b.buildingCode));
        this.buildingCodeList = this.buildingsList
          .map((building: any) => ({ buildingCode: building.buildingCode }));
      },
      error: (error) => {        this.buildingCodeList = [];
        this.buildingsList = [];
      }
    });
  }

  onBuildingChange(): void {
    // Extract floors for selected building from buildings API response
    this.floorList = [];
    this.workerSearch.floorSearch = '';
    
    if (this.workerSearch.buildingCodeSearch) {
      const selectedBuilding = this.buildingsList.find(
        (building: any) => building.buildingCode === this.workerSearch.buildingCodeSearch
      );
      
      if (selectedBuilding && selectedBuilding.buildingFloors) {
        this.floorList = selectedBuilding.buildingFloors
          .map((floor: any) => ({ floorNumber: floor.floorNumber }))
          .sort((a: any, b: any) => {
            // Sort floors numerically if possible, otherwise alphabetically
            const aNum = parseInt(a.floorNumber);
            const bNum = parseInt(b.floorNumber);
            if (!isNaN(aNum) && !isNaN(bNum)) {
              return aNum - bNum;
            }
            return String(a.floorNumber).localeCompare(String(b.floorNumber));
          });
      }
    }
  }

  /**
   * Open acronym lookup dialog
   */
  searchAcronym(): void {
    const dialogData = {
      title: 'Search and select acronym',
      button: 'Select acronym'
    };

    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      maxWidth: '1200px',
      height: '80vh',
      data: dialogData,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((selectedOrganization: any) => {
      if (selectedOrganization) {
        const businessAreaCode = selectedOrganization.organizationType?.businessArea?.code || selectedOrganization.businessAreaCode || '';
        const shortName = selectedOrganization.shortName || '';
        this.workerSearch.acronym = businessAreaCode && shortName ? `${businessAreaCode}/${shortName}` : '';
        // Trigger search after acronym selection
        this.submitSearch();
      }
    });
  }

  submitSearch(): void {
    // Filter workers based on search criteria
    this.filteredWorkers = this.workers.filter((worker: any) => {
      let matches = true;

      if (this.workerSearch.acronym) {
        matches = matches && worker.acronym?.toLowerCase().includes(this.workerSearch.acronym.toLowerCase());
      }
      if (this.workerSearch.firstName) {
        matches = matches && worker.givenName?.toLowerCase().includes(this.workerSearch.firstName.toLowerCase());
      }
      if (this.workerSearch.lastName) {
        matches = matches && worker.familyName?.toLowerCase().includes(this.workerSearch.lastName.toLowerCase());
      }
      if (this.workerSearch.employeeID) {
        matches = matches && worker.workerNumber?.includes(this.workerSearch.employeeID);
      }
      if (this.workerSearch.buildingCodeSearch) {
        matches = matches && worker.currentLocation?.building?.code === this.workerSearch.buildingCodeSearch;
      }

      return matches;
    });
  }

  selectWorker(worker: any): void {
    this.selectedWorker = worker;
    this.selectedWorkerChange.emit(worker);
  }
}
