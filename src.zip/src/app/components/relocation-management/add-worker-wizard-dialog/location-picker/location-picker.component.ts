import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { RelocationService } from '../../relocation.service';

@Component({
  selector: 'app-location-picker',
  templateUrl: './location-picker.component.html',
  styleUrls: ['./location-picker.component.scss']
})
export class LocationPickerComponent implements OnInit {
  @Input() locations: any[] = [];
  @Input() selectedWorker: any = {};
  @Input() selectedLocation: any = {};
  @Input() updateFn?: () => void;
  @Output() selectedLocationChange = new EventEmitter<any>();

  buildingCodeList: any[] = [];
  formData: any = {
    buildingCodeSearch: '',
    floorSearch: '',
    corridorSearch: '',
    suiteSearch: '',
    roomSearch: '',
    zoneId: ''
  };

  filteredLocations: any[] = [];

  constructor(private relocationService: RelocationService) {}

  ngOnInit(): void {
    this.filteredLocations = this.locations || [];
    this.extractBuildingCodes();
  }

  extractBuildingCodes(): void {
    // Extract unique building codes from locations
    const buildingSet = new Set<string>();
    this.locations?.forEach((location: any) => {
      if (location.building?.code) {
        buildingSet.add(location.building.code);
      }
    });
    this.buildingCodeList = Array.from(buildingSet).map(code => ({ buildingCode: code }));
  }

  submitSearch(): void {
    // Build search parameters
    const searchParams = {
      buildingCodeSearch: this.formData.buildingCodeSearch || '',
      floorSearch: this.formData.floorSearch || '',
      corridorSearch: this.formData.corridorSearch || '',
      suiteSearch: this.formData.suiteSearch || '',
      roomSearch: this.formData.roomSearch || '',
      zonePrefix: this.formData.zoneId || '',
      includeInactive: false
    };

    // Fetch locations from the service
    this.relocationService.getLocationsBySearch(searchParams).subscribe({
      next: (response: any) => {
        this.locations = response.results || [];
        this.filteredLocations = this.locations;
        this.extractBuildingCodes();
        
        // Call update function if provided
        if (this.updateFn) {
          this.updateFn();
        }
      },
      error: (error) => {        this.filteredLocations = [];
      }
    });
  }

  selectLocation(location: any): void {
    this.selectedLocation = location;
    this.selectedLocationChange.emit(location);
  }
}
