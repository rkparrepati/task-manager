import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-relocation-gau-attention-dialog',
  templateUrl: './relocation-gau-attention-dialog.component.html',
  styleUrls: ['./relocation-gau-attention-dialog.component.scss'],
})
export class RelocationGauAttentionDialogComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<RelocationGauAttentionDialogComponent>) {}

  confirm(message: any) {
    this.dialogRef.close(message);
  }

  cancel(message: any) {
    this.dialogRef.close(message);
  }
}
