import { Component, OnInit } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { RelocationService } from '../relocation.service';
import { AppService } from 'src/app/services/app.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { UtilityService } from 'src/app/services/utility.service';
import { GauMoveService } from '../relocate-worker-gau/gau-move.service';
import { RelocationGauAttentionDialogComponent } from '../relocation-gau-attention-dialog/relocation-gau-attention-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';
import { HttpService } from 'src/app/services/http.service';
import { WorkerService } from '../worker.service';
import { OrganizationService } from 'src/app/shared/services/organizations.services';

@Component({
  selector: 'app-relocate-worker-gau-queue',
  templateUrl: './relocate-worker-gau-queue.component.html',
  styleUrls: ['./relocate-worker-gau-queue.component.scss'],
})
export class RelocateWorkerGauQueueComponent implements OnInit {
  public rolesEnum = ROLES_ENUM;
  isManualAdd: boolean = false;
  importedFile: File | undefined = undefined;
  returnCode: any = '';
  hideMessage: boolean = true;
  returnMessage: string = '';
  accessDenied: any;
  selectedSearchCriteria: any;
  invalidBasicSearchText: boolean | undefined;
  invalidAcronym: boolean | undefined;
  applicationType: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchText: any;
  basicSearchSSNDiv: any;
  basicSearchFirmnameDiv: any;
  basicSearchLoginDiv: any;
  cedrRolesDiv: any;
  basicSearchfirmAdministratorDiv: any;
  basicSearchDOBDiv: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  basicSearchCriteria: any;
  errMsg: any;
  workerModel: any;
  basicSearch: any;
  savedSearchCriteria: any;
  searchResultsCount: any;
  advanceSearchOptions: any;
  basicSearchAcronym: any;
  primaryWorker: any;
  initialWorkerData: any; // Store initial worker data for submitted by column
  manualAddSPEErrorMessage: any;
  SPAWorkerNumberSearch: any;
  searchedSPAWorker: any = {};
  searchedWorker: any = {};
  effectiveDateErrorMessage: any;
  invalidRelocationEffectiveDate: any;
  plannedEffectiveDate: any;
  total: number | string = 0;
  disabledCheckboxes: boolean = false;
  selectedAll: boolean = false;
  deleteWorkersData: any;
  sortColumnGAU: string = 'beginEffectiveDt';
  sortDirectionGAU: string = 'asc';
  gauWorkerModel: any = {
    gauWorkers: [],
    selectedWorkers: [],
  };
  showGAUDelete: boolean = false;
  showGAUQueue: boolean = true;
  showGAUQueueSearch: boolean = false;
  showGAUQueueSearchResults: boolean = false;
  showGAUQueueSearchResultsCount: boolean = false;
  showGAUQueueSearchResultsError: boolean = false;
  showGAUQueueSearchResultsErrorMessage: string = '';
  showGAUQueueSearchResultsErrorMessageDetails: string = '';
  newGAUOrganisation = {};
  workerNumberToSearch = '';
  businessAreaCode = '';
  shortName = '';
  searchAcronym = '';
  manualAddWorkerErrorMessage: string | null = null;
  biweeklyDateInfo: string[] = [];
  showWait: boolean = false;
  loadingMessage: string = '';
  submittedDate: string = '';
  submittedBy: string = '';

  constructor(
    public relocationService: RelocationService,
    public appService: AppService,
    private utilityService: UtilityService,
    private gauMoveService: GauMoveService,
    private dialog: MatDialog,
    private httpService: HttpService,
    private workerService: WorkerService,
    private organizationService: OrganizationService
  ) {
    // Initialize current user's loginId from appService userData
    const userData = this.appService.getUserData();
    this.submittedBy = userData?.audit?.createdLoginId || userData?.loginId || '';
  }

  ngOnInit(): void {
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });

    // Initialization logic here
    this.basicSearchCriteria = [
      { value: 'workerId', description: 'Worker Number' },
      { value: 'familyName', description: 'Last Name' },
      { value: 'givenName', description: 'First Name' },
      { value: 'oldOrg', description: 'Current Organization' },
      { value: 'newOrg', description: 'Planned Organization' },
      { value: 'submittedBy', description: 'Submitted By' },
      { value: 'effectiveDate', description: 'Effective Date' },
    ];
    // Set default search criteria to "Worker Number"
    this.selectedSearchCriteria = this.basicSearchCriteria[0];
    this.primaryWorker = this.appService.getUserData();    // Load initial data
    this.getGauQueueList();
    this.getBiweeklyDates();
  }
  downloadTemplate(): void {
    this.relocationService.downloadTemplate('GAUMassUploadTemplate.csv');
  }
  sendFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.importedFile = input.files[0];
    }
  }

  importFile(): void {
    if (!this.importedFile) return;

    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      const parsedObject = this.gauMoveService.parsePlanSpreadsheet(text);
      if (parsedObject.validRows) {
        this.gauMoveService
          .validateSpreadSheet(parsedObject.validRows, this.biweeklyDateInfo, '5')
          .then(
            (processedRows: any) => {
              const invalidRows = parsedObject.invalidRows.concat(processedRows.invalidRows);
              if (invalidRows.length > 0) {
                processedRows.invalidRows = invalidRows;
                this.showImportRelocationDialogFailure(processedRows);
              } else {
                this.moveSuccesfulMass(processedRows.validRows);
              }
            },
            (error: any) => {            }
          );
      } else {
        this.showImportRelocationDialogFailure(parsedObject);
      }
    };

    const suffix = this.importedFile.name.slice(-4);
    if (suffix !== '.csv') {      return;
    }

    reader.readAsText(this.importedFile);
  }

  deleteGAUQueue(): void {
    if (!this.importedFile) return;

    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      const parsedObject = this.gauMoveService.parsePlanSpreadsheet(text);
      if (parsedObject?.validRows?.length) {
        this.deleteMove(parsedObject.validRows).then(
          (processList) => {
            this.saveTheValidDeleteDetails(processList);
          },
          (error) => {          }
        );
      } else {
        this.showImportRelocationDialogFailure(parsedObject);
      }
    };

    const suffix = this.importedFile.name.slice(-4);
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    reader.readAsText(this.importedFile);
  }

  private deleteMove(validRows: any[]): Promise<any> {
    // Use the gauMoveService to process the delete move
    return this.gauMoveService.deleteMove(validRows);
  }

  private saveTheValidDeleteDetails(processList: any): void {
    // Log what we're about to delete    processList.forEach((item: any, index: number) => {    });    // Call the moveDeleteSuccessful method from gauMoveService
    this.gauMoveService.moveDeleteSuccessful(processList).then(
      (response: any) => {        // Clear form fields and file input (matching legacy exitImport behavior)
        this.importedFile = false as any;
        this.searchedSPAWorker = {};
        this.newGAUOrganisation = {};
        this.searchedWorker = {};
        this.workerNumberToSearch = '';
        this.SPAWorkerNumberSearch = '';
        this.businessAreaCode = '';
        this.shortName = '';
        this.searchAcronym = '';
        this.plannedEffectiveDate = '';
        this.manualAddWorkerErrorMessage = null;
        this.manualAddSPEErrorMessage = null;
        this.basicSearchText = '';
        
        // Clear the file input
        const fileInput = document.getElementById('importExcelGAU') as HTMLInputElement;
        if (fileInput) {
          fileInput.value = '';
        }
        
        // Refresh the queue list and wait for it to complete
        this.showWait = true;
        this.loadingMessage = 'Refreshing worker data...';
        
        this.relocationService.getGAUQueueDetails(this.sortColumnGAU, this.sortDirectionGAU).subscribe({
          next: (queueResponse: any) => {            this.createGauWorkersList(queueResponse);
            this.total = queueResponse?.data?.meta?.total || queueResponse?.meta?.total || queueResponse?.total ||
                         (Array.isArray(queueResponse?.data?.results) ? queueResponse.data.results.length : 0) ||
                         (Array.isArray(queueResponse?.results) ? queueResponse.results.length : 0) ||
                         (Array.isArray(queueResponse?.data) ? queueResponse.data.length : 0) || 0;
            this.showWait = false;
            this.loadingMessage = '';
            
            // Now show success dialog after list is refreshed
            const modalOptions = {
              titleType: 'text-success',
              content: processList.length + ' employee(s) moves deleted from the Queue',
              primaryButton: 'OK',
              primaryButtonType: 'success',
              title: 'Mass move List deleted from GAU Queue Successfully!',
            };
            
            this.dialog.open(DialogComponent, {
              width: '400px',
              data: modalOptions,
              disableClose: true,
            });
          },
          error: (error: any) => {            this.showWait = false;
            this.loadingMessage = '';
            
            // Still show success dialog even if refresh fails
            const modalOptions = {
              titleType: 'text-success',
              content: processList.length + ' employee(s) moves deleted from the Queue',
              primaryButton: 'OK',
              primaryButtonType: 'success',
              title: 'Mass move List deleted from GAU Queue Successfully!',
            };
            
            this.dialog.open(DialogComponent, {
              width: '400px',
              data: modalOptions,
              disableClose: true,
            });
          }
        });
      },
      (error: any) => {        const modalOptions = {
          titleType: 'text-danger',
          content: error?.error?.message || processList.length + ' employee(s) could not be deleted from the queue.',
          primaryButton: 'OK',
          primaryButtonType: 'default',
          title: 'Mass move delete execution failed.',
        };

        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalOptions,
          disableClose: true,
        });
      }
    );
  }

  private showImportRelocationDialogFailure(processedRows: any) {
    const dialogRef = this.dialog.open(RelocationGauAttentionDialogComponent, {
      width: '80vw',
      height: '70vh',
      disableClose: true,
      data: {
        data: processedRows,
        title: 'Mass Move GAU Queue Errors Summary'
      },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result === 'continue' && processedRows.validRows && processedRows.validRows.length > 0) {
        this.moveSuccesfulMass(processedRows.validRows);
      }
      // If cancelled or no valid rows, stay on the same page (no redirect)
    });
  }

  private invalidFileTypeMessage(): void {  }

  setBasicSearchInputBox(): void {
    this.resetSearchInputs();

    switch (this.selectedSearchCriteria?.value) {
      case 'acronym':
        this.basicSearchAcronymDiv = true;
        break;
      case 'SSN':
        this.basicSearchSSNDiv = true;
        break;
      case 'firmName':
        this.basicSearchFirmnameDiv = true;
        break;
      case 'firmAdministrator':
        this.basicSearchfirmAdministratorDiv = true;
        break;
      case 'cedrRoles':
        this.cedrRolesDiv = true;
        break;
      case 'birthDate':
        this.basicSearchDOBDiv = true;
        break;
      case 'loginId':
        this.basicSearchLoginDiv = true;
        break;
      default:
        this.basicSearchDiv = true;
        break;
    }
  }

  private resetSearchInputs(): void {
    this.invalidBasicSearchText = false;
    this.invalidAcronym = false;
    this.applicationType = this.selectedSearchCriteria?.value;

    this.basicSearchDiv = false;
    this.basicSearchAcronymDiv = false;
    this.basicSearchSSNDiv = false;
    this.basicSearchFirmnameDiv = false;
    this.basicSearchfirmAdministratorDiv = false;
    this.cedrRolesDiv = false;
    this.basicSearchDOBDiv = false;
    this.basicSearchLoginDiv = false;

    this.basicSearchText = '';
    this.basicSearchBusinessAreaCode = '';
    this.basicSearchShortName = '';
  }
  searchKeyEventBasic(event: Event): void {
    this.basicSearchText = (event.target as HTMLInputElement)?.value;
    if (this.basicSearchText.length >= 1) {
      this.setSearchType(true);
      this.getGauSearchQueueList();
    } else {
      this.getGauQueueList();
      this.getBiweeklyDates();
    }
  }
  getBiweeklyDates(): void {
    this.relocationService.getDateInfo().subscribe({
      next: (response: any) => {
        // Check if response is an error object
        if (response?.stackTrace || response?.message === null) {          this.biweeklyDateInfo = [];
          return;
        }

        const payPeriodData = response?.response?.[0]?.payPeriodData;
        this.biweeklyDateInfo = [];

        if (payPeriodData && Array.isArray(payPeriodData)) {
          payPeriodData.forEach((biweekdate: any) => {
            this.biweeklyDateInfo.push(
              this.utilityService.formatDate(new Date(biweekdate.payPeriodEndDate), 'MMddyyyy')
            );
          });
        }
      },
      error: (error: any) => {        this.biweeklyDateInfo = [];
      },
    });
  }
  getGauQueueList(): void {
    this.showWait = true;
    this.loadingMessage = 'Loading worker data...';
    
    // Check if there's a search in progress
    if (this.selectedSearchCriteria != null && this.basicSearchText && this.basicSearchText.length > 0) {
      this.relocationService.getGAUPartialSearchQueueDetails(
        this.selectedSearchCriteria.value,
        this.basicSearchText,
        this.sortColumnGAU,
        this.sortDirectionGAU
      ).subscribe({
        next: (response: any) => {          this.createGauWorkersList(response);
          // Try multiple possible paths for total count
          this.total = response?.data?.meta?.total || response?.meta?.total || response?.total ||
                       (Array.isArray(response?.data?.results) ? response.data.results.length : 0) ||
                       (Array.isArray(response?.results) ? response.results.length : 0) ||
                       (Array.isArray(response?.data) ? response.data.length : 0) || 0;
          this.showWait = false;
          this.loadingMessage = '';
        },
        error: (error: any) => {          this.returnCode = error.status || 500;
          this.accessDenied = error.accessDenied;
          if (this.returnCode !== 404) {
            this.hideMessage = false;
          }
          this.gauWorkerModel = { gauWorkers: [], selectedWorkers: [] };
          this.total = 0;
          this.showWait = false;
          this.loadingMessage = '';
        },
      });
    } else {
      this.relocationService.getGAUQueueDetails(this.sortColumnGAU, this.sortDirectionGAU).subscribe({
        next: (response: any) => {          this.createGauWorkersList(response);
          // Try multiple possible paths for total count
          this.total = response?.data?.meta?.total || response?.meta?.total || response?.total ||
                       (Array.isArray(response?.data?.results) ? response.data.results.length : 0) ||
                       (Array.isArray(response?.results) ? response.results.length : 0) ||
                       (Array.isArray(response?.data) ? response.data.length : 0) || 0;
          this.showWait = false;
          this.loadingMessage = '';
        },
        error: (error: any) => {          this.returnCode = error.status || 500;
          this.accessDenied = error.accessDenied;
          if (this.returnCode !== 404) {
            this.hideMessage = false;
          }
          this.gauWorkerModel = { gauWorkers: [], selectedWorkers: [] };
          this.total = 0;
          this.showWait = false;
          this.loadingMessage = '';
        },
      });
    }
  }
  
  getGauSearchQueueList(): void {
    this.total = '';
    this.showWait = true;
    this.loadingMessage = 'Loading worker data...';
    
    this.relocationService.getGAUPartialSearchQueueDetails(
      this.selectedSearchCriteria.value,
      this.basicSearchText,
      this.sortColumnGAU,
      this.sortDirectionGAU
    ).subscribe({
      next: (response: any) => {        this.createGauWorkersList(response);
        // Try multiple possible paths for total count
        this.total = response?.data?.meta?.total || response?.meta?.total || response?.total ||
                     (Array.isArray(response?.data?.results) ? response.data.results.length : 0) ||
                     (Array.isArray(response?.results) ? response.results.length : 0) ||
                     (Array.isArray(response?.data) ? response.data.length : 0) || 0;
        this.errMsg = '';
        this.showWait = false;
        this.loadingMessage = '';
      },
      error: (error: any) => {        this.returnCode = error.status || 500;
        this.accessDenied = error.accessDenied;
        if (this.returnCode !== 404) {
          this.hideMessage = true;
          this.errMsg = 'No worker Found';
        }
        this.gauWorkerModel = { gauWorkers: [], selectedWorkers: [] };
        this.total = 0;
        this.showWait = false;
        this.loadingMessage = '';
      },
    });
  }
  
  createGauWorkersList(gauWorkerList: any): void {    // Handle different possible response structures
    let gauWorkersList: any[] = [];
    
    if (gauWorkerList) {
      // Try different response structures
      if (gauWorkerList.data?.results) {
        gauWorkersList = gauWorkerList.data.results;
      } else if (gauWorkerList.results) {
        gauWorkersList = gauWorkerList.results;
      } else if (Array.isArray(gauWorkerList.data)) {
        gauWorkersList = gauWorkerList.data;
      } else if (Array.isArray(gauWorkerList)) {
        gauWorkersList = gauWorkerList;
      }
    }    // Store the first worker's data for submitted by column in manual add
    if (gauWorkersList.length > 0 && !this.initialWorkerData) {
      this.initialWorkerData = JSON.parse(JSON.stringify(gauWorkersList[0]));    }
    
    this.gauWorkerModel = {
      gauWorkers: JSON.parse(JSON.stringify(gauWorkersList)),
      selectedWorkers: [],
    };
  }
  setSearchType(searchType: boolean): void {
    this.hideMessageDiv();
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria?.value,
        },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
      };
      this.clearAdvancedSearch();
    } else {
      this.savedSearchCriteria = { ...this.advanceSearchOptions };
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchAcronym = '';

      this.basicSearchCriteria.forEach((basicSearch: any) => {
        if (basicSearch.value === 'workerId' && basicSearch.description === 'Worker Number') {
          this.selectedSearchCriteria = basicSearch;
        }
      });

      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchfirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
    }
  }

  private hideMessageDiv(): void {
    // Implement the logic to hide the message div
  }

  private clearAdvancedSearch(): void {
    // Implement the logic to clear advanced search
  }
  searchSPAWorker() {
    if (!this.SPAWorkerNumberSearch) {
      return;
    }
    this.searchedSPAWorker = {};
    this.manualAddSPEErrorMessage = null;
    const url = 'workers?workerNumberPrefix=' + this.SPAWorkerNumberSearch;
    this.relocationService.getWorkerByWorkerNumber(this.SPAWorkerNumberSearch, false).subscribe(
      (response: any) => {
        if (
          response &&
          response.results &&
          Array.isArray(response.results) &&
          response.results[0]
        ) {
          this.searchedSPAWorker = response.results[0];
        } else {
          this.manualAddSPEErrorMessage = 'No worker found.';
        }
      },
      (error) => {
        this.manualAddSPEErrorMessage = 'No worker found.';
      }
    );
  }
  exportDataCallbackGAU() {
    // Build URL with query parameters - matching relocation management component format
    let url = `/gau-queue/excelReport?`;
    url += 'sortColumn=' + this.sortColumnGAU;
    url += '&sortOrder=' + this.sortDirectionGAU;
    
    // Add workerId if there's a search in progress
    if (this.selectedSearchCriteria?.value === 'workerId' && this.basicSearchText) {
      url += '&workerId=' + encodeURIComponent(this.basicSearchText);
    }
    
    const fileName = 'GAUQueueListResults.xls';

    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';

          // Append to body to ensure it works in Firefox
          document.body.appendChild(a);
          a.click();

          // Clean up
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
        }
      },
      error: (error: any) => {      }
    });
  }
  deleteWorkerFromGauQueue() {
    const selectedids: number[] = [];
    const selectedWorkers = this.gauWorkerModel.gauWorkers.filter((item: any) => {
      if (item.selected) {
        selectedids.push(item.workerOrganizationQueueId);
      }
      return item.selected;
    });

    this.deleteWorkersData = selectedWorkers;

    this.relocationService
      .executeGAUMoveDeleteWorkerQueue(selectedids)
      .subscribe({
        next: (response: any) => {
          // Success message from legacy: validRows.length + " employee(s) moves deleted from the Queue"
          const modalOptions = {
            titleType: 'text-success',
            content: selectedWorkers.length + ' employee(s) moves deleted from the Queue',
            primaryButton: 'OK',
            primaryButtonType: 'success',
            title: 'Mass move List deleted from GAU Queue Successfully!',
          };
          this.showGAUImport();
          this.selectedAll = false;
        },
        error: (error: any) => {
          const modalOptions = {
            titleType: 'text-danger',
            content: selectedWorkers.length + ' employee(s) could not be deleted.',
            primaryButton: 'OK',
            primaryButtonType: 'default',
            title: 'Mass move delete execution failed.',
          };
          // this.openTheDialog(modalOptions);
        },
      });

    return selectedids;
  }
  showGAUImport() {
    this.importedFile = false as any;
    this.searchedSPAWorker = {};
    this.newGAUOrganisation = {};
    this.searchedWorker = {};
    this.workerNumberToSearch = '';
    this.SPAWorkerNumberSearch = '';
    this.businessAreaCode = '';
    this.shortName = '';
    this.searchAcronym = '';
    this.plannedEffectiveDate = '';
    this.manualAddWorkerErrorMessage = null;
    this.manualAddSPEErrorMessage = null;

    // Clear the file input
    const fileInput = document.getElementById('importExcelGAU') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }

    this.basicSearchText = '';
    this.getGauQueueList();
    this.getBiweeklyDates();
  }
  searchWorker() {
    if (!this.workerNumberToSearch) {
      return;
    }
    this.searchedWorker = {};
    this.manualAddWorkerErrorMessage = null;
    const url = 'workers?workerNumberPrefix=' + this.workerNumberToSearch;
    this.relocationService.getWorkerByWorkerNumber(this.workerNumberToSearch, false).subscribe(
      (response: any) => {
        if (
          response &&
          response.results &&
          Array.isArray(response.results) &&
          response.results[0]
        ) {
          this.searchedWorker = response.results[0];
        } else {
          this.manualAddWorkerErrorMessage = 'No worker found.';
        }
      },
      (error) => {
        this.manualAddWorkerErrorMessage = 'No worker found.';
      }
    );
  }
  getPrimaryOrganization(organizationHistory: any[]): string | undefined {
    let acronym: string = '';
    if (Array.isArray(organizationHistory)) {
      for (const organization of organizationHistory) {
        if (organization.primaryOrganizationIndicator) {
          acronym = `${organization.organization.businessAreaCode}/${organization.organization.shortName}`;
          break;
        }
      }
    }
    return acronym;
  }

  getCurrentOrganization(organization: any): string {
    if (
      organization &&
      organization.organizationType &&
      organization.organizationType.businessArea &&
      organization.organizationType.businessArea.code &&
      organization.shortName
    ) {
      return organization.organizationType.businessArea.code + '/' + organization.shortName;
    }
    return '';
  }
  openLookupOrganization() {
    // const dialogInfo = {
    //   title: "Search and select acronym",
    //   button: "Select acronym",
    // };
    // ngDialog
    //   .openConfirm({
    //     template: "app/organization/organizationSelectTreeDialog.html",
    //     className: "ngdialog-theme-default organizationTreeDialog",
    //     controller: "OrganizationSelectController",
    //     data: dialogInfo,
    //     controllerAs: "vm",
    //   })
    //   .then(
    //     function (selectedOrganization) {
    //       vm.newGAUOrganisation = selectedOrganization;
    //       vm.businessAreaCode = selectedOrganization.organizationType.businessArea.code;
    //       vm.shortName = selectedOrganization.shortName;
    //       vm.searchAcronym = vm.businessAreaCode + "/" + vm.shortName;
    //     },
    //     function () {}
    //   );
  }
  checkAll(): void {
    this.selectedAll = !this.selectedAll;
    this.selectedCount();
  }

  selectedCount(): number {
    let selectedItems = 0;
    if (Array.isArray(this.gauWorkerModel.gauWorkers)) {
      this.gauWorkerModel.gauWorkers.forEach((item: any) => {
        item.selected = this.selectedAll;
        selectedItems += item.selected ? 1 : 0;
      });
    }
    return selectedItems;
  }
  searchAcronymChange(event: any): void {    // Event from lookup dialog - has full organization object
    if (event && event.organizationType && event.shortName) {
      this.businessAreaCode = event.organizationType.businessArea?.code || '';
      this.shortName = event.shortName || '';
      this.searchAcronym = `${this.businessAreaCode}/${this.shortName}`;
      this.newGAUOrganisation = event;    }
    // Manual input - parse the acronym string
    else if (typeof event === 'string' && event.includes('/')) {
      const parts = event.split('/');
      if (parts.length === 2 && parts[0] && parts[1]) {
        this.businessAreaCode = parts[0].trim();
        this.shortName = parts[1].trim();
        this.searchAcronym = event;
        // Note: newGAUOrganisation will be validated via API call in submitManualAdd      } else {
        // Invalid format
        this.businessAreaCode = '';
        this.shortName = '';
        this.newGAUOrganisation = {};      }
    }
    // Clear values if event is invalid
    else {
      this.businessAreaCode = '';
      this.shortName = '';
      this.searchAcronym = '';
      this.newGAUOrganisation = {};    }
  }
  clear(): void {
    this.isManualAdd = false;
    this.searchedWorker = {};
    this.searchedSPAWorker = {};
    this.workerNumberToSearch = '';
    this.SPAWorkerNumberSearch = '';
    this.businessAreaCode = '';
    this.shortName = '';
    this.searchAcronym = '';
    this.plannedEffectiveDate = '';
    this.submittedDate = new Date().toISOString().split('T')[0];
    this.manualAddWorkerErrorMessage = null;
    this.manualAddSPEErrorMessage = null;
    this.newGAUOrganisation = {};
  }
  moveSuccesfulMass(massUploadList: any) {
    const processList = [];
    let processItem: any;
    for (let item of massUploadList) {
      // Get current organization ID from worker's organization history
      let currentOrganizationId = null;
      for (let workerOrganization of item?.databaseWorker?.organizationHistory || []) {
        if (workerOrganization.primaryOrganizationIndicator) {
          currentOrganizationId = workerOrganization.organization.id;
          break;
        }
      }
      
      // Format date as MM/dd/yyyy
      const dateObj = new Date(item.date);
      const month = String(dateObj.getMonth() + 1).padStart(2, '0');
      const day = String(dateObj.getDate()).padStart(2, '0');
      const year = dateObj.getFullYear();
      const formattedDate = `${month}/${day}/${year}`;
      
      processItem = {
        currentOrganizationId: currentOrganizationId,
        plannedOrganizationId: item.newGAU.organization.organizationId,
        firstName: item.worker.givenName,
        lastName: item.worker.familyName,
        workerId: item.databaseWorker.workerId,
        speFirstName: item.worker.speFirstName,
        speLastName: item.worker.speLastName,
        speEmpNumber: item.worker.speEmpNumber,
        beginEffectiveDt: formattedDate,
        audit: {
          createdDate: '',
          createdUser: '',
          lastModifiedDate: '',
          lastModifiedUser: '',
          lockControlNumber: '',
        },
      };
      processList.push(processItem);
    }

    this.relocationService.executeGAUMoveMass(processList).subscribe({
      next: (response: any) => {        // Check if response contains validation errors (invalidResponses)
        const responseData = response?.data || response;
        const invalidResponses = responseData?.invalidResponses || [];
        const validResponses = responseData?.validResponses || [];
        
        if (invalidResponses.length > 0) {
          // Some rows failed - show attention dialog with errors
          const processedRows = {
            validRows: validResponses,
            invalidRows: invalidResponses
          };
          this.showImportRelocationDialogFailure(processedRows);
        } else {
          // All succeeded - show success dialog
          this.showGAUImport();
          const modalOptions = {
            titleType: 'text-success',
            content: processList.length + ' employee(s) moves added to the Queue',
            primaryButton: 'OK',
            primaryButtonType: 'success',
            title: 'Mass move List added to GAU Queue Successfully!',
          };
          
          // Show dialog without navigation (following move-employee-location pattern)
          this.dialog.open(DialogComponent, {
            width: '400px',
            data: modalOptions,
            disableClose: true,
          }).afterClosed().subscribe(() => {
            // Refresh the queue list after dialog closes
            this.showGAUImport();
          });
        }
      },
      error: (err: any) => {        // Emit error message via service for acme-navbar
        this.relocationService.updateReturnCode(err?.status || 500);
        this.relocationService.updateReturnMessage('Mass move execution failed');
        this.relocationService.updateReturnMessageArray([`${processList.length} employee(s) could not be added to the queue.`]);
        this.relocationService.updateHideMessage(false);
        
        const modalOptions = {
          titleType: 'text-danger',
          content: err?.error?.message || processList.length + ' employee(s) could not be added to the queue.',
          primaryButton: 'OK',
          primaryButtonType: 'default',
          title: 'Mass move execution failed.',
        };

        // Show dialog without navigation
        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalOptions,
          disableClose: true,
        });
      },
    });
  }
  openTheDialog(modalData: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: modalData,
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      // Refresh the queue list after dialog closes instead of redirecting
      this.showGAUImport();
    });
  }

  /**
   * Helper function to build error row structure for attention dialog
   */
  private buildErrorRow(errorMessage: string): any {
    const primaryOrg = this.getPrimaryOrganization(this.searchedWorker?.organizationHistory || []);
    // Only create acronym if both parts exist, otherwise leave empty
    const newAcronym = (this.businessAreaCode && this.shortName)
      ? `${this.businessAreaCode}/${this.shortName}`
      : '';
    
    return {
      row: 1,
      worker: {
        familyName: this.searchedWorker?.familyName || '',
        givenName: this.searchedWorker?.givenName || '',
        workerNumber: this.searchedWorker?.workerNumber || '',
        speLastName: this.searchedSPAWorker?.familyName || '',
        speFirstName: this.searchedSPAWorker?.givenName || '',
        speEmpNumber: this.searchedSPAWorker?.workerNumber || '',
      },
      oldGAU: {
        acronym: primaryOrg || '',
        organization: { acronym: primaryOrg || '' }
      },
      newGAU: {
        acronym: newAcronym,
        organization: { acronym: newAcronym }
      },
      date: this.formatDateForSubmission(this.plannedEffectiveDate),
      errorMessage: errorMessage
    };
  }

  /**
   * Submit manual add request - validates and adds single worker to GAU queue
   * Based on legacy code: relocation.controller.js importWorker() function (line 1349)
   * Makes 5 mandatory API calls before validation:
   * 1. workerQueue?includeInactive=true&workerNumber={workerNumber}
   * 2. workers?includeInactive=true&workerNumber={speWorkerNumber}
   * 3. workers?includeInactive=true&workerNumber={workerNumber}
   * 4. organizations?businessAreaCode={oldBusinessArea}&includeInactive=true&root=false&shortName={oldShortName}
   * 5. organizations?businessAreaCode={newBusinessArea}&includeInactive=true&root=false&shortName={newShortName}
   */
  async submitManualAdd(): Promise<void> {
    // Show loading indicator
    this.showWait = true;
    this.loadingMessage = 'Validating worker information...';

    try {      // Validate that new organization details are present
      if (!this.businessAreaCode || !this.shortName ||
          this.businessAreaCode.trim() === '' || this.shortName.trim() === '') {
        this.showWait = false;
        this.loadingMessage = '';        const processedRows = {
          invalidRows: [this.buildErrorRow('Please select a valid planned organization.')],
          validRows: []
        };
        this.showImportRelocationDialogFailure(processedRows);
        return;
      }

      // Get primary organization for old GAU
      const primaryOrg = this.getPrimaryOrganization(this.searchedWorker?.organizationHistory || []);
      const primaryOrgParts = primaryOrg?.split('/') || [];
      const oldBusinessAreaCode = primaryOrgParts[0] || '';
      const oldShortName = primaryOrgParts[1] || '';      // MANDATORY CALL 1: Check if worker exists in queue      const queueResponse: any = await firstValueFrom(
        this.workerService.getWorkerFromQueueByWorkerNumber(this.searchedWorker?.workerNumber || '', true)
      );
      
      let queueCount = 0;
      if (typeof queueResponse === 'number') {
        queueCount = queueResponse;
      } else if (queueResponse?.data?.results) {
        queueCount = queueResponse.data.results.length;
      } else if (queueResponse?.results) {
        queueCount = queueResponse.results.length;
      } else if (queueResponse?.data?.count !== undefined) {
        queueCount = queueResponse.data.count;
      } else if (queueResponse?.count !== undefined) {
        queueCount = queueResponse.count;
      }
      
      if (queueCount > 0) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('Worker already exists in Queue.')],
          validRows: []
        });
        return;
      }

      // MANDATORY CALL 2: Validate SPE worker      const speResponse: any = await firstValueFrom(
        this.relocationService.getWorkerByWorkerNumber(this.searchedSPAWorker?.workerNumber || '', true)
      );
      
      if (!speResponse?.results?.[0]) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('SPE Employee no. is not valid.')],
          validRows: []
        });
        return;
      }

      const speWorker = speResponse.results[0];
      
      // Validate SPE name matches
      if (speWorker.familyName?.trim() !== this.searchedSPAWorker.familyName?.trim() ||
          speWorker.givenName?.trim() !== this.searchedSPAWorker.givenName?.trim()) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('SPE Employee name does not belong to SPE Employee number.')],
          validRows: []
        });
        return;
      }

      // Validate SPE is active
      if (!speWorker.activeEmploymentIndicator) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('SPE is not active.')],
          validRows: []
        });
        return;
      }

      // MANDATORY CALL 3: Validate main worker      const workerResponse: any = await firstValueFrom(
        this.relocationService.getWorkerByWorkerNumber(this.searchedWorker?.workerNumber || '', true)
      );
      
      if (!workerResponse?.results?.[0]) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('Employee id is not valid.')],
          validRows: []
        });
        return;
      }

      const mainWorker = workerResponse.results[0];
      
      // Validate worker is active
      if (!mainWorker.activeEmploymentIndicator) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('Employee is not active.')],
          validRows: []
        });
        return;
      }

      // MANDATORY CALL 4: Validate old organization      let oldOrgData: any = null;
      if (oldBusinessAreaCode && oldShortName) {
        const oldOrgResponse: any = await firstValueFrom(
          this.organizationService.getOrganizationByAcronym(`${oldBusinessAreaCode}/${oldShortName}`, true)
        );
        if (oldOrgResponse?.results?.[0]) {
          oldOrgData = oldOrgResponse.results[0];
        }
      }

      // MANDATORY CALL 5: Validate new organization      const newOrgResponse: any = await firstValueFrom(
        this.organizationService.getOrganizationByAcronym(`${this.businessAreaCode}/${this.shortName}`, true)
      );
      
      if (!newOrgResponse?.results?.[0]) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('The new acronym does not exist.')],
          validRows: []
        });
        return;
      }

      const newOrgData = newOrgResponse.results[0];
      
      // Store the organization ID for payload - this is critical for submission
      const plannedOrganizationId = newOrgData.organizationId;      // Validate new organization is active
      if (newOrgData?.lifecycle?.endDate) {
        this.showWait = false;
        this.loadingMessage = '';
        this.showImportRelocationDialogFailure({
          invalidRows: [this.buildErrorRow('The new acronym is not active.')],
          validRows: []
        });
        return;
      }      // Build worker info object matching legacy structure (line 1360-1399)
    
    const workerInfo = [{
      row: 1,
      worker: {
        familyName: this.searchedWorker?.familyName || '',
        givenName: this.searchedWorker?.givenName || '',
        workerNumber: this.searchedWorker?.workerNumber || '',
        speLastName: this.searchedSPAWorker?.familyName || '',
        speFirstName: this.searchedSPAWorker?.givenName || '',
        speEmpNumber: this.searchedSPAWorker?.workerNumber || '',
      },
      oldGAU: {
        organization: {
          acronym: primaryOrg || '',
          organizationType: {
            businessArea: {
              value: primaryOrgParts[0] || '',
            },
          },
          shortName: primaryOrgParts[1] || '',
        },
      },
      newGAU: {
        organization: {
          acronym: this.searchAcronym || ((this.businessAreaCode && this.shortName) ? `${this.businessAreaCode}/${this.shortName}` : ''),
          organizationType: {
            businessArea: {
              value: this.businessAreaCode || '',
            },
          },
          shortName: this.shortName || '',
          id: plannedOrganizationId, // Add organization ID for payload
        },
      },
      date: this.formatDateForSubmission(this.plannedEffectiveDate),
      message: '',
      errorMessage: null,
      databaseWorker: this.searchedWorker,
      plannedOrganizationId: plannedOrganizationId, // Store at top level for easy access
    }];

      // Check if new GAU shortName is missing (legacy line 1400-1405)
      if (!workerInfo[0].newGAU.organization.shortName) {
        const processedRows = {
          invalidRows: [{
            ...workerInfo[0],
            errorMessage: 'Invalid new GAU'
          }],
          validRows: []
        };
        this.showImportRelocationDialogFailure(processedRows);
        return;
      }

      // Call validateSpreadSheet like legacy (line 1406-1418)
      const processedRows = await this.gauMoveService.validateSpreadSheet(
        workerInfo,
        this.biweeklyDateInfo,
        '5' // selectedTool for GAU queue
      );

      this.showWait = false;
      this.loadingMessage = '';

      // If there are invalid rows, show the attention dialog (legacy line 1409-1411)
      if (processedRows.invalidRows.length > 0) {
        this.showImportRelocationDialogFailure(processedRows);
      } else {
        // All valid - proceed to save (legacy line 1412)
        this.saveTheValidDetails(workerInfo);
      }

    } catch (error: any) {      this.showWait = false;
      this.loadingMessage = '';
      
      this.showImportRelocationDialogFailure({
        invalidRows: [this.buildErrorRow('An error occurred during validation.')],
        validRows: []
      });
    }
  }

  /**
   * Save valid worker details to GAU queue
   * Based on legacy saveTheValidDetails function
   */
  private saveTheValidDetails(workerInfo: any[]): void {
    this.showWait = true;
    this.loadingMessage = 'Adding worker to queue...';

    // Build payload for mass upload
    const dateObj = new Date(workerInfo[0].date);
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    const formattedDate = `${month}/${day}/${year}`;

    // Get primary organization ID
    let currentOrganizationId = null;
    for (const workerOrganization of workerInfo[0].databaseWorker?.organizationHistory || []) {
      if (workerOrganization.primaryOrganizationIndicator) {
        currentOrganizationId = workerOrganization.organization.id;
        break;
      }
    }

    const payload = [{
      currentOrganizationId: currentOrganizationId,
      plannedOrganizationId: workerInfo[0].plannedOrganizationId || workerInfo[0].newGAU?.organization?.id,
      firstName: workerInfo[0].worker.givenName,
      lastName: workerInfo[0].worker.familyName,
      workerId: workerInfo[0].databaseWorker.workerId,
      speFirstName: workerInfo[0].worker.speFirstName,
      speLastName: workerInfo[0].worker.speLastName,
      speEmpNumber: workerInfo[0].worker.speEmpNumber,
      beginEffectiveDt: formattedDate,
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lastModifiedUser: '',
        lockControlNumber: '',
      },
    }];    // Submit to API
    this.relocationService.executeGAUMoveMass(payload).subscribe({
      next: (response: any) => {        this.showWait = false;
        this.loadingMessage = '';
        
        // Check for validation errors
        const responseData = response?.data || response;
        const invalidResponses = responseData?.invalidResponses || [];
        
        if (invalidResponses.length > 0) {
          // Show error in attention dialog
          const processedRows = {
            invalidRows: invalidResponses,
            validRows: []
          };
          this.showImportRelocationDialogFailure(processedRows);
        } else {
          // Success - clear form and refresh list
          this.clear();
          this.isManualAdd = false;
          this.showGAUImport();
          
          const modalOptions = {
            titleType: 'text-success',
            content: '1 employee(s) moves added to the Queue',
            primaryButton: 'OK',
            primaryButtonType: 'success',
            title: 'Mass move List added to GAU Queue Successfully!',
          };
          
          this.dialog.open(DialogComponent, {
            width: '400px',
            data: modalOptions,
            disableClose: true,
          });
        }
      },
      error: (error: any) => {        this.showWait = false;
        this.loadingMessage = '';
        
        const modalOptions = {
          titleType: 'text-danger',
          content: error?.error?.message || 'Failed to add employee to the queue.',
          primaryButton: 'OK',
          primaryButtonType: 'default',
          title: 'Error',
        };
        
        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalOptions,
          disableClose: true,
        });
      },
    });
  }

  resortGAU(event: any): void {
    this.sortColumnGAU = event.columnName;
    this.sortDirectionGAU = event.sortOrder;
    this.getGauQueueList();
  }

  getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${month}/${day}/${year}`;
  }

  /**
   * Handles input event on the organization search input field.
   * Automatically adds "/" after the first character (business area code).
   * Converts input to uppercase.
   */
  onAcronymInput(event: any): void {
    const input = event.target as HTMLInputElement;
    let value = input.value.toUpperCase().replace(/\W+/g, ''); // Convert to uppercase and remove non-alphanumeric characters
    
    if (value) {
      value = this.formatAcronym(value);
      input.value = value;
    }
  }

  /**
   * Formats the acronym by adding "/" after the first character (business area code).
   * @param acronym - The raw acronym string
   * @returns Formatted acronym with "/" separator
   */
  /**
   * Format date for submission - handles both Date objects and strings
   */
  private formatDateForSubmission(date: any): string {
    if (!date) {
      return '';
    }
    
    // If it's already a string in MM/DD/YYYY format, return it
    if (typeof date === 'string') {
      return date;
    }
    
    // If it's a Date object, format it as MM/DD/YYYY
    if (date instanceof Date) {
      const month = ('0' + (date.getMonth() + 1)).slice(-2);
      const day = ('0' + date.getDate()).slice(-2);
      const year = date.getFullYear();
      return `${month}/${day}/${year}`;
    }
    
    // Try to convert to string
    return String(date);
  }

  private formatAcronym(acronym: string): string {
    if (!acronym) {
      return '';
    }
    
    // Remove any existing slashes
    const cleaned = acronym.replace(/\//g, '');
    
    // Format as X/XXXXXXXX (business area code / short name)
    if (cleaned.length <= 1) {
      return cleaned;
    } else {
      return `${cleaned.charAt(0)}/${cleaned.slice(1)}`;
    }
  }
}
  
