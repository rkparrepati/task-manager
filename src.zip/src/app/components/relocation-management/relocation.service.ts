import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RelocationService {
  private _selectedRelocationPlan: any;

  // Toast message management (following location service pattern)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();

  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  // Methods to update toast messages (following location service pattern)
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.scrolltoTop();
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  saveRelocationPlan(relocation: any) {
    relocation.plannedStartDate = this.utilityService.adjustDateFormatter(
      relocation.plannedStartDate
    );
    if (relocation.relocationPlanId) {
      return this.updateRelocationPlan(relocation);
    } else {
      return this.createRelocationPlan(relocation);
    }
  }

  private updateRelocationPlan(relocation: any) {
    return this.httpService.put(`/relocation-plans/${relocation.relocationPlanId}`, relocation);
  }

  private createRelocationPlan(relocation: any) {
    return this.httpService.post('/relocation-plans', relocation);
  }

  deleteRelocationPlan(relocationPlanId: string) {
    return this.httpService.delete(`/relocation-plans/${relocationPlanId}`);
  }

  getRelocationPlanDetails(relocation: any, limit?: number, skip?: number) {
    let planName = '';
    if (relocation.relocationPlanName) {
      for (let i = 0; i < relocation.relocationPlanName.length; i++) {
        const char = relocation.relocationPlanName.charAt(i);
        if (char === ' ') {
          planName += '+';
        } else {          planName += char;
        } 
      }
    }
    if(limit && skip) {
      const url = `/workerAssignmentPlans?relocationPlanId=${relocation.relocationPlanId || ''}&relocationPlanName=${planName}&limit=${limit.toString()}&skip=${skip.toString()}`;
      return this.httpService.get(url);
    }
    else{      const url = `/workerAssignmentPlans?relocationPlanId=${relocation.relocationPlanId || ''}&relocationPlanName=${planName}`;
      return this.httpService.get(url);
    }
  }

  getDateInfo() {
    return this.httpService.get('/gaumove');
  }

  getGAUQueueDetails(sortColumnGAU: string, sortDirectionGAU: string) {
    const url = `/gau-queue?sortColumn=${sortColumnGAU}&sortOrder=${sortDirectionGAU}`;
    return this.httpService.get(url);
  }

  getGAUSearchQueueDetails(workerId: string, sortColumnGAU: string, sortDirectionGAU: string) {
    const url = `/gau-search-queue?workerId=${workerId}&sortColumn=${sortColumnGAU}&sortOrder=${sortDirectionGAU}`;
    return this.httpService.get(url);
  }

  getGAUPartialSearchQueueDetails(searchType: string, searchText: string, sortColumnGAU: string, sortDirectionGAU: string) {
    let url = `/gau-queue?sortColumn=${sortColumnGAU}&sortOrder=${sortDirectionGAU}`;
    
    // Add search parameters based on search type
    if (searchType && searchText) {
      url += `&${searchType}=${encodeURIComponent(searchText)}`;
    }
    
    return this.httpService.get(url);
  }

  getRelocations(sortColumn: any, sortDirection: any) {
    const url = `/relocation-plans?sortColumn=${sortColumn}&sortOrder=${sortDirection}`;
    return this.httpService.get(url);
  }
  exportTableService(url: string) {
    return this.httpService.getExcelReport(url);
  }
  /**
   * This method is to download worker spreadsheet using POST method
   */
  getWorkerSpreadsheet(
    url: string,
    fileName: string,
    fileType: string,
    isInfraURL: boolean,
    payload: any
  ) {
    this.httpService.postForCsv(url, payload).subscribe({
      next: (blob: Blob) => {
        const objectUrl = URL.createObjectURL(blob);

        const anchor = document.createElement('a');
        anchor.href = objectUrl;
        anchor.download = fileName;
        anchor.target = '_blank';
        anchor.click();

        // Clean up the object URL
        URL.revokeObjectURL(objectUrl);
      },
      error: (err) => {      },
    });
  }
  downloadTemplate(fileName: string) {
    const link = document.createElement('a');
    link.style.display = 'none';
    link.href = `assets/uploads/${fileName}`;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  moveEmployeeLocation(url: string, params: Record<string, any>, payload: any) {
    // Serialize the audit object as JSON string for the query parameter
    const auditParam = params.audit ? JSON.stringify(params.audit) : '';
    const fullUrl = `${url}?audit=${encodeURIComponent(auditParam)}`;
    return this.httpService.put(fullUrl, payload);
  }
  validateLocations(locationData: any[]) {
    return this.httpService.post('/locationsTest', locationData);
  }
  getWorkerAssignments(workerId: string) {
    return this.httpService.get(`/workers/${workerId}/assignments`);
  }
  getWorkerByWorkerNumber(workerNumber: string, includeInactive: boolean) {
    return this.httpService.get(
      `/workers?workerNumber=${workerNumber}&includeInactive=${includeInactive}`
    );
  }
  executeGAUMove(rows: any) {
    return this.httpService.post('/gau-queue', rows);
  }
  getTelecomTypes(description = null) {
    let url = `/references/telcom-address-types?includeInactive=false`;
    if (description) {
      url += `&description=${description}`;
    }
    return this.httpService.get(url);
  }
  validatePhoneNumbers(phoneData: any[]) {
    return this.httpService.post('/workers/phonenumbers/execute', phoneData);
  }
  updatePhoneNumbers(list: any) {
    return this.httpService.post('/workers/phonenumbers/execute', list);
  }
  getUploadEmployeeRoleCodeResponse(validRequests: any) {
    return this.httpService.post('/workerOrgRoleUpdate', validRequests);
  }
  saveUploadEmployeeRoleCodeResponse(validRequests: any) {
    if (validRequests instanceof Array) {
      return this.httpService.post('/workerOrgRoleUpdateSave', validRequests);
    }
    return this.httpService.post('/workerOrgRoleUpdateSave', [validRequests]);
  }
  executeGAUMoveDelete(requests: any) {
    return this.httpService.put('/gau-queue', requests);
  }
  executeGAUMoveMass(requests: any) {
    return this.httpService.post('/gau-queue', requests);
  }
  executeGAUMoveDeleteWorkerQueue(workerIds: Array<number>) {
    return this.httpService.post('/deleteWorkerQueue', workerIds);
  }
  get selectedPlan(): any {
    return this._selectedRelocationPlan;
  }
  set selectedPlan(value: any) {
    this._selectedRelocationPlan = value;
  }

  getJobCodeClasses() {
    return this.httpService.get('/references/job-classes?sortOrder=asc&sortColumn=value');
  }

  getLocation(locationId: string) {
    return this.httpService.get(`/locations/${locationId}`);
  }

  getLocationsBySearch(searchParams: any) {
    const params: string[] = [];
    
    if (searchParams.buildingCodeSearch) {
      params.push(`buildingCode=${encodeURIComponent(searchParams.buildingCodeSearch)}`);
    }
    if (searchParams.floorSearch) {
      params.push(`floorPrefix=${encodeURIComponent(searchParams.floorSearch)}`);
    }
    if (searchParams.corridorSearch) {
      params.push(`corridorPrefix=${encodeURIComponent(searchParams.corridorSearch)}`);
    }
    if (searchParams.suiteSearch) {
      params.push(`suitePrefix=${encodeURIComponent(searchParams.suiteSearch)}`);
    }
    if (searchParams.roomSearch) {
      params.push(`roomPrefix=${encodeURIComponent(searchParams.roomSearch)}`);
    }
    if (searchParams.zonePrefix) {
      params.push(`zonePrefix=${encodeURIComponent(searchParams.zonePrefix)}`);
    }
    
    // Add includeInactive parameter (default to false)
    const includeInactive = searchParams.includeInactive !== undefined ? searchParams.includeInactive : false;
    params.push(`includeInactive=${includeInactive}`);
    
    const url = `/locations?${params.join('&')}`;
    return this.httpService.get(url);
  }
}
