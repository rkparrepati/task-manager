import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RelocationService } from '../relocation.service';
import { AppService } from 'src/app/services/app.service';
import { DialogComponent } from '../dialog/dialog.component';
import { WorkerService } from '../worker.service';
import { ImportPhoneNumbersAttentionDialogComponent } from '../import-phone-numbers-attention-dialog/import-phone-numbers-attention-dialog.component';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-import-phone-numbers',
  templateUrl: './import-phone-numbers.component.html',
  styleUrls: ['./import-phone-numbers.component.scss'],
})
export class ImportPhoneNumbersComponent implements OnInit {
  importedFile: File | null = null;
  phoneNumbersSpreadsheet: any;
  returnCode: any = '';
  hideMessage: boolean = true;
  returnMessage: string = '';
  accessDenied: any;
  telecommunicationTypes: any[] = [];
  messages = {
    firstNameMissing: 'First name is missing. ',
    lastNameMissing: 'Last name is missing. ',
    workerNumberMissing: 'Employee number is missing. ',
    workerNumberInvalid: 'Employee number is not valid. ',
    workerNameMismatch: 'Employee name does not belong to Employee number. ',
    workerAcronymMismatch: 'Employee does not belong to the old acronym. ',
    workerNotActive: 'Employee is not active. ',
    workerDuplicate: 'This Employee number is duplicated. ',
    formatInvalid: 'The format of the spreadsheet is not expected. ',
    phoneNumberMissing: 'Phone number is missing. ',
    phoneNumberInvalid:
      'Phone number format is not valid. See phone number column header for valid formats. ',
    phoneNumberNoChange: 'Current primary phone number is same as new phone number. ',
    phoneNumberIndicatorMissing: 'Phone number indicator is missing. ',
    phoneNumberTypeMissing: 'Phone number type is missing. ',
    phoneNumberOtherNoChange: ' number already exists. ',
    noPrimaryTelecommunication:
      'This worker does not have a primary communication. ' +
      "Alternate or Hidden worker communication can't be added without a Primary worker communication. ",
    invalidTelecommunicationType: 'Worker communication type is not valid. ',
  };

  constructor(
    public relocationService: RelocationService,
    private workerService: WorkerService,
    private appService: AppService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });

    // Load telecommunication types
    this.loadTelecommunicationTypes();
  }

  loadTelecommunicationTypes(): void {
    this.relocationService.getTelecomTypes().subscribe({
      next: (response: any) => {        this.telecommunicationTypes = response?.results || [];      },
      error: (error) => {      },
    });
  }

  downloadTemplate(): void {
    this.relocationService.downloadTemplate('PhoneNumbersMassUpload.csv');
  }

  sendFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.importedFile = input.files[0];
    }
  }

  importFile(): void {
    if (!this.importedFile) return;

    const suffix = this.importedFile.name.slice(-4);
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }

    // Ensure telecommunication types are loaded before parsing
    if (!this.telecommunicationTypes || this.telecommunicationTypes.length === 0) {      this.relocationService.getTelecomTypes().subscribe({
        next: (response: any) => {          this.telecommunicationTypes = response?.results || [];          this.processFile();
        },
        error: (error) => {          this.relocationService.updateReturnCode(500);
          this.relocationService.updateReturnMessage('Failed to load telecommunication types');
          this.relocationService.updateHideMessage(false);
        }
      });
    } else {
      this.processFile();
    }
  }

  private processFile(): void {
    if (!this.importedFile) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const text = reader.result as string;
      const parsedObject = await this.parsePlanSpreadsheet(text);
      
      if (parsedObject) {        if (parsedObject.validRows && parsedObject.validRows.length > 0) {          // Always call validation first (matches legacy flow)
          const processedRows = await this.validatePhoneNumbers(parsedObject.validRows, parsedObject.invalidRows || []);
          this.handleValidationResults(processedRows);
        } else {
          // No valid rows at all, still call validation to show dialog
          const processedRows = await this.validatePhoneNumbers([], parsedObject.invalidRows || []);
          this.handleValidationResults(processedRows);
        }
      }
    };

    reader.readAsText(this.importedFile);
  }

  async validatePhoneNumbers(validRows: any[], initialInvalidRows: any[]): Promise<{ validRows: any[]; invalidRows: any[] }> {
    try {
      // Step 1: Fetch worker data for all unique worker numbers
      const uniqueWorkerNumbers = [...new Set(validRows.map(row => row.worker.workerNumber))];
      const workerRequests = uniqueWorkerNumbers.map(workerNumber =>
        this.relocationService.getWorkerByWorkerNumber(workerNumber, true)
      );

      const workerResponses = await forkJoin(workerRequests).toPromise();
      
      // Create a map of worker data by worker number
      const workerDataMap = new Map();
      if (workerResponses) {
        uniqueWorkerNumbers.forEach((workerNumber, index) => {
          const workerResponse: any = workerResponses[index];
          const workerData = workerResponse?.data?.[0];
          if (workerData) {
            workerDataMap.set(workerNumber, workerData);
          }
        });
      }

      // Step 2: Fetch telecommunications for each worker
      const telecomRequests = Array.from(workerDataMap.values()).map(worker =>
        this.workerService.getTelecommunications(worker.workerId, [])
      );

      const telecomResponses = telecomRequests.length > 0 ? await forkJoin(telecomRequests).toPromise() : [];
      
      // Create a map of telecommunications by workerId
      const telecomMap = new Map();
      if (telecomResponses) {
        Array.from(workerDataMap.values()).forEach((worker, index) => {
          telecomMap.set(worker.workerId, telecomResponses[index] || []);
        });
      }

      // Step 3: Attach worker data and telecommunications to each row and perform additional validation
      validRows.forEach((lineInfo) => {
        const workerData = workerDataMap.get(lineInfo.worker.workerNumber);
        if (workerData) {
          lineInfo.databaseWorker = workerData;
          lineInfo.existingTelecommunications = telecomMap.get(workerData.workerId) || [];
          
          // Validate worker is active
          if (!workerData.activeEmploymentIndicator) {
            lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.workerNotActive;
          }
          
          // Check for primary telecommunication if indicator is HIDDEN or ALTERNATE
          if (lineInfo.indicator === 'HIDDEN' || lineInfo.indicator === 'ALTERNATE') {
            const hasPrimary = lineInfo.existingTelecommunications.some((comm: any) => comm.primaryIndicator);
            if (!hasPrimary) {
              lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.noPrimaryTelecommunication;
            }
          }
          
          // Compare with existing telecommunications
          const numberPattern = /\d+/g;
          const newPhoneNumber = lineInfo.phoneNumber.match(numberPattern)?.join('') || '';
          
          lineInfo.existingTelecommunications.forEach((communication: any) => {
            const existingPhoneNumber = communication.telephoneNo?.match(numberPattern)?.join('') || '';
            
            if (existingPhoneNumber === newPhoneNumber) {
              // Check if it's a primary phone number
              if (communication.primaryIndicator && lineInfo.indicator === 'PRIMARY') {
                lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.phoneNumberNoChange;
              }
              // Check if it's a hidden phone number
              else if (communication.hiddenIndicator && lineInfo.indicator === 'HIDDEN') {
                lineInfo.errorMessage = (lineInfo.errorMessage || '') +
                  'This ' + lineInfo.indicator + ' ' + lineInfo.type + this.messages.phoneNumberOtherNoChange;
              }
              // Check if it's an alternate phone number
              else if (!communication.hiddenIndicator && !communication.primaryIndicator && lineInfo.indicator === 'ALTERNATE') {
                lineInfo.errorMessage = (lineInfo.errorMessage || '') +
                  'This ' + lineInfo.indicator + ' ' + lineInfo.type + this.messages.phoneNumberOtherNoChange;
              }
            }
          });
        }
      });

      // Step 4: Process rows and determine valid/invalid based on all validation      const processedRows = {
        validRows: [] as any[],
        invalidRows: [] as any[]
      };
      
      // Separate valid and invalid rows based on error messages accumulated during validation
      validRows.forEach((row) => {
        if (!row.errorMessage) {
          processedRows.validRows.push(row);
        } else {
          processedRows.invalidRows.push(row);
        }
      });      // Merge initial invalid rows with validation invalid rows
      const allInvalidRows = [...initialInvalidRows, ...processedRows.invalidRows];
      processedRows.invalidRows = allInvalidRows;
      
      return processedRows;
    } catch (error) {      this.relocationService.updateReturnCode(500);
      this.relocationService.updateReturnMessage('Failed to fetch worker data');
      this.relocationService.updateHideMessage(false);
      return { validRows: [], invalidRows: initialInvalidRows };
    }
  }

  handleValidationResults(processedRows: { validRows: any[]; invalidRows: any[] }): void {    if (processedRows.invalidRows.length > 0) {
      this.showPhoneNumberImportDialogFailure(processedRows);
    } else {
      // All rows are valid, proceed with execution
      this.executeMassPhoneImport(processedRows.validRows);
    }
  }

  showPhoneNumberImportDialogFailure(parsedObject: any) {
    const dialogRef = this.dialog.open(ImportPhoneNumbersAttentionDialogComponent, {
      width: '80vw',
      height: '70vh',
      data: {
        data: parsedObject,
        title: 'Mass Phone Number Assignments Errors Summary'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'continue' && parsedObject.validRows && parsedObject.validRows.length > 0) {
        // Validation already happened, proceed to execute with valid rows only
        this.executeMassPhoneImport(parsedObject.validRows);
      }
      // If cancelled or no valid rows, do nothing
    });
  }

  invalidFileTypeMessage() {
    const modalData = {
      titleType: 'text-danger',
      content: 'The format of the spreadsheet is not expected. Only CSV files can be imported.',
      primaryButton: 'Close',
      primaryButtonType: 'danger',
      title: 'Invalid File type!'
    };
    
    this.dialog.open(DialogComponent, {
      width: '400px',
      data: modalData,
      disableClose: true,
    });
  }

  async executeMassPhoneImport(rows: any[]) {
    try {
      const numberPattern = /\d+/g;
      const executeList = rows.map((workerPhone) => {
        const phoneNumber = workerPhone.phoneNumber.match(numberPattern).join('');
        const formattedPhoneNumber = `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6)}`;
        return {
          worker: { workerId: workerPhone.databaseWorker?.workerId },
          telephoneNo: formattedPhoneNumber,
          telecomAddressType: { id: workerPhone.telecommunicationType?.id },
          primaryIndicator: workerPhone.indicator === 'PRIMARY',
          hiddenIndicator: workerPhone.indicator === 'HIDDEN',
        };
      });
      this.relocationService.updatePhoneNumbers(executeList).subscribe({
        next: () => {
          this.handleUploadCompletion({ validRows: rows, invalidRows: [] });
        },
        error: (response: any) => {
          this.handleUploadCompletion({ validRows: [], invalidRows: rows });
        },
      });
    } catch (error) {      throw error;
    }
  }

  handleUploadCompletion(rows: { validRows: any[]; invalidRows: any[] }): void {
    let modalData = {};
    if (rows.validRows.length > 0) {
      modalData = {
        titleType: 'text-success',
        content: rows.validRows.length + ' phone number(s) assigned.',
        primaryButton: 'OK',
        primaryButtonType: 'success',
        title: 'Phone number(s) assigned successfully!',
      };
    }
    if (rows.invalidRows.length > 0) {
      modalData = {
        titleType: 'text-danger',
        content:  ' Phone number(s) could not be assigned.',
        primaryButton: 'OK',
        primaryButtonType: 'default',
        title: 'Assignment of phones numbers failed: Worker Telecom Address already exists.'
      };
    }
    
    // Navigate first, then show dialog
    this.appService.changePage('/app/relocation');
    
    // Show dialog after navigation with a slight delay to ensure the page is loaded
    setTimeout(() => {
      this.dialog.open(DialogComponent, {
        width: '450px',
        data: modalData,
        disableClose: true,
      });
    }, 100);
  }

  checkHeader(lines: string[]): boolean {
    if (lines.length === 0) return false;

    const message = this.parseHeader(lines[0]);
    return !message;
  }

  async parsePlanSpreadsheet(text: string): Promise<{ invalidRows: any[]; validRows: any[] } | null> {
    const lines = text.split('\n');
    if (!this.checkHeader(lines)) {
      this.invalidFileTypeMessage();
      return null;
    }

    const returnObject: { invalidRows: any[]; validRows: any[] } = { invalidRows: [], validRows: [] };

    // Parse all lines first
    const parsedLines = lines.slice(1).map((line, index) => this.parseLine(line, index + 1)).filter(Boolean);

    // Fetch worker and telecommunication data for all valid lines
    const workerRequests = parsedLines
      .filter((lineInfo) => lineInfo && !lineInfo.errorMessage && lineInfo.worker?.workerNumber)
      .map((lineInfo) => this.relocationService.getWorkerByWorkerNumber(lineInfo.worker.workerNumber, true));

    if (workerRequests.length > 0) {
      try {
        const workerResponses = await forkJoin(workerRequests).toPromise();
        
        if (workerResponses) {
          let responseIndex = 0;
          for (const lineInfo of parsedLines) {
            if (lineInfo && !lineInfo.errorMessage && lineInfo.worker?.workerNumber) {
              const workerResponse: any = workerResponses[responseIndex++];            if (workerResponse?.results?.[0]) {
              const worker = workerResponse.results[0];
              lineInfo.databaseWorker = worker;
              
              // Validate worker name
              const nameValidation = this.validateNameInfo(worker, lineInfo);
              if (nameValidation) {
                lineInfo.errorMessage = (lineInfo.errorMessage || '') + nameValidation;
              }
              
              // Validate and find telecommunication type              const telecomType = this.telecommunicationTypes.find(
                (type) => type.description?.toUpperCase() === lineInfo.type?.toUpperCase()
              );
              
              if (telecomType) {
                lineInfo.telecommunicationType = telecomType;              } else {                lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.invalidTelecommunicationType;
              }
            } else {
              lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.workerNumberInvalid;
            }
          }
          
          // Check for duplicates
          if (lineInfo?.worker && lineInfo.phoneNumber) {
            const workerMessage = this.checkDuplicateWorkerNumber(returnObject, lineInfo);
            if (workerMessage) {
              lineInfo.errorMessage = (lineInfo.errorMessage || '') + this.messages.workerDuplicate;
            }
          }
          
            this.pushPhoneNumberRows(returnObject, lineInfo);
          }
        }
      } catch (error) {        // Add all lines as invalid if worker fetch fails
        parsedLines.forEach((lineInfo) => {
          if (lineInfo) {
            lineInfo.errorMessage = (lineInfo.errorMessage || '') + 'Failed to validate worker information. ';
            returnObject.invalidRows.push(lineInfo);
          }
        });
      }
    } else {
      // No valid lines to process
      parsedLines.forEach((lineInfo) => {
        if (lineInfo) {
          this.pushPhoneNumberRows(returnObject, lineInfo);
        }
      });
    }

    return returnObject;
  }

  pushPhoneNumberRows(returnObject: { invalidRows: any[]; validRows: any[] }, lineInfo: any): void {
    if (lineInfo) {
      if (!lineInfo.errorMessage) {
        returnObject.validRows.push(lineInfo);
      } else {
        returnObject.invalidRows.push(lineInfo);
      }
    }
  }

  checkDuplicateWorkerNumber(
    parsedRows: { validRows: any[]; invalidRows: any[] },
    lineInfo: any
  ): string | null {
    if (!lineInfo.worker.workerNumber) return null;

    return (
      this.checkPhoneInfo(parsedRows.validRows, lineInfo) ||
      this.checkPhoneInfo(parsedRows.invalidRows, lineInfo)
    );
  }

  checkPhoneInfo(rows: any[], lineInfo: any): string | null {
    const numberPattern = /\d+/g;

    for (const planRow of rows) {
      if (planRow.phoneNumber) {
        const thisPhoneNumber = lineInfo.phoneNumber.match(numberPattern)?.join('') || '';
        const iterationPhoneNumber = planRow.phoneNumber.match(numberPattern)?.join('') || '';

        const isDuplicate =
          planRow.worker.workerNumber === lineInfo.worker.workerNumber &&
          planRow.type === lineInfo.type &&
          planRow.indicator === lineInfo.indicator &&
          iterationPhoneNumber === thisPhoneNumber;

        if (isDuplicate) {
          return this.messages.workerDuplicate;
        }
      }
    }

    return null;
  }

  validateNameInfo(worker: any, rowData: any): string {
    if (
      worker.familyName.trim().toUpperCase() !== rowData.worker.familyName.toUpperCase() ||
      worker.givenName.trim().toUpperCase() !== rowData.worker.givenName.toUpperCase()
    ) {
      return this.messages.workerNameMismatch;
    }
    return '';
  }

  parseHeader(line: string): string | null {
    const columns = line.split(',');

    const isInvalidHeader =
      columns[0] !== 'WORKER NUMBER' ||
      columns[1] !== 'LAST NAME' ||
      columns[2] !== 'FIRST NAME' ||
      columns[3] !== 'PHONE NUMBER' ||
      columns[4] !== 'INDICATOR (Primary or Alternate or Hidden)' ||
      columns[5] !== 'TYPE (See Application Reference - Communication Types)';

    return isInvalidHeader ? this.messages.formatInvalid : null;
  }

  parseLine(line: string, row: number): any | null {
    const columns = line.split(',').map((col) => col.toUpperCase().trim());
    if (columns.length < 6 || (columns.length === 1 && !columns[0])) return null;

    return {
      row: row + 1,
      worker: {
        givenName: columns[2],
        familyName: columns[1],
        workerNumber: columns[0],
      },
      phoneNumber: columns[3],
      indicator: columns[4],
      type: columns[5],
      errorMessage: this.validateDetails(
        columns[0],
        columns[1],
        columns[2],
        columns[3],
        columns[4],
        columns[5]
      ),
    };
  }

  validateDetails(
    workerNumber: string,
    lastName: string,
    firstName: string,
    phoneNumber: string,
    indicator: string,
    type: string
  ): string {
    const phoneNumberPattern = /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s]{0,1}[0-9]{3}[-\s]{0,1}[0-9]{4}$/;
    let message = '';
    message = this.addMessage(firstName, message, this.messages.firstNameMissing);
    message = this.addMessage(lastName, message, this.messages.lastNameMissing);
    message = this.addMessage(workerNumber, message, this.messages.workerNumberMissing);
    message = this.addMessage(phoneNumber, message, this.messages.phoneNumberMissing);
    if (phoneNumber && !phoneNumber.match(phoneNumberPattern)) {
      message += this.messages.phoneNumberInvalid;
    }
    message = this.addMessage(indicator, message, this.messages.phoneNumberIndicatorMissing);
    message = this.addMessage(type, message, this.messages.phoneNumberTypeMissing);
    return message;
  }

  addMessage(value: string, message: string, invalidMessage: string): string {
    return value ? message : message + invalidMessage;
  }
}
