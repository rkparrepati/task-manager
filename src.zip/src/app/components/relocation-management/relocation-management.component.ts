import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { RelocationService } from './relocation.service';
import { UtilityService } from 'src/app/services/utility.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AppService } from 'src/app/services/app.service';
import { RelocationDetailsComponent } from './relocation-details/relocation-details.component';
import { RelocationEditComponent } from './relocation-edit/relocation-edit.component';
import { RelocateWorkerGauImmediateComponent } from './relocate-worker-gau-immediate/relocate-worker-gau-immediate.component';
import { MatDialog } from '@angular/material/dialog';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-relocation-management',
  templateUrl: './relocation-management.component.html',
  styleUrls: ['./relocation-management.component.scss'],
})
export class RelocationManagementComponent implements OnInit {
  @ViewChild('relocationDetailsTemplate', { static: true })
  relocationDetailsTemplate!: TemplateRef<RelocationDetailsComponent>;
  @ViewChild('relocationEditTemplate', { static: true })
  relocationEditTemplate!: TemplateRef<RelocationEditComponent>;

  public rolesEnum = ROLES_ENUM;
  tools: any = [
    { name: 'Move Employee Location', id: '2' },
    { name: 'Relocate Worker GAU Queue', id: '3' },
    { name: 'Upload phone numbers', id: '4' },
    { name: 'Update Role Code', id: '1' },
    { name: 'Relocate Worker GAU', id: '5' },
  ];
  searchResults: any;
  relocationModel: any = {};
  invalidPlanName: boolean = false;
  invalidVisualLocationCode: boolean = false;
  effectiveDateErrorMessage: any;
  invalidRelocationEffectiveDate: boolean = false;
  returnCode: any = '';
  hideMessage: boolean = true;
  edit: any;
  returnMessage: string = '';
  accessDenied: any;
  effectiveDateHeader: string = 'Effective Date';
  planNameHeader: string = 'Plan Name';
  add: boolean = false;
  sortColumn: string = 'plannedStartDate';
  sortDirection: string = 'asc';
  relocations: any;
  planType: string = '';
  showGAUImportPage: boolean = false;
  viewName: string = '';
  moduleName: string = 'Relocation Management';
  appTitle: string = 'Relocation Management';
  moveEmployeeLocationPage: boolean = false;
  showPhoneNumbersImportPage: boolean = false;
  updateEmployeeRoleCodeFlag: boolean = false;
  selectedTool: string = '';
  gauWorkersList: any;
  gauWorkerModel: any;
  createdDate: Date = new Date();
  searchText: string = '';
  searchResultsMode: boolean = false;
  constructor(
    public relocationService: RelocationService,
    private utilityService: UtilityService,
    public appService: AppService,
    private dialog: MatDialog,
    private httpService: HttpService
  ) {
    this.getRelocationsList();
  }

  ngOnInit(): void {
    this.relocationService.updateHideMessage(true);
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });
  }
  getRelocationTemplate(relocation: any): string {
    const templates: any = {
      1: 'detailsRelocationRow',
      2: 'editRelocationRow',
      default: 'displayRelocationRow',
    };
    return templates[relocation.viewMode] || templates.default;
  }
  invalidateRelocationParameters(): boolean {
    let theRelocationInvalid = false;
    const theRelocation = this.relocationModel?.selectedRelocation;
    const errorMessages: string[] = [];

    if (theRelocation && Object.keys(theRelocation).length > 0) {
      if (!theRelocation.relocationPlanName) {
        this.invalidPlanName = true;
        theRelocationInvalid = true;
        errorMessages.push('Plan name is required');
      }
      if (!theRelocation.relocationPlanName) {
        this.invalidVisualLocationCode = true;
        theRelocationInvalid = true;
      } else {
        theRelocation.relocationPlanName = theRelocation.relocationPlanName.toUpperCase().trim();
      }

      this.effectiveDateErrorMessage = this.utilityService.validateBeginDate(
        theRelocation.plannedStartDate,
        true
      );

      if (this.effectiveDateErrorMessage !== null) {
        this.invalidRelocationEffectiveDate = true;
        theRelocationInvalid = true;
        errorMessages.push(this.effectiveDateErrorMessage);
      }
    }

    // If validation errors exist, emit them to the navbar
    if (errorMessages.length > 0) {
      this.relocationService.updateReturnCode(700);
      this.relocationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.relocationService.updateReturnMessageArray(errorMessages);
      this.relocationService.updateHideMessage(false);
    }

    return theRelocationInvalid;
  }

  saveRelocation(): void {
    if (!this.invalidateRelocationParameters()) {
      this.relocationService.saveRelocationPlan(this.relocationModel.selectedRelocation).subscribe({
        next: () => {
          const typeMessage = this.edit ? ' updated' : ' created';
          const successMessage = `${this.relocationModel.selectedRelocation.relocationPlanName}${typeMessage} successfully`;          // Send success message using the service pattern
          
          
          this.cancelRelocation();
          this.getRelocationsList();

          this.relocationService.updateReturnCode(200);
          this.relocationService.updateReturnMessage(successMessage);
          this.relocationService.updateReturnMessageArray([]);
          this.relocationService.updateHideMessage(false);
        },
        error: (response: any) => {
          // Handle error using the service pattern
          const errorMessages: string[] = [];
          let errorMessage = 'An error occurred';
          let statusCode = response?.status || 500;
          
          if (response?.error?.message) {
            errorMessage = response.error.message;
          } else if (response?.message) {
            errorMessage = response.message;
          } else if (typeof response === 'string') {
            errorMessage = response;
          }
          
          errorMessages.push(errorMessage);
          
          this.relocationService.updateReturnCode(statusCode);
          this.relocationService.updateReturnMessage('An error occurred. Please review the errors below.');
          this.relocationService.updateReturnMessageArray(errorMessages);
          this.relocationService.updateHideMessage(false);
          
          this.accessDenied = response.accessDenied;
        },
      });
    }
  }
  cancelRelocation(): void {
    this.planNameHeader = 'Plan name';
    this.effectiveDateHeader = 'Effective date';
    this.cancelAllInvalidates();
    this.edit = false;
    this.add = false;

    // Only clear validation error messages (returnCode 700), not success messages
    if (this.returnCode === '700' || this.returnCode === 700) {
      this.relocationService.updateReturnMessageArray([]);
      this.relocationService.updateHideMessage(true);
    }

    this.relocationModel.relocations.forEach((relocation: any) => {
      relocation.viewMode = 0;
    });
  }
  cancelAllInvalidates() {
    this.invalidRelocationEffectiveDate = false;
    this.invalidPlanName = false;
    
    // Clear validation messages when canceling invalidations
    this.relocationService.updateReturnMessageArray([]);
    this.relocationService.updateHideMessage(true);
  }
  getRelocationsList() {
    if (!this.add && !this.edit) {
      this.relocationService.getRelocations(this.sortColumn, this.sortDirection).subscribe({
        next: (responseGetRelocations: any) => {
          this.createRelocations(responseGetRelocations);
        },
        error: (responseGetRelocations: any) => {
          this.returnCode = responseGetRelocations.status;
          this.accessDenied = responseGetRelocations.accessDenied;
          if (this.returnCode !== 404) {
            this.hideMessage = false;
          }
        },
      });
    }
  }
  createRelocations(relocations: any) {
    if (relocations) {
      this.relocations = relocations.results;
      this.planType = 'Worker';
    } else {
      this.relocations = [];
    }

    this.relocationModel = {
      relocations: JSON.parse(JSON.stringify(this.relocations)),
    };
  }

  showGAUImport(): void {
    this.viewName = 'relocationImport';
    this.moduleName = 'Import and Execute Employee Organization Relocation';
    this.appTitle = 'Import and Execute Employee Organization Relocation';

    if (this.selectedTool === '3') {
      this.relocationModel.basicSearchText = '';
      this.appService.changePage('/app/relocate-employee-gau-queue');
      return;
    }
    const dialogRef = this.dialog.open(RelocateWorkerGauImmediateComponent, {
      width: '30vw',
      height: '25vh',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        this.appService.changePage('/app/relocate-employee-gau');
      } else {
        this.selectedTool = '';
      }
    });
  }
  getGauQueueList(): void {
    this.relocationService.getGAUQueueDetails(this.sortColumn, this.sortDirection).subscribe({
      next: (response: any) => {
        this.createGauWorkersList(response);
        this.relocationModel.total = response.meta.total;
      },
      error: (response: any) => {
        this.returnCode = response.status;
        this.accessDenied = response.accessDenied;
        if (this.returnCode !== 404) {
          this.hideMessage = false;
        }
      },
    });
  }
  getBiweeklyDates(): void {
    this.relocationService.getDateInfo().subscribe({
      next: (response: any) => {        const payPeriodData = response?.response[0].payPeriodData;
        const biweeklyDateInfo: string[] = [];

        payPeriodData.forEach((biweekdate: any) => {
          biweeklyDateInfo.push(
            this.utilityService.formatDate(new Date(biweekdate.payPeriodEndDate), 'MMddyyyy')
          );
        });
      },
      error: (response: any) => {
        this.returnCode = response.status;
        this.accessDenied = response.accessDenied;
        if (this.returnCode !== 404) {
          this.hideMessage = false;
          this.returnMessage = this.utilityService.processFailureMessage(
            response,
            'Problem retrieving relocation plan'
          );
        }
      },
    });
  }

  exitImport(): void {
    this.moduleName = 'Relocation Management';
    this.appTitle = 'Relocation Management';
    this.viewName = '';
    this.showGAUImportPage = false;
    this.moveEmployeeLocationPage = false;
    this.showPhoneNumbersImportPage = false;
    this.updateEmployeeRoleCodeFlag = false;
    this.selectedTool = '';
  }
  createGauWorkersList(gauWorkerList: any): void {
    if (gauWorkerList) {
      this.gauWorkersList = gauWorkerList.results || [];
    } else {
      this.gauWorkersList = [];
    }

    this.gauWorkerModel = {
      gauWorkers: JSON.parse(JSON.stringify(this.gauWorkersList)),
    };
  }

  createNewRelocationPlan() {
    this.add = true;
    this.planNameHeader = 'Plan name *';
    this.effectiveDateHeader = 'Effective date *';
    this.createdDate = new Date();
    this.relocationModel.selectedRelocation = {
      plannedStartDate: new Date().toISOString(),
      lifecycle: {
        beginDate: new Date().toISOString(),
      },
      planName: '',
      purposeText: '',
    };
  }

  showEmployeeLocation() {
    this.viewName = 'relocationImport';
    this.moduleName = 'Import and Execute Employee Location';
    this.moveEmployeeLocationPage = true;
    this.appTitle = 'Import and Execute Employee Location';

    this.appService.changePage('/app/relocate-employee-location');
  }

  search() {
    const matchedRelocations: any = [];
    const searchTextLower = (this.searchText || '').toLowerCase();
    matchedRelocations.push(
      ...this.relocations.filter((relocation: any) =>
        relocation.relocationPlanName.toLowerCase().includes(searchTextLower)
      )
    );
    if (matchedRelocations.length > 0) {
      this.relocationModel.relocations = matchedRelocations;
      this.searchResults = matchedRelocations.length + ' plans found with name ' + this.searchText;
    } else {
      this.searchResults = 'No relocation plans found containing ' + this.searchText;
    }

    this.searchResultsMode = true;
  }

  clearSearchResults() {
    this.searchText = '';
    this.searchResultsMode = false;
    this.relocationModel.relocations = this.relocations;
  }
  searchKeyEvent(event: any) {
    if (event.key === 'Enter') {
      this.search();
    }
  }

  showUpdateRoleCode() {
    this.viewName = 'relocationImport';
    this.moduleName = 'Import and Execute Employee Role Code';
    this.updateEmployeeRoleCodeFlag = true;
    this.appTitle = 'Import and Execute Employee Role Code';
    this.appService.changePage('/app/import-role-code');
  }
  selectToolsById() {
    if (this.selectedTool == '1') {
      this.showUpdateRoleCode();
    } else if (this.selectedTool == '2') {
      this.showEmployeeLocation();
    } else if (this.selectedTool == '3') {
      this.showGAUImport();
    } else if (this.selectedTool == '4') {
      this.showPhoneNumbersImport();
    } else if (
      this.selectedTool == '5' &&
      this.appService.checkRoleExists(ROLES_ENUM.INFRA_ADMIN)
    ) {
      this.gauMoveDialog();
    }
  }

  gauMoveDialog() {
    // ngDialog.openConfirm({
    //     template : 'app/relocation/dialog/relocationGAUMoveConfirmDialog.html',
    //     controller : 'RelocationController',
    //     controllerAs : 'vm',
    //     className : 'ngdialog-theme-default'
    // }).then(function() {
    this.showGAUImport();
    // }, function() {
    //     // dialog closed or canceled
    // });
  }
  showPhoneNumbersImport() {
    this.viewName = 'relocationImport';
    this.moduleName = 'Import and assign phone numbers';
    this.showPhoneNumbersImportPage = true;
    this.appTitle = 'Import and assign phone numbers';
    this.appService.changePage('/app/import-phone-numbers');
  }
  exportDataCallback(): void {
    // Build URL with query parameters - matching building and location management component format
    let url = `/relocation-plans/excelReport?`;
    url += this.sortColumn ? 'sortColumn=' + this.sortColumn : '';
    url += this.sortDirection ? '&sortOrder=' + this.sortDirection : '&sortOrder=asc';
    
    const fileName = 'RelocationPlans.xls';

    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';

          // Append to body to ensure it works in Firefox
          document.body.appendChild(a);
          a.click();

          // Clean up
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
        }

        
      },
      error: (error: any) => {      }
    });
  }
  editRelocation(relocation: any) {
    if (
      this.edit ||
      this.add ||
      !this.appService.hasAnyRole([
        this.rolesEnum.INFRA_ADMIN,
        this.rolesEnum.INFRA_RELOCATION_ADMIN,
        this.rolesEnum.INFRA_RELOCATION_PLANNER,
      ])
    ) {
      return;
    } else {
      if (relocation) {
        this.planNameHeader = 'Plan name *';
        this.effectiveDateHeader = 'Effective date *';
        this.relocationModel.selectedRelocation = JSON.parse(JSON.stringify(relocation));
        relocation.viewMode = 2;
        this.edit = true;
      } else {
        this.createNewRelocationPlan();
      }

      this.hideMessage = true;
    }
  }
  resetRelocation(relocation: any) {
    this.returnMessage = '';
    this.returnCode = '';
    if (!this.add) {
      this.relocationModel.selectedRelocation = JSON.parse(JSON.stringify(relocation));
    } else {
      this.createNewRelocationPlan();
    }
    this.cancelAllInvalidates();
  }
  generateReport(relocation: any) {}
  relocationPlanDetails(plan: any) {
    this.relocationService.selectedPlan = plan;
    this.appService.changePage('/app/relocation-plan-details/' + plan.relocationPlanId);
  }
  setshowMode(relocation: any) {
    this.relocationModel.selectedRelocation = {};

    this.relocationModel.selectedRelocation = JSON.parse(JSON.stringify(relocation));
    this.planNameHeader = 'Plan name';
    this.effectiveDateHeader = 'Effective date';
    this.cancelAllInvalidates();
    relocation.viewMode = 1;
  }

  setViewMode(relocation: any) {
    this.relocationModel.selectedRelocation = {};
    this.relocationModel.selectedRelocation = JSON.parse(JSON.stringify(relocation));
    this.planNameHeader = 'Plan name';
    this.effectiveDateHeader = 'Effective date';
    this.cancelAllInvalidates();
    relocation.viewMode = 0;
  }
  
  resort(event: any): void {
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;
    this.getRelocationsList();
  }

  onDateChanged(newDate: any): void {
    if (newDate) {
      this.relocationModel.selectedRelocation.plannedStartDate = newDate;
    }
  }

  getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  onEditDateChanged(newDate: any): void {
    if (newDate) {
      this.relocationModel.selectedRelocation.plannedStartDate = newDate;
    }
  }

  onRelocationDeleted(): void {
    // Refresh the relocation list after successful deletion
    // The success message is already set by the child component
    this.getRelocationsList();
  }
}
