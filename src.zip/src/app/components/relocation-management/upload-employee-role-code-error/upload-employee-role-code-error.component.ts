import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-upload-employee-role-code-error',
  templateUrl: './upload-employee-role-code-error.component.html',
  styleUrls: ['./upload-employee-role-code-error.component.scss'],
})
export class UploadEmployeeRoleCodeErrorComponent {
  modalData: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<UploadEmployeeRoleCodeErrorComponent>) {}

  confirm(message: any = 'continue') {
    this.dialogRef.close(message);
  }

  cancel(message: any = 'cancelled') {
    this.dialogRef.close(message);
  }
}
