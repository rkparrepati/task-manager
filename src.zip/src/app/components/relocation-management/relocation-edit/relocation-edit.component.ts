import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-relocation-edit',
  templateUrl: './relocation-edit.component.html',
  styleUrls: ['./relocation-edit.component.scss'],
})
export class RelocationEditComponent {
  private _relocation: any;
  @Input()
  set relocation(value: any) {
    value.planType = 'Worker';
    this._relocation = value;
  }
  get relocation(): any {
    return this._relocation;
  }
}
