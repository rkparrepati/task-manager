export interface EditedLocation {
  workerAssignmentPlanId?: string;
  to: {
    lifecycle?: {
      beginDate?: string;
    };
    communication?: {
      telephoneNo?: string;
      telecomAddressType?: {
        id: string;
      };
      primaryIndicator?: boolean;
    };
  };
  worker: {
    familyName: string;
    givenName: string;
  };
}

export interface ResponseMessage {
  data: {
    message: string;
  };
  status: string;
  accessDenied: boolean;
}
