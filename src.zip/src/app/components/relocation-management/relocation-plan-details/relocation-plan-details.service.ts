import { Injectable } from '@angular/core';
import { Observable, throwError, forkJoin } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { RelocationService } from '../relocation.service';

@Injectable({
  providedIn: 'root',
})
export class RelocationPlanDetailsService {
  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService,
    private relocationService: RelocationService
  ) {}

  executePlan(relocationPlanDetails: any[]): Observable<any> {
    if (!relocationPlanDetails || relocationPlanDetails.length === 0) {
      return throwError(() => ({
        data: { message: 'No Relocation plan details were passed' },
      }));
    }

    const saveDetails = relocationPlanDetails.map((detail) => detail.workerAssignmentPlanId);

    return this.httpService
      .post(
        `/relocation-plans/${relocationPlanDetails[0].relocationPlan.relocationPlanId}/execute`,
        saveDetails
      )
      .pipe(
        tap(() => {
          // Emit success message
          const count = relocationPlanDetails.length;
          const msg = count > 1
            ? `${count} workers have been moved successfully`
            : `${count} worker has been moved successfully`;
          this.relocationService.updateReturnCode(200);
          this.relocationService.updateReturnMessage(msg);
          this.relocationService.updateReturnMessageArray([]);
          this.relocationService.updateHideMessage(false);
        }),
        map((response: any) => response.data),
        catchError((response: any) => {
          let responseMsg = 'Failed to execute plan';
          if (response.data && response.data.message) {
            responseMsg = response.data.message;
          }
          response.message = `Relocation Plan execute failed.  Message=${responseMsg}`;
          
          // Emit error message
          this.relocationService.updateReturnCode(response?.status || 500);
          this.relocationService.updateReturnMessage('Execution Failed!');
          this.relocationService.updateReturnMessageArray([response.message]);
          this.relocationService.updateHideMessage(false);
          
          return throwError(() => response);
        })
      );
  }

  deleteDetailsList(planDetailsLists: any[]): Observable<any> {
    if (!planDetailsLists || planDetailsLists.length === 0) {
      return throwError(() => 'No plan details provided');
    }
    const detailList = planDetailsLists.map((planDetail) => planDetail.workerAssignmentPlanId);
    const relocationPlanId = planDetailsLists[0].relocationPlan.relocationPlanId;

    return forkJoin([
      this.httpService.post(`/relocation-plans/${relocationPlanId}/deleteAll`, detailList),
    ]).pipe(
      tap(() => {
        // Emit success message
        this.relocationService.updateReturnCode(200);
        this.relocationService.updateReturnMessage('All workers removed from plan');
        this.relocationService.updateReturnMessageArray([]);
        this.relocationService.updateHideMessage(false);
      }),
      catchError((response: any) => {        if (response && response.data) {        }
        
        // Emit error message
        this.relocationService.updateReturnCode(response?.status || 500);
        this.relocationService.updateReturnMessage('Delete Failed!');
        this.relocationService.updateReturnMessageArray(['Problem occurred while removing all workers from relocation plan']);
        this.relocationService.updateHideMessage(false);
        
        return throwError(() => 'Problem removing details from plan');
      })
    );
  }

  deleteDetail(planDetail: any): Observable<any> {
    return this.httpService
      .delete(`/workerAssignmentPlans/${planDetail.workerAssignmentPlanId}`)
      .pipe(
        tap(() => {
          // Emit success message
          const workerName = `${planDetail.worker.familyName}, ${planDetail.worker.givenName}`;
          this.relocationService.updateReturnCode(200);
          this.relocationService.updateReturnMessage(`${workerName} removed from relocation plan`);
          this.relocationService.updateReturnMessageArray([]);
          this.relocationService.updateHideMessage(false);
        }),
        map((response: any) => {
          // Handle response - it might be the data directly or wrapped in a data property
          return response?.data || response;
        }),
        catchError((error: any) => {
          // Emit error message
          const workerName = `${planDetail.worker.familyName}, ${planDetail.worker.givenName}`;
          const errorMessage = error?.error?.message || error?.message ||
            `Problem occurred with removing ${workerName} from relocation plan`;
          
          this.relocationService.updateReturnCode(error?.status || 400);
          this.relocationService.updateReturnMessage(errorMessage);
          this.relocationService.updateReturnMessageArray([]);
          this.relocationService.updateHideMessage(false);
          return throwError(() => error);
        })
      );
  }

  saveRelocationPlanDetail(relocationPlanDetail: any): Observable<any> {
    return this.httpService
      .put(
        `/workerAssignmentPlans/${relocationPlanDetail.workerAssignmentPlanId}`,
        relocationPlanDetail
      )
      .pipe(
        tap(() => {
          // Emit success message
          this.relocationService.updateReturnCode(200);
          this.relocationService.updateReturnMessage(`Relocation plan detail saved successfully`);
          this.relocationService.updateReturnMessageArray([]);
          this.relocationService.updateHideMessage(false);
        }),
        map((response: any) => response.data),
        catchError((response: any) => {
          let errorMessage = '';
          if (response.status && response.status === 409) {
            errorMessage = `Relocation plan ${relocationPlanDetail.relocationPlan.relocationPlanName} detail has been changed by another user. Please refresh Relocation mangement screen`;
            response.data = { message: errorMessage };
          } else {
            errorMessage = `Relocation plan ${relocationPlanDetail.relocationPlan.relocationPlanName} failed to save`;
            response.data = { message: errorMessage };
          }
          
          // Emit error message
          this.relocationService.updateReturnCode(response?.status || 500);
          this.relocationService.updateReturnMessage('Save Failed!');
          this.relocationService.updateReturnMessageArray([errorMessage]);
          this.relocationService.updateHideMessage(false);
          
          return throwError(() => response);
        })
      );
  }

  addPlanDetails(relocationPlanDetails: any[]): Observable<any> {
    if (!relocationPlanDetails || relocationPlanDetails.length === 0) {
      return throwError(() => 'No Relocation plan details were passed');
    }    const saveDetails = relocationPlanDetails.map((detail) => this.createPlanDetail(detail));
    const url = `/relocation-plans/${relocationPlanDetails[0].relocationPlan.relocationPlanId}/save`;

    return this.httpService.post(url, saveDetails).pipe(
      tap(() => {
        // Emit success message
        const count = relocationPlanDetails.length;
        const msg = count > 1
          ? `${count} plan details added successfully`
          : `${count} plan detail added successfully`;
        this.relocationService.updateReturnCode(200);
        this.relocationService.updateReturnMessage(msg);
        this.relocationService.updateReturnMessageArray([]);
        this.relocationService.updateHideMessage(false);
      }),
      map((response: any) => response.data),
      catchError((response: any) => {
        const errorMessage = `Relocation plan ${relocationPlanDetails[0].relocationPlan.relocationPlanName} detail failed to save`;
        response.data = { message: errorMessage };
        
        // Emit error message
        this.relocationService.updateReturnCode(response?.status || 500);
        this.relocationService.updateReturnMessage('Add Failed!');
        this.relocationService.updateReturnMessageArray([errorMessage]);
        this.relocationService.updateHideMessage(false);
        
        return throwError(() => response);
      })
    );
  }

  createPlanDetail(relocationPlanDetail: any): any {
    let organizationId = null;
    if (relocationPlanDetail.to.workerOrganization.organization.organizationId) {
      organizationId = relocationPlanDetail.to.workerOrganization.organization.organizationId;
    } else if (relocationPlanDetail.to.workerOrganization.organization.id) {
      organizationId = relocationPlanDetail.to.workerOrganization.organization.id;
    }
    let beginDate = relocationPlanDetail.to.lifecycle.beginDate;
    if (!beginDate) {
      beginDate = this.utilityService.getTimeNow();
    }

    // Convert date to ISO format if it's in MM/DD/YYYY format
    // Expected format: "2026-04-02T15:49:59" (ISO)
    // Current format might be: "04/02/2026T15:53:36" (MM/DD/YYYY)
    if (beginDate && typeof beginDate === 'string' && beginDate.includes('/')) {
      // Parse MM/DD/YYYYTHH:mm:ss format and convert to ISO
      const parts = beginDate.split('T');
      if (parts.length === 2) {
        const datePart = parts[0]; // "04/02/2026"
        const timePart = parts[1]; // "15:53:36"
        const dateComponents = datePart.split('/'); // ["04", "02", "2026"]
        if (dateComponents.length === 3) {
          // Convert to ISO format: YYYY-MM-DDTHH:mm:ss
          beginDate = `${dateComponents[2]}-${dateComponents[0]}-${dateComponents[1]}T${timePart}`;
        }
      }
    }

    // Handle workerAssignmentId - convert to number and validate
    let workerAssignmentId = relocationPlanDetail.from.workerAssignmentId;
    
    // Convert string to number if needed
    if (typeof workerAssignmentId === 'string') {
      workerAssignmentId = parseInt(workerAssignmentId, 10);
    }
    
    // Build the from object - only include workerAssignmentId if it's valid (not 0, null, undefined, or NaN)
    const fromObj: any = {};
    if (workerAssignmentId && !isNaN(workerAssignmentId) && workerAssignmentId !== 0) {
      fromObj.workerAssignmentId = workerAssignmentId;
    }

    const createObj: any = {
      relocationPlan: {
        relocationPlanId: relocationPlanDetail.relocationPlan.relocationPlanId,
      },
      worker: {
        workerId: relocationPlanDetail.worker.workerId,
      },
      from: fromObj,
      to: {
        primaryLocationIndicator: true,
        workerOrganization: {
          organization: {
            id: organizationId,
          },
        },
        assignmentLocation: {
          locationId: relocationPlanDetail.to.assignmentLocation.locationId,
        },
        lifecycle: {
          beginDate: beginDate,
        },
      },
    };

    if (
      relocationPlanDetail.to.communication &&
      relocationPlanDetail.to.communication.telephoneNo
    ) {
      // Ensure telecomAddressType.id is a number
      const communication = { ...relocationPlanDetail.to.communication };
      if (communication.telecomAddressType && communication.telecomAddressType.id) {
        if (typeof communication.telecomAddressType.id === 'string') {
          communication.telecomAddressType.id = parseInt(communication.telecomAddressType.id, 10);
        }
      }
      createObj.to.communication = communication;
    }

    return createObj;
  }

  /**
   * This method is to download worker spread sheet using POST method
   */
  getWorkerSpreadsheet(
    url: string,
    fileName: string,
    fileType: string,
    isInfraURL: boolean,
    payload: any
  ): void {
    this.httpService.post(url, payload).subscribe({
      next: (response: any) => {
        const data = response.data;
        if ((window as any).MSBlobBuilder) {
          const blob = new Blob([data], { type: fileType });
          (window.navigator as any).msSaveBlob(blob, fileName);
        } else {
          const blobUrl = URL.createObjectURL(new Blob([data]));
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';
          a.click();
        }
      },
      error: () => {},
    });
  }
}
