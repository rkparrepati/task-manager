import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AppService } from 'src/app/services/app.service';
import { RelocationService } from '../relocation.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';
import { UtilityService } from 'src/app/services/utility.service';
import { RelocationPlanDetailsService } from './relocation-plan-details.service';
import { WorkerService } from '../worker.service';
import { AddWorkerWizardDialogComponent } from '../add-worker-wizard-dialog/add-worker-wizard-dialog.component';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { LocationselectDialogComponent } from '../../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-relocation-plan-details',
  templateUrl: './relocation-plan-details.component.html',
  styleUrls: ['./relocation-plan-details.component.scss'],
})
export class RelocationPlanDetailsComponent implements OnInit {
  @ViewChild('executeMoveDialogTemplate', { static: true }) executeMoveDialogTemplate!: TemplateRef<any>;
  @ViewChild('relocationRowsTemplate', { static: true }) relocationRowsTemplate!: TemplateRef<any>;
  
  plannedLocationValue: string = '';
  detailsToDelete: any;
  
  // Navbar properties
  main = { creationDate: new Date() };
  moduleName: string = 'Relocation Plan Details';
  appTitle: string = 'Relocation Plan Details';
  returnCode: string | number | null = null;
  hideMessage: boolean = true;
  returnMessage: string = '';
  
  // Search and filter properties
  showAdvancedSearch: boolean = false;
  basicSearch: string = '';
  searchText: string = '';
  basicFilterDropDownList: string[] = [
    'Move date',
    'Acronym',
    'First name',
    'Last name',
    'Worker #',
 
  ];
  
  // Advanced search options
  advanceSearchOptions: any = {
    acronym: '',
    moveDate: null,
    firstNameSearch: '',
    lastNameSearch: '',
    jobClassSearch: '',
    currentBldgSearch: '',
    currentFloorSearch: '',
    currentCorSearch: '',
    plannedBldgSearch: '',
    plannedFloorSearch: '',
    plannedCorSearch: ''
  };
  
  beginDateInvalid: boolean = false;
  jobClassCodes: any[] = [];
  
  // Import properties
  importFile: any = null;
  relocationSpreadsheet: string = '';
  showWait: boolean = false;
  loadingMessage: string = '';
  
  // Total results
  total: number = 0;

  constructor(
    public appService: AppService,
    public relocationService: RelocationService,
    private relocationPlanDetailsService: RelocationPlanDetailsService,
    private utilityService: UtilityService,
    private workerService: WorkerService,
    private dialog: MatDialog,
    private organizationService: OrganizationService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  public rolesEnum = ROLES_ENUM;
  relocationDetailsList: any = [];
  add: boolean = false;
  edit: boolean = false;
  totalRecords: number = 0;
  sortTypeObject: any = {};
  selectedRelocation: any;
  telephoneNumberInvalid: boolean = false;
  planDetailInvalid: boolean = false;
  moveDateInvalid: boolean = false;
  editedLocation: any;
  editedAcronym: string = '';
  userRoles: any;
  collapsedMode: boolean = false;
  selectedAll: boolean = false;
  workerResults: any[] = [];
  locationResults: any[] = [];
  teleComId: string = '';
  tempRelocationDetailsList: any[] = [];
  
  ngOnInit(): void {
    this.selectedRelocation = this.relocationService.selectedPlan;
    this.appTitle = `Relocation Plan Details - ${this.selectedRelocation?.relocationPlanName || ''}`;
    this.userRoles = this.appService.getUserRoles();
    // Check if route includes 'import' to set moduleName
    this.route.url.subscribe(urlSegments => {
      const hasImport = urlSegments.some(segment => segment.path === 'import');
      if (hasImport) {
        this.moduleName = 'Import';
        this.appTitle = this.selectedRelocation.relocationPlanName + ' - Import Details';
      }
    });
    
    this.getRelocationPlanDetails(this.relocationService.selectedPlan, 10, 0);
    this.sortTypeObject = this.getSortTypeObject(0);
    this.loadJobClassCodes();
    this.loadTelecomTypes();
    
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });
  }
  
  // Exit functionality
  exit(): void {
    this.appService.changePage('/app/relocation');
  }
  
  // Search functionality
  searchParamChanged(): void {
    this.searchText = '';
  }
  
  basicSearchKeyEventHandler(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.advanceFilterTheList(false);
    }
  }
  
  advancedSearchKeyEventHandler(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.advanceFilterTheList(true);
    }
  }

  advancedSearchAcronymChange(acronymData: any): void {
    // Simply store the acronym string, matching the basic search pattern
    this.advanceSearchOptions.acronym = acronymData || '';
  }
  
  advanceFilterTheList(isAdvanced: boolean): void {
    let isRowFiltered: boolean;
    let acronymSearch: string | null = null;
    let moveDtSearch: string | null = null;
    let workerGivenNm: string | null = null;
    let workerLastNm: string | null = null;
    let jobClassSearch: string | null = null;
    let currentBldgSearch: string | null = null;
    let currentFloorSearch: string | null = null;
    let currentCorSearch: string | null = null;
    let plannedBldgSearch: string | null = null;
    let plannedFloorSearch: string | null = null;
    let plannedCorSearch: string | null = null;
    let idSearch: string | null = null;

    // Check if temp list needs to be initialized
    if (this.tempRelocationDetailsList.length === 0) {
      this.tempRelocationDetailsList = [...this.relocationDetailsList];
    }

    this.relocationDetailsList = [];
    const filteredList: any[] = [];

    if (isAdvanced) {
      // Use the acronym string directly, just like basic search
      // Convert empty strings to null so they're not treated as search criteria
      acronymSearch = this.advanceSearchOptions.acronym || null;
      moveDtSearch = this.advanceSearchOptions.moveDate || null;
      workerGivenNm = this.advanceSearchOptions.firstNameSearch || null;
      workerLastNm = this.advanceSearchOptions.lastNameSearch || null;
      jobClassSearch = this.advanceSearchOptions.jobClassSearch || null;
      currentBldgSearch = this.advanceSearchOptions.currentBldgSearch || null;
      currentFloorSearch = this.advanceSearchOptions.currentFloorSearch || null;
      currentCorSearch = this.advanceSearchOptions.currentCorSearch || null;
      plannedBldgSearch = this.advanceSearchOptions.plannedBldgSearch || null;
      plannedFloorSearch = this.advanceSearchOptions.plannedFloorSearch || null;
      plannedCorSearch = this.advanceSearchOptions.plannedCorSearch || null;
    } else {
      acronymSearch = this.getSearchText('Acronym');
      moveDtSearch = this.getSearchText('Move date');
      workerGivenNm = this.getSearchText('First name');
      workerLastNm = this.getSearchText('Last name');
      jobClassSearch = this.getSearchText('Job class');
      currentBldgSearch = this.getSearchText('Current Location');
      plannedBldgSearch = this.getSearchText('Planned Location');
      idSearch = this.getSearchText('Worker number');
    }
    let matchCount = 0;
    
    this.tempRelocationDetailsList.forEach((value: any, index: number) => {
      isRowFiltered = false;

      if (acronymSearch && value.to && value.to.workerOrganization) {
        const workerOrg = value.to.workerOrganization.organization.businessAreaCode + '/' +
          value.to.workerOrganization.organization.shortName;
        isRowFiltered = workerOrg !== acronymSearch;
        
        // Log first few comparisons
        if (index < 3) {
        }
      }

      if (!isRowFiltered && moveDtSearch) {
        // Parse both dates - use UTC components to avoid timezone issues
        const valueDate = new Date(value.to.lifecycle.beginDate);
        const compareDate = new Date(moveDtSearch);
        
        // Use UTC date components for comparison since database stores in UTC
        const valueYear = valueDate.getUTCFullYear();
        const valueMonth = valueDate.getUTCMonth();
        const valueDay = valueDate.getUTCDate();
        
        const compareYear = compareDate.getUTCFullYear();
        const compareMonth = compareDate.getUTCMonth();
        const compareDay = compareDate.getUTCDate();
        
        // Debug: Log first comparison
        if (this.tempRelocationDetailsList.indexOf(value) === 0) {
        }
        
        // Compare year, month, and day separately using UTC components
        isRowFiltered = !(valueYear === compareYear && valueMonth === compareMonth && valueDay === compareDay);
      }

      const beforeOtherFilters = isRowFiltered;
      
      isRowFiltered = this.checkLikeSearchRowFilters(isRowFiltered, workerGivenNm, value.worker.givenName);
      isRowFiltered = this.checkLikeSearchRowFilters(isRowFiltered, workerLastNm, value.worker.familyName);
      isRowFiltered = this.checkIsRowFilters(isRowFiltered, idSearch, value.worker.workerNumber);
      isRowFiltered = this.checkIsRowFilters(isRowFiltered, jobClassSearch, value.jobClassCode);

      const hasLocation = value.location && value.location.building;
      if (hasLocation) {
        isRowFiltered = this.checkIsRowFilters(isRowFiltered, currentBldgSearch, value.location.building.code);
        isRowFiltered = this.checkIsRowFilters(isRowFiltered, currentFloorSearch, value.location.building.floorNumber);
        isRowFiltered = this.checkIsRowFilters(isRowFiltered, currentCorSearch, value.location.corridorId);
      }

      isRowFiltered = this.checkIsRowFilters(isRowFiltered, plannedBldgSearch, value.to.assignmentLocation.building.code);
      isRowFiltered = this.checkIsRowFilters(isRowFiltered, plannedFloorSearch, value.to.assignmentLocation.building.floorNumber);
      isRowFiltered = this.checkIsRowFilters(isRowFiltered, plannedCorSearch, value.to.assignmentLocation.corridorId);

      // Debug logging for first few rows
      if (index < 3 && !beforeOtherFilters && isRowFiltered) {
      }

      if (!isRowFiltered) {
        filteredList.push(value);
        matchCount++;
      }
    });
    this.relocationDetailsList = filteredList;
    this.total = filteredList.length;
  }

  private getSearchText(value: string): string | null {
    if (value.toLowerCase() === this.basicSearch.toLowerCase()) {
      if (value.toLowerCase() === 'move date' && this.searchText) {
        // The date-picker emits dates in ISO format (yyyy-MM-ddTHH:mm:ss)
        // We need to return it as-is for proper date comparison
        return this.searchText;
      }
      return this.searchText;
    }
    return null;
  }

  private checkIsRowFilters(isRowFiltered: boolean, value1: string | null, value2: any): boolean {
    if (isRowFiltered) {
      return true;
    }
    return value1 !== null && value2 !== value1;
  }

  private checkLikeSearchRowFilters(isRowFiltered: boolean, value1: string | null, value2: string): boolean {
    if (isRowFiltered) {
      return true;
    }
    if (value1 !== null && value2) {
      return value2.toUpperCase().indexOf(value1.toUpperCase()) < 0;
    }
    return false;
  }
  
  clearSearchResults(): void {
    this.searchText = '';
    this.basicSearch = '';
    this.relocationDetailsList = [...this.tempRelocationDetailsList];
    this.total = this.tempRelocationDetailsList.length;
  }
  
  clearAdvanceFilter(): void {
    this.advanceSearchOptions = {
      acronym: '',
      moveDate: null,
      firstNameSearch: '',
      lastNameSearch: '',
      jobClassSearch: '',
      currentBldgSearch: '',
      currentFloorSearch: '',
      currentCorSearch: '',
      plannedBldgSearch: '',
      plannedFloorSearch: '',
      plannedCorSearch: ''
    };
    this.relocationDetailsList = [...this.tempRelocationDetailsList];
    this.total = this.tempRelocationDetailsList.length;
  }
  
  toggleShowAdvSearch(): void {
    this.showAdvancedSearch = !this.showAdvancedSearch;
    // Clear advanced search inputs when closing the panel
    if (!this.showAdvancedSearch) {
      this.clearAdvanceFilter();
    }
  }
  
  // Download template
  downloadTemplate(): void {
    this.relocationService.downloadTemplate('RelocationMassUploadTemplate.csv');
  }
  
  // Import functionality
  sendFile(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.importFile = file;
    }
  }
  
  importTheFile(): void {
    if (!this.importFile) {
      return;
    }

    // Check file extension
    const fileName = this.importFile.name;
    const suffix = fileName.substring(fileName.length - 4, fileName.length);
    if (suffix !== '.csv') {
      this.relocationService.updateReturnCode(400);
      this.relocationService.updateReturnMessage('Invalid file type. Please upload a CSV file.');
      this.relocationService.updateHideMessage(false);
      return;
    }

    // Show loading state
    this.loadingMessage = 'Importing data...';
    this.showWait = true;

    const reader = new FileReader();
    reader.onload = (e: any) => {
      const text = e.target.result;
      const parsedObject = this.parsePlanSpreadsheet(text);
      
      if (!parsedObject) {
        this.showWait = false;
        return;
      }

      const errors = parsedObject.errorMessages || [];

      // Validate the spreadsheet
      this.validateSpreadSheet(parsedObject.validRows).then(
        (validatedObject: any) => {
          if (errors.length > 0) {
            validatedObject.errorMessages = [...validatedObject.errorMessages, ...errors];
          }
          if (validatedObject.errorMessages.length > 0) {
            this.showImportRelocationDialogFailure(validatedObject);
            // Don't set showWait to false here - let the dialog callback handle it
          } else {
            this.saveTheValidDetails(validatedObject);
          }
        },
        (error) => {
          this.showWait = false;
        }
      );
    };

    reader.onerror = () => {
      this.relocationService.updateReturnCode(500);
      this.relocationService.updateReturnMessage('Error reading file');
      this.relocationService.updateHideMessage(false);
      this.showWait = false;
    };

    reader.readAsText(this.importFile);
    this.moduleName = 'Relocation Management';
  }

  parsePlanSpreadsheet(text: string): any {
    const lines = text.split('\n');
    let dataRow = 0;
    const returnObject: any = {
      errorMessages: [],
      validRows: []
    };

    lines.forEach((line) => {
      if (dataRow > 0) {
        const lineInfo = this.parseLine(line, dataRow);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo.validRow);
          } else {
            returnObject.errorMessages.push(lineInfo.errorMessage);
          }
        }
      }
      dataRow++;
    });

    return returnObject;
  }

  private parseLine(line: string, row: number): any {
    const columns = line.split(',');
    if (!columns[0] || columns[0].length === 0) {
      return null;
    }

    // Trim and uppercase columns
    for (let index = 0; index < 14; index++) {
      if (columns[index]) {
        columns[index] = columns[index].toUpperCase().trim();
      }
    }

    const relocationDetail = {
      row: row,
      worker: {
        workerNumber: columns[3],
        jobClass: columns[4]
      },
      plannedLocation: {
        buildingCodeSearch: columns[7],
        floorSearch: this.checkLeadingZero(columns[8]),
        corridorSearch: columns[9],
        suiteSearch: columns[10],
        roomSearch: columns[11],
        zonePrefix: columns[12],
        locType: columns[0],
        acronym: columns[5]
      },
      moveDate: columns[6],
      telephoneNo: columns[13]
    };

    const theRow = row + 1;
    const message = this.validateSpreadsheetDetails(relocationDetail, theRow);
    if (message) {
      return message;
    } else {
      return {
        validRow: relocationDetail
      };
    }
  }

  private checkLeadingZero(value: string): string {
    if (!value) return value;
    // Add leading zero if needed for floor numbers
    if (value.length === 1 && !isNaN(Number(value))) {
      return '0' + value;
    }
    return value;
  }

  private validateSpreadsheetDetails(relocationDetail: any, row: number): any {
    if (relocationDetail.plannedLocation.locType !== 'P') {
      return {
        errorMessage: {
          message: `Row ${row}: Location Type of ${relocationDetail.plannedLocation.locType} is invalid. Value must be P`
        }
      };
    } else if (!relocationDetail.worker.workerNumber) {
      return {
        errorMessage: {
          message: `Row ${row}: Worker number is missing`
        }
      };
    } else if (!relocationDetail.plannedLocation.buildingCodeSearch) {
      return {
        errorMessage: {
          message: `Row ${row}: Planned Building missing`
        }
      };
    }
    return null;
  }

  validateSpreadSheet(validRows: any[]): Promise<any> {
    const returnObject: any = {
      errorMessages: [],
      validRows: []
    };
    const promises = validRows.map(planRow => this.getPlanRowPromise(planRow, returnObject));

    return Promise.all(promises).then(
      () => {
        return returnObject;
      },
      () => {
        return returnObject;
      }
    );
  }

  private getPlanRowPromise(planRow: any, returnObject: any): Promise<any> {
    return this.workerService.getWorkerByWorkerNumber(planRow.worker.workerNumber).toPromise()
      .then((response: any) => {
        if (response.results && response.results.length > 0) {
          planRow.worker = response.results[0];
          planRow = this.checkAcronymAndTelephoneNumber(planRow);
          this.updateReturnObjectForAcronym(planRow, returnObject);
          return this.workerService.getAssociatedAssignmentLocation(planRow.worker.workerId, this.appService.getUserRoles()).toPromise();
        } else {
          planRow.invalid = true;
          const errorMessage = {
            message: `Row ${planRow.row + 1} Worker: ${planRow.worker.workerNumber} not found`
          };
          returnObject.errorMessages.push(errorMessage);
          return this.workerService.getAssociatedAssignmentLocation('-1', this.appService.getUserRoles()).toPromise();
        }
      })
      .then((response: any) => {
        return this.checkLocationResponse(response, planRow, returnObject);
      }, (error: any) => {
        planRow.invalid = true;
        const errorMessage = {
          message: `Row ${planRow.row + 1} Worker assignment for ${planRow.worker.workerNumber} not found`
        };
        returnObject.errorMessages.push(errorMessage);
        return Promise.resolve(null);
      })
      .then(() => {
        // After checking location response, get the organization
        return this.organizationService.getOrganizationByAcronym(planRow.plannedLocation.acronym, false).toPromise();
      })
      .then((response: any) => {
        if (response.results && response.results.length > 0) {
          planRow.organization = response.results[0];
          return this.relocationService.getLocationsBySearch(planRow.plannedLocation).toPromise();
        } else {
          planRow.invalid = true;
          const errorMessage = {
            message: `Row ${planRow.row + 1} Organization: ${planRow.plannedLocation.acronym} not found`
          };
          returnObject.errorMessages.push(errorMessage);
          return this.relocationService.getLocationsBySearch(planRow.plannedLocation).toPromise();
        }
      }, (error: any) => {
        planRow.invalid = true;
        const errorMessage = {
          message: `Row ${planRow.row + 1} Organization: ${planRow.plannedLocation.acronym} - ${error.data?.message || 'not found'}`
        };
        returnObject.errorMessages.push(errorMessage);
        return this.relocationService.getLocationsBySearch(planRow.plannedLocation).toPromise();
      })
      .then((response: any) => {
        if (response && response.results && response.results.length > 0) {
          planRow.location = response.results[0];
          if (!planRow.invalid) {
            returnObject.validRows.push(planRow);
          }
        }
        return response;
      }, (error: any) => {
        const errorMessage = {
          message: `Row ${planRow.row + 1} Location - ${error.data?.message || 'not found'}`
        };
        returnObject.errorMessages.push(errorMessage);
        return error;
      });
  }

  private checkAcronymAndTelephoneNumber(planRow: any): any {
    try {
      if (!planRow.telephoneNo) {
        planRow.telephoneNo = this.getPrimaryTelephoneNumber(planRow.worker);
      }
      if (!planRow.plannedLocation.acronym) {
        planRow.plannedLocation.acronym = this.getPrimaryAcronymFromWorker(planRow.worker);
      }
    } catch (error) {
    }
    return planRow;
  }

  private getPrimaryAcronymFromWorker(worker: any): string | null {
    if (!worker.organizationHistory) return null;
    const primaryOrg = worker.organizationHistory.find((org: any) => org.primaryOrganizationIndicator);
    if (primaryOrg && primaryOrg.organization) {
      return `${primaryOrg.organization.businessAreaCode}/${primaryOrg.organization.shortName}`;
    }
    return null;
  }

  private updateReturnObjectForAcronym(planRow: any, returnObject: any): void {
    if (!planRow.plannedLocation.acronym) {
      const errorMessage = {
        message: `Row ${planRow.row + 1} Worker: ${planRow.worker.workerNumber} does not have current acronym and one was not provided in spreadsheet.`
      };
      returnObject.errorMessages.push(errorMessage);
    }
  }

  private checkLocationResponse(response: any, planRow: any, returnObject: any): Promise<any> {
    if (response && response.length > 0) {
      planRow.workerAssignment = response[0];
      if (planRow.workerAssignment.assignmentLocation) {
        return this.relocationService.getLocation(planRow.workerAssignment.assignmentLocation.locationId).toPromise()
          .then((location: any) => {
            planRow.workerAssignment.assignmentLocation = location;
            return location;
          });
      } else {
        // Worker has assignment but no location - still valid, just no location details
        return Promise.resolve(null);
      }
    }
    
    // Worker has no current assignments - create a placeholder assignment
    // This allows the worker to be imported with no "from" location
    planRow.workerAssignment = {
      workerAssignmentId: null,
      assignmentLocation: null
    };
    
    // Don't mark as invalid - allow the row to be imported
    return Promise.resolve(null);
  }

  showImportRelocationDialogFailure(parsedObject: any): void {
    const modalOptions = {
      titleType: 'text-danger',
      content: 'The import file contains errors. Please review and correct them.',
      primaryButton: 'Continue with valid rows',
      primaryButtonType: 'primary',
      cancelButton: true,
      title: 'Import Validation Errors',
      errorMessages: parsedObject.errorMessages,
      validRowCount: parsedObject.validRows.length
    };

    const dialogRef = this.dialog.open(DialogComponent, {
      width: '60vw',
      maxHeight: '80vh',
      data: modalOptions,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result === true && parsedObject.validRows && parsedObject.validRows.length > 0) {
        this.saveTheValidDetails(parsedObject);
      } else {
        this.showWait = false;
      }
    });
  }

  saveTheValidDetails(validatedObject: any): void {
    // Ensure selectedRelocation has required properties
    if (!this.selectedRelocation || !this.selectedRelocation.relocationPlanId) {
      this.showWait = false;
      this.relocationService.updateReturnCode(400);
      this.relocationService.updateReturnMessage('Relocation plan information is missing');
      this.relocationService.updateHideMessage(false);
      return;
    }
    
    const locationsToSave = this.buildLocations(validatedObject, this.selectedRelocation);

    // Ensure we have valid data to save
    if (!locationsToSave || locationsToSave.length === 0) {
      this.showWait = false;
      this.relocationService.updateReturnCode(400);
      this.relocationService.updateReturnMessage('No valid rows to import');
      this.relocationService.updateHideMessage(false);
      return;
    }
    this.relocationPlanDetailsService.addPlanDetails(locationsToSave).subscribe({
      next: () => {
        this.showWait = false;
        const errorCount = validatedObject.errorMessages ? validatedObject.errorMessages.length : 0;
        const validCount = validatedObject.validRows ? validatedObject.validRows.length : 0;
        const modalOptions = {
          titleType: 'text-success',
          content: `The imported file produced ${errorCount} errors and ${validCount} records were imported`,
          primaryButton: 'OK',
          primaryButtonType: 'success',
          title: 'Import Successful'
        };
        this.openTheDialog(modalOptions, () => {
          this.getRelocationPlanDetails(this.selectedRelocation, 10, 0);
        });
      },
      error: (error) => {
        this.showWait = false;
        this.relocationService.updateReturnCode(400);
        this.relocationService.updateReturnMessage('Problem occurred saving imported relocation Plan details');
        this.relocationService.updateHideMessage(false);
      }
    });
  }

  private buildLocations(parsedObject: any, currentRelocationPlan: any): any[] {
    const locationsToSave: any[] = [];

    parsedObject.validRows.forEach((aRow: any) => {
      if (!aRow.worker.jobClass || !aRow.worker.jobClass.value) {
        aRow.worker.jobClass = { value: 'PEXMR' };
      }

      let moveDate: string;
      if (!aRow.moveDate) {
        moveDate = this.utilityService.getTimeNow();
      } else {
        moveDate = this.utilityService.adjustDateFormatter(aRow.moveDate);
      }

      // Convert workerAssignmentId to number if it's a string
      let workerAssignmentId = aRow.workerAssignment.workerAssignmentId;
      if (typeof workerAssignmentId === 'string') {
        workerAssignmentId = parseInt(workerAssignmentId, 10);
      }

      const aLocation = {
        relocationPlan: currentRelocationPlan,
        worker: aRow.worker,
        from: {
          workerAssignmentId: workerAssignmentId,
          assignmentLocation: aRow.workerAssignment.assignmentLocation || null
        },
        to: {
          assignmentLocation: aRow.location,
          communication: aRow.telephoneNo ? {
            telephoneNo: aRow.telephoneNo,
            telecomAddressType: { id: this.teleComId || '1' },
            primaryIndicator: true
          } : null,
          workerOrganization: {
            organization: aRow.organization,
            organizationStatusCurrent: 'P'
          },
          lifecycle: {
            beginDate: moveDate
          }
        }
      };

      locationsToSave.push(aLocation);
    });

    return locationsToSave;
  }
  
  buildRelocationSpreadsheet(spreadsheet: string): void {
    if (!spreadsheet) {
      return;
    }
    // Replace all whitespace with commas, then split by comma
    const input = spreadsheet.replace(/\s/g, ',').split(',');
    // Filter out empty strings
    const payload = input.filter((value: string) => value !== '');
    
    const url = '/relocation-plans/mass-upload-excel-report';
    const fileName = 'relocation.csv';
    const fileType = 'text/csv';
    
    this.relocationService.getWorkerSpreadsheet(url, fileName, fileType, false, payload);
  }
  
  // Load job class codes
  loadJobClassCodes(): void {
    this.relocationService.getJobCodeClasses().subscribe({
      next: (response: any) => {
        this.jobClassCodes = response.results || [];
      },
      error: (error) => {
        this.jobClassCodes = [];
      }
    });
  }

  // Load telecom types
  loadTelecomTypes(): void {
    this.workerService.getTelecomTypes().subscribe({
      next: (responseTelecomTypes: any) => {
        const telecomTypes = responseTelecomTypes;
        telecomTypes.forEach((telecom: any) => {
          if (telecom.value === 'T') {
            this.teleComId = telecom.id;
          }
        });
      },
      error: (error: any) => {
      }
    });
  }
  
  checkAll(): void {
    this.selectedAll = !this.selectedAll;
    this.relocationDetailsList.forEach((item: any) => {
      item.selected = this.selectedAll ;
    });
  }
  
  toggleCollapse(): void {
    this.collapsedMode = !this.collapsedMode;
  }
  
  showImport(): void {
    if (this.add || this.edit) {
      return;
    }
    // Navigate to import route instead of just changing moduleName
    const relocationPlanId = this.selectedRelocation?.relocationPlanId;
    if (relocationPlanId) {
      this.router.navigate(['/app/relocation-plan-details', relocationPlanId, 'import']);
    } else {
      // Fallback to old behavior if no relocationPlanId
      this.moduleName = 'Import';
      this.appTitle = this.selectedRelocation.relocationPlanName + ' - Import Details';
    }
  }
  
  showAddRowWizard(): void {
    if (this.add || this.edit) {
      return;
    }

    const dialogData = {
      workerResults: this.workerResults || [],
      locationResults: this.locationResults || [],
      jobClassCodes: this.jobClassCodes || []
    };

    const dialogRef = this.dialog.open(AddWorkerWizardDialogComponent, {
      width: '90vw',
      maxWidth: '1200px',
      height: '80vh',
      maxHeight: '800px',
      data: dialogData,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result === 'import') {
        this.showImport();
        return;
      }
      
      if (result && result.selectedWorker && result.selectedLocation) {
        this.workerResults = result.workers;
        this.locationResults = result.locations;
        this.buildNewPlan(
          result.selectedWorker,
          result.selectedWorker.location,
          result.selectedWorker.workerAssignmentId,
          result.selectedLocation
        );
      }
    });
  }

  /**
   * Build a new relocation plan entry from selected worker and location
   */
  buildNewPlan(worker: any, fromLocation: any, currentWorkerAssignmentId: string, toLocation: any): void {
    // Check for duplicate worker in plan
    const isDuplicate = this.checkDuplicateWorkerInPlan(worker);
    if (isDuplicate) {
      const modalOptions = {
        titleType: 'text-danger',
        content: `Employee ${worker.workerNumber} is already in this relocation plan.`,
        primaryButton: 'Close',
        primaryButtonType: 'default',
        title: 'Duplicate found!'
      };
      this.openTheDialog(modalOptions);
      return;
    }

    this.editedAcronym = '';
    let currentTelephone = null;

    // Get primary telephone number
    if (worker.communicationHistory && worker.communicationHistory.length > 0) {
      currentTelephone = this.getPrimaryTelephoneNumber(worker);
    }

    // Get primary organization
    let currentOrganization: any;
    if (worker.organizationHistory) {
      worker.organizationHistory.forEach((orgObject: any) => {
        if (orgObject.primaryOrganizationIndicator) {
          currentOrganization = orgObject.organization;
        }
      });
    }

    // Set edited acronym
    this.setEditedAcronym(worker);

    // Set default job class if not present
    if (!worker.jobClass || !worker.jobClass.value) {
      worker.jobClass = { value: 'PEXMR' };
    }

    // Build the edited location object
    this.editedLocation = {
      relocationPlan: this.selectedRelocation,
      worker: worker,
      from: {
        workerAssignmentId: currentWorkerAssignmentId,
        assignmentLocation: fromLocation
      },
      to: {
        assignmentLocation: toLocation,
        communication: currentTelephone ? {
          telephoneNo: currentTelephone,
          telecomAddressType: { id: this.teleComId || '1' },
          primaryIndicator: true
        } : null,
        workerOrganization: {
          organization: currentOrganization,
          organizationStatusCurrent: 'P'
        },
        lifecycle: {
          beginDate: ''
        }
      }
    };

    this.buildLocationString(this.editedLocation.to.assignmentLocation);
    this.add = true;
  }

  /**
   * Check if worker already exists in the relocation plan
   */
  checkDuplicateWorkerInPlan(worker: any): boolean {
    if (!this.relocationDetailsList || this.relocationDetailsList.length === 0) {
      return false;
    }
    return this.relocationDetailsList.some((detail: any) =>
      detail.worker && detail.worker.workerId === worker.workerId
    );
  }

  /**
   * Get primary telephone number from worker communication history
   */
  getPrimaryTelephoneNumber(worker: any): string | null {
    if (!worker.communicationHistory) {
      return null;
    }
    const primaryComm = worker.communicationHistory.find((comm: any) => comm.primaryIndicator);
    return primaryComm ? primaryComm.telephoneNo : null;
  }

  /**
   * Set edited acronym from worker organization history
   */
  setEditedAcronym(worker: any): void {
    if (worker.organizationHistory && worker.organizationHistory.length > 0) {
      const primaryOrg = worker.organizationHistory.find((org: any) => org.primaryOrganizationIndicator);
      if (primaryOrg && primaryOrg.organization) {
        this.editedAcronym = `${primaryOrg.organization.businessAreaCode}/${primaryOrg.organization.shortName}`;
      }
    }
  }
  exportPlannedDetails() {
    const params = [];
    if (this.selectedRelocation?.relocationPlanId) {
      params.push(
        `relocationPlanId=${encodeURIComponent(this.selectedRelocation.relocationPlanId)}`
      );
    }
    if (this.selectedRelocation?.relocationPlanName) {
      params.push(
        `relocationPlanName=${encodeURIComponent(this.selectedRelocation.relocationPlanName)}`
      );
    }
    const url = `/workerAssignmentPlans/excelReport?${params.join('&')}`;

    this.relocationService.exportTableService(url).subscribe((response: any) => {
      const fileName = 'RelocationPlannedDetails.xls';
      const fileType = 'application/vnd.ms-excel';
      const blob = new Blob([response], { type: fileType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.target = '_blank';
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    });
  }

  deleteAll() {
    // Validate that there are details to delete
    if (!this.relocationDetailsList || this.relocationDetailsList.length === 0) {
      const modalOptions = {
        titleType: 'text-warning',
        content: 'There are no details to delete.',
        primaryButton: 'OK',
        primaryButtonType: 'warning',
        title: 'No Details Found',
      };
      this.openTheDialog(modalOptions);
      return;
    }
    
    const modalOptions = {
      titleType: 'text-danger',
      content: 'All planned move information will be deleted.',
      primaryButton: 'Continue',
      primaryButtonType: 'danger',
      cancelButton: true,
      title: 'Delete all rows in this plan?',
    };
    this.openTheDialog(modalOptions, () => this.removeAllPlanDetails(this.relocationDetailsList));
  }

  removeAllPlanDetails(detailsToDelete: any[]): void {
    // Optionally show a wait message or spinner here
    this.relocationPlanDetailsService.deleteDetailsList(detailsToDelete).subscribe({
      next: () => {
        // Optionally show a success message
        const modalOptions = {
          titleType: 'text-success',
          content: 'All workers removed from plan',
          primaryButton: 'Continue',
          primaryButtonType: 'success',
          title: 'Delete Successful!',
        };
        this.openTheDialog(modalOptions, () => {
          this.reloadRelocation();
          this.selectedRelocation = null;
        });
      },
      error: () => {
        // Optionally show an error message
        const modalOptions = {
          titleType: 'text-danger',
          content: 'Problem occurred while removing all workers from relocation plan',
          primaryButton: 'Close',
          primaryButtonType: 'danger',
          title: 'Delete Failed!',
        };
        this.openTheDialog(modalOptions);
      },
    });
  }

  executeRelocation() {
    this.validateExecuteRows(this.checkedItems());
  }

  editDetail(relocationPlanDetail: any) {
    if (this.add || this.edit || !this.canEdit()) {
      return;
    }
    this.moveDateInvalid = false;
    this.planDetailInvalid = false;
    this.telephoneNumberInvalid = false;
    // Deep copy to match legacy behavior - prevents editing original object
    this.editedLocation = JSON.parse(JSON.stringify(relocationPlanDetail));
    this.editedAcronym =
      this.editedLocation.to.workerOrganization.organization.businessAreaCode +
      '/' +
      this.editedLocation.to.workerOrganization.organization.shortName;
    if (this.editedLocation.to.communication && this.editedLocation.to.communication.telephoneNo) {
      this.editedLocation.to.communication.telephoneNo = this.utilityService.convertTelephone(
        this.editedLocation.to.communication.telephoneNo
      );
    }
    this.buildLocationString(this.editedLocation.to.assignmentLocation);
    relocationPlanDetail.edit = 1;
    this.edit = true;
  }

  canEdit(): boolean {
    return this.appService.hasAnyRole([
      ROLES_ENUM.INFRA_ADMIN,
      ROLES_ENUM.INFRA_RELOCATION_ADMIN,
      ROLES_ENUM.INFRA_GAU_PLANNER,
    ]);
  }

  buildLocationString(location: any): void {
    if (!location) {
      this.plannedLocationValue = '';
      return;
    }
    let value = '';
    if (location.building?.code) {
      value += location.building.code + ' ';
    }
    if (location.corridorId) {
      value += location.corridorId;
    }
    if (location.roomId) {
      value += location.roomId;
    }
    if (location.building?.floorNumber) {
      value += location.building.floorNumber;
    }
    if (location.suiteId) {
      value += location.suiteId;
    }
    if (location.zoneId) {
      value += location.zoneId;
    }
    this.plannedLocationValue = value;
  }

  cancelEdit(relocationPlanDetail: any): void {
    this.moveDateInvalid = false;
    this.planDetailInvalid = false;
    this.telephoneNumberInvalid = false;
    if (relocationPlanDetail) {
      relocationPlanDetail.edit = 0;
    }
    this.edit = false;
    this.add = false;
  }

  cancelAddEdit(): void {
    this.moveDateInvalid = false;
    this.planDetailInvalid = false;
    this.telephoneNumberInvalid = false;
    this.add = false;
    this.edit = false;
  }

  cancelAllInvalidates(): void {
    this.moveDateInvalid = false;
    this.planDetailInvalid = false;
    this.telephoneNumberInvalid = false;
  }

  validatePlanDetail(): boolean {
    this.moveDateInvalid = false;
    this.planDetailInvalid = false;
    this.telephoneNumberInvalid = false;

    // Validate move date
    if (this.editedLocation.to.lifecycle) {
      if (!this.editedLocation.to.lifecycle.beginDate) {
        this.moveDateInvalid = true;
        this.planDetailInvalid = true;
      } else {
        // Add unique time to date if it has 00:00:00
        const newDateStr = this.editedLocation.to.lifecycle.beginDate.replace(
          '00:00:00',
          this.utilityService.getUniqueTime()
        );
        this.editedLocation.to.lifecycle.beginDate = newDateStr;
      }
    } else {
      this.moveDateInvalid = true;
      this.planDetailInvalid = true;
    }

    // Validate telephone number if present (should be 14 characters with formatting)
    if (
      this.editedLocation.to.communication &&
      this.editedLocation.to.communication.telephoneNo &&
      this.editedLocation.to.communication.telephoneNo.length !== 14
    ) {
      this.telephoneNumberInvalid = true;
      this.planDetailInvalid = true;
    } else if (this.editedLocation.to.communication) {
      this.editedLocation.to.communication.telecomAddressType = { id: this.getTelephoneType() };
      this.editedLocation.to.communication.primaryIndicator = true;
    }

    return !this.planDetailInvalid;
  }

  getTelephoneType(): string {
    let theType = '1';
    if (this.teleComId) {
      theType = this.teleComId;
    }
    return theType;
  }

  pageSizeChangedEvent(event: any) {}

  changeOrganization(): void {
    const dialogData = {
      title: 'Search and select acronym',
      button: 'Select acronym'
    };

    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      maxWidth: '1200px',
      height: '80vh',
      data: dialogData,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((selectedOrganization: any) => {
      if (selectedOrganization) {
        const organization = {
          organizationId: selectedOrganization.organizationId,
          shortName: selectedOrganization.shortName,
          businessAreaCode: selectedOrganization.organizationType?.businessArea?.code || selectedOrganization.businessAreaCode
        };
        this.editedLocation.to.workerOrganization.organization = organization;
        this.editedAcronym = organization.businessAreaCode + '/' + organization.shortName;
      }
    });
  }

  changeLocation(): void {
    const dialogData = {
      mailStopIndicator: false,
      searchTitle: 'Select location'
    };

    const dialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '80vw',
      maxWidth: '1200px',
      height: '80vh',
      data: dialogData,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((location: any) => {
      if (location) {
        this.editedLocation.to.assignmentLocation = location;
        this.buildLocationString(location);
      }
    });
  }

  searchAcronymChange(event: any) {
    // TODO: Implement acronym search change
  }

  deleteDetail(relocationPlanDetail: any): void {
    if (this.add || this.edit || !this.canEdit()) {
      return;
    }

    // Show confirmation dialog before deleting
    const modalOptions = {
      titleType: 'text-danger',
      content: `Planned move information for ${relocationPlanDetail.worker.familyName}, ${relocationPlanDetail.worker.givenName} will be deleted.`,
      primaryButton: 'Continue',
      primaryButtonType: 'danger',
      cancelButton: true,
      title: 'Delete this row?',
    };
    
    this.openTheDialog(modalOptions, () => {
      // This callback only executes if user confirmed (clicked Continue)
      this.relocationPlanDetailsService.deleteDetail(relocationPlanDetail).subscribe({
        next: () => {
          // Refresh the table after successful deletion
          this.getRelocationPlanDetails(this.selectedRelocation, 10, 0);
        },
        error: (error) => {
          // Error message is already handled by the service
          // Just refresh the table to ensure consistency
          this.getRelocationPlanDetails(this.selectedRelocation, 10, 0);
        },
      });
    });
  }

  acceptAddEdit(relocationPlanDetail?: any): void {
    // Validate before saving
    if (!this.validatePlanDetail()) {
      return;
    }

    // Prepare the data for saving
    const detailToSave = JSON.parse(JSON.stringify(this.editedLocation));
    
    // Strip telephone number formatting if present (remove non-digits)
    if (detailToSave.to.communication && detailToSave.to.communication.telephoneNo) {
      detailToSave.to.communication.telephoneNo = detailToSave.to.communication.telephoneNo.replace(/\D/g, '');
    }

    // Adjust date format
    if (detailToSave.to.lifecycle && detailToSave.to.lifecycle.beginDate) {
      detailToSave.to.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
        detailToSave.to.lifecycle.beginDate
      );
    }

    if (this.editedLocation.workerAssignmentPlanId) {
      // Editing existing detail
      this.relocationPlanDetailsService.saveRelocationPlanDetail(detailToSave).subscribe({
        next: () => {
          this.relocationService.updateReturnMessage(
            `Plan Detail for ${this.editedLocation.worker.familyName}, ${this.editedLocation.worker.givenName} updated successfully.`
          );
          this.relocationService.updateHideMessage(false);
          this.relocationService.updateReturnCode(200);
          this.edit = false;
          this.getRelocationPlanDetails(this.selectedRelocation, 10, 0);
        },
        error: (responseMessage) => {
          this.relocationService.updateHideMessage(false);
          this.relocationService.updateReturnCode(400);
          this.relocationService.updateReturnMessage(responseMessage.data?.message || 'Failed to update plan detail');
        },
      });
    } else {
      // Adding new detail
      const details = [detailToSave];
      this.relocationPlanDetailsService.addPlanDetails(details).subscribe({
        next: () => {
          this.relocationService.updateReturnMessage(
            `Plan Detail for ${this.editedLocation.worker.familyName}, ${this.editedLocation.worker.givenName} added successfully.`
          );
          this.relocationService.updateHideMessage(false);
          this.relocationService.updateReturnCode(200);
          this.getRelocationPlanDetails(this.selectedRelocation, 10, 0);
          this.add = false;
        },
        error: (response) => {
          this.relocationService.updateHideMessage(false);
          this.relocationService.updateReturnCode(response.status);
          this.relocationService.updateReturnMessage(
            `Plan Detail for ${this.editedLocation.worker.familyName}, ${this.editedLocation.worker.givenName} failed to save.`
          );
        },
      });
    }
  }

  checkedItems() {
    return this.relocationDetailsList.filter((relocationDetail: any) => relocationDetail.selected);
  }
  validateExecuteRows(workersToExecutePlan: any[]): void {
    let modalOptions: any;
    if (workersToExecutePlan.length === 0) {
      modalOptions = {
        titleType: 'text-warning',
        content: 'At least one worker must be selected to execute a plan',
        primaryButton: 'Ok',
        primaryButtonType: 'warning',
        title: 'No Worker Selected!',
      };
      this.openTheDialog(modalOptions);
      return;
    }

    const now = new Date();
    const futureMoveDates: any[] = [];
    const validMoveDates: any[] = [];

    workersToExecutePlan.forEach((aRow: any) => {
      // Assuming UtilityService.compareDates returns >0 if aRow.to.lifecycle.beginDate is in the future
      const pastdate = this.utilityService.compareDates(now, new Date(aRow.to.lifecycle.beginDate));
      if (pastdate > 0) {
        futureMoveDates.push(aRow);
      } else {
        validMoveDates.push(aRow);
      }
    });

    if (futureMoveDates.length > 0) {
      if (validMoveDates.length > 0) {
        modalOptions = {
          titleType: 'text-warning',
          rows: futureMoveDates,
          dialogHtml: this.relocationRowsTemplate,
          content: `There are ${futureMoveDates.length} selected rows that have moves dates in the future. These workers cannot be moved until the move date.  Click 'Continue' to execute moves for past dates.`,
          primaryButton: 'Continue',
          primaryButtonType: 'warning',
          cancelButton: true,
          title: 'Future move dates selected!',
        };
        this.openTheDialog(modalOptions, () => this.showRelocationExecuteDialog(validMoveDates));
      } else {
        modalOptions = {
          titleType: 'text-warning',
          rows: futureMoveDates,
          dialogHtml: this.relocationRowsTemplate,
          content:
            'There are no rows with valid move dates.  Move dates must be today or earlier to execute plan.',
          primaryButton: 'Ok',
          primaryButtonType: 'warning',
          title: 'No Workers to move!',
        };
        this.openTheDialog(modalOptions);
      }
    } else {
      this.showRelocationExecuteDialog(validMoveDates);
    }
  }

  // Dialog open helper (replace with your actual dialog logic)
  private openTheDialog(options: any, afterCloseCallback?: () => void, width: string = '25vw', height: string = '20vh'): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: width,
      height: height,
      data: options,
      disableClose: true,
    });
    if (afterCloseCallback) {
      dialogRef.afterClosed().subscribe((result: boolean) => {
        // Only execute callback if user confirmed (clicked Continue/primary button)
        if (result === true) {
          afterCloseCallback();
        } else {
        }
      });
    }
  }

  showRelocationExecuteDialog(validMoveDates: any[]): void {
    const modalOptions = {
      titleType: 'text-default',
      primaryButton: 'Continue',
      dialogHtml: this.executeMoveDialogTemplate,
      content: '',
      cancelButton: true,
      primaryButtonType: 'primary',
      title: 'Execute move?',
    };
    this.openTheDialog(modalOptions, () => this.executeThePlan(validMoveDates), '40vw', '30vh');
  }

  executeThePlan(detailsToExecute: any[]): void {
    this.relocationPlanDetailsService.executePlan(detailsToExecute).subscribe({
      next: () => {
        const msg =
          detailsToExecute.length > 1
            ? `${detailsToExecute.length} workers have been moved successfully`
            : `${detailsToExecute.length} worker has been moved successfully`;
        const modalOptions = {
          titleType: 'text-success',
          content: msg,
          primaryButton: 'Continue',
          primaryButtonType: 'success',
          title: 'Execution Successful!',
        };
        this.openTheDialog(modalOptions, () => this.reloadRelocation());
      },
      error: (response: any) => {
        const modalOptions = {
          titleType: 'text-danger',
          content: response.message,
          primaryButton: 'Close',
          primaryButtonType: 'danger',
          title: 'Execution Failed!',
        };
        this.openTheDialog(modalOptions);
      },
    });
  }

  reloadRelocation(): void {
    this.utilityService.reload();
  }
  getRelocationPlanDetails(selectedRelocationPlan: any, limit: number, skip: number): void {
    this.relocationService.getRelocationPlanDetails(selectedRelocationPlan, limit, skip).subscribe({
      next: (response: any) => {
        this.relocationDetailsList = response.results;
        this.getCurrentRelocationPlanDetails(this.relocationDetailsList);
        this.tempRelocationDetailsList = [...this.relocationDetailsList];
        this.sortRelocationDetails(0);
        this.totalRecords = response.meta.total;
        this.total = response.meta.total;
      },
      error: (error: any) => {
        if (error.status === 404) {
          this.relocationDetailsList = [];
          this.getCurrentRelocationPlanDetails(this.relocationDetailsList);
        } else {
          // Optionally handle error messages
        }
        this.sortTypeObject = this.getSortTypeObject(0);
      },
    });
  }

  // You may need to implement or adapt these helper methods:
  getCurrentRelocationPlanDetails(relocationDetailsList: any[]): void {
    relocationDetailsList.forEach((item, index) => {
      item.organizationName =
        item.to.workerOrganization.organization.businessAreaCode +
        '/' +
        item.to.workerOrganization.organization.shortName;
      this.workerService
        .getAssociatedAssignmentLocation(item.worker.workerId, this.appService.getUserRoles())
        .subscribe((locations: any[]) => {
          setTimeout(() => {
            locations.forEach((location: any) => {
              if (
                location.primaryLocationIndicator &&
                location.assignmentLocation &&
                location.assignmentLocation.locationId &&
                location.location &&
                location.location.locationId &&
                location.assignmentLocation.locationId === location.location.locationId
              ) {
                this.relocationDetailsList[index].location = location.location;
              }
            });
          }, 1000);
        });
    });
  }

  sortRelocationDetails(sortIndex: number): void {
    this.sortTypeObject = this.getSortTypeObject(sortIndex);
    // Actually sort the relocationDetailsList array
    if (this.relocationDetailsList && this.relocationDetailsList.length > 0) {
      this.relocationDetailsList.forEach((item: any, idx: number) => {
      });
      
      // Create a new sorted array to trigger Angular change detection
      const sortedList = [...this.relocationDetailsList].sort((a: any, b: any) => {
        // Iterate through sort parameters in order
        for (const param of this.sortTypeObject.sortParameters) {
          const aValue = this.getNestedProperty(a, param);
          const bValue = this.getNestedProperty(b, param);
          
          // Handle null/undefined values
          if (aValue == null && bValue == null) continue;
          if (aValue == null) return 1;
          if (bValue == null) return -1;
          
          // Compare values
          if (aValue < bValue) return -1;
          if (aValue > bValue) return 1;
          // If equal, continue to next sort parameter
        }
        return 0;
      });
      sortedList.forEach((item: any, idx: number) => {
      });
      
      // Force view update by clearing and reassigning
      this.relocationDetailsList = [];
      setTimeout(() => {
        this.relocationDetailsList = sortedList;
      }, 0);
    } else {
    }
  }
  
  // Helper function to get nested property value
  private getNestedProperty(obj: any, path: string): any {
    return path.split('.').reduce((current, prop) => current?.[prop], obj);
  }

  getSortTypeObject(sortIndex: number): {
    sortName?: string;
    lastNameSortOrder?: number;
    acronymSortOrder?: number;
    moveDateSortOrder?: number;
    newLocationSortOrder?: number;
    sortParameters: string[];
  } {
    let sortName: string | undefined;
    let lastNameSortOrder: number | undefined;
    let acronymSortOrder: number | undefined;
    let moveDateSortOrder: number | undefined;
    let newLocationSortOrder: number | undefined;
    const sortParameters: string[] = [];

    switch (sortIndex) {
      case 0:
        lastNameSortOrder = 1;
        sortParameters.push('worker.familyName', 'worker.givenName', 'worker.workerNumber');
        sortName = 'Last name';
        break;
      case 1:
        acronymSortOrder = 1;
        lastNameSortOrder = 2;
        sortParameters.push(
          'organizationName',
          'worker.familyName',
          'worker.givenName',
          'worker.workerNumber'
        );
        sortName = 'Acronym';
        break;
      case 2:
        moveDateSortOrder = 1;
        acronymSortOrder = 2;
        lastNameSortOrder = 3;
        sortParameters.push(
          'to.lifecycle.beginDate',
          'to.workerOrganization.organization.shortName',
          'worker.familyName',
          'worker.givenName',
          'worker.workerNumber'
        );
        sortName = 'Move date';
        break;
      case 3:
        moveDateSortOrder = 1;
        newLocationSortOrder = 2;
        sortParameters.push(
          'to.lifecycle.beginDate',
          'to.assignmentLocation.building.code',
          'to.assignmentLocation.building.floorNumber',
          'to.assignmentLocation.corridorId',
          'to.assignmentLocation.roomId'
        );
        sortName = 'New location';
        break;
      default:
        sortName = 'Last name';
        lastNameSortOrder = 1;
        sortParameters.push('worker.familyName', 'worker.givenName', 'worker.workerNumber');
        break;
    }

    return {
      sortName,
      lastNameSortOrder,
      acronymSortOrder,
      moveDateSortOrder,
      newLocationSortOrder,
      sortParameters,
    };
  }
}
