import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { HttpService } from 'src/app/services/http.service';

@Injectable({
  providedIn: 'root',
})
export class WorkerService {
  constructor(private http: HttpService) {}

  getWorkerByWorkerNumber(workerNumber: string, inclueInactive: boolean = false): Observable<any> {
    return this.http.get(`/workers?workerNumber=${workerNumber}&includeInactive=${inclueInactive}`);
  }

  getWorkerUpdateObject(
    workerId: string,
    canGetSecure: boolean,
    userRoles: string[]
  ): Observable<any> {
    if (canGetSecure) {
      return this.getWorker(workerId).pipe(
        switchMap((worker) =>
          this.getSecureWorker(workerId).pipe(
            map((secureWorker) => ({ worker, workerSecure: secureWorker }))
          )
        ),
        switchMap((data) =>
          this.getPayPlan(workerId).pipe(map((payPlan) => ({ ...data, workerPayplan: payPlan })))
        ),
        switchMap((data) =>
          this.getAssociatedWorkerRolesDetails(workerId).pipe(
            map((workerRoles) => ({ ...data, workerRoles }))
          )
        ),
        switchMap((data) =>
          this.getWorkerOrganizations(workerId).pipe(
            map((organizations) => ({ ...data, organizations }))
          )
        ),
        switchMap((data) =>
          this.getAssociatedTelecommunicationLocationsAssignments(workerId, userRoles).pipe(
            map((telecommunications) => ({ ...data, telecommunications }))
          )
        ),
        switchMap((data) =>
          this.getAssociatedAssignmentLocation(workerId, userRoles).pipe(
            map((assignments) => ({ ...data, assignments }))
          )
        ),
        switchMap((data) =>
          this.getPrimaryWorkerOrganizationRoles(workerId).pipe(
            map((organizationWorkerRoles) => ({ ...data, organizationWorkerRoles }))
          )
        ),
        catchError((error) => {
          return of(null);
        })
      );
    } else {
      return this.getWorker(workerId).pipe(
        switchMap((worker) =>
          this.getPayPlan(workerId).pipe(map((payPlan) => ({ worker, workerPayplan: payPlan })))
        ),
        switchMap((data) =>
          this.getAssociatedWorkerRolesDetails(workerId).pipe(
            map((workerRoles) => ({ ...data, workerRoles }))
          )
        ),
        switchMap((data) =>
          this.getWorkerOrganizations(workerId).pipe(
            map((organizations) => ({ ...data, organizations }))
          )
        ),
        switchMap((data) =>
          this.getAssociatedTelecommunicationLocationsAssignments(workerId, userRoles).pipe(
            map((telecommunications) => ({ ...data, telecommunications }))
          )
        ),
        switchMap((data) =>
          this.getAssociatedAssignmentLocation(workerId, userRoles).pipe(
            map((assignments) => ({ ...data, assignments }))
          )
        ),
        switchMap((data) =>
          this.getPrimaryWorkerOrganizationRoles(workerId).pipe(
            map((organizationWorkerRoles) => ({ ...data, organizationWorkerRoles }))
          )
        ),
        catchError((error) => {
          return of(null);
        })
      );
    }
  }

  getWorker(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}`).pipe(
      map((response: any) => response.data),
      catchError((error) => {
        return of(null);
      })
    );
  }

  getSecureWorker(workerId: string): Observable<any> {
    return this.http.get(`/secure-workers/${workerId}`).pipe(
      map((response: any) => response.data),
      catchError((error) => {
        return of(null);
      })
    );
  }

  getPayPlan(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/payPlan`).pipe(
      map((response: any) => response.data),
      catchError((error) => {
        return of(null);
      })
    );
  }

  getAssociatedWorkerRolesDetails(workerId: string): Observable<any> {
    return this.getWorkerRoles(workerId).pipe(
      map((data) => data.results || []),
      catchError((error) => {
        return of([]);
      })
    );
  }

  getWorkerRoles(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/orgRoles`).pipe(
      map((response: any) => response.data),
      catchError(() => of({ results: [] }))
    );
  }

  getWorkerOrganizations(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/organizations`).pipe(
      map((response: any) => response.data.results),
      catchError(() => of([]))
    );
  }

  getAssociatedTelecommunicationLocationsAssignments(
    workerId: string,
    userRoles: string[] = []
  ): Observable<any> {
    return this.getTelecommunications(workerId, userRoles).pipe(
      catchError((error) => {
        return of([]);
      })
    );
  }

  getTelecommunications(workerId: string, userRoles: string[]): Observable<any> {
    if (userRoles.includes('InfraRoomCoordinator')) {
      return of([]);
    }
    return this.http.get(`/workers/${workerId}/telecommunications`).pipe(
      map((response: any) => response.data.results),
      catchError(() => of([]))
    );
  }

  getAssociatedAssignmentLocation(workerId: string, userRoles: string[]): Observable<any> {
    return this.getTelecommunications(workerId, userRoles).pipe(
      switchMap(() => this.getAssignments(workerId)),
      catchError((error) => {
        return of([]);
      })
    );
  }

  getAssignments(workerId: string): Observable<any> {
    return this.http.get(`/workers/${workerId}/assignments`).pipe(
      map((response: any) => {
        // Handle both response structures: {data: {results: []}} and {results: []}
        if (response.data?.results) {
          return response.data.results;
        } else if (response.results) {
          return response.results;
        } else if (response.data) {
          return response.data;
        }
        return [];
      }),
      catchError((error) => {
        return of([]);
      })
    );
  }

  getPrimaryWorkerOrganizationRoles(workerId: string): Observable<any> {
    return this.getWorkerOrganizations(workerId).pipe(
      map((organizations) => organizations.filter((org: any) => org.primaryOrganizationIndicator)),
      catchError(() => of([]))
    );
  }
  getWorkerFromQueueByWorkerNumber(
    workerNumber: string,
    inclueInactive: boolean = false
  ): Observable<any> {
    return this.http.get(
      `/workerQueue?workerNumber=${workerNumber}&includeInactive=${inclueInactive}`
    );
  }

  getTelecomTypes(): Observable<any> {
    return this.http.get('/references/telcom-address-types?includeInactive=false').pipe(
      map((response: any) => response.data?.results || response.results || []),
      catchError((error) => {        return of([]);
      })
    );
  }
}
