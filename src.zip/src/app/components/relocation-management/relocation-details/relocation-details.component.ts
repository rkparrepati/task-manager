import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AppService } from 'src/app/services/app.service';
import { RelocationService } from '../relocation.service';
import { RelocationDeleteConfirmDialogComponent } from '../relocation-delete-confirm-dialog/relocation-delete-confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-relocation-details',
  templateUrl: './relocation-details.component.html',
  styleUrls: ['./relocation-details.component.scss'],
})
export class RelocationDetailsComponent {
  private _relocation: any;
  @Input()
  set relocation(value: any) {
    value.planType = 'Worker';
    this._relocation = value;
  }
  get relocation(): any {
    return this._relocation;
  }

  @Output() relocationDeleted = new EventEmitter<void>();

  public rolesEnum = ROLES_ENUM;

  constructor(
    public appService: AppService,
    private relocationService: RelocationService,
    private dialog: MatDialog
  ) {}

  confirmDeleteRelocationPlan(relocation: any): void {
    this.relocationService.getRelocationPlanDetails(relocation).subscribe({
      next: () => {
        const modalOptions = {
          titleType: 'text-danger',
          okButton: true,
          title: `${relocation.relocationPlanName} can not be deleted`,
          content: relocation,
        };
        this.openDeleteRelocationDialog(modalOptions);
      },
      error: (responseDeleteRelocation) => {
        if (responseDeleteRelocation.error && responseDeleteRelocation.error.message) {
          const modalOptions = {
            titleType: 'text-danger',
            cancelButton: true,
            continueButton: true,
            title: `Delete ${relocation.relocationPlanName} plan ?`,
            content: relocation,
          };
          this.openDeleteAllRelocationDialog(modalOptions);
        }
      },
    });
  }

  // Placeholder methods for dialog opening, replace with actual implementations
  openDeleteRelocationDialog(options: any): void {
    this.dialog.open(RelocationDeleteConfirmDialogComponent, {
      width: '45vw',
      height: '200px',
      data: options,
      disableClose: true,
    });
  }

  openDeleteAllRelocationDialog(options: any): void {
    const dialogRef = this.dialog.open(RelocationDeleteConfirmDialogComponent, {
      width: '45vw',
      height: '200px',
      data: options,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteEntirePlan(options.content);
      }
    });
  }

  reloadRelocationDetails(relocation: any): void {
    this.relocationService.getRelocationPlanDetails(relocation).subscribe({
      next: (response: any) => {
        this.relocation = response.data;
      },
      error: (error: any) => {
      }
    });
  }

  deleteEntirePlan(relocation: any): void {
    this.relocationService.deleteRelocationPlan(relocation.relocationPlanId).subscribe({
      next: () => {
        // Success message from legacy: "Successfully deleted relocation plan " + relocationPlanName
        this.relocationService.updateReturnCode(200);
        this.relocationService.updateReturnMessage(
          `Successfully deleted relocation plan ${relocation.relocationPlanName}`
        );
        this.relocationService.updateReturnMessageArray([]);
        this.relocationService.updateHideMessage(false);
        
        // Emit event to parent component to refresh the relocation list
        // This preserves the success message while reloading the table data
        this.relocationDeleted.emit();
      },
      error: (response) => {
        this.relocationService.updateReturnCode(response.status);
        this.relocationService.updateReturnMessage('Failed to delete relocation plan');
        this.relocationService.updateReturnMessageArray([]);
        this.relocationService.updateHideMessage(false);
      },
    });
  }
  exportRelocation(relocation: any): void {
    // this.relocationService.exportRelocationPlan(relocation).subscribe({
    //   next: (response: any) => {
    //     const blob = new Blob([response], { type: 'application/json' });
    //     const url = window.URL.createObjectURL(blob);
    //     const a = document.createElement('a');
    //     a.href = url;
    //     a.download = `${relocation.relocationPlanName}.json`;
    //     a.click();
    //     window.URL.revokeObjectURL(url);
    //   },
    //   error: (error: any) => {
    //     
    //   }
    // });
  }
}
