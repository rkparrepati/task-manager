import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'src/app/services/app.service';
import { RelocationService } from '../relocation.service';
import { DialogComponent } from '../dialog/dialog.component';
import { MoveEmployeeLocationAttentionDialogComponent } from '../move-employee-location-attention-dialog/move-employee-location-attention-dialog.component';

@Component({
  selector: 'app-move-employee-location',
  templateUrl: './move-employee-location.component.html',
  styleUrls: ['./move-employee-location.component.scss'],
})
export class MoveEmployeeLocationComponent implements OnInit {
  importedFile: any = null;
  relocationSpreadsheet: any;
  returnCode: any = '';
  hideMessage: boolean = true;
  returnMessage: string = '';
  accessDenied: any;

  constructor(
    public relocationService: RelocationService,
    private appService: AppService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // Subscribe to service observables for acme-navbar message handling
    this.relocationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.relocationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.relocationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });
  }

  downloadTemplate() {
    this.relocationService.downloadTemplate('EmployeeLocationTemplate.csv');
  }
  sendFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input?.files?.length) {
      this.importedFile = input.files[0];
    }
  }

  buildRelocationSpreadsheet(): void {
    if (!this.relocationSpreadsheet) {
      return;
    }

    const input = this.relocationSpreadsheet.trim().split(/\s+/);
    const payload = input.filter((value: string) => value);

    if (payload.length === 0) {
      return;
    }

    const url = 'relocation-plans/mass-upload-excel-report';
    this.relocationService.getWorkerSpreadsheet(url, 'relocation.csv', 'text/csv', false, payload);
  }

  importFile() {    const reader = new FileReader();
    reader.onload = () => {
      const text: any = reader.result;
      const parsedObject = this.parsePlanSpreadsheet(text);      if (parsedObject.validRows && parsedObject.validRows.length > 0) {        // Call getMoveEmpLocationPayload equivalent (POST /locationsTest)
        this.getMoveEmpLocationPayload(parsedObject.validRows, parsedObject.invalidRows);
      } else {
        // Show error dialog with only invalid rows
        this.showEmployeeRelocationDialogFailure(parsedObject);
      }
    };
    
    const suffix = this.importedFile?.name.substring(
      this.importedFile?.name.length - 4,
      this.importedFile?.name.length
    );
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }
    reader.readAsText(this.importedFile as any);
  }

  getMoveEmpLocationPayload(validRows: any[], initialInvalidRows: any[]) {
    // This matches the legacy getMoveEmpLocationPayload which calls POST /locationsTest
    this.relocationService.validateLocations(validRows).subscribe({
      next: (response: any) => {        const returnedData = response?.data || response;
        
        // Create a map of validRows by employeeId to preserve row numbers
        const validRowsMap = new Map(validRows.map((row) => [row.employeeId, row]));
        
        const processedRows = {
          validRows: (returnedData.validResponses || []).map((validResponse: any) => {
            const originalRow = validRowsMap.get(validResponse.employeeId);
            return { ...validResponse, row: originalRow?.row };
          }),
          invalidRows: (returnedData.invalidResponses || []).map((invalidResponse: any) => {
            const originalRow = validRowsMap.get(invalidResponse.employeeId);
            return { ...invalidResponse, row: originalRow?.row };
          })
        };        // Merge initial invalid rows with validation invalid rows
        const allInvalidRows = [...initialInvalidRows, ...processedRows.invalidRows];
        
        if (allInvalidRows.length > 0) {
          processedRows.invalidRows = allInvalidRows;
          this.showEmployeeRelocationDialogFailure(processedRows);
        } else {
          this.updateTheValidDetails(processedRows.validRows);
        }
      },
      error: (err) => {        this.relocationService.updateReturnCode(500);
        this.relocationService.updateReturnMessage('Failed to validate locations');
        this.relocationService.updateHideMessage(false);
      }
    });
  }

  showEmployeeRelocationDialogFailure(parsedObject: any) {
    const dialogRef = this.dialog.open(MoveEmployeeLocationAttentionDialogComponent, {
      width: '80vw',
      height: '70vh',
      data: {
        data: parsedObject,
        title: 'Mass Move Employee Location Errors Summary'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'continue' && parsedObject.validRows && parsedObject.validRows.length > 0) {
        this.updateTheValidDetails(parsedObject.validRows);
      }
      // If cancelled or no valid rows, do nothing
    });
  }

  updateTheValidDetails(validRows: any[]) {
    this.moveSuccessful(validRows);
  }

  invalidFileTypeMessage() {
    const modalData = {
      titleType: 'text-danger',
      content: 'The format of the spreadsheet is not expected. Only CSV files can be imported.',
      primaryButton: 'Close',
      primaryButtonType: 'danger',
      title: 'Invalid File type!'
    };
    
    this.dialog.open(DialogComponent, {
      width: '400px',
      data: modalData,
      disableClose: true,
    });
  }

  parsePlanSpreadsheet(text: string) {
    const lines = text.split('\n');
    const returnObject: any = {
      invalidRows: [],
      validRows: [],
    };

    lines.forEach((value, index) => {
      if (index > 0) {
        const lineInfo: any = this.parseLine(value, index);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
    });

    return returnObject;
  }

  parseLine(line: string, row: number) {
    const columns = line.split(',').map((col) => col?.toUpperCase().trim());
    if (columns.length === 1 && !columns[0]) {
      return null;
    }

    const plannedDate = this.adjustDateFormatter(columns[9]);
    const moveEmployeeLocationDetail = {
      row: row,
      employeeId: columns[0],
      workerLastName: columns[1],
      workerFirstName: columns[2],
      plannedBuilding: columns[3],
      plannedFloor: columns[4],
      plannedCorridor: columns[5],
      plannedRoom: columns[6],
      plannedZone: columns[7],
      plannedSuite: columns[8],
      plannedMoveDate: plannedDate,
      message: '',
    };

    return moveEmployeeLocationDetail;
  }

  adjustDateFormatter(date: string): string {
    const parsedDate = new Date(date);
    return isNaN(parsedDate.getTime()) ? '' : parsedDate.toISOString().split('T')[0];
  }
  handleUploadCompletion(rows: any): void {
    let modalData = {};
    if (rows.validRows.length > 0) {
      modalData = {
        titleType: 'text-success',
        content: rows.validRows.length + ' employee(s) moved',
        primaryButton: 'OK',
        primaryButtonType: 'success',
        title: 'Mass move execution Successful!',
      };
    }
    if (rows.invalidRows.length > 0) {
      modalData = {
        titleType: 'text-danger',
        content: rows.invalidRows.length + ' employee(s) could not be moved.',
        primaryButton: 'OK',
        primaryButtonType: 'default',
        title: 'Mass move execution failed.',
      };
    }
    
    // Navigate first, then show dialog
    this.appService.changePage('/app/relocation');
    
    // Show dialog after navigation with a slight delay to ensure the page is loaded
    setTimeout(() => {
      this.dialog.open(DialogComponent, {
        width: '400px',
        data: modalData,
        disableClose: true,
      });
    }, 100);
  }

  moveSuccessful(massUploadList: any[]): void {
    // This matches the legacy moveSuccesful function
    const promises: Promise<any>[] = [];
    
    massUploadList.forEach((item) => {
      const params = {
        audit: {
          lockControlNumber: item.lockControlNumber
        }
      };
      const tempAssignment = this.getTempAssignment(item);      const url = `/workers/${item.workerId}/assignments/${item.workerAssignmentId}`;
      const promise = this.relocationService.moveEmployeeLocation(url, params, tempAssignment).toPromise();
      promises.push(promise);
    });

    Promise.allSettled(promises).then((results) => {      const rows = {
        validRows: [] as any[],
        invalidRows: [] as any[]
      };

      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          rows.validRows.push(massUploadList[index]);
        } else {
          const item = massUploadList[index];
          item.errorMessage = (result as any).reason?.error?.message || 'Failed to move employee location';
          rows.invalidRows.push(item);
        }
      });

      this.handleUploadCompletion(rows);
    }).catch((err) => {      const modalData = {
        titleType: 'text-danger',
        content: massUploadList.length + ' employee(s) could not be moved.',
        primaryButton: 'OK',
        primaryButtonType: 'default',
        title: 'Mass move execution failed.'
      };
      
      // Navigate first, then show dialog
      this.appService.changePage('/app/relocation');
      
      // Show dialog after navigation with a slight delay to ensure the page is loaded
      setTimeout(() => {
        this.dialog.open(DialogComponent, {
          width: '400px',
          data: modalData,
          disableClose: true,
        });
      }, 100);
    });
  }

  getTempAssignment(item: any): any {
    // This matches the legacy getTempAssignment function exactly
    const workerOrg = item?.workerOrganization;
    const tempAssignment: any = {
      workerAssignmentId: item?.workerAssignmentId,
      mailLocation: null,
      assignmentStatusCurrent: item?.assignmentStatusCurrent,
      primaryLocationIndicator: true,
      hiddenIndicator: false,
      palmLocation: null
    };
    
    tempAssignment.assignmentLocation = {
      locationId: item?.assignmentLocation?.locationId
    };
    
    tempAssignment.workerOrganization = {
      workerOrganizationId: workerOrg?.workerOrganizationId,
      organization: workerOrg?.organization
    };
    
    tempAssignment.lifecycle = {
      beginDate: item?.lifecycle?.beginDate
    };
    
    if (item?.palmLocation?.legacyLocationId != null) {
      tempAssignment.palmLocation = {
        legacyLocationId: item?.palmLocation?.legacyLocationId
      };
    }

    return tempAssignment;
  }
}
