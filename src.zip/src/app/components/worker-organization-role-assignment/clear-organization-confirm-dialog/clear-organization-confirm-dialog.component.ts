import { Component } from '@angular/core';

@Component({
  selector: 'app-clear-organization-confirm-dialog',
  templateUrl: './clear-organization-confirm-dialog.component.html',
  styleUrls: ['./clear-organization-confirm-dialog.component.scss'],
})
export class ClearOrganizationConfirmDialogComponent {}
