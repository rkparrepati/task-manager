import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cancel-confirm-dialog',
  templateUrl: './cancel-confirm-dialog.component.html',
  styleUrls: ['./cancel-confirm-dialog.component.scss'],
  standalone: true, // Remove this line if you are using app.module.ts
  imports: [CommonModule, MatDialogModule, MatButtonModule], // Include these for standalone components
})
export class CancelConfirmDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<CancelConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, // 'public' makes 'data' accessible to the template
    private router: Router
  ) {}

  onExitClick(): void {
    // Close the dialog and return true to indicate exit confirmation
    this.dialogRef.close(true);
  }
}
