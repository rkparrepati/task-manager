import { Component, inject, Input, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
//import { AcmeNavbarComponent } from './acme-navbar/acme-navbar.component';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { LocationselectDialogComponent } from '../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { OrganizationService } from '../organization/services/organization.service';
import { AssignedRole, WorkerRole } from 'src/app/shared/interfaces/models';
import { WorkerOrganizationRoleAssignmentServiceService } from './worker-organization-role-assignment-service.service';
import { catchError, last, Observable } from 'rxjs';

@Component({
  selector: 'app-worker-organization-role-assignment',
  //imports: [AcmeNavbarComponent], // Add it here
  templateUrl: './worker-organization-role-assignment.component.html',
  styleUrls: ['./worker-organization-role-assignment.component.scss'],
})
export class WorkerOrganizationRoleAssignmentComponent implements OnInit, OnDestroy {
  appTitle: string = 'Worker Organization Role Assignment';
  moduleName: string = 'Worker Assignment';
  creationDate: any;
  //  moduleName: string = '';
  //  appTitle: string = '';
  userRoles: string[] = [];
  returnCode: string | number = '';
  hideMessage: boolean = true;
  reportRoleOrganizationId: string = '';
  reportRoleOrganizationName: string = '';
  invalidBusinessAreaCode = false;
  gotoPage: string = '';
  returnMessage: string = '';
  accessDenied: boolean = false;
  resetTimeout: any;
  skipToId: string = '';
  cancelPage: string = '/app/home';
  main = {
    creationDate: new Date(),
  };

  // Search related properties
  searchAcronym: string = '';
  businessAreaCode: string = '';
  shortName: string = '';
  showAssignRoleView: boolean = false;
  noMatchFound: boolean = false;

  acronymRequired = false;
  public base: any = {
    newLocation: {
      invalidHiddenIndicator: true,
      singlePrimary: '',
      noPrimary: '',
      setPrimary: '',
      lifecycle: {},
      invalidPrimaryIndicator: false,
      multipleHiddenAssignments: false,
      multiplePrimaryAssignments: false,
      mailLocationIndicator: false,
    },
  };
  @Input() public acronym = '';
  dialog = inject(MatDialog);
  @Input() assignMentWorker!: FormGroup;
  @ViewChild('orgInput') orgInput!: ElementRef<HTMLInputElement>;
  allWorkerRoles: any[] = [];
  orgnizationBase: any = {
    organization: {
      id: '',
      shortName: '',
      organizationName: '',
      businessAreaCode: '',
      acronym: '',
    },
    availableRoles: [],
    assignedRoles: [],
  };
  sanitizer: any;
  lastModifiedLoginId: any;
  lastModifiedDate: any;
  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private orgService: OrganizationService,
    private wrkOrgRoleAssignmentService: WorkerOrganizationRoleAssignmentServiceService,
    private router: Router
    // private localStorageService: LocalStorageService,
    // private locationService:LocationService,
    // private dialog: MatDialog
  ) {}
  searchAcronymChange(event: any) {}

  /**
   * Handles input event on the organization search input field.
   * Automatically adds "/" after the first character (business area code).
   * Converts input to uppercase.
   */
  onAcronymInput(event: any): void {
    const input = event.target as HTMLInputElement;
    let value = input.value.toUpperCase().replace(/\W+/g, ''); // Convert to uppercase and remove non-alphanumeric characters
    
    if (value) {
      value = this.formatAcronym(value);
      input.value = value;
    }
  }

  /**
   * Formats the acronym by adding "/" after the first character.
   * Based on the AngularJS acronym filter logic.
   */
  private formatAcronym(acronym: string): string {
    if (!acronym) {
      return '';
    }
    
    const value = acronym.toString().trim().toUpperCase(); // Ensure uppercase
    let businessArea: string;
    let shortName: string = '';

    switch (value.length) {
      case 1:
        businessArea = value;
        break;
      case 2:
        if (value.indexOf('/') > 0) {
          businessArea = value.slice(0, 1);
          shortName = value.slice(2);
        } else {
          businessArea = value.slice(0, 1);
          shortName = value.slice(1);
        }
        break;
      default:
        businessArea = value.slice(0, 1);
        shortName = value.slice(1);
    }

    if (shortName) {
      return (businessArea + '/' + shortName).trim();
    } else {
      return businessArea.trim();
    }
  }
  ngOnDestroy(): void {
    // Clean up any subscriptions or resources if needed
    if (this.resetTimeout) {
      clearTimeout(this.resetTimeout);
    }
  }

  ngOnInit(): void {
    // Clear the search organization input field when the page loads
    if (this.base.newLocation.workerOrganization?.organization) {
      this.base.newLocation.workerOrganization.organization.businessAreaCode = '';
    }
  }

  getOrganization(searchText: string): void {
    this.searchAcronym = searchText;
    // Equivalent to vm.resetTimeout() logic if needed
    //this.resetTimeout();

    this.reportRoleOrganizationId = '';
    this.hideMessage = true;
    this.noMatchFound = false;

    // Parsing searchAcronym as in your AngularJS code
    const firstPart = this.searchAcronym.substring(0, 1);
    const secondPart = this.searchAcronym.substring(2).trim();

    this.orgService.searchOrganizations(firstPart, secondPart).subscribe({
      next: (response: any) => {
        if (response?.results?.length > 0) {
          this.reportRoleOrganizationId = response.results[0].organizationId;
          this.reportRoleOrganizationName = response.results[0].organizationName;
          this.getRolesInfo(); // Call your next function
          
          // Clear the input field after successful search
          if (this.orgInput && this.orgInput.nativeElement) {
            this.orgInput.nativeElement.value = '';
          }
        } else {
          // Handle case where API returns success but no results
          this.noMatchFound = true;
        }
      },
      error: (error: any) => {
        if (!this.checkSecurityViolation(error)) {
          this.hideMessage = false;
          this.returnCode = error.status;
          this.returnMessage = `No Organizations found that match the query`;
          this.noMatchFound = true;
        }
      },
    });
  }

  private checkSecurityViolation(error: any): boolean {
    if (error.status === 403) {
      this.returnCode = error.status;
      this.hideMessage = false;
      return true;
    }
    return false;
  }

  private getRolesInfo(): void {
    // Reset state
    this.allWorkerRoles = [];
    this.orgnizationBase = { organization: {}, assignedRoles: [] };

   const firstPart = this.searchAcronym.substring(0, 1);
    const secondPart = this.searchAcronym.substring(2).trim();

    this.wrkOrgRoleAssignmentService.getOrganization(firstPart, secondPart, '').subscribe({
      next: (response) => {
        // Business logic remains similar but uses 'this'
        const unassigned = this.selectUnassignedWorkerRoles(
          response.allWorkerRoles,
          response.assignedRoles
        );
         const organizationData =
          response.organization.results && response.organization.results.length > 0
            ? response.organization.results[0]
            : null;

        // 3. Update the object reference to ensure the child component detects the change
        this.orgnizationBase = {
          ...this.orgnizationBase,
          organization: organizationData,
          assignedRoles: this.buildDisplayOptionsAssigned(response.assignedRoles),
          availableRoles: this.buildDisplayOptionsAll(unassigned),
        };
        this.hideMessage = true;
        this.showAssignRoleView = true;

        this.allWorkerRoles = this.buildDisplayOptionsAll(unassigned);

        // angular.copy replacement: Use structuredClone or spread operator
        this.acronym = structuredClone(this.searchAcronym);
        this.searchAcronym = '';
      },
      error: (errorResponse) => {
        this.handleError(errorResponse);
      },
    });
  }
  buildDisplayOptionsAll(workerRoles: any[]): any[] {
    const maxlength = 6;

    workerRoles.forEach((workerRole) => {
      // .repeat() is a cleaner way to create the padding string
      const paddingCount = Math.max(0, maxlength - workerRole.value.length);
      const temp = '&nbsp;'.repeat(paddingCount + 1); // +1 to match original logic
      const extraSpaces = '&nbsp;'.repeat(6);

      workerRole.displayItem = `${workerRole.value}${temp}${extraSpaces}${workerRole.description}`;
    });

    return workerRoles;
  }

  // Equivalent to vm.buildDisplayOptionsAssigned
  buildDisplayOptionsAssigned(workerRoles: any[]): any[] {
    const maxlength = 6;

    workerRoles.forEach((workerRole) => {
      const paddingCount = Math.max(0, maxlength - workerRole.reportRole.value.length);
      const temp = '&nbsp;'.repeat(paddingCount + 1);
      const extraSpaces = '&nbsp;'.repeat(6);

      workerRole.reportRole.displayItem = `${workerRole.reportRole.value}${temp}${extraSpaces}${workerRole.reportRole.description}`;
    });

    this.getLastModifiedInfo(); // Ensure this method exists in your class
    return workerRoles;
  }

  private getLastModifiedInfo() {
    const orgId = this.reportRoleOrganizationId || this.orgnizationBase.organization.id;
    if (orgId) {
      this.wrkOrgRoleAssignmentService.getLastModifiedRole(orgId).subscribe({
        next: (response) => {
          if (response.results?.length > 0) {            this.setLastModifiedInfo(response.results[0].audit);
          }
        }
      });
    }
  }

  private setLastModifiedInfo(auditObject: any) {
    this.lastModifiedLoginId = auditObject.lastModifiedLoginId;
    this.lastModifiedDate = auditObject.lastModifiedDate;
  }

  handleLastModifiedInfoUpdate(data: { lastModifiedDate: any; id: string }): void {
    // Handle the emitted lastModifiedInfo from child component
    this.lastModifiedDate = data.lastModifiedDate;
    // You can use the id for additional logic if needed
  }
  selectUnassignedWorkerRoles(
    allWorkerRoles: WorkerRole[],
    assignedRoles: AssignedRole[]
  ): WorkerRole[] {
    if (allWorkerRoles.length === assignedRoles.length) {
      return [];
    }

    return this.getAllWorkerRoles(allWorkerRoles, assignedRoles);
  }

  private getAllWorkerRoles(
    allWorkerRoles: WorkerRole[],
    assignedRoles: AssignedRole[]
  ): WorkerRole[] {
    // Extract IDs into a Set for O(1) lookup performance
    const assignedIds = new Set(assignedRoles.map((role) => role.reportRole.id));

    // Filter out any worker role whose ID exists in the assigned set
    return allWorkerRoles.filter((role) => !assignedIds.has(role.id));
  }
  private handleError(err: any): void {
    // Angular HttpClient returns errors in an 'error' object or the response itself
    if (err.statusOrganization === 400 || err.statusOrganization === 404) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = err.statusOrganization;
      this.returnMessage = err.statusTextOrganization;
    } else if (err.statusAllWorkerRoles === 400 || err.statusAllWorkerRoles === 404) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = err.statusAllWorkerRoles;
      this.returnMessage = err.statusAllWorkerRoles;
    } else {
      // Logic for statusAssignedWorkerRoles
      this.showAssignRoleView = true;
      this.hideMessage =
        err.statusAssignedWorkerRoles === 400 || err.statusAssignedWorkerRoles === 404;

      //   this.allWorkerRoles = this.buildDisplayOptionsAll(err.allWorkerRoles);
      this.orgnizationBase.organization = err.organization;
      this.businessAreaCode =
        this.orgnizationBase.organization?.organizationType?.businessArea?.code;
      this.shortName = this.orgnizationBase.organization?.shortName;

      if (!this.hideMessage) {
        this.returnCode = err.statusAssignedWorkerRoles;
        this.returnMessage = err.statusTextAssignedWorkerRoles;
      }
    }
  }

  openLookupOrganization(): void {
    this.hideMessage = true;
    this.invalidBusinessAreaCode = false;
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '82vw',
      maxWidth:'82vw',
      data: {
        title: 'Search and select acronym',
        button: 'Select acronym',
        //  message: 'Are you sure want to delete?',
        buttonsVisible: true,
        buttonText: {
          ok: 'Save',
          cancel: 'No',
        },
      },
    });

    dialogRef.componentInstance.onSearchClicked.subscribe((searchAcronym: string) => {
      // 4. Execute your local method!
      this.searchAcronym = searchAcronym;
     dialogRef.close();
      this.getOrganization(searchAcronym);
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.organizationType && result.shortName) {
        this.acronym = result.organizationType.businessArea.code + '/' + result.shortName;
        this.getOrganization(result.organizationType.businessArea.code + '/' + result.shortName);
      }
    });
  }

  showOrganization(selectedOrganization: any): void {
    //this.resetTimeout();
    this.selectAcronym(selectedOrganization.organizationId);
  }

  selectAcronym(organizationId: string): void {
    this.searchAcronym = '';
    this.allWorkerRoles = [];
    this.orgnizationBase = {
      organization: {},
      assignedRoles: [],
      availableRoles: [],
    };

    // Angular HttpClient returns Observables, so we use .subscribe()
    this.wrkOrgRoleAssignmentService.getOrganization('', '', organizationId).subscribe({
      next: (response) => {
        this.allWorkerRoles = this.selectUnassignedWorkerRoles(
          response.allWorkerRoles,
          response.assignedRoles
        );
        this.allWorkerRoles = this.buildDisplayOptionsAll(this.allWorkerRoles);
        this.orgnizationBase.availableRoles = this.allWorkerRoles;
        this.orgnizationBase.organization = response.organization;
        this.businessAreaCode = response.organization.organizationType.businessArea.code;
        this.shortName = response.organization.shortName;
        this.acronym = `${this.businessAreaCode}/${this.shortName}`;

        this.orgnizationBase.assignedRoles = response.assignedRoles;
        this.orgnizationBase.assignedRoles = this.buildDisplayOptionsAssigned(
          this.orgnizationBase.assignedRoles
        );
        this.hideMessage = true;
        this.showAssignRoleView = true;
      },
      error: (errResponse) => {
        this.handleError(errResponse);
      },
    });
  }

  private handleError1(res: any): void {
    // Nested logic from your AngularJS code
    if ([400, 404].includes(res.statusOrganization)) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = res.statusOrganization;
      this.returnMessage = res.statusTextOrganization;
    } else if ([400, 404].includes(res.statusAllWorkerRoles)) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = res.statusAllWorkerRoles;
      this.returnMessage = res.statusAllWorkerRoles;
    } else {
      // Logic for partial success/assigned roles error
      this.showAssignRoleView = true;
      this.allWorkerRoles = this.buildDisplayOptionsAll(res.allWorkerRoles);
      this.orgnizationBase.organization = res.organization;
      this.businessAreaCode = res.organization.organizationType.businessArea.code;
      this.shortName = res.organization.shortName;
      this.acronym = `${this.businessAreaCode}/${this.shortName}`;

      if ([400, 404].includes(res.statusAssignedWorkerRoles)) {
        this.hideMessage = true;
      } else {
        this.hideMessage = false;
        this.returnCode = res.statusAssignedWorkerRoles;
        this.returnMessage = res.statusTextAssignedWorkerRoles;
      }
    }
  }

  openLookupOrganization1() {
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '82vw',
      maxWidth:'82vw',
      data: {
        message: 'Are you sure want to delete?',
        buttonsVisible: true,
        buttonText: {
          ok: 'Save',
          cancel: 'No',
        },
      },
    });
    dialogRef.componentInstance.onSearchClicked.subscribe((searchAcronym: string) => {
      // 4. Execute your local method!
      this.searchAcronym = searchAcronym;
     dialogRef.close();
      this.getOrganization(searchAcronym);
    });
    dialogRef.afterClosed().subscribe((searchAcronym: string) => {
      this.searchAcronym = searchAcronym;
      if (searchAcronym) {
        this.getOrganization(searchAcronym);
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.acronym = result.shortName;
      this.base.newLocation.workerOrganization = {
        organization: {
          id: result.organizationId,
          shortName: result.shortName,
          organizationName: result.organizationName,
          businessAreaCode: result.organizationType.businessArea.code,
          acronym: result.organizationType.businessArea.code + '/' + result.shortName,
        },
      };

      this.orgnizationBase.organization = this.base.newLocation.workerOrganization.organization;
      this.searchAcronym = this.base.newLocation.workerOrganization.organization.acronym;

      this.wrkOrgRoleAssignmentService.getReportRoles().subscribe({
        next: (response) => {
          // Business logic remains similar but uses 'this'
          this.allWorkerRoles = response.results;
          const unassigned = this.selectUnassignedWorkerRoles(
            response.allWorkerRoles,
            response.assignedRoles
          );
          this.allWorkerRoles = this.buildDisplayOptionsAll(unassigned);

          this.orgnizationBase.organization = response.organization;
          this.orgnizationBase.assignedRoles = this.buildDisplayOptionsAssigned(
            response.assignedRoles
          );

          this.hideMessage = true;
          this.showAssignRoleView = true;

          // angular.copy replacement: Use structuredClone or spread operator
          this.acronym = structuredClone(this.searchAcronym);
          this.searchAcronym = '';
        },
        error: (errorResponse) => {
          this.handleError(errorResponse);
        },
      });

      this.wrkOrgRoleAssignmentService.getReportRoles().subscribe({
        next: (response) => {
          // Business logic remains similar but uses 'this'
          this.allWorkerRoles = response.results;
          const unassigned = this.selectUnassignedWorkerRoles(
            response.allWorkerRoles,
            response.assignedRoles
          );
          this.allWorkerRoles = this.buildDisplayOptionsAll(unassigned);

          this.orgnizationBase.organization = response.organization;
          this.orgnizationBase.assignedRoles = this.buildDisplayOptionsAssigned(
            response.assignedRoles
          );

          this.hideMessage = true;
          this.showAssignRoleView = true;

          // angular.copy replacement: Use structuredClone or spread operator
          this.acronym = structuredClone(this.searchAcronym);
          this.searchAcronym = '';
        },
        error: (errorResponse) => {
          this.handleError(errorResponse);
        },
      });

      //getOrganizationReportRoles
      this.showAssignRoleView = true;

      this.getRolesInfo(); // Show the assign role view after selecting an organization
    });
  }
  handleClear(): void {
    this.showAssignRoleView = false; // Hide the component
    this.orgnizationBase = null;
    this.noMatchFound = false;
    // Clear the search organization input field
    if (this.orgInput && this.orgInput.nativeElement) {
      this.orgInput.nativeElement.value = '';
    }
    // Also clear the base object's business area code
    if (this.base.newLocation.workerOrganization?.organization) {
      this.base.newLocation.workerOrganization.organization.businessAreaCode = '';
    }
    // Reset acronym
    this.acronym = '';
  }

  /**
   * Handles the save completion event from the child assign-role component
   *
   * Business Logic:
   * - Captures the save status and message
   * - If save was successful (status 200), immediately refresh the organization data
   * - Auto-hide success message after 5 seconds
   * - This ensures the parent component displays the latest data from the server
   *
   * @param event Save completion event with status and message
   */
  handleSaveComplete(event: { status: number; message: string }): void {
    this.returnCode = event.status;
    this.returnMessage = event.message;
    this.hideMessage = false;
    
    // If save was successful, auto-hide success message after 5 seconds
    // Note: Data refresh is now handled by the child component (assign-role.component.ts)
    // which calls refreshAllDataAfterSave() and updates the UI directly
    if (event.status === 200) {
      // Auto-hide success message after 5 seconds
      setTimeout(() => {
        this.hideMessage = true;
      }, 5000);
    }
  }

  /**
   * Handles the refresh search event from the child assign-role component
   *
   * Business Logic:
   * - Called when save is completed in the child component
   * - Adds a delay to allow database to commit changes before refreshing
   * - Calls the service's refreshAllDataAfterSave() method which makes all 5 required API calls in parallel
   * - Updates the UI with fresh data from the database
   * - Uses the search acronym to extract businessAreaCode and shortName
   *
   * @param event Refresh search event with searchAcronym
   */
  handleRefreshSearch(event: { searchAcronym: string }): void {
     // Validate that we have a valid acronym before calling search
    if (!event.searchAcronym || event.searchAcronym.trim() === '' || event.searchAcronym === '-') {
      console.warn('Invalid acronym received, cannot refresh search:', event.searchAcronym);
      return;
    }
    
    // Parse the search acronym to extract businessAreaCode and shortName
    const firstPart = event.searchAcronym.substring(0, 1);
    const secondPart = event.searchAcronym.substring(2).trim();
     // Add delay to allow database to commit changes before refreshing
    // This ensures we fetch the latest data from the database
    setTimeout(() => {
      // Call the service's refreshAllDataAfterSave which makes all 5 required API calls in parallel
      this.wrkOrgRoleAssignmentService.refreshAllDataAfterSave(
        firstPart,
        secondPart,
        this.reportRoleOrganizationId
      ).subscribe({
        next: (response) => {
          
          // Update the UI with fresh data
          const unassigned = this.selectUnassignedWorkerRoles(
            response.allWorkerRoles,
            response.assignedRoles
          );

          const organizationData =
            response.organizationDetails && response.organizationDetails.length > 0
              ? response.organizationDetails[0]
              : null;

          // Update the object reference to ensure the child component detects the change
          this.orgnizationBase = {
            ...this.orgnizationBase,
            organization: organizationData,
            assignedRoles: this.buildDisplayOptionsAssigned(response.assignedRoles),
            availableRoles: this.buildDisplayOptionsAll(unassigned),
          };
          this.hideMessage = true;
          this.allWorkerRoles = this.buildDisplayOptionsAll(unassigned);
        },
        error: (errorResponse) => {
          console.error('Error refreshing data after save:', errorResponse);
          this.handleError(errorResponse);
        },
      });
    }, 1000); // 1 second delay to allow DB commit
  }

  /**
   * Refreshes organization and roles data after save operations
   *
   * Business Logic:
   * - Called immediately after successful save in the child component
   * - Fetches fresh data from server for:
   *   1. All available report roles
   *   2. Organization details
   *   3. Assigned roles for the organization
   * - Updates the parent component's orgnizationBase object with fresh data
   * - Filters unassigned roles for the available roles list
   * - Rebuilds display options for proper UI formatting
   *
   * This ensures the parent component displays the latest data from the server
   * and keeps the UI in sync with the backend state.
   */
  private refreshOrganizationData(): void {
    // Note: Data refresh is now handled by the child component (assign-role.component.ts)
    // The child component calls refreshAllDataAfterSave() which makes all 5 required API calls
    // and updates the UI directly. The parent component receives the updated data via
    // ngOnChanges() when the @Input orgnizationBase is updated by the child component.
    // This method is kept for backward compatibility but is no longer actively used.
  }

  handleCancelNavigation(): void {
    // Navigate to the cancel page (dashboard/home)
    this.navigateToCancelPage(this.cancelPage);
  }

  private navigateToCancelPage(path: string): void {
    // First clear the component state
    this.showAssignRoleView = false;
    this.orgnizationBase = null;
    this.acronym = '';
    
    // Clear the search organization input field
    if (this.orgInput && this.orgInput.nativeElement) {
      this.orgInput.nativeElement.value = '';
    }
    
    // Clear the base object's business area code
    if (this.base.newLocation.workerOrganization?.organization) {
      this.base.newLocation.workerOrganization.organization.businessAreaCode = '';
    }
    
    // Navigate to the specified cancel page
    this.router.navigate([path]);
  }

  changeLocation(type: string, val: any) {
    const locationSelectDialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '90vw',
      height: '75vh',
      data: val,
    });

    locationSelectDialogRef.afterClosed().subscribe((result: any) => {
      // Catch variable data emitted from the dialog here
      if (result) {
        if (type === 'mail') {
          this.assignMentWorker.patchValue({
            mailStopLocationcode: result.building?.code || '',
            mailStopLocationFloorNumber: result.building?.floorNumber || '',
            mailStopLocationcorridorId: result.corridorId || '',
            mailStopLocationsuiteId: result.suiteId || '',
            mailStopLocationroomId: result.roomId || '',
            mailStopLocationzoneId: result.zoneId || '',
          });
        } else {
          this.assignMentWorker.patchValue({
            code: result.building?.code || '',
            floorNumber: result.building?.floorNumber || '',
            corridorId: result.corridorId || '',
            suiteId: result.suiteId || '',
            roomId: result.roomId || '',
            zoneId: result.zoneId || '',
          });
        }
      }
    });
  }

  
   getLastModifiedRole(organizationId: string) :Observable<any> {
    const url = 'organization-report-roles?includeInactive=true&limit=1&organizationId=' + organizationId + '&skip=0&sortColumn=lastModifiedDate&sortOrder=desc';
    return this.httpService.get(url).pipe(catchError(async (error) => this.handleError(error)));
  }
}
