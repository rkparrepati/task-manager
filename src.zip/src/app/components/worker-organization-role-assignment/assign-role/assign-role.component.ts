import {
  Component,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ChangeDetectorRef,
} from '@angular/core';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { WorkerOrganizationRoleAssignmentServiceService } from '../worker-organization-role-assignment-service.service';
import { catchError, switchMap, throwError, forkJoin } from 'rxjs';
import { of } from 'rxjs';

import { ActivatedRoute, Router } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { CancelConfirmDialogComponent } from '../cancel-confirm-dialog/cancel-confirm-dialog.component';
import { HttpService } from 'src/app/services/http.service';
@Component({
  selector: 'app-assign-role',
  templateUrl: './assign-role.component.html',
  styleUrls: ['./assign-role.component.scss'],
})
export class AssignRoleComponent implements OnInit, OnChanges {
  //data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  // Define properties that were previously on vm
  @Input() orgnizationBase: any;
  
  /**
   * Detects changes to input properties from parent component
   *
   * Business Logic:
   * - Monitors changes to orgnizationBase input
   * - When parent updates orgnizationBase with fresh data after save:
   *   1. Clears local selection arrays
   *   2. Triggers change detection to update UI
   *   3. Logs the update for debugging
   *
   * This ensures the child component displays the latest data from the server
   * after the parent's refreshOrganizationData() completes.
   */
  ngOnChanges(changes: SimpleChanges) {
    if (changes['orgnizationBase']) {
      const change = changes['orgnizationBase'];
      
      // Only process if this is not the initial value
      if (!change.firstChange && change.currentValue) {
      
        // Clear selection arrays to reset UI state
        this.orgnizationBase.selectedAvailableRoles = [];
        this.orgnizationBase.selectedAssignedRoles = [];
        this.selectedAvailableRoles = [];
        this.selectedAssignedRoles = [];
        
        // Trigger explicit change detection to update UI with fresh data
        this.cdr.detectChanges();
       }
    }
  }
  @Output() clear = new EventEmitter<void>();
  @Output() saveComplete = new EventEmitter<{ status: number; message: string }>();
  @Output() cancelNavigation = new EventEmitter<void>();
  @Output() lastModifiedInfo = new EventEmitter<{ lastModifiedDate: any; id: string }>();
  @Output() refreshSearch = new EventEmitter<{ searchAcronym: string }>();
  //orgnizationBase: any = { organization: {}, assignedRoles: [] };
  allWorkerRoles: any[] = [];
  userRoles: string[] = []; // e.g., ['InfraAdmin']

  // Selection models for the <select multiple>
  selectedAvailableRoles: any[] = [];
  selectedAssignedRoles: any[] = [];

  searchAcronym: string = '';
  showAssignRoleView: boolean = false;
  hideMessage: boolean = true;
  returnCode: number | null = null;
  returnMessage: string = '';
  @Input() businessAreaCode: string = '';
  @Input() shortName: string = '';
  @Input() acronym: string = '';

  @Input() lastModifiedLoginId: string = '';
  @Input() lastModifiedDate: any;
  tempSelectedAllWorkerRoles: any[] = [];
  tempSelectedAssignedWorkerRoles: any[] = [];
  initialAssignedRoles: any[] = [];

  constructor(
    //private dialog: MatDialog,
    private orgService: OrganizationService,
    private wrkOrgRoleAssignmentService: WorkerOrganizationRoleAssignmentServiceService,
    private route: ActivatedRoute,
    private router: Router,
    private httpService: HttpService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Initialization logic: fetch roles and organization data here
  }

  /**
   * Moves roles between lists (single or multiple selected roles)
   *
   * Business Logic:
   * - When moving FROM available TO assigned: wrap flat roles into nested structure
   * - When moving FROM assigned TO available: unwrap nested roles into flat structure
   * - Uses immutable operations (spread operator, filter, map) for change detection
   * - Clears selection after move to reset UI state
   * - Does NOT persist changes - user must click Save button
   *
   * @param selectedRoles The roles currently highlighted in the select box
   * @param from Either 'all' (available) or 'assigned'
   * @param to Either 'all' (available) or 'assigned'
   */
  moveWorkerRole(selectedRoles: any[], from: string, to: string): void {
    if (!selectedRoles || selectedRoles.length === 0) return;

    // 1. Create local copies to maintain immutability (Standard for 2026 Change Detection)
    let newAvailable = [...this.orgnizationBase.availableRoles];
    let newAssigned = [...this.orgnizationBase.assignedRoles];

    if (from === 'all') {
      // --- MOVE FROM AVAILABLE TO ASSIGNED ---
      // We must WRAP the flat available role into the nested reportRole structure
      // so that [innerHTML]="workerRole.reportRole.displayItem" does not crash.
      const wrappedRoles = selectedRoles.map((role: any) => ({
        reportRole: {
          ...role, // Contains id, value, displayItem, etc.
        },
        audit: role.audit || null,
        lifeCycle: role.lifeCycle || null,
      }));

      newAssigned = [...newAssigned, ...wrappedRoles];

      // Remove from available by matching ID
      newAvailable = newAvailable.filter(
        (role: any) => !selectedRoles.some((selected: any) => selected.id === role.id)
      );
    } else {
      // --- MOVE FROM ASSIGNED TO AVAILABLE ---
      selectedRoles.forEach((assignedRole: any) => {
        // Reconstruct the flat workerRole object as per your AngularJS reconstruction logic
        const flatWorkerRole = {
          id: assignedRole.reportRole?.id,
          value: assignedRole.reportRole?.value,
          description: assignedRole.reportRole?.description,
          displayItem: assignedRole.reportRole?.displayItem, // Ensure this exists for the UI
          audit: assignedRole.audit,
          lifeCycle: assignedRole.lifeCycle,
        };

        // Add the flat object back to available list
        newAvailable.push(flatWorkerRole);

        // Remove from assigned list by matching the nested reportRole.id
        newAssigned = newAssigned.filter(
          (role: any) => role.reportRole?.id !== assignedRole.reportRole?.id
        );
      });
    }

    // 2. Reassign references to trigger UI Updates
    this.orgnizationBase.availableRoles = newAvailable;
    this.orgnizationBase.assignedRoles = newAssigned;

    // 3. Clear selection arrays to reset the UI state
    this.orgnizationBase.selectedAvailableRoles = [];
    this.orgnizationBase.selectedAssignedRoles = [];

    // 4. Do NOT call save here - user must click the Save button to persist changes
    // The roles are now moved in the UI only, waiting for user to click Save
  }

  /**
   * Moves ALL roles between lists (bulk operation)
   *
   * Business Logic:
   * - Delegates to moveWorkerRole() with all items from source list
   * - Simpler than legacy backward-iteration approach
   * - Reuses single-move logic for consistency
   *
   * @param from Either 'all' (available) or 'assigned'
   * @param to Either 'all' (available) or 'assigned'
   */
  moveAllWorkerRoles(from: string, to: string): void {
    if (from === 'all') {
      // Move all available roles to assigned
      this.moveWorkerRole([...this.orgnizationBase.availableRoles], 'all', 'assigned');
    } else {
      // Move all assigned roles to available
      this.moveWorkerRole([...this.orgnizationBase.assignedRoles], 'assigned', 'all');
    }
  }

  confirmClearOrganization(): void {
    this.clear.emit();
  }

  exportDataCallback(): void {
    // Build URL with query parameters - matching legacy code format
    const url = `${this.httpService.DOMAIN}/workerOrganizationRoleExcelReport?organizationId=${this.orgnizationBase.organization?.organizationId}&sortColumn=reportRoleValue&sortOrder=asc&businessAreaCode=${this.businessAreaCode}&shortName=${this.shortName}`;
    
    const orgName = this.orgnizationBase.organization?.organizationName || 'Organization';
    const fileName = `${orgName}_${this.businessAreaCode}-${this.shortName}.xls`;
    
    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (blob: Blob) => {
        // Verify we received a valid blob
        if (!blob || blob.size === 0) {
          return;
        }

        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(blob, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = blobUrl;
          link.download = fileName;
          link.style.display = 'none';
          
          // Append to body, click, and remove
          document.body.appendChild(link);
          link.click();
          
          // Clean up
          setTimeout(() => {
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl);
          }, 100);
        }
      },
      error: (error) => {
        // You can add user-facing error handling here if needed
        this.returnCode = error.status || 500;
        this.returnMessage = 'Failed to download Excel report';
        this.hideMessage = false;
      }
    });
  }

  hideAssignRoleView(): void {
    const dialogRef = this.dialog.open(CancelConfirmDialogComponent, {
      width: '500px',        // Sets the fixed width (reduced from 600px)
      maxWidth: '500px',     // Prevents it from expanding
      minWidth: '500px',
      minHeight: '220px',    // Increased height
      data: this.orgnizationBase.organization,
      disableClose: true, // Replicates modal behavior
      panelClass: 'cancel-confirm-dialog',
    });

    dialogRef.afterClosed().subscribe({
      next: (confirmCancel: boolean) => {
        if (confirmCancel) {
          // Emit event to parent with the cancel page path
          this.cancelNavigation.emit();
        }
      },
      error: (reason) => {
      },
    });
  }
  /**
   * Main save method - handles save and refresh of role assignments
   *
   * 6-Step Orchestrated Flow using RxJS switchMap for sequential execution:
   *
   * Step 1: Fetch current server state
   *   - Get existing assigned roles from server
   *   - This is the source of truth for comparison
   *
   * Step 2: Intelligent Diffing
   *   - Compare current local state with server state
   *   - Identify roles to ASSOCIATE (in local but not in server)
   *   - Identify roles to DISASSOCIATE (in server but not in local)
   *   - Uses Set for O(1) lookup performance
   *
   * Step 3: Execute Associate Operations
   *   - Call associateReportRole() with new roles
   *   - Service uses forkJoin() for parallel batch processing
   *   - Skips if no new roles to associate
   *
   * Step 4: Execute Disassociate Operations
   *   - Call disassociateReportRole() with removed roles
   *   - Service uses forkJoin() for parallel batch processing
   *   - Skips if no roles to disassociate
   *
   * Step 5: Refresh Fresh Data from Server
   *   - Fetch all available roles, assigned roles, and organization details
   *   - Ensures UI is always in sync with server state
   *   - Includes error fallback to prevent cascading failures
   *
   * Step 6: Update UI with Refreshed Data
   *   - Clear all temporary tracking arrays
   *   - Populate UI with fresh server data
   *   - Build display options (padding, formatting)
   *   - Filter unassigned roles
   *   - Extract organization data (handles array/object responses)
   *   - Emit success event and trigger change detection
   *
   * Error Handling:
   *   - Catches errors at each stage
   *   - Provides fallback data to prevent UI breakage
   *   - Emits error events to parent component
   *   - Logs errors for debugging
   */
  saveWorkerRoleAssociation(): void {
    this.resetTimeout();
    const org = this.orgnizationBase.organization;
    const currentAssignedRoles = this.orgnizationBase.assignedRoles;

    // Step 1: Get existing roles from server to compare
    this.wrkOrgRoleAssignmentService
      .getOrganizationReportRoles(org.organizationId)
      .pipe(
        // Step 2: Identify roles to associate and disassociate
        switchMap((existingRolesResponse: any) => {
          this.initialAssignedRoles = existingRolesResponse.results || [];

          // Find roles to associate (in current but not in existing)
          // Using Set for O(1) lookup performance
          const existingIds = new Set(
            this.initialAssignedRoles.map((role: any) => role.reportRole?.id)
          );
          this.tempSelectedAllWorkerRoles = currentAssignedRoles.filter(
            (role: any) => !existingIds.has(role.reportRole?.id)
          );

          // Find roles to disassociate (in existing but not in current)
          // Using Set for O(1) lookup performance
          const currentIds = new Set(
            currentAssignedRoles.map((role: any) => role.reportRole?.id)
          );
          this.tempSelectedAssignedWorkerRoles = this.initialAssignedRoles.filter(
            (role: any) => !currentIds.has(role.reportRole?.id)
          );
          // Step 3: Execute associate operations
          if (this.tempSelectedAllWorkerRoles.length > 0) {
            return this.wrkOrgRoleAssignmentService.associateReportRole(
              org,
              this.tempSelectedAllWorkerRoles
            );
          } else {
            return of({ status: 200, statusText: 'No new roles to associate' });
          }
        }),
        // Step 4: Execute disassociate operations
        switchMap((associateResponse: any) => {
          if (this.tempSelectedAssignedWorkerRoles.length > 0) {
            return this.wrkOrgRoleAssignmentService.disassociateReportRole(
              org,
              this.tempSelectedAssignedWorkerRoles
            );
          } else {
            return of({ status: 200, statusText: 'No roles to disassociate' });
          }
        }),
        catchError((err) => {
          // Handle errors from save operations
          this.hideMessage = false;
          const errorObj = err.error || err;
          this.returnCode = errorObj.status || err.status || 500;
          this.returnMessage =
            errorObj.statusText || errorObj.message || 'An error occurred while saving';

          console.error('Save operation failed:', this.returnMessage, err);

          this.saveComplete.emit({
            status: this.returnCode || 500,
            message: this.returnMessage,
          });

          this.cdr.detectChanges();
          return of({
            isSaveError: true,
          });
        })
      )
      .subscribe({
        next: (response: any) => {
          // Handle save errors
          if (response.isSaveError) {
            return;
          }

          // Step 5: Emit event to parent component to trigger basic search refresh
          // Use the acronym from the parent component (passed via @Input) or construct from organization
          const acronymToEmit = this.acronym ||
            (org.organizationType?.businessArea?.code + '-' + org.shortName);
          
          this.refreshSearch.emit({
            searchAcronym: acronymToEmit,
          });

          // Step 6: Emit success event to parent component
          this.saveComplete.emit({
            status: 200,
            message: 'Successfully updated worker organization role assignment(s)',
          });

          // Step 7: Trigger explicit change detection for UI update
          this.cdr.detectChanges();
        },
        error: (err) => {
          // Handle subscription errors
          console.error('Subscription error in saveWorkerRoleAssociation:', err);
          this.cdr.detectChanges();
        },
      });
  }

  /**
   * Updates the status message displayed to the user
   * @param resp Response object containing status and statusText
   */
  private updateStatus(resp: any): void {
    this.returnCode = resp.status;
    this.returnMessage = resp.statusText;
    this.hideMessage = false;
  }

  /**
   * Resets the session timeout timer
   * Placeholder for timeout management logic
   */
  private resetTimeout() {
    // TODO: Implement timeout reset logic if needed
  }
  /**
   * Builds display options for assigned roles (nested structure)
   *
   * Formatting Logic:
   * - Pads role value to fixed width (20 chars) with non-breaking spaces
   * - Appends role description
   * - Applies HTML decoding for special characters
   * - Updates displayItem property for UI rendering
   *
   * @param workerRoles Array of assigned roles with nested reportRole structure
   * @returns Formatted roles with displayItem property set
   */
  buildDisplayOptionsAssigned(workerRoles: any[]): any[] {
    const maxlength = 20;
    workerRoles.forEach((role) => {
      // Use non-breaking spaces (\u00A0) to prevent HTML parser from collapsing spaces
      const paddedValue = role.reportRole.value.padEnd(maxlength, '\u00A0');
      const rawString = `${paddedValue}${role.reportRole.description}`;
      // Apply htmlDecode to match the behavior of buildDisplayOptionsAll
      role.reportRole.displayItem = this.htmlDecode(rawString);
    });
    return workerRoles;
  }
  /**
   * Filters out already assigned roles from the full list of worker roles
   *
   * Business Logic:
   * - Compares all available roles against assigned roles
   * - Returns only roles that are NOT currently assigned
   * - Used to populate the "Available Roles" select box
   * - Optimization: If counts match, assumes all are assigned and returns empty array
   *
   * @param allWorkerRoles The complete list of available roles (flat structure)
   * @param assignedRoles The list of roles already assigned to the organization (nested structure)
   * @returns Array of unassigned roles (flat structure)
   */
  private selectUnassignedWorkerRoles(allWorkerRoles: any[], assignedRoles: any[]): any[] {
    // Optimization: If the counts are the same, we assume everything is assigned
    if (allWorkerRoles.length === assignedRoles.length) {
      return [];
    }

    // Filter the full list: only keep roles whose ID is NOT found in the assignedRoles list
    // Note: allWorkerRoles are flat (id property), assignedRoles are nested (reportRole.id)
    return allWorkerRoles.filter(
      (role) => !assignedRoles.some((assigned) => assigned.reportRole.id === role.id)
    );
  }
  /**
   * Builds display options for available roles (flat structure)
   *
   * Formatting Logic:
   * - Pads role value to fixed width (20 chars) with non-breaking spaces
   * - Appends role description
   * - Applies HTML decoding for special characters
   * - Updates displayItem property for UI rendering
   *
   * @param workerRoles Array of available roles with flat structure
   * @returns Formatted roles with displayItem property set
   */
  private buildDisplayOptionsAll(workerRoles: any[]): any[] {
    const maxlength = 20;

    workerRoles.forEach((workerRole) => {
      // Use non-breaking spaces (\u00A0) to prevent HTML parser from collapsing spaces
      const paddedValue = workerRole.value.padEnd(maxlength, '\u00A0');

      // Combine with non-breaking spaces
      const rawString = `${paddedValue}${workerRole.description}`;

      // htmlDecode handles any HTML entities in the description
      workerRole.displayItem = this.htmlDecode(rawString);
    });

    return workerRoles;
  }

  /**
   * Decodes HTML entities in a string
   *
   * Purpose:
   * - Converts HTML entities (e.g., &, <) to their character equivalents
   * - Ensures proper display of special characters in role descriptions
   * - Uses DOMParser for safe HTML parsing
   *
   * @param input HTML string with potential entities
   * @returns Decoded plain text string
   */
  private htmlDecode(input: string): string {
    const doc = new DOMParser().parseFromString(input, 'text/html');
    return doc.documentElement.textContent || '';
  }

  /**
   * Compares two roles for equality in ngFor trackBy and compareWith
   *
   * Purpose:
   * - Used by [(ngModel)] with [compareWith] directive in select elements
   * - Ensures proper role selection/deselection in multi-select boxes
   * - Compares by ID for objects, by value for primitives
   *
   * @param item1 First role object or primitive
   * @param item2 Second role object or primitive
   * @returns true if roles are equal, false otherwise
   */
  compareRoles(item1: any, item2: any): boolean {
    return item1 && item2 ? item1.id === item2.id : item1 === item2;
  }
  getRolesInfo(): void {
    // Reset state
    this.allWorkerRoles = [];
    this.orgnizationBase = {
      organization: {},
      assignedRoles: [],
      availableRoles: [],
      selectedAvailableRoles: [],
      selectedAssignedRoles: [],
    };

    const firstPart = this.searchAcronym.substring(0, 1);
    const secondPart = this.searchAcronym.substring(2).trim();

    this.orgService.getOrganizationByAcronym(this.searchAcronym, true).subscribe({
      next: (response) => {
        // Business logic remains similar but uses 'this'
        // const unassigned = this.selectUnassignedWorkerRoles(response.allWorkerRoles, response.assignedRoles);
        // this.allWorkerRoles = this.buildDisplayOptionsAll(unassigned);

        // this.orgnizationBase.organization = response.organization;
        // this.orgnizationBase.assignedRoles = this.buildDisplayOptionsAssigned(response.assignedRoles);

        this.hideMessage = true;
        this.showAssignRoleView = true;

        // angular.copy replacement: Use structuredClone or spread operator
        this.acronym = structuredClone(this.searchAcronym);
        this.searchAcronym = '';
      },
      error: (errorResponse) => {
        this.handleError(errorResponse);
      },
    });
  }

  private handleError(err: any): void {
    // Angular HttpClient returns errors in an 'error' object or the response itself
    if (err.statusOrganization === 400 || err.statusOrganization === 404) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = err.statusOrganization;
      this.returnMessage = err.statusTextOrganization;
    } else if (err.statusAllWorkerRoles === 400 || err.statusAllWorkerRoles === 404) {
      this.showAssignRoleView = false;
      this.hideMessage = false;
      this.returnCode = err.statusAllWorkerRoles;
      this.returnMessage = err.statusAllWorkerRoles;
    } else {
      // Logic for statusAssignedWorkerRoles
      this.showAssignRoleView = true;
      this.hideMessage =
        err.statusAssignedWorkerRoles === 400 || err.statusAssignedWorkerRoles === 404;

      //   this.allWorkerRoles = this.buildDisplayOptionsAll(err.allWorkerRoles);
      this.orgnizationBase.organization = err.organization;
      this.businessAreaCode =
        this.orgnizationBase.organization?.organizationType?.businessArea?.code;
      this.shortName = this.orgnizationBase.organization?.shortName;

      if (!this.hideMessage) {
        this.returnCode = err.statusAssignedWorkerRoles;
        this.returnMessage = err.statusTextAssignedWorkerRoles;
      }
    }
  }
}


