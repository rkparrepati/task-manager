import { Injectable } from '@angular/core';
//import { Organization, OrganizationResponse, OrganizationType } from '../models/organization.model';
import { HttpService } from 'src/app/services/http.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { UtilityService } from 'src/app/services/utility.service';
import { forkJoin, Observable, of, throwError } from 'rxjs';
import { catchError, switchMap, map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class WorkerOrganizationRoleAssignmentServiceService {
  constructor(
    private utilityService: UtilityService,
    private httpService: HttpService,
    private http: HttpClient
  ) {}

  workerOrganizationRoleExcelReport(
    organizationId: string,
    sortColumn: string,
    sortOrder: string,
    businessAreaCode: string,
    shortName: string
  ): Observable<Blob> {
    const headers = new HttpHeaders().set('Accept', 'application/vnd.ms-excel');
    const url = `/workerOrganizationRoleExcelReport?organizationId=${organizationId}&sortColumn=${sortColumn}&sortOrder=${sortOrder}&businessAreaCode=${businessAreaCode}&shortName=${shortName}`;
    return this.httpService.getExcelReport(url);
  }
  getOrganization(
    businessAreaCode: string,
    shortName: string,
    organizationId: any
  ): Observable<any> {
    let responseOrganizationGet: any = {};

    // 1. First Call: getReportRoles
    return this.getReportRoles().pipe(
      switchMap((response) => {
        responseOrganizationGet = {
          allWorkerRoles: response.results, // HttpClient automatically extracts 'data'
          statusAllWorkerRoles: 200, // Angular HttpClient doesn't wrap success in a full response by default
          statusTextAllWorkerRoles: 'OK',
        };
        // 2. Second Call: getOrganizationDetails
        return this.getOrganizationDetails(businessAreaCode, shortName, organizationId);
      }),
      catchError((error) => {
        // Handle error from getReportRoles
        return throwError(() => ({
          statusAllWorkerRoles: error.status,
          statusTextAllWorkerRoles: error.statusText,
        }));
      }),
      switchMap((orgResponse) => {
        // Extract organization ID from response
        let orgId = organizationId;
        if (orgResponse && orgResponse.results && orgResponse.results[0]) {
          orgId = orgResponse.results[0].organizationId;
        } else if (orgResponse && orgResponse.organizationId) {
          orgId = orgResponse.organizationId;
        }
        
        responseOrganizationGet.organization = orgResponse;
        // 3. Third Call: getOrganizationReportRoles
        return this.getOrganizationReportRoles(orgId);
      }),
      map((reportRolesResponse) => {
        // Success handler for the entire chain
        if (reportRolesResponse) {
          responseOrganizationGet.assignedRoles = reportRolesResponse.results;
          responseOrganizationGet.statusAssignedWorkerRoles = 200;
          responseOrganizationGet.statusTextAssignedWorkerRoles = 'OK';
          return responseOrganizationGet;
        }
        throw new Error('No report roles');
      }),
      catchError((error) => {
        // Detailed error branching similar to original logic
        if (!responseOrganizationGet.organization) {
          responseOrganizationGet.statusOrganization = error.status;
          responseOrganizationGet.statusTextOrganization = 'No organizations found.';
        } else {
          responseOrganizationGet.statusAssignedWorkerRoles = error.status;
          responseOrganizationGet.statusTextAssignedWorkerRoles =
            error.error?.message || 'Error fetching roles';
        }
        return throwError(() => responseOrganizationGet);
      })
    );
  }

  // // Mock methods for context - replace with actual http calls
  getReportRoles(): Observable<any> {
    // Define query parameters using HttpParams
    const params = {
      includeInactive: 'false',
      sortColumn: 'value',
      sortOrder: 'asc',
    };

    return this.httpService
      .get(`/references/report-roles?${this.httpService.mergeQueryParams(params)}`)
      .pipe(catchError((error) => this.handleError(error)));
  }

  getOrganizationDetails(
    businessAreaCode: string,
    shortName: string,
    organizationId?: string | number
  ): Observable<any> {
    if (organizationId) {
      // Angular HttpClient.get returns the body (response.data) by default
      return this.httpService.get(`/organizations/${organizationId}`);
    } else {
      const params = {
        businessAreaCode: businessAreaCode,
        shortName: shortName,
      };

      return this.httpService
        .get(`/organizations?${this.httpService.mergeQueryParams(params)}`)
        .pipe(
          // map(response => response.results?.[0]), // Extract the first organization from results
          catchError((error) => this.handleError(error))
        );
    }
  }

  getLastModifiedRole(organizationId: string | number): Observable<any> {
    const params = {
      organizationId: organizationId.toString(),
      includeInactive: 'true',
      sortColumn: 'lastModifiedDate',
      sortOrder: 'desc',
      limit: '1',
      skip: '0',
    };
    return this.httpService
      .get(`/organization-report-roles?${this.httpService.mergeQueryParams(params)}`)
      .pipe(catchError((error) => this.handleError(error)));
  }

  /**
   * Gets list of worker roles associated to an organization.
   */
  getOrganizationReportRoles(organizationId: string | number): Observable<any> {
    const params = {
      organizationId: organizationId.toString(),
      sortOrder: 'asc',
      sortColumn: 'reportRoleValue',
    };

    return this.httpService
      .get(`/organization-report-roles?${this.httpService.mergeQueryParams(params)}`)
      .pipe(catchError((error) => this.handleError(error)));
  }

  /**
   * Error handling utility
   * @param error - Error object
   * @param customMessage - Custom error message
   * @returns Observable error
   */
  private handleError(error: any, customMessage?: string): Observable<never> {
    const errorMessage = customMessage || error?.error?.message || 'An error occurred';
    return throwError(() => ({
      status: error?.status || 500,
      message: errorMessage,
      accessDenied: error?.status === 403,
      data: error?.error,
    }));
  }

  associateReportRole(organization: any, reportRoleList: any[]): Observable<any> {
    const requests: Observable<any>[] = reportRoleList.map((item) => {
      // Access the nested role object from your input data structure
      const roleData = item.reportRole;

      const payload = {
        organization: {
          id: organization.organizationId,
          name: organization.organizationName,
        },
        reportRole: {
          // Map correctly from the nested object
          id: roleData.id,
          value: roleData.value,
          description: roleData.description,
        },
        lifecycle: {
          // Check lifecycle on the nested roleData object
          beginDate: roleData.lifecycle
            ? this.utilityService.adjustDateFormatter(roleData.lifecycle.beginDate)
            : this.utilityService.adjustDateFormatter(
                this.utilityService.dateFormatter(new Date())
              ),
          endDate: roleData.lifecycle?.endDate
            ? this.utilityService.adjustDateFormatter(roleData.lifecycle.endDate)
            : null,
        },
      };

      // Use modern HttpClient or updated Auth service
      return this.httpService.post(`/organization-report-roles`, payload);
    });

    return forkJoin(requests).pipe(
      map(() => ({
        status: 201,
        statusText: 'Successfully updated worker organization role assignment(s)',
      })),
      catchError((error) => {
        return throwError(() => ({
          status: error.status,
          statusText: 'Failed organization worker roles assignment(s)',
        }));
      })
    );
  }

  disassociateReportRole(organization: any, reportRoleList: any[]): Observable<any> {
    const requests = reportRoleList.map((role) =>
      this.httpService.delete(`/organization-report-roles/${role.organizationReportRoleId}`)
    );

    return forkJoin(requests).pipe(
      map(() => {
        // Clear cache for organization report roles to ensure fresh data on next fetch
        this.httpService.clearCacheForPath(
          `/organization-report-roles?organizationId=${organization.organizationId}&sortOrder=asc&sortColumn=reportRoleValue`
        );
        this.httpService.clearCacheForPath(
          `/organization-report-roles?organizationId=${organization.organizationId}&includeInactive=true&sortColumn=lastModifiedDate&sortOrder=desc&limit=1&skip=0`
        );
        return {
          status: 201,
          statusText: 'Successfully updated worker organization role assignment(s)',
        };
      }),
      catchError((error) => {
        const message =
          'Worker role(s) could not be removed from organization. ' +
          'Worker role(s) may be associated to workers. Contact CEDR administrator for details.';
        return throwError(() => ({
          status: error.status,
          statusText: message,
        }));
      })
    );
  }

  /**
   * Refreshes all data after save operations
   *
   * Makes 5 parallel API calls to fetch fresh data:
   * 1. Get organization details by businessAreaCode and shortName
   * 2. Get all available report roles
   * 3. Get organization details by organizationId
   * 4. Get assigned roles for the organization
   * 5. Get last modified role info
   *
   * @param businessAreaCode Business area code (e.g., 'P')
   * @param shortName Organization short name (e.g., '1623')
   * @param organizationId Organization ID (e.g., '100260')
   * @returns Observable with all fresh data
   */
  refreshAllDataAfterSave(
    businessAreaCode: string,
    shortName: string,
    organizationId: string
  ): Observable<any> {
    // Make all 5 API calls in parallel using forkJoin
    // IMPORTANT: Pass false as second parameter to disable caching and get fresh data from server
    return forkJoin({
      // Call 1: Get organization by businessAreaCode and shortName with root=false
      organizationByAcronym: this.httpService.get(
        `/organizations?root=false&businessAreaCode=${businessAreaCode}&shortName=${shortName}&includeInactive=false`,
        false // Disable cache to get fresh data
      ).pipe(catchError(() => of({ results: [] }))),

      // Call 2: Get all available report roles
      allReportRoles: this.httpService.get(
        `/references/report-roles?includeInactive=false&sortColumn=value&sortOrder=asc`,
        false // Disable cache to get fresh data
      ).pipe(catchError(() => of({ results: [] }))),

      // Call 3: Get organization details by businessAreaCode and shortName
      organizationDetails: this.httpService.get(
        `/organizations?businessAreaCode=${businessAreaCode}&shortName=${shortName}`,
        false // Disable cache to get fresh data
      ).pipe(catchError(() => of({ results: [] }))),

      // Call 4: Get assigned roles for the organization
      assignedRoles: this.httpService.get(
        `/organization-report-roles?organizationId=${organizationId}&sortOrder=asc&sortColumn=reportRoleValue`,
        false // Disable cache to get fresh data
      ).pipe(catchError(() => of({ results: [] }))),

      // Call 5: Get last modified role info
      lastModifiedRole: this.httpService.get(
        `/organization-report-roles?organizationId=${organizationId}&includeInactive=true&sortColumn=lastModifiedDate&sortOrder=desc&limit=1&skip=0`,
        false // Disable cache to get fresh data
      ).pipe(catchError(() => of({ results: [] }))),
    }).pipe(
      map((responses: any) => {
        // Combine all responses into a single object
        return {
          organizationByAcronym: responses.organizationByAcronym?.results || [],
          allWorkerRoles: responses.allReportRoles?.results || [],
          organizationDetails: responses.organizationDetails?.results || [],
          assignedRoles: responses.assignedRoles?.results || [],
          lastModifiedRole: responses.lastModifiedRole?.results || [],
          status: 200,
          statusText: 'Data refreshed successfully',
        };
      }),
      catchError((error) => {
        console.error('Error refreshing data after save:', error);
        return throwError(() => ({
          status: error.status || 500,
          statusText: 'Error refreshing data',
          organizationByAcronym: [],
          allWorkerRoles: [],
          organizationDetails: [],
          assignedRoles: [],
          lastModifiedRole: [],
        }));
      })
    );
  }
}
