import { Component, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'src/app/services/app.service';
import { LocationService } from '../location/location.service';
import { DatePipe } from '@angular/common';
import { LocationMassUploadSuccessModalComponent } from '../location/location-mass-upload-success-modal/location-mass-upload-success-modal.component';
import { LocationMassUploadErrorModalComponent } from '../location/location-mass-upload-error-modal/location-mass-upload-error-modal.component';
import { BuildingManagementService } from '../building-management/building-management.service';

@Component({
  selector: 'app-location-mass-upload',
  templateUrl: './location-mass-upload.component.html',
  styleUrls: ['./location-mass-upload.component.scss'],
  providers: [DatePipe],
})
export class LocationMassUploadComponent {
  constructor(
    private locationService: LocationService,
    private appService: AppService,
    private datePipe: DatePipe,
    private buildingService: BuildingManagementService
  ) {}
  dialog = inject(MatDialog);
  importFile: File | null = null;
  purposeId: number = 0;
  message: string = '';
  
  private messages = {
    buildingMissing: 'Building name/code is missing. ',
    floorMissing: 'Floor number is missing. ',
    purposeMissing: 'Location purpose is missing. ',
    startDateMissing: 'Start date is missing. ',
    buildingInvalid: 'Building is not valid. ',
    locationExists: 'Location already exists. ',
    invalidDate: 'Location start date must be after building start date. ',
    roomRequired: 'Room is required to create new location with a new floor. ',
    locationPurposeInvalid: 'Location purpose is not valid. '
  };

  sendFile(event: Event) {
    this.message = '';
    const element = event.currentTarget as HTMLInputElement;
    const file: any = element?.files ? element.files[0] : null;
    this.importFile = file;
  }

  downloadTemplate() {
    const link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/uploads/LocationsMassUpload.csv';
    link.download = 'LocationsMassUpload.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  async parseLine(line: string, row: number): Promise<any> {
    const columns = line.split(',');
    if (columns[0].length === 0 && columns.length === 1) {
      return null;
    }

    // Trim and uppercase first 6 columns
    for (let index = 0; index < 6; index++) {
      if (columns[index]) {
        columns[index] = columns[index].toUpperCase().trim();
      }
    }

    // Validate required fields first
    const errorMessage = this.validateDetails(columns[0], columns[1], columns[6], columns[7]);
    
    const locationDetail: any = {
      row: row + 1,
      location: {
        building: columns[0] || null,
        floor: columns[1] || null,
        corridor: columns[2] || null,
        suite: columns[3] || null,
        room: columns[4] || null,
        zone: columns[5] || null,
        purpose: columns[6] || null,
        startDate: columns[7] || null,
      },
      building: {
        code: columns[0] || null,
        floorNumber: columns[1] || null,
      },
      corridorId: columns[2] || null,
      suiteId: columns[3] || null,
      roomId: columns[4] || null,
      zoneId: columns[5] || null,
      locationPurpose: { id: columns[6] || null },
      lifecycle: {
        beginDate: columns[7] || null,
      },
      errorMessage: errorMessage,
    };

    // If basic validation failed, return with error
    if (errorMessage) {
      return locationDetail;
    }

    // Parse date for valid rows
    const dateObject = new Date(columns[7]);
    const dateString = this.datePipe.transform(dateObject, 'yyyy-MM-ddTHH:mm:ss', '');
    locationDetail.lifecycle.beginDate = dateString;

    return locationDetail;
  }

  validateDetails(building: string, floor: string, purpose: string, startDate: string): string {
    if (building && floor && purpose && startDate) {
      return '';
    }
    return this.getDetailsMessage(building, floor, purpose, startDate);
  }

  getDetailsMessage(building: string, floor: string, purpose: string, startDate: string): string {
    let message = '';
    if (!building) {
      message += this.messages.buildingMissing;
    }
    if (!floor) {
      message += this.messages.floorMissing;
    }
    if (!purpose) {
      message += this.messages.purposeMissing;
    }
    if (!startDate) {
      message += this.messages.startDateMissing;
    }
    return message;
  }

  async parsePlanSpreadsheet(text: string) {
    const lines = text.split('\n');
    const returnObject: { invalidRows: any[]; validRows: any[] } = {
      invalidRows: [],
      validRows: [],
    };
    let dataRow = 0;
    
    // First pass: parse lines and validate basic required fields
    for (const value of lines) {
      if (dataRow > 0) {
        const lineInfo = await this.parseLine(value, dataRow);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
      dataRow++;
    }
    
    // Second pass: validate buildings, purposes, and locations for rows without basic errors
    if (returnObject.validRows.length > 0) {
      await this.validateSpreadsheet(returnObject);
    }
    
    return returnObject;
  }

  async validateSpreadsheet(returnObject: { invalidRows: any[]; validRows: any[] }): Promise<void> {
    const validationPromises = returnObject.validRows.map(async (planRow) => {
      planRow.errorMessage = '';
      
      try {
        // Step 1: Validate building exists by code
        // Matches: BuildingService.getBuildings(null, true, null, null, null, planRow.location.building)
        try {
          const buildingByCodeResponse: any = await this.buildingService
            .getBuildings(null, true, null, undefined, undefined, planRow.location.building)
            .toPromise();
          
          if (!buildingByCodeResponse?.results || buildingByCodeResponse.results.length === 0) {
            planRow.errorMessage += this.messages.buildingInvalid;
            return planRow;
          }
          
          planRow.building = buildingByCodeResponse.results[0];
        } catch (error) {
          planRow.errorMessage += this.messages.buildingInvalid;
          return planRow;
        }
        
        // Step 2: Check if floor exists in building
        // Matches: BuildingService.getBuildings(null, true, null, null, planRow.location.floor, planRow.location.building)
        try {
          const buildingWithFloorResponse: any = await this.buildingService
            .getBuildings(null, true, null, undefined, Number(planRow.location.floor), planRow.location.building)
            .toPromise();
          
          if (buildingWithFloorResponse?.results && buildingWithFloorResponse.results.length > 0) {
            // Floor exists in building
            planRow.building = buildingWithFloorResponse.results[0];
          } else {
            // Floor doesn't exist - this is not an error, just mark it as new floor
            // Keep the building from step 1
            planRow.building.buildingFloors = [];
            planRow.location.floor = '*' + planRow.location.floor;
            if (!planRow.location.room) {
              planRow.errorMessage += this.messages.roomRequired;
            }
          }
        } catch (error) {
          // If this fails but we already have building, treat floor as new
          if (planRow.building && !planRow.errorMessage) {
            planRow.building.buildingFloors = [];
            planRow.location.floor = '*' + planRow.location.floor;
            if (!planRow.location.room) {
              planRow.errorMessage += this.messages.roomRequired;
            }
          }
        }
        
        // Step 3: Validate location purpose (only if no errors so far)
        if (!planRow.errorMessage) {
          try {
            const purposeResponse: any = await this.locationService
              .getLocationPurpose(planRow.location.purpose)
              .toPromise();
            
            if (!purposeResponse?.results || purposeResponse.results.length === 0) {
              planRow.errorMessage += this.messages.locationPurposeInvalid;
              return planRow;
            }
            
            planRow.locationPurpose = purposeResponse.results[0];
            planRow.locationPurpose.id = purposeResponse.results[0].id;
            
          } catch (error) {
            planRow.errorMessage += this.messages.locationPurposeInvalid;
            return planRow;
          }
        } else {
          // If there's already an error, still try to get purpose for display
          try {
            const purposeResponse: any = await this.locationService
              .getLocationPurpose(planRow.location.purpose)
              .toPromise();
            if (purposeResponse?.results && purposeResponse.results.length > 0) {
              planRow.locationPurpose = purposeResponse.results[0];
              planRow.locationPurpose.id = purposeResponse.results[0].id;
            }
          } catch (error) {
            planRow.errorMessage += this.messages.locationPurposeInvalid;
          }
          return planRow;
        }
        
        // Step 4: Check if location already exists (only if no errors so far)
        if (!planRow.errorMessage) {
          try {
            // Build search criteria string
            let searchCriteria = `buildingCode=${planRow.location.building}`;
            searchCriteria += `&floorNumber=${planRow.location.floor.replace('*', '')}`;
            if (planRow.location.corridor) searchCriteria += `&corridorId=${planRow.location.corridor}`;
            if (planRow.location.suite) searchCriteria += `&suiteId=${planRow.location.suite}`;
            if (planRow.location.room) searchCriteria += `&roomId=${planRow.location.room}`;
            if (planRow.location.zone) searchCriteria += `&zoneId=${planRow.location.zone}`;
            if (planRow.locationPurpose?.id) searchCriteria += `&locationPurposeId=${planRow.locationPurpose.id}`;
            
            const locationsResponse: any = await this.locationService
              .getLocations(true, '', searchCriteria, false, 10, 0)
              .toPromise();
            
            // Check for exact match
            if (locationsResponse?.results && locationsResponse.results.length > 0) {
              const exactMatch = locationsResponse.results.find((loc: any) =>
                loc.building?.code?.toUpperCase() === planRow.location.building?.toUpperCase() &&
                loc.building?.floorNumber === planRow.location.floor?.replace('*', '') &&
                (loc.corridorId || '') === (planRow.location.corridor || '') &&
                (loc.suiteId || '') === (planRow.location.suite || '') &&
                (loc.roomId || '') === (planRow.location.room || '') &&
                (loc.zoneId || '') === (planRow.location.zone || '') &&
                loc.locationPurpose?.id === planRow.locationPurpose.id
              );
              
              if (exactMatch) {
                planRow.errorMessage += this.messages.locationExists;
              }
            }
          } catch (error) {
            // Location doesn't exist - this is fine, we can create it
            // Also check date validation even if location check fails
          }
        }
        
        // Step 5: Validate date comparison (check even if there are errors or location doesn't exist)
        if (planRow.building?.lifecycle?.beginDate && planRow.location.startDate) {
          const buildingDate = new Date(planRow.building.lifecycle.beginDate);
          const locationDate = new Date(planRow.location.startDate);
          
          if (locationDate < buildingDate) {
            planRow.errorMessage += this.messages.invalidDate;
            planRow.dateMismatch = true;
          }
        }
        
      } catch (error: any) {        // Don't add generic error if we already have specific errors
        if (!planRow.errorMessage) {
          planRow.errorMessage += 'Validation error occurred. ';
        }
      }
      
      return planRow;
    });
    
    // Wait for all validations to complete
    const validatedRows = await Promise.all(validationPromises);
    
    // Separate valid and invalid rows after validation
    const stillValid: any[] = [];
    const nowInvalid: any[] = [];
    
    validatedRows.forEach(row => {
      if (row.errorMessage) {
        nowInvalid.push(row);
      } else {
        // Prepare the row for API submission
        const submissionRow = {
          corridorId: row.location.corridor || null,
          roomId: row.location.room || null,
          suiteId: row.location.suite || null,
          zoneId: row.location.zone || null,
          mailStopIndicator: false,
          building: {
            code: row.location.building,
            floorNumber: row.location.floor?.replace('*', ''),
          },
          locationPurpose: { id: row.locationPurpose.id },
          lifecycle: {
            beginDate: row.lifecycle.beginDate,
          },
        };
        stillValid.push(submissionRow);
      }
    });
    
    // Update the return object
    returnObject.validRows = stillValid;
    returnObject.invalidRows = [...returnObject.invalidRows, ...nowInvalid];
  }

  getResponseForMultipleLocationsCreation(validRequests: any) {
    this.locationService.executeLocationMassUpload(validRequests).subscribe({
      next: (response: any) => {        if (response) {
          const processedRows = {
            validRows: response.validResponse,
            invalidRows: response.invalidResponse,
          };
          if (processedRows.invalidRows.length > 0 && processedRows.validRows.length > 0) {
            // Both valid and invalid - show error dialog with success count
            this.showImportDialogFailure(processedRows);
          } else if (processedRows.invalidRows.length > 0) {
            // Only invalid rows
            this.showImportDialogFailure(processedRows);
          } else if (processedRows.validRows.length > 0) {
            // All valid
            this.showImportDialogSuccess(processedRows.validRows.length);
          }
        } else {
          this.showImportDialogSuccess(validRequests.length);
        }
      },
      error: (error: any) => {        let errorMessage = 'Location(s) could not be created.';
        if (error?.error?.message) {
          errorMessage = error.error.message;
        } else if (error?.message) {
          errorMessage = error.message;
        } else if (error?.statusText) {
          errorMessage = error.statusText;
        } else if (typeof error === 'string') {
          errorMessage = error;
        }
        
        const errorObject = {
          validRows: [],
          invalidRows: validRequests.map((req: any, index: number) => ({
            ...req,
            row: index + 2,
            errorMessage: errorMessage
          }))
        };
        this.showImportDialogFailure(errorObject);
      }
    });
  }

  importLocationsFile() {
    const reader = new FileReader();
    reader.onload = async () => {
      const text: any = reader.result;
      const parsedObject = await this.parsePlanSpreadsheet(text);
      
      // Handle case where we have both valid and invalid rows
      if (parsedObject.invalidRows.length > 0 && parsedObject.validRows.length > 0) {
        // Show error dialog with option to continue with valid rows
        this.showImportDialogFailure(parsedObject);
      } else if (parsedObject.validRows.length > 0) {
        // All rows are valid, proceed with upload
        this.getResponseForMultipleLocationsCreation(parsedObject.validRows);
      } else {
        // All rows are invalid
        this.showImportDialogFailure(parsedObject);
      }
    };
    const suffix = this.importFile?.name.substring(
      this.importFile?.name.length - 4,
      this.importFile?.name.length
    );
    if (suffix !== '.csv') {
      this.message =
        'The format of the spreadsheet is not expected.  Only CSV files can be imported. ';
      return;
    }
    reader.readAsText(this.importFile as any);
  }

  showImportDialogFailure(parsedObject: any) {
    const failureDialogRef = this.dialog.open(LocationMassUploadErrorModalComponent, {
      width: '90vw',
      maxWidth: '90vw',
      height: '75vh',
      maxHeight: '85vh',
      panelClass: 'location-error-dialog',
      data: parsedObject,
    });
    
    // Handle the "Continue" button click from error dialog
    failureDialogRef.afterClosed().subscribe((result) => {
      if (result === 'continue' && parsedObject.validRows.length > 0) {
        // User chose to continue with valid rows only
        this.getResponseForMultipleLocationsCreation(parsedObject.validRows);
      }
    });
  }

  showImportDialogSuccess(count: number = 0) {
    this.appService.changePage('/app/location');
    const successDialogRef = this.dialog.open(LocationMassUploadSuccessModalComponent, {
      width: '400px',
      height: 'auto',
      data: { count: count },
    });
    successDialogRef.afterClosed().subscribe((result) => {});
  }
}
