import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { RegionManagement } from '../regionManagement';
import { NgForm } from '@angular/forms';
import { SiteService } from 'src/app/services/site.services';
import { RegionManagementService } from 'src/app/services/app-region-management.service';
import { UtilityService } from 'src/app/services/utility.service';

@Component({
  selector: 'app-region-management-edit',
  templateUrl: './region-management-edit.component.html',
  styleUrls: ['./region-management-edit.component.scss'],
})
export class RegionManagementEditComponent implements OnInit {
  responseGetAssociatedSite: any;
  responseGetDisassociatedSite: any;
  responseGetAssociatedSites: any = [];
  responseGetDisassociatedSites: any = [];
  private _regionManagement: RegionManagement | undefined;
  regionManagement: RegionManagement | undefined;
  @Input() set regionManagementData(value: RegionManagement | undefined) {
    this._regionManagement = JSON.parse(JSON.stringify(value));
    this.regionManagement = JSON.parse(JSON.stringify(value));
  }
  regionManagementModel: RegionManagement | undefined;
  @Input() edit: boolean = false;
  lastModifiedBy: string = '';
  lastModifiedDate: string = '';
  isLoadingSites: boolean = false;

  @Output() cancel = new EventEmitter<{ index: number; message: string }>();
  @Output() save = new EventEmitter<{ index: number; message: string, regionCode: string|null }>();
  data: any;
  @ViewChild('editForm') editForm!: NgForm;
  payLoad: any = {};
  constructor(
    private siteService: SiteService,
    private regionManagementService: RegionManagementService,
    private utilityService: UtilityService
  ) {}
  ngOnInit(): void {
    this.getsiteByregion();
    this.getsiteByAssociateion();
    this.setLastModifiedInfo();
  }
  setLastModifiedInfo(): void {
    if (this.regionManagement?.audit) {
      this.lastModifiedBy = this.regionManagement.audit.lastModifiedLoginId || '';
      this.lastModifiedDate = this.regionManagement.audit.lastModifiedDate || '';
    }
  }
  getsiteByregion(): void {
    this.isLoadingSites = true;
    this.siteService
      .getSites('regionId=' + this.regionManagement?.regionId)
      .subscribe((response) => {
        if (response && response.results) {
          const newSites: any = [];
          for (let i = 0; i < response.results.length; i++) {
            newSites.push({
              siteCode: response.results[i].code,
              siteId: response.results[i].siteId,
            });
          }
          this.responseGetAssociatedSites = newSites;
        }
        this.isLoadingSites = false;
      });
  }
  getsiteByAssociateion(): void {
    this.responseGetDisassociatedSites = [];
    this.isLoadingSites = true;
    this.siteService.getSites('disAssociated=true').subscribe((response) => {
      if (response && response.results) {
        const newSites: any = [];
        for (let i = 0; i < response.results.length; i++) {
          newSites.push({
            siteCode: response.results[i].code,
            siteId: response.results[i].siteId,
          });
        }
        this.responseGetDisassociatedSites = newSites;
      }
      this.isLoadingSites = false;
    });
  }
  moveSiteToDisassociatedList(): void {
    if (this.responseGetAssociatedSite != undefined) {
      for (let i = 0; i < this.responseGetAssociatedSite.length; i++) {
        let item = this.responseGetAssociatedSites.find(
          (x: any) => x.siteId == this.responseGetAssociatedSite[i]
        );
        if (item != undefined) {
          this.responseGetDisassociatedSites.push(item);
          this.responseGetAssociatedSites.splice(this.responseGetAssociatedSites.indexOf(item), 1);
        }
      }
    }
  }
  moveSiteToAssociatedList(): void {
    if (this.responseGetDisassociatedSite != undefined) {
      for (let i = 0; i < this.responseGetDisassociatedSite.length; i++) {
        let item = this.responseGetDisassociatedSites.find(
          (x: any) => x.siteId == this.responseGetDisassociatedSite[i]
        );
        if (item != undefined) {
          this.responseGetAssociatedSites.push(item);
          this.responseGetDisassociatedSites.splice(
            this.responseGetDisassociatedSites.indexOf(item),
            1
          );
        }
      }
    }
  }
  saveRegion(): void {
    // Set lifecycle object with current date as beginDate and null as endDate
    if (this.regionManagement) {
      this.regionManagement.lifecycle.beginDate = this.utilityService.dateFormatter(new Date());
      this.regionManagement.lifecycle.endDate = null;
    }

    this.regionManagementService
      .updateRegion(
        this.regionManagement,
        '/regions/' +
          this.regionManagement?.regionId +
          '?lockControlNumber=' +
          this.regionManagement?.audit?.lockControlNumber
      )
      .subscribe((response: any) => {
        this.save.emit({ index: 0, message: 'Region Updated', regionCode: this.regionManagement?.regionCode || null });
        // Reload the screen after successful save
        window.location.reload();
      },
        (error: any) => {
           this.save.emit({ index: 0, message: error, regionCode: this.regionManagement?.regionCode || null });
        });
  }
  resetEditRegion(): void {
    // Reset form fields to original values
    this.regionManagement = JSON.parse(JSON.stringify(this._regionManagement));
    // Reset the site associations to original state
    this.isLoadingSites = true;
    this.getsiteByregion();
    this.getsiteByAssociateion();
  }
  cancelEditRegion(): void {
    this.cancel.emit({ index: 0, message: '' });
  }

  convertToDate(date: string | null | undefined = ''): Date | null {
    if (!date || date === null || date === undefined || date === '') {
      return null;
    }
    return new Date(date);
  }
}
