import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { RegionManagement } from './regionManagement';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../core/confirmation-dialog/confirmation-dialog.component';
import { RegionManagementService } from 'src/app/services/app-region-management.service';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-region-management',
  templateUrl: './region-management.component.html',
  styleUrls: ['./region-management.component.scss'],
})
export class RegionManagementComponent implements OnInit {
  edit: boolean = false;
  isopen: boolean = false;
  isInvalid: boolean = false;
    returnCode: number = 700;
  resultMessage: string = 'Invalid input was detected. Please correct required/invalid fields.';
  errors: string[] = [];
  add: boolean = false;
  showType: string = 'active';
  total: number = 0;
  searchText: string = '';
  searchResultsMode: boolean = false;
  currentSearchText: string | null = '';
  isLoading: boolean = false;
  dataRegionBYLastModifiedDate: any = [];
  regionManagementModel: RegionManagement = {
    regionId: 0,
    regionCode: '',
    regionDescription: '',
    viewMode: 0,
    selectedRegionManagement: {},
    systemName: '',
    lifecycle: {
      beginDate: '',
      endDate: '',
    },
    audit: {
      createdDate: '',
      createdUser: '',
      lastModifiedDate: '',
      lastModifiedUser: '',
      lockControlNumber: '',
      createdLoginId: '',
      lastModifiedLoginId: '',
    },
    dbLocationCode: null,
  };
  regionManagement: RegionManagement | undefined;
  regionManagements: RegionManagement[] = [];
  userRoles: any;
  visualRegionNameHeader: string = 'Region Name';
  descriptionHeader: string = 'Region Description';
  startDateHeader: string = 'Start Date';
  disableShowRadioButton: boolean = true;
  invalidregionCode: string = '';
  sortDirection: string = 'asc';
  sortColumn: string = 'regionCode';
  invalidDescription: string = '';
  beginDateErrorMessage: string | null = '';
  endDateErrorMessage: string | null = '';
  invalidSystemName: string = '';
  searchResults: string | null = '';
  readonly todayDate = new Date();
  constructor(
    private regionManagementService: RegionManagementService,
    private utilityService: UtilityService,
    private ctr: ChangeDetectorRef,
    private dialog: MatDialog,
    private httpService: HttpService,
  ) {}
  ngOnInit(): void {
    this.getRegionManagementList();
    this.getDatabyLastModifiedDate();
    // throw new Error('Method not implemented.');
  }
  hideMessageDiv(): void {
    this.isInvalid = false;
  }
  resort(event: any): void {}
  setshowMode(regionManagement: any, mode: string = 'expand'): void {
    if (mode === 'expand') {
      // this.regionManagements[index].viewMode = this.regionManagements[index].viewMode === 0 ? 1 : 0;
      regionManagement.viewMode === 0
        ? (regionManagement.viewMode = 1)
        : (regionManagement.viewMode = 0);
    }
    if (regionManagement.viewMode === 2) {
      return;
    }

    // this.regionManagementModel.selectedRegionManagement = {

    // };

    this.regionManagementModel.selectedRegionManagement = regionManagement;
    this.visualRegionNameHeader = 'Region Name';
    this.descriptionHeader = 'Description';
    this.cancelAllInvalidates();
    this.ctr.detectChanges();
  }
  firstPage(): void {}
  toggleActiveAll(key: number): void {
    this.showType = key === 0 ? 'active' : 'all';
    this.getRegionManagementList();
  }
  clearSearchResults(): void {
    this.searchResultsMode = false;
    this.searchText = '';
    this.getRegionManagementList();
  }
  getRegionManagementTemplate(regionManagement: any): string {
    if (regionManagement.viewMode === 2) {
      return '#editRegionManagementRow';
    } else if (regionManagement.viewMode === 1) {
      return '#detailsRegionManagementRow';
    } else {
      return '#displayRegionManagementRow';
    }
  }

  editcancelRegionManagement(event: any): void {
    event.viewMode = 0;
    this.edit = false;
    this.cancelRegionManagement();
  }
  cancelRegionManagement(): void {
    this.resetRegionManagement();
    this.add = false;
  }
  resetRegionManagement(): void {
    const formattedDate =this.utilityService.formatDate(new Date(), 'MM/dd/yyyy'); // Format as YYYY-MM-DD
    this.regionManagementModel.selectedRegionManagement = {
      lifecycle: {
        beginDate: formattedDate,
        endDate: '',
      },
      systemName: 'PALM',
      visualLocationCode: '',
      dbLocationCode: null,
      audit: {
        lockControlNumber: 0,
      },
    };
  }
  createNewRegionManagement(): void {
    this.resetRegionManagement();
    this.add = true;
  }
  search(): void {
    if (!this.edit && !this.add) {
      this.hideMessageDiv();
      if (this.searchText.length > 0) {
        this.searchResultsMode = true;
        this.currentSearchText = this.searchText.toUpperCase();
        // this.firstPage();
        this.getRegionManagementList();
      }
    }
  }
  editModel(regionManagement?: any): void {
    // if (!this.edit && !this.add && this.userRoles?.indexOf('InfraAdmin') >= 0) {
    if (!this.edit && !this.add) {
      // Collapse all other expanded rows
      this.regionManagements.forEach((region: any) => {
        if (region.viewMode === 1) {
          region.viewMode = 0;
        }
      });

      if (regionManagement) {
        this.regionManagementModel.selectedRegionManagement = JSON.parse(
          JSON.stringify(regionManagement)
        );
        regionManagement.viewMode = 2;
        this.edit = true;
        if (!this.regionManagementModel.selectedRegionManagement.lifecycle.endDate) {
          this.regionManagementModel.selectedRegionManagement.lifecycle.endDate = '';
        }
      } else {
        this.createNewRegionManagement();
      }
      this.visualRegionNameHeader = 'Region Name';
      this.descriptionHeader = 'Region Description';
      this.hideMessageDiv();
      this.disableShowRadioButton = true;
    }

    if (this.edit) {
      regionManagement.viewMode = 2;
    }
  }
  deleteModel(model: any): void {
    this.regionManagementService
      .deleteRegionManagement(model, model.audit?.lockControlNumber)
      .subscribe(
        (response: any) => {
          this.getRegionManagementList();
           this.returnCode = 200;
        this.resultMessage = `Successfully inactivated region: ${model.regionCode}`;
        this.isInvalid = true;
        },
        (error: any) => {
           this.resultMessage = this.utilityService.processFailureMessage(
              error,
              'Error updating Application reference'
            );
            this.returnCode = error.status;
            this.isInvalid = true;
        }
      );
  }
  deleteConfirmation(model: any): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '30%',
      data: {
        message: `Region ${model.regionDescription} will be inactivated.<br> Click Confirm to continue.`,
        title: 'Inactivate region',
        buttonText: {
          ok: 'Confirm',
          cancel: 'Cancel',
        },
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        // Check if region has associated sites before proceeding with deletion
        this.regionManagementService.getSites(model.regionId).subscribe(
          (response: any) => {
            if (response && response.results && response.results.length > 0) {
              // Sites exist for this region, show error message
              this.returnCode = 400;
              this.resultMessage = 'Cannot delete this region please delete the associated locations first';
              this.isInvalid = true;
            } else {
              // No sites associated, proceed with deletion
              this.deleteModel(model);
            }
          },
          (error: any) => {
            // Handle error in fetching sites
            this.returnCode = error.status || 500;
            this.resultMessage = ' Unable to delete.Please delete Associated sites first';
            this.isInvalid = true;
          }
        );
      }
    });
  }
  getRegionManagementList(limit: number = 10, skip: number = 0): void {
    if (!this.add && !this.edit) {
      const includeInactive = this.showType === 'all';
      const searchParam = this.searchResultsMode ? this.searchText : '';
      this.isLoading = true;
      this.regionManagementService
        .getRegionManagements(includeInactive, limit, this.sortColumn, this.sortDirection, searchParam)
        .subscribe(
          (response: any) => {
            if (response) {
              this.regionManagements = [];
              for (let i = 0; i < response.results.length; i++) {
                response.results[i].viewMode = 0;
                this.regionManagements.push(response.results[i]);
              }
              this.total = response.meta.total;
              console.log('total', this.total);
            }
            this.isLoading = false;
          },
          (error: any) => {
            this.isLoading = false;
          }
        );
    }
  }
  updateSaveRegionManagement(event: any): void {
    this.regionManagements[event.index].viewMode = 0;
    if(event.message == 'Region Updated'){
      this.returnCode = 200;
      this.resultMessage = `Successfully updated region: ${event.regionCode}`;
      this.isInvalid = true;
      this.edit = false;
      setTimeout(() => {
        this.fetchAndUpdateRegionsList();
      }, 2000);
    }else{
      if(event.message){
        this.add = false;
        this.edit = false;
       this.returnCode =  403;
      this.resultMessage = (event.message?.error?.message);
      this.isInvalid = true;
      }
    }
  } //RegionManagement
  saveRegionManagement(): void {
    if (!this.invalidateRegionManagementParameters()) {
      let payload = {
        lifecycle: {
          beginDate: this.utilityService.dateFormatter(this.regionManagementModel.selectedRegionManagement.lifecycle.beginDate),
          endDate: '',
        },
        regionCode: this.regionManagementModel.selectedRegionManagement.regionCode,
        regionDescription: this.regionManagementModel.selectedRegionManagement.regionDescription,
      };
      this.regionManagementService.saveRegionManagement(payload, '').subscribe((response: any) => {
        this.isInvalid = true;
          this.returnCode = 200;
          this.resultMessage = `Successfully created region: ${response.regionCode}`;
          this.add = false;
          setTimeout(() => {
            this.fetchAndUpdateRegionsList();
            // this.editcancelRegionManagement(response);
          }, 2000);

      });
    } else {
      //this.setMessage('700', this.utilityService.getInvalidInputErrorMessage());
    }
  }
  cancelAllInvalidates(): void {
    this.invalidregionCode = '';

    this.invalidDescription = '';
    this.invalidSystemName = '';
    this.endDateErrorMessage = '';
    this.beginDateErrorMessage = '';
  }
  private invalidateRegionManagementParameters(): boolean {
    this.cancelAllInvalidates();
    this.isInvalid = false;
    const selectedRegionManagement = this.regionManagementModel.selectedRegionManagement;

    if (JSON.stringify(selectedRegionManagement) !== '{}') {
      if (!selectedRegionManagement.regionCode) {
        this.errors.push('Region Code required');
        this.invalidregionCode = 'Region Code required';
        this.isInvalid = true;
      } else {
        this.regionManagementModel.selectedRegionManagement.regionCode =
          selectedRegionManagement.regionCode.toUpperCase().trim();
      }

      if (!selectedRegionManagement.regionDescription) {
        this.invalidDescription = 'Region Description required';
        this.errors.push('Region Description required');
        this.isInvalid = true;
      }

      // if (!selectedRegionManagement.systemName) {
      //   this.invalidSystemName = 'System name required';
      //   isInvalid = true;
      // } else {
      //   this.regionManagementModel.selectedRegionManagement.systemName = selectedRegionManagement.systemName
      //     .toUpperCase()
      //     .trim();
      // }

      // this.beginDateErrorMessage = this.utilityService.validateBeginDate(
      //   selectedRegionManagement.lifecycle.beginDate
      // );

      if (this.beginDateErrorMessage) {
        this.isInvalid = true;
      }

      // this.endDateErrorMessage = this.utilityService.validateEndDate(
      //   selectedRegionManagement.lifecycle.beginDate,
      //   selectedRegionManagement.lifecycle.endDate
      // );

      if (this.endDateErrorMessage) {
        this.isInvalid = true;
      }
    }

    return this.isInvalid;
  }
  exportDataCallback(): void {
    let url = `/regions/excelReport?includeInactive=${this.showType === 'all' ? 'true' : 'false'}`;
    if (this.searchText) {
      url += `&codePrefix=${this.searchText}`;
    }
    this.utilityService.exportTableService(
      url,
      'Region Management.xls',
      'application/vnd.ms-excel'
    );
  }
  changeState(state: number): void {
    if (!this.add && !this.edit) {
      this.regionManagements.forEach((regionManagement: any) => {
        regionManagement.lifecycle.beginDate = regionManagement?.lifecycle?.beginDate || '';
        regionManagement.lifecycle.endDate = regionManagement?.lifecycle?.endDate || '';
        regionManagement.viewMode = state;
      });
    }
  }
  searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13 && !this.add && !this.edit) {
      this.search();
    }
  }

  clickedOnSort(event: any, columnName: string): void {
    if (this.sortColumn === columnName) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = columnName;
      this.sortDirection = 'asc';
    }
    this.getRegionManagementList();
  }

  confirmReactivateRegionManagement(regionManagement: any): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        message: `Region ${regionManagement.regionCode} will be reactivated. <br>Click Confirm to continue.`,
        title: `Reactivate Region`,
        isSiteManagement:true,
        buttonText: {
          ok: 'Confirm',
          cancel: 'Cancel',
        },
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.reactivateRegionManagement(regionManagement);
      }
    });
  }

  reactivateRegionManagement(regionManagement: any): void {
    const audit = {
      lockControlNumber: regionManagement.audit.lockControlNumber,
    };
    const reactivatedModel = {
      regionId: regionManagement.regionId,
      regionCode: regionManagement.regionCode,
      regionDescription: regionManagement.regionDescription,
      audit: audit,
      lifecycle: {
        ...regionManagement.lifecycle,
        endDate: '',
      },
    };

    const url =
      '/regions/' +
      regionManagement.regionId +
      '?lockControlNumber=' +
      regionManagement.audit.lockControlNumber;
    this.regionManagementService.updateRegion(reactivatedModel, url).subscribe(
      (response: any) => {
         this.returnCode = 200;
        this.resultMessage = `Successfully reactivated region: ${regionManagement.regionId}`;
        this.isInvalid = true;
        this.getRegionManagementList();
      },
      (error: any) => {
      }
    );
  }

  convertToDate(date: string | null | undefined = ''): Date | null {
    if (!date || date === null || date === undefined || date === '') {
      return null;
    }
    return new Date(date);
  }

  getDatabyLastModifiedDate(limit: number = 1, skip: number = 0): void {
    if (!this.add && !this.edit) {
      this.dataRegionBYLastModifiedDate = [];
      this.regionManagementService
        .getRegionManagements(
          true,
          limit,
          'lastModifiedDate',
          'desc',
          this.searchText
        )
        .subscribe((response: any) => {
          if (response) {
            this.dataRegionBYLastModifiedDate.push(response.results[0]);
          }
        });
    }
  }

  fetchAndUpdateRegionsList(): void {
    const includeInactive = this.showType === 'all';
    const searchParam = this.searchResultsMode ? this.searchText : '';
    this.isLoading = true;
    this.regionManagementService
      .fetchAllRegions(includeInactive, this.sortColumn, this.sortDirection, searchParam)
      .subscribe(
        (response: any) => {
          if (response) {
            this.regionManagements = [];
            for (let i = 0; i < response.results.length; i++) {
              response.results[i].viewMode = 0;
              this.regionManagements.push(response.results[i]);
            }
            this.total = response.meta.total;
            console.log('total', this.total);
          }
          this.isLoading = false;
        },
        (error: any) => {
          this.isLoading = false;
        }
      );
  }
}
