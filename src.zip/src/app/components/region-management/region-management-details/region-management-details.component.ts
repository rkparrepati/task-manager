import { Component, Input, OnInit } from '@angular/core';
import { RegionManagementService } from 'src/app/services/app-region-management.service';

@Component({
  selector: 'app-region-management-details',
  templateUrl: './region-management-details.component.html',
  styleUrls: ['./region-management-details.component.scss'],
})
export class RegionManagementDetailsComponent implements OnInit {
  regionManagements: any[] = [];
  @Input() region: any = {};
  constructor(private regionService: RegionManagementService) {}
  ngOnInit(): void {
    this.regionService.getSite(this.region.regionId).subscribe((response: any) => {
      for (let i = 0; i < response.results.length; i++) {
        this.regionManagements.push({
          siteCode: response.results[i].code,
          siteName: response.results[i].description,
        });
      }
      // this.regionManagement = response.results[0];
    });
  }
}
