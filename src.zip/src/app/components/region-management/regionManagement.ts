export interface RegionManagement {
  regionId: number;
  regionCode: string | null;
  regionDescription: string;
  viewMode: number;
  dbLocationCode: string | null;
  systemName: string;
  lifecycle: Lifecycle;
  audit?: Audit;
  selectedRegionManagement: any;
}
export interface Lifecycle {
  beginDate: string | null;
  endDate: string | null;
}
export interface SelectedPalmLocation {}
export interface Audit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: string;
  createdLoginId: string;
  lastModifiedLoginId: string;
}
