import { Component } from '@angular/core';
import { Payload } from 'src/app/shared/components/management/Management';

@Component({
  selector: 'app-site-management',
  templateUrl: './site-management.component.html',
  styleUrls: ['./site-management.component.scss'],
})
export class SiteManagementComponent {
  componentName: string = 'Site';
  payload: Payload = {
    code: null,
    description: '',
    lifecycle: {
      beginDate: null,
      endDate: null,
    },
    region: {
      id: 0,
    },
  };
  urls: any = {
    list: '/sites',
    add: '/sites',
    edit: '',
    delete: '',
    savePayload: this.payload,
  };
  headers: any = {
    name: 'Site name',
    code: 'Site code',
    description: 'Region',
  };
}
