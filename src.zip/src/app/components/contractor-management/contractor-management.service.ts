import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ContractorManagementService {
  // Toast message management (following location/transfer-search pattern)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();
  
  // Store message for move-contractor page persistence
  private moveContractorStoredMessage: string = '';
  private moveContractorStoredCode: string | number = '';

  constructor() {}

  // Methods to update toast messages (following location/transfer-search pattern)
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.scrolltoTop();
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /**
   * Display success message via acme-navbar
   * @param message Success message to display
   */
  showSuccessMessage(message: string) {
    this.updateReturnCode(200);
    this.updateReturnMessage(message);
    this.updateHideMessage(false);
  }

  /**
   * Display error message via acme-navbar
   * @param message Error message to display
   * @param code Optional error code (default: 500)
   */
  showErrorMessage(message: string, code: string | number = 500) {
    this.updateReturnCode(code);
    this.updateReturnMessage(message);
    this.updateHideMessage(false);
  }

  /**
   * Display multiple error messages via acme-navbar
   * @param messages Array of error messages
   * @param code Optional error code (default: 500)
   */
  showErrorMessages(messages: string[], code: string | number = 500) {
    this.updateReturnCode(code);
    this.updateReturnMessageArray(messages);
    this.updateHideMessage(false);
  }

  /**
   * Hide the message banner
   */
  hideMessages() {
    this.updateHideMessage(true);
    this.updateReturnMessage('');
    this.updateReturnMessageArray([]);
  }
  
  /**
   * Store message for move-contractor page to persist across navigation
   */
  storeMoveContractorMessage() {
    this.moveContractorStoredMessage = this.returnMessageSource.value;
    this.moveContractorStoredCode = this.returnCodeSource.value;
  }
  
  /**
   * Restore stored message for move-contractor page
   */
  restoreMoveContractorMessage() {
    if (this.moveContractorStoredMessage) {
      this.updateReturnCode(this.moveContractorStoredCode);
      this.updateReturnMessage(this.moveContractorStoredMessage);
      this.updateHideMessage(false);
      // Clear stored message after restoring
      this.moveContractorStoredMessage = '';
      this.moveContractorStoredCode = '';
    }
  }
  
  /**
   * Clear stored move-contractor message
   */
  clearMoveContractorStoredMessage() {
    this.moveContractorStoredMessage = '';
    this.moveContractorStoredCode = '';
  }
}
