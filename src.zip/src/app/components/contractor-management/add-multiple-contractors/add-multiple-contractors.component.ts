import { Component, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { WorkerManagementService } from '../../worker-management/worker-management.service';
import { AddMultipleContractorsSuccessModalComponent } from '../add-multiple-contractors-success-modal/add-multiple-contractors-success-modal.component';
import { AddMultipleContractorsErrorModalComponent } from '../add-multiple-contractors-error-modal/add-multiple-contractors-error-modal.component';
import { AppService } from 'src/app/services/app.service';
import { ContractorManagementService } from '../contractor-management.service';

@Component({
  selector: 'app-add-multiple-contractors',
  templateUrl: './add-multiple-contractors.component.html',
  styleUrls: ['./add-multiple-contractors.component.scss'],
})
export class AddMultipleContractorsComponent {
  dialog = inject(MatDialog);
  importedFile: File | null = null;
  message: string = '';
  constructor(
    private workerManagementService: WorkerManagementService,
    private appService: AppService,
    private contractorManagementService: ContractorManagementService
  ) {}

  sendFile(event: Event) {
    this.message = '';
    const element = event.currentTarget as HTMLInputElement;
    const file: any = element?.files ? element.files[0] : null;
    this.importedFile = file;
  }

  downloadTemplate() {
    const link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/uploads/CreateMultipleContractorsTemplate.csv';
    link.download = 'CreateMultipleContractorsTemplate.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  parseLine(line: string, row: number) {
    const columns = line.split(',');
    if (columns[0].length === 0 && columns.length === 1) {
      return null;
    }
    const dateObj = new Date(columns[4]);
    const dateString = [
      ('0' + (dateObj.getMonth() + 1)).slice(-2),
      ('0' + dateObj.getDate()).slice(-2),
      dateObj.getFullYear(),
    ].join('/');
    const contractorDetail = {
      row: row + 1,
      firstName: columns[0].toUpperCase(),
      middleName: columns[1].toUpperCase(),
      lastName: columns[2].toUpperCase(),
      preferredFirstName: columns[3].toUpperCase(),
      dateOFBirth: dateString,
      lastTwoDigitsOfSSN: columns[5],
      firmName: columns[6],
      org: columns[7].toUpperCase(),
      errorMessage: '',
    };
    return contractorDetail;
  }

  parsePlanSpreadsheet(text: string) {
    const lines = text.split('\n');
    const returnObject: { invalidRows: any[]; validRows: any[] } = {
      invalidRows: [],
      validRows: [],
    };
    let dataRow = 0;
    lines.forEach((value) => {
      if (dataRow) {
        const lineInfo = this.parseLine(value, dataRow);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }
      dataRow++;
    });
    return returnObject;
  }

  getResponseForMultipleContractorsCreation(validRequests: any) {
    this.workerManagementService
      .getContractorCreationResponse(validRequests)
      .subscribe((response: any) => {
        if (response) {
          const processedRows = {
            validRows: response.validResponse,
            invalidRows: response.invalidResponse,
          };
          if (processedRows.invalidRows.length > 0) {
            this.showImportDialogFailure(processedRows);
          } else {
            this.showImportDialogSuccess(processedRows.validRows);
          }
        }
      });
  }

  importFile() {
    const reader = new FileReader();
    reader.onload = () => {
      const text: any = reader.result;
      const parsedObject = this.parsePlanSpreadsheet(text);
      if (
        parsedObject.validRows &&
        Array.isArray(parsedObject.validRows) &&
        parsedObject.validRows.length
      ) {
        this.getResponseForMultipleContractorsCreation(parsedObject.validRows);
      } else {
        this.showImportDialogFailure(parsedObject);
      }
    };
    const suffix = this.importedFile?.name.substring(
      this.importedFile?.name.length - 4,
      this.importedFile?.name.length
    );
    if (suffix !== '.csv') {
      this.message =
        'The format of the spreadsheet is not expected.  Only CSV files can be imported. ';
      return;
    }
    reader.readAsText(this.importedFile as any);
  }

  showImportDialogFailure(parsedObject: any) {
    const failureDialogRef = this.dialog.open(AddMultipleContractorsErrorModalComponent, {
      width: '90vw',
      height: '75vh',
      data: parsedObject,
      disableClose: true,
    });
    failureDialogRef.afterClosed().subscribe((result) => {});
  }

  showImportDialogSuccess(parsedObject: any) {
    // Navigate to contractor management page FIRST
    this.appService.changePage('/app/workerManagement/Contractor');
    
    // Then show the detailed success modal with the list of created contractors
    // Use setTimeout to ensure navigation completes before opening dialog
    setTimeout(() => {
      const successDialogRef = this.dialog.open(AddMultipleContractorsSuccessModalComponent, {
        width: '90vw',
        height: '75vh',
        data: parsedObject,
        disableClose: true,
      });
    }, 100);
  }
}
