import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { WorkerManagementService } from '../../worker-management/worker-management.service';

@Component({
  selector: 'app-contractor-status-dialog',
  templateUrl: './contractor-status-dialog.component.html',
  styleUrls: ['./contractor-status-dialog.component.scss'],
})
export class ContractorStatusDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<ContractorStatusDialogComponent>,
    private workerManagementService: WorkerManagementService
  ) {}
  workersList: any = [];
  importedFile: File | null = null;
  limit = 10;
  total = 0;
  otherSearchView = 'advanced';
  location = 0;
  buildingCodeList = [];
  workerModel: any = '';
  isFileImported = false;
  applicationType = 'Contractor';
  sortColumn = 'lastName';
  sortDirection = 'asc';
  loadingMessage = 'Loading Worker data...';
  showWait = true;
  isContractor = true;
  workerEmploymentType = 'C';
  applicationTypeLowerCase = 'contractor';
  moduleName = 'Contractor Management';
  appTitle = 'Contractor Management';
  fileToImport = '/ui/uploads/ContractorStatusMassUpload.csv';
  //fileToImport = '/uploads/ContractorStatusMassUpload.csv';

  sendFile(event: Event) {
    const element = event.currentTarget as HTMLInputElement;
    const file: any = element?.files ? element.files[0] : null;
    this.workersList = [];
    this.importedFile = file;
  }

  downloadTemplate() {
    const link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/uploads/ContractorStatusMassUpload.csv';
    link.download = 'ContractorStatusMassUpload.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  parseLine(line: string, row: any) {
    const columns = line.split(',');
    if (columns[0].length === 0) {
      return null;
    }

    for (let index = 0; index < 3; index++) {
      if (columns[index]) {
        columns[index] = columns[index].toUpperCase().trim();
      }
    }

    const workerDetails = {
      row: row,
      workerNumber: columns[0],
      errorMessage: '',
    };
    return workerDetails;
  }
  invalidFileTypeMessage() {
    const modalOptions = {
      titleType: 'text-danger',
      content: 'The format of the spreadsheet is not expected.  Only CSV files can be imported. ',
      primaryButton: 'Close',
      primaryButtonType: 'danger',
      title: 'Invalid File type!',
    };
  }
  parsePlanSpreadsheet(text: string) {
    const lines = text.split('\n');
    let dataRow = 0;
    const returnObject: { invalidRows: any[]; validRows: any[] } = {
      invalidRows: [],
      validRows: [],
    };

    lines.forEach((value) => {
      if (dataRow > 0) {
        const lineInfo: any = this.parseLine(value, dataRow);
        if (lineInfo) {
          if (!lineInfo.errorMessage) {
            returnObject.validRows.push(lineInfo);
          } else {
            returnObject.invalidRows.push(lineInfo);
          }
        }
      }

      dataRow++;
    });

    return returnObject;
  }

  exportStatusList() {
    // Download the status report as CSV
    this.workerManagementService
      .getWorkerStatusExcelReport(this.workersList)
      .subscribe(
        (blob: Blob) => {
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'ContractorStatusReport.csv';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);

        },
        (error: any) => {

        }
      );
  }

  getResponseForMultipleContractorsCreation(validRequests: any) {
    this.workerManagementService
      .getContractorStatusValidResponse(validRequests)
      .subscribe((response: any) => {
        const returnedData = response;
        const processedRows = {
          validRows: returnedData.validResponse,
          invalidRows: returnedData.invalidResponse,
        };

        this.isFileImported = true;
        this.dialogRef.updateSize('95em');
        if (processedRows.invalidRows.length > 0) {
          // closeThisDialog(true);
          // showImportDialogFailure(processedRows);
        } else {
          const list = [];
          const responseWorkersList = [];
          for (let counter = 0; counter < processedRows.validRows.length; counter++) {
            list.push(processedRows.validRows[counter].contractorNumber);
            const worker = processedRows.validRows[counter].worker;
            responseWorkersList.push(worker);
          }
          this.workersList = list;
          this.workerModel = {
            workerList: responseWorkersList,
            selectedWorker: {},
            newWorker: {},
          };

          this.exportStatusList();
        }
      });
  }

  importFile() {
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result;
      this.fileReader(text);
    };
    const suffix = this.importedFile?.name.substring(
      this.importedFile?.name.length - 4,
      this.importedFile.name.length
    );
    if (suffix !== '.csv') {
      this.invalidFileTypeMessage();
      return;
    }
    reader.readAsText(this.importedFile as any);
  }
  fileReader(text: any) {
    const parsedObject = this.parsePlanSpreadsheet(text);

    if (parsedObject.validRows) {
      this.getResponseForMultipleContractorsCreation(parsedObject.validRows);
    }
  }

  closeThisDialog() {
    this.isFileImported = false;
    this.dialogRef.close();
  }
  /*
  
    showImportDialogSuccess(parsedObject) {
      ngDialog.openConfirm({
        template: 'app/workerManagement/multiContractorWorkerStatusSuccessDialog.html',
        className: 'ngdialog-theme-default locationSelecctDialog',
        controller: 'CreateMultipleContractorsAttentionController',
        data: parsedObject,
        controllerAs: 'vm',
        preCloseCallback: {
  
          ngDialog.close();
        }
      }).then(() {
      }, () {
      });
    }
  
    showImportDialogFailure(parsedObject) {
      ngDialog.openConfirm({
        template: 'app/workerManagement/multiContractorStatusFailureDialog.html',
        className: 'ngdialog-theme-default showAssociatedOrganizationsDialog',
        controller: 'CreateMultipleContractorsAttentionController',
        data: parsedObject,
        controllerAs: 'vm',
        preCloseCallback:){
  
        ngDialog.close();
      }
    }).then(() {
    }, () {
    });
            }        
          
           
        
            
  
           
         */
}
