import { Component } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { WorkerManagementService } from '../../worker-management/worker-management.service';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { ContractorManagementService } from '../contractor-management.service';

@Component({
  selector: 'app-move-contractor',
  templateUrl: './move-contractor.component.html',
  styleUrls: ['./move-contractor.component.scss'],
})
export class MoveContractorComponent {
  allFirmsAssigned: boolean = false;
  showMoveContractorPage: boolean = false;
  firmName: string = '';
  newContractorFirm: any = null;
  selectedFromContractors: any;
  selectedContractors: any;
  contractorsInFirm: any[] = [];
  currentContractorsInFirm: any[] = [];
  newFirmContractors: any[] = [];
  contractorFirmNames: any[] = [];

  // Toast message properties for app-acme-navbar-component
  main = { creationDate: new Date() };
  appTitle: string = 'Move Contractors';

  constructor(
    private appService: AppService,
    private workerManagementService: WorkerManagementService,
    private organizationService: OrganizationService,
    public contractorManagementService: ContractorManagementService
  ) {}

  ngOnInit(): void {
    this.organizationService.getFirms().subscribe((res: any) => {
      this.contractorFirmNames = res.results;
    });
    
    // Restore success message if it was stored
    this.contractorManagementService.restoreMoveContractorMessage();
  }

  backToContractorMgmt() {
    // Store the current success message before clearing it
    this.contractorManagementService.storeMoveContractorMessage();
    
    // Clear any success messages before navigating away
    this.contractorManagementService.hideMessages();
    this.appService.changePage('/app/workerManagement/Contractor');
  }
  moveContractorsList(direction: string, moveList: any[] = []) {
    if (!moveList || moveList.length === 0) {
      return;
    }

    let fromList = this.contractorsInFirm || [];
    let toList = this.newFirmContractors || [];

    if (direction === 'remove') {
      fromList = this.newFirmContractors || [];
      toList = this.contractorsInFirm || [];
    }

    moveList.forEach((contractor: any) => {
      if (contractor && !toList.some((item) => item.workerNumber === contractor.workerNumber)) {
        toList.push(contractor);
        this.removeFromList(contractor, fromList);
      }
    });
  }

  removeFromList(contractor: any, fromList: any[] = []) {
    if (!contractor || !fromList || fromList.length === 0) {
      return;
    }

    const index = fromList.findIndex((item) => item.workerNumber === contractor.workerNumber);
    if (index > -1) {
      fromList.splice(index, 1);
    }
  }

  showFirmContractors() {
    this.contractorsInFirm = [];
    this.workerManagementService.getContractorsByFirmSearch(this.firmName).subscribe(
      (response: any) => {
        this.contractorsInFirm = response.results.map((contractor: any) => {
          contractor.displayItem = `${contractor.familyName}, ${contractor.preferredFirstName}, ${contractor.workerNumber}`;
          return contractor;
        });
        this.currentContractorsInFirm = JSON.parse(JSON.stringify(this.contractorsInFirm));
        this.showMoveContractorPage = true;
      },
      (error: any) => {
        // Display error message via contractorManagementService (acme-navbar)
        const errorMessage = error?.error?.message || error?.message || `No contractors found for firm: ${this.firmName}`;
        this.contractorManagementService.showErrorMessage(errorMessage, error?.status || 404);
      }
    );
  }

  moveContractors(moveAll: boolean, direction: string) {
    if (moveAll) {
      if (direction === 'remove') {
        this.contractorsInFirm = JSON.parse(JSON.stringify(this.currentContractorsInFirm));
        this.newFirmContractors = [];
      } else {
        this.newFirmContractors = JSON.parse(JSON.stringify(this.contractorsInFirm));
        this.contractorsInFirm = [];
      }
    } else {
      let selectedList;
      if (direction === 'add') {
        selectedList = this.selectedContractors;
      } else {
        selectedList = this.selectedFromContractors;
      }

      if (!this.newFirmContractors) {
        this.newFirmContractors = [];
      }
      this.moveContractorsList(direction, selectedList);
    }
  }

  saveContractorMove() {
    const movedContractors = JSON.parse(JSON.stringify(this.newFirmContractors));
    const contractorCount = movedContractors.length;
    const oldFirmName = this.firmName;
    
    // Get the new firm name from contractorFirmNames (handle type conversion)
    const newFirm = this.contractorFirmNames.find((firm: any) => firm.id == this.newContractorFirm);
    const newFirmName = newFirm ? newFirm.value : String(this.newContractorFirm);

    const workerIds = movedContractors.map((contractor: any) => contractor.workerId);
    const servicesObject = {
      workerId: workerIds,
      firm: { id: this.newContractorFirm },
    };

    this.workerManagementService.moveContractorsList(servicesObject).subscribe(
      (response: any) => {
        // Display success message via contractorManagementService (acme-navbar)
        const message = `${contractorCount} contractor(s) moved from ${oldFirmName} to ${newFirmName}`;
        this.contractorManagementService.showSuccessMessage(message);
        
        // Navigate back to contractor management without setting success message
        // this.appService.changePage('/app/workerManagement/Contractor');
        this.resetPage();
      },
      (error: any) => {
        // Display error message via contractorManagementService (acme-navbar)
        const errorMessage = error?.error?.message || 'Failed to move contractors';
        this.contractorManagementService.showErrorMessage(errorMessage);
      }
    );
  }
  resetPage() {
    this.newFirmContractors = [];
    this.newContractorFirm = null;
    this.showMoveContractorPage = false;
    this.firmName = '';
    this.contractorsInFirm = [];
    this.currentContractorsInFirm = [];
  }
}
