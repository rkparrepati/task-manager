import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AppService } from 'src/app/services/app.service';
import { MatSort } from '@angular/material/sort';
import { WorkerManagementService } from '../../worker-management/worker-management.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { forkJoin } from 'rxjs';

/**
 * @title Table with expandable rows
 */
@Component({
  selector: 'app-contractor-grid',
  styleUrls: ['contractor-grid.component.scss'],
  templateUrl: 'contractor-grid.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ContractorGridComponent implements OnInit, OnChanges {
  @Input() dataSource: any = { meta: {}, results: [] };
  @Input() applicationType: string = 'Worker';
  @Input() sortColumn: string = 'lastName';
  @Input() sortDirection: string = 'asc';
  @Output() editWorker: EventEmitter<any> = new EventEmitter();
  @Output() sortChange: EventEmitter<any> = new EventEmitter();

  total: any;
  userRoles: any = [];
  updateWorkerButton: any;
  workerModel: any = { workerList: [] };
  userInfo: any;
  worker: any = {};
  phoneNumberDetail: any = {};
  locationDetail: any = {};
  expandedElement: any | null;
  rolesEnum = ROLES_ENUM;

  displayedColumns: string[] = [
    'status',
    'applicationTypeNumber',
    'lastName',
    'firstName',
    'preferredFirstName',
    'acronym',
    'building',
    'location',
    'jobClass',
    'firmName',
    'actions',
  ];

  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  constructor(
    private appService: AppService,
    private workerService: WorkerManagementService
  ) {}

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges) {
    // No need to create MatTableDataSource - we'll use dataSource.results directly in template
  }

  /**
   * Navigates to worker update page with appropriate edit type
   * For Contractors: shows edit button for all users
   * For Workers: shows edit button based on user roles
   */
  getWorkerUpdateObject(worker: any, type: string = '') {
    if (!type && this.appService.checkRoleExists(ROLES_ENUM.INFRA_ADMIN)) {
      type = 'A';
    } else if (!type) {
      type = 'N';
    }
    this.appService.changePage(
      '/app/workerUpdate/' +
        worker.workerId +
        '/' +
        worker.workerNumber +
        '/' +
        this.applicationType +
        '/' +
        type
    );
  }

  /**
   * Checks if edit button should be shown for contractor
   * Contractors can be edited by any user
   */
  canEditContractor(): boolean {
    return this.applicationType === 'Contractor';
  }

  /**
   * Checks if user has admin role for contractor edit dropdown
   */
  isInfraAdmin(): boolean {
    return this.appService.checkRoleExists(ROLES_ENUM.INFRA_ADMIN);
  }

  /**
   * Checks if user has contractor admin role
   */
  isContractorAdmin(): boolean {
    return this.appService.checkRoleExists(ROLES_ENUM.INFRA_CONTRACTOR_ADMIN);
  }
  getTemplateWorkerSearch(worker: any) {
    if (
      worker &&
      this.workerModel &&
      this.workerModel.selectedWorker &&
      this.workerModel.selectedWorker.workerId &&
      worker.workerId === this.workerModel.selectedWorker.workerId
    ) {
      return 'detail';
    } else {
      return 'view';
    }
  }
  toggleExpandRow(worker: any) {
    // Toggle the expanded element
    if (this.expandedElement === worker) {
      this.expandedElement = null;
      this.phoneNumberDetail = null;
      this.locationDetail = null;
      this.workerModel.selectedWorker = {};
    } else {
      this.expandedElement = worker;
      this.expandPhoneNumber(worker);
    }
  }

  expandPhoneNumber(worker: any) {
    this.phoneNumberDetail = null;
    this.locationDetail = null;
    this.workerModel.selectedWorker = worker;

    // Make API call to get worker assignments
    this.workerService.getWorkerAssignments(worker.workerId).subscribe(
      (assignmentResponse: any) => {

        // Handle response structure with meta and results
        let assignments = assignmentResponse;
        if (assignmentResponse?.results && Array.isArray(assignmentResponse.results)) {
          assignments = assignmentResponse.results;
        } else if (Array.isArray(assignmentResponse)) {
          assignments = assignmentResponse;
        } else {
          assignments = [assignmentResponse];
        }
        
        // Find primary assignment or use first one
        const primaryAssignment = assignments.find((a: any) => a.primaryLocationIndicator) || assignments[0];

        // Store the assignment data for display
        this.phoneNumberDetail = primaryAssignment;
        
        // Extract locationId from the assignment
        const locationId = primaryAssignment?.assignmentLocation?.locationId;

        if (locationId) {

          this.workerService.getLocationDetails(locationId).subscribe(
            (locationResponse: any) => {

              this.locationDetail = locationResponse;
            },
            (error: any) => {

            }
          );
        } else {

        }
      },
      (error) => {

      }
    );
  }
  clickedOnSort(event: any): void {
    this.sortChange.emit(event);
  }

  /**
   * Resort method to handle sorting events from app-sort-button component
   * Following relocation-management pattern
   */
  resort(event: any): void {
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;
    this.sortChange.emit(event);
  }

  // loadWorkers() {
  //   const params = {
  //     page: this.pageIndex + 1,
  //     pageSize: this.pageSize,
  //     sortColumn: this.sortColumn,
  //     sortDirection: this.sortDirection
  //   };

  //   this.workerService.getWorkers(params).subscribe((response: any) => {
  //     this.matdataSource = new MatTableDataSource<any>(response.results);
  //     this.total = response.meta.totalRecords;
  //     this.matdataSource.paginator = this.paginator;
  //     this.matdataSource.sort = this.sort;
  //   });
  // }
  // onPaginateChange(event: PageEvent) {
  //   this.pageIndex = event.pageIndex;
  //   this.pageSize = event.pageSize;
  //   this.loadWorkers();
  // }

  getPrimaryOrganization(organizationHistory: Array<any>) {
    let acronym;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organization = organizationHistory[i];
      if (organization.primaryOrganizationIndicator) {
        acronym =
          organization.organization.businessAreaCode + '/' + organization.organization.shortName;
      }
    }
    return acronym;
  }
  getBuildingData(organizationHistory: Array<any>) {
    let building = '';
    let position = -1;
    const len = organizationHistory?.length || 0;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData?.locationSummary?.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    if (position >= 0 && organizationHistory[position]) {
      const locationSummary = organizationHistory[position]?.locationSummary?.[0]?.locationSummary;
      if (locationSummary?.building?.code) {
        building = locationSummary.building.code;
      }
    }
    return building;
  }
  getLocation = function (organizationHistory: Array<any>) {
    let location = '';
    let position = -1;
    const len = organizationHistory?.length || 0;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData?.locationSummary?.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    if (position >= 0 && organizationHistory[position]) {
      const locationSummary = organizationHistory[position]?.locationSummary?.[0]?.locationSummary;
      if (locationSummary != null) {
        let floor = locationSummary.building?.floorNumber;
        let corridor = locationSummary.corridorId;
        let room = locationSummary.roomId;
        let zone = locationSummary.zoneId;
        let suite = locationSummary.suiteId;
        if (corridor == null && room == null && zone == null && suite == null) {
          location = floor;
        } else if (corridor == null && zone == null && suite == null) {
          location = floor + '/' + room;
        } else if (room == null && zone == null && suite == null) {
          location = floor + '/' + corridor;
        } else if (zone == null && suite == null) {
          location = floor + '/' + corridor + room;
        } else if (suite == null) {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '/' + corridor + room + zone;
        } else {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '-' + suite + '/' + corridor + room + zone;
        }
      }
    }
    return location;
  };
  collapsePhoneNumber() {
    this.workerModel.selectedWorker = {};
  }
  pageSizeChangedEvent(pageSize: number) {}
}
