import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { JobClassService } from 'src/app/shared/services/job-class.service';
import { OrganizationService } from 'src/app/shared/services/organizations.services';

@Component({
  selector: 'app-contractor-advanced-search',
  templateUrl: './contractor-advance-search.component.html',
  styleUrls: ['./contractor-advance-search.component.scss'],
})
export class ContractorAdvancedSearchComponent implements OnInit {
  ssnMask = { mask: '000-00-0000' };
  @Output() public advanceSearch = new EventEmitter();
  contractorFirmNames: any[] = [];
  public status = true;
  public searchForm: FormGroup;
  public isContractor: boolean = true;
  advanceSearchAcronym: any;
  acronymInvalid: any;
  jobClassCodeList: any;
  constructor(
    private organizationService: OrganizationService,
    private fb: FormBuilder,
    private jobClassService: JobClassService
  ) {
    this.searchForm = this.fb.group({
      workerNumber: [''],
      lastName: [''],
      firmName: [''],
      firstName: [''],
      preferredFirstName: [''],
      loginId: [''],
      firmAdministrator: [''],
      birthDate: [''],
      ssn2: [''],
      classCode: [''],
      businessAreaCode: [''],
      shortName: [''],
    });
  }

  ngOnInit(): void {
    // Initialization logic here
    this.getJobClass();
    this.getFirmAdministrator();
  }

  onSubmit(): void {
    if (this.searchForm.valid) {
      this.advanceSearch.emit(this.searchForm.value);
    }
  }
  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
  setSearchType(searchType: any) {
    const advanceSearchOptions = {
      searchType: searchType,
      searchCriteria: this.searchForm.value,
    };
    this.advanceSearch.emit(advanceSearchOptions);
  }
  onAcronymChange(acronym: string) {
    // Split acronym format "P/1600" into businessAreaCode and shortName
    if (acronym && acronym.includes('/')) {
      const parts = acronym.split('/');
      this.searchForm.patchValue({
        businessAreaCode: parts[0].trim(),
        shortName: parts[1].trim()
      });
    } else {
      this.searchForm.patchValue({
        businessAreaCode: '',
        shortName: ''
      });
    }
  }
  getJobClass() {
    this.jobClassService.getJobClasses().subscribe((response: any) => {
      this.jobClassCodeList = response.results;
    });
  }
  getFirmAdministrator() {
    this.organizationService.getFirms().subscribe((res: any) => {
      this.contractorFirmNames = res.results;
    });
  }
  clearAdvanvedSearch() {
    this.searchForm.reset();
    this.advanceSearchAcronym = '';
  }
  onBirthDateChange(date: string) {
    this.searchForm.patchValue({
      birthDate: date
    });
  }

  getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}
