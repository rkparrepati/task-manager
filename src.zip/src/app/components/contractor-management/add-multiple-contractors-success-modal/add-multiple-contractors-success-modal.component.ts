import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-multiple-contractors-success-modal',
  templateUrl: './add-multiple-contractors-success-modal.component.html',
  styleUrls: ['./add-multiple-contractors-success-modal.component.scss'],
})
export class AddMultipleContractorsSuccessModalComponent {
  data: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<AddMultipleContractorsSuccessModalComponent>) {}

  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
}
