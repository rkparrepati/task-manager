import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { WorkerManagementService } from '../../worker-management/worker-management.service';
import { AppService } from 'src/app/services/app.service';
import { ContractorManagementService } from '../contractor-management.service';
import { AddMultipleContractorsSuccessModalComponent } from '../add-multiple-contractors-success-modal/add-multiple-contractors-success-modal.component';

@Component({
  selector: 'app-add-multiple-contractors-error-modal',
  templateUrl: './add-multiple-contractors-error-modal.component.html',
  styleUrls: ['./add-multiple-contractors-error-modal.component.scss'],
})
export class AddMultipleContractorsErrorModalComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(
    private dialogRef: MatDialogRef<AddMultipleContractorsErrorModalComponent>,
    private workerManagementService: WorkerManagementService,
    private appService: AppService,
    private contractorManagementService: ContractorManagementService
  ) {}

  importTheFile() {
    if (this.data.validRows) {
      this.workerManagementService
        .getContractorValidCreationResponse(this.data.validRows)
        .subscribe((response: any) => {
          const processedRows = {
            validRows: response.validResponse,
          };
          this.showImportDialogSuccess(processedRows);
        });
    }
  }

  showImportDialogSuccess(parsedObject: any) {
    // Close the error dialog first
    this.dialogRef.close();
    
    // Navigate to contractor management page FIRST
    this.appService.changePage('/app/workerManagement/Contractor');
    
    // Then show the detailed success modal with the list of created contractors
    // Use setTimeout to ensure navigation completes before opening dialog
    setTimeout(() => {
      const successDialogRef = this.dialog.open(AddMultipleContractorsSuccessModalComponent, {
        width: '90vw',
        height: '75vh',
        data: parsedObject.validRows,
        disableClose: true,
      });
    }, 100);
  }
  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
}
