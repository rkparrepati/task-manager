import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AccessionSelectDialogComponent } from './../worker-management/accession-select-dialog/accession-select-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { WorkerManagementService } from '../worker-management/worker-management.service';
import { AdvanceSearchOptions } from 'src/app/shared/interfaces/models';
import { ContractorStatusDialogComponent } from './contractor-status-dialog/contractor-status-dialog.component';
import { ContractorManagementService } from './contractor-management.service';
import { NotificationService } from 'src/app/services/notification.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-contractor-management',
  templateUrl: './contractor-management.component.html',
  styleUrls: ['./contractor-management.component.scss'],
})
export class ContractorManagementComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  public workerRecords: any = { meta: {}, results: [] };
  public rolesEnum = ROLES_ENUM;
  canAdd: boolean = true;
  searchResultsCount: number = 0;
  disableShowRadioButton: any;
  showType: any = 'active';
  selectedData: any = {};
  searchResultsText: string = '';
  searchCriteria: any = {};
  paginationData: any = {};
  appTitle: string = 'Contractor Management';
  applicationType: string = 'Contractor';
  sortColumn: string = 'lastName';
  sortDirection: string = 'asc';

  // Toast message properties for app-acme-navbar-component (following location component pattern)
  main = { creationDate: new Date() };

  otherSearchView: string = 'advanced';
  constructor(
    public appService: AppService,
    private workerManagementService: WorkerManagementService,
    private dialog: MatDialog,
    public contractorManagementService: ContractorManagementService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    // Hide any messages and clear stored move-contractor messages when landing on contractor management page
    this.contractorManagementService.hideMessages();
    this.contractorManagementService.clearMoveContractorStoredMessage();
    
    // Check for success message from worker update/create
    this.notificationService.getSuccessMessageData()
      .pipe(takeUntil(this.destroy$))
      .subscribe(data => {
        if (data) {

          // Build success message in format: "Successfully updated worker: HANSELL (Worker number:C45655)"
          const action = data.status === 'created' ? 'created' : 'updated';
          const message = `Successfully ${action} worker: ${data.lastName} (Worker number:${data.workerNumber})`;
          
          // Display success message via contractorManagementService (acme-navbar)
          this.contractorManagementService.showSuccessMessage(message);
          
          // Clear the success message data after displaying
          this.notificationService.clearSuccessMessageData();
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
  toggleSearchView() {
    if (this.otherSearchView === 'basic') {
      this.otherSearchView = 'advanced';
    } else {
      this.otherSearchView = 'basic';
    }
  }
  resetPagination() {
    this.paginationData.limit = this.paginationData.limit || 10;
    this.paginationData.skip = 0;
  }

  searchWorkers(data: any, isFromPagination: boolean = false) {
    if (!isFromPagination) {
      this.resetPagination();
    }
    this.searchCriteria = data;
    if (data.searchCriteria === 'workerNumber') {
      data.searchValue = data.searchValue.toUpperCase();
    }
    this.selectedData.searchText = data.searchValue;
    this.selectedData.searchCriteria = data.searchCriteria;
    this.workerManagementService
      .getWorkers(
        this.showType === 'active' ? false : true,
        this.selectedData.searchText,
        this.selectedData.searchCriteria,
        true,
        this.paginationData.limit,
        this.paginationData.skip,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response) => {
          this.searchResultsCount = response.meta.total;
          this.workerRecords = response;
          const workerText = this.searchResultsCount === 1 ? 'worker has' : 'worker(s) have';
          this.searchResultsText = `${this.searchResultsCount} ${workerText} been found with the entered search criteria.`;
        },
        (error) => {
          this.workerRecords = [];
          this.searchResultsCount = 0;
          this.searchResultsText = `Something went wrong. Please try again.`;
          if (error.status === 404) {
            this.searchResultsText = `No worker(s) have been found with the entered search criteria.`;
          }
        }
      );
  }
  public generateReports() {
    const dialogRef = this.dialog.open(AccessionSelectDialogComponent, {
      width: '25vw',
      height: '100',
    });

    dialogRef.afterClosed().subscribe((result) => {
      // this.acronym = result.shortName;
    });
  }
  exportDataCallback(): void {
    let url = '&isContractor=true';
    const searchCriteria = this.searchCriteria;
    if (this.otherSearchView === 'basic') {
      Object.keys(searchCriteria).forEach((key) => {
        if (searchCriteria[key]) {
          let paramKey = key;
          if (key === 'workerNumber') {
            const val = searchCriteria[key].toUpperCase();
            paramKey = 'workerNumberPrefix';
            searchCriteria[key] = val;
          } else if (key === 'lastName') {
            // Map lastName form field to familyName API parameter
            paramKey = 'familyName';
          }
          const value = encodeURIComponent(searchCriteria[key]);
          url += `&${paramKey}=${value}`;
        }
      });
    } else {
      url += `&${this.workerManagementService.getSearchCriteriaKey(
        searchCriteria.searchCriteria
      )}=${searchCriteria.searchValue}`;
    }
    
    const fileName = 'ContractorSearchExport.xlsx';
    
    this.workerManagementService
      .workerExcelReport(this.showType === 'active' ? false : true, url, this.searchResultsCount)
      .subscribe({
        next: (data: Blob) => {
          // Check for IE > 10 which has msSaveBlob
          if (window.navigator && (window.navigator as any).msSaveBlob) {
            (window.navigator as any).msSaveBlob(data, fileName);
          } else {
            // For Chrome and other modern browsers
            const blobUrl = URL.createObjectURL(data);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = fileName;
            a.target = '_blank';

            // Append to body to ensure it works in Firefox
            document.body.appendChild(a);
            a.click();

            // Clean up
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
          }
        },
        error: (error: any) => {

        }
      });
  }
  employeeStatus() {
    // ngDialog.openConfirm({
    //     template: 'app/workerManagement/multiWorkerStatus.html',
    //     controller: 'MultiWorkerStatusDialogController',
    //     data: null,
    //     controllerAs: 'vm'
    // }).then(function (workersList) {
    //     if (workersList.length) {
    //         vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilityService.exportTableServicePOST(url, 'WorkerStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    //     }
    // }, function () {
    // });
  }
  contractorAdd() {
    this.appService.changePage('/app/workerAdd/Contractor');
  }
  workerAddmultipleContractor() {
    this.appService.changePage('/app/contractor-management/createMultipleContractors/Contractors');
  }
  contractorStatus() {
    // ngDialog.openConfirm({
    //     template : 'app/workerManagement/multiContractorStatus.html',
    //     controller : 'MultiContractorStatusDialogController',
    //     data : null,
    //     controllerAs : 'vm'
    // // }).then(function(confirmSaveExit) {
    // }).then(function(workersList) {
    //     var promises = [];
    //     vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilityService.exportTableServicePOST(url, 'ContractorStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    // }, function() {
    // });
    const dialogRef = this.dialog.open(ContractorStatusDialogComponent, {
      width: '28vw',
      height: '100',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      // this.acronym = result.shortName;
    });
  }
  public setActiveWorkerList(showIactive: boolean) {
    this.workerManagementService
      .getWorkers(
        this.showType === 'active' ? false : true,
        this.selectedData.searchText,
        this.selectedData.searchCriteria,
        true,
        this.paginationData.limit || 10,
        this.paginationData.skip || 0,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response) => {
          this.searchResultsCount = response.meta.total;
          this.workerRecords = response;
          const workerText = this.searchResultsCount === 1 ? 'worker has' : 'worker(s) have';
          this.searchResultsText = `${this.searchResultsCount} ${workerText} been found with the entered search criteria.`;
        },
        (error) => {
          this.workerRecords = [];
          this.searchResultsCount = 0;
          this.searchResultsText = `Something went wrong. Please try again.`;
          if (error.status === 404) {
            this.searchResultsText = `No worker(s) have been found with the entered search criteria.`;
          }
        }
      );
  }
  onPageChange(event: any) {
    this.paginationData.limit = event.pageSize;
    this.paginationData.skip = event.pageIndex * event.pageSize;
    if (this.otherSearchView !== 'basic') {
      this.searchWorkers(this.searchCriteria, true);
    } else {
      this.buildUrl(this.searchCriteria, this.paginationData.limit, this.paginationData.skip);
    }
  }

  pageSizeChangedEvent(event: any) {
    this.paginationData.limit = event;
    this.paginationData.skip = 0;
    if (this.otherSearchView !== 'basic') {
      this.searchWorkers(this.searchCriteria, true);
    } else {
      this.buildUrl(this.searchCriteria, this.paginationData.limit, this.paginationData.skip);
    }
  }

  onPageChanged(event: any) {
    this.paginationData.skip = event * this.paginationData.limit;
    if (this.otherSearchView !== 'basic') {
      this.searchWorkers(this.searchCriteria, true);
    } else {
      this.buildUrl(this.searchCriteria, this.paginationData.limit, this.paginationData.skip);
    }
  }

  handleAdvanceSearch(data: any) {
    this.resetPagination();
    this.searchCriteria = data.searchCriteria;
    this.buildUrl(this.searchCriteria);
  }

  handleSortChange(event: any): void {
    // Handle sort change event from grid component
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;
    
    // Re-fetch data with new sort parameters
    if (this.otherSearchView !== 'basic') {
      this.searchWorkers(this.searchCriteria, true);
    } else {
      this.buildUrl(this.searchCriteria, this.paginationData.limit, this.paginationData.skip);
    }
  }

  private buildUrl(searchCriteria: any, limit: number = 10, skip: number = 0): void {
    let url = '&isContractor=true';
    Object.keys(searchCriteria).forEach((key) => {
      if (searchCriteria[key]) {
        let paramKey = key;
        if (key === 'workerNumber') {
          const val = searchCriteria[key].toUpperCase();
          paramKey = 'workerNumberPrefix';
          searchCriteria[key] = val;
        } else if (key === 'lastName') {
          // Map lastName form field to familyName API parameter
          paramKey = 'familyName';
        } else if (key === 'firstName') {
          // Map firstName form field to givenName API parameter
          paramKey = 'givenName';
        } else if (key === 'birthDate') {
          // Map birthDate form field to dateOfBirth API parameter
          paramKey = 'dateOfBirth';
        } else if (key === 'ssn2') {
          // Map ssn2 form field to contractorSSN API parameter
          paramKey = 'contractorSSN';
        }
        const value = encodeURIComponent(searchCriteria[key]);
        url += `&${paramKey}=${value}`;
      }
    });
    this.workerManagementService
      .getWorkersWithAdvanceSearch(
        this.showType === 'active' ? false : true,
        url,
        limit,
        skip,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response) => {
          this.searchResultsCount = response.meta.total;
          this.workerRecords = response;
          const workerText = this.searchResultsCount === 1 ? 'worker has' : 'worker(s) have';
          this.searchResultsText = `${this.searchResultsCount} ${workerText} been found with the entered search criteria.`;
        },
        (error) => {
          this.workerRecords = [];
          this.searchResultsCount = 0;
          this.searchResultsText = `Something went wrong. Please try again.`;
          if (error.status === 404) {
            this.searchResultsText = `No worker(s) have been found with the entered search criteria.`;
          }
        }
      );
  }
  redirectToMoveContractors() {
    this.appService.changePage('/app/contractor-management/move-contractors');
  }
}
