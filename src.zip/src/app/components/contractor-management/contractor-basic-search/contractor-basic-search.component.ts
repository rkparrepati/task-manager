import { Component, EventEmitter, Output } from '@angular/core';
import { DropdownLookup } from 'src/app/shared/interfaces/models';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-contractor-basic-search',
  templateUrl: './contractor-basic-search.component.html',
  styleUrls: ['./contractor-basic-search.component.scss'],
})
export class ContractorBasicSearchComponent {
  @Output() search: EventEmitter<any> = new EventEmitter();
  public basicSearchDropdownValues: DropdownLookup[] = [];
  public searchForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.basicSearchDropdownValues = [
      { key: 'workerNumber', value: 'Contractor number' },
      { key: 'familyName', value: 'Last name' },
      { key: 'givenName', value: 'First name' },
      { key: 'preferredFirstName', value: 'Preferred first name' },
      { key: 'mulWorkerNumber', value: 'Contractor numbers(separated by comma and no space)' },
    ];

    this.searchForm = this.fb.group({
      searchCriteria: ['workerNumber'],
      searchValue: [''],
    });
  }

  public setSearchType() {
    this.search.emit(this.searchForm.value);
  }

  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType();
    }
  }
}
