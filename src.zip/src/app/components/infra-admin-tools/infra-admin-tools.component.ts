import { Component } from '@angular/core';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-infra-admin-tools',
  templateUrl: './infra-admin-tools.component.html',
  styleUrls: ['./infra-admin-tools.component.scss'],
})
export class InfraAdminToolsComponent {
  accessInfo: any = this.appService.getNavData();
  constructor(public appService: AppService) {}
}
