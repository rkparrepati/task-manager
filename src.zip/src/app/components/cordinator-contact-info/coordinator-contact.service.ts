import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/services/http.service';
import { CoordinatorContact } from './coordinator-contact.interface';
import { UtilityService } from '../../services/utility.service';

@Injectable({
  providedIn: 'root',
})
export class CoordinatorContactService {
  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  private buildUrlWithParams(queryParams: any): string {
    let urlWithParams = '';
    Object.keys(queryParams).forEach((key) => {
      const value = queryParams[key];
      if (value !== null && value !== undefined) {
        urlWithParams += `${key}=${encodeURIComponent(value)}&`;
      }
    });
    if (urlWithParams.endsWith('&')) {
      urlWithParams = urlWithParams.slice(0, -1);
    }
    return urlWithParams;
  }
  getCoorContactInfoList(
    url: string,
    includeInactive: boolean,
    limit: number = 10,
    skip: number = 0,
    sortColumn?: string,
    sortOrder: 'asc' | 'desc' = 'asc',
    searchText?: string
  ): Observable<any> {
    const queryParams: any = {
      includeInactive,
      skip: skip.toString(),
      limit: limit.toString(),
    };

    if (sortColumn) {
      queryParams.sortColumn = sortColumn;
    }
    if (searchText) {
      queryParams.searchText = searchText;
    }
    queryParams.sortOrder = sortOrder;

    return this.httpService.get(`/${url}?${this.buildUrlWithParams(queryParams)}`);
  }

  createCoordContactInfo(coordContact: Partial<CoordinatorContact>): Observable<any> {
    const requestObject: Partial<CoordinatorContact> = {
      coordinatorContactId: null,
      officeDescriptionText: coordContact.officeDescriptionText,
      acronymText: coordContact.acronymText,
      nameText: coordContact.nameText,
      phoneNo: coordContact.phoneNo,
      lifecycle: {
        beginDate:
          this.utilityService.adjustDateFormatter(this.utilityService.dateFormatter(new Date())) ||
          new Date().toISOString(),
        endDate: null,
      },
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lastModifiedUser: '',
        lockControlNumber: '',
      },
    };

    return this.httpService.post('/coordinator-contacts', requestObject);
  }

  updateCoordContactInfo(coordContact: CoordinatorContact): Observable<any> {
    return this.httpService.put(
      '/coordinator-contacts/' + coordContact.coordinatorContactId + '?lockControlNumber=' + coordContact.audit.lockControlNumber,
      coordContact
    );
  }

  deleteCoordContactInfo(coordContact: CoordinatorContact): Observable<any> {
    return this.httpService.delete(
      '/coordinator-contacts/' + coordContact.coordinatorContactId + '?lockControlNumber=' + coordContact.audit.lockControlNumber
    );
  }
}
