export interface CoordinatorContact {
  coordinatorContactId: number | null;
  officeDescriptionText: string;
  acronymText?: string;
  nameText?: string;
  phoneNo?: string;
  coordinator?: string;
  lifecycle: {
    beginDate: string;
    endDate: string | null;
  };
  audit: {
    createdDate: string;
    createdUser: string;
    lastModifiedDate: string;
    lastModifiedUser: string;
    lockControlNumber: string;
  };
}

export interface CoordinatorContactResponse {
  results: CoordinatorContact[];
  meta: {
    total: number;
  };
}
