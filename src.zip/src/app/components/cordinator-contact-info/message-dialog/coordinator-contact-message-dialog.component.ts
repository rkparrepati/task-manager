import { Component } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-coordinator-contact-message-dialog',
  templateUrl: './coordinator-contact-message-dialog.component.html',
  styleUrls: ['./coordinator-contact-message-dialog.component.scss'],
})
export class CoordinatorContactMessageDialogComponent {
  title = '';
  message = '';

  constructor(public bsModalRef: BsModalRef) {}
}
