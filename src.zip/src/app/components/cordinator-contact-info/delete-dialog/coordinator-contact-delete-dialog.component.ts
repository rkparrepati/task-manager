import { Component, Inject, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Subject } from 'rxjs';
import { CoordinatorContact } from '../coordinator-contact.interface';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-coordinator-contact-delete-dialog',
  templateUrl: './coordinator-contact-delete-dialog.component.html',
  styleUrls: ['./coordinator-contact-delete-dialog.component.scss'],
})
export class CoordinatorContactDeleteDialogComponent {
  // @Input() data!: CoordinatorContact;
  // public onClose: Subject<boolean> = new Subject();

  // constructor(public modalRef: BsModalRef) {}
   constructor(
      public dialogRef: MatDialogRef<CoordinatorContactDeleteDialogComponent>,
      @Inject(MAT_DIALOG_DATA)
      public data: {
         officeDescriptionText: string;
        acronymText: string;
        nameText: string;
        // Text: string;
        // title: string;
        // buttonText: { ok: string; cancel: string };
      }
    ) {}
  

  // onCancel(): void {
  //   this.onClose.next(false);
  //   this.modalRef.hide();
  // }

  // onConfirm(): void {
  //   this.onClose.next(true);
  //   this.modalRef.hide();
  // }

  onConfirm(): void {
    // Pass true back to the component that opened the dialog
    this.dialogRef.close(true);
  }

  onCancel(): void {
    // Pass false back to the component that opened the dialog
    this.dialogRef.close(false);
  }

  truncateText(text: string | undefined, length: number = 9): string {
    if (!text) return '';
    return text.length > length ? `${text.substring(0, length)}...` : text;
  }
}
