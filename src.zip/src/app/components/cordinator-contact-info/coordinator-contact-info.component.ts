import { Component, OnInit } from '@angular/core';
import { BsModalService,BsModalRef, ModalOptions } from 'ngx-bootstrap/modal';
import { CoordinatorContact } from './coordinator-contact.interface';
import { CoordinatorContactService } from './coordinator-contact.service';
import { CoordinatorContactDeleteDialogComponent } from './delete-dialog/coordinator-contact-delete-dialog.component';
import { CoordinatorContactMessageDialogComponent } from './message-dialog/coordinator-contact-message-dialog.component';
import { UtilityService } from '../../services/utility.service';
import { AppService } from 'src/app/services/app.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-coordinator-contact-info',
  templateUrl: './coordinator-contact-info.component.html',
  styleUrls: ['./coordinator-contact-info.component.scss'],
})
export class CoordinatorContactInfoComponent implements OnInit {
  public rolesEnum = ROLES_ENUM;
  appTitle = 'Coordinator Contact Information';
  moduleName = 'Coordinator Contact Information';
  showType = 'active';

  basicSearchText: string = '';
  referenceDataSearchSelected: string = '';

  coordContactInfoDescriptionHeader = 'Office description';
  coordContactInfoAcronymHeader = 'Acronym';
  coordContactInfoCoordinatorHeader = 'Coordinator';
  coordContactInfoPhoneNumberHeader = 'Phone number';

  coordContactModel = {
    selectedCoordContact: {} as CoordinatorContact,
    newCoordContact: {} as CoordinatorContact,
    coordContactList: [] as CoordinatorContact[],
  };

  addCoordContact = false;
  editCoordContact = false;
  includeInactive = false;

  sortColumn = 'officeDescriptionText';
  sortDirection: 'asc' | 'desc' = 'asc';
  limit = 10;
  total = 0;
  skip = 0;

  coordContactInfoInvalidAddMsg = '';
  coordContactInfoInvalidEditMsg = '';
  coordContactInfoInvalidEditErrMsg = '';

  hideMessage = true;
  returnMessage = '';
  returnCode:any;
  accessDenied = false;
  continueMessage = false;
  wholeMessage = '';
  errorList: boolean = false;
  lastModifiedLoginId = '';
  lastModifiedDate: Date | null = null;

  constructor(
    private coordContactService: CoordinatorContactService,
    private utilityService: UtilityService,
    private modalService: BsModalService,
    private dialog: MatDialog,
    public appService: AppService
  ) {}

  ngOnInit(): void {
    this.getCoordContactInfoList(this.limit, 0);
  }
  getCoordContactInfoList(limit: number = this.limit, skip: number = this.skip): void {
    const includeInactive = this.showType === 'all';
    let url = 'coordinator-contacts';
    
    
    this.coordContactService
      .getCoorContactInfoList(
        url,
        includeInactive,
        limit,
        skip,
        this.referenceDataSearchSelected,
        this.sortDirection,
        this.basicSearchText
      )
      .subscribe({
        next: (response) => {
          this.coordContactModel.coordContactList = response.results;
          this.total = response.meta.total;
          this.hideMessage = true;
          this.getLastModifiedInfo();
        },
        error: (error) => {
          this.returnMessage = this.utilityService.processFailureMessage(
            error,
            'No coordinator-contacts found that match the query'
          );
          this.hideMessage = false;
          this.returnCode = error.status;
          this.accessDenied = error.accessDenied;
          this.coordContactModel.coordContactList = [];
          this.total = 0;
        },
      });
  }

    sortBy(column: string): void {
    if (this.sortColumn === column) {
      // Toggle sort direction if clicking the same column
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and default to ascending
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.skip = 0;
    this.total = 0;
    this.getCoordContactInfoList();
  }

  searchKeyEventBasic(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.hideMessageDiv();
      this.getCoordContactInfoList(10, 0);
    }
  }

    pageSizeChangedEvent(limit: number) {
    this.limit = limit;
    this.skip = 0;
    this.total = 0;
    this.getCoordContactInfoList();
  }

  onPageChanged(pageNumber: number) {
    this.skip = (pageNumber - 1) * this.limit;
    this.getCoordContactInfoList();
  }

  private getLastModifiedInfo(): void {
    this.utilityService.getLastModifiedInfo('/coordinator-contacts').subscribe({
      next: (response: any) => {
        if (response?.results?.length > 0) {
          this.setLastModifiedInfo(response.results[0].audit);
        }
      },
      error: (error) => {      },
    });
  }

  private setLastModifiedInfo(auditObject: any): void {
    this.lastModifiedLoginId =
      auditObject.lastModifiedLoginId == undefined
        ? auditObject.lastModifiedUser
        : auditObject.lastModifiedLoginId;
    this.lastModifiedDate = new Date(auditObject.lastModifiedDate);
  }

  showCoordContactInfoAdd(): void {
    this.coordContactInfoDescriptionHeader = 'Office description *';
    this.addCoordContact = true;
    this.coordContactModel.newCoordContact = {} as CoordinatorContact;
    this.utilityService.scrollToTop();
  }

  cancelCoordContactInfo(): void {
    this.hideMessage = true;
    this.cancelAddEdit();
  }

  private cancelAddEdit(): void {
    if (!this.editCoordContact) {
      this.coordContactInfoDescriptionHeader = 'Office description';
    }
    this.addCoordContact = false;
    this.coordContactModel.newCoordContact = {} as CoordinatorContact;
    this.coordContactInfoInvalidAddMsg = '';
    this.hideMessage = true;
  }

  resetCoordContactInfo(): void {
    this.hideMessage = true;
    this.coordContactModel.newCoordContact = {} as CoordinatorContact;
    this.coordContactInfoInvalidAddMsg = '';
    this.basicSearchText = '';
  }

  createCoordContactInfo(): void {
    this.errorList = false;
    if (!this.validateAddForm()) {
      this.utilityService.scrollToTop();

      this.coordContactService
        .createCoordContactInfo(this.coordContactModel.newCoordContact)
        .subscribe({
          next: (response) => {
            this.returnCode = 201;
            this.hideMessage = false;
            this.setMessages(
              this.utilityService.getMessages(
                `Successfully created ${response.officeDescriptionText}`
              )
            );
             this.returnMessage =  `Successfully created ${response.officeDescriptionText}`;

             setTimeout(() => {
                  this.getCoordContactInfoList(this.limit, 0);
            this.cancelAddEdit()
             },2000);
            
          },
          error: (error) => {
            this.hideMessage = false;
            this.returnMessage = this.utilityService.processFailureMessage(
              error,
              'Problem encountered creating coordinator contact'
            );
            this.returnCode = error.status;
            this.accessDenied = error.accessDenied;
          },
        });
    } else {
      this.errorList = true;
      this.setMessage('700', this.utilityService.getInvalidInputErrorMessage());
    }
  }

  showCoordContactInfoEdit(coordContact: CoordinatorContact): void {
    if (this.addCoordContact || this.editCoordContact) {
      return;
    }

    // TODO: Replace with actual role check
    if (true) {
      // this.userRoles.includes('InfraAdmin') || this.userRoles.includes('InfraCoordContactAdmin')
      this.coordContactInfoDescriptionHeader = 'Office description *';
      this.coordContactModel.selectedCoordContact = { ...coordContact };
      this.editCoordContact = true;
    }
  }

  cancelEditCoordContact(): void {
    this.cancelEdit();
    this.hideMessage = true;
  }

  private cancelEdit(): void {
    if (!this.addCoordContact) {
      this.coordContactInfoDescriptionHeader = 'Office description';
    }
    this.coordContactModel.selectedCoordContact = {} as CoordinatorContact;
    this.editCoordContact = false;
    this.coordContactInfoInvalidEditMsg = '';
    this.coordContactInfoInvalidEditErrMsg = '';
  }

  resetEditCoordContact(coordContact: CoordinatorContact): void {
    this.coordContactModel.selectedCoordContact = { ...coordContact };
    this.coordContactInfoInvalidEditMsg = '';
    this.coordContactInfoInvalidEditErrMsg = '';
  }

  updateCoordContactInfo(coordContact: CoordinatorContact): void {
    if (!this.validateEditForm()) {
      this.utilityService.scrollToTop();
      this.coordContactService.updateCoordContactInfo(coordContact).subscribe({
        next: (response) => {
          this.returnCode = 201;
          this.hideMessage = false;
          this.returnMessage =  `Successfully updated ${response.officeDescriptionText}`;
          this.setMessages(
            this.utilityService.getMessages(
              `Successfully updated ${response.officeDescriptionText}`
            )
          );
         
           setTimeout(() => {
               this.getCoordContactInfoList(this.limit, 0);
          this.cancelEdit();
            }, 2000);
        },
        error: (error) => {
          this.returnMessage = this.utilityService.processFailureMessage(
            error,
            'Failed to update coordinator contact info'
          );
          this.hideMessage = false;
          this.returnCode = error.status;
          this.accessDenied = error.accessDenied;
        },
      });
    } else {
      this.setMessage('700', this.utilityService.getInvalidInputErrorMessage());
    }
  }

  deleteCoordContactInfo(coordContact: CoordinatorContact): void {
    const dialogRef = this.dialog.open(CoordinatorContactDeleteDialogComponent, {
      data: {
        officeDescriptionText: coordContact.officeDescriptionText,
        acronymText: coordContact.acronymText,
        nameText: coordContact.nameText
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.performDelete(coordContact);
      }
    });
  }

  private performDelete(coordContact: CoordinatorContact): void {
    this.utilityService.scrollToTop();

    this.coordContactService.deleteCoordContactInfo(coordContact).subscribe({
      next: () => {
        this.returnCode = '201';
        this.hideMessage = false;
        this.returnMessage =  `Successfully deleted ${coordContact.officeDescriptionText}`;
        this.setMessages(
          this.utilityService.getMessages(
            `Successfully deleted ${coordContact.officeDescriptionText}`
          )
        );

        setTimeout(() => {
          this.getCoordContactInfoList(this.limit, 0);
        }, 2000);
        
      },
      error: (error) => {
        this.hideMessage = false;
        this.returnMessage = this.utilityService.processFailureMessage(
          error,
          'Failed to delete coordinator contact info'
        );
        this.returnCode = error.status;
        this.accessDenied = error.accessDenied;
      },
    });
  }

  getTemplateCoordContactInfo(coordContact: CoordinatorContact): string {
    return coordContact.coordinatorContactId ===
      this.coordContactModel.selectedCoordContact.coordinatorContactId
      ? 'editCoordContactRow'
      : 'displayCoordContactRow';
  }

  hideMessageDiv(): void {
    this.hideMessage = true;
  }

  confirmUpdateCoordContact(coordContact: CoordinatorContact): void {
    this.updateCoordContactInfo(coordContact);
  }

  private setMessages(messages: string[]): void {
    if (!messages) {
      this.returnMessage = 'Unknown error message found';
      this.continueMessage = false;
      return;
    }

    if (messages.length > 1) {
      this.returnMessage = messages[1];
      this.wholeMessage = messages[0];
      this.continueMessage = true;
    } else {
      this.returnMessage = messages[0];
      this.continueMessage = false;
    }
  }

  private validateAddForm(): boolean {
    this.coordContactInfoInvalidAddMsg = '';
    if (this.coordContactModel.newCoordContact.officeDescriptionText) {
      if (this.coordContactModel.newCoordContact.officeDescriptionText.length < 4) {
        this.coordContactInfoInvalidAddMsg = 'Office description must be at least 4 chars';
      }
    } else {
      this.coordContactInfoInvalidAddMsg = 'Office description is required';
    }
    this.errorList = !!this.coordContactInfoInvalidAddMsg;
    return !!this.coordContactInfoInvalidAddMsg;
  }
  closeMessage(): void {
    this.errorList = false;
  }
  private validateEditForm(): boolean {
    this.errorList = false;
    this.coordContactInfoInvalidEditMsg = '';
    if (this.coordContactModel.selectedCoordContact.officeDescriptionText) {
      if (this.coordContactModel.selectedCoordContact.officeDescriptionText.length < 4) {
        this.coordContactInfoInvalidEditMsg = 'Office description must be at least 4 chars';
      }
    } else {
      this.coordContactInfoInvalidEditMsg = 'Office description is required';
    }
    this.errorList = !!this.coordContactInfoInvalidEditMsg;
    return !!this.coordContactInfoInvalidEditMsg;
  }

  showLargeMessage(): void {
  //   const modalRef = this.modalService.show(CoordinatorContactMessageDialogComponent, {
  //     initialState: {
  //       title: 'Message Details',
  //       message: this.wholeMessage,
  //     },
  //     class: 'modal-lg',
  //   });
  }

  resort(sortColumn: string, sortDirection: 'asc' | 'desc'): void {
    this.sortColumn = sortColumn;
    this.sortDirection = sortDirection;
    this.getCoordContactInfoList(this.limit, 0);
  }

  private setMessage(returnCode: string, returnMessage: string, response?: any): void {
    this.returnCode = returnCode;
    this.returnMessage = returnMessage;
    this.hideMessage = false;
    if (response) {
      this.accessDenied = response.accessDenied;
    }
  }

  exportDataCallback(): void {
    let url = '/coordinator-contacts/excelReport?';
    url += this.showType === 'all' ? 'includeInactive=true' : 'includeInactive=false';
    url += this.sortColumn ? `&sortColumn=${this.sortColumn}` : '';
    url += this.basicSearchText.length > 0 ? `&searchText=${this.basicSearchText}` : '';
    url += this.sortDirection ? `&sortOrder=${this.sortDirection}` : '&sortOrder=asc';

    this.utilityService.exportTableService(
      url,
      'CoordinatorContact.xls',
      'application/vnd.ms-excel'
    );
  }
}
