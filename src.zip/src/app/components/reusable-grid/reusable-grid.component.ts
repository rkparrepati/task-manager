import { Component, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { columnDefinition } from '../../components/reports-to/Models/IWorkerVM';

@Component({
  selector: 'app-reusable-grid',
  templateUrl: './reusable-grid.component.html',
  styleUrls: ['./reusable-grid.component.scss'],
})
export class ReusableGridComponent {
  @Input() data: any[] = [];
  @Input() title: string = '';
  @Input() columnDefinitions: columnDefinition[] = [];
  displayedColumns: string[] = [];
  datasource: MatTableDataSource<any> = new MatTableDataSource<any>([]);

  ngOnchanges(): void {
    this.displayedColumns = this.columnDefinitions.map((col) => col.key);
    this.datasource = new MatTableDataSource(this.data);
  }
}
