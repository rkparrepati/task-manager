import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderService } from './header.service';
import { AppService } from 'src/app/services/app.service';
import { AuthorizationService } from 'src/app/services/authorization.service';
import { OKTA_AUTH } from '@okta/okta-angular';
import { OktaAuth } from '@okta/okta-auth-js';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @Output() navDataEvent = new EventEmitter();
  moduleName: string = '';
  helpLink: string = '';
  employeeLocatorLink: string = '';
  userData: any = {};
  showModal: boolean = false;
  constructor(
    private router: Router,
    private headerService: HeaderService,
    private appService: AppService,
    private authorizationService: AuthorizationService,
    @Inject(OKTA_AUTH) private oktaAuth: OktaAuth
  ) {}
  ngOnInit(): void {
    this.headerService.getWhoAmI().subscribe(async (data: any) => {
      if (!data) {
        data = await this.oktaAuth.getUser();
      }
      // Check if firstName, lastName, or middleName are null and get from OKTA ID Token if needed
      if (!data.firstName || !data.lastName || !data.middleName) {
        const user = await this.oktaAuth.getUser();
        // Fill in missing values from OKTA claims
        if (!data.firstName) {
          const firstName = (await user).given_name;
          if (firstName) {
            data.firstName = firstName;
          }
        }
        if (!data.lastName) {
          const lastName = (await user).family_name;
          if (lastName) {
            data.lastName = lastName;
          }
        }
      }

      this.appService.setUserData(data);
      this.userData = this.appService.getUserData();
      const navData = this.authorizationService.getAccessInfo(this.userData.roles);
      this.appService.setNavData(navData);
      this.navDataEvent.emit();
    });
    this.headerService.getEmployeeLocator().subscribe((data: any) => {
      this.employeeLocatorLink = data.value;
    });
    this.headerService.getHelpLink().subscribe((data: any) => {
      this.helpLink = data.value;
    });
  }
  goHome() {
    this.appService.changePage('#/');
  }
  skipToContent() {}
}
