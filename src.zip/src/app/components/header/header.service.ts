import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';

@Injectable({
  providedIn: 'root',
})
export class HeaderService {
  constructor(private httpService: HttpService) {}
  getEmployeeLocator() {
    return this.httpService.get('/cedrinfralinks/locator');
  }
  getHelpLink() {
    return this.httpService.get('/cedrinfralinks/help');
  }
  getWhoAmI() {
    return this.httpService.get('/who-am-i');
  }
}
