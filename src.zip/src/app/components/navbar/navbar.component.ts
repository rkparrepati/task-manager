import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { AccessionSelectDialogComponent } from '../worker-management/accession-select-dialog/accession-select-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  accessInfo: any = this.appService.getNavData();
  openDropdown: string | null = null;
  constructor(
    public appService: AppService,
    private dialog: MatDialog,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.appService.navChange.subscribe((data: any) => {
      this.accessInfo = data;
    });
  }
  handleDropdownClick(dropdownId: string) {
    this.openDropdown = this.openDropdown === dropdownId ? null : dropdownId;
  }
  closeDropdown(dropdownId: string) {
    setTimeout(() => {
      if (this.openDropdown === dropdownId) {
        this.openDropdown = null;
      }
    }, 100);
  }
  handleAction() {
    this.openDropdown = null;
  }

  opeWorkerReportModal(): void {
    const dialogRef = this.dialog.open(AccessionSelectDialogComponent, {
      width: '504px',
      minHeight: '600px',
      height: 'auto',
      maxHeight: '90vh',
      autoFocus: false,
      disableClose: true,
      data: null,
      panelClass: 'worker-reports-dialog',
      position: { top: '80px' }
    });
    dialogRef.afterClosed().subscribe((result) => {      if (result === 'upload') {        this.router.navigate(['/app/workerForms']);
      }
    });
  }
}
