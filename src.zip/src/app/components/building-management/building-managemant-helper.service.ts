import { Injectable } from '@angular/core';
import { UtilityService } from 'src/app/services/utility.service';

@Injectable({
  providedIn: 'root',
})
export class BuildingManagemantHelperService {
  constructor(private utilityService: UtilityService) {}

  /**
   * Determines if the floor date is within the Building dates
   */
  checkDate(floorDate: Date, building: any) {
    if (!floorDate) {
      return true;
    }
    let dateError = this.utilityService.compareDates(
      new Date(building.lifecycle.beginDate),
      new Date(floorDate)
    );
    if (dateError === -1) {
      return false;
    } else {
      if (building.lifecycle.endDate) {
        dateError = this.utilityService.compareDates(
          new Date(floorDate),
          new Date(building.lifecycle.endDate)
        );
        if (dateError === -1) {
          return false;
        }
      }
    }

    return true;
  }
  isBuildingActive(building: any): boolean {
    const now = this.utilityService.dateFormatter(new Date());

    if (building.lifecycle.endDate) {
      return building.lifecycle.endDate >= now;
    } else {
      return true;
    }
  }
  invalidateFloors(building: any): string {
    let invalidFloorErrorFound = false;
    let floorErrorMessage = '';
    building.buildingFloors.forEach((floor: any) => {
      if (!invalidFloorErrorFound) {
        floorErrorMessage = 'Floor ' + floor.floorNumber + ': ';

        if (!this.checkDate(floor.lifecycle.beginDate, building)) {
          floorErrorMessage += 'Start';
          invalidFloorErrorFound = true;
        }

        if (building.lifecycle.endDate && floor.lifecycle.endDate) {
          const endDateValid = this.utilityService.compareDates(
            new Date(floor.lifecycle.endDate),
            new Date(building.lifecycle.endDate)
          );
          if (endDateValid < 0) {
            floorErrorMessage = this.addSlash(invalidFloorErrorFound, floorErrorMessage);

            floorErrorMessage += 'End ';
            invalidFloorErrorFound = true;
          }
        }
      }
    });

    if (invalidFloorErrorFound) {
      floorErrorMessage += ' date must be within building dates';
      return floorErrorMessage;
    } else {
      return '';
    }
  }
  addSlash(invalidFloorErrorFound: boolean, floorErrorMessage: string) {
    if (invalidFloorErrorFound) {
      floorErrorMessage += ' / ';
    }

    return floorErrorMessage;
  }

  /**
   * Determines if floor number already exists in the building
   */
  duplicateFloor(floorNumber: number, floorDetails: any): boolean {
    let foundFloorNumber: boolean = false;
    floorDetails.forEach((floor: any) => {
      if (floor.floorNumber === floorNumber) {
        foundFloorNumber = true;
      }
    });
    return foundFloorNumber;
  }

  checkLeadingZero(value: string): string {
    if (!value) {
      return '';
    }
    let stringFloor = value.toString();
    const startIsInt = parseInt(value);
    if (startIsInt % 1 !== 0) {
      return stringFloor;
    }

    if (startIsInt <= 9) {
      stringFloor = '0' + startIsInt;
    }

    return stringFloor;
  }
  getFloors(floorNumber: string): any {
    const floorList = [];
    let stringFloor;
    const hasDash = floorNumber.indexOf('-');
    if (hasDash > 0) {
      const startFlr = floorNumber.substring(0, hasDash);
      const endFlr = floorNumber.substring(hasDash + 1);

      const startIsInt = parseInt(startFlr);
      const endIsInt = parseInt(endFlr);
      if (startIsInt % 1 === 0 && endIsInt % 1 === 0) {
        if (startIsInt >= endIsInt) {
          floorList.push(floorNumber);
          return floorList;
        }
      } else {
        floorList.push(floorNumber);
        return floorList;
      }

      for (let i = startIsInt; i <= endIsInt; i++) {
        stringFloor = this.checkLeadingZero(i.toString());
        floorList.push(stringFloor);
      }
    } else {
      floorNumber = this.checkLeadingZero(floorNumber);
      floorList.push(floorNumber);
    }
    return floorList;
  }
  removeFloorFromList(floorList: any, floorToRemove: any) {
    let index: number = -1;
    let foundIndex: number = -1;
    floorList.forEach((floor: any) => {
      index++;
      if (floor.floorNumber === floorToRemove.floorNumber) {
        foundIndex = index;
      }
    });

    if (foundIndex >= 0) {
      floorList.splice(foundIndex, 1);
    }
  }
}
