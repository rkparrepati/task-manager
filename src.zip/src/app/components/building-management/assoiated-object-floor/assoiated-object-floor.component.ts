import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-assoiated-object-floor',
  templateUrl: './assoiated-object-floor.component.html',
  styleUrls: ['./assoiated-object-floor.component.scss'],
})
export class AssoiatedObjectFloorComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<AssoiatedObjectFloorComponent>) {}

  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
