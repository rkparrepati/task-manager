import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';
import { BuildingManagementService } from './building-management.service';
import { BuildingManagemantHelperService } from './building-managemant-helper.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { MatDialog } from '@angular/material/dialog';
import { InactivateBuildingConfirmComponent } from './inactivate-building-confirm/inactivate-building-confirm.component';
import { AssoiatedObjectBuildingComponent } from './assoiated-object-building/assoiated-object-building.component';
import { InactivateFloorConfirmComponent } from './inactivate-floor-confirm/inactivate-floor-confirm.component';
import { AssoiatedObjectFloorComponent } from './assoiated-object-floor/assoiated-object-floor.component';
import { ReactivateBuildingConfirmComponent } from './reactivate-building-confirm/reactivate-building-confirm.component';
import { ReactivateFloorConfirmComponent } from './reactivate-floor-confirm/reactivate-floor-confirm.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-building-management',
  templateUrl: './building-management.component.html',
  styleUrls: ['./building-management.component.scss'],
})
export class BuildingManagementComponent implements OnInit, OnDestroy {
  public rolesEnum = ROLES_ENUM;
  appTitle = 'Building Management';
  moduleName = 'Building Management';
  searchResultsMode = false;
  add = false;
  edit = false;

  floorNumber = '';
  sortColumn = 'buildingCode';
  sortDirection = 'asc';
  showType = 'active';
  total = 0;
  
  // Pagination properties (following transfer-search pattern)
  currentPage: number = 1;
  pageSize: number = 10;
  skip: number = 0;
  limit: number = 10;

  // Toast message properties for app-acme-navbar-component (following location component pattern)
  main = { creationDate: new Date() };
  resetTimeout: boolean = false;
  hideMessage: boolean = true;
  returnMessage: string = '';
  returnCode: string | number = '';
  returnMessageArray: string[] = [];
  
  // Subscription management
  private subscription: Subscription = new Subscription();
  floorErrorMessage: string = '';
  invalidBuildingCode: boolean = false;
  invalidBuildingDescription: boolean = false;
  invalidBuildingSiteCode: boolean = false;
  invalidBuildingStartDate: boolean = false;
  invalidBuildingAddressCity: boolean = false;
  invalidBuildingAddress: boolean = false;
  invalidBuildingAddressState: boolean = false;
  invalidBuildingAddressPostalCode: boolean = false;
  invalidStartFloor: boolean = false;
  invalidFloorStartDate: boolean = false;
  invalidFloorEndDate: boolean = false;
  invalidFloorEntry: boolean = false;
  invalidBuildingAddressPostalCodeSuffix: boolean = false;
  sites: any;
  states: any;
  currentSearchText: string | null = '';
  buildings: any = [];
  buildingModel: any = { buildings: [], selectedBuilding: {} };
  searchResults: string = '';
  accessDenied: any;
  allBuildings: any;
  siteModel: { sites: any } = { sites: [] };
  searchText: string = '';
  disableShowRadioButton: boolean = false;
  buildingCodeHeader: string = '';
  buildingNameHeader: string = '';
  buildingCodeName: string = '';
  floorStartDate: Date | null = null;
  floorEndDate: Date | null = null;
  buildingSiteCodeInvalid: boolean = false;
  beginDateErrorMessage: string | null = '';
  invalidUpdateFloorBeginDate: boolean = false;
  invalidUpdateFloorEndDate: boolean = false;
  updateFloorBeginDateErrorMessage: string | null = '';
  editedFloor: any | null = null;
  editFloorList: any;
  floorBeginDateErrorMessage: any;
  selectedFloor: any;
  updateFloorEndDateErrorMessage: any;
  updateFloorBeginDateErrorMessag: any;
  floorEndDateErrorMessage: string | null = null;

  constructor(
    private dialog: MatDialog,
    public appService: AppService,
    private utilityService: UtilityService,
    private httpService: HttpService,
    public buildingManagementService: BuildingManagementService,
    private buildingManagemantHelperService: BuildingManagemantHelperService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.buildingManagementService.updateHideMessage(true);
    
    // Subscribe to message observables for ACME navbar component (following location component pattern)
    this.subscription.add(
      this.buildingManagementService.hideMessage$.subscribe((val) => {        this.hideMessage = val;
      })
    );

    this.subscription.add(
      this.buildingManagementService.returnMessage$.subscribe((msg) => {        this.returnMessage = msg;
      })
    );

    this.subscription.add(
      this.buildingManagementService.returnCode$.subscribe((code) => {        this.returnCode = code;
      })
    );

    this.subscription.add(
      this.buildingManagementService.returnMessagesArray$.subscribe((messages) => {        this.returnMessageArray = messages;
      })
    );
    

    this.setRequiredFields('');
    this.cancelAllInvalidates();
    this.buildingCallBack();
  }

  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions to prevent memory leaks
    this.subscription.unsubscribe();
  }

  setMessage(returnCode: number, returnMessage: string, response?: any) {
    // Use service to emit messages for ACME navbar component (following location component pattern)
    this.buildingManagementService.updateReturnCode(returnCode);
    this.buildingManagementService.updateReturnMessage(returnMessage);
    this.buildingManagementService.updateHideMessage(false);
    
    if (response) {
      this.accessDenied = response.accessDenied;
    }
  }
  //* Resets all the invalid flags to false.
  cancelAllInvalidates() {
    this.floorErrorMessage = '';
    this.invalidBuildingCode = false;
    this.invalidBuildingDescription = false;
    this.invalidBuildingSiteCode = false;
    this.invalidBuildingStartDate = false;
    this.invalidBuildingAddress = false;
    this.invalidBuildingAddressCity = false;
    this.invalidBuildingAddressState = false;
    this.invalidBuildingAddressPostalCode = false;
    this.invalidStartFloor = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    this.invalidFloorEntry = false;
    this.invalidBuildingAddressPostalCodeSuffix = false;
  }

  /**
   * Resort method to handle sorting events from app-sort-button component
   * Following transfer-search pattern
   */
  resort(event: { columnName: string; sortOrder: string; sortId: string }): void {
    // Update local sorting state
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;

    // Reset to first page when sorting changes
    this.currentPage = 1;
    this.skip = 0;

    // Refresh the buildings list with new sort order
    this.getBuildingsList(this.limit, this.skip);
    this.cdr.detectChanges();
  }
  getTableParams(limit: number, skip: number) {
    return {
      limit: limit,
      skip: skip,
      sortOrder: this.sortDirection,
      sortColumn: this.sortColumn,
    };
  }
  /**
   * This method connects with building service to gets list of buildings.
   */
  getBuildingsList(limit: number, skip: number) {
    if (!this.add && !this.edit) {
      const includeInactive = this.showType === 'all';
      const tableParams = this.getTableParams(limit, skip);
      this.buildingManagementService
        .getBuildings(this.currentSearchText, includeInactive, tableParams)
        .subscribe({next:(response: any) => {
          this.buildings = response.results;
          this.buildingModel = {
            buildings: this.buildings,
          };
          this.total = response.meta.total;
          
          // First, set building active status before processing floors
          this.buildings.forEach((building: any) => {
            if (this.buildingManagemantHelperService.isBuildingActive(building)) {
              building.active = true;
            } else {
              building.active = false;
            }
            // Collapse all building views after refresh
            building.viewMode = 0;
          });
          
          // Then process floors (which also sets floor active status)
          this.processFloors();
          
          if (this.searchResultsMode) {
            this.searchResults = this.total + ' results found for ' + this.currentSearchText;
          }
          // Don't hide messages on refresh - let them persist for user to see
        }, error: (error: any) => {
          // Emit error message through service for ACME navbar component
          const errorMessage = this.utilityService.processFailureMessage(
            error,
            'Error retrieving buildings'
          );
          if (!this.searchResultsMode) {
            this.buildingManagementService.sendErrorMessage(errorMessage);
          }
          this.processFailureResponse(error, limit, skip, includeInactive, 'get');
        }});
    }
  }
  /**
   * Process all failure responses from service calls which includes handling a timeout
   */
  processFailureResponse(
    response: any,
    limit: number,
    skip: number,
    includeInactive: boolean,
    type: string
  ) {
    let messsageToUser;
    switch (type) {
      case 'get':
        if (!this.searchResultsMode) {
          messsageToUser = this.utilityService.processFailureMessage(
            response,
            'Error retrieving buildings'
          );
          this.setMessage(response.status, messsageToUser, response);
        } else {
          if (!includeInactive) {
            this.searchResults = 'No active buildings found for ' + this.currentSearchText;
          } else {
            this.searchResults = 'No buildings found for ' + this.currentSearchText;
          }
        }
        break;
      case 'save':
        this.setMessage(response.status, response.data.message, response);
        break;
      default:
        this.getBuildingsList(limit, skip);
        break;
    }
  }
  /**
   * This method is to get all buildings list to print
   */
  getAllBuildingsListToPrint(limit: number, skip: number) {
    if (!this.add && !this.edit) {
      const includeInactive = this.showType === 'all';
      const tableParams = this.getTableParams(limit, skip);
      this.buildingManagementService
        .getBuildings(this.currentSearchText, includeInactive, tableParams)
        .subscribe(
          (response: any) => {
            this.allBuildings = response.results;
          },
          (error: any) => {
            if (!this.searchResultsMode) {
              const userMessage = this.utilityService.processFailureMessage(
                error,
                'Error retrieving buildings'
              );
              this.setMessage(error.status, userMessage, error);
            } else {
              if (!includeInactive) {
                this.searchResults = 'No active buildings found for ' + this.currentSearchText;
              } else {
                this.searchResults = 'No buildings found for ' + this.currentSearchText;
              }
            }
          }
        );
    }
  }
  buildingCallBack() {
    this.sites = this.getSitesList();
    this.states = this.getStates();
    this.getBuildingsList(this.limit, this.skip);
  }
  /**
   * Building the floor table.
   */
  processFloors() {
    const today = new Date();
    today.setUTCHours(7, 0, 0);
    this.buildingModel.buildings.forEach((building: any) => {
      // Don't recalculate building.active here - it's already set in getBuildingsList()
      // This prevents overwriting the correct active status
      
      building.buildingFloors.forEach((floor: any) => {
        floor.active = true;
        try {
          const endDate = floor.lifecycle.endDate;
          if (endDate) {
            // marks floors that are inactive
            const anEndDate = new Date(endDate);
            if (anEndDate < today) {
              floor.active = false;
            }
          } else {
            floor.lifecycle.endDate = '';
          }
        } catch (error) {}
      });
      
      // Sort floor list by floor number (following location component pattern)
      this.sortFloorList(building.buildingFloors);
    });
  }

  /**
   * Sort floor list by floor number (following location component pattern)
   */
  sortFloorList(floorList: any[]): void {
    if (floorList && floorList.length > 0) {
      floorList.sort((a, b) => {
        // Convert floor numbers to strings for comparison
        const floorA = String(a.floorNumber || '').trim();
        const floorB = String(b.floorNumber || '').trim();
        
        // Extract numeric part and suffix (e.g., "10%" -> num: 10, suffix: "%")
        const matchA = floorA.match(/^(-?\d+\.?\d*)(.*)$/);
        const matchB = floorB.match(/^(-?\d+\.?\d*)(.*)$/);
        
        if (matchA && matchB) {
          const numA = parseFloat(matchA[1]);
          const numB = parseFloat(matchB[1]);
          const suffixA = matchA[2];
          const suffixB = matchB[2];
          
          // If numeric parts are valid, compare them first
          if (!isNaN(numA) && !isNaN(numB)) {
            if (numA !== numB) {
              return numA - numB;
            }
            // If numbers are equal, compare suffixes
            return suffixA.localeCompare(suffixB);
          }
        }
        
        // Fallback to string comparison for non-numeric floors
        return floorA.localeCompare(floorB, undefined, { numeric: true, sensitivity: 'base' });
      });
    }
  }

  /**
   * This method connects with Site service top get list of sites.
   */
  getSitesList() {
    const includeInactive = this.showType === 'all';
    this.buildingManagementService.getSites(includeInactive).subscribe(
      (response: any) => {
        this.sites = response.results;
        const selectBoxSites: any = [];
        this.sites.forEach((site: any) => {
          const aSite = {
            siteId: site.siteId,
            code: site.code,
            siteNameText: site.code + '/' + site.description,
          };
          selectBoxSites.push(aSite);
        });
        this.siteModel = {
          sites: selectBoxSites,
        };
      },
      (error) => {
        // Problem with getting sites from Infra Service
        // Emit error message through service
        this.buildingManagementService.sendErrorMessage('No sites found');
        this.setMessage(error.status, 'No sites found', error);
      }
    );
  }

  /**
   * Get the states from the building service
   */
  getStates() {
    this.buildingManagementService.getStates().subscribe(
      (response: any) => {
        const emptyStateObject = {
          id: '',
          description: '',
          inValidDate: '',
          longDescription: '',
          propsList: [],
          validDate: '',
          value: '',
        };
        this.states = response;
        this.states.splice(0, 0, emptyStateObject);
      },
      (error: any) => {
        let errorMessage;
        if (error.data && error.data.message) {
          errorMessage = error.data.message;
        } else {
          errorMessage = 'Not able to retrieve State List.';
        }
        // Emit error message through service
        this.buildingManagementService.sendErrorMessage(errorMessage);
        this.setMessage(error.status, errorMessage, error);
      }
    );
  }
  /**
   * Clear search results (if in view mode
   */
  clearSearchResults() {
    this.searchResultsMode = false;
    this.currentSearchText = null;
    this.searchText = '';
    this.getBuildingsList(this.limit, this.skip);
  }
  /**
   * Listens to show active/show all button.
   */
  toggleActiveAll() {
    this.hideMessageDiv();
    this.sites = this.getSitesList();
    // Reset to first page when toggling active/all
    this.currentPage = 1;
    this.skip = 0;
    // Refresh the buildings list when toggling between active/all
    this.getBuildingsList(this.limit, this.skip);
  }
  /**
   * Performs a search. When the table is reloading the search terms will be used to get the building list
   */
  search() {
    if (!this.edit && !this.add && this.searchText.length > 0) {
      this.buildingManagementService.updateHideMessage(true);
      this.searchResultsMode = true;
      this.currentSearchText = this.searchText.toUpperCase();
      // Reset to first page when searching
      this.currentPage = 1;
      this.skip = 0;
      this.getBuildingsList(this.limit, this.skip);
    }
  }
  /**
   * This method builds/rebuilds buildings tables in edit or read mode.
   * @param building Object
   */
  getBuildingTemplate(building: any) {
    if (building.viewMode === 2) {
      return 'editBuildingRow';
    } else if (building.viewMode === 1) {
      return 'detailsBuildingRow';
    } else {
      return 'displayBuildingRow';
    }
  }

  enableDisableShowActiveAll() {
    this.disableShowRadioButton = this.edit || this.add;
  }

  /**
   * This method is called on selecting Edit for a building.
   * @param building Object
   */
  editBuilding(building: any) {
    // User must have role of Building admin or Infra Admin to edit
    if (
      !this.appService.hasAnyRole([this.rolesEnum.INFRA_ADMIN, this.rolesEnum.INFRA_BUILDING_ADMIN])
    ) {
      return;
    }
    if (!this.edit && !this.add && building.active) {
      this.buildingModel.selectedBuilding = JSON.parse(JSON.stringify(building));
      if (!building.lifecycle.endDate) {
        this.buildingModel.selectedBuilding.lifecycle.endDate = '';
      }
      building.viewMode = 2;
      this.edit = true;
      // Place required * in table headers
      this.setRequiredFields('*');
      this.floorNumber = '';
      this.hideMessageDiv();
      this.floorStartDate = new Date();
      this.floorEndDate = null;
      this.enableDisableShowActiveAll();
    }
  }

  /**
   * This method is called on selecting Reset for a building.
   * @param building Object
   */
  resetBuilding(building: any) {
    if (building) {
      // It is in edit mode. Reset the selected building for this row
      this.buildingModel.selectedBuilding = JSON.parse(JSON.stringify(building));
      if (!this.buildingModel.selectedBuilding.lifecycle.endDate) {
        this.buildingModel.selectedBuilding.lifecycle.endDate = null;
      }
      this.floorStartDate = new Date();
      this.floorEndDate = null;
      this.floorNumber = '';
    } else {
      this.resetAddBuilding();
    }
    this.buildingManagementService.updateHideMessage(true);
    this.cancelAllInvalidates();
  }

  /**
   * NOTE: saveBuilding() method has been removed from parent component.
   * Building save operations are now handled entirely by the edit-building child component.
   * The child component emits all messages through the service, and the parent subscribes to them.
   */

  /**
   * This method is called on selecting open button for a building.
   * Toggles between collapsed (0) and info view (1).
   */
  setShowMode(building: any) {
    this.setRequiredFields('');
    this.cancelAllInvalidates();
    // Toggle between collapsed (0) and info view (1)
    building.viewMode = building.viewMode === 1 ? 0 : 1;
  }

  /**
   * This method is called when clicking on building cells (code, description, site).
   * Opens info view if not already in edit mode.
   */
  openShowMode(building: any) {
    // Only open if collapsed (0) and not in edit mode (2)
    if (building.viewMode === 0) {
      building.viewMode = 1;
      this.setRequiredFields('');
      this.cancelAllInvalidates();
    }
  }

  /**
   * This method is called on selecting close button for a building.
   * Collapses the building info view.
   */
  setViewMode(building: any) {
    this.setRequiredFields('');
    this.cancelAllInvalidates();
    building.viewMode = 0;
  }

  setRequiredFields(requiredCharacter: any) {
    this.buildingCodeHeader = 'Building code ' + requiredCharacter;
    this.buildingNameHeader = 'Building name ' + requiredCharacter;
    this.buildingCodeName = 'Site code/name ' + requiredCharacter;
  }

  /**
   * This method is called on selecting Cancel from Edit mode for a building.
   */
  cancelBuilding() {
    this.buildingModel.selectedBuilding = null;
    this.setRequiredFields('');
    this.cancelAllInvalidates();
    this.floorNumber = '';
    this.floorStartDate = new Date();
    this.floorEndDate = null;
    this.edit = false;
    this.add = false;
    this.enableDisableShowActiveAll();
    // Don't hide messages here - they should persist after save operations
    // Messages are only hidden when user manually closes them or starts a new operation
    this.buildingModel.buildings.forEach((aBuilding: any) => {
      aBuilding.viewMode = 0;
    });
    this.cancelUpdateFloor();
  }

  /**
   * NOTE: validateBuildingParameters() and invalidateAddress() methods have been removed from parent component.
   * Building validation is now handled entirely by the edit-building child component.
   */

  /**
   * This method is called on viewing the building details. Calls controller method to show building details.
   */
  viewBuilding(building: any) {
    this.buildingModel.selectedBuilding = JSON.parse(JSON.stringify(building));
    this.setRequiredFields('');

    this.add = false;
    this.enableDisableShowActiveAll();
    building.viewMode = 1;
  }
  /**
   * This method shows row to add new building. This method is called on selecting Add.
   */
  showAddRow() {
    if (!this.edit && !this.add) {
      this.add = true;
      this.setRequiredFields('*');
      this.resetAddBuilding();
      this.hideMessageDiv();
      this.changeState(0);
      this.enableDisableShowActiveAll();
      // Set floor start date to today's date
      this.floorStartDate = new Date();
      this.floorEndDate = null;
    }
  }
  /**
   * Reset the add building model. Called from add mode Reset button.
   */
  resetAddBuilding() {
    this.buildingModel.selectedBuilding = {
      lifecycle: {
        beginDate: new Date().toISOString(),
        endDate: null,
      },
      address: {
        addressLine2: '',
        postalCode: '',
        addressLineTwo: '',
        stateCode: this.states[0]?.value || '',
      },
      site: {
        siteId: null,
      },
      buildingFloors: [],
    };
    this.floorStartDate = new Date();
    this.floorEndDate = null;
    this.floorNumber = '';
  }
  /**
   * This method is called on selecting Delete for a building.
   */
  hideMessageDiv() {
    // Use service to hide message for ACME navbar component (following location component pattern)
    this.buildingManagementService.updateHideMessage(true);
    this.buildingManagementService.updateReturnMessage('');
  }

  changeState(state: any) {
    if (this.add || this.edit) {
      return;
    }
    this.buildingModel.buildings.forEach((aBuilding: any) => {
      aBuilding.viewMode = state;
    });
  }
  /**
   * triggered by enter key on building search input box.
   */
  searchKeyEvent($event: any) {
    if (this.add || this.edit) {
      return;
    }
    if ($event.keyCode === 13) {
      this.search();
    }
  }

  /**
   * triggered by enter key on floor add input box.
   */
  addFloorKeyEvent($event: any) {
    if ($event.keyCode === 13) {
      this.addFloors();
    }
  }

  /**
   * deletes floors where check box is checked.
   */
  deleteFloors() {
    const newFloorList: any = [];
    const currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;
    currentFloorDetails.forEach((floor: any) => {
      if (!floor.floorChecked) {
        newFloorList.push(floor);
      }
    });
    this.buildingModel.selectedBuilding.buildingFloors = newFloorList;
  }

  /**
   * Put the floor in edit mode
   */
  editFloor(floor: any) {
    floor.edit = true;
    const newFloorList: any = [];
    const currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;
    currentFloorDetails.forEach((floor: any) => {
      if (floor.floorChecked) {
        newFloorList.push(floor);
      }
    });
    this.editFloorList = newFloorList;
  }

  /**
   * Resets for floor start date when reset is clicked on
   * building edit
   */
  resetFloorStartDate() {
    this.invalidStartFloor = false;
  }

  /**
   * Add the floors to the list. Updates the floor model.
   * Called when user clicks the Plus button next to the
   * floors input box.
   */
  addFloors() {    // Clear all previous validation messages at the start of each add floor operation (following location pattern)
    this.buildingManagementService.updateReturnMessageArray([]);
    this.buildingManagementService.updateHideMessage(true);
    
    // 1. Reset flags
    this.invalidFloorEntry = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    
    // Collect all validation errors before displaying (following location pattern)
    let validationErrors: string[] = [];
    
    // 2. Initial Validation (floorNumber required check)
    if (!this.floorNumber || this.floorNumber.trim() === '') {
      const requiredMessage = 'Floor number is required';
      validationErrors.push(requiredMessage);
      
      // Display validation error using array pattern (following location pattern)
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
      return;
    }

    // 3. Validate dates before processing floors
    this.floorBeginDateErrorMessage = this.utilityService.validateBeginDate(
      this.floorStartDate?.toISOString()
    );
    if (this.floorBeginDateErrorMessage) {
      this.invalidFloorStartDate = true;
      validationErrors.push(this.floorBeginDateErrorMessage);
    }

    this.floorEndDateErrorMessage = this.utilityService.validateEndDate(
      this.floorStartDate?.toISOString() || '',
      this.floorEndDate?.toISOString()
    );
    if (this.floorEndDateErrorMessage) {
      this.invalidFloorEndDate = true;
      validationErrors.push(this.floorEndDateErrorMessage);
    }

    // If there are date validation errors, display them and return
    if (validationErrors.length > 0) {
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
      return;
    }

    // 4. Processing Logic
    const floors = this.buildingManagemantHelperService.getFloors(this.floorNumber);
    let currentFloorDetails: any;
    if (!this.buildingModel.selectedBuilding.buildingFloors) {
      this.buildingModel.selectedBuilding.buildingFloors = [];
    }
    currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;

    // Pre-validate all floors before processing (following location pattern)
    let hasDuplicates = false;
    let duplicateFloors: string[] = [];
    
    floors.forEach((floor: any) => {
      // Check floor length
      if (floor.length > 4) {
        this.invalidFloorEntry = true;
        const lengthMessage = `Floor number '${floor}' exceeds maximum length of 4 characters`;
        // Add to validation errors if not already present
        if (!validationErrors.includes(lengthMessage)) {
          validationErrors.push(lengthMessage);
        }
      }
      
      // Check for duplicates
      if (this.buildingManagemantHelperService.duplicateFloor(floor, currentFloorDetails)) {
        hasDuplicates = true;
        duplicateFloors.push(floor);
      }
    });
    
    // If there are validation errors, display them and return
    if (validationErrors.length > 0) {
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
      return;
    }
    
    // Add valid floors
    let addedFloors: string[] = [];
    floors.forEach((floor: any) => {
      if (floor.length <= 4 && !this.buildingManagemantHelperService.duplicateFloor(floor, currentFloorDetails)) {
        const floorDetail = {
          floorNumber: floor.toUpperCase(),
          lifecycle: {
            beginDate: this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(this.floorStartDate || '')
            ),
            endDate: null,
          },
          active: true,
        };
        this.buildingModel.selectedBuilding.buildingFloors.push(floorDetail);
        addedFloors.push(floor.toUpperCase());
      }
    });
    
    // Sort floor list after adding new floors (following location component pattern)
    this.sortFloorList(this.buildingModel.selectedBuilding.buildingFloors);
    
    // Handle duplicate floor message (following location pattern)
    if (hasDuplicates) {
      const duplicateMessage = `Floor(s) ${duplicateFloors.join(', ')} already exist(s) in building. Non-duplicate floors have been added.`;
      this.buildingManagementService.updateReturnCode(400);
      this.buildingManagementService.updateReturnMessage(duplicateMessage);
      this.buildingManagementService.updateReturnMessageArray([]);
      this.buildingManagementService.updateHideMessage(false);
    } else if (addedFloors.length > 0) {
      // Success message for added floors
      const successMessage = `Floor(s) ${addedFloors.join(', ')} successfully added`;
      this.buildingManagementService.updateReturnCode(200);
      this.buildingManagementService.updateReturnMessage(successMessage);
      this.buildingManagementService.updateReturnMessageArray([]);
      this.buildingManagementService.updateHideMessage(false);
    }
    
    // Clear input
    this.floorNumber = '';
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
  }
  invalidFloorDates() {
    this.floorBeginDateErrorMessage = this.utilityService.validateBeginDate(
      this.floorStartDate?.toISOString()
    );
    if (this.floorBeginDateErrorMessage) {
      this.invalidFloorStartDate = true;
    }

    this.floorEndDateErrorMessage = this.utilityService.validateEndDate(
      this.floorStartDate?.toISOString() || '',
      this.floorEndDate?.toISOString()
    );
    if (this.floorEndDateErrorMessage) {
      this.invalidFloorEndDate = true;
    }

    if (this.invalidFloorStartDate || this.invalidFloorEndDate) {
      return true;
    }
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    return false;
  }
  /**
   * get template for floor in location edit mode
   */
  getFloorTemplateEdMode(floor: any) {
    if (this.editedFloor && floor.floorNumber === this.editedFloor.floorNumber) {
      return 'floorEditAddMode';
    }
    return 'floorDisplayAddMode';
  }
  /**
   * This method is to show update floor view
   */
  //   this.selectedFloor = null;
  showUpdateFloor(editFloor: any) {
    this.selectedFloor = editFloor;
    if (!this.editedFloor) {
      this.editedFloor = JSON.parse(JSON.stringify(editFloor));
      if (!this.editedFloor.endDate) {
        this.editedFloor.endDate = null;
      }
    }
  }
  /**
   * This method is to cancel update floor
   */
  cancelUpdateFloor() {
    this.invalidUpdateFloorBeginDate = false;
    this.invalidUpdateFloorEndDate = false;
    this.updateFloorBeginDateErrorMessage = null;
    this.updateFloorBeginDateErrorMessage = null;
    this.editedFloor = null;
  }
  updateFloor() {
    this.invalidUpdateFloorBeginDate = false;
    this.invalidUpdateFloorEndDate = false;
    this.updateFloorBeginDateErrorMessage = this.utilityService.validateBeginDate(
      this.editedFloor.lifecycle.beginDate
    );
    if (this.updateFloorBeginDateErrorMessage) {
      this.invalidUpdateFloorBeginDate = true;
    }
    if (this.updateFloorEndDateErrorMessage) {
      this.invalidUpdateFloorEndDate = true;
    }
    if (this.updateFloorBeginDateErrorMessag || this.updateFloorEndDateErrorMessage) {
      return;
    }
    this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
      if (this.editedFloor.floorNumber === floor.floorNumber) {
        floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
          this.utilityService.dateFormatter(new Date(this.editedFloor.lifecycle.beginDate))
        );
        floor.lifecycle.endDate = !!this.editedFloor.lifecycle.endDate
          ? this.utilityService.adjustEndDateFormatter(
              this.utilityService.dateFormatter(new Date(this.editedFloor.lifecycle.endDate))
            )
          : '';
      }
    });
    this.editedFloor = null;
  }
  /**
   * This methods shows confirmation message before
   * in-activating a building
   */
  confirmInactivateBuilding(building: any) {
    building.viewMode = 1;
    
    // Show the inactivate confirmation dialog
    const dialogRef = this.dialog.open(InactivateBuildingConfirmComponent, {
      width: '25vw',
      height: '100',
      disableClose: true,
      data: { building: building, type: 'B' },
    });
    
    dialogRef.afterClosed().subscribe((inactivateBuilding: any) => {
      // Only proceed if user confirmed (clicked Confirm button, not X or Cancel)
      if (inactivateBuilding === true) {
        building.lifecycle.endDate = this.utilityService.adjustEndDateFormatter(
          this.utilityService.dateFormatterEndDate(
            new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
          )
        );
        building.lifecycle.cascade = true;
        
        // Try to inactivate the building
        this.buildingManagementService.inactivateBuilding(building).subscribe({
          next: (responseInactivateBuilding: any) => {
            const successMessage = 'Successfully inactivated building: ' + responseInactivateBuilding.buildingCode;
            
            // Use direct service methods for consistent message handling
            this.buildingManagementService.scrolltoTop();
            this.buildingManagementService.updateReturnCode(200);
            this.buildingManagementService.updateReturnMessage(successMessage);
            this.buildingManagementService.updateReturnMessageArray([]);
            this.buildingManagementService.updateHideMessage(false);
            
            // Refresh the table to show updated building state (with reactivate icon)
            // Maintain search context if in search mode
            this.getBuildingsList(this.limit, this.skip);
          },
          error: (error: any) => {
            // When inactivation fails, show the associated objects dialog
            // The dialog will fetch and display associated locations
            const innerDialogRef = this.dialog.open(AssoiatedObjectBuildingComponent, {
              width: '800px',
              disableClose: true,
              data: { building: building, type: 'B' },
            });
            
            innerDialogRef.afterClosed().subscribe((result: any) => {
              // Only display error message if user clicked OK (result === true)
              // If user closed with X or Cancel (result === false), do nothing
              if (result === true) {
                const displayMessage = `Building ${building.buildingCode} cannot be inactivated. There are locations associated to the building.`;
                
                this.buildingManagementService.scrolltoTop();
                this.buildingManagementService.updateReturnCode(400);
                this.buildingManagementService.updateReturnMessage(displayMessage);
                this.buildingManagementService.updateReturnMessageArray([]);
                this.buildingManagementService.updateHideMessage(false);
              }
              
              this.edit = false;
              this.add = false;
            });
          }
        });
      }
      // If user closed dialog with X or Cancel (inactivateBuilding is false), do nothing
    });
  }
  /**
   * This methods shows confirmation message before in-activating a floor
   */
  confirmInactivateFloor(floorEdited: any) {
    if (!floorEdited.buildingFloorId) {
      this.buildingManagemantHelperService.removeFloorFromList(
        this.buildingModel.selectedBuilding.buildingFloors,
        floorEdited
      );
      return;
    }

    const dialogRef = this.dialog.open(InactivateFloorConfirmComponent, {
      width: '25vw',
      height: '100',
      disableClose: true,
      data: { floor: floorEdited },
    });
    dialogRef.afterClosed().subscribe((inactivate: any) => {
      // Only proceed if user confirmed (clicked Confirm button, returns true)
      // If user clicked Cancel or X, inactivate will be a string or falsy, so don't proceed
      if (inactivate === true) {
        let floorLifecycleValid: string | null = null;
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          if (floorEdited.floorNumber === floor.floorNumber) {
            floor.lifecycle.endDate = this.utilityService.adjustEndDateFormatter(
              this.utilityService.dateFormatterEndDate(
                new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
              )
            );
            floorLifecycleValid = this.utilityService.validateInactivateEndDate(floor.lifecycle);
            floor.lifecycle.cascade = true;
          }
        });
        if (floorLifecycleValid) {
          // Emit validation error message through service
          this.buildingManagementService.sendErrorMessage('Building floor inactivation failed: ' + floorLifecycleValid);
          this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
            floor.lifecycle.endDate = '';
            floor.lifecycle.cascade = false;
          });
        } else {
          this.updateBuildingObject(floorEdited);
        }
      }
    });
  }
  updateBuildingObject(floorEdited: any) {
    const updateBuildingObject = {
      buildingCode: this.buildingModel.selectedBuilding.buildingCode,
      buildingDescription: this.buildingModel.selectedBuilding.buildingDescription,
      lifecycle: this.buildingModel.selectedBuilding.lifecycle,
      buildingFloors: this.buildingModel.selectedBuilding.buildingFloors,
      site: this.buildingModel.selectedBuilding.site,
      address: this.buildingModel.selectedBuilding.address,
      audit: {
        lockControlNumber: this.buildingModel.selectedBuilding.audit.lockControlNumber,
      },
    };

    const url = '/buildings/' + this.buildingModel.selectedBuilding.buildingId;
    this.buildingManagementService.inactivateBuildingFloor(updateBuildingObject, url).subscribe({
      next: () => {
        const successMessage = 'Successfully inactivated building floor';
        
        // Use direct service methods for consistent message handling
        this.buildingManagementService.scrolltoTop();
        this.buildingManagementService.updateReturnCode(200);
        this.buildingManagementService.updateReturnMessage(successMessage);
        this.buildingManagementService.updateReturnMessageArray([]);
        this.buildingManagementService.updateHideMessage(false);
        
        // Refresh the table to show updated floor state
        // Maintain search context if in search mode
        this.getBuildingsList(this.limit, this.skip);
      },
      error: (error: any) => {
        this.handleInactivateResponse(error, floorEdited);
      }
    });
  }
  handleInactivateResponse(responseInactivate: any, floorEdited: any) {
    if (
      responseInactivate.statusCode === 400 &&
      responseInactivate.statusMessage.indexOf('workers associated to the location') > -1
    ) {
      const dialogRef = this.dialog.open(AssoiatedObjectFloorComponent, {
        width: '25vw',
        height: '100',
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe((result: any) => {
        this.setShowMode(this.updateBuildingObject);
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          floor.lifecycle.endDate = '';
          floor.lifecycle.cascade = false;
        });
      });
    } else {
      // Emit error message through service
      this.buildingManagementService.sendErrorMessage(
        'Building floor inactivation failed: ' + responseInactivate.statusMessage
      );
      this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
        floor.lifecycle.endDate = '';
        floor.lifecycle.cascade = false;
      });
    }
  }
  /**
   * This methods shows confirmation message before re-activating a building
   */
  confirmReactivateBuilding(building: any) {
    const dialogRef = this.dialog.open(ReactivateBuildingConfirmComponent, {
      width: '25vw',
      height: '100',
      disableClose: true,
      data: { building: building },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      // Only proceed if user confirmed (clicked Confirm button, returns true)
      // If user clicked Cancel or X, result will be a string or falsy, so don't proceed
      if (result !== true) {
        return;
      }
      
      this.buildingManagementService
        .getAssociatedSite(building.site.siteId)
        .subscribe((response: any) => {
          if (response.lifecycle.endDate) {
            // Emit error message through service
            this.buildingManagementService.sendErrorMessage('Building cannot be reactivated. Associated site is not active.');
          } else {
            // Clear the building's endDate to reactivate it
            building.lifecycle.endDate = '';
            
            // Also clear all floor endDates
            building.buildingFloors.forEach((floor: any) => {
              floor.lifecycle.endDate = '';
            });
            
            this.buildingManagementService
              .reactivateBuilding(building)
              .subscribe({
                next: (response: any) => {
                  const successMessage = 'Successfully reactivated building: ' + response.buildingCode;
                  
                  // Use direct service methods for consistent message handling
                  this.buildingManagementService.scrolltoTop();
                  this.buildingManagementService.updateReturnCode(200);
                  this.buildingManagementService.updateReturnMessage(successMessage);
                  this.buildingManagementService.updateReturnMessageArray([]);
                  this.buildingManagementService.updateHideMessage(false);
                  
                  // Refresh the table to show updated building state (with inactivate icon)
                  // Maintain search context if in search mode
                  this.getBuildingsList(this.limit, this.skip);
                },
                error: (error: any) => {
                  // Handle error using direct pattern
                  const errorMessages: string[] = [];
                  let errorMessage = 'Failed to reactivate building';
                  
                  if (error?.error?.message) {
                    errorMessage = error.error.message;
                  } else if (error?.data?.message) {
                    errorMessage = error.data.message;
                  } else if (error?.message) {
                    errorMessage = error.message;
                  }
                  
                  errorMessages.push(errorMessage);
                  
                  this.buildingManagementService.updateReturnCode(error?.status || 500);
                  this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
                  this.buildingManagementService.updateReturnMessageArray(errorMessages);
                  this.buildingManagementService.updateHideMessage(false);
                }
              });
          }
        });
    });
  }
  /**
   * This methods shows confirmation message before re-activating a floor
   */
  confirmReactivateFloor(floorEdited: any) {
    const dialogRef = this.dialog.open(ReactivateFloorConfirmComponent, {
      width: '25vw',
      height: '100',
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      // Only proceed if user confirmed (clicked Confirm button, returns true)
      // If user clicked Cancel or X, result will be a string or falsy, so don't proceed
      if (result !== true) {
        return;
      }
      
      if (this.buildingModel.selectedBuilding.lifecycle.endDate) {
        // Emit error message through service
        this.buildingManagementService.sendErrorMessage('Floor cannot be reactivated. Associated building is not active.');
      } else {
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          if (floorEdited.floorNumber === floor.floorNumber) {
            floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(new Date(floor.lifecycle.beginDate))
            );
            floor.lifecycle.endDate = '';
            floor.cascade = false;
          }
        });
        const updateBuildingObject = {
          buildingCode: this.buildingModel.selectedBuilding.buildingCode,
          buildingDescription: this.buildingModel.selectedBuilding.buildingDescription,
          lifecycle: this.buildingModel.selectedBuilding.lifecycle,
          buildingFloors: this.buildingModel.selectedBuilding.buildingFloors,
          site: this.buildingModel.selectedBuilding.site,
          address: this.buildingModel.selectedBuilding.address,
          audit: {
            lockControlNumber: this.buildingModel.selectedBuilding.audit.lockControlNumber,
          },
        };
        this.buildingManagementService
          .reactivateBuildingFloor(
            updateBuildingObject,
            `buildings/${this.buildingModel.selectedBuilding.buildingId}`
          )
          .subscribe({
            next: (response: any) => {
              const successMessage = 'Successfully reactivated building floor';
              
              // Use direct service methods for consistent message handling
              this.buildingManagementService.scrolltoTop();
              this.buildingManagementService.updateReturnCode(200);
              this.buildingManagementService.updateReturnMessage(successMessage);
              this.buildingManagementService.updateReturnMessageArray([]);
              this.buildingManagementService.updateHideMessage(false);
              
              // Refresh the table to show updated floor state
              // Maintain search context if in search mode
              this.getBuildingsList(this.limit, this.skip);
            },
            error: (error: any) => {
              // Handle error using direct pattern
              const errorMessages: string[] = [];
              let errorMessage = 'Building floor could not be reactivated';
              
              if (error?.error?.message) {
                errorMessage = error.error.message;
              } else if (error?.data?.message) {
                errorMessage = error.data.message;
              } else if (error?.message) {
                errorMessage = error.message;
              }
              
              errorMessages.push(errorMessage);
              
              this.buildingManagementService.updateReturnCode(error?.status || 500);
              this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
              this.buildingManagementService.updateReturnMessageArray(errorMessages);
              this.buildingManagementService.updateHideMessage(false);
            }
          });
      }
    });
  }
  /**
   * This method is to export data for building management
   */
  exportDataCallback() {
    // Determine includeInactive based on current showType
    const includeInactive = this.showType === 'all' ? true : false;
    
    // Build URL with query parameters
    let url = `/buildings/excelReport?includeInactive=${includeInactive}`;
    
    // Add search text if present
    if (this.searchText) {
      url += `&codePrefix=${this.searchText}`;
    }
    
    const fileName = 'Building Management.xls';
    
    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';
          
          // Append to body to ensure it works in Firefox
          document.body.appendChild(a);
          a.click();
          
          // Clean up
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
        }
      },
      error: (error) => {        // Emit error message through service for ACME navbar component
        const errorMessage = `Failed to download Excel report: ${error.error?.message || error.message || 'Unknown error'}`;
        this.buildingManagementService.sendErrorMessage(errorMessage);
      }
    });
  }

  /**
   * Pagination methods (following transfer-search pattern)
   */
  
  /**
   * Handle page change event from pagination component
   */
  onPageChanged(page: number): void {
    this.currentPage = page;
    this.skip = (this.currentPage - 1) * this.limit;
    
    // Refresh buildings list with new pagination
    this.getBuildingsList(this.limit, this.skip);
    this.cdr.detectChanges();
  }

  /**
   * Handle page size change event from pagination component
   */
  onPageSizeChanged(size: number): void {
    this.limit = size;
    this.pageSize = size;
    this.currentPage = 1; // Reset to page 1 when page size changes
    this.skip = 0;
    
    // Refresh buildings list with new page size
    this.getBuildingsList(this.limit, this.skip);
    this.cdr.detectChanges();
  }
}
