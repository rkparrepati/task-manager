import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { OnInit } from '@angular/core';

@Component({
  selector: 'app-inactivate-building-confirm',
  templateUrl: './inactivate-building-confirm.component.html',
  styleUrls: ['./inactivate-building-confirm.component.scss'],
})
export class InactivateBuildingConfirmComponent implements OnInit {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<InactivateBuildingConfirmComponent>) {}

  ngOnInit() {  }

  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
