import { Component, Input } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';
import { BuildingManagementService } from '../building-management.service';
import { BuildingManagemantHelperService } from '../building-managemant-helper.service';

@Component({
  selector: 'app-new-floor',
  templateUrl: './new-floor.component.html',
  styleUrls: ['./new-floor.component.scss'],
})
export class NewFloorComponent {
  @Input() buildingModel: any = { buildings: [], selectedBuilding: {} };

  invalidFloorEntry: boolean = false;
  invalidFloorEndDate: boolean = false;
  invalidFloorStartDate: boolean = false;

  floorNumber: string = '';
  floorStartDate: Date | null = null;
  floorEndDate: Date | null = null;
  floorEndDateErrorMessage: string | null = '';
  floorBeginDateErrorMessage: string | null = '';

  constructor(
    public appService: AppService,
    private utilityService: UtilityService,
    private buildingManagementService: BuildingManagementService,
    private buildingManagemantHelperService: BuildingManagemantHelperService
  ) {}

  convertToISOString(date: Date | string | null | undefined): string {
    if (!date) {
      return '';
    }
    if (typeof date === 'string') {
      return new Date(date).toISOString();
    }
    return date.toISOString();
  }
  addFloorKeyEvent($event: any) {
    if ($event.keyCode === 13) {
      this.addFloors();
    }
  }

  addFloors() {
    this.invalidFloorEntry = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    if (this.floorNumber.length === 0) {
      return;
    }

    if (this.invalidFloorDates()) {
      return;
    }

    const floors = this.buildingManagemantHelperService.getFloors(this.floorNumber);
    let currentFloorDetails: any;
    if (!this.buildingModel.selectedBuilding.buildingFloors) {
      this.buildingModel.selectedBuilding.buildingFloors = [];
    }
    currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;

    this.invalidFloorEntry = false;
    floors.forEach((floor: any) => {
      let floorDetail;
      if (floor.length > 4) {
        this.invalidFloorEntry = true;
        return;
      }
      if (!this.buildingManagemantHelperService.duplicateFloor(floor, currentFloorDetails)) {
        floorDetail = {
          floorNumber: floor.toUpperCase(),
          lifecycle: {
            beginDate: this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(this.floorStartDate || '')
            ),
            endDate: null,
          },
          active: true,
        };
        this.buildingModel.selectedBuilding.buildingFloors.push(floorDetail);
      }
    });
    this.floorNumber = '';
  }
  invalidFloorDates() {
    this.floorBeginDateErrorMessage = this.utilityService.validateBeginDate(
      this.convertToISOString(this.floorStartDate)
    );
    if (this.floorBeginDateErrorMessage) {
      this.invalidFloorStartDate = true;
    }

    this.floorEndDateErrorMessage = this.utilityService.validateEndDate(
      this.convertToISOString(this.floorStartDate) || '',
      this.convertToISOString(this.floorEndDate)
    );
    if (this.floorEndDateErrorMessage) {
      this.invalidFloorEndDate = true;
    }

    if (this.invalidFloorStartDate || this.invalidFloorEndDate) {
      return true;
    }
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    return false;
  }

  deleteFloors() {
    const newFloorList: any = [];
    const currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;
    currentFloorDetails.forEach((floor: any) => {
      if (!floor.floorChecked) {
        newFloorList.push(floor);
      }
    });
    this.buildingModel.selectedBuilding.buildingFloors = newFloorList;
  }
}
