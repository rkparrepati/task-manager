import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-inactivate-floor-confirm',
  templateUrl: './inactivate-floor-confirm.component.html',
  styleUrls: ['./inactivate-floor-confirm.component.scss'],
})
export class InactivateFloorConfirmComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<InactivateFloorConfirmComponent>) {}

  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
