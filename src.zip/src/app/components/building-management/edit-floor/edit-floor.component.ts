import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';
import { BuildingManagementService } from '../building-management.service';
import { BuildingManagemantHelperService } from '../building-managemant-helper.service';
import { InactivateFloorConfirmComponent } from '../inactivate-floor-confirm/inactivate-floor-confirm.component';
import { MatDialog } from '@angular/material/dialog';
import { AssoiatedObjectFloorComponent } from '../assoiated-object-floor/assoiated-object-floor.component';
import { ReactivateFloorConfirmComponent } from '../reactivate-floor-confirm/reactivate-floor-confirm.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-edit-floor',
  templateUrl: './edit-floor.component.html',
  styleUrls: ['./edit-floor.component.scss', './../new-floor/new-floor.component.scss'],
})
export class EditFloorComponent implements OnInit, OnDestroy {
  @Input() buildingModel: any = { buildings: [], selectedBuilding: {} };
  @Input() add: boolean = false;
  @Input() edit: boolean = false;
  
  // Subscription management
  private subscription: Subscription = new Subscription();
  invalidFloorEntry: boolean = false;
  invalidFloorEndDate: boolean = false;
  invalidFloorStartDate: boolean = false;
  invalidUpdateFloorBeginDate: boolean = false;
  invalidUpdateFloorEndDate: boolean = false;
  updateFloorBeginDateErrorMessage: string | null = '';
  updateFloorEndDateErrorMessage: string | null = '';

  floorNumber: string = '';
  floorStartDate: Date | null = new Date(); // Set to today's date by default
  floorEndDate: Date | null = null;
  floorEndDateErrorMessage: string | null = '';
  floorBeginDateErrorMessage: string | null = '';

  selectedFloor: any;
  editedFloor: any;
  returnCode: number = 0;
  returnMessage: string = '';
  hideMessage: boolean = false;
  accessDenied: any;
  floorErrorMessage: string = '';
  invalidBuildingCode: boolean = false;
  invalidBuildingDescription: boolean = false;
  invalidBuildingSiteCode: boolean = false;
  invalidBuildingStartDate: boolean = false;
  invalidBuildingAddress: boolean = false;
  invalidStartFloor: boolean = false;
  invalidBuildingAddressPostalCodeSuffix: boolean = false;
  buildingCodeHeader: string = '';
  updateFloorBeginDateErrorMessag: string | null = '';

  constructor(
    private dialog: MatDialog,
    public appService: AppService,
    private utilityService: UtilityService,
    private buildingManagementService: BuildingManagementService,
    private buildingManagemantHelperService: BuildingManagemantHelperService
  ) {}

  ngOnInit(): void {
    // Subscribe to message observables for ACME navbar component (following building-management component pattern)
    this.subscription.add(
      this.buildingManagementService.hideMessage$.subscribe((val) => {
        this.hideMessage = val;
      })
    );

    this.subscription.add(
      this.buildingManagementService.returnMessage$.subscribe((msg) => {
        this.returnMessage = msg;
      })
    );

    this.subscription.add(
      this.buildingManagementService.returnCode$.subscribe((code: any) => {
        this.returnCode = code;
      })
    );
  }

  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions to prevent memory leaks
    this.subscription.unsubscribe();
  }

  addFloors() {
    // Clear previous validation messages
    this.buildingManagementService.updateReturnMessageArray([]);
    this.buildingManagementService.updateHideMessage(true);
    
    this.invalidFloorEntry = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    
    let validationErrors: string[] = [];
    
    if (this.floorNumber.length === 0) {
      validationErrors.push('Floor number is required');
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
      return;
    }

    if (this.invalidFloorDates()) {
      // Collect date validation errors
      if (this.floorBeginDateErrorMessage) {
        validationErrors.push('Floor start date: ' + this.floorBeginDateErrorMessage);
      }
      if (this.floorEndDateErrorMessage) {
        validationErrors.push('Floor end date: ' + this.floorEndDateErrorMessage);
      }
      
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
      return;
    }

    const floors = this.buildingManagemantHelperService.getFloors(this.floorNumber);
    let currentFloorDetails: any;
    if (!this.buildingModel.selectedBuilding.buildingFloors) {
      this.buildingModel.selectedBuilding.buildingFloors = [];
    }
    currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;

    this.invalidFloorEntry = false;
    let hasInvalidFloor = false;
    
    floors.forEach((floor: any) => {
      let floorDetail;
      if (floor.length > 4) {
        this.invalidFloorEntry = true;
        hasInvalidFloor = true;
        validationErrors.push('Floor number "' + floor + '" exceeds maximum length of 4 characters');
        return;
      }
      if (!this.buildingManagemantHelperService.duplicateFloor(floor, currentFloorDetails)) {
        floorDetail = {
          floorNumber: floor.toUpperCase(),
          lifecycle: {
            beginDate: this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(this.floorStartDate || '')
            ),
            endDate: null,
          },
          active: true,
        };
        this.buildingModel.selectedBuilding.buildingFloors.push(floorDetail);
      }
    });
    
    // If there were validation errors, emit them
    if (hasInvalidFloor && validationErrors.length > 0) {
      this.buildingManagementService.updateReturnCode(700);
      this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.buildingManagementService.updateReturnMessageArray(validationErrors);
      this.buildingManagementService.updateHideMessage(false);
    }
    
    this.floorNumber = '';
  }
  invalidFloorDates() {
    // Convert to ISO string if it's a Date object, otherwise use the string value directly
    const startDateISO = this.floorStartDate instanceof Date
      ? this.floorStartDate.toISOString()
      : this.floorStartDate || undefined;
    
    this.floorBeginDateErrorMessage = this.utilityService.validateBeginDate(startDateISO);
    if (this.floorBeginDateErrorMessage) {
      this.invalidFloorStartDate = true;
    }

    const endDateISO = this.floorEndDate instanceof Date
      ? this.floorEndDate.toISOString()
      : this.floorEndDate || undefined;
    
    this.floorEndDateErrorMessage = this.utilityService.validateEndDate(
      startDateISO || '',
      endDateISO
    );
    if (this.floorEndDateErrorMessage) {
      this.invalidFloorEndDate = true;
    }

    if (this.invalidFloorStartDate || this.invalidFloorEndDate) {
      return true;
    }
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    return false;
  }
  showUpdateFloor(editFloor: any) {
    this.selectedFloor = editFloor;
    if (!this.editedFloor) {
      this.editedFloor = JSON.parse(JSON.stringify(editFloor));
      if (!this.editedFloor.endDate) {
        this.editedFloor.endDate = null;
      }
    }
  }
  confirmInactivateFloor(floorEdited: any) {
    if (!floorEdited.buildingFloorId) {
      this.buildingManagemantHelperService.removeFloorFromList(
        this.buildingModel.selectedBuilding.buildingFloors,
        floorEdited
      );
      return;
    }

    const dialogRef = this.dialog.open(InactivateFloorConfirmComponent, {
      width: '25vw',
      height: '100',
      data: { floor: floorEdited },
      disableClose: true, // Prevent closing by clicking outside or pressing Escape to ensure explicit user action
    });
    dialogRef.afterClosed().subscribe((inactivate: any) => {
      // Only proceed if user confirmed (clicked Confirm button, returns true)
      // If user clicked Cancel or X, inactivate will be a string or falsy, so don't proceed
      if (inactivate === true) {
        let floorLifecycleValid: string | null = null;
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          if (floorEdited.floorNumber === floor.floorNumber) {
            floor.lifecycle.endDate = this.utilityService.adjustEndDateFormatter(
              this.utilityService.dateFormatterEndDate(
                new Date(new Date().getTime() - 24 * 60 * 60 * 1000)
              )
            );
            floorLifecycleValid = this.utilityService.validateInactivateEndDate(floor.lifecycle);
            floor.lifecycle.cascade = true;
          }
        });
        if (floorLifecycleValid) {
          // Use direct service methods for error message
          const errorMessages: string[] = [floorLifecycleValid];
          this.buildingManagementService.updateReturnCode(400);
          this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
          this.buildingManagementService.updateReturnMessageArray(errorMessages);
          this.buildingManagementService.updateHideMessage(false);
          
          this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
            floor.lifecycle.endDate = '';
            floor.lifecycle.cascade = false;
          });
        } else {
          this.updateBuildingObject(floorEdited);
        }
      }
    });
  }

  updateBuildingObject(floorEdited: any) {
    const updateBuildingObject = {
      buildingCode: this.buildingModel.selectedBuilding.buildingCode,
      buildingDescription: this.buildingModel.selectedBuilding.buildingDescription,
      lifecycle: this.buildingModel.selectedBuilding.lifecycle,
      buildingFloors: this.buildingModel.selectedBuilding.buildingFloors,
      site: this.buildingModel.selectedBuilding.site,
      address: this.buildingModel.selectedBuilding.address,
      audit: {
        lockControlNumber: this.buildingModel.selectedBuilding.audit.lockControlNumber,
      },
    };

    const url = '/buildings/' + this.buildingModel.selectedBuilding.buildingId;
    this.buildingManagementService.inactivateBuildingFloor(updateBuildingObject, url).subscribe({
      next: () => {
        const successMessage = 'Successfully inactivated building floor';
        
        // Use direct service methods for consistent message handling
        this.buildingManagementService.scrolltoTop();
        this.buildingManagementService.updateReturnCode(200);
        this.buildingManagementService.updateReturnMessage(successMessage);
        this.buildingManagementService.updateReturnMessageArray([]);
        this.buildingManagementService.updateHideMessage(false);
        
        // Clear cascade flags
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          floor.lifecycle.cascade = false;
        });
        
        // Reset edit/add flags (matching reactivate pattern)
        this.edit = false;
        this.add = false;
        
        // Trigger search refresh to update the grid and collapse the view
        this.buildingManagementService.triggerRefreshSearch('Floor inactivated successfully');
      },
      error: (error: any) => {
        this.handleInactivateResponse(error, floorEdited);
      }
    });
  }
  handleInactivateResponse(responseInactivate: any, floorEdited: any) {
    if (
      responseInactivate.statusCode === 400 &&
      responseInactivate.statusMessage.indexOf('workers associated to the location') > -1
    ) {
      const dialogRef = this.dialog.open(AssoiatedObjectFloorComponent, {
        width: '25vw',
        height: '100',
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe((result: any) => {
        this.setShowMode(this.updateBuildingObject);
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          floor.lifecycle.endDate = '';
          floor.lifecycle.cascade = false;
        });
      });
    } else {
      // Use direct service methods for error message
      const errorMessages: string[] = [responseInactivate.statusMessage || 'Building floor inactivation failed'];
      this.buildingManagementService.updateReturnCode(400);
      this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
      this.buildingManagementService.updateReturnMessageArray(errorMessages);
      this.buildingManagementService.updateHideMessage(false);
      
      this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
        floor.lifecycle.endDate = '';
        floor.lifecycle.cascade = false;
      });
    }
  }

  setShowMode(building: any) {
    this.setRequiredFields('');
    this.cancelAllInvalidates();
    building.viewMode = 1;
  }
  cancelAllInvalidates() {
    this.floorErrorMessage = '';
    this.invalidBuildingCode = false;
    this.invalidBuildingDescription = false;
    this.invalidBuildingSiteCode = false;
    this.invalidBuildingStartDate = false;
    this.invalidBuildingAddress = false;
    this.invalidBuildingAddress = false;
    this.invalidBuildingAddress = false;
    this.invalidBuildingAddress = false;
    this.invalidStartFloor = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    this.invalidFloorEntry = false;
    this.invalidBuildingAddressPostalCodeSuffix = false;
  }
  setRequiredFields(requiredCharacter: any) {
    this.buildingCodeHeader = 'Building code ' + requiredCharacter;
    this.buildingCodeHeader = 'Building name ' + requiredCharacter;
    this.buildingCodeHeader = 'Site code/name ' + requiredCharacter;
  }

  confirmReactivateFloor(floorEdited: any) {
    const dialogRef = this.dialog.open(ReactivateFloorConfirmComponent, {
      width: '25vw',
      height: '100',
      data: { floor: floorEdited },
      disableClose: true, // Prevent closing by clicking outside or pressing Escape to ensure explicit user action
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      // Only proceed if user confirmed (clicked Confirm button, returns true)
      // If user clicked Cancel or X, result will be a string or falsy, so don't proceed
      if (result !== true) {
        return;
      }
      
      if (this.buildingModel.selectedBuilding.lifecycle.endDate) {
        // Use direct service methods for error message
        const errorMessages: string[] = ['Floor cannot be reactivated. Associated building is not active.'];
        this.buildingManagementService.updateReturnCode(400);
        this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.buildingManagementService.updateReturnMessageArray(errorMessages);
        this.buildingManagementService.updateHideMessage(false);
      } else {
        this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
          if (floorEdited.floorNumber === floor.floorNumber) {
            floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(new Date(floor.lifecycle.beginDate))
            );
            floor.lifecycle.endDate = '';
            floor.cascade = false;
          }
        });
        const updateBuildingObject = {
          buildingCode: this.buildingModel.selectedBuilding.buildingCode,
          buildingDescription: this.buildingModel.selectedBuilding.buildingDescription,
          lifecycle: this.buildingModel.selectedBuilding.lifecycle,
          buildingFloors: this.buildingModel.selectedBuilding.buildingFloors,
          site: this.buildingModel.selectedBuilding.site,
          address: this.buildingModel.selectedBuilding.address,
          audit: {
            lockControlNumber: this.buildingModel.selectedBuilding.audit.lockControlNumber,
          },
        };
        this.buildingManagementService
          .reactivateBuildingFloor(
            updateBuildingObject,
            `/buildings/${this.buildingModel.selectedBuilding.buildingId}`
          )
          .subscribe({
            next: (response: any) => {
              const successMessage = 'Successfully reactivated building floor';
              
              // Use direct service methods for consistent message handling
              this.buildingManagementService.scrolltoTop();
              this.buildingManagementService.updateReturnCode(200);
              this.buildingManagementService.updateReturnMessage(successMessage);
              this.buildingManagementService.updateReturnMessageArray([]);
              this.buildingManagementService.updateHideMessage(false);
              
              this.edit = false;
              this.add = false;
              
              // Trigger search refresh to update the grid
              this.buildingManagementService.triggerRefreshSearch('Floor reactivated successfully');
            },
            error: (error: any) => {
              // Handle error using direct pattern
              const errorMessages: string[] = [];
              let errorMessage = 'Building floor could not be reactivated';
              
              if (error?.error?.message) {
                errorMessage = error.error.message;
              } else if (error?.data?.message) {
                errorMessage = error.data.message;
              } else if (error?.message) {
                errorMessage = error.message;
              }
              
              errorMessages.push(errorMessage);
              
              this.buildingManagementService.updateReturnCode(error?.status || 500);
              this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
              this.buildingManagementService.updateReturnMessageArray(errorMessages);
              this.buildingManagementService.updateHideMessage(false);
            }
          });
      }
    });
  }
  updateFloor() {
    this.invalidUpdateFloorBeginDate = false;
    this.invalidUpdateFloorEndDate = false;
    this.updateFloorBeginDateErrorMessage = this.utilityService.validateBeginDate(
      this.editedFloor.lifecycle.beginDate
    );
    if (this.updateFloorBeginDateErrorMessage) {
      this.invalidUpdateFloorBeginDate = true;
    }
    if (this.updateFloorEndDateErrorMessage) {
      this.invalidUpdateFloorEndDate = true;
    }
    if (this.updateFloorBeginDateErrorMessag || this.updateFloorEndDateErrorMessage) {
      return;
    }
    this.buildingModel.selectedBuilding.buildingFloors.forEach((floor: any) => {
      if (this.editedFloor.floorNumber === floor.floorNumber) {
        floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
          this.utilityService.dateFormatter(new Date(this.editedFloor.lifecycle.beginDate))
        );
        floor.lifecycle.endDate = !!this.editedFloor.lifecycle.endDate
          ? this.utilityService.adjustEndDateFormatter(
              this.utilityService.dateFormatter(new Date(this.editedFloor.lifecycle.endDate))
            )
          : '';
      }
    });
    this.editedFloor = null;
  }

  cancelUpdateFloor() {
    this.invalidUpdateFloorBeginDate = false;
    this.invalidUpdateFloorEndDate = false;
    this.updateFloorBeginDateErrorMessage = null;
    this.updateFloorBeginDateErrorMessage = null;
    this.editedFloor = null;
    this.floorNumber = ''; // Reset floor number input field
  }
  addFloorKeyEvent($event: any) {
    if ($event.keyCode === 13) {
      this.addFloors();
    }
  }
  getFloorTemplateEdMode(floor: any) {
    if (this.editedFloor && floor.floorNumber === this.editedFloor.floorNumber) {
      return 'floorEditAddMode';
    }
    return 'floorDisplayAddMode';
  }
  
  deleteFloors() {
    const newFloorList: any = [];
    const currentFloorDetails = this.buildingModel.selectedBuilding.buildingFloors;
    currentFloorDetails.forEach((floor: any) => {
      if (!floor.floorChecked) {
        newFloorList.push(floor);
      }
    });
    this.buildingModel.selectedBuilding.buildingFloors = newFloorList;
  }

  // Public method to reset floor number input - called from parent component
  resetFloorNumber() {
    this.floorNumber = '';
  }
}
