import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BuildingManagementService {
  // Toast message management (following location component pattern)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();

  // Subject to trigger search refresh after save
  private refreshSearchSource = new Subject<string>();
  refreshSearch$ = this.refreshSearchSource.asObservable();

  // Expand/collapse functionality
  private expandCollapseSubject = new Subject<'expand' | 'collapse'>();
  get command$(): Observable<'expand' | 'collapse'> {
    return this.expandCollapseSubject.asObservable();
  }

  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  // Methods to update toast messages (following location component pattern)
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.scrolltoTop();
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  triggerRefreshSearch(message: string): void {
    this.refreshSearchSource.next(message);
  }

  // Methods the button component calls
  expandAllRows(): void {
    this.expandCollapseSubject.next('expand');
  }

  collapseAllRows(): void {
    this.expandCollapseSubject.next('collapse');
  }

  sendMessage(message: string, messageType: 'success' | 'danger' = 'success') {    // Scroll to top whenever a message is sent
    window.scrollTo(0, 0);
    
    // Update message observables for ACME navbar component
    this.updateReturnMessage(message);
    
    // Set return code based on message type
    // 200 for success (shows green/success toast)
    // 400+ for danger (shows red/danger toast)
    const returnCode = messageType === 'success' ? 200 : 400;    this.updateReturnCode(returnCode);
    
    // Clear any previous message arrays for simple messages
    this.updateReturnMessageArray([]);
    
    // Show the message (stays visible until user manually closes it)
    this.updateHideMessage(false);
  }
  
  sendSuccessMessage(message: string) {
    this.sendMessage(message, 'success');
  }
  
  sendErrorMessage(message: string) {
    this.sendMessage(message, 'danger');
  }

  /**
   * Get standardized message based on operation type and status
   * Matches the location component pattern
   *
   * @param operation - Operation type: 'AddBuilding', 'UpdateBuilding', 'AddFloor', 'UpdateFloor', etc.
   * @param statusText - HTTP status text
   * @param status - HTTP status code
   * @returns Observable<string> - Formatted message
   */
  getMessage(operation: string, statusText: string, status: number): Observable<string> {
    let message = '';
    
    // Success messages (status 200-299)
    if (status >= 200 && status < 300) {
      switch (operation) {
        case 'AddBuilding':
          message = 'Add building successful';
          break;
        case 'UpdateBuilding':
          message = 'Update building successful';
          break;
        case 'AddFloor':
          message = 'Add floor successful';
          break;
        case 'UpdateFloor':
          message = 'Update floor successful';
          break;
        case 'InactivateBuilding':
          message = 'Inactivate building successful';
          break;
        case 'ReactivateBuilding':
          message = 'Reactivate building successful';
          break;
        case 'InactivateFloor':
          message = 'Inactivate floor successful';
          break;
        case 'ReactivateFloor':
          message = 'Reactivate floor successful';
          break;
        default:
          message = statusText || 'Operation successful';
      }
    } else {
      // Error messages
      switch (operation) {
        case 'AddBuilding':
          message = 'Add building failed';
          break;
        case 'UpdateBuilding':
          message = 'Update building failed';
          break;
        case 'AddFloor':
          message = 'Add floor failed';
          break;
        case 'UpdateFloor':
          message = 'Update floor failed';
          break;
        case 'InactivateBuilding':
          message = 'Inactivate building failed';
          break;
        case 'ReactivateBuilding':
          message = 'Reactivate building failed';
          break;
        case 'InactivateFloor':
          message = 'Inactivate floor failed';
          break;
        case 'ReactivateFloor':
          message = 'Reactivate floor failed';
          break;
        default:
          message = statusText || 'Operation failed';
      }
    }
    
    return new Observable(observer => {
      observer.next(message);
      observer.complete();
    });
  }

  private getTableParams(
    findText: string | null = '',
    includeInactive: boolean = false,
    tableParams: any = {},
    siteCode: string = '',
    floorNumber: number | null = null,
    code: string = ''
  ): any {
    return {
      includeInactive,
      codePrefix: findText || null,
      floorNumber: floorNumber || null,
      code: code || null,
      siteCode: siteCode || null,
      skip: tableParams?.skip || null,
      limit: tableParams?.limit || null,
      sortColumn: tableParams?.sortColumn || null,
      sortOrder: tableParams?.sortOrder || null,
    };
  }

  private convertParamsToQueryParams(params: any): string {
    let queryParamas = new HttpParams();
    Object.keys(params).forEach((key) => {
      const value = params[key];
      if (value !== null && value !== undefined) {
        queryParamas = queryParamas.set(key, value.toString());
      }
    });
    return queryParamas.toString();
  }

  getBuildings(
    findText: string | null,
    includeInactive: boolean,
    tableParams: any,
    siteCode?: string,
    floorNumber?: number,
    code?: string
  ) {
    const params = this.getTableParams(
      findText,
      includeInactive,
      tableParams,
      siteCode,
      floorNumber,
      code
    );
    return this.httpService.get(`/buildings?${this.convertParamsToQueryParams(params)}`);
  }
  getSites(
    includeInactive: boolean,
    limit?: number,
    skip?: number,
    sortColumn?: string,
    sortOrder?: string,
    codePrefix?: string
  ) {
    const params = {
      includeInactive: !!includeInactive,
      sortColumn: sortColumn || null,
      sortOrder: sortOrder || 'asc',
      limit: limit || null,
      skip: skip || null,
      codePrefix: codePrefix || null,
    };

    return this.httpService.get(`/sites?${this.convertParamsToQueryParams(params)}`);
  }

  getStates() {
    return this.httpService.get('/geoRegions');
  }

  /**
   * This method makes restful service call and updates a
   * building. This method returns response promise from http
   * put.
   *
   * @param building
   *            Object
   */
  saveBuilding(building: any) {
    if (building.buildingId) {
      return this.updateBuilding(building);
    } else {
      return this.createBuilding(building);
    }
  }

  /**
   * Method to do a POST for a building
   */
  createBuilding(building: any) {
    building.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
      building.lifecycle.beginDate
    );
    building.lifecycle.endDate = null;

    building.buildingFloors.forEach((floor: any) => {
      floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
        floor.lifecycle.beginDate
      );
      floor.lifecycle.endDate = floor.lifecycle.endDate
        ? this.utilityService.adjustDateFormatter(floor.lifecycle.endDate)
        : null;
    });

    return this.httpService.post('/buildings', building);
  }

  /**
   * Calls service to update a building
   */
  updateBuilding(building: any) {
    building.buildingFloors.forEach((floor: any) => {
      if (!floor.buildingFloorId) {
        floor.lifecycle.beginDate = this.utilityService.adjustDateFormatter(
          floor.lifecycle.beginDate
        );
        floor.lifecycle.endDate = floor.lifecycle.endDate
          ? this.utilityService.adjustDateFormatter(floor.lifecycle.endDate)
          : null;
      }
    });

    return this.httpService.put(
      `/buildings/${building.buildingId}?lockControlNumber=${this.utilityService.getLockControlNumber(building)}`,
      building
    );
  }

  inactivateBuildingFloor(buildingObject: any, url: string) {
    buildingObject.lifecycle.endDate = null;
    buildingObject.lifecycle.cascade = false;

    return this.httpService.put(
      `${url}?lockControlNumber=${this.utilityService.getLockControlNumber(buildingObject)}`,
      buildingObject
    );
  }
  inactivateBuilding(building: any) {
    const updateBuildingObject = {
      buildingCode: building.buildingCode,
      buildingDescription: building.buildingDescription,
      lifecycle: building.lifecycle,
      buildingFloors: building.buildingFloors,
      site: building.site,
      address: building.address,
      audit: {
        lockControlNumber: building.audit.lockControlNumber,
      },
    };
    return this.httpService.put(
      `/buildings/${building.buildingId}?lockControlNumber=${this.utilityService.getLockControlNumber(building)}`,
      updateBuildingObject
    );
  }
  getAssociatedSite(siteId: number) {
    return this.httpService.get('/sites/' + siteId);
  }

  reactivateBuilding(building: any) {
    const updateBuildingObject = {
      buildingCode: building.buildingCode,
      buildingDescription: building.buildingDescription,
      lifecycle: building.lifecycle,
      buildingFloors: building.buildingFloors,
      site: building.site,
      address: building.address,
      audit: {
        lockControlNumber: building.audit.lockControlNumber,
      },
    };
    return this.httpService.put(
      `/buildings/${building.buildingId}?lockControlNumber=${this.utilityService.getLockControlNumber(building)}`,
      updateBuildingObject
    );
  }
  reactivateBuildingFloor(buildingObject: any, url: string) {
    buildingObject.lifecycle.endDate = null;
    buildingObject.lifecycle.cascade = false;
    return this.httpService.put(
      `${url}?lockControlNumber=${this.utilityService.getLockControlNumber(buildingObject)}`,
      buildingObject
    );
  }

  getAssociatedLocations(buildingCode: string) {
    const url = '/locations?buildingCode=' + buildingCode;
    return this.httpService.get(url);
  }
}
