import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-reactivate-building-confirm',
  templateUrl: './reactivate-building-confirm.component.html',
  styleUrls: ['./reactivate-building-confirm.component.scss'],
})
export class ReactivateBuildingConfirmComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<ReactivateBuildingConfirmComponent>) {}

  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
