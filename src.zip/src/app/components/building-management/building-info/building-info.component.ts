import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-building-info',
  templateUrl: './building-info.component.html',
  styleUrls: ['./building-info.component.scss'],
})
export class BuildingInfoComponent {
  @Output() setViewModeEvent = new EventEmitter();
  @Output() editBuildingEvent = new EventEmitter();
  @Output() confirmInactivateBuildingEvent = new EventEmitter();
  @Output() confirmReactivateBuildingEvent = new EventEmitter();
  @Input() building: any;
  public rolesEnum = ROLES_ENUM;

  constructor(public appService: AppService) {}

  setViewMode(building: any) {
    this.setViewModeEvent.emit(building);
  }
  editBuilding(building: any) {
    this.editBuildingEvent.emit(building);
  }
  confirmInactivateBuilding(building: any) {
    this.confirmInactivateBuildingEvent.emit(building);
  }
  confirmReactivateBuilding(building: any) {
    this.confirmReactivateBuildingEvent.emit(building);
  }
}
