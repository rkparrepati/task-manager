import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { BuildingManagementService } from '../building-management.service';

@Component({
  selector: 'app-assoiated-object-building',
  templateUrl: './assoiated-object-building.component.html',
  styleUrls: ['./assoiated-object-building.component.scss'],
})
export class AssoiatedObjectBuildingComponent implements OnInit {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  locations: any;
  constructor(
    private dialogRef: MatDialogRef<AssoiatedObjectBuildingComponent>,
    private buildingManagementService: BuildingManagementService
  ) {}

  ngOnInit(): void {
    this.getLocations();
  }

  getLocations() {
    this.buildingManagementService
      .getAssociatedLocations(this.data.building.buildingCode)
      .subscribe((response: any) => {
        this.locations = response.results;      });
  }
  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
