import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-reactivate-floor-confirm',
  templateUrl: './reactivate-floor-confirm.component.html',
  styleUrls: ['./reactivate-floor-confirm.component.scss'],
})
export class ReactivateFloorConfirmComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(private dialogRef: MatDialogRef<ReactivateFloorConfirmComponent>) {}

  confirm() {
    this.dialogRef.close(true);
  }
  
  closeThisDialog() {
    this.dialogRef.close(false);
  }
}
