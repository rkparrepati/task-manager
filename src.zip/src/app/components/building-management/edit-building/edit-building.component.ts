import { Component, Input, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { UtilityService } from 'src/app/services/utility.service';
import { BuildingManagemantHelperService } from '../building-managemant-helper.service';
import { BuildingManagementService } from '../building-management.service';
import { EditFloorComponent } from '../edit-floor/edit-floor.component';

@Component({
  selector: 'app-edit-building',
  templateUrl: './edit-building.component.html',
  styleUrls: ['./edit-building.component.scss'],
})
export class EditBuildingComponent implements OnInit {
  @Input() building: any;
  @Input() buildingModel: any;
  @Input() add: boolean = false;
  @Input() edit: boolean = false;
  @Output() cancelBuildingEvent = new EventEmitter<any>();
  @ViewChild(EditFloorComponent) editFloorComponent!: EditFloorComponent;
  
  invalidBuildingCode: boolean = false;
  invalidBuildingDescription: boolean = false;
  invalidBuildingSiteCode: boolean = false;
  invalidBuildingAddressPostalCodeSuffix: boolean = false;
  invalidBuildingStartDate: boolean = false;
  invalidBuildingAddressPostalCode: boolean = false;
  invalidBuildingAddress: boolean = false;
  invalidBuildingAddressCity: boolean = false;
  invalidBuildingAddressState: boolean = false;

  beginDateErrorMessage: string | null = '';

  siteModel: { sites: any } = { sites: [] };
  states: any = [];
  hideMessage: boolean = false;
  returnMessage: string = '';
  floorErrorMessage: string = '';
  invalidStartFloor: boolean = false;
  invalidFloorStartDate: boolean = false;
  invalidFloorEndDate: boolean = false;
  invalidFloorEntry: boolean = false;
  buildingSiteCodeInvalid: boolean = false;
  floorNumber: string = '';
  floorStartDate: Date | null = null;
  floorEndDate: Date | null = null;
  buildingCodeHeader: string = '';
  buildingNameHeader: string = '';
  buildingCodeName: string = '';
  disableShowRadioButton: boolean = false;
  returnCode: number = 200;
  accessDenied: string = '';
  invalidUpdateFloorBeginDate: boolean = false;
  invalidUpdateFloorEndDate: boolean = false;
  updateFloorBeginDateErrorMessage: string | null = null;
  editedFloor: any;
  sites: any = [];

  constructor(
    private utilityService: UtilityService,
    private buildingManagemantHelperService: BuildingManagemantHelperService,
    private buildingManagementService: BuildingManagementService
  ) {}

  ngOnInit(): void {
    // Child component only emits messages via service methods
    // Parent component (building-management) handles message subscriptions and display via ACME navbar
    this.getSitesList();
    this.getStates();
    
    // Ensure selectedBuilding is initialized
    if (!this.buildingModel.selectedBuilding) {
      this.buildingModel.selectedBuilding = {};
    }
  }

  hideMessageDiv() {
    this.hideMessage = true;
    this.returnMessage = '';
  }
  cancelAllInvalidates() {
    this.floorErrorMessage = '';
    this.invalidBuildingCode = false;
    this.invalidBuildingDescription = false;
    this.invalidBuildingSiteCode = false;
    this.invalidBuildingStartDate = false;
    this.invalidBuildingAddress = false;
    this.invalidBuildingAddressCity = false;
    this.invalidBuildingAddressState = false;
    this.invalidBuildingAddressPostalCode = false;
    this.invalidStartFloor = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    this.invalidFloorEntry = false;
    this.invalidBuildingAddressPostalCodeSuffix = false;
  }
  invalidateAddress(theBuilding: any) {
    let theBuildingInvalid: boolean = false;
    if (!theBuilding.address.addressLineOne) {
      this.invalidBuildingAddress = true;
      theBuildingInvalid = true;
    } else {
      this.invalidBuildingAddress = false;
    }

    if (!theBuilding.address.city) {
      this.invalidBuildingAddressCity = true;
      theBuildingInvalid = true;
    } else {
      this.invalidBuildingAddressCity = false;
    }

    if (!theBuilding.address.stateCode) {
      this.invalidBuildingAddressState = true;
      theBuildingInvalid = true;
    } else {
      this.invalidBuildingAddressState = false;
    }

    if (!theBuilding.address.postalCode || theBuilding.address.postalCode.length !== 5) {
      this.invalidBuildingAddressPostalCode = true;
      theBuildingInvalid = true;
    }

    if (theBuilding.address.postalCodeSuffix && theBuilding.address.postalCodeSuffix.length !== 4) {
      this.invalidBuildingAddressPostalCodeSuffix = true;
      theBuildingInvalid = true;
    } else if (!theBuilding.address.postalCodeSuffix) {
      theBuilding.address.postalCodeSuffix = null;
      this.invalidBuildingAddressPostalCodeSuffix = false;
    } else {
      this.invalidBuildingAddressPostalCodeSuffix = false;
    }

    return theBuildingInvalid;
  }

  validateBuildingParameters() {
    this.hideMessageDiv();
    this.cancelAllInvalidates();
    
    // Clear previous validation messages
    this.buildingManagementService.updateReturnMessageArray([]);
    this.buildingManagementService.updateHideMessage(true);
    
    let theBuilding: any = {};
    let theBuildingInvalid: boolean = false;
    let validationErrors: string[] = [];
    
    theBuilding = this.buildingModel.selectedBuilding;
    if (theBuilding) {
      if (!theBuilding.buildingCode) {
        this.invalidBuildingCode = true;
        theBuildingInvalid = true;
        validationErrors.push('Building code is required');
      } else {
        this.buildingModel.selectedBuilding.buildingCode = theBuilding.buildingCode.toUpperCase();
        this.invalidBuildingCode = false;
      }
      if (!theBuilding.buildingDescription) {
        this.invalidBuildingDescription = true;
        theBuildingInvalid = true;
        validationErrors.push('Building name is required');
      } else {
        this.buildingModel.selectedBuilding.buildingDescription =
          theBuilding.buildingDescription.toUpperCase();
        this.invalidBuildingDescription = false;
      }

      if (!theBuilding.site || !theBuilding.site.siteId) {
        this.invalidBuildingSiteCode = true;
        theBuildingInvalid = true;
        validationErrors.push('Site code/name is required');
      } else {
        this.buildingSiteCodeInvalid = false;
      }

      this.beginDateErrorMessage = this.utilityService.validateBeginDate(
        theBuilding.lifecycle.beginDate,
        true
      );

      if (this.beginDateErrorMessage) {
        this.invalidBuildingStartDate = true;
        theBuildingInvalid = true;
        validationErrors.push('Building start date: ' + this.beginDateErrorMessage);
      }
      if (this.invalidateAddress(theBuilding)) {
        theBuildingInvalid = true;
        if (this.invalidBuildingAddress) {
          validationErrors.push('Address line one is required');
        }
        if (this.invalidBuildingAddressCity) {
          validationErrors.push('City is required');
        }
        if (this.invalidBuildingAddressState) {
          validationErrors.push('State is required');
        }
        if (this.invalidBuildingAddressPostalCode) {
          validationErrors.push('Postal code must be 5 digits');
        }
        if (this.invalidBuildingAddressPostalCodeSuffix) {
          validationErrors.push('Postal code suffix must be 4 digits');
        }
      }
      if (!theBuildingInvalid) {
        this.floorErrorMessage = this.buildingManagemantHelperService.invalidateFloors(theBuilding);
        if (this.floorErrorMessage) {
          theBuildingInvalid = true;
          validationErrors.push('Floor validation: ' + this.floorErrorMessage);
        }
      }
      
      // If there are validation errors, emit them as array with returnCode 700
      if (theBuildingInvalid && validationErrors.length > 0) {
        this.buildingManagementService.updateReturnCode(700);
        this.buildingManagementService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
        this.buildingManagementService.updateReturnMessageArray(validationErrors);
        this.buildingManagementService.updateHideMessage(false);
      }
    }
    return theBuildingInvalid;
  }

  enableDisableShowActiveAll() {
    this.disableShowRadioButton = this.edit || this.add;
  }
  setRequiredFields(requiredCharacter: any) {
    this.buildingCodeHeader = 'Building code ' + requiredCharacter;
    this.buildingNameHeader = 'Building name ' + requiredCharacter;
    this.buildingCodeName = 'Site code/name ' + requiredCharacter;
  }
  cancelBuilding(building: any) {
    this.buildingModel.selectedBuilding = null;
    this.setRequiredFields('');
    this.cancelAllInvalidates();
    this.floorNumber = '';
    this.floorStartDate = new Date();
    this.floorEndDate = null;
    this.edit = false;
    this.add = false;
    this.enableDisableShowActiveAll();
    this.hideMessageDiv();
    this.buildingModel.buildings.forEach((aBuilding: any) => {
      aBuilding.viewMode = 0;
    });
    this.cancelUpdateFloor();
    // Emit event to parent component
    this.cancelBuildingEvent.emit(building);
  }

  resetBuilding(building: any) {
    if (building) {
      // It is in edit mode. Reset the selected building for this row
      this.buildingModel.selectedBuilding = JSON.parse(JSON.stringify(building));
      if (!this.buildingModel.selectedBuilding.lifecycle.endDate) {
        this.buildingModel.selectedBuilding.lifecycle.endDate = null;
      }
      this.floorStartDate = new Date();
      this.floorEndDate = null;
      this.floorNumber = '';
      
    } else {
      this.resetAddBuilding();
    }
    this.hideMessage = true;
    this.cancelAllInvalidates();
    
    // Reset floor number in the child edit-floor component
    if (this.editFloorComponent) {
      this.editFloorComponent.resetFloorNumber();
    }
  }

  saveBuilding(building: any) {
    // Clear all previous messages at the start (following addFloor pattern)
    this.buildingManagementService.updateReturnMessageArray([]);
    this.buildingManagementService.updateHideMessage(true);
    
    if (!this.validateBuildingParameters()) {
      this.buildingManagementService.saveBuilding(this.buildingModel.selectedBuilding).subscribe({
        next: () => {
          let typeMessage = ' created ';
          if (this.edit) {
            typeMessage = ' updated ';
          }
          
          // Success message - emit through service using single message pattern (following addFloor pattern)
          const successMessage = 'Successfully' +
            typeMessage +
            ' Building: ' +
            this.buildingModel.selectedBuilding.buildingCode;
          
          // Use direct service methods for consistent message handling (following addFloor pattern)
          this.buildingManagementService.scrolltoTop();
          this.buildingManagementService.updateReturnCode(200);
          this.buildingManagementService.updateReturnMessage(successMessage);
          this.buildingManagementService.updateReturnMessageArray([]);
          this.buildingManagementService.updateHideMessage(false);
          
          this.edit = false;
          this.add = false;
          this.enableDisableShowActiveAll();
          this.setRequiredFields('');
          
          // Trigger search refresh to update the grid
          this.buildingManagementService.triggerRefreshSearch('Building saved successfully');
          
          // Close the edit row by emitting cancel event
          this.cancelBuildingEvent.emit(building);
        },
        error: (error: any) => {
          // Handle error using array pattern (following addFloor pattern)
          const errorMessages: string[] = [];
          let errorMessage = 'Failed to save building';
          let statusCode = error?.status || 500;
          
          if (error?.error?.message) {
            errorMessage = error.error.message;
          } else if (error?.data?.message) {
            errorMessage = error.data.message;
          } else if (error?.message) {
            errorMessage = error.message;
          } else if (typeof error === 'string') {
            errorMessage = error;
          }
          
          errorMessages.push(errorMessage);
          
          // Emit error with array pattern (following addFloor pattern)
          this.buildingManagementService.scrolltoTop();
          this.buildingManagementService.updateReturnCode(statusCode);
          this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
          this.buildingManagementService.updateReturnMessageArray(errorMessages);
          this.buildingManagementService.updateHideMessage(false);
        }
      });
    } else {
      // Validation errors are already emitted by validateBuildingParameters() method with array pattern
      // Scroll to top to ensure user sees the validation messages
      this.buildingManagementService.scrolltoTop();
    }
  }
  cancelUpdateFloor() {
    this.invalidUpdateFloorBeginDate = false;
    this.invalidUpdateFloorEndDate = false;
    this.updateFloorBeginDateErrorMessage = null;
    this.updateFloorBeginDateErrorMessage = null;
    this.editedFloor = null;
  }
  resetAddBuilding() {
    this.buildingModel.selectedBuilding = {
      lifecycle: {
        beginDate: new Date().toISOString(),
        endDate: null,
      },
      address: {
        addressLine2: '',
        postalCode: '',
        addressLineTwo: '',
        stateCode: this.states[0]?.value || '',
      },
      site: {
        siteId: null,
      },
      buildingFloors: [],
    };
    this.floorStartDate = new Date();
    this.floorEndDate = null;
    this.floorNumber = '';
  }

  getSitesList() {
    this.buildingManagementService.getSites(false).subscribe(
      (response: any) => {
        this.sites = response.results;
        const selectBoxSites: any = [];
        this.sites.forEach((site: any) => {
          const aSite = {
            siteId: site.siteId,
            code: site.code,
            siteNameText: site.code + '/' + site.description,
          };
          selectBoxSites.push(aSite);
        });
        this.siteModel = {
          sites: selectBoxSites,
        };
      },
      (error: any) => {
        // Use direct service methods for error message (following addFloor pattern)
        const errorMessages: string[] = ['No sites found'];
        this.buildingManagementService.scrolltoTop();
        this.buildingManagementService.updateReturnCode(error?.status || 500);
        this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.buildingManagementService.updateReturnMessageArray(errorMessages);
        this.buildingManagementService.updateHideMessage(false);
      }
    );
  }
  getStates() {
    this.buildingManagementService.getStates().subscribe(
      (response: any) => {
        const emptyStateObject = {
          id: '',
          description: '',
          inValidDate: '',
          longDescription: '',
          propsList: [],
          validDate: '',
          value: '',
        };
        this.states = response;
        this.states.splice(0, 0, emptyStateObject);
      },
      (error: any) => {
        let errorMessage;
        if (error.data && error.data.message) {
          errorMessage = error.data.message;
        } else {
          errorMessage = 'Not able to retrieve State List.';
        }
        // Use direct service methods for error message (following addFloor pattern)
        const errorMessages: string[] = [errorMessage];
        this.buildingManagementService.scrolltoTop();
        this.buildingManagementService.updateReturnCode(error?.status || 500);
        this.buildingManagementService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.buildingManagementService.updateReturnMessageArray(errorMessages);
        this.buildingManagementService.updateHideMessage(false);
      }
    );
  }
  convertToDate(date?: string | null | undefined): Date {
    if (!date || date === '') {      return new Date();
    }
    return new Date(date);
  }
}
