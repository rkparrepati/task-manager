import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'src/app/services/app.service';
import { AccessionSelectDialogComponent } from '../worker-management/accession-select-dialog/accession-select-dialog.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-human-resoures-tools',
  templateUrl: './human-resoures-tools.component.html',
  styleUrls: ['./human-resoures-tools.component.scss'],
})
export class HumanResouresToolsComponent {
  accessInfo: any = this.appService.getNavData();

  constructor(
    public appService: AppService,
    private dialog: MatDialog,
    private router: Router
  ) {}

  opeWorkerReportModal(): void {
    const dialogRef = this.dialog.open(AccessionSelectDialogComponent, {
      width: '650px',
      height: 'auto',
      maxHeight: '85vh',
      autoFocus: false,
      disableClose: true,
      data: null,
      panelClass: 'worker-reports-dialog'
    });
    dialogRef.afterClosed().subscribe((result) => {      if (result === 'upload') {        this.router.navigate(['/app/workerForms']);
      }
    });
  }
}
