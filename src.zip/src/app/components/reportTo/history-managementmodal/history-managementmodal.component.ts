import { Component, Inject, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReportserviceService } from 'src/app/services/reportservice.service';
@Component({
  selector: 'app-history-managementmodal',
  templateUrl: './history-managementmodal.component.html',
  styleUrls: ['./history-managementmodal.component.scss'],
})
export class HistoryManagementmodalComponent implements OnInit, OnChanges {
  worker: any;
  title: string = '';
  searchText: string = '';
  includeInactive: boolean = false;
  workerData: any[] = [];
  reportservice: ReportserviceService;
  constructor(
    ReportserviceService: ReportserviceService,
    public dialogRef: MatDialogRef<HistoryManagementmodalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
    // private reportserviceService: ReportserviceService
  ) {
    this.title = data.Title;
    this.reportservice = ReportserviceService;
  }
  ngOnInit() {}
  ngOnChanges(changes: SimpleChanges) {}
  selectItem(data: any) {
    this.dialogRef.close({ confirmed: true, results: data });
  }
  searchEmployee() {
    this.reportservice
      .getDataContent(
        '/workers?includeInactive=' +
          this.includeInactive +
          '&flag=true&familyName=' +
          this.searchText?.toUpperCase() +
          '&limit=200&skip=0&sortColumn=familyName1&sortOrder=asc'
      )
      .subscribe((response: any) => {
        for (let i = 0; i < response.results.length; i++) {
          this.workerData.push({
            id: response.results[i].workerId,
            name: response.results[i].familyName + ',' + response.results[i].givenName,
          });
        }
      });
    // this.dialogRef.close({ confirmed: true, results: this.worker });
  }
  closeDialog() {
    this.dialogRef.close();
  }
  removeAssignment(data: any, worker: any) {}
}
