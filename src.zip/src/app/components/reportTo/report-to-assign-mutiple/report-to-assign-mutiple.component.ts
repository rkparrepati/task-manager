import { Component, inject, Input, OnChanges } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';
import { constants } from 'src/app/components/reports-to/Models/MasterData';
import { ReportserviceService } from 'src/app/services/reportservice.service';

@Component({
  selector: 'app-report-to-assign-mutiple',
  templateUrl: './report-to-assign-mutiple.component.html',
  styleUrls: ['./report-to-assign-mutiple.component.scss'],
})
export class ReportToAssignMutipleComponent implements OnChanges {
  @Input() assignUser: any = null;
  worker: any = {};
  workerNumber: string = '';
  workerName: string = '';
  items: any[] = [];
  selectedUser: any;
  selectedUsers: any[] = [];
  employeesUsersSearch: string = '';
  step: number = 0;
  reportTypes: any[] = constants.relationTypes;
  reportType: number = 0;
  isSupervisor: boolean = false;
  selectedReportType: string = '';
  isLinear = false;
  usersToAssign: any[] = [];
  constructor(private reportserviceService: ReportserviceService) {
    const data = localStorage.getItem('assignMultiple');
    this.workerNumber = data ? JSON.parse(data).workerNumber : '';
    this.workerName = data ? JSON.parse(data).name : '';
    this.search();
    this.selectedReport(this.reportType);
  }
  ngOnChanges() {}
  selectedReport(id: number) {
    this.reportType = id;
    this.selectedReportType = this.reportTypes.filter((item: any) => item.Id === id)[0].label;
  }
  selectUser(item: any) {
    this.selectedUser = item;
    this.selectedUsers.push(item);
  }
  /*************  ✨ Windsurf Command ⭐  *************/
  /**
 * Search for users to assign, given as follows:
 * @param workers - workers to assign
 * @param familyName - family name
 * @param limit - limit of the number of workers to return
 * @param skip - number of workers to skip
 * @param sortColumn - column name to sort

/*******  0900dd50-80a4-4e53-94f2-af35507fc8db  *******/
  search(): void {
    this.reportserviceService
      .getDataContent(
        '/workers?flag=true&includeInactive=false&limit=100000&sortColumn=familyName1&sortOrder=asc&workerNumber=' +
          this.workerNumber
      )
      .subscribe((response: any) => {
        this.eraser();
        this.addToUsersList([]);
        this.worker = response.results[0];
        this.workerNumber = this.worker.workerNumber;
        this.employeesUsersSearch = this.workerNumber;
        this.workerName = this.worker.familyName + ',' + this.worker.givenName;
      });
  }
  ReassignUser() {}
  eraser() {
    this.worker = {};
    this.workerNumber = '';
    this.workerName = '';
    this.reportType = 0;
    this.employeesUsersSearch = '';
    this.items = [];
  }
  removeUser() {
    this.items = this.items.filter((item) => item.id !== this.selectUser);
  }
  reportTypeChange(reportTypeId: number) {
    this.reportType = reportTypeId;
    this.selectedReport(reportTypeId);
  }
  onStepChange(event: any) {
    this.step = event.selectedIndex;
  }
  duplicateEmployee(data: any) {
    return true;
  }
  searchEmployee() {
    let url: string = `/workers?includeInactive=false&flag=true&familyName=${this.employeesUsersSearch}&limit=100000&skip=0&sortColumn=familyName1&sortOrder=asc`;
    this.reportserviceService.getDataContent(url).subscribe((response) => {
      response.results.forEach((element: any) => {
        this.items.push({
          label: element.familyName + ',' + element.givenName,
          id: element.workerId,
        });
      });
    });
  }
  getusersToAssign(workers: any[]) {
    workers.forEach((data: any) => {
      if (!this.duplicateEmployee(data)) {
        var params = {
          workerId: data.workerId,
        };
        this.reportserviceService
          .getWorkersRelationships(data.workerId.toString(), true)
          .subscribe((response) => (data.relatedWorkerResults = response.data.results));
        this.usersToAssign.push(data);
        this.employeesUsersSearch = '';
      }
    });
  }
  addToUsersList(workers: any[]) {
    if (workers.length != undefined) {
      this.getusersToAssign(workers);
    } else {
      var workerArr = [];
      workerArr.push(workers);
      this.getusersToAssign(workerArr);
    }
  }
}
