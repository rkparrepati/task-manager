import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { RelationshipType, EmailInfo } from '../../reports-to/Models/IWorkerDetails';
import { SelectionService } from '../../reports-to/SelectionService';
import { constants } from '../../reports-to/Models/MasterData';
import { MatDialog } from '@angular/material/dialog';
import { HttpService } from 'src/app/services/http.service';
import { PopupComponent } from '../popup/popup/popup.component';
import { ISearchWorker, IWorkerVM } from '../../reports-to/Models/IWorkerVM';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';
import {
  addDays,
  getPrimaryOrganization,
  getReportTypeFilterData,
  initWorkerVM,
  buildAssignment,
} from '../../reports-to/reportToUtil';
import { ColumnDefinition, IWorker } from '../../reports-to/Models/IWorkerDetails';
import { HttpParams } from '@angular/common/http';
import { WorkerModel } from '../../reports/model/workerModel';
//import {WorkerRoot} from './repoToModels'; // Adjust the import path as necessary

@Component({
  selector: 'app-report-tolanding',
  templateUrl: './report-tolanding.component.html',
  styleUrls: ['./report-tolanding.component.scss'],
})
export class ReportTolandingComponent implements OnInit, OnChanges {
  @Input() selectedworkerNumber: string = '';
  @Input() selectedworker: IWorker | undefined;
  @Input() gridKey: string = '';
  @Output() cellValueChanged = new EventEmitter<{ rowIndex: number; key: string; value: any }>();
  @Output() assignMultiple = new EventEmitter<{ workerNumber: string; name: string }>();
  @Output() workerdataToParent = new EventEmitter<any[]>();
  workerVM: IWorkerVM = initWorkerVM();
  getSubList: boolean = true;
  returnMessage: string = '';
  pageTitle: string = '';
  data: any[] = [];
  reportTypes: any[] = [];
  relationshipTypes: any[] = ['SUPERVISOR', 'PAR', 'TIMECARD'];
  columns: ColumnDefinition[] = [];
  dataSource = new MatTableDataSource<IWorker>([]);
  heading: string = '';
  isVisible: boolean = false;
  editingCell: { rowIndex: number; key: string } | null = null;
  displayedColumns: string[] = [];
  worker!: any;
  relationShips: RelationshipType[] = [];
  constructor(
    public appService: AppService,
    private reportserviceService: ReportserviceService,
    private selectionService: SelectionService,
    private dialog: MatDialog,
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}
  ngOnInit() {
    this.getReportTypes(true);
    //Get UserInformation
    this.workerVM.userInfo = this.appService.getUserData();
    this.checkRoleHasAccess();
    this.getParameters();
    this.getWorkerByWorkerNumber(this.workerVM.userInfo.workerNumber, true);

    this.columns = constants.gridColumns;
    this.displayedColumns = this.columns
      .filter((column) => column.visible !== false)
      .map((column) => column.key);
    //this.getWorkers();
    this.childSelectedItem();
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes['selectedworker']) {
      if (this.selectedworker != undefined) {
        this.data = [];
        if (this.selectedworker.workerId != 0) {
          this.getWorkerSearchData(this.selectedworker);
          this.dataSource = new MatTableDataSource<IWorker>([]);
        }
      }
    }
    if (changes['selectedworkerNumber']) {
      if (this.selectedworkerNumber != '') this.data = [];
      this.dataSource = new MatTableDataSource<IWorker>(this.data);
      this.getWorkerByWorkerNumber(this.selectedworkerNumber, true);
    }
    if (changes['columns']) {
      this.displayedColumns = this.columns.map((column) => column.key);
    }
    if (changes.dataSource && changes.dataSource.currentValue) {
      this.dataSource = new MatTableDataSource<IWorker>(changes.dataSource.currentValue.results);
    }
  }
  searchWorker() {}
  getWorkerSearchData(worker: IWorker) {
    if (worker.workerId == 0) {
      return;
    }
    if (worker) {
      this.workerVM.total = 1;
    }
    this.workerVM.employeeList = [];
    //this.workerVM.primaryWorker = worker;
    this.workerVM.primaryWorker.name =
      this.workerVM.primaryWorker.familyName +
      ', ' +
      this.workerVM.primaryWorker.preferredFirstName;

    if (this.workerVM.primaryWorker.workerOrganizationSufix != null) {
      this.workerVM.primaryWorker.organizationSuffixTx =
        this.workerVM.primaryWorker.workerOrganizationSufix.sufixTx;
    }
    this.workerVM.workerList = [];
    var primarySearchOrg: any = this.getPrimaryOrganization(worker.organizationHistory);
    if (primarySearchOrg) {
      worker.organization =
        primarySearchOrg.organization.businessAreaCode +
        '/' +
        primarySearchOrg.organization.shortName;
      this.workerVM.accronym = worker.organization;
    } else {
      worker.organization = 'Home Organization missing';
    }
    this.reportserviceService
      .getWorkersRelationships(worker.workerId.toString(), true)
      .subscribe((response: any) => {
        this.getSubList = false;
        this.processWorkerReportSearchInfo(worker, response.results);
      });
  }
  processWorkerReportSearchInfo(worker: any, response: any) {
    this.processWorkerReportInfo(worker, response);
    this.workerVM.showPrimarySearch = true;
  }
  getReportTypes(includeInactive: boolean) {
    this.reportserviceService.getReportTypes(includeInactive).subscribe((response: any) => {
      this.reportTypes = getReportTypeFilterData(response?.results);
      this.relationShips =
        response?.results.filter(
          (item: any) => item.value === constants.relationshipTypes.SUPERVISOR
        ) || [];
      if (this.relationShips.length > 0) this.workerVM.reportsToType = this.relationShips[0];
    });
  }
  getParameters(): void {
    this.reportserviceService.getParameters().subscribe((response: any) => {
      this.workerVM.links = response.results;

      this.workerVM.emLocatorurl =
        response?.results.filter((item: any) => item.parameterName === 'Employee Locator')[0]
          ?.parameterValueText || '';
    });
  }
  getWorkerByWorkerNumber(
    workerNumber: string,
    includeInactive: boolean,
    pageload: boolean = true
  ): void {
    if (this.worker != undefined) pageload = false;
    //userInfoRetrieved
    this.reportserviceService
      .getWorkerByWorkerNumber(workerNumber, includeInactive)
      .subscribe((response: any) => {
        this.workerVM.isPrimary = true;
        this.workerVM.primaryWorker = response?.results[0];
        // this.workerdataToParent.emit(this.workerVM.primaryWorker.workerId);
        this.workerVM.primaryWorker.name =
          this.workerVM.primaryWorker.familyName +
          ', ' +
          this.workerVM.primaryWorker.preferredFirstName;
        let data = { workerNumber: workerNumber, name: this.workerVM.primaryWorker.name };
        localStorage.setItem('assignMultiple', JSON.stringify(data)); // Store the data in localStorage data.toString());
        this.assignMultiple.emit({
          workerNumber: workerNumber,
          name: this.workerVM.primaryWorker.name,
        });
        if (pageload == true) {
          this.workerVM.employeeSearch = this.workerVM.primaryWorker.workerNumber;

          this.getEmployees(0);
          this.getWorkerData(this.workerVM.primaryWorker, true);
        }
      });
  }
  getEmployees(type: number): void {
    this.workerVM.reportsToType = type;
    this.workerVM.noWorkerFoundMsg = '';
    this.workerVM.getEmployeesOnlytype2 = [];
    var searchTerm = this.getSearchTerm(type);
    var pageName;
    if (!searchTerm) {
      return;
    }
    var includeInactive;
    var flag;
    if (type === 2 && this.workerVM.includeAttrition) {
      includeInactive = false;
      flag = 'reportsTo';
    } else {
      includeInactive = true;
      flag = 'reportsTo';
    }
    /**
     * If type=2, pageName='reportsToPage' which in turn make the filter=200
     * If type=1, pageName='tableDataPage' which in turn make the filter=100000
     */
    if (type == 2) {
      pageName = 'reportsToPage';
    }
    if (type == 0 || type == 1) {
      pageName = 'tableDataPage';
      this.searchWorkerNumber(searchTerm, includeInactive, true, 100000, type);
    }
  }

  getSearchTerm(type: null | number): string {
    var searchTerm;
    if (type === 0) {
      searchTerm = this.workerVM.employeeSearch;
    } else if (type === 1) {
      searchTerm = this.workerVM.employeeSearch;
    } else if (type === 2) {
      searchTerm = this.workerVM.reportsToSearchInput;
    }
    return searchTerm;
  }

  childSelectedItem(): void {
    this.selectionService.selectedItem$.subscribe((selected) => {
      if (selected) {
        let items = constants.menu.link.items;
        let url: string = '';
        this.data = [];
        this.dataSource = new MatTableDataSource<IWorker>(this.data);
        const selectedItem = items.find((item) => item.id.toString() === selected);
        this.pageTitle = selectedItem?.label || '';
        // if (selectedItem && (selectedItem.id == 0 || selectedItem.id == 1))
        if (
          selectedItem &&
          (selectedItem.id == 0 || selectedItem.id == 1 || selectedItem.id == 3)
        ) {
          if (this.getSubList) {
            url = selectedItem.id == 3 ? this.getWaitingForAssignment() : selectedItem.url;
            this.workerVM.showWait = true;
            this.reportserviceService.getData(url).subscribe((data) => {
              this.displayData(data.results, 'L');
            });
          }
        }
      }
    });
  }

  editAssignment(
    worker: any,
    retortyType: string,
    defaultUpdate: boolean = false,
    title: string = ''
  ): void {
    let fromWorker: string = '';
    let relationshipType: any;
    const reportTypeObject = this.getReportType(retortyType);
    //reportTypes
    relationshipType = reportTypeObject.length > 0 ? reportTypeObject[0] : 0;
    switch (retortyType) {
      case 'SUPERVISOR':
        fromWorker = worker.defaultReporting;
        worker.relationshipId = worker.defaultReportingId;
        break;
      case 'TIMECARD':
        fromWorker = worker.timecardReporting;
        worker.relationshipId = worker.timecardReportingId;
        break;
      case 'PAR':
        fromWorker = worker.parReporting;
        worker.relationshipId = worker.parReportingId;
        break;
      default:
        break;
    }
    this.workerVM.parReportTypeObject = this.getReportType('PAR');
    this.workerVM.timecardReportTypeObject = this.getReportType('TIMECARD');

    if (
      defaultUpdate == true &&
      (worker.parReporting == 'UNASSIGNED' || worker.parReporting == worker.defaultReporting)
    ) {
      this.workerVM.defaultUpdateOfPar = true;
    }
    if (
      defaultUpdate == true &&
      (worker.timecardReporting == 'UNASSIGNED' ||
        worker.timecardReporting == worker.defaultReporting)
    ) {
      this.workerVM.defaultUpdateOfTimecard = true;
    }
    if (fromWorker === 'UNASSIGNED') {
      fromWorker = '';
    }

    let dailogPopup = this.dialog.open(PopupComponent, {
      data: { Title: this.heading, SelectedItem: title, Row: worker },
      width: '75%',
      height: '60%',
    });

    dailogPopup.afterClosed().subscribe((result) => {
      this.handleReassignWorker(result, worker, defaultUpdate, relationshipType, fromWorker);
    });
  }

  reassignFilterWorker(
    worker: any,
    reportType: string,
    toWorker: any,
    notification: boolean,
    reportTypes: any
  ): boolean {
    return true;
  }
  sendEmail(emails: any[]) {
    var emailPromises: any[] = [];

    emails.forEach((email: any) => {
      emailPromises.push(this.httpService.post('/email', email).subscribe((response: any) => {}));
    });
  }
  reassignWorker(supervisor: any, reportType: any, worker: any, notification: boolean): any {
    let emailInfo: any;
    if (notification) {
      emailInfo = this.buildEmail(
        supervisor,
        reportType,
        this.workerVM.usersToAssign,
        this.reportTypes
      );
    }
    let assignments: any[] = [];
    if (reportType.id === -1 || reportType.label === 'SUPERVISOR') {
      assignments = [
        buildAssignment(supervisor, worker, this.reportTypes[0].id),
        buildAssignment(supervisor, worker, this.reportTypes[1].id),
        buildAssignment(supervisor, worker, this.reportTypes[2].id),
      ];
    } else {
      assignments = [buildAssignment(supervisor, worker, reportType.id)];
    }
    const url =
      assignments.length === 1 ? '/workers-relationships' : '/workers-relationships/assign-users';
    this.httpService.post(url, assignments).subscribe((data) => {
      this.sendEmail(emailInfo);
    });
  }
  hasAnEmailAddress(address: string): boolean {
    if (address && address !== 'none@uspto.gov') return true;
    return false;
  }
  getRelatedSupervisor(reportType: any, relatedWorkerResults: any[]) {
    const relatedEmails = relatedWorkerResults.filter(
      (relationship: any) => relationship.relationshipSummary.id === reportType.id
    );
    if (relatedEmails) return this.createEmailItem(relatedEmails[0], reportType);
  }
  createEmailItem(relationship: any, reportType: any): any {
    if (relationship.relatedWorker.emailAddress) {
      var emailInfo = {
        toMail: relationship.relatedWorker.emailAddress,
        fromEmail: relationship.relatedWorker.emailAddress,
        subject: 'Worker has been removed from your supervisory list',
        message:
          'Worker ' +
          relationship.baseWorker.givenName +
          ' ' +
          relationship.baseWorker.familyName +
          ' has been assign to another supervisor for report type ' +
          reportType.label,
      };
      if (this.hasAnEmailAddress(relationship.relatedWorker.emailAddress)) {
        return emailInfo;
      }
    }
    return null;
  }
  getPreviousSupervisorEmails(reportType: any, workers: any[], reportToTypes: any[]) {
    var emailMessages: any[] = [];
    var relatedEmail: any;
    workers.forEach((worker: any) => {
      if (worker.relatedWorkerResults) {
        let reportTypeObj: any = null;

        if (reportType.id === -1) {
          reportToTypes.forEach((relationType: any) => {
            relatedEmail = this.getRelatedSupervisor(relationType, worker.relatedWorkerResults);
            if (relatedEmail) {
              emailMessages.push(relatedEmail);
            }
          });
        } else {
          relatedEmail = this.getRelatedSupervisor(reportType, worker.relatedWorkerResults);
          if (relatedEmail) {
            emailMessages.push(relatedEmail);
          }
        }
      } else {
        var toMail;
        if (reportType.label === 'Par') {
          toMail = worker.parReportingEmailAddress;
        } else if (reportType.label === 'TIMECARD') {
          toMail = worker.timecardReportingEmailAddress;
        } else {
          toMail = worker.defaultReportingEmailAddress;
        }
        let emailInformation = {
          toMail: toMail,
          fromEmail: toMail,
          subject: 'Worker has been removed from your supervisory list',
          message:
            'Worker ' +
            worker.name +
            ' has been assign to another supervisor for report type ' +
            reportType.label,
        };

        if (this.hasAnEmailAddress(toMail)) {
          emailMessages.push(emailInformation);
        }
      }
    });
    return emailMessages;
  }
  buildEmail(supervisor: any, reportType: any, workers: any, reportToTypes: any): EmailInfo[] {
    var toEmail = supervisor.emailAddress;
    var workerList = '';

    var emailInfo: EmailInfo;
    var emailToWorkers: any;

    if (reportType?.id === -1) {
      reportType.label = 'All Reports';
    }

    var emailMessages = this.getPreviousSupervisorEmails(reportType, workers, reportToTypes);
    var workerSubject = 'Your supervisor has changed for report type ' + reportType.label;
    workers.forEach((item: any) => {
      if (workerList) {
        workerList += ', ' + item.givenName + ' ' + item.familyName;
      } else {
        workerList = item.givenName + ' ' + item.familyName;
      }

      if (emailToWorkers) {
        emailToWorkers += '~' + item.emailAddress;
      } else {
        emailToWorkers = item.emailAddress;
      }
    });

    emailInfo = {
      toMail: emailToWorkers,
      fromEmail: emailToWorkers,
      subject: workerSubject,
      message: 'Your supervisor is now ' + supervisor.givenName + ' ' + supervisor.familyName,
    };

    if (this.hasAnEmailAddress(emailInfo.toMail)) {
      emailMessages.push(emailInfo);
    }

    var subject = 'Workers has been assigned to you for report type ' + reportType.label;
    var message = 'Workers:' + workerList;
    message += ' .  Reporting type is: ' + reportType.label;

    emailInfo = {
      toMail: toEmail,
      fromEmail: toEmail,
      subject: subject,
      message: message,
    };
    if (this.hasAnEmailAddress(emailInfo.toMail)) {
      emailMessages.push(emailInfo);
    }
    return emailMessages;
  }

  handleReassignWorker(
    data: any,
    worker: any,
    defaultUpdate: any,
    relationshipType: any,
    fromWorker: string
  ) {
    if (data.actionType == '' || data.actionType == undefined) {
      return;
    }
    this.workerVM.showWait = true;
    if (data.actionType === 'removeAssignment') {
      this.removeAssignmentDetails(data.results, worker, relationshipType, fromWorker, true);
      return;
    } else if (data.actionType === 'assignToMe') {
      data.toWorker = this.workerVM.primaryWorker;
    } else {
      data.toWorker = data.results;
    }
    this.reassignWorker(worker, relationshipType, data.toWorker, true);
    {
      this.workerVM.showWait = false;
      var dialogType = data == 'Par' ? 'Performance Appraisals' : data.dialogDataType;
      if (data.toWorker.workerOrganizationSufix !== undefined) {
        worker.organizationSuffixTx = data.toWorker.workerOrganizationSufix.sufixTx;
      } else {
        worker.organizationSuffixTx = data.toWorker.organizationSuffixTx;
      }

      if (data.actionType === 'assignToMe') {
        this.returnMessage =
          dialogType +
          ' reporting assignment for ' +
          worker.familyName +
          ', ' +
          worker.preferredFirstName +
          ' (' +
          worker.workerNumber +
          ') ' +
          ' reassigned to you.';
        var workerExists = false;
        for (var i = 0; i < this.workerVM.originalList.length; i++) {
          if (this.workerVM.originalList[i].workerId == worker.workerId) {
            workerExists = true;
          }
        }
        if (!workerExists) {
          this.workerVM.originalList.push(worker);
        }
      } else {
        this.returnMessage =
          dialogType +
          ' reporting assignment for ' +
          worker.familyName +
          ', ' +
          worker.preferredFirstName +
          ' reassigned to ' +
          data.toWorker.preferredFirstName +
          ' ' +
          data.toWorker.familyName +
          ' - ' +
          data.toWorker.workerNumber;
        for (var i = 0; i < this.workerVM.originalList.length; i++) {
          if (this.workerVM.originalList[i].workerId == worker.workerId) {
            this.workerVM.originalList.splice(i, 1);
          }
        }
      }
      // getWorkerEmployeeList({ workerId: data.toWorker.workerId });
      if (data.reportType && data.reportType.value == 'PAR') {
        worker.parReporting = data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
      } else if (data.reportType && data.reportType.value == 'TIMECARD') {
        worker.timecardReporting =
          data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
      } else {
        worker.defaultReporting =
          data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
      }

      if (defaultUpdate == true) {
        worker.defaultReporting =
          data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
      }
      this.workerVM.usersToAssign = [];

      /**
       * editViewNumber:
       *  is 0 when edit operation is done from unassigned page
       *  is 3 when edit operation is done from default or table search page
       */
      if (this.workerVM.editViewNumber == 0) {
        // getUnassignedWorkers(vm.limit, vm.skip);
      }
      if (this.workerVM.editViewNumber == 4) {
        //  getUnassignedPWorkers(vm.limit, vm.skip);
      }
      if (this.workerVM.editViewNumber == 3) {
        // refreshChildData();
      }
    }
    if (this.workerVM.defaultUpdateOfPar == true) {
      worker.parReporting = data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
    }
    if (this.workerVM.defaultUpdateOfTimecard == true) {
      worker.timecardReporting = data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
    }
    if (defaultUpdate == true) {
      worker.defaultReporting = data.toWorker.familyName + ', ' + data.toWorker.preferredFirstName;
      worker.organizationSuffixTx = data.toWorker.organizationSuffixTx;
    }
    this.workerVM.defaultUpdateOfPar = false;
    this.workerVM.defaultUpdateOfTimecard = false;
    //refreshChildData();
  }

  refreshChildData() {
    let workerId: number = 0;
    var parentFullName = '';
    var isEditFromDefaultPage = false;

    if (this.workerVM.person != undefined && this.workerVM.person != '') {
      workerId = this.workerVM.person.workerId;
      isEditFromDefaultPage = false;
    } else {
      workerId = this.workerVM.primaryWorker.workerId;
      parentFullName =
        this.workerVM.primaryWorker.familyName +
        ', ' +
        this.workerVM.primaryWorker.preferredFirstName;
      isEditFromDefaultPage = true;
    }
    this.reportserviceService
      .getSupervisorWorkersRelationshipsList(Number(workerId), false, null, null)
      .subscribe((response: any) => {
        if (isEditFromDefaultPage == true) {
          this.updateEmployeeGlobalListForDefaultPage(response.results);
        } else {
          this.updateEmployeeGlobalListForDefaultPage(this.workerVM.employeeListGlobal);
        }
        this.processEmployeeListSearchUpdated(response.results, parentFullName);
      });
  }
  processEmployeeListSearchUpdated(data: any[], parentFullName: string) {
    var worker;
    let tableList: any = [];
    this.workerVM.employeeList = [];
    data.forEach((row) => {
      var inListWorker = this.isAlreadyInList(row.baseWorker);
      if (inListWorker) {
        worker = inListWorker;
      } else {
        worker = row.baseWorker;
      }
      worker.organizationHistory = row.organizationHistory;
      if (row.relationshipSummary.value === 'SUPERVISOR') {
        worker.defaultReportingId = row.workerRelationshipId;
        worker.defaultReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.defaultReportingEmailAddress = row.relatedWorker.emailAddress;
        worker.defaultReportingWorkerId = row.relatedWorker.workerId;
        worker.defaultReportingWorkerNumber = row.relatedWorker.workerNumber;
      } else if (row.relationshipSummary.value === 'PAR') {
        worker.parReportingId = row.workerRelationshipId;
        worker.parReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.parReportingEmailAddress = row.relatedWorker.emailAddress;
      } else if (row.relationshipSummary.value === 'TIMECARD') {
        worker.timecardReportingId = row.workerRelationshipId;
        worker.timecardReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.timecardReportingEmailAddress = row.relatedWorker.emailAddress;
      }
      if (!worker.defaultReporting) {
        worker.defaultReporting = 'UNASSIGNED';
      }
      if (!worker.parReporting || worker.parReporting == 'UNASSIGNED') {
        worker.parReporting = worker.defaultReporting;
      }

      if (!worker.timecardReporting || worker.timecardReporting == 'UNASSIGNED') {
        worker.timecardReporting = worker.defaultReporting;
      }
      //worker.organization = this.workerVM.getPrimaryOrganization(worker.organizationHistory);
      worker.name = worker.familyName + ', ' + worker.preferredFirstName;
      if (!inListWorker) {
        this.workerVM.tableList.push(worker);
        this.workerVM.employeeList.push(worker); // helps to merge data in single row
      }
    });
    var parentPersonName = '';
    if (!this.workerVM.originalList) {
      this.workerVM.originalList = this.workerVM.workerList;
    }

    //vm.tableList = angular.copy(tableListAfterRemoval);
    this.workerVM.tableList = this.getTableListByRemovingUnwantedData3(this.workerVM.tableList);
    this.workerVM.total = this.workerVM.tableList.length + 1;
    var empRecords = [];
    this.workerVM.tableList.forEach(function (row) {
      // MultipleAssignmentsControllerHelper.searchUsers(row.workerNumber).then(function (response) {
      //     if (response.results[0].supervisorIndicator) {
      //         row.supervisorIndicator = true;
      //     }
      //     row.organizationSuffixTx = response.results[0].workerOrganizationSufix.sufixTx;
      //     empRecords.push(row);
      //     if (empRecords.length === vm.tableList.length) {
      //         sortRecords(vm.tableList)
      //     }
      // }, function () {
      // });
    });
  }

  getDialogType(data: string): string {
    if (data == 'Par') {
      return 'Performance Appraisals';
    } else {
      return data;
    }
  }
  removeAssignmentDetails(
    data: any,
    worker: any,
    relationshipType: any,
    fromWorker: string,
    notification: boolean = false
  ) {
    let emails: EmailInfo[] = [];
    let emailInfo: EmailInfo;
    data.dialogDataType = relationshipType.label.toUpperCase();
    if (notification) {
      let toMail;
      if (data.dialogDataType === 'PAR') {
        toMail = data.parReportingEmailAddress;
      } else if (data.dialogDataType === 'TIMECARD') {
        toMail = data.worker.timecardReportingEmailAddress;
      } else {
        toMail = data.emailAddress;
      }
      emailInfo = {
        toMail: toMail,
        fromEmail: toMail,
        subject: 'Worker has been removed from your supervisory list',
        message:
          'Worker ' +
          data.givenName +
          ' ' +
          data.familyName +
          ' supervisor hass been removed for report type ' +
          data.dialogDataType,
      };
      if (this.hasAnEmailAddress(toMail)) {
        emails.push(emailInfo);
      }
      toMail = data.emailAddress;
      emailInfo = {
        toMail: toMail,
        fromEmail: toMail,
        message:
          'Your supervisor (' + fromWorker + ') for ' + data.dialogDataType + ' has been removed',
        subject: 'Your supervisor for ' + data.dialogDataType + ' has been removed',
      };
      if (this.hasAnEmailAddress(toMail)) {
        emails.push(emailInfo);
      }
    }
    this.reportserviceService.removeAssignment(worker.relationshipId).subscribe((response: any) => {
      if (emails.length > 0) this.sendEmail(emails);

      this.workerVM.employeeList = [];
      if (data.reportType && data.reportType.value == 'PAR') {
        worker.parReporting = worker.defaultReporting;
      }
      if (data.reportType && data.reportType.value == 'TIMECARD') {
        worker.timecardReporting = worker.defaultReporting;
      }
      this.refreshChildData();
    });
  }
  getTableListByRemovingUnwantedData2(existingTableList: WorkerModel[]) {
    var parentFullName = this.getParentFullName();
    var tableListAfterRemoval: any = [];
    existingTableList.forEach((row: any, index: any) => {
      if (
        row.relatedWorker.workerId == this.workerVM.primaryWorkerId &&
        (row.relationshipSummary.value == 'PAR' ||
          row.relationshipSummary.value == 'TIMECARD' ||
          row.relationshipSummary.value == 'SUPERVISOR')
      ) {
        tableListAfterRemoval.push(row);
      }
    });
    return tableListAfterRemoval;
  }
  getParentFullName(): string {
    var parentFullName = '';
    var workerId = '';
    if (this.workerVM.person != undefined && this.workerVM.person != '') {
      workerId = this.workerVM.person.workerId;
      this.workerVM.primaryWorkerId = this.workerVM.person.workerId;
      parentFullName =
        this.workerVM.person.familyName + ', ' + this.workerVM.person.preferredFirstName;
    } else {
      workerId = this.workerVM.primaryWorker.workerId;
      this.workerVM.primaryWorkerId = this.workerVM.primaryWorker.workerId;
      parentFullName =
        this.workerVM.primaryWorker.familyName +
        ', ' +
        this.workerVM.primaryWorker.preferredFirstName;
    }
    return parentFullName;
  }

  updateEmployeeGlobalListForDefaultPage(updatedListAfterEdit: any[]) {
    let uniqueWorkerIdList: WorkerModel[] = updatedListAfterEdit.filter((row: any) => {
      row.relatedWorker.workerId == this.workerVM.primaryWorkerId &&
        (row.relationshipSummary.value == 'PAR' ||
          row.relationshipSummary.value == 'TIMECARD' ||
          row.relationshipSummary.value == 'SUPERVISOR');
    });
    updatedListAfterEdit.forEach(function (worker: any) {
      if (!uniqueWorkerIdList.includes(worker.baseWorker.workerId)) {
        uniqueWorkerIdList.push(worker.baseWorker.workerId);
      }
    });

    var temp = this.workerVM.employeeListGlobal;
    this.workerVM.employeeListGlobal.forEach(function (globalWorker, index) {
      if (!uniqueWorkerIdList.includes(globalWorker.workerId)) {
        temp.splice(index, 1);
      }
    });
    this.workerVM.employeeListGlobal = temp;
  }
  editAssignment1(worker: any) {
    const params = new HttpParams()
      .set('workerId', worker.Id)
      .set('relationshipTypeId', worker.relationshipTypeId);
    this.reportserviceService
      .getworkerData('/workers-relationships', params)
      .subscribe((response: any) => {
        this.headings(response?.results);
      });
  }
  checkRoleHasAccess() {
    this.isVisible = this.workerVM.userInfo.roles.filter((role: any) => {
      return (
        role === constants.roles.InfraAdmin ||
        role === constants.roles.InfraSupervisorAdmin ||
        role === constants.roles.InfraReportsTo
      );
    });
  }
  getReportType(reportType: string): any {
    return this.reportTypes.filter(
      (item: any) => item.label.toUpperCase() === reportType.toUpperCase()
    );
  }
  //#region Optional Region Name
  // getUserInfo() {
  //     this.reportserviceService.getUserInfo().subscribe((response: any) => {
  //         this.workerVM.userInfo = response;
  //         this.getWorkerData(true, this.workerVM.userInfo.workerNumber);
  //     });
  // }
  //#endregion
  getWaitingForAssignment(): string {
    const endDate = addDays(7).toISOString().split('T')[0];
    let startDate = new Date().toISOString().split('T')[0];
    return '/waiting-for-assignments/' + startDate + '/' + endDate;
  }
  setSupervisor(employee: any) {
    this.workerVM.supervisor = employee;
    this.workerVM.supervisorName =
      this.workerVM.supervisor.familyName + ', ' + this.workerVM.supervisor.preferredFirstName;
  }
  //10-Sept
  searchWorkerNumber(
    text: string,
    includeInactive: boolean,
    flag: boolean,
    defaultLimit: number,
    type: number
  ): void {
    this.workerVM.showWait = false;
    this.reportserviceService
      .getworker(flag, includeInactive, defaultLimit, 'familyName1', 'asc', text)
      .subscribe((response: any) => {
        const data = response?.results || [];
        let onlyEmps = data.filter((emp: any) => emp.employmentType?.value != 'C');

        if (type != 2 && onlyEmps.length == 0) {
          this.workerVM.supervisorName = '';
          this.workerVM.noWorkersFound = true;
          this.workerVM.noWorkerFoundMsg = 'No workers found';
        } else if (onlyEmps.length == 1) {
          if (type === 0) {
            if (!this.workerVM.supervisorData) {
              this.workerVM.supervisorData = onlyEmps[0];
            }
            this.setSupervisor(onlyEmps[0]);
          } else if (type === 1) {
            this.workerVM.supervisorName =
              this.workerVM.supervisor.familyName +
              ', ' +
              this.workerVM.supervisor.preferredFirstName;
            if (this.workerVM.supervisor.workerNumber == onlyEmps[0].workerNumber) {
              this.workerVM.supervisorName = '';
              this.workerVM.noWorkersFound = true;
              this.workerVM.noWorkerFoundMsg = 'Cannot assign yourself';
            } else {
              this.addToUsersList(onlyEmps[0]);
            }
          } else if (type === 2) {
            this.workerVM.getEmployeesOnlytype2.push(onlyEmps[0]);
          }
        } else {
          if (type === 2) {
            this.workerVM.getEmployeesOnlytype2 = onlyEmps.filter(
              (listFilter: any) => listFilter.workerNumber.indexOf('C') === -1
            );
          } else {
            this.showMultipleEmployees(onlyEmps, type);
          }
        }
        if (type === 2 && this.workerVM.getEmployeesOnlytype2.length == 0) {
          // this.workerVM.mainNoWorkerFound = true;
        }
      });
  }
  //10-Sept
  showMultipleEmployees(workers: [], type: number) {
    var modalOptions = {
      workers: workers,
      roleName: this.workerVM.reportToType.value,
      type: type,
      isOrganizationRequired: 'true',
      supervisor: this.workerVM.supervisor,
    };

    this.getWorkersForSupervisor(modalOptions, type);
  }
  //10-Sept
  getWorkersForSupervisor(dataObject: any, type: number) {
    this.reportserviceService
      .getSupervisorWorkersRelationshipsList(this.workerVM.supervisor.workerId, true)
      .subscribe((response: any) => {
        var workersList = dataObject.workers;
        var responseWorkersList = response.data.results;
        var supervisorWorkerId = this.workerVM.supervisor.workerId;
        workersList.forEach((worker: any) => {
          worker.isSameSupervisor = false;
          const responseWorkers = responseWorkersList.filter(
            (responseWorker: any) =>
              responseWorker.relatedWorker.workerId == worker.workerId &&
              supervisorWorkerId == responseWorker.relatedWorker.workerId &&
              responseWorker.relationshipSummary.id == this.workerVM.reportToType.id
          );
          if (responseWorkers != null && responseWorkers != undefined) {
            worker.supervisorId = dataObject.supervisor.workerId;
            worker.isSameSupervisor = true;
          }
          if (this.workerVM.supervisor.workerNumber == worker.workerNumber) {
            worker.isSameSupervisor = true;
          }
          if (
            this.workerVM.usersToAssign.filter(
              (assignedUser: any) => assignedUser.workerNumber == worker.workerNumber
            )
          ) {
            worker.isSameSupervisor = true;
          }
        });
        dataObject.workers = workersList;
      });
  }
  addToUsersList(workers: any) {
    if (workers.length != undefined) {
      workers.forEach((worker: any) => {
        this.reportserviceService
          .getWorkersRelationships(worker.workerId.toString(), true)
          .subscribe((response) => {
            worker.relatedWorkerResults = response.data.results;
            this.workerVM.usersToAssign.push(worker);
          });
      });
    }
  }
  fillData(
    id: string,
    name: string,
    role: string = '',
    workerNumber: string,
    defaultReporting: string,
    organization: string,
    organizationSuffixTx: string,
    employeeNumber: string,
    appraisalsReporting: string,
    timecardReporting: string,
    prefix: string,
    parReporting: string,
    defaultReportingId: string = '',
    timecardReportingId: string = '',
    parReportingId: string = '',
    emailAddress: string = ''
  ): void {
    this.workerVM.showWait = true;
    this.data.push({
      id: id,
      name: name,
      role: role,
      workerNumber: workerNumber,
      defaultReporting: defaultReporting,
      organization: organization,
      organizationSuffixTx: organizationSuffixTx,
      employeeNumber: employeeNumber,
      appraisalsReporting: appraisalsReporting,
      timecardReporting: timecardReporting,
      prefix: prefix,
      parReporting: parReporting,
      editable: false,
      defaultReportingId: defaultReportingId,
      timecardReportingId: timecardReportingId,
      parReportingId: parReportingId,
      emailAddress: emailAddress,
    });
    this.workerVM.showPrimarySearch = true;
    this.dataSource = new MatTableDataSource<IWorker>(this.data);
    this.workerVM.showWait = false;
  }
  getWorkers() {
    const params = new HttpParams()
      .set('notRelated', true)
      .set('isContractor', false)
      .set('limit', this.workerVM.limit)
      .set('skip', this.workerVM.skip)
      .set('sortColumn', 'familyName1')
      .set('sortOrder', 'asc');
    this.reportserviceService.getworkerData(`/workers`, params).subscribe((response: any) => {
      this.headings(response?.results);
    });
  }
  headings(results: any[]): void {
    if (results && results.length > 0) {
      const firstResult = results[0];

      this.worker = firstResult;
      this.heading = firstResult.familyName + ', ' + firstResult.givenName;
      this.heading += '_' + firstResult.workerNumber;
      const organizationHistory = firstResult.organizationHistory[0].organization;
      this.heading +=
        '-' + organizationHistory?.businessAreaCode + '/' + organizationHistory?.shortName;
    }
  }

  cancelChanges() {
    this.editingCell = null;
  }
  // saveChanges() {}
  buildReportingTitle(worker: any) {
    this.workerVM.tableTitle =
      'Reporting Information for: ' +
      worker.familyName +
      ', ' +
      worker.preferredFirstName +
      ' - ' +
      worker.workerNumber +
      ' - ' +
      this.getPrimaryOrganization(worker.organizationHistory);
  }
  processWorkerReportInfo1(worker: any, data: [], getSubList: [] = []) {
    this.buildReportingTitle(worker);
    worker.name = worker.familyName + ', ' + worker.preferredFirstName;
    worker.organization = this.getPrimaryOrganization(worker.organizationHistory);
    worker.defaultReporting = constants.reportingStatus.unAssigned;
    worker.timecardReporting = constants.reportingStatus.unAssigned;
    worker.parReporting = constants.reportingStatus.unAssigned; // Process the worker report information
    if (data) {
      data.forEach((row: any) => {
        worker.workerOrganizationSufix = row.workerOrganizationSufix;
        if (row.relationshipSummary.value === constants.relationshipTypes.SUPERVISOR) {
          worker.defaultReportingId = row.workerRelationshipId;
          worker.defaultReportingWorkerId = row.relatedWorker.workerId;
          worker.defaultReportingWorkerNumber = row.relatedWorker.workerNumber;
          worker.defaultReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        } else if (row.relationshipSummary.value === constants.relationshipTypes.PAR) {
          worker.parReportingId = row.workerRelationshipId;
          worker.parReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        } else if (row.relationshipSummary.value === constants.relationshipTypes.TIMECARD) {
          worker.timecardReportingId = row.workerRelationshipId;
          worker.timecardReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        }
        if (!worker.defaultReporting) {
          worker.defaultReporting = constants.reportingStatus.unAssigned;
        }

        if (!worker.parReporting || worker.parReporting == constants.reportingStatus.unAssigned) {
          worker.parReporting = worker.defaultReporting;
        }

        if (
          !worker.timecardReporting ||
          worker.timecardReporting == constants.reportingStatus.unAssigned
        ) {
          worker.timecardReporting = worker.defaultReporting;
        }
      });
    }
    if (getSubList) {
      let url =
        '/workers-relationships?associatedToReportingWorkerId=' +
        worker.workerId +
        '&includeInactive=true';
      if (this.workerVM.sortColumn) {
        url +=
          '&sortColumn=' + this.workerVM.sortColumn + '&sortOrder=' + this.workerVM.sortDirection;
      }
      this.reportserviceService.getworkerData(url, new HttpParams()).subscribe((response: any) => {
        this.workerVM.showWait = false;
      });
      this.workerVM.showPrimarySearch = true;

      //this.getWorkerEmployeeList(worker);
    } else {
      // this.showWorkerData(worker);
    }
  }
  showWorkerData(person: any) {
    this.workerVM.person = person;
    this.workerVM.tableList = [];
    this.workerVM.showPrimarySearch = true;
    this.workerVM.subListSupervisorIndicator = false;
    this.workerVM.showPrimary = false;
    this.reportserviceService
      .getSupervisorWorkersRelationshipsList(person.workerId, false, null, null)
      .subscribe((response) => {
        this.processEmployeeListSearch(response.results);
      });
  }
  processEmployeeListSearch(data: any[]) {
    var worker;
    data.forEach((row) => {
      var inListWorker = this.isAlreadyInList(row.baseWorker);

      if (inListWorker) {
        worker = inListWorker;
      } else {
        worker = row.baseWorker;
      }

      worker.organizationHistory = row.organizationHistory;
      if (row.relationshipSummary.value === 'SUPERVISOR') {
        worker.defaultReportingId = row.workerRelationshipId;
        worker.defaultReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.defaultReportingEmailAddress = row.relatedWorker.emailAddress;
        worker.defaultReportingWorkerId = row.relatedWorker.workerId;
        worker.defaultReportingWorkerNumber = row.relatedWorker.workerNumber;
      } else if (row.relationshipSummary.value === 'PAR') {
        worker.parReportingId = row.workerRelationshipId;
        worker.parReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.parReportingEmailAddress = row.relatedWorker.emailAddress;
      } else if (row.relationshipSummary.value === 'TIMECARD') {
        worker.timecardReportingId = row.workerRelationshipId;
        worker.timecardReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.timecardReportingEmailAddress = row.relatedWorker.emailAddress;
      }
      if (!worker.defaultReporting) {
        worker.defaultReporting = 'UNASSIGNED';
      }
      if (!worker.parReporting || worker.parReporting == 'UNASSIGNED') {
        worker.parReporting = worker.defaultReporting;
      }

      if (!worker.timecardReporting || worker.timecardReporting == 'UNASSIGNED') {
        worker.timecardReporting = worker.defaultReporting;
      }
      worker.organization = this.getPrimaryOrganization(worker.organizationHistory);
      worker.name = worker.familyName + ', ' + worker.preferredFirstName;
      if (!inListWorker) {
        this.workerVM.tableList.push(worker);
        this.workerVM.employeeList.push(worker); // helps to merge data in single row
      }
    });
    if (!this.workerVM.originalList) {
      this.workerVM.originalList = this.workerVM.workerList;
    }
    this.workerVM.tableList = this.getTableListByRemovingUnwantedData(this.workerVM.tableList);

    this.workerVM.total = this.workerVM.tableList.length + 1;
    var empRecords = [];
    this.workerVM.tableList.forEach((row) => {
      this.reportserviceService.getWorkerByWorkerNumber(row.workerNumber, false).subscribe(
        (response) => {
          if (response.results[0].supervisorIndicator) {
            row.supervisorIndicator = true;
          }
          row.organizationSuffixTx = response.results[0].workerOrganizationSufix.sufixTx;
          this.data.push(row);
          if (empRecords.length === this.workerVM.tableList.length) {
            //sortRecords(vm.tableList)
          }
        },
        function () {}
      );
    });
  }
  getTableListByRemovingUnwantedData(existingTableList: any[]) {
    var parentFullName = this.getParentFullName();
    var tableListAfterRemoval = existingTableList;
    existingTableList.forEach((row: any, index: number) => {
      if (
        row.defaultReporting != parentFullName &&
        row.parReporting != parentFullName &&
        row.timecardReporting != parentFullName
      ) {
        tableListAfterRemoval.splice(index, 1);
      }
    });
    return tableListAfterRemoval;
  }
  isAlreadyInList(worker: any) {
    var foundWorker;
    this.workerVM.employeeList.forEach((employee: any) => {
      if (worker.workerNumber === employee.workerNumber) {
        foundWorker = employee;
      }
    });
    return foundWorker;
  }
  // getParentFullName() {
  //   var parentFullName = '';
  //   if (this.workerVM.person != undefined && this.workerVM.person != '') {
  //     this.workerVM.primaryWorkerId = this.workerVM.person.workerId;
  //     parentFullName =
  //       this.workerVM.person.familyName + ', ' + this.workerVM.person.preferredFirstName;
  //   } else {
  //     this.workerVM.primaryWorkerId = this.workerVM.primaryWorker.workerId;
  //     parentFullName =
  //       this.workerVM.primaryWorker.familyName +
  //       ', ' +
  //       this.workerVM.primaryWorker.preferredFirstName;
  //   }
  //   return parentFullName;
  // };
  processEmployeeList(empData: any[], isSort: any) {
    let worker: any;
    this.workerVM.workerList = [];
    this.workerVM.employeeList = [];
    empData.forEach((row: any) => {
      var inListWorker = this.isAlreadyInList(row.baseWorker);
      worker = inListWorker ? inListWorker : row.baseWorker;

      worker.organizationHistory = row.organizationHistory;
      worker.workerOrganizationSufix = row.workerOrganizationSufix;
      if (row.relationshipSummary.value === constants.relationshipTypes.SUPERVISOR) {
        worker.defaultReportingId = row.workerRelationshipId;
        worker.defaultReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.defaultReportingEmailAddress = row.relatedWorker.emailAddress;
        worker.defaultReportingWorkerId = row.relatedWorker.workerId;
        worker.defaultReportingWorkerNumber = row.relatedWorker.workerNumber;
      } else if (row.relationshipSummary.value === constants.relationshipTypes.PAR) {
        worker.parReportingId = row.workerRelationshipId;
        worker.parReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.parReportingEmailAddress = row.relatedWorker.emailAddress;
      } else if (row.relationshipSummary.value === constants.relationshipTypes.TIMECARD) {
        worker.timecardReportingId = row.workerRelationshipId;
        worker.timecardReporting =
          row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        worker.timecardReportingEmailAddress = row.relatedWorker.emailAddress;
      }
      if (!worker.defaultReporting) {
        worker.defaultReporting = constants.reportingStatus.unAssigned;
      }
      if (!worker.parReporting || worker.parReporting == constants.reportingStatus.unAssigned) {
        worker.parReporting = worker.defaultReporting;
      }
      if (
        !worker.timecardReporting ||
        worker.timecardReporting == constants.reportingStatus.unAssigned
      ) {
        worker.timecardReporting = worker.defaultReporting;
      }
      worker.organization = this.getPrimaryOrganization(worker.organizationHistory);
      worker.name = worker.familyName + ', ' + worker.preferredFirstName;
      worker = JSON.parse(JSON.stringify(worker));
      if (!inListWorker) {
        this.workerVM.workerList.push(worker);
        if (constants.relationshipTypesUsed.includes(row.relationshipSummary.value)) {
          this.workerVM.employeeList.push(worker);
        }
      }
    });
    this.workerVM.workerList = this.getTableListByRemovingUnwantedData3(this.workerVM.workerList);
    let tableListAfterAdding: any[] = [];
    this.workerVM.total = this.workerVM.workerList.length + 1;
    let tableList = this.workerVM.workerList;
    if (this.workerVM.originalList.length == 0) this.workerVM.originalList = tableList;

    if (this.workerVM.workerList.length < 2) {
      this.workerVM.workerList.forEach((row: any) => {
        tableListAfterAdding.push(row);
      });
      this.workerVM.originalList.forEach((row: any) => {
        tableListAfterAdding.push(row);
      });
      var workerArr: any = [];

      tableListAfterAdding.forEach((data: any) => {
        let seen = new Set();
        if (
          this.workerVM.usersToAssign.filter((aUser) => aUser.workerNumber === data.workerNumber)
            .length == 0
        )
          workerArr.push(data);
      });
      this.workerVM.workerList = workerArr;
    }
    this.workerdataToParent.emit(this.workerVM.workerList);
    this.workerVM.workerList.forEach((workerRow: any) => {
      this.fillData(
        workerRow.workerId,
        workerRow.name,
        '',
        workerRow.workerNumber,
        workerRow.defaultReporting,
        workerRow.organization,
        workerRow.organizationSuffixTx,
        workerRow.workerNumber,
        workerRow.appraisalsReporting,
        workerRow.timecardReporting,
        workerRow.prefix,
        workerRow.parReporting,
        workerRow.defaultReportingId,
        workerRow.timecardReportingId,
        workerRow.parReportingId,
        workerRow.emailAddress
      );
    });
    let empRecords: any = [];
    if (!isSort) {
      tableList.forEach((sworker: any) => {
        this.reportserviceService
          .searchWorkerNumber(sworker.workerNumber, false, false, 200)
          .subscribe((response) => {
            if (response.results[0].supervisorIndicator) {
              sworker.supervisorIndicator = true;
            }
            sworker.organizationSuffixTx = response.results[0].workerOrganizationSufix.sufixTx;
            empRecords.push(sworker);
            if (empRecords.length === tableList.length) {
              var sortedRecords = empRecords.sort(function (worker1: any, worker2: any) {
                var sortColumnValue1 = worker1.name;
                var sortColumnValue2 = worker2.name;
                if (sortColumnValue1 < sortColumnValue2) {
                  return -1;
                } else if (sortColumnValue1 > sortColumnValue2) {
                  return 1;
                } else {
                  return 0;
                }
              });
              //sortRecords(sortedRecords);
            }
          });
      });
    }
  }
  sortRecords(records: any) {
    if (this.workerVM.sortColumn && this.workerVM.sortDirection) {
      var sortColumn = this.workerVM.sortColumn;
      var sortOrder = this.workerVM.sortDirection;
      var sortedList = records.sort(function (worker1: any, worker2: any) {
        var sortColumnValue1;
        var sortColumnValue2;
        if (sortColumn === 'workerNumber1') {
          sortColumnValue1 = Number(worker1.workerNumber);
          sortColumnValue2 = Number(worker2.workerNumber);
        } else if (sortColumn === 'name') {
          sortColumnValue1 = worker1.name;
          sortColumnValue2 = worker2.name;
        } else if (sortColumn === 'organization') {
          sortColumnValue1 = worker1.workerOrganizationSufix;
          sortColumnValue2 = worker2.workerOrganizationSufix;
        } else if (sortColumn === 'shortName') {
          sortColumnValue1 = worker1.organizationHistory[0].organization.shortName;
          sortColumnValue2 = worker2.organizationHistory[0].organization.shortName;
        } else if (sortColumn === 'supervisorIndicator') {
          sortColumnValue1 = worker1.supervisorIndicator ? worker1.supervisorIndicator : 2;
          sortColumnValue2 = worker2.supervisorIndicator ? worker2.supervisorIndicator : 2;
        }
        if (sortOrder === 'asc') {
          if (sortColumnValue1 < sortColumnValue2) {
            return -1;
          } else if (sortColumnValue1 > sortColumnValue2) {
            return 1;
          } else {
            return 0;
          }
        } else if (sortOrder === 'desc') {
          if (sortColumnValue1 < sortColumnValue2) {
            return 1;
          } else if (sortColumnValue1 > sortColumnValue2) {
            return -1;
          } else {
            return 0;
          }
        }
        return 0;
      });
      var uniqueList = [];
      for (var i = 0; i < sortedList.length; i++) {
        var isFound = false;
        for (var j = 0; j < uniqueList.length; j++) {
          if (sortedList[i].workerId === uniqueList[j].workerId) {
            isFound = true;
          }
        }
        if (!isFound) {
          uniqueList.push(sortedList[i]);
        }
      }
      this.workerVM.total = uniqueList.length + 1;
      // this.workerVM.tableList = angular.copy(uniqueList)
    }
  }
  getTableListByRemovingUnwantedData3(existingTableList: any) {
    var parentFullName = this.getParentFullName();
    return existingTableList.filter(
      (row: any) =>
        row.defaultReporting == parentFullName ||
        row.parReporting == parentFullName ||
        row.timecardReporting == parentFullName
    );
  }
  duplicateEmployee = (employee: any): boolean => {
    this.workerVM.usersToAssign.forEach((user: any) => {});
    this.workerVM.usersToAssign.filter((aUser) => aUser.workerNumber === employee.workerNumber);
    // if (aUser.workerNumber === employee.workerNumber) {
    //     foundDuplicate = true;
    // }

    return false;
  };
  editorganizationSuffix(row: any) {
    row.editable = true;
  }
  saveorganizationSuffix(row: any) {
    this.workerVM.showWait = true;
    this.reportserviceService
      .saveOrganizationSuffix(row.id, row.organizationSuffixTx)
      .subscribe((reports) => {
        row.editable = false;
        this.workerVM.showWait = false;
      });
  }
  cancelorganizationSuffix(row: any): void {
    row.editable = false;
  }
  getWorkerData(worker: IWorker, getSubList: boolean) {
    this.workerVM.employeeList = [];
    this.workerVM.workerList = [];
    this.workerVM.showWait = true;
    worker.organizationSuffixTx = '';
    if (worker && worker.workerOrganizationSufix && worker.workerOrganizationSufix.sufixTx) {
      worker.organizationSuffixTx = worker.workerOrganizationSufix.sufixTx;
    }
    var primaryOrg = worker.organizationHistory.filter(
      (org: any) => org.primaryOrganizationIndicator == true
    )[0];
    worker.organization = primaryOrg
      ? primaryOrg.organization.businessAreaCode + '/' + primaryOrg.organization.shortName
      : 'Home Organization missing';

    this.fillData(
      worker.workerId.toString(),
      worker.familyName + ', ' + worker.preferredFirstName,
      '(Supervisor) ',
      worker.workerNumber,
      constants.reportingStatus.unAssigned,
      this.getPrimaryOrganization(worker.organizationHistory),
      worker.workerOrganizationSufix ? worker.workerOrganizationSufix.sufixTx : '',
      worker.workerNumber,
      constants.reportingStatus.unAssigned,
      constants.reportingStatus.unAssigned,
      '',
      constants.reportingStatus.unAssigned,
      worker.defaultReportingId,
      worker.timecardReportingId,
      worker.parReportingId,
      worker.emailAddress
    );

    this.reportserviceService
      .getWorkersRelationships(worker.workerId.toString(), getSubList)
      .subscribe((reports) => {
        this.processWorkerReportInfo(worker, reports);
        this.workerVM.showWait = false;
      });
  }
  processWorkerReportInfo(worker: any, data: []): void {
    worker.name = worker.familyName + ', ' + worker.preferredFirstName;
    worker.organization = this.getPrimaryOrganization(worker.organizationHistory);
    worker.defaultReporting = constants.reportingStatus.unAssigned;
    worker.timecardReporting = constants.reportingStatus.unAssigned;
    worker.parReporting = constants.reportingStatus.unAssigned;
    
    // Set the heading with worker information
    this.heading = worker.familyName + ', ' + worker.preferredFirstName;
    this.heading += '_' + worker.workerNumber;
    this.heading += '-' + worker.organization;
    
    // Process the worker report search information
    if (data && data.length > 0) {
      data.forEach((row: any) => {
        worker.workerOrganizationSufix = row.workerOrganizationSufix;
        if (row.relationshipSummary.value === constants.relationshipTypes.SUPERVISOR) {
          worker.defaultReportingId = row.workerRelationshipId;
          worker.defaultReportingWorkerId = row.relatedWorker.workerId;
          worker.defaultReportingWorkerNumber = row.relatedWorker.workerNumber;
          worker.defaultReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        } else if (row.relationshipSummary.value === constants.relationshipTypes.PAR) {
          worker.parReportingId = row.workerRelationshipId;
          worker.parReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        } else if (row.relationshipSummary.value === constants.relationshipTypes.TIMECARD) {
          worker.timecardReportingId = row.workerRelationshipId;
          worker.timecardReporting =
            row.relatedWorker.familyName + ', ' + row.relatedWorker.preferredFirstName;
        }
        if (!worker.defaultReporting) {
          worker.defaultReporting = constants.reportingStatus.unAssigned;
        }
        if (!worker.parReporting || worker.parReporting == constants.reportingStatus.unAssigned) {
          worker.parReporting = worker.defaultReporting;
        }
        if (
          !worker.timecardReporting ||
          worker.timecardReporting == constants.reportingStatus.unAssigned
        ) {
          worker.timecardReporting = worker.defaultReporting;
        }
      });
    }
    if (this.getSubList == false) {
      this.showWorkerData(worker);
    } else {
      this.getWorkerEmployeeList(worker.workerId, true);
    }
  }
  getWorkerEmployeeList(workerId: number, includeInactive: boolean) {
    includeInactive = false;
    this.reportserviceService
      .getSupervisorWorkersRelationshipsList(workerId, includeInactive, null, null)
      .subscribe((response) => {
        this.processEmployeeList(response.results, true);
      });
  }
  getPrimaryOrganizationDetails(organizationHistory: any[]): any {
    var primaryOrganization;
    organizationHistory.forEach(function (organization) {
      if (organization.primaryOrganizationIndicator) {
        primaryOrganization = organization;
      }
    });
    return primaryOrganization;
  }
  displayData(results: any[], type: string = 'd') {
    results?.forEach((report: any) => {
      let worker = type == 'd' ? report.baseWorker : report;
      this.fillData(
        worker.workerId,
        worker.familyName + ', ' + worker.preferredFirstName,
        '',
        worker.workerNumber,
        constants.reportingStatus.unAssigned,
        this.getPrimaryOrganization(worker.organizationHistory),
        worker.workerOrganizationSufix ? worker.workerOrganizationSufix.sufixTx : '',
        worker.workerNumber,
        constants.reportingStatus.unAssigned,
        constants.reportingStatus.unAssigned,
        '',
        constants.reportingStatus.unAssigned,
        worker.defaultReportingId,
        worker.timecardReportingId,
        worker.parReportingId
      );
      // this.data.push({
      //     id: worker.workerId,
      //     prefix: worker.workerOrganizationSufix ? worker.workerOrganizationSufix.prefixTx : '',
      //     name: worker.familyName + ' ' + worker.givenName,
      //     workerNumber: worker.workerNumber,
      //     organization: this.getPrimaryOrganization(worker.organizationHistory),
      //     defaultReporting: worker.defaultReporting ? worker.defaultReporting.value : 'N/A',
      // })
    });
    this.dataSource = new MatTableDataSource<IWorker>(this.data);
    this.workerVM.showWait = false;
  }
  getPrimaryOrganization(organizationHistory: any) {
    var acronym: string = '';
    for (var i = 0; i < organizationHistory?.length; i++) {
      const organization = organizationHistory[i];
      if (organization.primaryOrganizationIndicator) {
        acronym =
          organization.organization.businessAreaCode + '/' + organization.organization.shortName;
      }
    }
    return acronym;
  }

  startEdit(rowIndex: number, key: string) {
    const column = this.columns.find((c) => c.key === key);
    if (column && column.editable) {
      this.editingCell = { rowIndex, key };
    }
  }

  isEditing(rowIndex: number, key: string): boolean {
    return this.editingCell?.rowIndex === rowIndex && this.editingCell?.key === key;
  }

  saveEdit(rowIndex: number, key: string, event: any) {
    const value = event.target.value;
    this.data[rowIndex][key] = value;
    this.cellValueChanged.emit({ rowIndex, key, value });
    this.editingCell = null;
  }

  cancelEdit() {
    this.editingCell = null;
  }

  getManagersHistory(relatedWorkerId: number, limit: number = 10, skip: number = 0): void {
    this.workerVM.showPrimarySearch = false;
    this.workerVM.managersHistoryList = [];
    // Removed reference to undefined 'resetTimeout'
    this.workerVM.showWait = true;
    this.reportserviceService.getManagersHistory(relatedWorkerId, limit, skip).subscribe(
      (response: any) => {
        this.workerVM.managersHistoryList = response.results;
        this.workerVM.showWait = false;

        // Handle the response as needed
      },
      (error) => {      }
    );
  }

  /**
   * Handles sorting when user clicks on column sort icons
   * Toggles sort direction (asc/desc) and applies sorting to the table data
   * @param columnName - The name of the column to sort by ('name' or 'employeeNumber')
   */
  onSort(columnName: string): void {
    // Map column names to the internal sort column names used by sortRecords()
    let sortColumnKey = columnName;
    if (columnName === 'employeeNumber') {
      sortColumnKey = 'workerNumber1';
    } else if (columnName === 'name') {
      sortColumnKey = 'name';
    }

    // Toggle sort direction if clicking the same column, otherwise set to ascending
    if (this.workerVM.sortColumn === sortColumnKey) {
      this.workerVM.sortDirection = this.workerVM.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.workerVM.sortColumn = sortColumnKey;
      this.workerVM.sortDirection = 'asc';
    }

    // Apply sorting to the current table list
    if (this.workerVM.tableList && this.workerVM.tableList.length > 0) {
      this.sortRecords(this.workerVM.tableList);
      // Update the data source to reflect the sorted data
      this.dataSource = new MatTableDataSource<IWorker>(this.workerVM.tableList);
    }
  }

  /**
   * Exports the current table data to Excel format
   * Uses the same approach as application-reference component
   */
  exportDataCallback(): void {
    if (!this.dataSource.data || this.dataSource.data.length === 0) {      return;
    }

    // Build the export URL for the reporting data
    const url = `workers/speEmployeeExcelReport?includeInactive=false&workerNumber=${this.workerVM.workerNumber}`;
    
    // Call the utility service to export the data
    this.utilityService.exportTableService(
      url,
      'ReportingData.xls',
      'application/vnd.ms-excel'
    );
  }
}
