import { Component, Inject, OnChanges, OnInit, SimpleChange, SimpleChanges } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { constants } from 'src/app/components/reports-to/Models/MasterData';
import { ReportTolandingComponent } from '../../report-tolanding/report-tolanding.component';

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss'],
})
export class PopupComponent implements OnInit, OnChanges {
  worker: any;
  title: string = '';
  selecetedItem: string = '';
  newAssignment: string = '';
  reassignToUser: string = '';
  assignments: any = constants.reportingStatus;
  constructor(
    public dialogRef: MatDialogRef<PopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private reportserviceService: ReportserviceService
  ) {
    this.title = data.Title;
    this.selecetedItem = data.SelectedItem;
    this.worker = data.Row;
  }
  ngOnInit() {}
  ngOnChanges(changes: SimpleChanges) {}
  responseClick(action: string) {
    this.dialogRef.close({ confirmed: true, results: this.worker, actionType: action });
  }
  removeAssignment(data: any, worker: any) {
    //     vm.showSaveWait = false;
    //     vm.returnMessage = getDialogType(data.dialogDataType) + " reporting assignment removed for " +
    //         worker.familyName + ", " + worker.preferredFirstName + " - " + worker.workerNumber;
    //     vm.returnCode = 200;
    //     vm.hideMessage = false;
    //     hideMessageTimeoutFunc();
    //     $anchorScroll();
    //     vm.employeeList = [];
    //     vm.tableList = [];
    //     /**
    //      * reassigning the par/timecard value same as default for parent data in the table
    //      *  */
    //     if (data.reportType && data.reportType.value == 'PAR') {
    //         worker.parReporting = worker.defaultReporting;
    //     }
    //     if (data.reportType && data.reportType.value == 'TIMECARD') {
    //         worker.timecardReporting = worker.defaultReporting;
    //     }
    //     refreshChildData();
    //     vm.usersToAssign = [];
    // }, function (response) {
    //     vm.showSaveWait = false;
    //     vm.returnCode = response.status;
    //     vm.hideMessage = false;
    //     hideMessageTimeoutFunc();
    //     vm.returnMessage = AuthorizationService.processFailureMessage(response, "Failed to remove assignment");
    // });
  }

  searchWorker(): void {
    this.reassignToUser = '';
    this.reportserviceService
      .getDataContent(
        '/workers?includeInactive=false&flag=true&familyName=' +
          this.newAssignment.toUpperCase() +
          '&limit=100000&skip=0&sortColumn=familyName1&sortOrder=asc'
      )
      .subscribe((response: any) => {
        this.worker = response.results[0];
        this.reassignToUser = this.worker.familyName + ',' + this.worker.givenName;
        // reassignToUser:string='';
      });
  }
}
