import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { HistoryManagementmodalComponent } from '../history-managementmodal/history-managementmodal.component';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { Sort } from '@angular/material/sort';
import { getDifferenceInDays } from '../../reports-to/reportToUtil';
@Component({
  selector: 'app-historyofmanagement',
  templateUrl: './historyofmanagement.component.html',
  styleUrls: ['./historyofmanagement.component.scss'],
})
export class HistoryofmanagementComponent implements OnInit {
  reportService: ReportserviceService;
  dataSource: any = { results: [] };
  columnDefinitions: [] = [];
  displayedColumns: string[] = [
    'workerName',
    'organization',
    'organizationSuffix',
    'employee',
    'defaultReporting',
    'startDateindex',
    'startDate',
    'endDate',
  ];
  constructor(
    public dialog: MatDialog,
    reportService: ReportserviceService
  ) {
    this.reportService = reportService;
  }
  onSortChange(event: any) {}
  onPageChange(event: any) {}
  ngOnInit(): void {
    this.openWelcomeModal();
  }

  openWelcomeModal() {
    let dailogPopup = this.dialog.open(HistoryManagementmodalComponent, {
      data: { Title: 'History of Management' },
      width: '60%',
      height: '60%',
      disableClose: true, // Prevent closing by clicking outside or pressing Escape
    });
    dailogPopup.afterClosed().subscribe((response) => {
      this.loadHistoryManagement(response?.results?.id);
    });
  }
  loadHistoryManagement(id: number) {
    let url: string =
      '/manager-history/' + id + '?isContractor=false&limit=100&notRelated=true&skip=0';
    this.reportService.getDataContent(url).subscribe((response: any) => {
      let results: any[] = [];
      for (let i = 0; i < response.results.length; i++) {
        let worker = response.results[i];
        results.push({
          workerName: worker.baseWorker.familyName + ', ' + worker.baseWorker.preferredFirstName,
          organization: worker.orgCode,
          organizationSuffix: worker.orgSuffix,
          employee: worker.baseWorker.workerNumber,
          defaultReporting:
            worker.relatedWorker.familyName +
            ',' +
            worker.relatedWorker.preferredFirstName +
            '(' +
            worker.relatedWorker.workerNumber +
            ')',
          startDateindex: false,
          startDate: worker.lifecycle.beginDate,
          endDate:
            worker.lifecycle.endDate != null
              ? worker.lifecycle.endDate
              : worker.lifecycle && worker.lifecycle.endDate == null
                ? 'Current'
                : worker.lifecycle.endDate,
        });
      }
      if (results.length >= 3) {
        var lastRecord1 = results[1];
        var secondToLastRecord1 = results[0];
        var endDateLastRecord1 = lastRecord1.endDate;
        var startDateSecondToLastRecord1 = secondToLastRecord1.beginDate;
        if (startDateSecondToLastRecord1 !== endDateLastRecord1) {
          results[0].startDateindex = true;
        } else {
        }
        for (var i = results.length - 1; i > 0; i--) {
          var lastRecord = results[i];
          var secondToLastRecord = results[i - 1];
          if (lastRecord != undefined && lastRecord.endDate != undefined) {
            var endDateLastRecord = lastRecord.endDate;
            var startDateSecondToLastRecord = secondToLastRecord.beginDate;
            if (getDifferenceInDays(startDateSecondToLastRecord, endDateLastRecord) > 2) {
              results[i - 1].startDateindex = true;
            }
          }
        }
      }
      this.dataSource = {
        results: results,
        total: response.meta.total,
        limit: response.meta.limit,
      };
    });
  }
}
