import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SubclassGAUandSearchRoomAssignmentService } from '../services/subclass-gau-assignment.service';

@Component({
  selector: 'app-update-dates-wizard',
  templateUrl: './update-dates-wizard.component.html',
  styleUrls: ['./update-dates-wizard.component.scss'],
})
export class UpdateDatesWizardComponent implements OnInit {
  dateForm!: FormGroup;
  invalidSearchRoomStartDate = false;
  invalidGAUStartDate = false;
  searchRoomStartDateMessage = '';
  gauStartDateMessage = '';
  selectedItems: any[] = [];
  hasGAU = false;
  hasSearchRoom = false;

  constructor(
    public dialogRef: MatDialogRef<UpdateDatesWizardComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private subclassGAUService: SubclassGAUandSearchRoomAssignmentService
  ) {}

  ngOnInit(): void {
    console.log('UpdateDatesWizardComponent ngOnInit called');
    this.initializeForm();
    this.analyzeSelectedItems();
    this.populateDateFields();
  }

  /**
   * Initialize the form with date controls
   */
  private initializeForm(): void {
    this.dateForm = this.fb.group({
      searchRoomStartDate: [''],
      gauStartDate: [''],
    });
  }

  /**
   * Analyze selected items to determine which dates are needed
   */
  private analyzeSelectedItems(): void {
    console.log('analyzeSelectedItems called');
    console.log('data:', this.data);
    
    if (this.data && this.data.content && Array.isArray(this.data.content)) {
      this.selectedItems = this.data.content;
      console.log('selectedItems:', this.selectedItems);

      // Check if any selected item has GAU
      this.hasGAU = this.selectedItems.some(
        (item) => item.activeGAU && item.activeGAU.length > 0
      );

      // Check if any selected item has Search Room
      this.hasSearchRoom = this.selectedItems.some(
        (item) => item.activeSearchRoom && item.activeSearchRoom.length > 0
      );
      
      console.log('hasGAU:', this.hasGAU);
      console.log('hasSearchRoom:', this.hasSearchRoom);
    } else {
      console.log('No data or content provided');
    }
  }

  /**
   * Populate date fields from selected items
   */
  private populateDateFields(): void {
    console.log('populateDateFields called');
    console.log('selectedItems:', this.selectedItems);
    
    if (this.selectedItems && this.selectedItems.length > 0) {
      const firstItem = this.selectedItems[0];
      console.log('firstItem:', firstItem);

      // Extract GAU start date if available
      if (this.hasGAU && firstItem.activeGAU && firstItem.activeGAU.length > 0) {
        const gauDate = firstItem.activeGAU[0].lifecycle?.beginDate;
        console.log('gauDate:', gauDate);
        if (gauDate) {
          const formattedGAUDate = this.formatDateForInput(gauDate);
          console.log('formattedGAUDate:', formattedGAUDate);
          this.dateForm.patchValue({ gauStartDate: formattedGAUDate });
        }
      }

      // Extract Search Room start date if available
      if (this.hasSearchRoom && firstItem.activeSearchRoom && firstItem.activeSearchRoom.length > 0) {
        const searchRoomDate = firstItem.activeSearchRoom[0].lifecycle?.beginDate;
        console.log('searchRoomDate:', searchRoomDate);
        if (searchRoomDate) {
          const formattedSearchRoomDate = this.formatDateForInput(searchRoomDate);
          console.log('formattedSearchRoomDate:', formattedSearchRoomDate);
          this.dateForm.patchValue({ searchRoomStartDate: formattedSearchRoomDate });
        }
      }
    } else {
      console.log('No selected items to populate');
    }
  }

  /**
   * Format date string to YYYY-MM-DD format for HTML date input
   */
  private formatDateForInput(dateString: string): string {
    try {
      // Handle ISO format (e.g., "2026-06-24T00:00:00.000Z")
      const date = new Date(dateString);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    } catch (error) {
      console.error('Error formatting date:', error);
      return '';
    }
  }

  /**
   * Handle date change for search room start date
   */
  onSearchRoomDateChange(event: any): void {
    this.invalidSearchRoomStartDate = false;
    this.searchRoomStartDateMessage = '';
  }

  /**
   * Handle date change for GAU start date
   */
  onGAUDateChange(event: any): void {
    this.invalidGAUStartDate = false;
    this.gauStartDateMessage = '';
  }

  /**
   * Validate and update dates
   */
  updateDateHandler(): void {
    console.log('updateDateHandler called');
    console.log('hasSearchRoom:', this.hasSearchRoom);
    console.log('hasGAU:', this.hasGAU);
    
    // Reset validation flags
    this.invalidSearchRoomStartDate = false;
    this.invalidGAUStartDate = false;
    this.searchRoomStartDateMessage = '';
    this.gauStartDateMessage = '';

    const searchRoomDate = this.dateForm.get('searchRoomStartDate')?.value;
    const gauDate = this.dateForm.get('gauStartDate')?.value;

    console.log('searchRoomDate:', searchRoomDate);
    console.log('gauDate:', gauDate);

    // Validate that at least one date is provided
    if (!searchRoomDate && !gauDate) {
      console.log('No dates provided - validation failed');
      if (this.hasSearchRoom) {
        this.invalidSearchRoomStartDate = true;
        this.searchRoomStartDateMessage = 'Search room start date is required';
      }
      if (this.hasGAU) {
        this.invalidGAUStartDate = true;
        this.gauStartDateMessage = 'GAU start date is required';
      }
      return;
    }

    // Validate search room date if GAU is selected
    if (this.hasSearchRoom && !searchRoomDate) {
      console.log('Search room date required but not provided');
      this.invalidSearchRoomStartDate = true;
      this.searchRoomStartDateMessage = 'Search room start date is required';
      return;
    }

    // Validate GAU date if GAU is selected
    if (this.hasGAU && !gauDate) {
      console.log('GAU date required but not provided');
      this.invalidGAUStartDate = true;
      this.gauStartDateMessage = 'GAU start date is required';
      return;
    }

    // All validation passed, close dialog with data
    const result = {
      content: {
        updatedSearchRoomStartDate: searchRoomDate,
        updatedGauStartDate: gauDate,
      },
    };

    console.log('Validation passed - closing dialog with result:', result);
    this.dialogRef.close(result);
  }

  /**
   * Cancel and close dialog
   */
  cancel(): void {
    this.dialogRef.close();
  }

  /**
   * Check if the update button should be disabled
   */
  isUpdateDisabled(): boolean {
    const searchRoomDate = this.dateForm.get('searchRoomStartDate')?.value;
    const gauDate = this.dateForm.get('gauStartDate')?.value;
    return !searchRoomDate && !gauDate;
  }
}
