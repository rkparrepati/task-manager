import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnDestroy,
  SimpleChanges,
  OnChanges,
  HostListener,
  ChangeDetectorRef,
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface ArtSubclassAssignment {
  artSubclassNo: string;
  selected?: boolean;
  activeGAU?: Array<{
    orgArtSubclassId: string;
    organization: {
      businessAreaCode: string;
      shortName: string;
    };
    lifecycle: {
      beginDate: string;
    };
  }>;
  activeSearchRoom?: Array<{
    searchRoomArtSubclassId: string;
    searchRoom: {
      building: {
        name: string;
        floorNumber: string;
      };
      corridorId: string;
      roomId: string;
      suiteId: string;
      zoneId: string;
    };
    lifecycle: {
      beginDate: string;
    };
  }>;
}

@Component({
  selector: 'app-subclass-gau-search-results',
  templateUrl: './subclass-gau-search-results.component.html',
  styleUrls: ['./subclass-gau-search-results.component.scss'],
})
export class SubclassGauSearchResultsComponent implements OnInit, OnDestroy, OnChanges {
  @Input() assignments: any[] = [];
  @Input() searchResultsCount: string = '';
  @Input() userRoles: string[] = [];
  @Input() selectedAll: boolean = false;
  @Input() selectAllDisabled: boolean = false;
  @Input() disabledButtons: boolean = false;
  @Input() selectedItems: number = 0;
  @Input() selectText: string = 'Select All';
  @Input() total: number = 0;
  @Input() limit: number = 100;
  @Input() selectOptions: any[] = [];
  @Input() pageSizeOptions: any[] = [];
  @Input() resultsFound: boolean = false;

  @Output() checkAll = new EventEmitter<void>();
  @Output() checked = new EventEmitter<void>();
  @Output() toggleSelected = new EventEmitter<void>();
  @Output() dissociateSearchRoom = new EventEmitter<void>();
  @Output() dissociateBoth = new EventEmitter<void>();
  @Output() changeDates = new EventEmitter<void>();
  @Output() dissociateGAU = new EventEmitter<void>();
  @Output() exportData = new EventEmitter<void>();
  @Output() updateFn = new EventEmitter<any>();
  @Output() pageSizeChanged = new EventEmitter<number>();
  @Output() pageChanged = new EventEmitter<number>();

  dropdownOpen: boolean = false;
  dropdownOpenTop: boolean = false;
  dropdownOpenBottom: boolean = false;
  private destroy$ = new Subject<void>();

  constructor(private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {
    console.log('ngOnChanges triggered in SubclassGauSearchResultsComponent', changes);
    // Ensure arrays are properly initialized
    if (this.assignments && this.assignments.length > 0) {
      console.log('Assignments updated. Length:', this.assignments.length);
      this.assignments.forEach((assignment: any) => {
        // Keep as arrays - do not convert to single objects
        assignment.activeGAU = assignment.activeGAU || [];
        assignment.activeSearchRoom = assignment.activeSearchRoom || [];
      });
      this.cdr.markForCheck();
      this.cdr.detectChanges();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onCheckAll(): void {
    this.checkAll.emit();
    for (let assignment of this.assignments) {
      assignment.selected = !this.selectedAll;
    }
  }

  onChecked(): void {
    this.checked.emit();
  }

  onToggleSelected(): void {
    this.toggleSelected.emit();
    for (let assignment of this.assignments) {
      assignment.selected = !this.selectedAll;
    }
  }

  onDissociateSearchRoom(): void {
    this.dropdownOpenTop = false;
    this.dropdownOpenBottom = false;
    this.dissociateSearchRoom.emit();
  }

  onDissociateBoth(): void {
    this.dropdownOpenTop = false;
    this.dropdownOpenBottom = false;
    this.dissociateBoth.emit();
  }

  onChangeDates(): void {
    this.dropdownOpenTop = false;
    this.dropdownOpenBottom = false;
    this.changeDates.emit();
  }

  onDissociateGAU(): void {
    this.dropdownOpenTop = false;
    this.dropdownOpenBottom = false;
    this.dissociateGAU.emit();
  }

  onExportData(): void {
    this.exportData.emit();
  }

  onUpdateFn(event: any): void {
    this.updateFn.emit(event);
  }

  toggleDropdown(position: 'top' | 'bottom' = 'top'): void {
    if (position === 'top') {
      this.dropdownOpenTop = !this.dropdownOpenTop;
      this.dropdownOpenBottom = false;
    } else {
      this.dropdownOpenBottom = !this.dropdownOpenBottom;
      this.dropdownOpenTop = false;
    }
  }

  onPageSizeChanged(pageSize: number): void {
    this.pageSizeChanged.emit(pageSize);
  }

  onPageChanged(currentPage: number): void {
    this.pageChanged.emit(currentPage);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    const clickedInside = target.closest('.infra-dropdown-menu');
    
    if (!clickedInside) {
      this.dropdownOpenTop = false;
      this.dropdownOpenBottom = false;
    }
  }
}
 
