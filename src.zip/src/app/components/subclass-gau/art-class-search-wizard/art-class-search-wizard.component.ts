import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TransferSearchService } from 'src/app/components/transfer-search/transfer-search.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface ArtClass {
  artClassNo: string;
  titleText: string;
  lifecycle: {
    beginDate: string;
    endDate: string;
  };
  subjectMatterCD: string;
}

interface DialogInfo {
  title: string;
  titleType: string;
  primaryButtonTypeSearch: string;
  primaryButtonSearch: string;
  clearButton: boolean;
  cancelButton: boolean;
  content?: string;
}

interface ArtClassResponse {
  results: ArtClass[];
  meta: {
    total: number;
  };
}

@Component({
  selector: 'app-art-class-search-wizard',
  templateUrl: './art-class-search-wizard.component.html',
  styleUrls: ['./art-class-search-wizard.component.scss'],
})
export class ArtClassSearchWizardComponent implements OnInit, OnDestroy {
  @Input() dialogInfo: DialogInfo = {
    title: 'Art Class Search',
    titleType: 'title-default',
    primaryButtonTypeSearch: 'primary',
    primaryButtonSearch: 'Search',
    clearButton: true,
    cancelButton: true,
  };

  @Output() confirm = new EventEmitter<ArtClass>();
  @Output() cancel = new EventEmitter<string>();

  artClassNoWizard: string = '';
  showArtClassMessage: boolean = false;
  artClassResults: boolean = false;
  returnMessage: string = '';
  total: number = 0;
  artClassModel: { artClass: ArtClass[] } = { artClass: [] };

  private destroy$ = new Subject<void>();

  constructor(
    private transferSearchService: TransferSearchService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    if (data && data.dialogInfo) {
      this.dialogInfo = data.dialogInfo;
    }
  }

  ngOnInit(): void {
    this.initializeArtClassNo();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize art class number from dialog info content
   */
  private initializeArtClassNo(): void {
    if (this.dialogInfo?.content) {
      this.artClassNoWizard = this.dialogInfo.content;
    }
  }

  /**
   * Clear all form fields and results
   */
  clear(): void {
    this.artClassNoWizard = '';
    this.artClassModel = { artClass: [] };
    this.artClassResults = false;
    this.showArtClassMessage = false;
    this.returnMessage = '';
    this.total = 0;
  }

  /**
   * Handle Enter key press in input field
   */
  enterKey(event: KeyboardEvent): void {
    if (this.artClassNoWizard && event.keyCode === 13) {
      this.populateArtClassInformation();
    }
  }

  /**
   * Fetch art class information from service
   */
  populateArtClassInformation(): void {
    if (!this.artClassNoWizard) {
      return;
    }

    this.transferSearchService
      .getArtClassInformation(this.artClassNoWizard)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          const artClassResponse = response as ArtClassResponse;
          this.artClassModel = {
            artClass: artClassResponse.results,
          };
          this.total = artClassResponse.meta.total;
          this.artClassResults = true;
          this.showArtClassMessage = false;
        },
        error: () => {
          this.total = 0;
          this.artClassModel = { artClass: [] };
          this.artClassResults = false;
          this.returnMessage = 'Art Class not found';
          this.showArtClassMessage = true;
        },
      });
  }

  /**
   * Hide the error/warning message
   */
  hideArtClassMessage(): void {
    this.showArtClassMessage = false;
  }

  /**
   * Handle row selection
   */
  selectArtClass(artClass: ArtClass): void {
    this.confirm.emit(artClass);
  }

  /**
   * Handle cancel action
   */
  closeDialog(): void {
    this.cancel.emit('Select location is cancelled.');
  }
}
