import { Injectable } from '@angular/core';
import { UtilityService } from '../../../services/utility.service';

interface SearchOptions {
  artClassNo: string;
  beginSubclass: string;
  endSubclass: string;
  businessAreaCode: string;
  shortName: string;
}

@Injectable({
  providedIn: 'root',
})
export class SubclassGAUandSearchRoomControllerHelper {
  constructor(private utilityService: UtilityService) {}

  /**
   * Build the search room request
   */
  getSearchRoomRequest(artSubclassId: string, locationId: string): any {
    const today = new Date().toISOString();
    const adjustedDate = this.utilityService.adjustDateFormatter(today);

    return {
      artSubClass: {
        artSubclassId: artSubclassId,
      },
      searchRoom: {
        locationId: locationId,
      },
      lifecycle: {
        beginDate: adjustedDate,
      },
    };
  }

  /**
   * Build export URL for subclass GAU search results
   */
  buildExportURL(currentSearchOptions: SearchOptions): string {
    let url = '/art-subclasses/excelReport?';

    if (currentSearchOptions.artClassNo) {
      url += 'artClassNo=' + currentSearchOptions.artClassNo;
    }
    if (currentSearchOptions.beginSubclass) {
      url += '&beginSubclass=' + currentSearchOptions.beginSubclass;
    }
    if (currentSearchOptions.endSubclass) {
      url += '&endSubclass=' + currentSearchOptions.endSubclass;
    }
    if (currentSearchOptions.businessAreaCode) {
      url += '&businessAreaCode=' + currentSearchOptions.businessAreaCode;
    }
    if (currentSearchOptions.shortName) {
      url += '&shortName=' + currentSearchOptions.shortName;
    }

    url += '&limit=1000';
    url += '&includeInactive=true';

    return url;
  }
}
