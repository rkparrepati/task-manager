import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { UtilityService } from '../../../services/utility.service';
import { HttpService } from '../../../services/http.service';

export interface LocationSearchData {
  locationPurposeId?: string | null;
  includeInactive?: boolean;
  buildingCode?: string | null;
  floorPrefix?: string;
  corridorPrefix?: string | null;
  suitePrefix?: string | null;
  roomPrefix?: string | null;
  zonePrefix?: string | null;
  startDate?: string | null;
  endDate?: string | null;
  mailStopIndicator?: boolean;
  limit?: number | null;
  skip?: number | null;
}

export interface LocationDetail {
  lifecycle: {
    beginDate: string | null;
    endDate: string | null;
  };
  corridorId?: string | null;
  suiteId?: string | null;
  roomId?: string | null;
  zoneId?: string | null;
  building: any;
  locationPurpose: any;
  mailStopIndicator: boolean;
  audit?: {
    lockControlNumber: string;
  };
}

export interface BuildingInfo {
  audit: {
    lockControlNumber: string;
  };
  [key: string]: any;
}

@Injectable({
  providedIn: 'root',
})
export class LocationService {
  constructor(
    private http: HttpService,
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  /**
   * This method makes restful service call and gets list of locations.
   * This method returns http get observable to component.
   */
  getLocations(
    formData: any,
    limit?: number,
    skip?: number,
    paramIncludeInactive?: boolean
  ): Observable<any> {
    const locationSearchData = this.getLocationSearchData(
      formData,
      limit,
      skip,
      paramIncludeInactive
    );

    const startDateSearch = this.utilityService.dateFormatterEndDate(
      new Date(formData.startDateSearch)
    );
    if (formData.startDateSearch) {
      const adjustedDate = this.utilityService.adjustEndDateFormatter(startDateSearch);
      if (adjustedDate) {
        locationSearchData.startDate = adjustedDate.substring(0, 10);
      } else {
        locationSearchData.startDate = null;
      }
    } else {
      locationSearchData.startDate = null;
    }

    const endDateSearch = this.utilityService.dateFormatterEndDate(
      new Date(formData.endDateSearch)
    );
    if (formData.endDateSearch) {
      const adjustedDate = this.utilityService.adjustEndDateFormatter(endDateSearch);
      if (adjustedDate) {
        locationSearchData.endDate = adjustedDate.substring(0, 10);
      } else {
        locationSearchData.endDate = null;
      }
    } else {
      locationSearchData.endDate = null;
    }

    locationSearchData.mailStopIndicator = formData.mailStopIndicator;

    if (limit) {
      locationSearchData.limit = limit;
    } else {
      locationSearchData.limit = null;
    }

    if (skip) {
      locationSearchData.skip = skip;
    } else {
      locationSearchData.skip = null;
    }

    const params = this.buildHttpParams(locationSearchData);
    return this.httpService.getData('/locations', params).pipe(
      map((successResponse: any) => successResponse.data),
      catchError((failureResponse: any) => throwError(() => failureResponse))
    );
  }

  /**
   * Helper method to build location search data
   */
  private getLocationSearchData(
    formData: any,
    limit?: number,
    skip?: number,
    paramIncludeInactive?: boolean
  ): LocationSearchData {
    const locationSearchData: LocationSearchData = {};

    if (formData.purposeSearch) {
      locationSearchData.locationPurposeId = formData.purposeSearch.id;
    } else {
      locationSearchData.locationPurposeId = null;
    }

    if (paramIncludeInactive) {
      locationSearchData.includeInactive = paramIncludeInactive;
    } else {
      locationSearchData.includeInactive = formData.showAllSearch === 'Y';
    }

    if (formData.buildingCodeSearch) {
      locationSearchData.buildingCode = formData.buildingCodeSearch;
    } else {
      locationSearchData.buildingCode = null;
    }

    if (formData.floorSearch) {
      locationSearchData.floorPrefix = formData.floorSearch;
    } else {
      locationSearchData.floorPrefix = '';
    }

    if (formData.corridorSearch) {
      locationSearchData.corridorPrefix = formData.corridorSearch;
    } else {
      locationSearchData.corridorPrefix = null;
    }

    if (formData.suiteSearch) {
      locationSearchData.suitePrefix = formData.suiteSearch;
    } else {
      locationSearchData.suitePrefix = null;
    }

    if (formData.roomSearch) {
      locationSearchData.roomPrefix = formData.roomSearch;
    } else {
      locationSearchData.roomPrefix = null;
    }

    if (formData.zoneSearch) {
      locationSearchData.zonePrefix = formData.zoneSearch;
    } else {
      locationSearchData.zonePrefix = null;
    }

    return locationSearchData;
  }

  /**
   * This method gets location details
   */
  getLocation(locationId: string): Observable<any> {
    return this.httpService.get(`/locations/${locationId}`).pipe(
      map((response: any) => response.data),
      catchError((response: any) => throwError(() => response)),
      catchError(() => of([]))
    );
  }

  /**
   * This method makes restful service call and gets list of purposes.
   * This method returns http get observable to component.
   */
  getPurposes(): Observable<any> {
    return this.httpService.get('/references/location-purposes').pipe(
      map((response: any) => response.data || response),
      catchError((failureResponse: any) => throwError(() => failureResponse))
    );
  }

  /**
   * This method makes restful service call and gets list of floors for
   * selected building. This method returns http get observable to component.
   */
  getBuildingFloors(buildingCode: string): Observable<any> {
    const url = `/buildings/${buildingCode}`;
    return this.httpService.get(url).pipe(
      map((response: any) => response),
      catchError((failureResponse: any) => throwError(() => failureResponse))
    );
  }

  /**
   * This method makes restful service call and updates a location. This
   * method returns response observable from http put.
   */
  updateLocation(location: any): Observable<any> {
    const locationDetail = this.getLocationDetailForUpdate(location);
    return this.httpService.put(`/locations/${location.locationId}`, locationDetail).pipe(
      map((response: any) => response),
      catchError((response: any) => throwError(() => response))
    );
  }

  /**
   * This method is to get location detail for update
   */
  private getLocationDetailForUpdate(location: any): LocationDetail {
    // check for empty lifecycle
    if (!location.lifecycle) {
      location.lifecycle = { beginDate: null, endDate: null };
    } else {
      // begin date
      if (!location.lifecycle.beginDate) {
        location.lifecycle.beginDate = null;
      }
    }

    // corridor input
    if (!location.corridorId) {
      location.corridorId = null;
    }

    // suite input
    if (!location.suiteId) {
      location.suiteId = null;
    }

    // room input
    if (!location.roomId) {
      location.roomId = null;
    }

    // zone input
    if (!location.zoneId) {
      location.zoneId = null;
    }

    const locationDetail: LocationDetail = {
      lifecycle: {
        beginDate: location.lifecycle.beginDate ? location.lifecycle.beginDate : null,
        endDate: null,
      },
      corridorId: location.corridorId,
      suiteId: location.suiteId,
      roomId: location.roomId,
      zoneId: location.zoneId,
      building: location.building,
      locationPurpose: location.locationPurpose,
      mailStopIndicator: location.mailStopIndicator,
      audit: {
        lockControlNumber: location.audit.lockControlNumber,
      },
    };

    return locationDetail;
  }

  /**
   * This method makes restful service call to add a new location. This
   * method returns response observable from http post.
   */
  addLocation(location: any): Observable<any> {
    // check for empty audiInformation
    // begin date
    if (!location.lifecycle.beginDate) {
      location.lifecycle.beginDate = null;
    }

    // end date
    location.lifecycle.endDate = null;

    // check mailStopIndicator
    if (!location.mailStopIndicator) {
      location.mailStopIndicator = false;
    }

    // check for empty string input '' then set to null
    // corridor input
    if (!location.corridorId) {
      location.corridorId = null;
    }

    // suite input
    if (!location.suiteId) {
      location.suiteId = null;
    }

    // room input
    if (!location.roomId) {
      location.roomId = null;
    }

    // zone input
    if (!location.zoneId) {
      location.zoneId = null;
    }

    const locationDetail: LocationDetail = {
      lifecycle: {
        beginDate: this.utilityService.getTimeNow(),
        endDate: location.lifecycle.endDate,
      },
      locationPurpose: location.locationPurpose,
      mailStopIndicator: location.mailStopIndicator,
      building: location.building,
      corridorId: location.corridorId,
      suiteId: location.suiteId,
      roomId: location.roomId,
      zoneId: location.zoneId,
    };

    return this.httpService.post('/locations', locationDetail).pipe(
      map((response: any) => response),
      catchError((response: any) => throwError(() => response))
    );
  }

  /**
   * This method is to update a floor from floor list
   */
  updateFloor(buildingInfo: BuildingInfo, buildingId: string): Observable<any> {
    return this.httpService.put(`/buildings/${buildingId}`, buildingInfo).pipe(
      map((response: any) => response),
      catchError((response: any) => throwError(() => response))
    );
  }

  /**
   * This method is to add floor to floor list
   */
  addFloor(buildingInfo: BuildingInfo, buildingId: string): Observable<any> {
    return this.httpService.put(`/buildings/${buildingId}`, buildingInfo).pipe(
      map((response: any) => response),
      catchError((response: any) => throwError(() => response))
    );
  }

  /**
   * Process add floor response
   */
  private processAddFloor(
    response: any,
    action: string,
    actionResult: string,
    actionCode: number
  ): any {
    if (action === 'AddFloor' && actionResult === 'OK' && actionCode === 200) {
      return response.data.AddFloor200OK;
    }

    if (action === 'AddFloor' && actionResult !== 'OK' && actionCode !== 200) {
      return response.data.AddFloor400FAIL;
    }

    return null;
  }

  /**
   * Process update floor response
   */
  private processUpdateFloor(
    response: any,
    action: string,
    actionResult: string,
    actionCode: number
  ): any {
    if (action === 'UpdateFloor' && actionResult === 'OK' && actionCode === 200) {
      return response.data.UpdateFloor200OK;
    }

    if (action === 'UpdateFloor' && actionResult !== 'OK' && actionCode !== 200) {
      return response.data.UpdateFloor400FAIL;
    }

    return null;
  }

  /**
   * Process add location response
   */
  private processAddLocation(
    response: any,
    action: string,
    actionResult: string,
    actionCode: number
  ): any {
    if (action === 'AddLocation' && actionResult === 'Created' && actionCode === 201) {
      return response.data.AddLocation201CREATED;
    }

    if (action === 'AddLocation' && actionResult !== 'Created' && actionCode !== 201) {
      return response.data.AddLocation400FAIL;
    }

    return null;
  }

  /**
   * Process update location response
   */
  private processUpdateLocation(
    response: any,
    action: string,
    actionResult: string,
    actionCode: number
  ): any {
    if (action === 'UpdateLocation' && actionResult === 'OK' && actionCode === 200) {
      return response.data.UpdateLocation200OK;
    }

    if (action === 'UpdateLocation' && actionResult !== 'OK' && actionCode !== 200) {
      return response.data.UpdateLocation400FAIL;
    }

    return null;
  }

  /**
   * This method connects to the properties file to get corresponding
   * success or error message.
   */
  getMessage(action: string, actionResult: string, actionCode: number): Observable<any> {
    return this.http.get('/assets/messages.properties').pipe(
      map((response: any) => {
        const addFloorResponse = this.processAddFloor(response, action, actionResult, actionCode);
        const updateFloorResponse = this.processUpdateFloor(
          response,
          action,
          actionResult,
          actionCode
        );
        const addLocationResponse = this.processAddLocation(
          response,
          action,
          actionResult,
          actionCode
        );
        const updateLocationResponse = this.processUpdateLocation(
          response,
          action,
          actionResult,
          actionCode
        );

        const successResponse = this.getSuccessResponse(
          addFloorResponse,
          updateFloorResponse,
          addLocationResponse,
          updateLocationResponse
        );

        if (successResponse) {
          return successResponse;
        }

        const failMessage = this.getFailMessage(response, actionCode);
        if (failMessage) {
          return failMessage;
        }

        return 'Could not find Message';
      }),
      catchError(() => {
        return throwError(() => new Error('Failed while getting success/error message'));
      })
    );
  }

  /**
   * Get success response from various response types
   */
  private getSuccessResponse(
    addFloorResponse: any,
    updateFloorResponse: any,
    addLocationResponse: any,
    updateLocationResponse: any
  ): any {
    if (addFloorResponse) {
      return addFloorResponse;
    }

    if (updateFloorResponse) {
      return updateFloorResponse;
    }

    if (addLocationResponse) {
      return addLocationResponse;
    }

    if (updateLocationResponse) {
      return updateLocationResponse;
    }

    return null;
  }

  /**
   * Get fail message based on action code
   */
  private getFailMessage(response: any, actionCode: number): any {
    if (actionCode === 500) {
      return response.data.Internal500ERROR;
    }

    if (actionCode === 400) {
      return response.data.BadRequest400ERROR;
    }

    if (actionCode === 404) {
      return response.data.NotFound404ERROR;
    }

    return undefined;
  }

  /**
   * Get associated workers for a location
   */
  getAssociatedWorkers(locationId: string): Observable<any> {
    const params = new HttpParams().set('locationId', locationId);
    return this.httpService.getData('/workers', params).pipe(
      map((response: any) => response.data.results),
      catchError((response: any) => throwError(() => new Error(response.data.message)))
    );
  }

  /**
   * Get active building floor
   */
  getActiveBuildingFloor(buildingId: string): Observable<any> {
    return this.httpService.get(`/buildings/${buildingId}`).pipe(
      map((response: any) => {
        if (response.data.lifecycle.endDate) {
          throw response;
        }
        return response.data;
      }),
      catchError((response: any) => throwError(() => new Error(response.data.message)))
    );
  }

  /**
   * Get exact location match from results
   */
  getExactLocation(formData: any, locationResults: any[]): any {
    let locationMatch = null;

    locationResults.forEach((aLocation: any) => {
      const locationResult = {
        buildingCodeSearch: aLocation.building.code,
        corridorSearch: aLocation.corridorId,
        roomSearch: aLocation.roomId,
        floorSearch: aLocation.building.floorNumber,
        suiteSearch: aLocation.suiteId,
        zoneSearch: aLocation.zoneId,
      };

      const locationFormData = {
        buildingCodeSearch: formData.buildingCodeSearch,
        corridorSearch: formData.corridorSearch,
        roomSearch: formData.roomSearch,
        floorSearch: formData.floorSearch,
        suiteSearch: formData.suiteSearch,
        zoneSearch: formData.zoneSearch,
      };

      if (JSON.stringify(locationResult) === JSON.stringify(locationFormData)) {
        locationMatch = aLocation;
      }
    });

    return locationMatch;
  }

  /**
   * This method gets location purpose details
   */
  getLocationPurpose(purposeDescription: string): Observable<any> {
    const params = new HttpParams().set('description', purposeDescription);
    return this.httpService.getData('/references/location-purposes', params).pipe(
      map((response: any) => response.data),
      catchError((response: any) => throwError(() => new Error(response.data.message)))
    );
  }

  /**
   * This method executes locations mass upload
   */
  executeLocationMassUpload(validRows: any[]): Observable<any> {
    const executeList: any[] = [];

    validRows.forEach((validLocation: any) => {
      const executeLocation = {
        corridorId: validLocation.location.corridor || null,
        roomId: validLocation.location.room || null,
        suiteId: validLocation.location.suite || null,
        zoneId: validLocation.location.zone || null,
        mailStopIndicator: false,
        building: {
          code: validLocation.location.building,
          floorNumber: validLocation.location.floor,
        },
        locationPurpose: {
          id: validLocation.locationPurpose.id,
        },
        lifecycle: {
          beginDate: this.utilityService.adjustDateFormatter(
            this.utilityService.dateFormatter(new Date(validLocation.location.startDate))
          ),
        },
      };
      executeList.push(executeLocation);
    });

    return this.httpService.post('/locations/execute', executeList).pipe(
      map((response: any) => response.status),
      catchError((response: any) => throwError(() => new Error(response.data.message)))
    );
  }

  /**
   * Helper method to build HttpParams from object
   */
  private buildHttpParams(params: any): HttpParams {
    let httpParams = new HttpParams();
    for (const key in params) {
      if (params[key] !== null && params[key] !== undefined) {
        httpParams = httpParams.set(key, String(params[key]));
      }
    }
    return httpParams;
  }
}
