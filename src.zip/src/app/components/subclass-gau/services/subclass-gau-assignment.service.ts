import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from '../../../services/http.service';
import { UtilityService } from '../../../services/utility.service';

@Injectable({
  providedIn: 'root',
})
export class SubclassGAUandSearchRoomAssignmentService {
  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  /**
   * Validate start date
   */
  validateStartDate(beginDateValue: any): string | null {
    if (beginDateValue === undefined || beginDateValue === null) {
      return 'Start date value is invalid';
    }
    return null;
  }

  /**
   * Get subclass GAU assignments
   */
  getSubclassGAUAssignment(
    searchCriteria: any,
    includeInactive: boolean,
    limit: number,
    skip: number
  ): Observable<any> {
    const params: any = {
      includeInactive: true,
      artClassNo: searchCriteria.artClassNo || null,
      limit: limit || null,
      skip: skip || null,
    };
    
    // Only add optional search parameters if they have values
    if (searchCriteria.beginSubclass) {
      params.beginSubclass = searchCriteria.beginSubclass;
    }
    if (searchCriteria.endSubclass) {
      params.endSubclass = searchCriteria.endSubclass;
    }
    if (searchCriteria.businessAreaCode) {
      params.businessAreaCode = searchCriteria.businessAreaCode;
    }
    if (searchCriteria.shortName) {
      params.shortName = searchCriteria.shortName;
    }
    
    const queryString = this.httpService.mergeQueryParams(
      this.httpService.removeNullQueryParams(params)
    );
    // Disable caching for search results to ensure fresh data on each search
    return this.httpService.get(`/art-subclasses?${queryString}`, false);
  }

  /**
   * Get available GAU assignments
   */
  getAvailableGAUAssignment(searchCriteria: any): Observable<any> {
    const params = {
      artClassNo: searchCriteria.artClassNo || null,
      unassignedGAU: searchCriteria.unassignedGAU,
    };
    const queryString = this.httpService.mergeQueryParams(params);
    // Disable caching to ensure fresh data on each call
    return this.httpService.get(`/art-subclasses?${queryString}`, false);
  }

  /**
   * Get available search room assignments
   */
  getAvailableSearchRoomAssignment(searchCriteria: any): Observable<any> {
    const params = {
      artClassNo: searchCriteria.artClassNo || null,
      unassignedSearchRoom: searchCriteria.unassignedSearchRoom,
    };
    const queryString = this.httpService.mergeQueryParams(params);
    // Disable caching to ensure fresh data on each call
    return this.httpService.get(`/art-subclasses?${queryString}`, false);
  }

  /**
   * Get unassigned GAU subclasses for a specific art class
   */
  getUnassignedGAUSubclasses(artClassNo: string): Observable<any> {
    const params = {
      artClassNo: artClassNo,
      unassignedGAU: true,
    };
    const queryString = this.httpService.mergeQueryParams(params);
    // Disable caching to ensure fresh data on each call
    return this.httpService.get(`/art-subclasses?${queryString}`, false);
  }

  /**
   * Get all subclasses including inactive for a specific art class
   */
  getAllSubclassesIncludingInactive(artClassNo: string, limit: number = 100): Observable<any> {
    const params = {
      artClassNo: artClassNo,
      includeInactive: true,
      limit: limit,
    };
    const queryString = this.httpService.mergeQueryParams(params);
    // Disable caching to ensure fresh data on each call
    return this.httpService.get(`/art-subclasses?${queryString}`, false);
  }

  /**
   * Dissociate GAU subclass assignment
   */
  dissociateGAUSubclassAssignment(organizationIdList: string[]): Observable<any> {
    return this.httpService.post('/gau-subclass-assignments/dissociations', organizationIdList);
  }

  /**
   * Dissociate search room subclass assignment
   */
  dissociateSearchRoomSubclassAssignment(organizationIdList: string[]): Observable<any> {
    return this.httpService.post(
      '/search-room-subclass-assignments/dissociations',
      organizationIdList
    );
  }

  /**
   * Associate search room subclass assignment
   */
  associateSearchRoomSubclassAssignment(searchRoomRequest: any[]): Observable<any> {
    return this.httpService.post('/search-room-subclass-assignments', searchRoomRequest);
  }

  /**
   * Associate GAU subclass assignment
   */
  associateGAUSubclassAssignment(gauRequest: any[]): Observable<any> {
    return this.httpService.post('/gau-subclass-assignments', gauRequest);
  }

  /**
   * Update GAU start date
   */
  updateGAUStartDate(
    gauStartDate: string,
    activeGAU: any,
    orgArtSubclassId: string
  ): Observable<any> {
    const updatedGAU = { ...activeGAU };
    updatedGAU.lifecycle.beginDate = this.utilityService.adjustDateFormatter(gauStartDate);
    return this.httpService.put(`/gau-subclass-assignments/${orgArtSubclassId}`, updatedGAU);
  }

  /**
   * Update search room start date
   */
  updateSearchRoomStartDate(
    searchRoomStartDate: string,
    activeSearchRoom: any,
    searchRoomArtSubclassId: string
  ): Observable<any> {
    const updatedSearchRoom = { ...activeSearchRoom };
    updatedSearchRoom.lifecycle.beginDate = this.utilityService.adjustDateFormatter(searchRoomStartDate);
    return this.httpService.put(
      `/search-room-subclass-assignments/${searchRoomArtSubclassId}`,
      updatedSearchRoom
    );
  }
}
