import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

interface FilterDialogData {
  title: string;
  beginSubclass?: string;
  endSubclass?: string;
}

@Component({
  selector: 'app-filter-subclasses-dialog',
  templateUrl: './filter-subclasses-dialog.component.html',
  styleUrls: ['./filter-subclasses-dialog.component.scss'],
})
export class FilterSubclassesDialogComponent implements OnInit {
  beginSubclass: string = '';
  endSubclass: string = '';
  title: string = 'Filter Subclasses';

  constructor(
    public dialogRef: MatDialogRef<FilterSubclassesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: FilterDialogData
  ) {
    if (data) {
      this.title = data.title || 'Filter Subclasses';
      this.beginSubclass = data.beginSubclass || '';
      this.endSubclass = data.endSubclass || '';
    }
  }

  ngOnInit(): void {}

  /**
   * Handle filter button click - validate and return filter data
   */
  applyFilter(): void {
    if (this.validateInput()) {
      this.dialogRef.close({
        content: {
          beginSubclass: this.beginSubclass,
          endSubclass: this.endSubclass,
        },
      });
    }
  }

  /**
   * Validate filter input
   */
  private validateInput(): boolean {
    if (!this.beginSubclass || !this.endSubclass) {
      alert('Please enter both Begin and End subclass values');
      return false;
    }

    const begin = parseInt(this.beginSubclass, 10);
    const end = parseInt(this.endSubclass, 10);

    if (isNaN(begin) || isNaN(end)) {
      alert('Subclass values must be numeric');
      return false;
    }

    return true;
  }

  /**
   * Handle cancel button click
   */
  cancel(): void {
    this.dialogRef.close();
  }

  /**
   * Handle Enter key press in input fields
   */
  onKeyPress(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.applyFilter();
    }
  }
}
