import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SubclassGAUandSearchRoomAssignmentService } from './services/subclass-gau-assignment.service';
import { LocationService } from './services/location.service';
import { OrganizationService } from '../organization/services/organization.service';
import { UtilityService } from '../../services/utility.service';
import { SubclassGAUandSearchRoomControllerHelper } from './helpers/subclass-gau.helper';
import { ArtClassSearchWizardComponent } from './art-class-search-wizard/art-class-search-wizard.component';
import { OrganizationSelectTreeDialogComponent } from '../../shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { LocationselectDialogComponent } from '../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { FilterSubclassesDialogComponent } from './filter-subclasses-dialog/filter-subclasses-dialog.component';
import { FilterSearchRoomSubclassesDialogComponent } from './filter-search-room-subclasses-dialog/filter-search-room-subclasses-dialog.component';
import { UpdateDatesWizardComponent } from './update-dates-wizard/update-dates-wizard.component';

interface ArtSubclassAssignment {
  artSubclassId: string;
  artSubclassNo: string;
  artClass: { artClassNo: string };
  activeGAU?: Array<{
    orgArtSubclassId: string;
    organization: {
      businessAreaCode: string;
      shortName: string;
      organizationId?: string;
    };
    lifecycle: {
      beginDate: string;
    };
  }>;
  activeSearchRoom?: Array<{
    searchRoomArtSubclassId: string;
    searchRoom: {
      locationId?: string;
      building: {
        name: string;
        code?: string;
        floorNumber: string;
      };
      corridorId: string;
      roomId: string;
      suiteId: string;
      zoneId: string;
    };
    lifecycle: {
      beginDate: string;
    };
  }>;
  selected?: boolean;
}

interface UnassignedGAU {
  artSubclassId: string;
  artSubclassNo: string;
  selected?: boolean;
}

interface UnassignedSubclass {
  artSubclassId: string;
  artSubclassNo: string;
  selected?: boolean;
}

interface SearchOptions {
  artClassNo: string;
  beginSubclass: string;
  endSubclass: string;
  businessAreaCode: string;
  shortName: string;
}

interface Location {
  locationId?: string;
  building?: { code?: string; floorNumber?: string };
  corridorId?: string;
  suiteId?: string;
  roomId?: string;
  zoneId?: string;
}

interface Purpose {
  description: string;
  [key: string]: any;
}

@Component({
  selector: 'app-subclass-gau',
  templateUrl: './subclass-gau.component.html',
  styleUrls: ['./subclass-gau.component.scss'],
})
export class SubclassGAUComponent implements OnInit, OnDestroy {
  // UI State
  appTitle = 'Subclass GAU and Search Room Assignments';
  moduleName = 'Subclass GAU and Search Room Assignments';
  showType = 'active';
  skip: number = 0;

  limit = 100;
  disabledButtons = true;
  activeSideBar = true;
  showSideBarButton = false;
  searchResultsMode = false;
  hideMessage = true;
  invalidAcronym = false;
  invalidArtClass = false;
  searchResultsCount = '';
  showWait = false;
  loadingMessage = '';
  resultsFound = false;
  accessDenied = false;
  returnMessage = '';
  returnCode: string | number = '';
  showLongMessage = false;
  wholeMessage = '';

  // Search Form
  artClassNo = '';
  displayArtClassNo = '';
  acronym = 'P/';  // Display default 'P/' but don't include in search unless user adds more
  associateAcronym = 'P/';  // Default for association
  businessAreaCode = '';
  shortName = '';
  beginSubclass = '';
  endSubclass = '';
  associateBusinessArea = '';
  gauOrganizationId = '';

  // Data Models
  artSubclassAssignments: ArtSubclassAssignment[] = [];
  unassignedGAU: UnassignedGAU[] = [];
  unassignedSubclass: UnassignedSubclass[] = [];
  purposeList: Purpose[] = [];
  searchRoomPurpose: Purpose | null = null;

  // Selection State
  selectedAll = false;
  subclassSelectedAll = false;
  searchRoomSelectedAll = false;
  selectedItems = 0;
  selectedValues: UnassignedGAU[] = [];
  selectedSearchRoomValues: UnassignedSubclass[] = [];
  selectedLocation: any = {
    locationId: '',
    building: { code: '', floorNumber: '' },
    corridorId: '',
    suiteId: '',
    roomId: '',
    zoneId: '',
  };

  // UI Text
  selectText = 'Select all';
  gauSelectText = 'Select all';
  searchRoomSelectText = 'Select all';
  filterGAUText = 'Filter';
  filterSearchroomText = 'Filter';

  // Disabled States
  selectAllDisabled = true;
  searchRoomFilterDisabled = true;
  gauFilterDisabled = true;
  disabledCheckboxes = false;

  // Counters
  total = 0;  // Total search results count
  unassignedGAUTotal = 0;  // Total unassigned GAU count
  unassignedSubclassTotal = 0;  // Total unassigned search room count
  unassignedGAUCount = '0 record(s).';
  unassignedSubclassCount = '0 record(s)';
  currentPage = 1;

  // Select Options
  selectOptions = [
    { text: '100', value: 100 },
    { text: '250', value: 250 },
  ];
  
  pageSizeOptions = [
    { name: '100', value: 100 },
    { name: '250', value: 250 },
  ];

  // Internal State
  searchOptions: SearchOptions = {
    artClassNo: '',
    beginSubclass: '',
    endSubclass: '',
    businessAreaCode: '',
    shortName: '',
  };
  currentSearchOptions: SearchOptions = { ...this.searchOptions };
  currentGAUList: any = {};
  currentSubclassList: any = {};
  artClassList: ArtSubclassAssignment[] = [];
  gauStartDate: string = '';
  searchRoomStartDate: string = '';
  accordionOpen = true;
  userRoles: any[] = [];

  private destroy$ = new Subject<void>();
  private timeoutId: any;
  private artClassModalRef: MatDialogRef<ArtClassSearchWizardComponent> | null = null;

  constructor(
    private subclassGAUService: SubclassGAUandSearchRoomAssignmentService,
    private locationService: LocationService,
    private organizationService: OrganizationService,
    private utilityService: UtilityService,
    private controllerHelper: SubclassGAUandSearchRoomControllerHelper,
    private matDialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.getSearchRoomPurpose();
    this.resetAssignmentSearchOptions();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
    if (this.artClassModalRef) {
      this.artClassModalRef.close();
    }
  }

  resetTimeout(): void {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  resetAssignmentSearchOptions(): void {
    this.artClassNo = '';
    this.acronym = 'P/';  // Reset to default 'P/'
    this.associateAcronym = 'P/';
    this.businessAreaCode = '';
    this.shortName = '';
    this.beginSubclass = '';
    this.endSubclass = '';
    this.displayArtClassNo = '';
    this.total = 0;
    this.searchResultsCount = '';
    this.unassignedGAUCount = '0 record(s).';
    this.unassignedSubclassCount = '0 record(s)';
    this.selectAllDisabled = true;
    this.searchRoomFilterDisabled = true;
    this.gauFilterDisabled = true;
    this.selectedLocation = {
      locationId: '',
      building: { code: '', floorNumber: '' },
      corridorId: '',
      suiteId: '',
      roomId: '',
      zoneId: '',
    };
    this.searchOptions = {
      artClassNo: '',
      beginSubclass: '',
      endSubclass: '',
      businessAreaCode: '',
      shortName: '',
    };
    this.currentSearchOptions = { ...this.searchOptions };
  }

  cancelAllInvalidates(): void {
    this.invalidArtClass = false;
    this.invalidAcronym = false;
    this.selectedItems = 0;
  }

  hideSideBar(): void {
    this.showSideBarButton = true;
    this.activeSideBar = false;
  }

  showSideBar(): void {
    this.activeSideBar = true;
    this.timeoutId = setTimeout(() => this.addActiveBarStyle(), 10);
  }

  addActiveBarStyle(): void {
    this.showSideBarButton = false;
  }

  showSearchResult(): void {
    this.invalidAcronym = false;
    this.hideMessage = true;
    this.searchResultsMode = true;
    
    // Parse acronym if manually entered (format: "P/3725")
    // Only process if acronym has content beyond default "P/"
    let searchBusinessAreaCode = '';
    let searchShortName = '';
    
    if (this.acronym && this.acronym.trim() && this.acronym !== 'P/') {
      if (this.acronym.includes('/')) {
        const parts = this.acronym.split('/');
        if (parts.length === 2 && parts[1].trim()) {
          searchBusinessAreaCode = parts[0].trim();
          searchShortName = parts[1].trim();
        }
      }
    }
    
    // Build search options - only include GAU fields if they have meaningful values
    this.searchOptions = {
      artClassNo: this.artClassNo,
      beginSubclass: this.beginSubclass,
      endSubclass: this.endSubclass,
      businessAreaCode: searchBusinessAreaCode,
      shortName: searchShortName,
    };

    this.currentSearchOptions = { ...this.searchOptions };
    if (!this.invalidArtSubclassParameters()) {
      this.getTemplateSubclassSearch(
        this.limit,
        0,
        'Loading Subclass GAU and Search Room Assignments...'
      );
      this.firstPage();
    }
    
    // Reset associate acronym after search
    this.associateAcronym = 'P/';
  }
  
  searchAcronymChange(event: any): void {
    // When user selects from organization tree dialog for search field
    if (event?.organizationType?.businessArea?.code && event?.shortName) {
      this.businessAreaCode = event.organizationType.businessArea.code;
      this.shortName = event.shortName;
      this.acronym = `${this.businessAreaCode}/${this.shortName}`;
    } else if (event === null || event === '') {
      // Clear the acronym if user clears the selection
      this.businessAreaCode = '';
      this.shortName = '';
      this.acronym = '';
    }
  }

  onAssociateAcronymChange(event: any): void {
    // When user selects from organization tree dialog
    if (event?.organizationType?.businessArea?.code && event?.shortName) {
      this.associateBusinessAreaCode = event.organizationType.businessArea.code;
      this.associateShortName = event.shortName;
      this.associateAcronym = `${this.associateBusinessAreaCode}/${this.associateShortName}`;
    }
  }

  compareGAU(a: UnassignedGAU, b: UnassignedGAU): boolean {
    return a && b ? a.artSubclassId === b.artSubclassId : a === b;
  }

  compareSearchRoom(a: UnassignedSubclass, b: UnassignedSubclass): boolean {
    return a && b ? a.artSubclassId === b.artSubclassId : a === b;
  }

  associateBusinessAreaCode = '';
  associateShortName = '';
  private getSearchRoomPurpose(): void {
    this.locationService
      .getPurposes()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.purposeList = response.results || response;
          this.purposeList.forEach((purpose: Purpose) => {
            if (purpose.description === 'Search Room') {
              this.searchRoomPurpose = purpose;
            }
          });
        },
        (response: any) => {
          this.accessDenied = response.accessDenied;
          this.returnMessage = this.utilityService.processFailureMessage(
            response,
            'Problem retrieving Search room purpose data'
          );
          this.returnCode = response.status;
          this.hideMessage = false;
        }
      );
  }

  getTemplateSubclassSearch(limit: number, skip: number, message?: string): void {
    const includeInactive = false;
    if (this.searchResultsMode) {
      if (message) {
        this.loadingMessage = message;
      }
      this.showWait = true;
      this.resetTimeout();

      this.subclassGAUService
        .getSubclassGAUAssignment(this.currentSearchOptions, includeInactive, limit, skip)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            this.showWait = false;
            this.selectAllDisabled = false;
            
            // Create a new array reference to trigger ngOnChanges in child component
            this.artSubclassAssignments = [...response.results];
            
            this.displayArtClassNo = this.artSubclassAssignments[0]?.artClass?.artClassNo || '';
            this.total = response.meta.total;
            this.searchResultsCount = `${this.total} assignment(s) found.`;
            this.resultsFound =
              this.artSubclassAssignments && this.artSubclassAssignments.length > 0;
            
            this.loadingMessage = '';
            // Load unassigned GAU and search room data after successful search
            this.currentGAUList = {
              artClassNo: this.displayArtClassNo,
              unassignedGAU: true,
            };
            this.getUnassignedGAU();
            this.currentSubclassList = {
              artClassNo: this.displayArtClassNo,
              unassignedSearchRoom: true,
            };
            this.getUnassignedSubclassList();
          },
          (response: any) => {
            this.showWait = false;
            if (this.searchResultsMode) {
              // Clear results and show 0 count when error or no results
              this.artSubclassAssignments = [];
              this.total = 0;
              this.searchResultsCount = `${this.total} assignment(s) found.`;
              this.displayArtClassNo = '';
              this.resultsFound = false;
            } else {
              this.accessDenied = response.accessDenied;
              this.returnMessage = this.utilityService.processFailureMessage(
                response,
                'Problem retrieving Transfer and Search data'
              );
              this.returnCode = response.status;
              this.hideMessage = false;
            }
          }
        );
    }
  }

  checkAll(): void {
    if (this.selectedAll) {
      this.selectedAll = true;
      this.disabledButtons = false;
    } else {
      this.selectedAll = false;
      this.disabledButtons = true;
    }
    this.selectedCount();
  }

  checked(): number {
    this.selectedItems = this.artSubclassAssignments.filter((item) => item.selected).length;
    if (this.selectedItems) {
      this.disabledButtons = false;
    } else {
      this.disabledButtons = true;
    }
    return this.selectedItems;
  }

  selectedCount(): number {
    let selectedItems = 0;
    this.artSubclassAssignments.forEach((item) => {
      item.selected = this.selectedAll;
      selectedItems += item.selected ? 1 : 0;
    });
    this.selectedItems = selectedItems;
    return this.selectedItems;
  }

  toggleSelected(): void {
    this.selectedAll = !this.selectedAll;
    this.selectedCount();
    if (this.selectedAll) {
      this.selectedAll = true;
      this.disabledButtons = false;
      this.selectText = 'Unselect all';
    } else {
      this.selectText = 'Select all';
      this.selectedAll = false;
      this.disabledButtons = true;
    }
  }

  openLookupOrganization(type: string): void {
    const dialogInfo = {
      title: 'Search and select acronym',
      button: 'Select acronym',
    };

    const dialogRef = this.matDialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      maxWidth: '90vw',
      data: {
        dialogInfo: dialogInfo,
        buttonsVisible: true,  // Enable the Select Acronym and Cancel buttons
        button: 'Select acronym',
      },
    });

    dialogRef.afterClosed().subscribe((selectedOrganization: any) => {
      if (selectedOrganization) {
        if (type === 'associate') {
          // For the "Assign GAU" field
          this.associateBusinessAreaCode = selectedOrganization.organizationType?.businessArea?.code || '';
          this.associateShortName = selectedOrganization.shortName || '';
          this.associateAcronym = `${this.associateBusinessAreaCode}/${this.associateShortName}`;
        } else {
          // For the search field (if needed in future)
          this.businessAreaCode = selectedOrganization.organizationType?.businessArea?.code || '';
          this.shortName = selectedOrganization.shortName || '';
          this.acronym = `${this.businessAreaCode}/${this.shortName}`;
        }
      }
    });
  }

  hideMessageDiv(): void {
    this.hideMessage = true;
  }

  clearAdvancedSearch(): void {
    this.resetAssignmentSearchOptions();
    this.searchResultsMode = false;
    this.cancelAllInvalidates();
    this.resultsFound = false;
    
    // Clear the grid data
    this.artSubclassAssignments = [];
    this.total = 0;
    this.searchResultsCount = '';
    
    // Clear the Available subclasses for GAU selection box
    this.unassignedGAU = [];
    this.unassignedGAUTotal = 0;
    this.unassignedGAUCount = '0 record(s).';
    this.selectedValues = [];
    this.subclassSelectedAll = false;
    this.gauSelectText = 'Select all';
    
    // Clear the Available subclasses for Search Room selection box
    this.unassignedSubclass = [];
    this.unassignedSubclassTotal = 0;
    this.unassignedSubclassCount = '0 record(s)';
    this.selectedSearchRoomValues = [];
    this.searchRoomSelectedAll = false;
    this.searchRoomSelectText = 'Select all';
    
    // Reset filter buttons
    this.filterGAUText = 'Filter';
    this.filterSearchroomText = 'Filter';
    this.gauFilterDisabled = true;
    this.searchRoomFilterDisabled = true;
  }

  mainSearchSubclassGAUKeyEventHandler(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.hideMessage = true;
      this.showSearchResult();
    }
  }

  searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.search();
    }
  }

  search(): void {
    if (this.businessAreaCode && this.shortName) {
      this.searchWithTerm(this.businessAreaCode.toUpperCase(), this.shortName.toUpperCase());
    }
  }

  searchWithTerm(businessArea: string, shortName: string): void {
    // Search for organization by business area and short name
    this.organizationService
      .searchOrganizations(businessArea, shortName, false)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response.results && response.results.length > 0) {
            const org = response.results[0];
            this.businessAreaCode = org.organizationType.businessArea.code;
            this.shortName = org.shortName;
            this.acronym = `${this.businessAreaCode}/${this.shortName}`;
          }
        },
        (error: any) => {
        }
      );
  }

  showArtClassWizard(): void {
    const dialogInfo = {
      title: 'Art Class Search',
      titleType: 'title-default',
      primaryButtonTypeSearch: 'primary',
      primaryButtonSearch: 'Search',
      clearButton: true,
      cancelButton: true,
      content: this.artClassNo,
    };

    this.artClassModalRef = this.matDialog.open(ArtClassSearchWizardComponent, {
      width: '1000px',
      maxWidth: '90vw',
      // disableClose: true,
      data: {
        dialogInfo: dialogInfo,
      },
    });

    // Handle component output events
    if (this.artClassModalRef) {
      this.artClassModalRef.componentInstance.confirm.subscribe((artClass: any) => {
        this.artClassNo = artClass.artClassNo;
        this.artClassModalRef?.close();
      });

      this.artClassModalRef.componentInstance.cancel.subscribe(() => {
        this.artClassModalRef?.close();
      });
    }
  }

  changeDates(): void {
    this.artClassList = this.artSubclassAssignments.filter((item) => item.selected);

    if (this.artClassList.length === 0) {
      this.hideMessage = false;
      this.returnMessage = 'Please select at least one record to update dates';
      this.returnCode = '400';
      return;
    }

    const modalOptions = {
      title: 'Change Dates',
      titleType: 'text-primary',
      content: this.artClassList,
      primaryButton: 'Change',
      primaryButtonType: 'primary',
      cancelButton: true,
    };

    this.openDateWizard(modalOptions);
  }

  /**
   * Open the date wizard dialog
   */
  private openDateWizard(modalOptions: any): void {
    const dialogRef = this.matDialog.open(UpdateDatesWizardComponent, {
      width: '600px',
      maxWidth: '90vw',
      data: modalOptions,
      disableClose: false,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('Dialog closed with result:', result);
      if (result && result.content) {
        console.log('Saving updated dates:', result.content);
        this.saveUpdatedSearchRoomGAUDates(result.content);
        // Refresh the grid after dates are updated
        console.log('Refreshing grid after date update');
        this.refreshGridAfterDateUpdate();
      } else {
        console.log('No result or content from dialog');
      }
    });
  }

  /**
   * Refresh grid data after date update
   */
  private refreshGridAfterDateUpdate(): void {
    console.log('refreshGridAfterDateUpdate called');
    // Use the current search options to refresh the grid
    this.getTemplateSubclassSearch(
      this.limit,
      0,
      'Refreshing data after date update...'
    );
    this.firstPage();
  }

  /**
   * Save updated GAU dates
   */
  private saveGAUDates(dateInfo: any): void {
    // Convert date to ISO string (service will adjust it)
    this.gauStartDate = new Date(dateInfo.updatedGauStartDate).toISOString();
    let updateCount = 0;
    let successCount = 0;

    this.artClassList.forEach((item) => {
      if (item.activeGAU && item.activeGAU.length > 0) {
        updateCount++;
        const orgArtSubclassId = item.activeGAU[0].orgArtSubclassId;
        this.subclassGAUService
          .updateGAUStartDate(this.gauStartDate, item, orgArtSubclassId)
          .pipe(takeUntil(this.destroy$))
          .subscribe(
            () => {
              successCount++;
              // Only refresh once all updates are complete
              if (successCount === updateCount) {
                this.getTemplateSubclassSearch(
                  this.limit,
                  0,
                  'Loading Subclass GAU and Search Room Assignments...'
                );
                this.firstPage();
                this.selectedAll = false;
                this.selectText = 'Select all';
                this.hideMessage = false;
                this.returnCode = '201';
                this.returnMessage = 'Successfully updated GAU start date(s)';
              }
            },
            (response: any) => {
              this.accessDenied = response.accessDenied;
              this.returnMessage = this.utilityService.processFailureMessage(
                response,
                'Problem saving GAU dates'
              );
              this.returnCode = response.status;
              this.hideMessage = false;
            }
          );
      }
    });
  }

  /**
   * Save updated search room dates
   */
  private saveSearchRoomDates(dateInfo: any): void {
    // Convert date to ISO string (service will adjust it)
    this.searchRoomStartDate = new Date(dateInfo.updatedSearchRoomStartDate).toISOString();
    let updateCount = 0;
    let successCount = 0;

    this.artClassList.forEach((item) => {
      if (item.activeSearchRoom && item.activeSearchRoom.length > 0) {
        updateCount++;
        const searchRoomArtSubclassId = item.activeSearchRoom[0].searchRoomArtSubclassId;
        this.subclassGAUService
          .updateSearchRoomStartDate(this.searchRoomStartDate, item, searchRoomArtSubclassId)
          .pipe(takeUntil(this.destroy$))
          .subscribe(
            () => {
              successCount++;
              // Only refresh once all updates are complete
              if (successCount === updateCount) {
                this.disabledButtons = true;
                this.getTemplateSubclassSearch(
                  this.limit,
                  0,
                  'Loading Subclass GAU and Search Room Assignments...'
                );
                this.firstPage();
                this.selectedAll = false;
                this.selectText = 'Select all';
                this.hideMessage = false;
                this.returnCode = '201';
                this.returnMessage = 'Successfully updated Search Room start date(s)';
              }
            },
            (response: any) => {
              this.accessDenied = response.accessDenied;
              this.returnMessage = this.utilityService.processFailureMessage(
                response,
                'Problem saving Search room dates'
              );
              this.returnCode = response.status;
              this.hideMessage = false;
            }
          );
      }
    });
  }

  /**
   * Save updated search room and GAU dates
   */
  private saveUpdatedSearchRoomGAUDates(dateInfo: any): void {
    this.resetTimeout();
    this.showWait = true;
    
    if (dateInfo.updatedGauStartDate) {
      this.saveGAUDates(dateInfo);
    }
    if (dateInfo.updatedSearchRoomStartDate) {
      this.saveSearchRoomDates(dateInfo);
    }
    
    // Hide wait indicator after a short delay
    setTimeout(() => {
      this.showWait = false;
    }, 500);
  }

  filterSubclasses(): void {
    const filterButtonText = this.filterGAUText;
    if (filterButtonText.indexOf('Clear') > -1) {
      this.getUnassignedGAU();
      this.filterGAUText = 'Filter';
    } else {
      // Open filter subclasses wizard modal
      this.openFilterSubclassesWizard();
    }
  }

  filterSearchRoomSubclasses(): void {
    const filterSearchRoomButtonText = this.filterSearchroomText;
    if (filterSearchRoomButtonText.indexOf('Clear') > -1) {
      this.getUnassignedSubclassList();
      this.filterSearchroomText = 'Filter';
    } else {
      // Open filter search room subclasses wizard modal
      this.openFilterSearchRoomSubclassesWizard();
    }
  }

  toggleGAUSelected(): void {
    this.subclassSelectedAll = !this.subclassSelectedAll;
    if (this.subclassSelectedAll) {
      this.gauSelectText = 'Unselect all';
      this.selectedValues = [];
      this.unassignedGAU.forEach((unassignedGAU) => {
        this.selectedValues.push(unassignedGAU);
      });
    } else {
      this.gauSelectText = 'Select all';
      this.selectedValues = [];
    }
  }

  toggleSearchRoomSelected(): void {
    this.searchRoomSelectedAll = !this.searchRoomSelectedAll;
    if (this.searchRoomSelectedAll) {
      this.searchRoomSelectText = 'Unselect all';
      this.selectedSearchRoomValues = [];
      this.unassignedSubclass.forEach((unassignedSearchRoom) => {
        this.selectedSearchRoomValues.push(unassignedSearchRoom);
      });
    } else {
      this.searchRoomSelectText = 'Select all';
      this.selectedSearchRoomValues = [];
    }
  }

  lookupSearchRoom(): void {
    const data = {
      searchPurpose: this.searchRoomPurpose,
      searchTitle: 'Search for Search Room',
    };

    const dialogRef = this.matDialog.open(LocationselectDialogComponent, {
      width: '90vw',
      maxWidth: '95vw',
      data: data,
    });

    dialogRef.afterClosed().subscribe((selectedLocation: any) => {
      if (selectedLocation) {
        this.selectedLocation = {
          locationId: selectedLocation.locationId || '',
          building: {
            code: selectedLocation.building?.code || '',
            floorNumber: selectedLocation.building?.floorNumber || '',
          },
          corridorId: selectedLocation.corridorId || '',
          suiteId: selectedLocation.suiteId || '',
          roomId: selectedLocation.roomId || '',
          zoneId: selectedLocation.zoneId || '',
        };
      }
    });
  }

  private invalidArtSubclassParameters(): boolean {
    this.cancelAllInvalidates();
    let theArtSubclassInvalid = false;

    if (!this.artClassNo) {
      this.invalidArtClass = true;
      theArtSubclassInvalid = true;
    }

    // GAU acronym is optional for search
    // Old app had validation: if (vm.acronym && vm.acronym.length<3) but it's not needed
    // The search should work with or without GAU filter

    return theArtSubclassInvalid;
  }

  getUnassignedGAU(): void {
    this.subclassGAUService
      .getAvailableGAUAssignment(this.currentGAUList)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.selectAllDisabled = false;
          this.unassignedGAU = response.results;
          this.unassignedGAUTotal = response.meta.total;
          this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;
          this.gauFilterDisabled = false;
        },
        (response: any) => {
          if (response.status === 404) {
            this.unassignedGAU = [];
            this.unassignedGAUTotal = 0;
            this.gauFilterDisabled = true;
            this.unassignedGAUCount = '0 record(s).';
          } else {
            this.accessDenied = response.accessDenied;
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Problem getting unassigned GAU'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
          }
        }
      );
  }

  getUnassignedSubclassList(): void {
    this.searchRoomSelectedAll = true;
    this.toggleSearchRoomSelected();

    this.subclassGAUService
      .getAvailableSearchRoomAssignment(this.currentSubclassList)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.selectAllDisabled = false;
          this.unassignedSubclass = response.results;
          this.unassignedSubclassTotal = response.meta.total;
          this.unassignedSubclassCount = `${this.unassignedSubclassTotal} record(s)`;
          this.searchRoomFilterDisabled = false;
        },
        (response: any) => {
          if (response.status === 404) {
            this.unassignedSubclassTotal = 0;
            this.unassignedSubclassCount = '0 record(s)';
            this.unassignedSubclass = [];
            this.searchRoomFilterDisabled = true;
          } else {
            this.accessDenied = response.accessDenied;
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Problem getting available search room assignments'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
          }
        }
      );
  }

  dissociateGAU(): void {
    this.artClassList = this.artSubclassAssignments.filter((item) => item.selected);
    const orgArtList: string[] = [];
    const subclassesToAdd: UnassignedGAU[] = [];

    this.artClassList.forEach((item) => {
      if (item.activeGAU && item.activeGAU.length > 0) {
        orgArtList.push(item.activeGAU[0].orgArtSubclassId);
      }
      // Add the subclass to the list to be moved to GAU select box
      subclassesToAdd.push({
        artSubclassId: item.artSubclassId,
        artSubclassNo: item.artSubclassNo,
        selected: false,
      });
    });

    if (orgArtList.length > 0) {
      this.showWait = true;
      this.subclassGAUService
        .dissociateGAUSubclassAssignment(orgArtList)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            this.showWait = false;
            this.disabledButtons = true;
            
            // Clear the activeGAU from the selected items in the search results
            this.artClassList.forEach((item) => {
              item.activeGAU = [];
            });
            
            // Uncheck all checkboxes in the search results table
            this.uncheckAllSearchResultsCheckboxes();
            
            // Refresh the search results to show updated data
            this.getTemplateSubclassSearch(this.limit, 0, 'Refreshing after GAU dissociation...');
            this.firstPage();
            
            // Refresh unassigned GAU list first, then add dissociated subclasses
            this.getUnassignedGAUAndAddSubclasses(subclassesToAdd);
            
            this.hideMessage = false;
            this.returnCode = '201';
            this.returnMessage = 'Successfully dissociated GAU';
            this.selectedAll = false;
            this.selectText = 'Select all';
          },
          (response: any) => {
            this.showWait = false;
            this.accessDenied = response.accessDenied;
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Problem dissociating GAU assignment'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
          }
        );
    }
  }

  /**
   * Get unassigned GAU list and then add dissociated subclasses
   */
  private getUnassignedGAUAndAddSubclasses(subclassesToAdd: UnassignedGAU[]): void {
    this.subclassGAUService
      .getAvailableGAUAssignment(this.currentGAUList)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.selectAllDisabled = false;
          this.unassignedGAU = response.results;
          this.unassignedGAUTotal = response.meta.total;
          this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;
          this.gauFilterDisabled = false;
          
          // Now add the dissociated subclasses to the GAU select box
          this.addSubclassesToGAUSelectBox(subclassesToAdd);
        },
        (response: any) => {
          if (response.status === 404) {
            this.unassignedGAU = [];
            this.unassignedGAUTotal = 0;
            this.gauFilterDisabled = true;
            this.unassignedGAUCount = '0 record(s).';
            
            // Add dissociated subclasses even if no other unassigned GAU exists
            this.addSubclassesToGAUSelectBox(subclassesToAdd);
          } else {
            this.accessDenied = response.accessDenied;
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Problem getting unassigned GAU'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
          }
        }
      );
  }

  /**
   * Uncheck all checkboxes in the search results table
   */
  private uncheckAllSearchResultsCheckboxes(): void {
    this.artSubclassAssignments.forEach((item) => {
      item.selected = false;
    });
  }

  /**
   * Add subclasses to the GAU select box after dissociation
   */
  private addSubclassesToGAUSelectBox(subclassesToAdd: UnassignedGAU[]): void {
    subclassesToAdd.forEach((subclass) => {
      // Check if subclass is not already in the unassignedGAU list
      const exists = this.unassignedGAU.some(
        (gau) => gau.artSubclassId === subclass.artSubclassId
      );
      if (!exists) {
        this.unassignedGAU.push(subclass);
      }
    });

    // Update the count
    this.unassignedGAUTotal = this.unassignedGAU.length;
    this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;

    // Add the subclasses to the selected values so they appear in the select box
    subclassesToAdd.forEach((subclass) => {
      const exists = this.selectedValues.some(
        (selected) => selected.artSubclassId === subclass.artSubclassId
      );
      if (!exists) {
        this.selectedValues.push(subclass);
      }
    });
  }

  dissociateSearchRoom(): void {
    this.artClassList = this.artSubclassAssignments.filter((item) => item.selected);
    const orgArtList: string[] = [];
    this.artClassList.forEach((item) => {
      if (item.activeSearchRoom && item.activeSearchRoom.length > 0) {
        orgArtList.push(item.activeSearchRoom[0].searchRoomArtSubclassId);
      }
    });

    if (orgArtList.length > 0) {
      this.showWait = true;
      this.subclassGAUService
        .dissociateSearchRoomSubclassAssignment(orgArtList)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            this.showWait = false;
            this.disabledButtons = true;
            // Refresh the search results to show updated data
            this.getTemplateSubclassSearch(this.limit, 0, 'Refreshing after Search Room dissociation...');
            this.firstPage();
            this.getUnassignedSubclassList();
            this.hideMessage = false;
            this.returnCode = '201';
            this.returnMessage = 'Successfully dissociated Search Room';
            this.selectedAll = false;
            this.selectText = 'Select all';
          },
          (response: any) => {
            this.showWait = false;
            this.accessDenied = response.accessDenied;
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Problem dissociating Search Room assignment'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
          }
        );
    }
  }

  dissociateBoth(): void {
    this.dissociateSearchRoom();
    this.dissociateGAU();
  }

  associateSearchRoom(): void {
    this.hideMessage = true;

    // Validate that we have selected search rooms and a location
    if (!this.selectedSearchRoomValues || this.selectedSearchRoomValues.length === 0) {
      this.hideMessage = false;
      this.returnCode = '400';
      this.returnMessage = 'Please select at least one subclass';
      return;
    }

    if (!this.selectedLocation || !this.selectedLocation.locationId) {
      this.hideMessage = false;
      this.returnCode = '400';
      this.returnMessage = 'Please select a location';
      return;
    }

    // Build the association requests directly using the selected location
    const associateRequests: any[] = [];
    this.selectedSearchRoomValues.forEach((item) => {
      associateRequests.push(
        this.controllerHelper.getSearchRoomRequest(item.artSubclassId, this.selectedLocation.locationId)
      );
    });

    if (associateRequests.length > 0) {
      this.showWait = true;
      console.log('Calling associateSearchRoomSubclassAssignment with requests:', associateRequests);
      this.subclassGAUService
        .associateSearchRoomSubclassAssignment(associateRequests)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          () => {
            this.showWait = false;
            this.getTemplateSubclassSearch(this.limit, 0, 'Associate Search Room...');
            this.firstPage();
            this.getUnassignedSubclassList();
            this.hideMessage = false;
            this.returnCode = '201';
            this.returnMessage = 'Successfully associated Search Room to subclass(es)';
          },
          (responseMessage: any) => {
            this.showWait = false;
            this.returnMessage = responseMessage.data.message;
            this.hideMessage = false;
            this.returnCode = '400';
          }
        );
    }
  }

  private processLocations(response: any, formData: any): void {
    const associateRequests: any[] = [];
    const artSubclassIdList: string[] = [];
    const locationMatch = this.findMatchingLocation(formData, response.results);

    if (!locationMatch) {
      this.hideMessage = false;
      this.returnCode = '400';
      this.returnMessage = 'Location not found';
      return;
    }

    this.selectedSearchRoomValues.forEach((item) => {
      artSubclassIdList.push(item.artSubclassId);
    });

    artSubclassIdList.forEach((item) => {
      associateRequests.push(
        this.controllerHelper.getSearchRoomRequest(item, locationMatch.locationId || '')
      );
    });

    if (associateRequests.length > 0) {
      this.showWait = true;
      this.subclassGAUService
        .associateSearchRoomSubclassAssignment(associateRequests)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          () => {
            this.showWait = false;
            this.getTemplateSubclassSearch(this.limit, 0, 'Associate Search Room...');
            this.firstPage();
            this.getUnassignedSubclassList();
            this.hideMessage = false;
            this.returnCode = '201';
            this.returnMessage = 'Successfully associated Search Room to subclass(es)';
          },
          (responseMessage: any) => {
            this.showWait = false;
            this.returnMessage = responseMessage.data.message;
            this.hideMessage = false;
            this.returnCode = '400';
          }
        );
    }
  }

  private findMatchingLocation(formData: any, locationResults: Location[]): Location | null {
    let locationMatch: Location | null = null;
    locationResults.forEach((aLocation: Location) => {
      if (this.locationsMatch(aLocation, formData)) {
        locationMatch = aLocation;
      }
    });
    return locationMatch;
  }

  private locationsMatch(aLocation: Location, formData: any): boolean {
    const buildingMatch =
      aLocation.building?.code === formData.buildingCodeSearch &&
      aLocation.corridorId === formData.corridorSearch &&
      aLocation.roomId === formData.roomSearch;

    const floorMatch =
      aLocation.building?.floorNumber === formData.floorSearch &&
      aLocation.suiteId === formData.suiteSearch &&
      aLocation.zoneId === formData.zoneSearch;

    return buildingMatch && floorMatch;
  }

  private getGAURequest(item: string, organizationId: string): any {
    const today = new Date().toISOString();
    const adjustedDate = this.utilityService.adjustDateFormatter(today);

    return {
      artSubClass: {
        artSubclassId: item,
      },
      organization: {
        id: organizationId,
      },
      lifecycle: {
        beginDate: adjustedDate,
      },
    };
  }

  /**
   * Remove associated subclasses from the GAU select box
   */
  private removeAssociatedSubclassesFromGAUSelectBox(subclassesToRemove: UnassignedGAU[]): void {
    subclassesToRemove.forEach((subclass) => {
      // Remove from unassignedGAU array
      this.unassignedGAU = this.unassignedGAU.filter(
        (gau) => gau.artSubclassId !== subclass.artSubclassId
      );
    });

    // Update the count
    this.unassignedGAUTotal = this.unassignedGAU.length;
    this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;
  }

  associateGAU(): void {
    console.log('associateGAU() called');
    
    // Call the two additional APIs immediately upon button click
    const artClassNo = this.artClassNo;
    if (artClassNo) {
      console.log('Calling additional APIs with artClassNo:', artClassNo);
      
      // API 1: Get unassigned GAU subclasses
      this.subclassGAUService.getUnassignedGAUSubclasses(artClassNo).subscribe(
        (response: any) => {
          console.log('API 1 Success:', response);
          if (response && response.results) {
            this.unassignedGAU = response.results.map((item: any) => ({
              artSubclassId: item.artSubclassId,
              artSubclassNo: item.artSubclassNo,
              selected: false
            }));
            this.unassignedGAUTotal = response.meta?.total || response.results.length;
            this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;
            this.cdr.detectChanges();
            console.log('Unassigned GAU text area updated and change detection triggered');
          }
        },
        (error: any) => console.error('API 1 Error:', error)
      );
      
      // API 2: Get all subclasses including inactive
      this.subclassGAUService.getAllSubclassesIncludingInactive(artClassNo, this.limit).subscribe(
        (response: any) => {
          console.log('API 2 Success:', response);
          if (response && response.results) {
            // Create a new array reference to trigger change detection in child component
            this.artSubclassAssignments = [...response.results];
            this.total = response.meta?.total || response.results.length;
            this.searchResultsCount = `${this.total} assignment(s) found.`;
            this.cdr.detectChanges();
            console.log('Grid updated and change detection triggered');
          }
        },
        (error: any) => console.error('API 2 Error:', error)
      );
    }
    
    const associateGAURequests: any[] = [];
    const artSubclassIdList: string[] = [];

    this.organizationService
      .getOrganizationByAcronym(this.associateAcronym)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          console.log('Organization retrieved:', response);
          this.selectedValues.forEach((item) => {
            artSubclassIdList.push(item.artSubclassId);
          });

          artSubclassIdList.forEach((item) => {
            associateGAURequests.push(this.getGAURequest(item, response.results[0].organizationId));
          });

          if (associateGAURequests.length > 0) {
            this.showWait = true;
            this.subclassGAUService
              .associateGAUSubclassAssignment(associateGAURequests)
              .pipe(takeUntil(this.destroy$))
              .subscribe(
                () => {
                  console.log('GAU association successful');
                  this.showWait = false;
                  
                  this.hideMessage = false;
                  this.returnCode = '201';
                  this.returnMessage = 'Successfully associated GAU to subclass(es)';
                  
                  // Refresh the grid with updated data
                  this.subclassGAUService.getAllSubclassesIncludingInactive(this.artClassNo, this.limit).subscribe(
                    (response: any) => {
                      console.log('Grid refreshed after GAU association:', response);
                      if (response && response.results) {
                        // Create a new array reference to trigger change detection in child component
                        this.artSubclassAssignments = [...response.results];
                        this.total = response.meta?.total || response.results.length;
                        this.searchResultsCount = `${this.total} assignment(s) found.`;
                        this.cdr.detectChanges();
                        // Force child component to detect changes
                        setTimeout(() => {
                          this.cdr.markForCheck();
                        }, 0);
                        console.log('Grid updated with new GAU data and change detection triggered');
                         this.cdr.detectChanges();
                      }
                    },
                    (error: any) => console.error('Error refreshing grid after GAU association:', error)
                  );
                },
                () => {
                  console.error('GAU association failed');
                  this.showWait = false;
                }
              );
          }
          this.associateAcronym = 'P/';
          this.subclassSelectedAll = false;
          this.gauSelectText = 'Select all';
          this.selectedValues = [];
        },
        (response: any) => {
          console.error('Organization lookup failed:', response);
          this.showWait = false;
          this.hideMessage = false;
          this.accessDenied = response.accessDenied;
          this.returnCode = response.status;
          this.returnMessage = this.utilityService.processFailureMessage(
            response,
            'Organization not found'
          );
        }
      );
  }

  /**
   * Call the two additional APIs for Associate GAU button
   * API 1: Get unassigned GAU subclasses - bind to unassigned GAU text area
   * API 2: Get all subclasses including inactive - bind to grid
   */
  private callAdditionalAPIs(): void {
    // Use artClassNo from multiple sources - try displayArtClassNo first, then currentSearchOptions, then artClassNo input
    const artClassNo = this.displayArtClassNo || this.currentSearchOptions.artClassNo || this.artClassNo;
    
    if (!artClassNo) {
      console.warn('Art class number is not available for additional API calls');
      console.warn('displayArtClassNo:', this.displayArtClassNo);
      console.warn('currentSearchOptions.artClassNo:', this.currentSearchOptions.artClassNo);
      console.warn('artClassNo:', this.artClassNo);
      return;
    }

    console.log('Calling additional APIs for artClassNo:', artClassNo);

    // Call API 1: Get unassigned GAU subclasses
    // Note: Not using takeUntil here to ensure the API is called even on subsequent clicks
    this.subclassGAUService
      .getUnassignedGAUSubclasses(artClassNo)
      .subscribe(
        (response: any) => {
          console.log('API 1 Success - Unassigned GAU subclasses retrieved:', response);
          
          // Bind the response to the unassigned GAU text area
          if (response && response.results) {
            // Transform the response to extract only artSubclassId and artSubclassNo
            this.unassignedGAU = response.results.map((item: any) => ({
              artSubclassId: item.artSubclassId,
              artSubclassNo: item.artSubclassNo,
              selected: false
            }));
            this.unassignedGAUTotal = response.meta?.total || response.results.length;
            this.unassignedGAUCount = `${this.unassignedGAUTotal} record(s).`;
            this.gauFilterDisabled = false;
            console.log('Unassigned GAU text area updated. Total records:', this.unassignedGAUTotal);
          }
        },
        (error: any) => {
          console.error('API 1 Error - Failed to get unassigned GAU subclasses:', error);
        }
      );

    // Call API 2: Get all subclasses including inactive
    // Note: Not using takeUntil here to ensure the API is called even on subsequent clicks
    this.subclassGAUService
      .getAllSubclassesIncludingInactive(artClassNo, this.limit)
      .subscribe(
        (response: any) => {
          console.log('API 2 Success - All subclasses including inactive retrieved:', response);
          
          // Bind the response to the grid
          if (response && response.results) {
            // Create a new array reference to trigger change detection in child component
            this.artSubclassAssignments = [...response.results];
            this.total = response.meta?.total || response.results.length;
            this.searchResultsCount = `${this.total} assignment(s) found.`;
            this.cdr.detectChanges();
            console.log('Grid updated with API 2 response. Total records:', this.total);
          }
        },
        (error: any) => {
          console.error('API 2 Error - Failed to get all subclasses:', error);
        }
      );
  }

  associateSearchRoomAndGAU(): void {
    this.associateGAU();
    this.associateSearchRoom();
  }

  exportDataCallback(): void {
    if (this.total > 1000) {
      this.hideMessage = false;
      this.returnCode = '600';
      this.returnMessage =
        'There are more than 1000 search results. Only first 1000 records are exported to SubclassGAUAndSearchRoomAssignments.xls.';
      this.wholeMessage =
        'There are more than 1000 search results. Only first 1000 records are exported to SubclassGAUAndSearchRoomAssignments.xls. Refine the search to limit search results to less than 1000 records.';
      this.showLongMessage = true;
    }
    const url = this.controllerHelper.buildExportURL(this.currentSearchOptions);
    this.utilityService.exportTableService(
      url,
      'SubclassGAUAndSearchRoomAssignments.xls',
      'application/vnd.ms-excel'
    );
  }

  showSubclassGAULongMessage(): void {
    // Display long message in a simple alert or snackbar
    // This can be enhanced with a Material Dialog component if needed
    alert(this.wholeMessage);
  }

  toggleAccordion(): void {
    this.accordionOpen = !this.accordionOpen;
  }

  private firstPage(): void {
    // Reset to first page - this is called after operations that refresh the data
    this.currentPage = 1;
  }

  // Event handlers for search results component
  onCheckAll(): void {
    this.checkAll();
  }

  onChecked(): void {
    this.checked();
  }

  onToggleSelected(): void {
    this.toggleSelected();
  }

  onDissociateSearchRoom(): void {
    this.dissociateSearchRoom();
  }

  onDissociateBoth(): void {
    this.dissociateBoth();
  }

  onChangeDates(): void {
    this.changeDates();
  }

  onDissociateGAU(): void {
    this.dissociateGAU();
  }

  onExportData(): void {
    this.exportDataCallback();
  }

  onUpdateFn(event: any): void {
    this.getTemplateSubclassSearch(event.limit, event.skip);
  }

  /**
   * Show actual filtered results for GAU subclasses on filter button click
   */
  private showFilteredResultGAU(inputSubclass: any): void {
    const unassignedGAUList: string[] = [];
    this.unassignedGAU.forEach((unassignedGAU) => {
      unassignedGAUList.push(unassignedGAU.artSubclassNo);
    });

    let min = 0;
    let max = 10000000;
    try {
      min = parseInt(inputSubclass.content.beginSubclass, 10);
      max = parseInt(inputSubclass.content.endSubclass, 10);
    } catch (error) {
    }

    const newList: UnassignedGAU[] = [];
    unassignedGAUList.forEach((aGAU) => {
      try {
        const currentNum = parseInt(aGAU, 10);
        if (currentNum >= min && currentNum <= max) {
          const matchingGAU = this.getGAUObject(currentNum);
          if (matchingGAU) {
            newList.push(matchingGAU);
          }
        }
      } catch (error) {
      }
    });

    this.unassignedGAU = newList;
    this.unassignedGAUCount = `${newList.length} record(s)`;
    this.filterGAUText = 'Clear Filter';
  }

  /**
   * Get GAU object refreshed after filter operation
   */
  private getGAUObject(gauNum: number): UnassignedGAU | null {
    let matchingGAU: UnassignedGAU | null = null;
    this.unassignedGAU.forEach((unassignedGAU) => {
      const gauInt = parseInt(unassignedGAU.artSubclassNo, 10);
      if (gauInt === gauNum) {
        matchingGAU = unassignedGAU;
      }
    });
    return matchingGAU;
  }

  /**
   * Show actual filtered results for search room in available list
   */
  private showFilteredResultSearchRoom(inputSubclass: any): void {
    const unassignedSearchRoomList: string[] = [];
    this.unassignedSubclass.forEach((unassignedSearchRoom) => {
      unassignedSearchRoomList.push(unassignedSearchRoom.artSubclassNo);
    });

    let min = 0;
    let max = 10000000;
    try {
      min = parseInt(inputSubclass.content.beginSubclass, 10);
      max = parseInt(inputSubclass.content.endSubclass, 10);
    } catch (error) {
    }

    const newList: UnassignedSubclass[] = [];
    unassignedSearchRoomList.forEach((aSearchRoom) => {
      try {
        const currentNum = parseInt(aSearchRoom, 10);
        if (currentNum >= min && currentNum <= max) {
          const matchingSearchRoom = this.getSearchRoomObject(currentNum);
          if (matchingSearchRoom) {
            newList.push(matchingSearchRoom);
          }
        }
      } catch (error) {
      }
    });

    this.unassignedSubclass = newList;
    this.unassignedSubclassCount = `${newList.length} record(s)`;
    this.filterSearchroomText = 'Clear Filter';
  }

  /**
   * Get search room object refreshed after filter
   */
  private getSearchRoomObject(searchRoomNum: number): UnassignedSubclass | null {
    let matchingSearchRoom: UnassignedSubclass | null = null;
    this.unassignedSubclass.forEach((unassignedSearchRoom) => {
      const searchRoomInt = parseInt(unassignedSearchRoom.artSubclassNo, 10);
      if (searchRoomInt === searchRoomNum) {
        matchingSearchRoom = unassignedSearchRoom;
      }
    });
    return matchingSearchRoom;
  }

  /**
   * Open filter subclasses wizard modal
   */
  private openFilterSubclassesWizard(): void {
    const dialogRef = this.matDialog.open(FilterSubclassesDialogComponent, {
      width: '500px',
      data: {
        title: 'Filter Subclasses for GAU',
      },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.content) {
        this.showFilteredResultGAU(result);
      }
    });
  }

  /**
   * Open filter search room subclasses wizard modal
   */
  private openFilterSearchRoomSubclassesWizard(): void {
    const dialogRef = this.matDialog.open(FilterSearchRoomSubclassesDialogComponent, {
      width: '500px',
      data: {
        title: 'Filter Subclasses for Search Room',
      },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.content) {
        this.showFilteredResultSearchRoom(result);
      }
    });
  }

  onPageChanged(page: number): void {
    this.currentPage = page;
    this.skip = (page - 1) * this.limit;
    this.getTemplateSubclassSearch(this.limit, this.skip);
  }

  onPageSizeChanged(size: number): void {
    this.limit = size;
    this.currentPage = 1;
    this.skip = 0;
    this.getTemplateSubclassSearch(this.limit, this.skip);
  }
}
