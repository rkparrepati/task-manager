import { Component } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, map } from 'rxjs';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.scss'],
})
export class RootComponent {
  isNavDataLoaded: boolean = false;
  constructor(
    private router: Router,
    public appService: AppService
  ) {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        map(() => {
          let route: ActivatedRoute = this.router.routerState.root;
          while (route.firstChild) {
            route = route.firstChild;
          }
          return route;
        }),
        filter((route: ActivatedRoute) => route.outlet === 'primary'),
        map((route: ActivatedRoute) => route.snapshot.data)
        // Subscribe to the observable to update the service
      )
      .subscribe((data: any) => {
        const { breadcrumb = [] } = data || {};
        this.appService.moduleName = breadcrumb.length
          ? breadcrumb[breadcrumb.length - 1].title
          : '';
      });
  }
  navDataEventTriggered(event: any) {
    this.isNavDataLoaded = true;
  }
}
