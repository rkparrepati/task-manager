import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-role-management-grid',
  templateUrl: './role-management-grid.component.html',
  styleUrls: ['./role-management-grid.component.scss'],
})
export class RoleManagementGridComponent {
  @Input() dataSource: any = { results: [], meta: { total: 0 } };
  @Output() pageChange = new EventEmitter<{ page: number; limit: number }>();
  @Output() sortChange = new EventEmitter<Sort>();
  @Output() editRole = new EventEmitter<any>();

  limit: number = 10;
  currentPage: number = 1;
  currentSortColumn: string = 'lastName';
  currentSortDirection: string = 'asc';

  displayedColumns: string[] = [
    'status',
    'workerNumber',
    'familyName',
    'givenName',
    'preferredFirstName',
    'loginId',
    'acronym',
    'jobClass',
    'usptoRole',
    'cedrRoles',
    'actions',
  ];

  getPrimaryOrganization(organizationHistory: any[]): string {
    if (!organizationHistory) return '';
    const primaryOrg = organizationHistory.find((org) => org.primaryOrganizationIndicator);
    return primaryOrg ? primaryOrg.acronym : '';
  }

  handleEditRole(worker: any): void {
    if (worker.usptoRole?.indexOf('EnterpriseResourceAdmin') === 0) {
      this.editRole.emit(worker);
    }
  }

  onPageChanged(page: number): void {
    this.currentPage = page;
    const skip = (page - 1) * this.limit;
    this.pageChange.emit({ page: skip, limit: this.limit });
  }

  onPageSizeChanged(pageSize: number): void {
    this.limit = pageSize;
    this.currentPage = 1;
    const skip = 0;
    this.pageChange.emit({ page: skip, limit: this.limit });
  }

  onSortChange(sort: Sort): void {
    this.currentSortColumn = sort.active;
    this.currentSortDirection = sort.direction;
    this.sortChange.emit(sort);
  }
  
  clickedOnSort(event: any, columnName: string): void {
    this.currentSortColumn = columnName;
    this.currentSortDirection = event;
    const sortEvent: { active: string; direction: string } = {
      active: columnName,
      direction: event,
    };
    this.sortChange.emit(sortEvent as any);
  }
}
