import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AccessManagementHelperService } from 'src/app/services/access-management-helper.service';
import { AccessManagementService } from 'src/app/services/access-management.service';

export interface RoleEditDialogData {
  titleType?: string;
  title: string;
  button: string;
  worker: any;
}

export interface RoleAssignment {
  modifier: string;
  enabled: boolean;
}

@Component({
  selector: 'app-role-edit-dialog',
  templateUrl: './role-edit-dialog.component.html',
  styleUrls: ['./role-edit-dialog.component.scss'],
})
export class RoleEditDialogComponent implements OnInit {
  newRoleList: string[] = [];
  availableRoles: string[] = [];
  selectedAvailableRoles: string[] = [];
  selectedRoles: string[] = [];
  showValidationMessage = false;
  errorMessage = '';
  isLoading = false;

  constructor(
    public dialogRef: MatDialogRef<RoleEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: RoleEditDialogData,
    private accessManagementHelperService: AccessManagementHelperService,
    private accessManagementService: AccessManagementService
  ) {}

  ngOnInit(): void {
    this.initializeRoles();
  }

  /**
   * Initialize the role lists from worker data
   */
  private initializeRoles(): void {
    if (!this.data.worker) {
      return;
    }

    // Create a copy of the current role list
    if (this.data.worker.roleList && Array.isArray(this.data.worker.roleList)) {
      this.newRoleList = [...this.data.worker.roleList];
    }

    // Fetch available roles from API
    this.fetchAvailableRoles();
  }

  /**
   * Fetch available CEDR roles from the API endpoint
   * Calls /getAllCedrRolesGroups and populates availableRoles list
   */
  private fetchAvailableRoles(): void {
    this.isLoading = true;
    this.accessManagementService.getAllCedrRolesGroups().subscribe(
      (response: any) => {
        this.isLoading = false;
        this.buildAvailableRolesFromApi(response);
      },
      (error: any) => {
        this.isLoading = false;        // Fallback to building from rbacUser data if API fails
        this.buildDisabledList();
      }
    );
  }

  /**
   * Build available roles list from API response
   * Extracts role names from groups array and trims "Cedr" prefix
   * @param response API response containing groups array
   */
  private buildAvailableRolesFromApi(response: any): void {
    this.availableRoles = [];

    if (!response || !response.groups || !Array.isArray(response.groups)) {      // Fallback to building from rbacUser data
      this.buildDisabledList();
      return;
    }

    // Extract role names from groups and trim "Cedr" prefix
    response.groups.forEach((group: any) => {
      if (group.name) {
        // Trim "Cedr" prefix from role name
        const trimmedRole = this.trimCedrPrefix(group.name);
        
        // Only add if not already in assigned roles
        if (trimmedRole && !this.newRoleList.includes(trimmedRole)) {
          this.availableRoles.push(trimmedRole);
        }
      }
    });
  }

  /**
   * Trim "Cedr" prefix from role name
   * Example: "CedrInfraAdmin" -> "InfraAdmin"
   * @param roleName The role name to trim
   * @returns Trimmed role name without "Cedr" prefix
   */
  private trimCedrPrefix(roleName: string): string {
    if (!roleName) {
      return '';
    }
    
    // Check if role starts with "Cedr" prefix (case-sensitive)
    if (roleName.startsWith('Cedr')) {
      return roleName.substring(4); // Remove first 4 characters ("Cedr")
    }
    
    return roleName;
  }

  /**
   * Build the list of available roles that are not yet assigned
   * Fallback method when API is not available
   * Mirrors the old AngularJS implementation from roleEdit.controller.js
   */
  private buildDisabledList(): void {
    this.availableRoles = [];

    if (!this.data.worker || !this.data.worker.rbacUser) {
      return;
    }

    // Handle both old and new API formats
    if (this.data.worker.rbacUser.attributes && Array.isArray(this.data.worker.rbacUser.attributes)) {
      // Old format: attributes array with modifiers
      // Iterate through all modifiers and add only those not in newRoleList
      if (this.data.worker.rbacUser.attributes[0]?.modifiers) {
        this.data.worker.rbacUser.attributes[0].modifiers.forEach((modifier: any) => {
          if (modifier.modifier && !this.newRoleList.includes(modifier.modifier)) {
            this.availableRoles.push(modifier.modifier);
          }
        });
      }
    } else if (this.data.worker.rbacUser.modifiers && Array.isArray(this.data.worker.rbacUser.modifiers)) {
      // New format: direct modifiers array
      this.data.worker.rbacUser.modifiers.forEach((modifier: any) => {
        if (modifier.modifier && !this.newRoleList.includes(modifier.modifier)) {
          this.availableRoles.push(modifier.modifier);
        }
      });
    }
  }

  /**
   * Move selected available roles to assigned roles
   */
  moveToAssigned(): void {
    if (!this.selectedAvailableRoles || this.selectedAvailableRoles.length === 0) {
      return;
    }

    this.selectedAvailableRoles.forEach((role: string) => {
      this.newRoleList.push(role);
      const roleIndex = this.availableRoles.indexOf(role);
      if (roleIndex > -1) {
        this.availableRoles.splice(roleIndex, 1);
      }
    });

    this.selectedAvailableRoles = [];
  }

  /**
   * Move selected assigned roles back to available roles
   */
  moveToUnassigned(): void {
    if (!this.selectedRoles || this.selectedRoles.length === 0) {
      return;
    }

    this.selectedRoles.forEach((role: string) => {
      this.availableRoles.push(role);
      const roleIndex = this.newRoleList.indexOf(role);
      if (roleIndex > -1) {
        this.newRoleList.splice(roleIndex, 1);
      }
    });

    this.selectedRoles = [];
  }

  /**
   * Assign roles and validate before closing dialog
   */
  assignRoles(): void {
    this.showValidationMessage = false;
    const errorMessage = this.accessManagementHelperService.validateRoles(this.newRoleList);

    if (errorMessage) {
      this.showValidationMessage = true;
      this.errorMessage = errorMessage;
      return;
    }

    // Build the role assignments with enabled/disabled status
    const allRoles: RoleAssignment[] = [];

    // Add assigned roles with enabled=true
    this.newRoleList.forEach((role: string) => {
      allRoles.push({
        modifier: role,
        enabled: true,
      });
    });

    // Add available roles with enabled=false
    this.availableRoles.forEach((role: string) => {
      allRoles.push({
        modifier: role,
        enabled: false,
      });
    });

    this.dialogRef.close(allRoles);
  }

  /**
   * Cancel the dialog without saving
   */
  cancel(): void {
    this.dialogRef.close();
  }
}
