import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { JobClassService } from 'src/app/shared/services/job-class.service';

@Component({
  selector: 'app-rbac-advanced-search',
  templateUrl: './rbac-advanced-search.component.html',
  styleUrls: ['./rbac-advanced-search.component.scss'],
})
export class RbacAdvancedSearchComponent implements OnInit {
  @Output() public advanceSearch = new EventEmitter();
  workerModel: any;
  basicSearch: any;
  savedSearchCriteria: any;
  basicSearchText: any;
  selectedSearchCriteria: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  searchResultsCount: any;
  basicSearchAcronym: any;
  basicSearchCriteria: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  basicSearchDOBDiv: any;
  basicSearchLoginDiv: any;
  userInfo: any;
  workerNumber: any = 123;
  addWorkerButton: any;
  buildingFloors: any;
  userRoles: any = ['InfraAdmin'];
  isContractor: any;
  applicationType: any = 'Worker';
  hideFirms: any;
  cedrRoleSearch: boolean = true;
  invalidBirthDate: any;
  birthDateErrorMessage: any;
  hideBuildingSearch: any;
  acronymInvalid: any;
  acronymEnter: any;
  advanceSearchAcronym: any;
  invalidAdvancedAcronym: any;
  hidePhoneNumberSearch: any;
  jobClassCodeList: any;
  buildingCodeList: any[] = [];
  status: boolean = true;
  advanceSearchOptions: any = {};

  constructor(private jobClassService: JobClassService) {}
  ngOnInit(): void {
    this.setAdvanceSearchOptions();
    this.getJobClass();
  }
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
  getJobClass() {
    this.jobClassService.getJobClasses().subscribe((response: any) => {
      this.jobClassCodeList = response.results;
    });
  }
  setSearchType(searchType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria.value,
        },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo.workerNumber,
      };
      this.clearAdvanvedSearch();
      // this.firstPage();
    } else {
      if (this.checkBlankAdvanceSearch()) {
        this.searchResultsCount = '';
        return;
      }
      // this.savedSearchCriteria = angular.copy(this.advanceSearchOptions);
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchAcronym = '';
      // begin set default basic search to Last Name
      // angular.forEach(this.basicSearchCriteria, function (basicSearch) {
      //   if (basicSearch.value === 'workerNumber' && basicSearch.description === 'Worker number') {
      //     this.selectedSearchCriteria = basicSearch;
      //   }
      // });
      // end set default to Last Name
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
      // this.firstPage();
      // }
    }

    this.advanceSearch.emit(this.advanceSearchOptions);
  }
  checkBlankAdvanceSearch() {
    if (this.advanceSearchOptions.classCode.description) {
      return false;
    }

    if (this.advanceSearchOptions.cedrRoles.description) {
      return false;
    }

    return this.checkBlankAdvanceSearchHelper();
  }
  checkBlankAdvanceSearchHelper() {
    if (
      this.advanceSearchOptions.workerNumber.description ||
      this.advanceSearchOptions.lastName.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firstName.description ||
      this.advanceSearchOptions.preferredFirstName.description ||
      this.advanceSearchOptions.loginId.description
    ) {
      return false;
    }
    return true;
  }
  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }
  buildingChanged() {
    this.buildingFloors = [];
    const index = this.buildingCodeList.findIndex(
      (x) => this.advanceSearchOptions.buildingCode.description === x.buildingDescription
    );
    this.buildingFloors = this.buildingCodeList[index].buildingFloors;
  }
  clearAdvanvedSearch() {
    this.setAdvanceSearchOptions();
    this.advanceSearchAcronym = '';
    this.invalidAdvancedAcronym = false;
    this.acronymInvalid = false;
  }
  setAdvanceSearchOptions() {
    this.advanceSearchOptions = {
      workerNumber: {
        value: 'workerNumber',
        description: '',
      },
      lastName: {
        value: 'familyName',
        description: '',
      },
      firstName: {
        value: 'givenName',
        description: '',
      },
      preferredFirstName: {
        value: 'preferredFirstName',
        description: '',
      },
      loginId: {
        value: 'loginId',
        description: '',
      },

      classCode: {
        value: 'classCode',
        description: '',
      },
      loginWorkerNumber: {
        value: 'loginWorkerNumber',
        description: this.userInfo?.workerNumber,
      },
      cedrRoles: {
        value: 'cedrRoles',
        description: '',
      },
    };
  }
}
