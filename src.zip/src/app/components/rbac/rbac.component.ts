import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Sort } from '@angular/material/sort';
import { of } from 'rxjs';
import { catchError, finalize, switchMap } from 'rxjs/operators';

import { WorkerManagementService } from '../worker-management/worker-management.service';
import { AccessManagementService } from '../../services/access-management.service';
import { AccessManagementHelperService } from '../../services/access-management-helper.service';
import { AdvanceSearchOptions } from 'src/app/shared/interfaces/models';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { RoleDialogComponent } from './role-dialog/role-dialog.component';
import { UtilityService } from 'src/app/services/utility.service';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-rbac',
  templateUrl: './rbac.component.html',
  styleUrls: ['./rbac.component.scss'],
})
export class RbacComponent implements OnInit {
  dialog = inject(MatDialog);
  public workerRecords: any = { meta: {}, results: [] };
  otherSearchView: string = 'advanced';
  showType: string = 'active';
  loadingMessage: string = '';
  showWait: boolean = false;
  searchResultsCount: number = 0;
  disableShowRadioButton: boolean = false;
  sortColumn: string = 'lastName';
  sortDirection: string = 'asc';
  rbacUrl: string = '';
  cacheUsers: { [key: string]: any } = {};
  hideMessage: boolean = true;
  returnMessage: string = '';
  returnCode: number = 0;
  searchData: AdvanceSearchOptions = {
    birthDate: {
      description: '',
      value: 'birthDate',
    },
    buildingCode: {
      description: '',
      value: 'buildingCode',
    },
    businessAreaCode: {
      description: '',
      value: 'businessAreaCode',
    },
    cedrRoles: {
      description: '',
      value: 'cedrRoles',
    },
    classCode: {
      description: '',
      value: 'classCode',
    },
    corridorId: {
      description: '',
      value: 'corridorId',
    },
    firmAdministrator: {
      description: '',
      value: 'firmAdministrator',
    },
    firmName: {
      description: '',
      value: 'firmName',
    },
    firstName: {
      description: '',
      value: 'firstName',
    },
    floorNumber: {
      description: '',
      value: 'floorNumber',
    },
    lastName: {
      description: '',
      value: 'lastName',
    },
    loginId: {
      description: '',
      value: 'loginId',
    },
    loginWorkerNumber: {
      description: '',
      value: 'loginWorkerNumber',
    },
    phoneNumber: {
      description: '',
      value: 'phoneNumber',
    },
    preferredFirstName: {
      description: '',
      value: 'preferredFirstName',
    },
    roomId: {
      description: '',
      value: 'roomId',
    },
    shortName: {
      description: '',
      value: 'shortName',
    },
    ssn: {
      description: '',
      value: 'ssn',
    },
    ssn2: {
      description: '',
      value: 'ssn2',
    },
    suiteId: {
      description: '',
      value: 'suiteId',
    },
    workerAssociatedFirms: {
      description: '',
      value: 'workerAssociatedFirms',
    },
    workerNumber: {
      description: '',
      value: 'workerNumber',
    },
    zoneId: {
      description: '',
      value: 'zoneId',
    },
  };

  constructor(
    private workerManagementService: WorkerManagementService,
    private accessManagementService: AccessManagementService,
    private accessManagementHelperService: AccessManagementHelperService,
    private utilityService: UtilityService,
    private appService: AppService
  ) {}

  ngOnInit() {
    // Get RBAC URL from parameters
    this.workerManagementService.getParameters().subscribe({
      next: (response: any) => {
        if (response?.results) {
          const rbacParam = response.results.find((param: any) => param.parameterName === 'RBAC');
          if (rbacParam) {
            this.rbacUrl = rbacParam.parameterValueText;
          }
        }
      },
      error: (error: Error) => {      },
    });
  }

  toggleSearchView() {
    this.otherSearchView = this.otherSearchView === 'basic' ? 'advanced' : 'basic';
  }

  hideMessageDiv() {
    this.hideMessage = true;
  }

  private selectedData: any;
  public setActiveWorkerList(showIactive: boolean) {
    this.showWait = true;
    this.loadingMessage = 'Loading...';
    this.workerManagementService
      .getWorkers(
        this.showType === 'active' ? false : true,
        this.selectedData?.searchText,
        this.selectedData?.searchCriteria
      )
      .subscribe({
        next: (response) => {
          this.workerRecords = response;
          this.processWorkerRecords();
        },
        error: (error: Error) => {
          this.showWait = false;        },
      });
  }

  private processWorkerRecords() {
    if (this.workerRecords?.results) {
      // Sort by lastName by default
      this.workerRecords.results.sort((a: any, b: any) => {
        const aName = (a.familyName || '').toLowerCase();
        const bName = (b.familyName || '').toLowerCase();
        return aName.localeCompare(bName);
      });
      // Process organization and communication history
      this.workerRecords.results = this.workerRecords.results.map((worker: any) => {
        worker.primaryOrganization =
          worker.organizationHistory?.find(
            (organization: any) => organization.primaryOrganizationIndicator
          ) || {};

        worker.primaryCommunication =
          worker.communicationHistory?.find(
            (communication: any) => communication.primaryIndicator
          ) || {};

        return worker;
      });

      // Get CEDR roles
      const employeeNumbers: string[] = [];
      const cedrRoleResponse: any[] = [];

      this.workerRecords.results.forEach((worker: any) => {
        worker.cedrRole = 'No CEDR Role';
        if (this.cacheUsers[worker.workerNumber]) {
          cedrRoleResponse.push(this.cacheUsers[worker.workerNumber]);
        } else {
          employeeNumbers.push(worker.workerNumber);
        }
      });

      if (employeeNumbers.length > 0) {
        this.accessManagementService
          .getCEDRRoles(employeeNumbers, this.rbacUrl)
          .pipe(
            catchError((error) => {              return of({ data: [] });
            }),
            finalize(() => {
              this.showWait = false;
              this.searchResultsCount = this.workerRecords.meta?.total || 0;
            })
          )
          .subscribe((response) => {
            response.forEach((user: any) => {
              cedrRoleResponse.push(user);
              // Handle both old and new API response formats
              const employeeNumber = user?.user?.employeeNumber || user?.employeeNumber;
              if (employeeNumber) {
                this.cacheUsers[employeeNumber] = user;
              }
            });
            this.accessManagementHelperService.getModifierAndRole(this.workerRecords.results, {
              data: cedrRoleResponse,
            });
          });
      } else {
        this.accessManagementHelperService.getModifierAndRole(this.workerRecords.results, {
          data: cedrRoleResponse,
        });
        this.showWait = false;
        this.searchResultsCount = this.workerRecords.meta?.total || 0;
      }
    }
  }

  public searchWorkers(data: any, skip: number = 0, limit: number = 10): void {
    this.selectedData = data;
    this.showWait = true;
    this.loadingMessage = 'Searching...';
    this.workerManagementService
      .getWorkersForRoles(
        this.showType === 'active' ? false : true,
        this.selectedData.searchText,
        this.selectedData.searchCriteria,
        this.sortColumn,
        this.sortDirection,
        false,
        limit,
        skip
      )
      .subscribe({
        next: (response) => {
          this.workerRecords = response;
          this.processWorkerRecords();
        },
        error: (error: Error) => {
          this.workerRecords = { meta: {}, results: [] };
          this.showWait = false;        },
      });
  }

  public handlePageChange(event: { page: number; limit: number }): void {
    // event.page is actually the skip value calculated in role-management-grid
    if (this.otherSearchView === 'basic') {
      this.buildUrl(this.selectedData, event.page, event.limit);
    } else {
      this.searchWorkers(this.selectedData, event.page, event.limit);
    }
  }

  public handleSortChange(sort: Sort): void {
    this.sortColumn = sort.active || 'lastName';
    this.sortDirection = sort.direction || 'asc';
    // Reset to first page when sorting changes
    if (this.otherSearchView === 'basic') {
      this.buildUrl(this.selectedData, 0, 10);
    } else {
      this.searchWorkers(this.selectedData, 0, 10);
    }
  }

  public handleEditRole(worker: any): void {
    if (worker.usptoRole?.indexOf('EnterpriseResourceAdmin') === 0) {
      const dialogInfo = {
        titleType: 'text-info',
        title: 'Edit CEDR roles for ' + worker.givenName + ' ' + worker.familyName,
        button: 'Update roles',
        worker: worker,
      };

      const dialogRef = this.dialog.open(RoleDialogComponent, {
        width: '90vw',
        height: '52.5vh',
        data: dialogInfo,
      });
      dialogRef.afterClosed().subscribe((roles: any) => {
        if (roles) {
          this.saveRoles(worker, roles);
        }
      });
    }
  }
  saveRoles(worker: any, roles: any[]) {
    this.accessManagementService
      .updateCEDRRoles(worker.rbacUser, roles)
      .subscribe({
        next: (response: any) => {
          // Build roles string for success message
          const rolesString = this.getRolesString(roles);
          this.returnMessage = `CEDR Roles updated for ${worker.givenName} ${worker.familyName} ${rolesString}`;
          this.returnCode = 200;
          this.hideMessage = false;
          
          // Refresh the data to show updated roles
          if (this.otherSearchView === 'basic') {
            if (this.selectedData) {
              this.buildUrl(this.selectedData, 0, 10);
            }
          } else {
            if (this.selectedData) {
              this.searchWorkers(this.selectedData, 0, 10);
            }
          }
          
          // Scroll to top to show message
          window.scrollTo({ top: 0, behavior: 'smooth' });
        },
        error: (error: any) => {
          this.hideMessage = false;
          this.returnCode = 400;
          this.returnMessage = 'Error updating roles to RBAC';          // Scroll to top to show error message
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      });
  }

  private getRolesString(roles: any[]): string {
    let rolesString = '';
    roles.forEach((aRole: any) => {
      if (aRole.enabled) {
        rolesString += aRole.modifier + ' ';
      }
    });

    if (!rolesString) {
      return '(No CEDR roles).';
    } else {
      return '( ' + rolesString + ')';
    }
  }
  public handleAdvanceSearch(data: AdvanceSearchOptions) {
    this.showWait = true;
    this.loadingMessage = 'Searching...';
    this.searchData = data;
    this.buildUrl(data);
  }

  public exportDataCallback(): void {
    this.showWait = true;
    this.loadingMessage = 'Exporting data...';
    let url = `/workers/workerAccessManagementExcelReport?includeInactive=${this.showType === 'active'}`;
    if (this.otherSearchView === 'basic') {
      const data: AdvanceSearchOptions = this.searchData;
      if (data.birthDate?.description) {
        url += `&${data.birthDate.value}=${data.birthDate.description}`;
      }
      if (data.buildingCode?.description) {
        url += `&${data.buildingCode.value}=${data.buildingCode.description}`;
      }
      if (data.businessAreaCode?.description) {
        url += `&${data.businessAreaCode.value}=${data.businessAreaCode.description}`;
      }
      if (data.cedrRoles?.description) {
        url += `&${data.cedrRoles.value}=${data.cedrRoles.description}`;
      }
      if (data.classCode?.description) {
        url += `&${data.classCode.value}=${data.classCode.description}`;
      }
      if (data.corridorId?.description) {
        url += `&${data.corridorId.value}=${data.corridorId.description}`;
      }
      if (data.firmAdministrator?.description) {
        url += `&${data.firmAdministrator.value}=${data.firmAdministrator.description}`;
      }
      if (data.firmName?.description) {
        url += `&${data.firmName.value}=${data.firmName.description}`;
      }
      if (data.firstName?.description) {
        url += `&${data.firstName.value}=${data.firstName.description}`;
      }
      if (data.floorNumber?.description) {
        url += `&${data.floorNumber.value}=${data.floorNumber.description}`;
      }
      if (data.lastName?.description) {
        url += `&${data.lastName.value}=${data.lastName.description}`;
      }
      if (data.loginId?.description) {
        url += `&${data.loginId.value}=${data.loginId.description}`;
      }
      if (data.phoneNumber?.description) {
        url += `&${data.phoneNumber.value}=${data.phoneNumber.description}`;
      }
      if (data.preferredFirstName?.description) {
        url += `&${data.preferredFirstName.value}=${data.preferredFirstName.description}`;
      }
      if (data.roomId?.description) {
        url += `&${data.roomId.value}=${data.roomId.description}`;
      }
      if (data.shortName?.description) {
        url += `&${data.shortName.value}=${data.shortName.description}`;
      }
      if (data.ssn?.description) {
        url += `&${data.ssn.value}=${data.ssn.description}`;
      }
      if (data.ssn2?.description) {
        url += `&${data.ssn2.value}=${data.ssn2.description}`;
      }
      if (data.suiteId?.description) {
        url += `&${data.suiteId.value}=${data.suiteId.description}`;
      }
      if (data.workerNumber?.description) {
        url += `&workerNumberPrefix=${data.workerNumber.description}`;
      }
      if (data.zoneId?.description) {
        url += `&${data.zoneId.value}=${data.zoneId.description}`;
      }
    } else {
      url += this.workerManagementService.getSearchUrl(
        this.selectedData?.searchCriteria,
        this.selectedData?.searchText
      );
    }
    
    // Subscribe to the export service to hide loading indicator after completion
    this.utilityService.exportTableService1(
      url,
      'WorkerCEDRRoleBasedAccessManagement.xls',
      'application/vnd.ms-excel'
    ).pipe(
      finalize(() => {
        this.showWait = false;
      })
    ).subscribe({
      next: () => {
        // Export completed successfully
      },
      error: (error) => {        this.showWait = false;
      }
    });
  }

  private url: string = '';
  private buildUrl(data: AdvanceSearchOptions, skip: number = 0, limit: number = 10): void {
    let url = '';
    if (this.otherSearchView === 'basic') {
      if (data.birthDate?.description) {
        url += `&${data.birthDate.value}=${data.birthDate.description}`;
      }
      if (data.buildingCode?.description) {
        url += `&${data.buildingCode.value}=${data.buildingCode.description}`;
      }
      if (data.businessAreaCode?.description) {
        url += `&${data.businessAreaCode.value}=${data.businessAreaCode.description}`;
      }
      if (data.cedrRoles?.description) {
        url += `&${data.cedrRoles.value}=${data.cedrRoles.description}`;
      }
      if (data.classCode?.description) {
        url += `&${data.classCode.value}=${data.classCode.description}`;
      }
      if (data.corridorId?.description) {
        url += `&${data.corridorId.value}=${data.corridorId.description}`;
      }
      if (data.firmAdministrator?.description) {
        url += `&${data.firmAdministrator.value}=${data.firmAdministrator.description}`;
      }
      if (data.firmName?.description) {
        url += `&${data.firmName.value}=${data.firmName.description}`;
      }
      if (data.firstName?.description) {
        url += `&${data.firstName.value}=${data.firstName.description}`;
      }
      if (data.floorNumber?.description) {
        url += `&${data.floorNumber.value}=${data.floorNumber.description}`;
      }
      if (data.lastName?.description) {
        url += `&${data.lastName.value}=${data.lastName.description}`;
      }
      if (data.loginId?.description) {
        url += `&${data.loginId.value}=${data.loginId.description}`;
      }
      if (data.phoneNumber?.description) {
        url += `&${data.phoneNumber.value}=${data.phoneNumber.description}`;
      }
      if (data.preferredFirstName?.description) {
        url += `&${data.preferredFirstName.value}=${data.preferredFirstName.description}`;
      }
      if (data.roomId?.description) {
        url += `&${data.roomId.value}=${data.roomId.description}`;
      }
      if (data.shortName?.description) {
        url += `&${data.shortName.value}=${data.shortName.description}`;
      }
      if (data.ssn?.description) {
        url += `&${data.ssn.value}=${data.ssn.description}`;
      }
      if (data.ssn2?.description) {
        url += `&${data.ssn2.value}=${data.ssn2.description}`;
      }
      if (data.suiteId?.description) {
        url += `&${data.suiteId.value}=${data.suiteId.description}`;
      }
      if (data.workerNumber?.description) {
        url += `&workerNumberPrefix=${data.workerNumber.description}`;
      }
      if (data.zoneId?.description) {
        url += `&${data.zoneId.value}=${data.zoneId.description}`;
      }
    } else {
      // For non-basic search (advanced search), return early as it's handled by searchWorkers
      return;
    }
    url += `&sortColumn=${this.sortColumn}&sortOrder=${this.sortDirection}`;
    this.url = url;
    this.workerManagementService
      .getWorkersWithAdvanceSearch(this.showType === 'active' ? false : true, url, limit, skip)
      .subscribe({
        next: (response) => {
          this.workerRecords = response;
          this.processWorkerRecords();
        },
        error: (error: Error) => {
          this.workerRecords = { meta: {}, results: [] };
          this.showWait = false;        },
      });
  }
}
