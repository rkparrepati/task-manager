import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AccessManagementHelperService } from 'src/app/services/access-management-helper.service';
import { AccessManagementService } from 'src/app/services/access-management.service';

@Component({
  selector: 'app-role-dialog',
  templateUrl: './role-dialog.component.html',
  styleUrls: ['./role-dialog.component.scss'],
})
export class RoleDialogComponent implements OnInit {
  dialog = inject(MatDialog);
  data: any = inject(MAT_DIALOG_DATA);
  errorMessage: string = '';
  showValidationMessage: boolean = false;
  selectedAvailableRoles: string[] = [];
  availableRolesList: string[] = [];
  selectedRoles: string[] = [];
  selectedRolesList: string[] = [];
  isLoading: boolean = false;

  constructor(
    private dialogRef: MatDialogRef<RoleDialogComponent>,
    private accessManagementHelperService: AccessManagementHelperService,
    private accessManagementService: AccessManagementService
  ) {}

  ngOnInit(): void {
    // Build the role lists from the worker's RBAC data
    // roleList contains the currently assigned roles (enabled modifiers)
    if (this.data.worker.roleList && this.data.worker.roleList.length > 0) {
      this.selectedRolesList = this.data.worker.roleList.map((role: any) =>
        typeof role === 'string' ? role : role.modifier
      );
    }

    // Fetch available roles from API
    this.fetchAvailableRoles();
  }

  /**
   * Fetch available CEDR roles from the API endpoint
   * Calls /getAllCedrRolesGroups and populates availableRolesList
   */
  private fetchAvailableRoles(): void {
    this.isLoading = true;
    this.accessManagementService.getAllCedrRolesGroups().subscribe(
      (response: any) => {
        this.isLoading = false;
        this.buildAvailableRolesFromApi(response);
      },
      (error: any) => {
        this.isLoading = false;        // Fallback to building from rbacRoles data if API fails
        this.buildAvailableRolesFromRbac();
      }
    );
  }

  /**
   * Build available roles list from API response
   * Extracts role names from groups array and trims "Cedr" prefix
   * @param response API response containing groups array
   */
  private buildAvailableRolesFromApi(response: any): void {
    this.availableRolesList = [];

    if (!response || !response.groups || !Array.isArray(response.groups)) {      // Fallback to building from rbacRoles data
      this.buildAvailableRolesFromRbac();
      return;
    }

    // Extract role names from groups and trim "Cedr" prefix
    response.groups.forEach((group: any) => {
      if (group.name) {
        // Trim "Cedr" prefix from role name
        const trimmedRole = this.trimCedrPrefix(group.name);
        
        // Only add if not already in selected roles
        if (trimmedRole && this.selectedRolesList.indexOf(trimmedRole) < 0) {
          this.availableRolesList.push(trimmedRole);
        }
      }
    });
  }

  /**
   * Trim "Cedr" prefix from role name
   * Example: "CedrInfraAdmin" -> "InfraAdmin"
   * @param roleName The role name to trim
   * @returns Trimmed role name without "Cedr" prefix
   */
  private trimCedrPrefix(roleName: string): string {
    if (!roleName) {
      return '';
    }
    
    // Check if role starts with "Cedr" prefix (case-sensitive)
    if (roleName.startsWith('Cedr')) {
      return roleName.substring(4); // Remove first 4 characters ("Cedr")
    }
    
    return roleName;
  }

  /**
   * Build available roles list from rbacRoles data
   * Fallback method when API is not available
   */
  private buildAvailableRolesFromRbac(): void {
    this.availableRolesList = [];

    // Get all available modifiers from rbacRoles
    if (this.data.worker.rbacRoles && this.data.worker.rbacRoles[0]?.modifiers) {
      this.data.worker.rbacRoles[0].modifiers.forEach((modifier: any) => {
        const modifierName = typeof modifier === 'string' ? modifier : modifier.modifier;
        // If not in selected list, add to available list
        if (this.selectedRolesList.indexOf(modifierName) < 0) {
          this.availableRolesList.push(modifierName);
        }
      });
    }
  }

  moveToAssigned() {
    if (this.selectedAvailableRoles && this.selectedAvailableRoles.length > 0) {
      this.selectedAvailableRoles.forEach((role: string) => {
        this.selectedRolesList.push(role);
        const roleIndex = this.availableRolesList.indexOf(role);
        if (roleIndex >= 0) {
          this.availableRolesList.splice(roleIndex, 1);
        }
      });
      this.selectedAvailableRoles = [];
    }
  }

  moveToUnassigned() {
    if (this.selectedRoles && this.selectedRoles.length > 0) {
      this.selectedRoles.forEach((role: string) => {
        this.availableRolesList.push(role);
        const index = this.selectedRolesList.indexOf(role);
        if (index >= 0) {
          this.selectedRolesList.splice(index, 1);
        }
      });
      this.selectedRoles = [];
    }
  }

  assignRoles() {
    this.showValidationMessage = false;
    const errorMessage = this.accessManagementHelperService.validateRoles(this.selectedRolesList);

    if (errorMessage) {
      this.showValidationMessage = true;
      this.errorMessage = errorMessage;
      return;
    }

    // Build the complete roles array with enabled/disabled flags
    const allRoles: any[] = [];
    
    // Add selected roles as enabled
    this.selectedRolesList.forEach((modifier: string) => {
      allRoles.push({
        modifier: modifier,
        enabled: true
      });
    });

    // Add available roles as disabled
    this.availableRolesList.forEach((modifier: string) => {
      allRoles.push({
        modifier: modifier,
        enabled: false
      });
    });

    this.confirm(allRoles);
  }

  confirm(selectedRoles: any) {
    this.dialogRef.close(selectedRoles);
  }

  closeThisDialog() {
    this.dialogRef.close();
  }
}
