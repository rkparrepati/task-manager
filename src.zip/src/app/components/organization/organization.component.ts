import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrganizationService } from './services/organization.service';
import {
  OrganizationMessageService,
  SuccessMessage,
} from './services/organization-message.service';
import { Organization } from './models/organization.model';
import { AppService } from 'src/app/services/app.service';
import { AssociatedObjectsOrganizationComponent } from './associated-objects-organization/associated-objects-organization.component';
import { MatDialog } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface TreeNode {
  id: string;
  organization: Organization;
  name: string;
  showChildren: boolean;
  selected: boolean;
  loaded: boolean;
  root: boolean;
  showFamily: boolean;
  hasChildren: boolean;
  icon: string;
  toggleLabel: string;
  inactive: boolean;
  isDisabled: string;
  parentInactive?: boolean;
  pleaseWait?: string;
  children: TreeNode[];
  parentName?: string;
}

@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.scss'],
})
export class OrganizationComponent implements OnInit, OnDestroy {
  appTitle = 'Organization Management';
  moduleName = 'Organization Management';
  updateButtonDisabled = true;
  addButtonDisabled = true;
  loadingMessage = 'Loading organization...';
  showType = 'active';
  selectedNode: any;
  treeFamily: TreeNode | null = null;
  theSearchTerm = '';
  termToSearch: string = '';
  acronym = '';
  acronymError = false;
  searchResults = '';
  searchResultsMode = 0;
  showWait = false;
  hasError: boolean = true;
  returnCode: number = 0;
  returnMessage = '';
  accessDenied = false;
  currentReactivating = false;
  selectedOrg: TreeNode | null = null;
  organizationMatched: Organization | null = null as any;
  searchOrg: TreeNode | null = null;
  orgsNeeded: TreeNode[] = [];
  orgsToOpen: TreeNode[] | null = null;
  hideResultMessage: boolean = false;
  successMessage: string = '';
  showSuccessMessage: boolean = false;
  changedFields: string[] = [];
  recentlyUpdatedOrgId: string = '';
  highlightTimeout: any;
  private destroy$ = new Subject<void>();
  private dialogOpen = false;

  constructor(
    public appService: AppService,
    private organizationService: OrganizationService,
    private organizationMessageService: OrganizationMessageService,
    private route: ActivatedRoute,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.subscribeToSuccessMessage();
    this.getOrganizationTree();
  }

  ngOnDestroy(): void {
    // Clear success message when leaving the component
    this.hideSuccessMessage();
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Subscribe to success message from organization-add-update component
   */
  subscribeToSuccessMessage(): void {
    this.organizationMessageService.successMessage$
      .pipe(takeUntil(this.destroy$))
      .subscribe((message: SuccessMessage) => {
        // Only show message if it's not empty (ignore cleared messages)
        if (!message.message || message.message.trim().length === 0) {
          this.showSuccessMessage = false;
          this.hasError = false;
          return;
        }
        const successMessage = `Organization ${message.code} ${message.mode}d successfully`;
        this.successMessage = message.message;
        this.changedFields = message.changedFields || [];
        this.recentlyUpdatedOrgId = message.organizationId;
        this.showSuccessMessage = true;
        this.returnCode = 200;
        this.returnMessage = message.message;
        this.hasError = true;
        
        if(successMessage === this.successMessage && message.mode === 'update') {
          this.acronym = message.code;
        }
        // Auto-hide success message after 5 seconds
        // setTimeout(() => {
        //   this.hideSuccessMessage();
        // }, 5000);
        // Remove highlight after 10 seconds
        // if (this.highlightTimeout) {
        //   clearTimeout(this.highlightTimeout);
        // }
        // this.highlightTimeout = setTimeout(() => {
        //   this.recentlyUpdatedOrgId = '';
        // }, 10000);
      });
  }

  /**
   * Hide success message
   */
  hideSuccessMessage(): void {
    this.showSuccessMessage = false;
    this.successMessage = '';
    this.changedFields = [];
    this.returnMessage = '';
    this.hasError = false;
    // Clear the message from the service to prevent replay on navigation
    this.organizationMessageService.clearSuccessMessage();
    // Keep highlight for a bit longer after message hides
    if (this.highlightTimeout) {
      clearTimeout(this.highlightTimeout);
    }
    this.highlightTimeout = setTimeout(() => {
      this.recentlyUpdatedOrgId = '';
    }, 5000);
  }

  public searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.search();
      event.stopPropagation();
    }
  }

  searchAcronym(): void {
    if (this.termToSearch != this.acronym) {
      this.showWait = true;
      setTimeout(() => {
        this.showWait = false;
      }, 1000);
    }
    const searchTerm = this.acronym;
    if (!searchTerm || searchTerm.trim().length < 2) {
      this.searchResults = 'Please enter at least 2 characters';
      this.searchResultsMode = 1;
      return;
    }
    this.termToSearch = searchTerm;
  }
  /**
   * Builds the initial tree. Loading the root and its children.
   */
  getOrganizationTree(): void {
    this.resetTimeout();
    this.updateButtonDisabled = true;
    this.addButtonDisabled = true;

    const includeInactive = this.showType === 'all';
    this.organizationService.getOrganizationsRoot(includeInactive).subscribe(
      (response: Organization[]) => {
        this.treeFamily = {
          organization: response[0],
          name:
            response[0].organizationType.businessArea.code.trim() +
            '/' +
            response[0].shortName.trim() +
            ' ' +
            response[0].organizationName.trim(),
          showChildren: true,
          id: response[0].organizationType.businessArea.code.trim() + response[0].shortName.trim(),
          showFamily: true,
          root: true,
          inactive: false,
          selected: false,
          loaded: true,
          icon: 'fa-plus-square-o',
          toggleLabel: 'Expand',
          hasChildren: false,
          isDisabled: '',
          children: [],
        };

        if (this.treeFamily) {
          this.getOrganizationChildren(this.treeFamily);
        }
      },
      (error) => {
        this.checkSecurityViolation(error);
      }
    );
  }

  /**
   * Call services to load the children of a tree node or family.
   */
  getOrganizationChildren(family: TreeNode): void {
    this.resetTimeout();
    this.showWait = true;
    const includeInactive = this.showType === 'all';
    this.organizationService
      .getOrganizationChildren(family.organization.organizationId, includeInactive)
      .subscribe(
        (response: any) => {
          family.loaded = true;
          response.results.forEach((node: Organization) => {
            const child: TreeNode = {
              id: node.organizationType.businessArea.code.trim() + node.shortName.trim(),
              organization: node,
              name:
                node.organizationType.businessArea.code.trim() +
                '/' +
                node.shortName.trim() +
                ' ' +
                node.organizationName.trim(),
              parentName: family.organization.organizationName,
              showChildren: false,
              selected: false,
              loaded: false,
              root: false,
              showFamily: true,
              hasChildren: false,
              icon: 'fa-plus-square-o',
              toggleLabel: 'Expand',
              inactive: false,
              isDisabled: '',
              children: [],
            };

            if (child.id !== 'UDIR' && !this.isDuplicate(family, child)) {
              child.hasChildren = node.hasChild || false;
              this.setChildProperties(node, child, family);
              family.children.push(child);
            }
          });
          this.showWait = false;
          this.processSaveOrg();
        },
        (error) => {
          this.checkSecurityViolation(error);
        }
      );
  }

  /**
   * Determines if this page came from add/update page during a save operation.
   */
  processSaveOrg(): void {
    const params = this.route.snapshot.params;
    if (params['mode']) {
      this.organizationService.getOrganization(params['organizationId']).subscribe(
        (savedOrg: Organization) => {
          this.returnMessage =
            'Organization ' +
            savedOrg.organizationType.businessArea.code.trim() +
            '/' +
            savedOrg.shortName.trim() +
            ' ' +
            params['mode'] +
            ' successfully';
          this.hasError = true;
          this.returnCode = 200;
          const acronym =
            savedOrg.organizationType.businessArea.code.trim() + '/' + savedOrg.shortName.trim();
          this.searchWithTerm(acronym.substring(0, 1), acronym.substring(2));
        },
        (error) => {
          this.checkSecurityViolation(error);
        }
      );
    }
  }

  /**
   * Checks if a child is a duplicate in the family.
   */
  isDuplicate(family: TreeNode, child: TreeNode): boolean {
    return family.children.some((aChild) => aChild.id === child.id);
  }

  /**
   * Sets child properties including if the child is currently inactive.
   */
  setChildProperties(node: Organization, child: TreeNode, family: TreeNode): void {
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle.endDate || '');

    if (endDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        child.inactive = true;
        child.parentInactive = family.inactive;
        child.isDisabled = 'disabled';
        child.name += ' - inactive';
      }
    }
  }

  /**
   * Hides the user messages.
   */
  hideMessageDiv(): void {
    this.hasError = false;
    this.returnMessage = '';
    this.returnCode = 0;
  }

  /**
   * Sets the search term and then calls search. Invoked from Search button
   */
  search(): void {
    if (this.treeFamily) {
      this.deselectAll(this.treeFamily);
    }
    this.hasError = false;
    if (this.acronym.length < 3) {
      this.acronymError = true;
      return;
    }
    this.searchWithTerm(this.acronym.substring(0, 1), this.acronym.substring(2));
  }

  /**
   * Sets matched organization from search results.
   */
  setMatchedOrganization(results: Organization[], shortName: string): void {
    results.forEach((organization) => {
      if (organization.shortName.trim() === shortName) {
        this.organizationMatched = organization;
      }
    });
  }

  /**
   * Calls Organization service to find organization from search term.
   */
  searchWithTerm(businessArea: string, shortName: string): void {
    this.resetTimeout();
    this.acronymError = false;
    this.theSearchTerm = businessArea + '/' + shortName;

    const includeInactive = this.showType === 'all';
    this.organizationService
      .searchOrganizations(businessArea, shortName, includeInactive)
      .subscribe(
        (response: any) => {
          this.organizationMatched = null;
          this.setMatchedOrganization(response.results, shortName);
          if (this.showType === 'active' && this.checkInactive(this.organizationMatched)) {
            this.acronym = '';
            this.searchResults = 'No active organization found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
            return;
          }

          if (this.treeFamily && this.organizationMatched) {
            const foundOrg = this.findOrgById(
              this.treeFamily.children,
              (this.organizationMatched as any).organizationId
            );
            this.searchOrg = foundOrg;
            this.processFoundOrg(foundOrg, response);
          }
        },
        (error) => {
          if (!this.checkSecurityViolation(error)) {
            this.acronym = '';
            this.searchResults = 'No match found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
          }
        }
      );
  }

  /**
   * Processes found organization.
   */
  processFoundOrg(foundOrg: TreeNode | null, response: any): void {
    if (foundOrg) {
      this.openAncestor(foundOrg);
      if (foundOrg.selected) {
        this.openAncestor(foundOrg);
        if (foundOrg.selected) {
          this.openAncestor(foundOrg);
          setTimeout(() => {
            this.updateButtonDisabled = false;
            this.addButtonDisabled = false;
          }, 100);
          return;
        }
        this.selectOrganization(foundOrg);
        setTimeout(() => {
          this.updateButtonDisabled = false;
          this.addButtonDisabled = false;
        }, 100);
        this.acronym = '';
      }
    } else {
      const aFamily: TreeNode = {
        id: '',
        children: [],
        organization: {} as Organization,
        name: '',
        showChildren: false,
        selected: true,
        loaded: false,
        root: false,
        showFamily: false,
        hasChildren: false,
        icon: '',
        toggleLabel: '',
        inactive: false,
        isDisabled: '',
      };
      aFamily.organization.organizationId = response.results[0].parentOrganization.id;
      this.searchOrg = aFamily;
      this.loadAncestors(response.results[0].parentOrganization.id);
    }
  }

  /**
   * Checks if organization is inactive.
   */
  checkInactive(node: Organization | null): boolean {
    if (!node) return false;
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle.endDate || '');

    if (endDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        return true;
      }
    }
    return false;
  }

  /**
   * Clear search results
   */
  clearSearchResults(): void {
    this.searchResultsMode = 0;
    this.acronym = '';
  }

  /**
   * Loads the parent of the passed in id. If not in tree, recursively goes up the tree.
   */
  loadAncestors(parentId: string): void {
    this.organizationService.getOrganization(parentId).subscribe(
      (organization: Organization) => {
        const aFamily: TreeNode = {
          id: '',
          children: [],
          organization: organization,
          name: '',
          showChildren: false,
          selected: false,
          loaded: false,
          root: false,
          showFamily: false,
          hasChildren: false,
          icon: '',
          toggleLabel: '',
          inactive: false,
          isDisabled: '',
        };
        this.orgsNeeded.push(aFamily);
        let currentOrg;

        if (organization.organizationId === organization.parentOrganization.id) {
          this.orgsToOpen = this.orgsNeeded;
          this.loadTreeBranches();
          return;
        } else if (this.treeFamily) {
          currentOrg = this.findOrgById(
            this.treeFamily.children,
            organization.parentOrganization.id
          );
        }

        if (currentOrg !== null && currentOrg !== undefined) {
          this.orgsNeeded.push(currentOrg);
          this.orgsToOpen = this.orgsNeeded;
          this.loadTreeBranches();
        } else {
          this.loadAncestors(organization.parentOrganization.id);
        }
      },
      (error) => {
        this.checkSecurityViolation(error);
      }
    );
  }

  /**
   * Once we have all the ancestors, we get all the children
   */
  loadTreeBranches(): void {
    if (this.orgsNeeded.length > 0) {
      const orgToLoad = this.orgsNeeded.pop();
      if (orgToLoad) {
        this.getOrganizationChildren(orgToLoad);
      }
      setTimeout(() => {
        if (this.orgsNeeded.length > 0) {
          this.loadTreeBranches();
        } else {
          if (this.searchOrg && this.treeFamily) {
            const theOrg = this.findOrgById(
              this.treeFamily.children,
              this.searchOrg.organization.organizationId
            );
            if (theOrg !== null) {
              this.getOrganizationChildren(theOrg);
            }
          }
          this.searchWithTerm(this.acronym.substring(0, 1), this.acronym.substring(2));
        }
      }, 100);
    }
  }

  /**
   * Opens the parent of the passed in family (tree node)
   */
  openAncestor(family: TreeNode): void {
    family.selected = true;
    let foundRoot = false;
    let parentId = family.organization.parentOrganization.id;
    let count = 0;

    if (this.treeFamily && parentId === this.treeFamily.organization.organizationId) {
      foundRoot = true;
    }

    while (!foundRoot) {
      count++;
      if (count > 20) {
        foundRoot = true;
      }

      if (this.treeFamily) {
        const ancestor = this.findOrgById(this.treeFamily.children, parentId);
        if (!ancestor || ancestor.root || ancestor.id === 'UDIR') {
          foundRoot = true;
        } else {
          this.toggleOrganizationFolder(ancestor, true);
          ancestor.showChildren = true;
          parentId = ancestor.organization.parentOrganization.id;
        }
      }
    }
  }

  /**
   * User switched show all/ show active radio buttons
   */
  toggleActiveAllOrganization(): void {
    this.hideMessageDiv();
    this.clearSearchResults();
    this.acronym = '';
    this.updateButtonDisabled = false;
    this.addButtonDisabled = false;
    this.getOrganizationTree();
  }

  /**
   * Open/close organization folder
   */
  toggleOrganizationFolder(family: TreeNode, open?: boolean): void {
    if (open) {
      family.showChildren = true;
      family.icon = 'fa-minus-square-o';
      family.toggleLabel = 'Collapse';
    } else {
      family.showChildren = !family.showChildren;

      if (family.showChildren) {
        family.icon = 'fa-minus-square-o';
        family.toggleLabel = 'Collapse';
      } else {
        family.icon = 'fa-plus-square-o';
        family.toggleLabel = 'Expand';
      }

      if (!family.loaded) {
        this.getOrganizationChildren(family);
        family.showChildren = true;
        family.icon = 'fa-minus-square-o';
        family.toggleLabel = 'Collapse';
      }
    }
  }

  /**
   * Called when user clicks on a tree label (node)
   */
  selectOrganization(selectedOrganization: TreeNode): void {
    if (!selectedOrganization.selected) {
      if (this.treeFamily) {
        this.deselectAll(this.treeFamily);
      }
    }

    selectedOrganization.selected = !selectedOrganization.selected;

    if (selectedOrganization.selected) {
      this.updateButtonDisabled = false;
      this.addButtonDisabled = false;
    } else {
      this.updateButtonDisabled = true;
      this.addButtonDisabled = true;
    }
  }

  /**
   * Deselects all tree nodes.
   */
  deselectAll(aOrganization: TreeNode): void {
    aOrganization.selected = false;
    this.selectedOrg = null;
    aOrganization.children.forEach((organization) => {
      organization.selected = false;
      if (organization.loaded && organization.hasChildren) {
        this.deselectAll(organization);
      }
    });
  }

  /**
   * Finds the selected tree node (organization)
   */
  findSelected(aOrganization: TreeNode): void {
    aOrganization.children.forEach((organization) => {
      if (organization.selected) {
        this.selectedOrg = organization;
      } else {
        if (organization.loaded && organization.hasChildren) {
          this.findSelected(organization);
        }
      }
    });
  }

  /**
   * Edit button event
   */
  editSelectedOrganization(): void {
    if (this.treeFamily && this.treeFamily.selected) {
      this.editOrganization();
      return;
    }
    if (this.treeFamily) {
      this.findSelected(this.treeFamily);
    }
    if (this.selectedOrg !== null) {
      this.editOrganization();
    }
  }

  /**
   * Add child organization
   */
  organizationAddChild(): void {
    if (this.treeFamily && this.treeFamily.selected) {
      this.addOrganization();
      return;
    }
    if (this.treeFamily) {
      this.findSelected(this.treeFamily);
    }
    if (this.selectedOrg !== null) {
      this.addOrganization();
    }
  }

  /**
   * Finds the organization by id
   */
  findOrgById(children: TreeNode[], organizationId: string): TreeNode | null {
    let orgFound: TreeNode | null = null;
    if (children) {
      for (const organization of children) {
        if (orgFound === null) {
          if (organization.organization.organizationId === organizationId) {
            orgFound = organization;
          } else {
            orgFound = this.findOrgById(organization.children, organizationId);
          }
        }
      }
    }
    return orgFound;
  }

  /**
   * Inactivate organization
   */
  inactivate(node: TreeNode): void {
    // Implementation for inactivate
  }

  /**
   * Reactivate organization
   */
  reactivate(node: TreeNode): void {
    // Implementation for reactivate
  }

  /**
   * Reset timeout
   */
  resetTimeout(): void {
    // Implementation for timeout reset
  }

  /**
   * Check security violation
   */
  checkSecurityViolation(response: any): boolean {
    if (response.status === 403) {
      this.returnCode = response.status;
      this.hasError = true;
      this.accessDenied = response.accessDenied;
      return true;
    }
    return false;
  }

  /**
   * Node operations
   */
  nodeOps(node: TreeNode): void {
    if (node) {
      this.toggleOrganizationFolder(node);
    }
  }

  /**
   * Select node
   */
  select(node: TreeNode): void {
    this.selectOrganization(node);
  }

  /**
   * Add node
   */
  add(node: TreeNode): void {
    this.addOrganization();
  }

  /**
   * Update node
   */
  update(node: TreeNode): void {
    this.editOrganization();
  }
  inactivateOrganization(node: any) {
    const _node = {
      organization: node,
    };
    this.organizationService.inActivateOrganization(_node).subscribe(
      (response: any) => {
        this.returnCode = 200;
        this.returnMessage =
          'Successfully inactivated ' + node.name + '. Also all children are inactivated.';
        this.hasError = true;
        this.getOrganizationTree();
      },
      (error: any) => {
        this.returnCode = error.status;
        this.returnMessage = error.error.message;
        this.hasError = true;
        this.showAssociatedObject(node, error);
      }
    );
  }

  reactivateOrganization(node: any) {
    // First fetch the complete organization data to get the audit/lockControlNumber
    this.organizationService.getOrganization(node.organizationId as any).subscribe(
      (response: any) => {
        const completeOrg = response.results ? response.results[0] : response;
        this.organizationService.reactivateOrganization(completeOrg).subscribe(
          (reactivateResponse: any) => {
            this.returnCode = 200;
            const fullName = completeOrg.organizationType.businessArea.code.trim() + '/' +
                             completeOrg.shortName.trim() + ' ' +
                             completeOrg.organizationName.trim();
            this.returnMessage =
              'Successfully reactivated ' + fullName + '.';
            this.hasError = true;
            this.getOrganizationTree();
          },
          (error: any) => {
            this.returnCode = error.status;
            this.returnMessage = error.error.message;
            this.hasError = true;
          }
        );
      },
      (error: any) => {
        this.returnCode = error.status;
        this.returnMessage = error.error.message;
        this.hasError = true;
      }
    );
  }
  showAssociatedObject(node: any, error: any) {
    if (this.dialogOpen) {
      return;
    }
    this.dialogOpen = true;

    const dialogRef = this.dialog.open(AssociatedObjectsOrganizationComponent, {
      width: '730px',
      maxHeight: '80vh',
      data: { error, node },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      this.dialogOpen = false;
      // this.hasError = false;
      if (result) {
      }
    });
  }
  childSelectedEvent(node: any) {
    this.selectedNode = node;
    this.updateButtonDisabled = false;
    this.addButtonDisabled = false;
  }

  editOrganization(): void {
    this.appService.changePage(`/app/organization/update/${this.selectedNode.organizationId}`);
  }

  /**
   * Add is selected on the tree.
   */
  addOrganization(): void {
    this.appService.changePage(`/app/organization/add/${this.selectedNode.organizationId}`);
  }
}
