import {
  Component,
  EventEmitter,
  Inject,
  OnInit,
  Output,
  ViewChild,
  OnDestroy,
  Input,
} from '@angular/core';
// import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { FlatTreeControl } from '@angular/cdk/tree';
import { of, Subject } from 'rxjs';
import { takeUntil, map, catchError, audit } from 'rxjs/operators';
import { AcronymInputComponent } from 'src/app/shared/components/acronym-input/acronym-input.component';
// import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { AppService } from 'src/app/services/app.service';
import { DialogComponent } from '../../relocation-management/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../../core/confirmation-dialog/confirmation-dialog.component';
import { ReactivateOrganizationConfirmDialogComponent } from '../reactivate-organization-confirm-dialog/reactivate-organization-confirm-dialog.component';
import { OrganizationMessageService } from '../services/organization-message.service';

interface OrganizationNode {
  name: string;
  organizationId: string;
  children?: OrganizationNode[];
  organizationType?: any;
  shortName?: string;
  organizationName?: string;
  hasChild?: boolean;
  lifecycle?: any;
  parentOrganization?: any;
  inactive?: boolean;
}

interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  node: any;
  organizationId: string;
  level: number;
}

@Component({
  selector: 'app-organization-tree',
  templateUrl: './organization-tree.component.html',
  styleUrls: ['./organization-tree.component.scss'],
})
export class OrganizationTreeComponent implements OnInit, OnDestroy {
  @Output() inactiveOrganization = new EventEmitter<any>();
  @Output() reactivateOrganizationEvent = new EventEmitter<any>();
  @Output() childSelectedEvent = new EventEmitter<any>();
  @Input() family: any;
  @Input() recentlyUpdatedOrgId: string = '';
  private _showType: string = 'active';
  get showTypeValue(): string {
    return this._showType;
  }
  @Input() set showType(showType: string) {
    this._showType = showType;
    this.includeInactive = showType === 'all' ? 'true' : 'false';
    this.orgDataSource = [];
    this.dataSource.data = [];
    this.getOrganizationTree();
  }
  @Input() set searchAcronymTerm(searchTerm: string) {
    if (!searchTerm || searchTerm.trim().length < 2) {
      this.searchResults = 'Please enter at least 2 characters';
      this.searchResultsMode = 1;
      return;
    }
    // Parse acronym format: "C/ABC" -> businessAreaCode="C", shortName="ABC"
    let businessAreaCode = 'C'; // Default
    let shortName = searchTerm.toUpperCase();

    if (searchTerm.includes('/')) {
      const parts = searchTerm.split('/');
      businessAreaCode = parts[0].trim().toUpperCase();
      shortName = parts[1].trim().toUpperCase();
    } else if (searchTerm.length === 1) {
      // If only one letter provided, treat it as businessAreaCode
      businessAreaCode = searchTerm.trim().toUpperCase();
      shortName = '';
    }

    this.searchWithTerm(businessAreaCode, shortName);
  }
  @Output() onSearchClicked = new EventEmitter<string>();
  selectMode: boolean = false;
  public orgDataSource: any[] = [];
  includeInactive: string = 'false';
  title: string = '';
  buttontext: string = '';
  selectOrganizationInfo: { button: string; title: string } = { button: 'Update', title: 'Test' };
  hideResultMessage = false;
  buttonsVisible: boolean = false;
  searchResultsMode = 0;
  updateButtonDisabled = true;
  message: string = '';
  cancelButtonText = 'Cancel';
  acronym: string = '';
  selectedOrganization: any = null;
  searchResults: string = '';
  organizationMatched: any = null;
  searchOrg: any = null;
  orgsNeeded: any[] = [];
  orgsToOpen: any[] = [];
  traverseOrgsIds: any[] = [];
  theSearchTerm: string = '';
  now: Date = new Date();
  private destroy$ = new Subject<void>();

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    (node) => node.level,
    (node) => node.expandable
  );

  private _transformer = (node: any, level: number) => {
    return {
      expandable: !!node.hasChild,
      name:
        node.name ||
        `${node.organizationType.businessArea.code.trim()}/${node.shortName.trim()} ${node.organizationName.trim()}`,
      organizationId: node.organizationId,
      level: level,
      node: node,
    };
  };

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    (node) => node.level,
    (node) => node.expandable,
    (node) => node.children
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  @ViewChild('acronymInput', { static: false }) vcAcronym!: AcronymInputComponent;

  public constructor(
    // @Inject(MAT_DIALOG_DATA) public data: any,
    // private dialogRef: MatDialogRef<OrganizationSelectTreeDialogComponent>,
    private organizationService: OrganizationService,
    private appService: AppService,
    public dialog: MatDialog,
    private organizationMessageService: OrganizationMessageService
  ) {
    // const data;
    // if (data) {
    //   this.buttonsVisible = this.data.buttonsVisible;
    //   this.message = data.message || this.message;
    //   this.title = data.title || this.title;
    //   this.buttontext = data.button || this.buttontext;
    //   if (data.buttonText) {
    //     this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
    //   }
    // }
  }

  ngOnInit(): void {
    this.populateDropdowns();
    this.getOrganizationTree();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Load the root Organization
   */
  private getOrganizationTree(): void {
    // Load root organization
    this.organizationService
      .getOrganizationsRoot(this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response && response.results && response.results.length > 0) {
            this.getOrganizationChildrenForInit(response.results[0]);
          }
        },
        (error: any) => {
        }
      );
  }

  private getOrganizationChildrenForInit(organization: any): void {
    this.organizationService
      .getChildOrganizations(+organization.organizationId, this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          const children = (response.results || []).map((node: any) => {
            const child = {
              organizationId: node.organizationId,
              organizationType: node.organizationType,
              shortName: node.shortName,
              organizationName: node.organizationName,
              name:
                node.organizationType.businessArea.code.trim() +
                '/' +
                node.shortName.trim() +
                ' ' +
                node.organizationName.trim(),
              hasChild: node.hasChild || false,
              lifecycle: node.lifecycle,
              parentOrganization: node.parentOrganization,
              children: [],
            };
            this.setChildProperties(node, child);
            return child;
          });

          Object.assign(organization, { children: children });
          this.orgDataSource = [organization];
          this.dataSource.data = [organization];
          // Expand only the root node, keep children collapsed
          if (this.treeControl.dataNodes.length > 0) {
            const rootNode = this.treeControl.dataNodes[0];
            if (rootNode && !this.treeControl.isExpanded(rootNode)) {
              this.treeControl.expand(rootNode);
            }
          }
        },
        (error: any) => {
        }
      );
  }


  /**
   * Set the child properties on the Tree node
   */
  private setChildProperties(node: any, child: any): void {
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle?.endDate || 0);

    if (endDate && endDate > beginningValueDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        child.inactive = true;
        child.name += ' - inactive';
      }
    }
  }

  /**
   * Check if organization is inactive
   */
  private checkInactive(node: any): boolean {
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle?.endDate || 0);

    if (endDate && endDate > beginningValueDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        return true;
      }
    }
    return false;
  }

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  // Click on acronym name - highlights it for confirmation with Select button
  public selectNodeForConfirmation(node: any): void {
    if (!node.node.hasChild) {
      this.selectedNoChildNode(node);
    }
    if (
      this.selectedOrganization &&
      this.selectedOrganization.organizationId === node.organizationId
    ) {
      this.selectedOrganization = {};
      return;
    }
    this.selectedOrganization = node.node;
    this.updateButtonDisabled = false;
  }

  // Click on hand icon - immediately selects and closes dialog
  public selectNodeImmediately(node: any): void {
    this.selectedOrganization = node.node;
    // this.dialogRef.close(node.node);
  }

  // Check if a node is currently selected (for highlighting)
  public isNodeSelected(node: any): boolean {
    return (
      this.selectedOrganization && this.selectedOrganization.organizationId === node.organizationId
    );
  }

  // Check if a node was recently updated (for highlighting)
  public isNodeRecentlyUpdated(node: any): boolean {
    return !!(this.recentlyUpdatedOrgId && this.recentlyUpdatedOrgId === node.organizationId);
  }

  // Select button click - confirms the selection
  public selectAndClose(): void {
    if (this.selectedOrganization) {
      // this.dialogRef.close(this.selectedOrganization);
    }
  }

  // Apply role organisation button click
  public applyRoleOrganization(): void {
    if (this.selectedOrganization) {
      // this.dialogRef.close(this.selectedOrganization);
    }
  }

  // Legacy method - kept for compatibility
  public handleSelectedNode(node: any): void {
    this.selectNodeForConfirmation(node);
  }

  public organizationSelected(): void {}

  public toggleNode(node: any): void {
    if (this.treeControl.isExpanded(node)) {
      // Collapse the node
      this.treeControl.collapse(node);
    } else {
      // Check if children are already loaded
      if (node.node.children && node.node.children.length > 0) {
        // Children already loaded, just expand
        this.treeControl.expand(node);
      } else {
        // Children not loaded, fetch them first
        this.populateChildNodes(node);
      }
    }
  }

  public populateChildNodes(node: any): void {
    this.organizationService
      .getChildOrganizations(+node.organizationId, this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe((child: any) => {
        const childNodes = (child.results || []).map((childNode: any) => {
          // Create child node with all necessary properties
          const newNode: any = {
            organizationId: childNode.organizationId,
            organizationType: childNode.organizationType,
            shortName: childNode.shortName,
            organizationName: childNode.organizationName,
            lifecycle: childNode.lifecycle,
            parentOrganization: childNode.parentOrganization,
            isInActive: this.checkIsInactive(childNode.lifecycle),
            hasChild: childNode.hasChild || false,
            children: [], // Initialize empty children array for nested expansion
            name:
              childNode.organizationType.businessArea.code.trim() +
              '/' +
              childNode.shortName.trim() +
              ' ' +
              childNode.organizationName.trim(),
          };

          this.setChildProperties(childNode, newNode);
          return newNode;
        });

        // Store currently expanded node IDs and scroll position
        const expandedNodeIds = this.treeControl.expansionModel.selected.map(
          (n) => n.organizationId
        );

        // Update the underlying data node
        if (node.node) {
          node.node.children = childNodes;
        }

        // Update the data source
        this.findAndUpdateNode(this.orgDataSource, node.organizationId, childNodes);

        // Trigger change detection by creating new array reference
        this.dataSource.data = [...this.orgDataSource];

        // Restore expansion state and scroll position after data update
        requestAnimationFrame(() => {
          // Find and expand previously expanded nodes
          expandedNodeIds.forEach((orgId) => {
            const nodeToExpand = this.treeControl.dataNodes.find((n) => n.organizationId === orgId);
            if (nodeToExpand && !this.treeControl.isExpanded(nodeToExpand)) {
              this.treeControl.expand(nodeToExpand);
            }
          });

          // Find the updated node by organizationId and expand it
          const updatedNode = this.treeControl.dataNodes.find(
            (n) => n.organizationId === node.organizationId
          );
          if (updatedNode && !this.treeControl.isExpanded(updatedNode)) {
            this.treeControl.expand(updatedNode);
          }

          // Scroll to the element
          setTimeout(() => {
            const element = document.getElementById(node.node.organizationId);
            if (element) {
              element.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
          }, 0);
        });
      });
  }

  removeChildren(nodes: OrganizationNode[], orgId: any): OrganizationNode[] {
    return nodes.map((node) => {
      if (node.organizationId === orgId) {
        return { ...node, children: [] };
      }
      if (node.children && node.children.length > 0) {
        return { ...node, children: this.removeChildren(node.children, orgId) };
      }
      return node;
    });
  }

  deleteChildNodes(node: any): void {
    const orgId = node.organizationId;
    const data = this.removeChildren(this.orgDataSource, orgId);
    this.orgDataSource = data;
    this.dataSource.data = data;
  }

  findAndUpdateNode(
    dataSource: OrganizationNode[],
    id: string,
    childNodes: OrganizationNode[]
  ): boolean {
    for (let node of dataSource) {
      if (node.organizationId === id) {
        node.children = [...childNodes];
        return true;
      }
      if (node.children && node.children.length > 0) {
        const found = this.findAndUpdateNode(node.children, id, childNodes);
        if (found) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Search button listener - handles acronym search
   */
  search(): void {
    const searchTerm = this.acronym;

    if (!searchTerm || searchTerm.trim().length < 2) {
      this.searchResults = 'Please enter at least 2 characters';
      this.searchResultsMode = 1;
      return;
    }

    // Parse acronym format: "C/ABC" -> businessAreaCode="C", shortName="ABC"
    let businessAreaCode = 'C'; // Default
    let shortName = searchTerm.toUpperCase();

    if (searchTerm.includes('/')) {
      const parts = searchTerm.split('/');
      businessAreaCode = parts[0].trim().toUpperCase();
      shortName = parts[1].trim().toUpperCase();
    } else if (searchTerm.length === 1) {
      // If only one letter provided, treat it as businessAreaCode
      businessAreaCode = searchTerm.trim().toUpperCase();
      shortName = '';
    }

    this.searchWithTerm(businessAreaCode, shortName);
  }

  /**
   * Search with specific business area and short name
   */
  private searchWithTerm(businessArea: string, shortName: string): void {
    this.theSearchTerm = businessArea + '/' + shortName;

    this.organizationService
      .searchOrganizations(businessArea, shortName, this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.organizationMatched = null;
          this.setMatchedOrganization(response.results, shortName);

          if (!this.organizationMatched) {
            this.searchResults = 'No match found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
            return;
          }

          const isInactive = this.checkInactive(this.organizationMatched);
          if (isInactive) {
            this.searchResults = 'No active organization found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
            return;
          }

          const foundOrg = this.findOrgById(
            this.orgDataSource,
            this.organizationMatched.organizationId
          );
          this.searchOrg = foundOrg;

          if (foundOrg) {
            // Refresh tree data source to ensure nodes are rendered
            this.dataSource.data = [...this.orgDataSource];

            // Traverse and open tree from root to searched item with delay
            setTimeout(() => {
              this.traverseAndOpenTree(foundOrg);
              this.selectOrganization(foundOrg);
              this.searchResultsMode = 1;
              this.searchResults = `Found: ${foundOrg.name}`;
            }, 300);
          } else {
            // Organization not in current tree, load ancestors
            this.orgsNeeded = [];
            this.loadAncestors(this.organizationMatched.parentOrganization.id);
          }
        },
        (error: any) => {
          this.searchResults = 'Search failed. Please try again.';
          this.searchResultsMode = 1;
        }
      );
  }

  /**
   * Set matched organization from search results
   */
  private setMatchedOrganization(results: any[], shortName: string): void {
    if (!results) return;
    results.forEach((organization: any) => {
      if (organization.shortName && organization.shortName.trim() === shortName) {
        this.organizationMatched = organization;
      }
    });
  }

  /**
   * Loads organization ancestors. Keeps going up the tree until it finds an already loaded organization.
   */
  private loadAncestors(parentId: number): void {
    this.organizationService
      .getOrganization(parentId, this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (organization: any) => {
          this.orgsNeeded.push(organization);
          const currentOrg = this.findOrgById(
            this.orgDataSource,
            organization.parentOrganization.id
          );

          if (currentOrg !== null) {
            // Found it in the tree, load children and go
            this.orgsNeeded.push(currentOrg);
            this.orgsToOpen = this.orgsNeeded;
            this.loadTreeBranches();
          } else {
            // Keep going up
            this.loadAncestors(organization.parentOrganization.id);
          }
        },
        (error: any) => {
        }
      );
  }

  /**
   * Loads all the organizations found in the loadAncestors method
   */
  private loadTreeBranches(): void {
    if (this.orgsNeeded.length > 0) {
      const orgToLoad = this.orgsNeeded.pop();
      this.getOrganizationChildrenForSearchAsync(orgToLoad).subscribe(() => {
        if (this.orgsNeeded.length > 0) {
          this.loadTreeBranches();
        } else {
          // After loading all ancestors, find and open the matched organization
          if (this.organizationMatched && this.organizationMatched.organizationId) {
            const theOrg = this.findOrgById(
              this.orgDataSource,
              this.organizationMatched.organizationId
            );
            if (theOrg !== null) {
              this.searchOrg = theOrg;
              this.getOrganizationChildrenForSearchAsync(theOrg).subscribe(() => {
                // Traverse and open tree from root to searched item
                this.traverseAndOpenTree(theOrg);
                this.selectOrganization(theOrg);
                this.searchResultsMode = 1;
                this.searchResults = `Found: ${theOrg.name}`;
                this.search();
              });
            }
          }
        }
      });
    }
  }

  /**
   * Get organization children for search tree loading
   */
  private getOrganizationChildrenForSearch(organization: any): void {
    this.organizationService
      .getChildOrganizations(+organization.organizationId, this.includeInactive)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          const children = (response.results || []).map((node: any) => {
            const child = {
              organizationId: node.organizationId,
              organizationType: node.organizationType,
              shortName: node.shortName,
              organizationName: node.organizationName,
              name:
                node.organizationType.businessArea.code.trim() +
                '/' +
                node.shortName.trim() +
                ' ' +
                node.organizationName.trim(),
              hasChild: node.hasChild || false,
              lifecycle: node.lifecycle,
              parentOrganization: node.parentOrganization,
              isInActive: this.checkIsInactive(node.lifecycle),
              children: [],
            };
            this.setChildProperties(node, child);
            return child;
          });

          this.findAndUpdateNode(this.orgDataSource, organization.organizationId, children);
          this.dataSource.data = [...this.orgDataSource];
        },
        (error: any) => {
        }
      );
  }

  /**
   * Get organization children for search tree loading (async version that returns Observable)
   */
  private getOrganizationChildrenForSearchAsync(organization: any): any {
    return this.organizationService.getChildOrganizations(+organization.organizationId, this.includeInactive).pipe(
      takeUntil(this.destroy$),
      map((response: any) => {
        const children = (response.results || []).map((node: any) => {
          const child = {
            organizationId: node.organizationId,
            organizationType: node.organizationType,
            shortName: node.shortName,
            organizationName: node.organizationName,
            name:
              node.organizationType.businessArea.code.trim() +
              '/' +
              node.shortName.trim() +
              ' ' +
              node.organizationName.trim(),
            hasChild: node.hasChild || false,
            lifecycle: node.lifecycle,
            parentOrganization: node.parentOrganization,
            isInActive: this.checkIsInactive(node.lifecycle),
            children: [],
          };
          this.setChildProperties(node, child);
          return child;
        });

        this.findAndUpdateNode(this.orgDataSource, organization.organizationId, children);
        this.dataSource.data = [...this.orgDataSource];
        return response;
      }),
      catchError((error: any) => {
        return of({});
      })
    );
  }

  /**
   * Find organization by ID in the tree
   */
  private findOrgById(children: any[], organizationId: string): any {
    let orgFound = null;
    if (children) {
      for (const organization of children) {
        if (orgFound === null) {
          if (organization.organizationId === organizationId) {
            orgFound = organization;
          } else if (organization.children && organization.children.length > 0) {
            orgFound = this.findOrgById(organization.children, organizationId);
          }
        }
      }
    }
    return orgFound;
  }

  /**
   * Scroll to organization in the tree
   */
  private scrollToOrganization(org: any): void {
    if (!org || !org.organizationId) {
      return;
    }
    setTimeout(() => {
      const element = document.getElementById(org.organizationId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 0);
  }

  /**
   * Opens the parent (ancestor) of the passed in organization
   */
  private openAncestor(organization: any): void {
    let foundRoot = false;
    let parentId = organization.parentOrganization?.id;
    let count = 0;

    if (!parentId) {
      return;
    }

    while (!foundRoot && count < 20) {
      count++;
      const ancestor = this.findOrgById(this.orgDataSource, parentId);
      if (!ancestor) {
        foundRoot = true;
      } else {
        const flatNode = this.treeControl.dataNodes.find(
          (n: any) => n.organizationId === ancestor.organizationId
        );
        if (flatNode) {
          this.treeControl.expand(flatNode);
        }
        parentId = ancestor.parentOrganization?.id;
        if (!parentId) {
          foundRoot = true;
        }
      }
    }
  }

  /**
   * Select organization from tree
   */
  private selectOrganization(organization: any): void {
    this.selectedOrganization = organization;
    this.updateButtonDisabled = false;
  }

  /**
   * Handle search key event (Enter key)
   */
  public searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.search();
      event.stopPropagation();
    }
  }

  private populateDropdowns(): void {}

  public clearSearchResults(): void {
    this.searchResultsMode = 0;
    this.searchResults = '';
    this.acronym = '';
    this.ngOnInit();
  }

  onConfirmClick(): void {
    // this.dialogRef.close(true);
  }

  public confirm(data: any) {}

  public closeThisDialog(data: any): void {
    // this.dialogRef.close(data);
  }

  /**
   * Traverse and open tree to show searched organization
   */
  private traverseAndOpenTree(organization: any): void {
    if (!organization || !organization.organizationId) {
      return;
    }

    // Clear previous traverse IDs
    this.traverseOrgsIds = [];
    let current = organization;
    let loopCount = 0;
    const maxLoops = 100; // Safety limit to prevent infinite loops
    const visitedIds = new Set<string>(); // Track visited IDs to prevent cycles

    // Build path from organization to root
    while (current && loopCount < maxLoops) {
      loopCount++;

      // Check for cycles
      if (visitedIds.has(current.organizationId)) {
        break;
      }

      visitedIds.add(current.organizationId);
      this.traverseOrgsIds.unshift(current.organizationId);

      if (current.parentOrganization?.id) {
        const parent = this.findOrgById(this.orgDataSource, current.parentOrganization.id);
        if (parent) {
          current = parent;
        } else {
          break;
        }
      } else {
        break;
      }
    }

    // Expand all nodes in the path sequentially to ensure proper rendering
    // Exclude the last node (target organization) from expansion - it should only be selected
    const nodesToExpand = this.traverseOrgsIds.slice(0, -1);
    this.expandNodesSequentially(nodesToExpand, 0, organization);
  }

  /**
   * Expand nodes sequentially to ensure proper rendering and tree expansion
   */
  private expandNodesSequentially(nodeIds: string[], index: number, targetOrganization: any): void {
    if (index >= nodeIds.length) {
      // All ancestor nodes expanded, scroll to target and select it (but don't expand it)
      setTimeout(() => {
        this.scrollToOrganization(targetOrganization);
      }, 100);
      return;
    }

    requestAnimationFrame(() => {
      const orgId = nodeIds[index];
      const flatNode = this.treeControl.dataNodes.find((n: any) => n.organizationId === orgId);

      if (flatNode && !this.treeControl.isExpanded(flatNode)) {
        this.treeControl.expand(flatNode);
        // Wait for expansion to complete before expanding next node
        setTimeout(() => {
          this.expandNodesSequentially(nodeIds, index + 1, targetOrganization);
        }, 50);
      } else {
        // Node already expanded or not found, move to next
        this.expandNodesSequentially(nodeIds, index + 1, targetOrganization);
      }
    });
  }

  private checkIsInactive(lifecycle: any): boolean {
    if (lifecycle?.endDate) {
      const endDate = new Date(lifecycle.endDate);
      return endDate < this.now;
    } else {
      return false;
    }
  }
  editOrganization(organizationId: string): void {
    this.appService.changePage(`/app/organization/update/${organizationId}`);
  }

  /**
   * Add is selected on the tree.
   */
  addOrganization(organizationId: string): void {
    this.appService.changePage(`/app/organization/add/${organizationId}`);
  }
  inactivate(node: any): void {
    const data = {
      titleType: 'text-danger',
      content: `<p style="font-size:14px;"> Inactivate organization ${node.organizationType.businessArea.code}/${node.shortName} ${node.organizationName} and all its children ? </p>`,
      primaryButton: 'Continue',
      primaryButtonType: 'danger',
      cancelButton: true,
      title: 'Inactivate Organization?',
    };

    const dialogRef = this.dialog.open(DialogComponent, {
      width: '30vw',
      data: data,
      panelClass: 'inactivate-dialog-container',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      // Only emit inactivate event if user clicked Continue (result is true)
      if (result === true) {
        this.inactiveOrganization.emit(node);
      }
      // If user clicked Cancel or X button, do nothing (result is undefined or false)
    });
  }

  /**
   * Reactivate organization
   */
  reactivate(node: any): void {
    const dialogRef = this.dialog.open(ReactivateOrganizationConfirmDialogComponent, {
      width: '30%',
      height: '24vh',
      disableClose: true,
      panelClass: 'reactivate-dialog-container',
      data: { organization: node },
    });

    dialogRef.afterClosed().subscribe((confirmed: any) => {
      if (confirmed === true) {
        this.reactivateOrganizationEvent.emit(node);
      }
    });
  }

  /**
   * Refresh organization - reload the tree data
   */
  refreshOrganization(node: any): void {
    if (node && node.organizationId) {
      // Reload the entire tree to refresh the data
      this.getOrganizationTree();
    }
  }

  selectedNoChildNode(node: any) {
    this.childSelectedEvent.emit(node);
  }
}
