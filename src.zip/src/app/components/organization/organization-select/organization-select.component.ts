import { Component, OnInit } from '@angular/core';
import { OrganizationService } from '../services/organization.service';
import { Organization } from '../models/organization.model';

interface TreeNode {
  id: string;
  organization: Organization;
  name: string;
  showChildren: boolean;
  selected: boolean;
  loaded: boolean;
  root: boolean;
  showFamily: boolean;
  hasChildren: boolean;
  icon: string;
  toggleLabel: string;
  inactive: boolean;
  isDisabled: string;
  children: TreeNode[];
  parentName?: string;
}

@Component({
  selector: 'app-organization-select',
  templateUrl: './organization-select.component.html',
  styleUrls: ['./organization-select.component.scss'],
})
export class OrganizationSelectComponent implements OnInit {
  selectOrganizationInfo: any;
  selectMode = true;
  searchOrg: TreeNode | null = null;
  treeFamily: TreeNode | null = null;
  updateButtonDisabled = true;
  addButtonDisabled = true;
  theSearchTerm = '';
  acronym = '';
  showType = 'active';
  searchResults = '';
  searchResultsMode = 0;
  organizationMatched: Organization | null = null;
  selectedOrg: Organization | null = null;
  orgsNeeded: TreeNode[] = [];
  orgsToOpen: TreeNode[] | null = null;
  hideMessage = true;
  returnCode = '';
  businessArea = '';
  shortName = '';

  constructor(private organizationService: OrganizationService) {}

  ngOnInit(): void {
    this.getOrganizationTree();
  }

  /**
   * Load the root Organization
   */
  getOrganizationTree(): void {
    this.updateButtonDisabled = true;
    this.addButtonDisabled = true;

    const includeInactive = this.showType === 'all';

    this.organizationService.getOrganizationsRoot(includeInactive).subscribe(
      (response: Organization[]) => {
        this.treeFamily = {
          organization: response[0],
          name:
            response[0].organizationType.businessArea.code.trim() +
            '/' +
            response[0].shortName.trim() +
            ' ' +
            response[0].organizationName.trim(),
          showChildren: true,
          id: response[0].organizationType.businessArea.code.trim() + response[0].shortName.trim(),
          showFamily: true,
          root: true,
          inactive: false,
          selected: false,
          loaded: true,
          icon: 'fa-plus-square-o',
          toggleLabel: 'Expand',
          hasChildren: false,
          isDisabled: '',
          children: [],
        };

        if (this.treeFamily) {
          this.getOrganizationChildren(this.treeFamily);
        }
      },
      (error) => {        this.checkSecurityViolation(error);
      }
    );
  }

  /**
   * Load the organization children
   */
  getOrganizationChildren(family: TreeNode): void {
    const includeInactive = this.showType === 'all';
    this.organizationService
      .getOrganizationChildren(family.organization.organizationId, includeInactive)
      .subscribe(
        (response: any) => {
          family.loaded = true;
          response.results.forEach((node: Organization) => {
            const child: TreeNode = {
              id: node.organizationType.businessArea.code.trim() + node.shortName.trim(),
              organization: node,
              name:
                node.organizationType.businessArea.code.trim() +
                '/' +
                node.shortName.trim() +
                ' ' +
                node.organizationName.trim(),
              parentName: family.organization.organizationName,
              showChildren: false,
              selected: false,
              loaded: false,
              root: false,
              showFamily: true,
              hasChildren: false,
              icon: 'fa-plus-square-o',
              toggleLabel: 'Expand',
              inactive: false,
              isDisabled: '',
              children: [],
            };
            if (node.hasChild === true) {
              child.hasChildren = true;
            }

            this.setChildProperties(node, child);
            family.children.push(child);
          });
        },
        (error) => {        }
      );
  }

  /**
   * Set the child properties on the Tree node
   */
  setChildProperties(node: Organization, child: TreeNode): void {
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle.endDate || '');

    if (endDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        child.inactive = true;
        child.isDisabled = 'disabled';
        child.name += ' - inactive';
      }
    }
  }

  /**
   * Check if organization is inactive
   */
  checkInactive(node: Organization | null): boolean {
    if (!node) return false;
    const beginningValueDate = new Date(0);
    const endDate = new Date(node.lifecycle.endDate || '');

    if (endDate) {
      const now = new Date();
      now.setUTCHours(0, 0, 0);

      if (endDate < now && endDate >= beginningValueDate) {
        return true;
      }
    }
    return false;
  }

  /**
   * Search button listener
   */
  search(): void {
    if (this.acronym.length < 3) {
      return;
    }
    this.searchWithTerm(this.acronym.substring(0, 1), this.acronym.substring(2));
  }

  /**
   * Set matched organization from search results
   */
  setMatchedOrganization(results: Organization[], shortName: string): void {
    results.forEach((organization) => {
      if (organization.shortName.trim() === shortName) {
        this.organizationMatched = organization;
      }
    });
  }

  /**
   * Search with term
   */
  searchWithTerm(businessArea: string, shortName: string): void {
    this.theSearchTerm = businessArea + '/' + shortName;

    const includeInactive = this.showType === 'all';
    this.organizationService
      .searchOrganizations(businessArea, shortName, includeInactive)
      .subscribe(
        (response: any) => {
          this.organizationMatched = null;
          this.setMatchedOrganization(response.results, shortName);
          const isInactive = this.checkInactive(this.organizationMatched);
          if (isInactive) {
            this.acronym = '';
            this.searchResults = 'No active organization found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
            return;
          }
          if (this.treeFamily) {
            const foundOrg = this.findOrgById(
              this.treeFamily.children,
              (this.organizationMatched as any).organizationId
            );
            this.searchOrg = foundOrg;
            if (foundOrg) {
              this.openAncestor(foundOrg);

              if (foundOrg.selected) {
                this.updateButtonDisabled = false;
                this.addButtonDisabled = false;
                return;
              }
              this.selectOrganization(foundOrg);
              this.updateButtonDisabled = false;
              this.addButtonDisabled = false;
              this.acronym = '';
            } else {
              const aFamily: TreeNode = {
                id: '',
                children: [],
                organization: {} as Organization,
                name: '',
                showChildren: false,
                selected: false,
                loaded: false,
                root: false,
                showFamily: false,
                hasChildren: false,
                icon: '',
                toggleLabel: '',
                inactive: false,
                isDisabled: '',
              };
              aFamily.organization.organizationId = response.results[0].parentOrganization.id;
              this.searchOrg = aFamily;
              this.loadAncestors(response.results[0].parentOrganization.id);
            }
          }
        },
        (error) => {
          if (!this.checkSecurityViolation(error)) {
            this.businessArea = '';
            this.shortName = '';
            this.searchResults = 'No match found for ' + this.theSearchTerm;
            this.searchResultsMode = 1;
          }
        }
      );
  }

  /**
   * Check security violation
   */
  checkSecurityViolation(response: any): boolean {
    if (response.status === 403) {
      this.returnCode = response.status;
      this.hideMessage = false;
      return true;
    }
    return false;
  }

  /**
   * Clears the search results
   */
  clearSearchResults(): void {
    this.searchResultsMode = 0;
    this.businessArea = '';
    this.shortName = '';
  }

  /**
   * Loads organization ancestors. Keeps going up the tree until it finds an already loaded organization.
   */
  loadAncestors(parentId: string): void {
    this.organizationService.getOrganization(parentId).subscribe(
      (organization: Organization) => {
        const aFamily: TreeNode = {
          id: '',
          children: [],
          organization: organization,
          name: '',
          showChildren: false,
          selected: false,
          loaded: false,
          root: false,
          showFamily: false,
          hasChildren: false,
          icon: '',
          toggleLabel: '',
          inactive: false,
          isDisabled: '',
        };
        this.orgsNeeded.push(aFamily);
        let currentOrg;

        if (this.treeFamily) {
          currentOrg = this.findOrgById(
            this.treeFamily.children,
            organization.parentOrganization.id
          );
        }

        if (currentOrg !== null && currentOrg !== undefined) {
          this.orgsNeeded.push(currentOrg);
          this.orgsToOpen = this.orgsNeeded;
          this.loadTreeBranches();
        } else {
          this.loadAncestors(organization.parentOrganization.id);
        }
      },
      (error) => {      }
    );
  }

  /**
   * Triggered by enter key on the Short name text box.
   */
  searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.search();
    }
  }

  /**
   * Loads all the organizations found in the load Ancestor method
   */
  loadTreeBranches(): void {
    if (this.orgsNeeded.length > 0) {
      const orgToLoad = this.orgsNeeded.pop();
      if (orgToLoad) {
        this.getOrganizationChildren(orgToLoad);
      }
      setTimeout(() => {
        if (this.orgsNeeded.length > 0) {
          this.loadTreeBranches();
        } else {
          if (this.searchOrg && this.treeFamily) {
            const theOrg = this.findOrgById(
              this.treeFamily.children,
              this.searchOrg.organization.organizationId
            );
            if (theOrg !== null) {
              this.getOrganizationChildren(theOrg);
            }
          }

          this.search();
        }
      }, 100);
    }
  }

  /**
   * Opens the parent(ancestor) of the passed in family (organization tree node)
   */
  openAncestor(family: TreeNode): void {
    let foundRoot = false;
    let parentId = family.organization.parentOrganization.id;

    let count = 0;

    if (this.treeFamily && parentId === this.treeFamily.organization.organizationId) {
      foundRoot = true;
    }

    while (!foundRoot) {
      count++;
      if (count > 20) {
        foundRoot = true;
      }

      if (this.treeFamily) {
        const ancestor = this.findOrgById(this.treeFamily.children, parentId);
        if (!ancestor || ancestor.root) {
          foundRoot = true;
        } else {
          this.toggleOrganizationFolder(ancestor, true);
          ancestor.showChildren = true;
          parentId = ancestor.organization.parentOrganization.id;
        }
      }
    }
  }

  /**
   * Open/closes tree node.
   */
  toggleOrganizationFolder(family: TreeNode, open?: boolean): void {
    if (open) {
      family.showChildren = true;
      family.icon = 'fa-minus-square-o';
      family.toggleLabel = 'Collapse';
    } else {
      family.showChildren = !family.showChildren;

      if (family.showChildren) {
        family.icon = 'fa-minus-square-o';
        family.toggleLabel = 'Collapse';
      } else {
        family.icon = 'fa-plus-square-o';
        family.toggleLabel = 'Expand';
      }

      if (!family.loaded) {
        this.getOrganizationChildren(family);
        family.showChildren = true;
        family.icon = 'fa-minus-square-o';
        family.toggleLabel = 'Collapse';
      }
    }
  }

  /**
   * Called when user clicks on a tree node label.
   */
  selectOrganization(selectedOrganization: TreeNode): void {
    if (!selectedOrganization.selected) {
      if (this.treeFamily) {
        this.deselectAll(this.treeFamily);
      }
    }

    selectedOrganization.selected = !selectedOrganization.selected;

    if (selectedOrganization.selected) {
      this.updateButtonDisabled = false;
      this.addButtonDisabled = false;
      this.selectedOrg = selectedOrganization.organization;
    } else {
      this.updateButtonDisabled = true;
      this.addButtonDisabled = true;
      this.selectedOrg = null;
    }
  }

  /**
   * Deselects all organization labels.
   */
  deselectAll(aOrganization: TreeNode): void {
    aOrganization.selected = false;
    this.selectedOrg = null;
    aOrganization.children.forEach((organization) => {
      organization.selected = false;
      if (organization.loaded && organization.hasChildren) {
        this.deselectAll(organization);
      }
    });
  }

  /**
   * Finds organization on the tree by id.
   */
  findOrgById(children: TreeNode[], organizationId: string): TreeNode | null {
    let orgFound: TreeNode | null = null;
    if (children) {
      for (const organization of children) {
        if (orgFound === null) {
          if (organization.organization.organizationId === organizationId) {
            orgFound = organization;
          } else {
            orgFound = this.findOrgById(organization.children, organizationId);
          }
        }
      }
    }

    return orgFound;
  }

  /**
   * Needed to fire an angular confirm event for the dialog
   */
  organizationSelected(family: TreeNode): void {
    // Implementation for dialog confirmation
  }

  /**
   * Node operations
   */
  nodeOps(node: TreeNode): void {
    if (node) {
      this.toggleOrganizationFolder(node);
    }
  }

  /**
   * Select node
   */
  select(node: TreeNode): void {
    this.selectOrganization(node);
  }

  /**
   * Add node
   */
  add(node: TreeNode): void {
    // Implementation for add
  }

  /**
   * Update node
   */
  update(node: TreeNode): void {
    this.organizationSelected(node);
  }
}
