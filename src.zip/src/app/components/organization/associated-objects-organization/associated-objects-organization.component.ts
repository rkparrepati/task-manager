import { Component, Inject, OnInit } from '@angular/core';
import { HttpService } from '../../../services/http.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

interface Worker {
  [key: string]: any;
}

@Component({
  selector: 'app-associated-objects-organization',
  templateUrl: './associated-objects-organization.component.html',
  styleUrls: ['./associated-objects-organization.component.scss'],
})
export class AssociatedObjectsOrganizationComponent implements OnInit {
  node: any;
  workersList: Worker[] = [];

  constructor(
    private httpService: HttpService,
    public dialogRef: MatDialogRef<AssociatedObjectsOrganizationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    this.node = this.data.node;
    this.loadWorkers();
  }

  /**
   * Load workers associated with organization
   */
  loadWorkers(): void {
    if (!this.node || !this.node.organizationType) {
      return;
    }

    const params = {
      sortColumn: 'familyName',
      sortOrder: 'asc',
    };

    const url =
      '/workers?&businessAreaCode=' +
      this.node.organizationType.businessArea.code +
      '&shortName=' +
      this.node.shortName;

    this.httpService.getData(url, params as any).subscribe(
      (response: any) => {
        this.workersList = response.results || [];
      },
      (error) => {        this.workersList = [];
      }
    );
  }
  closeDialog() {
    this.dialogRef.close(false);
  }
}
