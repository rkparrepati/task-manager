import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Organization, OrganizationResponse, OrganizationType } from '../models/organization.model';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpParams } from '@angular/common/http';
/**
 * Organization Service - Handles all HTTP interactions for Organization feature
 * Migrated from AngularJS 1.5 to Angular 15 with RxJS
 */
@Injectable({
  providedIn: 'root',
})
export class OrganizationService {
  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  /**
   * Searches for organizations by business area and short name
   * @param businessAreaCode - Business area code
   * @param shortName - Short name
   * @param includeInactive - Include inactive organizations
   * @returns Observable of SearchResult
   */
  searchOrganizations(
    businessAreaCode: string,
    shortName: string,
    includeInactive: boolean = false
  ): Observable<any> {
    const params = {
      root: 'false',
      businessAreaCode,
      shortName,
      includeInactive: includeInactive ? 'true' : 'false',
    };

    return this.httpService
      .get(`/organizations?${this.httpService.mergeQueryParams(params)}`, false)
      .pipe(catchError((error) => this.handleError(error)));
  }

  getOrganizationReportRoles(organizationId: string) {
    // Define query parameters using HttpParams (immutable)
    const params = {
      organizationId: organizationId,
      sortColumn: 'reportRoleValue',
      sortOrder: 'asc',
    };
    return this.httpService
      .get(`/organization-report-roles?${this.httpService.mergeQueryParams(params)}`)
      .pipe(catchError((error) => this.handleError(error)));
  }

  /**
   * Error handling utility
   * @param error - Error object
   * @param customMessage - Custom error message
   * @returns Observable error
   */
  private handleError(error: any, customMessage?: string): Observable<never> {
    const errorMessage = customMessage || error?.error?.message || 'An error occurred';
    return throwError(() => ({
      status: error?.status || 500,
      message: errorMessage,
      accessDenied: error?.status === 403,
      data: error?.error,
    }));
  }

  /**
   * Gets the root organization.
   * @param includeInactive - Include inactive organizations
   * @returns Observable of root organizations
   */
  getOrganizationsRoot(includeInactive: boolean): Observable<Organization[]> {
    const params = {
      root: 'true',
      includeInactive: includeInactive ? 'true' : 'false',
    };

    return this.httpService.get(`/organizations?${this.httpService.mergeQueryParams(params)}`).pipe(
      map((response: any) => response.results),
      catchError((error) => throwError(() => error))
    );
  }

  /**
   * Gets the children of a passed in organization id.
   * @param organizationId - Parent organization ID
   * @param includeInactive - Include inactive organizations
   * @returns Observable of organization response
   */
  getOrganizationChildren(
    organizationId: string,
    includeInactive: boolean
  ): Observable<OrganizationResponse> {
    const params = {
      root: 'false',
      includeInactive: includeInactive ? 'true' : 'false',
      parentOrganizationId: organizationId,
    };

    return this.httpService.get(`/organizations?${this.httpService.mergeQueryParams(params)}`).pipe(
      map((response: any) => response),
      catchError((error) => throwError(() => error))
    );
  }

  /**
   * Gets a specific organization by ID.
   * @param organizationId - Organization ID
   * @returns Observable of organization
   */
  getOrganization(organizationId: string): Observable<Organization> {
    return this.httpService.get(`/organizations/${organizationId}`).pipe(
      map((response: any) => response),
      catchError((error) => throwError(() => error))
    );
  }

  getLastModifiedRole(orgId: string) {
    return this.httpService.get(
      `/organization-report-roles?sortColumn=reportRoleValue&sortOrder=ascorganizationId=${orgId}`
    );
  }

  /**
   * Gets organization by acronym
   * @param acronym - Organization acronym (format: X/SHORTNAME)
   * @param includeInactive - Include inactive organizations
   * @returns Observable of SearchResult
   */
  getOrganizationByAcronym(acronym: string, includeInactive: boolean = false): Observable<any> {
    if (!acronym || acronym.length < 3) {
      return throwError(() => new Error(`Acronym of (${acronym}) contains an invalid format`));
    }

    const businessArea = acronym.substring(0, 1);
    const shortName = acronym.substring(2);

    const params = {
      root: 'false',
      businessAreaCode: businessArea,
      shortName,
      includeInactive: includeInactive ? 'true' : 'false',
    };

    return this.httpService
      .get(`/organizations?${this.httpService.mergeQueryParams(params)}`, false)
      .pipe(catchError((error) => this.handleError(error)));
  }
  /**
   * Gets the organization types for an organization.
   * @param organization - Organization object
   * @param includeInactive - Include inactive types
   * @returns Observable of organization types
   */
  getOrganizationTypes(
    organization: Organization,
    includeInactive: boolean
  ): Observable<OrganizationType[]> {
    const params = {
      businessAreaCode: organization.organizationType.businessArea.code,
      businessAreaId: organization.organizationType.businessArea.id,
      includeInactive: includeInactive ? 'true' : 'false',
    };

    return this.httpService
      .get(`/organization-types?${this.httpService.mergeQueryParams(params)}`)
      .pipe(
        map((response: any) => response),
        catchError((error) => {
          error.message = 'Organization types not found';
          return throwError(() => error);
        })
      );
  }

  /**
   * Gets location information.
   * @param locationId - Location ID
   * @returns Observable of location
   */
  getLocation(locationId: string): Observable<Location> {
    return this.httpService.get(`/locations/${locationId}`).pipe(
      map((response: any) => response),
      catchError((error) => {
        error.message = 'Location not found';
        return throwError(() => error);
      })
    );
  }

  /**
   * Creates or updates an organization.
   * @param organization - Organization object
   * @param isUpdate - True for update, false for create
   * @returns Observable of created/updated organization
   */
  createUpdateOrganization(
    organization: Organization,
    isUpdate: boolean
  ): Observable<Organization> {
    if (isUpdate) {
      if (organization.telephone && !organization.telephone.extensionNo) {
        organization.telephone.extensionNo = null as any;
      }
      return this.httpService
        .put(`/organizations/${organization.organizationId}`, organization)
        .pipe(
          map((response: any) => response),
          catchError((error) => throwError(() => error))
        );
    } else {
      return this.httpService.post('/organizations', organization).pipe(
        map((response: any) => response),
        catchError((error) => {
          error.message = `Organization ${organization.organizationName} failed to save. ${error.data?.message || ''}`;
          return throwError(() => error);
        })
      );
    }
  }

  inActivateOrganization(node: any) {
    const organization = node.organization;
    const endDate = new Date(new Date().getTime() - 24 * 60 * 60 * 1000);
    organization.lifecycle = organization.lifecycle || {};
    organization.lifecycle.endDate = this.utilityService.adjustEndDateFormatter(
      this.utilityService.dateFormatterEndDateToString(endDate)
    );
    organization.lifecycle.cascade = true;
    const islifecycleInValid = this.utilityService.validateInactivateEndDate(
      organization.lifecycle
    );

    if (islifecycleInValid) {
      return throwError(() => new Error(islifecycleInValid));
    }
    // ?lockControlNumber=${this.utilityService.getLockControlNumber(organization)}
    return this.httpService.put(`/organizations/${organization.organizationId}`, organization);
  }

  /**
   * Reactivate organization by clearing the end date
   * @param organization - Organization object to reactivate
   * @returns Observable of updated organization
   */
  reactivateOrganization(organization: any): Observable<Organization> {
    const reactivatedOrg = {
      ...organization,
      lifecycle: {
        ...organization.lifecycle,
        endDate: null,
        cascade: false,
      },
    };

    return this.httpService
      .put(
        `/organizations/${organization.organizationId}?lockControlNumber=${organization.audit?.lockControlNumber || ''}`,
        reactivatedOrg
      )
      .pipe(
        map((response: any) => response),
        catchError((error) => {
          error.message = `Organization reactivation failed. ${error.data?.message || ''}`;
          return throwError(() => error);
        })
      );
  }
}
