import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';

export interface SuccessMessage {
  message: string;
  code: string;
  organizationId: string;
  mode: string;
  changedFields?: string[];
}

@Injectable({
  providedIn: 'root',
})
export class OrganizationMessageService {
  private successMessageSubject = new ReplaySubject<SuccessMessage>(1);
  public successMessage$ = this.successMessageSubject.asObservable();

  constructor() {}

  /**
   * Emit success message after organization create/update
   */
  emitSuccessMessage(
    message: string,
    code: string,
    organizationId: string,
    mode: string,
    changedFields?: string[]
  ): void {
    this.successMessageSubject.next({
      message,
      code,
      organizationId,
      mode,
      changedFields,
    });
  }

  /**
   * Clear success message
   */
  clearSuccessMessage(): void {
    this.successMessageSubject.next({
      message: '',
      code: '',
      organizationId: '',
      mode: '',
      changedFields: [],
    });
  }
}
