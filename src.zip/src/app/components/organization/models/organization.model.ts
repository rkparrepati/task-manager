/**
 * Organization Model - Interfaces and types for Organization feature
 */

import { AssignedRole, WorkerRole } from 'src/app/shared/interfaces/models';

export interface BusinessArea {
  id: string;
  code: string;
}

export interface OrganizationType {
  businessArea: BusinessArea;
  organizationLevel: {
    code: string;
  };
  organizationTypeName?: string;
}

export interface Lifecycle {
  beginDate: Date | string;
  endDate?: Date | string;
}

export interface Telephone {
  phoneNo?: string;
  extensionNo?: string;
}

export interface LocationAssociation {
  location: {
    locationId: string;
  };
}

export interface MailStop {
  location: {
    locationId: string;
  };
}

export interface AuditInfo {
  lastModifiedLoginId: string;
  lastModifiedUser: string;
  lastModifiedDate: Date | string;
}

export interface ParentOrganization {
  id: string;
}

export interface Organization {
  organization: any;
  assignedRoles: AssignedRole[];
  allWorkerRoles: WorkerRole[];
  organizationId: string;
  organizationName: string;
  shortName: string;
  organizationType: OrganizationType;
  parentOrganization: ParentOrganization;
  lifecycle: Lifecycle;
  publishIndicator?: boolean;
  telephone: Telephone;
  faxNo?: string;
  emailAddress?: string;
  locationAssociation?: LocationAssociation;
  mailStop?: MailStop;
  audit?: AuditInfo;
  hasChild?: boolean;
}

export interface OrganizationTreeNode {
  id: string;
  organization: Organization;
  name: string;
  parentName?: string;
  showChildren: boolean;
  selected: boolean;
  loaded: boolean;
  root: boolean;
  showFamily: boolean;
  hasChildren: boolean;
  icon: string;
  toggleLabel: string;
  inactive: boolean;
  isDisabled: string;
  children: OrganizationTreeNode[];
  pleaseWait?: string;
  parentInactive?: boolean;
}

export interface Location {
  locationId: string;
  building: {
    code: string;
    floorNumber: string;
  };
  suiteId: string;
  roomId: string;
  corridorId: string;
  zoneId: string;
}

export interface Worker {
  familyName: string;
  // [key: string]: any;
}

export interface OrganizationEditObject {
  organization: Organization;
  parentOrganization: any;
  organizationTypes: OrganizationType[];
}

export interface SearchResult {
  results: Organization[];
}

export interface ChildrenResult {
  results: Organization[];
}

export interface OrganizationResponse {
  results: Organization[];
}

export interface OrganizationType {
  id: string;
  code: string;
  businessArea: {
    code: string;
    id: string;
  };
}

export interface Location {
  locationId: string;
  // [key: string]: any;
}
