import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-reactivate-organization-confirm-dialog',
  templateUrl: './reactivate-organization-confirm-dialog.component.html',
  styleUrls: ['./reactivate-organization-confirm-dialog.component.scss'],
})
export class ReactivateOrganizationConfirmDialogComponent {
  organization: any;

  constructor(
    public dialogRef: MatDialogRef<ReactivateOrganizationConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.organization = data.organization;
  }

  onCancel(): void {
    this.dialogRef.close(false); // Closes and returns false
  }

  onConfirm(): void {
    this.dialogRef.close(true); // Closes and returns true
  }
}
