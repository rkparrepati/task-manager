import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-organisation-select-tree',
  templateUrl: './organisation-select-tree.component.html',
  styleUrls: ['./organisation-select-tree.component.scss'],
})
export class OrganisationSelectTreeComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  updateButtonDisabled: boolean = false;
  acronym: string = '';
  searchResults: any = [];
  selectOrganizationInfo: any = {};
  hideResultMessage: boolean = false;
  searchResultsMode: number = 0;
  selectedOrg: any = {};

  constructor(private dialogRef: MatDialogRef<OrganisationSelectTreeComponent>) {}

  confirm(selectedOrg: any) {
    this.dialogRef.close(selectedOrg);
  }
  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
  clearSearchResults() {
    this.acronym = '';
    this.searchResults = [];
  }
  search() {}
}
