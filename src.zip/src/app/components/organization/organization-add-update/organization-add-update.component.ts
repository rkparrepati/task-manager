import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Organization, OrganizationType, Location } from '../models/organization.model';
import { OrganizationService } from '../services/organization.service';
import { OrganizationMessageService } from '../services/organization-message.service';
import { UtilityService } from '../../../services/utility.service';
import { AppService } from '../../../services/app.service';
import { MatDialog } from '@angular/material/dialog';
import { LocationselectDialogComponent } from '../../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { ErrorMessagesComponent } from 'src/app/shared/components/error-messages/error-messages.component';

interface OrganizationEditObject {
  organization: Organization;
  parentOrganization: any;
  organizationTypes: OrganizationType[];
}

@Component({
  selector: 'app-organization-add-update',
  templateUrl: './organization-add-update.component.html',
  styleUrls: ['./organization-add-update.component.scss'],
})
export class OrganizationAddUpdateComponent implements OnInit {
  viewName = 'organizationAddUpdate';
  moduleName = 'Add';
  appTitle = `Organization Management - ${this.moduleName}`;
  mode = 0; // 0 for add, 1 for update
  isRootOrganization = false;
  hasError: boolean = false;
  userRoles: string[] = this.appService.getUserRoles();
  organizationEditObject: OrganizationEditObject = {
    organization: {
      telephone: {
        phoneNo: '',
        extensionNo: '',
      },
      organizationType: {
        organizationLevel: {
          code: '',
        },
        businessArea: { code: '' },
      },
      lifecycle: {
        beginDate: new Date(),
        endDate: '',
      },
    } as Organization,
    parentOrganization: {},
    organizationTypes: [],
  };
  originalOrganizationObject: OrganizationEditObject = {
    organization: {} as Organization,
    parentOrganization: {},
    organizationTypes: [],
  };
  primaryLocation: Location = {
    locationId: '',
    building: {
      code: '',
      floorNumber: '',
    },
    suiteId: '',
    roomId: '',
    corridorId: '',
    zoneId: '',
  };
  originalPrimaryLocation: Location = {
    locationId: '',
    building: {
      code: '',
      floorNumber: '',
    },
    suiteId: '',
    roomId: '',
    corridorId: '',
    zoneId: '',
  };
  mailStop: Location = {
    locationId: '',
    building: {
      code: '',
      floorNumber: '',
    },
    suiteId: '',
    roomId: '',
    corridorId: '',
    zoneId: '',
  };
  originalMailStop: Location = {
    locationId: '',
    building: {
      code: '',
      floorNumber: '',
    },
    suiteId: '',
    roomId: '',
    corridorId: '',
    zoneId: '',
  };

  // Validation flags
  organizationNameInvalid = false;
  shortNameInvalid = false;
  beginDateInvalid = false;
  beginDateMessage: string | null = '';
  endDateInvalid = false;
  endDateMessage: string | null = '';
  invalidPhoneMessage = '';
  phoneNoInvalid = false;
  faxNoInvalid = false;
  emailAddressInvalid = false;
  phoneNumberMessage = '';

  // Message display
  hideMessage = true;
  returnCode = 0;
  returnMessage = '';
  accessDenied = false;

  @ViewChild(ErrorMessagesComponent, { static: false })
  errorMessagesComponent!: ErrorMessagesComponent;

  constructor(
    private organizationService: OrganizationService,
    private organizationMessageService: OrganizationMessageService,
    private utilityService: UtilityService,
    private route: ActivatedRoute,
    private router: Router,
    public appService: AppService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.callBack();
  }

  /**
   * Callback to load organization data
   */
  callBack(): void {
    const snapshotData = this.route.snapshot;
    const organizationId = snapshotData.params['organizationId'];
    const mode = snapshotData.data.breadcrumb[snapshotData.data.breadcrumb.length - 1].title;
    this.organizationService.getOrganization(organizationId).subscribe(
      (passedOrg: Organization) => {
        if (mode === 'Update') {
          this.moduleName = 'Update';
          this.setUpdateOrganization(passedOrg);
        } else {
          this.setAddOrganization(passedOrg);
        }
      },
      (error) => {
        this.checkSecurityViolation(error);      }
    );
  }

  /**
   * Setup for add mode
   */
  setAddOrganization(parentOrganization: Organization): void {
    this.isRootOrganization = false;
    this.appTitle = 'Organization Management - Add';
    this.mode = 0;
    // this.organizationEditObject = {
    //   organization: {
    //     telephone: {
    //       phoneNo: '',
    //       extensionNo: '',
    //     },
    //     organizationType: {
    //       organizationLevel: {
    //         code: '',
    //       },
    //       businessArea: { code: '' },
    //     },
    //     lifecycle: {
    //       beginDate: new Date(),
    //       endDate: '',
    //     },
    //   } as Organization,
    //   parentOrganization: {},
    //   organizationTypes: [],
    // };

    this.organizationEditObject.parentOrganization = {
      businessAreaCode: parentOrganization.organizationType.businessArea.code,
      shortName: parentOrganization.shortName,
      name: parentOrganization.organizationName,
    };

    (this.organizationEditObject.organization as any).parentOrganization = {
      id: parentOrganization.organizationId,
    };

    (this.organizationEditObject.organization as any).telephone = {
        phoneNo: '',
         extensionNo: '',
    };

    this.organizationService.getOrganizationTypes(parentOrganization, true).subscribe(
      (response: OrganizationType[]) => {
        this.organizationEditObject.organizationTypes = response;
        (this.organizationEditObject.organization as any).organizationType = {};
        (this.organizationEditObject.organization as any).lifecycle = {};
        const aDate = this.utilityService.getTimeNow();

        (this.organizationEditObject.organization as any).lifecycle.beginDate = aDate;
        (this.organizationEditObject.organization as any).lifecycle.endDate = '';
        (this.organizationEditObject.organization as any).publishIndicator = false;
        (this.organizationEditObject.organization as any).telephone = {
          phoneNo: '',
          extensionNo: '',
        };
        (this.organizationEditObject.organization as any).organizationType.businessArea = {};
        (this.organizationEditObject.organization as any).organizationType.businessArea.code =
          parentOrganization.organizationType.businessArea.code;
        (this.organizationEditObject.organization as any).organizationType.organizationLevel = {};
        (this.organizationEditObject.organization as any).organizationType.organizationLevel.code =
          parentOrganization.organizationType.organizationLevel.code;

        this.originalOrganizationObject = JSON.parse(JSON.stringify(this.organizationEditObject));
        this.primaryLocation = {
          locationId: '',
          building: {
            code: '',
            floorNumber: '',
          },
          suiteId: '',
          roomId: '',
          corridorId: '',
          zoneId: '',
        } as Location;
        this.mailStop = {
          locationId: '',
          building: {
            code: '',
            floorNumber: '',
          },
          suiteId: '',
          roomId: '',
          corridorId: '',
          zoneId: '',
        } as Location;
        this.originalPrimaryLocation = JSON.parse(JSON.stringify(this.primaryLocation));
        this.originalMailStop = JSON.parse(JSON.stringify(this.mailStop));
      },
      (error) => {
        this.hideMessage = false;
        this.returnCode = error.status;
        this.returnMessage = error.message;
      }
    );
  }

  /**
   * Setup for update mode
   */
  setUpdateOrganization(editedOrganization: Organization): void {
    this.appTitle = 'Organization Management - Update';
    this.mode = 1;
    this.moduleName = 'Update';
    this.isRootOrganization =
      editedOrganization.organizationId === editedOrganization.parentOrganization.id;

    this.organizationService.getOrganizationTypes(editedOrganization, true).subscribe(
      (response: OrganizationType[]) => {
        this.organizationEditObject = {
          organization: editedOrganization,
          parentOrganization: editedOrganization.parentOrganization,
          organizationTypes: response,
        };

        this.setDefaultPhoneParams();
        this.originalOrganizationObject = JSON.parse(JSON.stringify(this.organizationEditObject));

        if ((this.organizationEditObject.organization as any).locationAssociation) {
          this.organizationService
            .getLocation(
              (this.organizationEditObject.organization as any).locationAssociation.location
                .locationId
            )
            .subscribe(
              (response: any) => {
                this.primaryLocation = response;
                this.originalPrimaryLocation = JSON.parse(JSON.stringify(this.primaryLocation));
              },
              (error) => {
                this.checkSecurityViolation(error);
              }
            );
        }

        if ((this.organizationEditObject.organization as any).mailStop) {
          this.organizationService
            .getLocation(
              (this.organizationEditObject.organization as any).mailStop.location.locationId
            )
            .subscribe(
              (response: any) => {
                this.mailStop = response;
                this.originalMailStop = JSON.parse(JSON.stringify(this.mailStop));
              },
              (error) => {
                this.checkSecurityViolation(error);
              }
            );
        }
      },
      (error) => {
        this.hideMessage = false;
        this.returnCode = error.status;
        this.returnMessage = error.message;
      }
    );
  }

  /**
   * Set default phone parameters
   */
  setDefaultPhoneParams(): void {
    if (!(this.organizationEditObject.organization as any).telephone) {
      (this.organizationEditObject.organization as any).telephone = {};
    }

    if (!(this.organizationEditObject.organization as any).lifecycle.endDate) {
      (this.organizationEditObject.organization as any).lifecycle.endDate = '';
    }
  }

  /**
   * Save organization
   */
  organizationCreateUpdate(): void {
    const action = this.mode === 0 ? 'add' : 'update';
    if (!this.validateOrganizationParameters()) {
      this.resetTimeout();
      this.organizationService
        .createUpdateOrganization(this.organizationEditObject.organization, action === 'update')
        .subscribe(
          (response: Organization) => {
            if (response.organizationId) {
              // Track changed fields
              const changedFields = this.getChangedFields();
              const code = `${response.organizationType.businessArea.code.trim()}/${response.shortName.trim()}`;
              // Emit success message to organization component
              const successMessage = `Organization ${response.organizationType.businessArea.code.trim()}/${response.shortName.trim()} ${action}d successfully`;
              this.organizationMessageService.emitSuccessMessage(
                successMessage,
                code,
                response.organizationId,
                action,
                changedFields
              );
              // Navigate back to organization component
              this.appService.changePage(`/app/organization`);
            }
          },
          (error) => {
            this.returnMessage = this.utilityService.processFailureMessage(
              error,
              'Failed to create organization'
            );
            this.returnCode = error.status;
            this.accessDenied = error.accessDenied;
            this.hideMessage = false;
          }
        );
    } else {
      this.hideMessage = false;
      this.returnCode = 700;
      this.returnMessage = this.utilityService.getInvalidInputErrorMessage();
      // Scroll to top to show error message
      this.utilityService.scrollToTop();
      // Trigger change detection and error message collection
      setTimeout(() => {
        if (this.errorMessagesComponent) {
          this.errorMessagesComponent.formatErrorMessagesHTML();
        }
      }, 100);
    }
  }

  /**
   * Get list of changed fields by comparing current with original
   */
  getChangedFields(): string[] {
    const changedFields: string[] = [];
    const current = this.organizationEditObject.organization;
    const original = this.originalOrganizationObject.organization;

    // Check organization name
    if (current.organizationName !== original.organizationName) {
      changedFields.push('Organization Name');
    }

    // Check short name
    if (current.shortName !== original.shortName) {
      changedFields.push('Short Name');
    }

    // Check organization type
    if (
      current.organizationType?.organizationLevel?.code !==
      original.organizationType?.organizationLevel?.code
    ) {
      changedFields.push('Organization Type');
    }

    // Check begin date
    if (
      new Date(current.lifecycle?.beginDate).getTime() !==
      new Date(original.lifecycle?.beginDate).getTime()
    ) {
      changedFields.push('Start Date');
    }

    // Check end date
    if (current.lifecycle?.endDate !== original.lifecycle?.endDate) {
      changedFields.push('End Date');
    }

    // Check publish indicator
    if (current.publishIndicator !== original.publishIndicator) {
      changedFields.push('Allow Publishing');
    }

    // Check phone number
    if (current.telephone?.phoneNo !== original.telephone?.phoneNo) {
      changedFields.push('Main Phone');
    }

    // Check extension
    if (current.telephone?.extensionNo !== original.telephone?.extensionNo) {
      changedFields.push('Phone Extension');
    }

    // Check fax
    if (current.faxNo !== original.faxNo) {
      changedFields.push('Fax');
    }

    // Check email
    if (current.emailAddress !== original.emailAddress) {
      changedFields.push('Email Address');
    }

    // Check primary location
    if (this.primaryLocation.locationId !== this.originalPrimaryLocation.locationId) {
      changedFields.push('Primary Location');
    }

    // Check mail stop
    if (this.mailStop.locationId !== this.originalMailStop.locationId) {
      changedFields.push('Mail Stop');
    }

    return changedFields;
  }

  /**
   * Cancel and go back
   */
  organizationCancel(): void {
    this.appService.changePage('/app/organization');
  }

  /**
   * Reset to original values
   */
  organizationReset(): void {
    this.cancelAllInvalidates();
    this.hideMessageDiv();
    this.organizationEditObject = JSON.parse(JSON.stringify(this.originalOrganizationObject));
    this.primaryLocation = JSON.parse(JSON.stringify(this.originalPrimaryLocation));
    this.mailStop = JSON.parse(JSON.stringify(this.originalMailStop));
  }

  /**
   * Cancel all validation errors
   */
  cancelAllInvalidates(): void {
    this.organizationNameInvalid = false;
    this.shortNameInvalid = false;
    this.beginDateInvalid = false;
    this.beginDateMessage = '';
    this.endDateInvalid = false;
    this.endDateMessage = '';
    this.invalidPhoneMessage = '';
    this.phoneNoInvalid = false;
    this.faxNoInvalid = false;
    this.emailAddressInvalid = false;
  }

  /**
   * Hide message
   */
  hideMessageDiv(): void {
    this.hideMessage = true;
    this.returnMessage = '';
  }

  /**
   * Validate organization parameters
   */
  validateOrganizationParameters(): boolean {
    this.cancelAllInvalidates();
    let invalidOrganization = false;

    if (this.organizationEditObject && this.organizationEditObject.organization) {
      if (
        !(this.organizationEditObject.organization as any).organizationName ||
        (this.organizationEditObject.organization as any).organizationName.trim() === ''
      ) {
        this.organizationNameInvalid = true;
        invalidOrganization = true;
      } else {
        (this.organizationEditObject.organization as any).organizationName = (
          this.organizationEditObject.organization as any
        ).organizationName.toUpperCase();
      }

      if (!(this.organizationEditObject.organization as any).shortName) {
        this.shortNameInvalid = true;
        invalidOrganization = true;
      } else {
        (this.organizationEditObject.organization as any).shortName = (
          this.organizationEditObject.organization as any
        ).shortName.toUpperCase();
      }

      const beginDateError = this.utilityService.validateBeginDate(
        (this.organizationEditObject.organization as any).lifecycle.beginDate
      );
      this.beginDateMessage = beginDateError || '';

      if (beginDateError) {
        this.beginDateInvalid = true;
        invalidOrganization = true;
      }

      const endDateError = this.utilityService.validateEndDate(
        (this.organizationEditObject.organization as any).lifecycle.beginDate,
        (this.organizationEditObject.organization as any).lifecycle.endDate
      );
      this.endDateMessage = endDateError || '';

      if (endDateError) {
        this.endDateInvalid = true;
        invalidOrganization = true;
      }

      if (this.invalidateCommunication()) {
        invalidOrganization = true;
      }
    }

    // Show error messages component if there are validation errors
    if (invalidOrganization) {
      this.hideMessage = false;
      this.returnCode = 700;
      this.returnMessage = this.utilityService.getInvalidInputErrorMessage();
      // Scroll to top to show error message
      this.utilityService.scrollToTop();
      // Trigger change detection to ensure error messages are visible and collected
      setTimeout(() => {
        if (this.errorMessagesComponent) {
          this.errorMessagesComponent.formatErrorMessagesHTML();
        }
      }, 100);
    }

    return invalidOrganization;
  }

  /**
   * Validate communication data
   */
  invalidateCommunication(): boolean {
    let invalidCommunication = false;

    if ((this.organizationEditObject.organization as any).telephone) {
      const phoneNumberValue =  (this.organizationEditObject.organization as any).telephone.phoneNo ? this.validatePhoneNumber(
        (this.organizationEditObject.organization as any).telephone.phoneNo
      ): '';

      if (phoneNumberValue === -1) {
        this.phoneNoInvalid = true;
        invalidCommunication = true;
        this.phoneNumberMessage = 'Phone number must be empty or (###) ###-####';
      } else if (phoneNumberValue === 1) {
        this.phoneNoInvalid = this.invalidateExtension();
        if (this.phoneNoInvalid) {
          this.phoneNumberMessage = 'Extension must be empty or a 4 digit number';
          invalidCommunication = true;
        }
      } else {
        if ((this.organizationEditObject.organization as any).telephone.extensionNo) {
          this.phoneNumberMessage = 'Must supply a phone number with an extension number';
          this.phoneNoInvalid = true;
          invalidCommunication = true;
        } else {
          (this.organizationEditObject.organization as any).telephone = {
            phoneNo: '',
            extensionNo: '',
          };
        }
      }
    }

    const faxNumberValue = this.validatePhoneNumber(
      (this.organizationEditObject.organization as any).faxNo
    );
    if (faxNumberValue < 0) {
      this.faxNoInvalid = true;
      invalidCommunication = true;
    }

    if (
      (this.organizationEditObject.organization as any).emailAddress &&
      (this.organizationEditObject.organization as any).emailAddress.length > 0
    ) {
      const re = /\S+@\S+\.\S+/;
      const isValid = re.test((this.organizationEditObject.organization as any).emailAddress);
      if (!isValid) {
        this.emailAddressInvalid = true;
        invalidCommunication = true;
      }
    }

    return invalidCommunication;
  }

  /**
   * Validate phone number format
   */
  validatePhoneNumber(phoneNumber: string): number {
    if (phoneNumber) {
      if (phoneNumber.length === 0) {
        return 0;
      } else if (phoneNumber.length === 14) {
        return 1;
      } else {
        return -1;
      }
    }
    return 0;
  }

  /**
   * Validate extension
   */
  invalidateExtension(): boolean {
    if (
      (this.organizationEditObject.organization as any).telephone.extensionNo &&
      (this.organizationEditObject.organization as any).telephone.extensionNo.length === 4
    ) {
      return false;
    } else if (
      (this.organizationEditObject.organization as any).telephone.extensionNo &&
      (this.organizationEditObject.organization as any).telephone.extensionNo.length > 0
    ) {
      this.invalidPhoneMessage = 'Extension must be empty or a 4 digit number';
      return true;
    }

    return false;
  }

  /**
   * Change parent organization
   */
  changeParent(organization: Organization): void {
    this.organizationEditObject.parentOrganization = organization;
    this.organizationEditObject.parentOrganization.businessAreaCode =
      organization.organizationType.businessArea.code;
    this.organizationEditObject.parentOrganization.name = organization.organizationName;
    (this.organizationEditObject.organization as any).parentOrganization.id =
      organization.organizationId;

    this.organizationService
      .getOrganizationTypes(this.organizationEditObject.parentOrganization, true)
      .subscribe(
        (response: OrganizationType[]) => {
          this.organizationEditObject.organizationTypes = response;
          (this.organizationEditObject.organization as any).organizationType.businessArea.code =
            this.organizationEditObject.parentOrganization.organizationType.businessArea.code;
        },
        (error) => {
          this.checkSecurityViolation(error);        }
      );
  }

  /**
   * Check security violation
   */
  checkSecurityViolation(response: any): void {
    this.returnCode = response.status;
    this.hideMessage = false;
    this.accessDenied = response.accessDenied;
    this.returnMessage = this.utilityService.processFailureMessage(
      response,
      'Issue found in Organization Add/Update'
    );
  }

  /**
   * Change parent organization via dialog
   */
  changeParentOrganization(): void {
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '70vw',
      height: '90vh',
      autoFocus: true,
      data: {
        title: 'Choose a new parent organization',
        buttonsVisible: true, // Enable the Select Acronym and Cancel buttons
        button: 'Update parent organization',
      },
    });

    dialogRef.afterClosed().subscribe((selectedOrganization: any) => {
      if (selectedOrganization) {
        this.changeParent(selectedOrganization);
      }
    });
  }

  /**
   * Change location
   */
  changeLocation(type: string): void {
    const isMailStopIndicator = type !== 'primary';
    const locationSelectDialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '90vw',
      height: '75vh',
      data: {
        title: !isMailStopIndicator ? 'Select location' : 'Select mail stop location',
        mailStopIndicator: isMailStopIndicator,
      },
    });

    locationSelectDialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        if (isMailStopIndicator) {
          this.mailStop = result;
          this.organizationEditObject.organization.mailStop = {
            location: { locationId: result.locationId },
          };
        } else {
          this.primaryLocation = result;
          this.organizationEditObject.organization.locationAssociation = {
            location: {
              locationId: result.locationId,
            },
          };
        }
      }
    });
  }

  /**
   * Set message
   */
  setMessage(returnCode: number, returnMessage: string): void {
    this.returnCode = returnCode;
    this.returnMessage = returnMessage;
    this.hideMessage = false;
  }

  /**
   * Reset timeout
   */
  resetTimeout(): void {
    // Implementation for timeout reset
  }
}
