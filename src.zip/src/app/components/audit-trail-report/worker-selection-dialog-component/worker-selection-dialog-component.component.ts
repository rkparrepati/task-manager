import { Component, inject, Inject } from '@angular/core';
import { DialogData } from '../audit-trail-report.component';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';

interface Organization {
  businessAreaCode: string;
  shortName: string;
}

interface OrganizationHistoryItem {
  primaryOrganizationIndicator: boolean;
  organization: Organization;
}

interface Worker {
  employmentType: { value: string };
  organizationHistory: OrganizationHistoryItem[];
  gauValue?: string; // 'gauValue' is added dynamically, so it's optional on the input type

  workerNumber: string;
  // Add all the properties that the template is using:
  activeEmploymentIndicator: boolean;
  supervisorIndicator: boolean;
  familyName: string;
  preferredFirstName: string;
  isSameSupervisor?: boolean; // Optional property
  selected?: boolean;
  // ... other properties
}

interface Supervisor {
  workerNumber: string;
}

interface DialogInfo {
  workers: Worker[];
  roleName: string;
}

@Component({
  selector: 'app-worker-selection-dialog-component',
  templateUrl: './worker-selection-dialog-component.component.html',
  styleUrls: ['./worker-selection-dialog-component.component.scss'],
})
export class WorkerSelectionDialogComponentComponent {
  //  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  public dialogInfo: any;

  constructor(
    public dialogRef: MatDialogRef<WorkerSelectionDialogComponentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // 2. Assign the data.
    // If the alert shows "{}", ensure the data being passed from the main component is correct.
    this.dialogInfo = data;
  }

  isOrganizationRequired: boolean = true; // Changed from string 'true' to boolean true for better practice
  type: number = 0; // Example: 0 for single select, 1 for multi-select
  selectedAll: boolean = false;
  checked: boolean = false; // Used in the original template, though its purpose is slightly redundant with ng-model

  availableCapabilities: string[] = [
    /* e.g., "Docketing", "PALM Reports" */
  ];
  newCapabilityList: string[] = [];

  // Arrays to hold items selected in the UI lists
  selectedAvailableCapabilities: string[] = [];
  selectedCapabilities: string[] = []; // Used in the second function

  // Note: The original code uses 'newRoleList' in the second function,
  // which might be a typo for 'newCapabilityList'. I translate it literally first,
  // but assume 'newRoleList' needs to be declared as well if it's not a typo.
  newRoleList: string[] = [];
  newCapabilitiesList: string[] = []; // Corrected spelling from 'newCapabilityList'

  // Variables needed for the checkAll logic (mocked for context)
  // dialogInfo: DialogInfo = {
  //   workers: [],
  //   roleName: ''
  // };

  supervisor: Supervisor = { workerNumber: 'someId' };
  // type: number = 0; // 0 or 1
  // selectedAll: boolean = false;
  // checked: boolean = false;
  ngOnInit(): void {
    // Initialization logic
  }

  checkAll(): void {
    // Note: If you are using [(ngModel)] on the checkbox in your template,
    // the 'this.selectedAll' value is already updated to the *new* value when this function runs.

    if (this.selectedAll) {
      // this.selectedAll = true; // This line is redundant in modern Angular if ngModel is used
      this.checked = true;

      this.dialogInfo.workers.forEach((worker: Worker) => {
        worker.selected = true;

        if (worker.workerNumber === this.supervisor.workerNumber) {
          worker.selected = false;
        }

        if (this.type === 1) {
          worker.selected = !worker.isSameSupervisor;
        }
      });
    } else {
      // this.selectedAll = false; // This line is redundant in modern Angular if ngModel is used
      this.checked = false;

      // Use standard Array.forEach instead of angular.forEach
      this.dialogInfo.workers.forEach((worker: Worker) => {
        worker.selected = false;
      });
    }

    // If you have a selectedCount method, call it here:
    // this.selectedCount();
  }

  assignCapabilities(): void {
    // In AngularJS, the forEach loop was used to create a *copy* of the array.
    // In modern TypeScript, we use the spread operator for a cleaner copy:
    const allCapabilities: string[] = [...this.newCapabilitiesList];

    // Call the component's confirm method instead of $scope.confirm
    this.confirm(allCapabilities);
  }

  /**
   * Filters the list of workers and returns only those that are selected.
   */
  getSelectedLocations(): Worker[] {
    // Use native Array.prototype.filter with an arrow function
    const selectedLocations = this.dialogInfo.workers.filter((item: Worker) => {
      return item.selected;
    });

    // Simplified arrow function version:
    // const selectedLocations = this.dialogInfo.workers.filter(item => item.selected);

    return selectedLocations;
  }

  /**
   * Action handler for the 'Continue' button, using the selected workers list.
   */
  continueSelected(): void {
    // Call the internal method using 'this'
    const activeData = this.getSelectedLocations();



    // Call the component's confirm method instead of $scope.confirm
    this.confirm(activeData);
  }

  confirm(data: any): void {
    // Implementation remains the same

    // You can check the type if the logic inside 'confirm' differs:
    if (Array.isArray(data)) {
    }

    this.dialogRef.close(data); // Pass the data back to the caller
  }

  closeDialog() {
    this.dialogRef.close();
  }

  // Helper function to check role inclusion (since the template logic was complex)
  hasRole(roleName: string): boolean {
    //const rolesToCheck = ['SUPERVISOR', 'PAR', 'TIMECARD'];
    //return rolesToCheck.some(role => this.dialogInfo.roleName.includes(roleName));

    const currentRoleName = this.dialogInfo?.roleName || '';

    const rolesToCheck = ['SUPERVISOR', 'PAR', 'TIMECARD'];
    // Check if currentRoleName includes the search string
    return currentRoleName.includes(roleName);
  }

  selectWorker(worker: Worker): void {
    this.dialogRef.close(worker); // Closes the dialog and returns the worker object
  }

  cancel(): void {
    this.dialogRef.close(); // Closes the dialog without returning data (equivalent to ngDialog dismiss)
  }

  getWorkers(workers: Worker[]): Worker[] {
    // Use 'const' for a variable that isn't reassigned
    const onlyEmps: Worker[] = [];

    // Replace angular.forEach with native Array.prototype.forEach
    workers.forEach((emp: Worker) => {
      // Initialize the property (ensures TS compatibility)
      emp.gauValue = '';
      const organizationHistory = emp.organizationHistory;

      // Use safer checks for existence (optional chaining is great here if targets ES2020+)
      if (organizationHistory && organizationHistory.length > 0) {
        // Use 'for...of' loop for cleaner iteration than a C-style for loop
        for (const historyItem of organizationHistory) {
          const org = historyItem.organization;

          // Use optional chaining (?.) and strict equality (===)
          if (historyItem.primaryOrganizationIndicator && org?.businessAreaCode && org?.shortName) {
            // Use template literals for clean string concatenation
            emp.gauValue = `${org.businessAreaCode}/${org.shortName}`;

            // Note: If there's only ever one primary indicator, you can add a 'break' here
            // if using a standard 'for (let i=0; ...)' loop, but not a forEach or for...of.
          }
        }
      }

      // Filter logic: Check employment type value
      if (emp.employmentType.value !== 'C') {
        onlyEmps.push(emp);
      }
    });

    return onlyEmps;
  }

  /**
   * Moves selected capabilities from the 'Available' list to the 'Assigned' list.
   */
  moveToAssigned(): void {
    // Use native forEach method
    this.selectedAvailableCapabilities.forEach((capability: string) => {
      // Push the item into the destination array
      this.newCapabilityList.push(capability);

      // Find the index of the item in the source array
      const capabilityIndex = this.availableCapabilities.indexOf(capability);

      // Remove the item from the source array if found
      if (capabilityIndex > -1) {
        this.availableCapabilities.splice(capabilityIndex, 1);
      }
    });

    // Clear the selection model
    this.selectedAvailableCapabilities = [];
  }

  /**
   * Moves selected items back from the 'Assigned' list to the 'Available' list.
   */
  moveToUnassigned(): void {
    // Use native forEach method
    this.selectedCapabilities.forEach((aRole: string) => {
      // Push the item into the destination array
      this.availableCapabilities.push(aRole);

      // Note: This next line assumes you intended 'newRoleList' to be the source array,
      // where items are being removed from.
      const capabilityIndex = this.newRoleList.indexOf(aRole);

      if (capabilityIndex > -1) {
        // Remove the item from the source array
        this.newRoleList.splice(capabilityIndex, 1);
      }
    });

    // Clear the selection model
    this.selectedCapabilities = [];
  }
}
