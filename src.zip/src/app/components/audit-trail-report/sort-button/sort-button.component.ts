import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-sort-button',
  templateUrl: './sort-button.component.html',
  styleUrls: ['./sort-button.component.scss'],
})
export class SortButtonComponent {
  @Input() sortId: string = '';
  @Input() sortColumn: string = ''; // Currently active sort column in parent
  @Input() sortOrder: string = 'asc'; // Current direction ('asc' or 'desc')
  @Input() columnName: string = ''; // The column this specific button represents
  @Input() columnDescription: string = '';
  @Input() total: number | null = 0;

  // Output to notify parent when clicked
  @Output() callBack = new EventEmitter<any>();

  toggleSort() {
    // Determine new direction
    const newOrder =
      this.sortColumn === this.columnName && this.sortOrder === 'asc' ? 'desc' : 'asc';

    // Emit object back to parent resort($event)
    this.callBack.emit({
      columnName: this.columnName,
      sortOrder: newOrder,
      sortId: this.sortId,
    });
  }
}
