import { Component, EventEmitter, Input, Output, Optional, OnInit, ChangeDetectorRef } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { AuditTrailReportService } from '../audit-trail-report.service';
import { TransferSearchService } from '../../transfer-search/transfer-search.service';

@Component({
  selector: 'app-acme-navbar-component',
  templateUrl: './acme-navbar-component.component.html',
  styleUrls: ['./acme-navbar-component.component.scss'],
})
export class AcmeNavbarComponentComponent implements OnInit {
  @Input() creationDate: any;
  @Input() moduleName: string = '';
  @Input() appTitle: string = '';
  @Input() hideTitle: boolean = false;
  @Input() userRoles: string[] = [];
  @Input() returnCode: string | number | null = null;
  @Input() hideMessage: boolean = false;
  @Input() errorMessages: any[] = [];
  @Input() returnMessage: string = '';
  @Input() accessDenied: boolean = false;
  @Input() resetTimeout: any;
  @Input() skipToId: string = '';
  @Input() messageService: any; // Accept any service with the required observables
  showDropdown = false;
  // Migrated from & (callback) binding to @Output()
  @Output() fnCallback = new EventEmitter<any>();

  // Inside your component class
  constructor(
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef,
    @Optional() private auditTrailService: AuditTrailReportService,
    @Optional() private transferSearchService: TransferSearchService
  ) {
    this.hideMessage;
  }

  ngOnInit() {
    // Determine which service to use
    let serviceToUse = this.messageService || this.auditTrailService || this.transferSearchService;
    // Subscribe to the service observables if available
    if (serviceToUse && serviceToUse.hideMessage$) {
      serviceToUse.hideMessage$.subscribe((val: boolean) => {
        this.hideMessage = val;
        this.cdr.detectChanges();
      });

      // Listen for 'returnMessage' updates
      if (serviceToUse.returnMessage$) {
        serviceToUse.returnMessage$.subscribe((msg: string) => {
          this.returnMessage = msg;
          this.cdr.detectChanges();
        });
      }

      // Listen for 'returnCode' updates
      if (serviceToUse.returnCode$) {
        serviceToUse.returnCode$.subscribe((code: string | number) => {
          this.returnCode = code;
          this.cdr.detectChanges();
        });
      }

      if (serviceToUse.returnMessagesArray$) {
        serviceToUse.returnMessagesArray$.subscribe((messages: string[]) => {
          this.errorMessages = messages.map((msg) => ({ text: msg }));
          this.cdr.detectChanges();
        });
      }
    }
  }
  // Helper method to trigger the callback
  onActionTriggered(data: any) {
    this.fnCallback.emit(data);
  }

  getGeneralMessageSnippet(): SafeHtml {
    const rawHtml = '<span>' + this.returnMessage + ' </span>';
    return this.sanitizer.bypassSecurityTrustHtml(rawHtml);
  }

  getAccessViolationMessageSnippet(): SafeHtml {
    const rawHtml = '<span role="alert" aria-hidden="false">Security violation. Your role does not have rights to perform ' +
      (this.accessDenied || 'this action') + '</span>';
    return this.sanitizer.bypassSecurityTrustHtml(rawHtml);
  }

  closeMessage(): void {
    this.hideMessage = true;
    this.returnMessage = '';
  }

  formatErrorMessagesHTML() {
    this.showDropdown = !this.showDropdown;
  }

  setFocus(errorMessage: string = ''): void {
    const searchString = errorMessage.trim().toLowerCase();
    const eles = document.getElementsByClassName('text-danger');

    Array.from(eles).forEach((element: any) => {
      const elementText = ((element as HTMLElement).innerText || '').trim().toLowerCase();

      if (elementText === searchString) {
        const targetElement = element.parentElement.getElementsByTagName('input')[0];
        this.showDropdown = false;
        if (targetElement) {
          targetElement.focus();
          targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    });
  }
  
  trackByFn(index: number, item: any) {
    return item.id || index;
  }

  buildErrorMessages(incomingErrors: any[]): void {}

  private getWidgetId(errorNode: HTMLElement, inputs: NodeListOf<Element>): string {
    // Logic to match the error node to its input (using aria-describedby)
    let foundId = '';
    inputs.forEach((input) => {
      const describedBy = input.getAttribute('aria-describedby');
      if (describedBy && describedBy.includes(errorNode.id)) {
        foundId = input.id;
      }
    });
    return foundId;
  }

  private checkDuplicate(newItem: any): void {
    const exists = this.errorMessages.some((msg) => msg.text === newItem.text);
    if (!exists) {
      this.errorMessages.push(newItem);
    }
  }
}
