import { Injectable } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { catchError, forkJoin, map, Observable, of, Subject, switchMap, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { NewLocation } from 'src/app/shared/interfaces/models';
import { DatePipe } from '@angular/common';

interface AdvanceSearchOption {
  value?: string;
  description: string;
}

interface AdvanceSearchOptions {
  //lastName: AdvanceSearchOption;
  familyName: AdvanceSearchOption;
  preferredFirstName: AdvanceSearchOption;
  ssn: any;
  ssn2: { description: string };
  birthDate: { description: string };
  cedrRoles: AdvanceSearchOption;
  flag?: AdvanceSearchOption;
}

@Injectable({
  providedIn: 'root',
})
export class AuditTrailReportService {
  constructor(
    private httpservice: HttpService,
    private appservice: AppService,
    private http: HttpClient,
    private datePipe: DatePipe
  ) {}
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();

  // Expose as an observable
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();

  // Method to update the messages
  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.returnMessageSource.next(msg);
  }
  /**
   * Replaces getModules
   * Angular HttpClient returns an Observable. Errors are caught automatically.
   */
  getModules(): Observable<any> {
    return this.httpservice.get('/audit-tables');
  }

  /**
   * Internal method 'a' (equivalent to your getAuditTrails)
   */
  public getAuditTrails(tableParams: any, limit: number, skip: number): Observable<any> {
    const params = this.getTableParams(tableParams, limit, skip);

    return this.httpservice.get(`/audit-log-changes?${params}`).pipe(
      map((response) => response), // Equivalent to .then(function(response) { return response.data; })
      catchError((error) => {
        // Equivalent to $q.reject(response)
        return throwError(() => error);
      })
    );
  }

  /**
   * Logic to transform your data into URL parameters
   */
  private getTableParams(tableParams: any, limit: number, skip: number): HttpParams {
    let params = new HttpParams().set('limit', limit.toString()).set('skip', skip.toString());

    // Safely append formData keys to params
    Object.keys(tableParams).forEach((key) => {
      if (tableParams[key] !== null && tableParams[key] !== undefined) {
        params = params.set(key, tableParams[key]);
      }
    });

    return params;
  }

  /**
   * Replaces getAuditFields
   * @param module The module object containing tableNm
   */
  public getAuditFields(module: any): Observable<any> {
    const params = new HttpParams().set('tableName', module.tableNm || '').toString();

    return this.httpservice.get(`/audit-columns?${params}`).pipe(
      catchError((response) => {        return throwError(() => response);
      })
    );
  }

  public searchWorkerNumber(
    text: string,
    includeInactive: any,
    flag: boolean,
    defaultLimit: number
  ): Observable<any> {
    // 1. Build basic parameter object
    let paramObject: any = {
      workerNumber: text,
      includeInactive: (!!includeInactive).toString(),
    };

    // 2. Add extra flags if truthy (equivalent to your flag branch)
    if (flag) {
      paramObject = {
        ...paramObject,
        includeInactive: (!!this.getIncludeInactive(includeInactive)).toString(),
        flag: 'true',
        limit: defaultLimit.toString(),
        sortColumn: 'familyName1',
        sortOrder: 'asc',
      };
    }

    // 3. Convert object to HttpParams
    // HttpClient expects params to be string-based
    const params = new HttpParams({ fromObject: paramObject });

    // 4. Perform the GET request
    // HttpClient returns an Observable, replacing .then() with .pipe()

    return this.httpservice.get(`/workers?${params}`).pipe(
      catchError((error) => {
        // Equivalent to $q.reject(response)
        return throwError(() => error);
      })
    );
  }

  public characterSearch(
    text: string,
    includeInactive: any,
    flag: any,
    defaultLimit: number
  ): Observable<any> {
    const names = text.split(' ');

    // 2. Initialize options using the defined interface
    const advanceSearchOptions: AdvanceSearchOptions = {
      //lastName: { value: "familyName", description: "" },
      familyName: { value: 'familyName', description: '' },
      preferredFirstName: { value: 'preferredFirstName', description: '' },
      ssn: {},
      ssn2: { description: '' },
      birthDate: { description: '' },
      cedrRoles: { value: 'cedrRoles', description: '' },
    };

    // 3. Optional Chaining / Strict Null Checks for flag
    if (flag !== null && flag !== undefined) {
      advanceSearchOptions.flag = {
        value: 'flag',
        description: 'true',
      };
    }

    // 4. Handle name splitting
    if (names.length > 1) {
      advanceSearchOptions.preferredFirstName.description = names[1];
      advanceSearchOptions.familyName.description = names[0];
    } else {
      advanceSearchOptions.familyName.description = names[0];
    }

    // 5. Determine sort column based on flag
    const sortColumn = flag ? 'familyName1' : 'familyName';

    // Returns an Observable for the component to subscribe to
    return this.getWorkerListAdvancedSearch(
      advanceSearchOptions,
      includeInactive,
      false,
      defaultLimit,
      0,
      sortColumn,
      'asc'
    );
  }

  public getWorkerListAdvancedSearch(
    advancedSearchOptions: any,
    includeInactive: boolean,
    contractorSearch: boolean,
    limit: number,
    skip: number,
    sortColumn: string,
    sortOrder: string
  ): Observable<any> {
    // Optional Chaining (?.) replaces long logical AND (&&) checks
    if (advancedSearchOptions.ssn?.description) {
      return this.getAdvancedWithSSN(
        advancedSearchOptions,
        includeInactive,
        contractorSearch,
        limit,
        skip
      );
    } else {
      return this.getAdvancedSearchNoSSN(
        advancedSearchOptions,
        includeInactive,
        contractorSearch,
        limit,
        skip,
        sortColumn,
        sortOrder
      );
    }
  }

  getAdvancedSearchNoSSN(
    advancedSearchOptions: any,
    includeInactive: any,
    contractorSearch: boolean,
    limit: number,
    skip: number,
    sortColumn: string,
    sortOrder: string
  ): Observable<any> {
    // 1. Handle CEDR Roles Branch
    if (advancedSearchOptions.cedrRoles?.description) {
      return this.getWorkerbyCedrRoles(
        advancedSearchOptions.cedrRoles.description,
        advancedSearchOptions
      );
    }

    // 2. Initialize Parameters (Replaces manual URL concatenation)
    let params = new HttpParams()
      .set('includeInactive', this.getIncludeInactive(includeInactive));
    
    // Only add contractorSearch if it's true (to avoid adding it when false)
    if (contractorSearch) {
      params = params.set('contractorSearch', String(contractorSearch));
    }

    // 3. Map Fields to Parameters (Refactored buildUrl logic)
    // Add all fields that were previously handled by buildUrl()
    const textFields = [
      'workerNumber',
      'buildingCode',
      'floorNumber',
      'lastName',
      'firstName',
      'familyName',
      'preferredFirstName',
      'corridorId',
      'roomId',
      'suiteId',
      'zoneId',
      'phoneNumber',
      'loginId',
      'classCode',
      'firmName',
      'firmAdministrator',
      'businessAreaCode',
      'shortName',
    ];

    textFields.forEach((field) => {
      const description = advancedSearchOptions[field]?.description;
      if (description) {
        params = params.set(field, description);
      }
    });

    // 4. Handle Conditional Flag Parameter
    if (advancedSearchOptions.flag?.description) {
      params = params.set('flag', advancedSearchOptions.flag.description);
    }

    // 5. Date Formatting (Replaces $filter('date'))
    if (advancedSearchOptions.birthDate?.description) {
      const formattedDate = this.datePipe.transform(
        advancedSearchOptions.birthDate.description,
        'MM/dd/yyyy'
      );
      if (formattedDate) {
        params = params.set('dateOfBirth', formattedDate);
      }
    }

    // 6. Handle SSN2 (Specific check from your AngularJS code)
    if (advancedSearchOptions.ssn2?.description) {
      params = params.set('contractorSSN', advancedSearchOptions.ssn2.description);
    }

    // 7. Add Pagination and Sorting
    params = params
      .set('limit', String(limit))
      .set('skip', String(skip))
      .set('sortColumn', sortColumn)
      .set('sortOrder', sortOrder);

    // 8. Execute Request
    if (!contractorSearch) {
      // Logic for Worker Management Search

      return this.httpservice.get(`/workers?${params}`).pipe(
        map((response) => ({
          results: response,
          // meta: response.meta,
          status: 200,
          statusText: 'OK',
        })),
        catchError((err) => throwError(() => err))
      );
    } else {
      // Logic for Contractor Search
      if (!advancedSearchOptions.allFirms) {
        if (advancedSearchOptions.loginWorkerNumber?.description) {
          params = params.set(
            'loginWorkerNumber',
            advancedSearchOptions.loginWorkerNumber.description
          );
        }
        if (advancedSearchOptions.workerAssociatedFirms?.description) {
          params = params.set(
            'workerAssociatedFirms',
            advancedSearchOptions.workerAssociatedFirms.description
          );
        }
      }
      return this.doContractorNoSSN(params + '', includeInactive, limit, skip);
    }
  }

  getAdvancedWithSSN(
    advancedSearchOptions: any,
    includeInactive: any,
    contractorSearch: boolean,
    limit: number,
    skip: number
  ): Observable<any> {
    const ssnUrl = 'secure-workers';
    const payload = {
      socialSecurityNumber: advancedSearchOptions.ssn.description,
    };

    // 1. First Call: POST to get the Worker Number from SSN
    return this.http.post<any>(ssnUrl, payload).pipe(
      switchMap((responseSSN) => {
        const ssnWorker = responseSSN.results[0];

        // 2. Build Query Parameters for the Second Call (GET)
        let params = new HttpParams()
          .set('includeInactive', this.getIncludeInactive(includeInactive))
          .set('workerNumberPrefix', ssnWorker.worker.workerNumber);

        // Map advanced fields (Replacing buildUrl logic)
        const fields = [
          'lastName',
          'firstName',
          'preferredFirstName',
          'loginId',
          'classCode',
          'firmName',
          'firmAdministrator',
          'businessAreaCode',
          'shortName',
          'phoneNumber',
        ];

        fields.forEach((field) => {
          if (advancedSearchOptions[field]?.description) {
            params = params.set(field, advancedSearchOptions[field].description);
          }
        });

        if (contractorSearch) {
          params = params.set('isContractor', 'true');
          if (advancedSearchOptions.workerAssociatedFirms?.description) {
            params = params.set(
              'workerAssociatedFirms',
              advancedSearchOptions.workerAssociatedFirms.description
            );
          }
          if (advancedSearchOptions.loginWorkerNumber?.description) {
            params = params.set(
              'loginWorkerNumber',
              advancedSearchOptions.loginWorkerNumber.description
            );
          }
        }

        // Add Pagination
        params = params.set('limit', limit.toString()).set('skip', skip.toString());

        // 3. Second Call: GET workers based on SSN-derived Worker Number
        return this.httpservice.get(`/workers?${params}`).pipe(
          map((responseWorkers) => {
            // Reconstruct the responseSearchGet structure
            return {
              status: 200,
              statusText: 'OK',
              results: [responseWorkers],
              // meta: {
              //   total: 1,
              //   limit: limit,
              //   skip: skip
              // }
            };
          })
        );
      }),
      catchError((error) => throwError(() => error))
    );
  }

  // Placeholder for internal methods
  getWorkerbyCedrRoles(cedrRole: string, advancedSearchOptions: any): Observable<any> {
    const url = `/getWorkersByCERDRoles/${cedrRole}`;

    // HttpClient.get returns an Observable
    return this.httpservice.get(url).pipe(
      map((response) => {
        // response.body contains the JSON data
        return {
          results: response,
          //.body.users,
          // meta: response.body.totalUsersCount,
          // status: response.status,
          // statusText: response.statusText
        };
      }),
      catchError((error) => {
        // Replicates $q.reject(response) behavior
        return throwError(() => error);
      })
    );
  }

  doContractorNoSSN(
    url: string,
    includeInactive: any,
    limit: number,
    skip: number
  ): Observable<any> {
    // 1. Initial GET call to retrieve the worker list
    return this.httpservice.get(url).pipe(
      switchMap((response: any) => {
        const workerList = response; //.results;
        const totalRecords = response; //.meta.total;

        // 2. Prepare parallel calls for each worker (Replaces angular.forEach + workerPromise.push)
        const workerPromises: Observable<any>[] = workerList.map((worker: any) => {
          const secureUrl = `/secure-workers/${worker.workerId}`;
          const params = new HttpParams().set(
            'includeInactive',
            this.getIncludeInactive(includeInactive)
          );

          // Observe 'response' to get status/statusText matching legacy logic
          // return this.http.get<any>(secureUrl, { params, observe: 'response' }).pipe(
          return this.httpservice.get(`${secureUrl}?${params}`).pipe(
            catchError((err) => of(err)) // Prevent one failure from stopping all calls
          );
        });

        // 3. Parallel Execution (Replaces $q.all)
        // If there are no workers, return an empty result immediately
        if (workerPromises.length === 0) {
          return of({
            results: [],
            meta: { total: 0, limit, skip },
            status: 200,
            statusText: 'OK',
          });
        }

        return forkJoin(workerPromises).pipe(
          map((responseWorkers: any[]) => {
            // 4. Merge Secure Data back into Worker List
            responseWorkers.forEach((workerRecordResp) => {
              if (workerRecordResp.ok) {
                // Check if the individual request succeeded
                const secureData = workerRecordResp.body;
                const worker = workerList.find(
                  (w: any) => w.workerId === secureData.worker.workerId
                );
                if (worker) {
                  worker.secureWorker = {
                    dateOfBirth: secureData.birthDate,
                    contractorSSN: secureData.contractorSocialSecurity,
                  };
                }
              }
            });

            // 5. Build Final Response Object
            return {
              results: workerList,
              meta: { total: totalRecords, limit, skip },
              status: responseWorkers[0]?.status || 200,
              statusText: responseWorkers[0]?.statusText || 'OK',
            };
          })
        );
      }),
      catchError((err) => throwError(() => err))
    );
  }

  /**
   * Refactored utility function
   */
  getIncludeInactive(includeInactive: string): boolean {
    return includeInactive !== 'active';
  }

  public searchUsers(type: number, text: string): Observable<any> {
    switch (type) {
      case 0:
      case 2: {
        const defaultLimit = 100000;
        // In Angular 15, we return the Observable directly
        return this.characterSearch(text, true, null, defaultLimit);
      }
      case 1:
      case 3: {
        // Ensure this method in your SearchHelperService is also updated to return an Observable
        return this.searchWorkerNumber(text, true, false, 10);
      }
      default:
        // Returning undefined (or of(null)) for an invalid type
        return '' as any;
        '';
    }
  }
}
