import { Component, OnInit, ViewChild } from '@angular/core';
import { AuditTrailReportService } from './audit-trail-report.service';
import { FormGroup, ValidationErrors, FormBuilder, Validators } from '@angular/forms';
import { DatePipe, ViewportScroller } from '@angular/common';
import { catchError, Observable, throwError } from 'rxjs';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpErrorResponse, HttpParams } from '@angular/common/http';
import { WorkerSelectionDialogComponentComponent } from './worker-selection-dialog-component/worker-selection-dialog-component.component';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { PaginationComponent } from '../core/pagination/pagination.component';
import { ChangeDetectorRef } from '@angular/core';

interface SortEvent {
  columnName: string;
  sortOrder: string;
}

interface AuditFormData {
  infraModule: any;
  startDate: string | null;
  endDate: string | null;
  infraField: any;
  updaterEmployeeNo: any;
  updaterFirstName: any;
  updaterLastName: any;
  workerFirstName: any;
  workerLastName: any;
  workerEmployeeNo: any;
  limit: number;
  [key: string]: any; // Add an index signature for safety during iteration
}

export interface Worker {
  workerNumber: string;
  givenName: string;
  familyName: string;
  // ... any other worker properties
}

// Define the data structure passed *into* the dialog
export interface DialogData {
  workers: Worker[];
  isOrganizationRequired: boolean;
  type: number;
}

@Component({
  selector: 'app-audit-trail-report',
  templateUrl: './audit-trail-report.component.html',
  styleUrls: ['./audit-trail-report.component.scss'],
})
export class AuditTrailReportComponent implements OnInit {
  @ViewChild(PaginationComponent) pagination!: PaginationComponent;
  showWait = false;
  modules: any[] = [];
  selectedModule: any = null;
  validAuditModule = true;
  isInputSearch = false;
  workerNamePerformedChange = '';
  showWorkerNamePerformedChangeFound = '';
  auditStartDate: Date | null = new Date();
  auditEndDate: Date | null = new Date();
  validStartDate = true;
  validEndDate = true;
  auditField: any = null;
  auditFieldsList: any[] = [];
  total = 0;
  auditLogChanges: any[] = [];
  main = { creationDate: new Date() };
  moduleName = 'Audit Report';
  appTitle = ' Audit Trail and History View';
  hideMessage = false;
  returnMessage = '';
  returnCode: string | number = '';
  accessDenied = false;
  resetTimeout = null;
  userRoles = [];
  showWaitLoader = false;
  sortColumn: string = '';
  sortDirection: string = 'asc';
  limit: number = 10;
  //total: number = 0;
  selectedOption = 1;
  selectOptions = [10, 25, 50];
  firstPage = 1;
  skip: number = 0;
  auditStartDateErrorMessage: string | null = '';
  auditEndDateErrorMessage: string | null = '';
  workerNumberPerformedChange: string = '';
  showWorkerNumberPerformedChangeFound: string | null = null;
  workerNameChanged: string = '';
  showWorkerNameChangedFound: string | null = null;

  workerNumberChanged: string = '';
  showWorkerNumberChangedFound: string | null = null;
  workerNamePerformedChangeFound: any = null;

  workerNumberPerformedChangeFound: any = null;
  private selectedData: any;
  workerNameChangedFound: any = null;

  workerNumberChangedFound: any = null;

  constructor(
    private auditTrailService: AuditTrailReportService,
    private viewportScroller: ViewportScroller,
    private utilityService: UtilityService,
    private datePipe: DatePipe,
    public dialog: MatDialog,
    public cdr: ChangeDetectorRef,
  ) {}

  currentPage: number = 1;
  pageSizeOptions = [
    { name: '10', value: 10 },
    { name: '25', value: 25 },
    { name: '50', value: 50 },
  ];

  /**
   * Triggered when "Next", "Previous", or a page number is clicked
   */
  onPageChanged(page: number): void {
    this.currentPage = page;
    this.skip = (this.currentPage - 1) * this.limit;

    // Call your search with new skip, keeping the current limit
    this.search(this.limit, this.skip);
  }

  /**
   * Triggered when the "Items per page" dropdown changes
   */
  onPageSizeChanged(size: number): void {
    this.limit = size;
    this.currentPage = 1; // Reset to page 1 for new sizes
    this.skip = 0; // Reset skip to 0

    // Call search with new limit and reset skip
    this.search(this.limit, this.skip);
  }

  getAuditFields(): void {
    this.auditTrailService.getAuditFields(this.selectedModule).subscribe({
      next: (response: any) => {
        // Handle success
        this.auditFieldsList = response.results;
        // Success - keep message hidden
        this.hideMessage = true;
        this.auditTrailService.updateHideMessage(true);
      },
      error: (error: any) => {
        // Handle failure - show error message
        this.hideMessage = false;
        this.auditTrailService.updateHideMessage(false);
        this.returnCode = error.status;
        this.returnMessage = error.error?.message || 'An error occurred';
        this.auditTrailService.updateReturnMessage(this.returnMessage);
      },
    });
  }

  resort(event: SortEvent): void {
    // Update local state
    this.sortColumn = event.columnName;
    this.sortDirection = event.sortOrder;

    // Reset to first page (Assuming firstPage logic sets an offset or page index to 0)
    //this.goToFirstPage();

    // Trigger the search logic
    this.search(this.limit, 0);
  }

  goToFirstPage(): void {
    // Logic to reset your pagination component state
    // usually sets a 'currentPage' or 'offset' variable to 0
  }

  /**
   * Refactored validation logic
   */
  validAuditHistoryParam(): boolean {
    // 1. Module Validation
    this.validAuditModule = !!this.selectedModule;

    // 2. Start Date Validation
    //this.auditStartDateErrorMessage = this.utilityService.validateBeginDate(this.auditStartDate? , true) ?? '';
    this.auditStartDateErrorMessage =
      this.utilityService.validateBeginDate(
        this.auditStartDate ? new Date(this.auditStartDate).toISOString() : undefined,
        true
      ) ?? '';
    this.validStartDate = !this.auditStartDateErrorMessage;

    // 3. End Date Validation
    this.auditEndDateErrorMessage =
      this.utilityService.validateBeginDate(
        this.auditEndDate ? new Date(this.auditEndDate).toISOString() : undefined,
        true
      ) ?? '';
    // this.auditEndDateErrorMessage = this.utilityService.validateBeginDate(this.auditEndDate?.toISOString() ?? undefined, true) ?? '';
    this.validEndDate = !this.auditEndDateErrorMessage;

    // Return overall validity
    return this.validAuditModule && this.validStartDate && this.validEndDate;
  }

  private buildGetAuditHistoryFormData() {
    return {
      infraModule: this.selectedModule?.auditTableId,
      // DatePipe replaces $filter('date')
      startDate: this.datePipe.transform(this.auditStartDate, 'yyyy-MM-dd'),
      endDate: this.datePipe.transform(this.auditEndDate, 'yyyy-MM-dd'),
      infraField: this.auditField?.auditColumnId ?? null,
      updaterEmployeeNo: this.workerNumberPerformedChangeFound?.workerNumber ?? null,
      updaterFirstName: this.workerNamePerformedChangeFound?.givenName ?? null,
      updaterLastName: this.workerNamePerformedChangeFound?.familyName ?? null,
      workerFirstName: this.workerNameChangedFound?.givenName ?? null,
      workerLastName: this.workerNameChangedFound?.familyName ?? null,
      workerEmployeeNo: this.workerNumberChangedFound?.workerNumber ?? null,
      limit: this.limit,
      skip: this.skip,
      // The parenthesis and spread (...) ensure TypeScript evaluates this as part of the object literal
      ...(this.sortColumn ? { sortColumn: this.sortColumn, sortOrder: this.sortDirection } : {}),
    };
  }

  /**
   * Replaces vm.resetSearchText
   */
  resetSearchText(type: number): void {
    const resets: Record<number, { key: string; foundKey: string; showKey: string }> = {
      0: {
        key: 'workerNamePerformedChange',
        foundKey: 'workerNamePerformedChangeFound',
        showKey: 'showWorkerNamePerformedChangeFound',
      },
      1: {
        key: 'workerNumberPerformedChange',
        foundKey: 'workerNumberPerformedChangeFound',
        showKey: 'showWorkerNumberPerformedChangeFound',
      },
      2: {
        key: 'workerNameChanged',
        foundKey: 'workerNameChangedFound',
        showKey: 'showWorkerNameChangedFound',
      },
      3: {
        key: 'workerNumberChanged',
        foundKey: 'workerNumberChangedFound',
        showKey: 'showWorkerNumberChangedFound',
      },
    };

    const config = resets[type];
    if (config && !(this as any)[config.key]) {
      (this as any)[config.foundKey] = null;
      (this as any)[config.showKey] = null;
    }
  }

  /**
   * Replaces workerDetailsFound
   */
  workerDetailsFound(type: any): boolean {
    // Assuming these methods exist in your class
    return (
      this.workerNameWhoPerformedChangeFound(type) ||
      this.workerNumberWhoPerformedChangeFound(type) ||
      this.workerNameWhoChangeFound(type) ||
      this.workerNumberWhoChangeFound(type)
    );
  }
  /**
   * Type-safe replacement for boolean check functions
   */
  workerNameWhoPerformedChangeFound(type: number): boolean {
    return type === 0 && !!this.workerNamePerformedChangeFound;
  }

  workerNumberWhoPerformedChangeFound(type: number): boolean {
    return type === 1 && !!this.workerNumberPerformedChangeFound;
  }

  workerNameWhoChangeFound(type: number): boolean {
    return type === 2 && !!this.workerNameChangedFound;
  }

  workerNumberWhoChangeFound(type: number): boolean {
    return type === 3 && !!this.workerNumberChangedFound;
  }

  /**
   * Refactored capture function using Template Literals
   */
  captureWorkerSearchResults(type: number, response: any, search: boolean): void {
    const result = response?.results?.[0];

    if (!result) return;

    // Standardized string formatting for all types
    const displayValue = `[${result.familyName}, ${result.givenName}]`;

    switch (type) {
      case 0:
        this.workerNamePerformedChangeFound = result;
        this.showWorkerNamePerformedChangeFound = displayValue;
        break;
      case 1:
        this.workerNumberPerformedChangeFound = result;
        this.showWorkerNumberPerformedChangeFound = displayValue;
        break;
      case 2:
        this.workerNameChangedFound = result;
        this.showWorkerNameChangedFound = displayValue;
        break;
      case 3:
        this.workerNumberChangedFound = result;
        this.showWorkerNumberChangedFound = displayValue;
        break;
    }

    if (search) {
      this.search(this.limit, 0); // Calls your previously converted search method
    }
  }

  getAuditTrailForWorkerManagement(formData: any, limit: number, skip: number): Observable<any> {
    return this.auditTrailService.getAuditTrails(formData, limit, skip);
  }
  search(limit: number, skip: number): void {
    this.limit = limit || 10;
    this.skip = skip || 0;
    if (this.validAuditHistoryParam()) {
      this.showWait = true;
      this.validAuditModule = true;
      this.hideMessage = true;
      this.auditTrailService.updateHideMessage(this.hideMessage);
      const formData = this.buildGetAuditHistoryFormData();

      // Assuming the service returns an Observable
      this.getAuditTrailForWorkerManagement(formData, this.limit, this.skip).subscribe({
        next: (response: any) => {
          this.showWait = false;
          // Success - keep message hidden, clear any previous error messages
          this.hideMessage = true;
          this.auditTrailService.updateHideMessage(true);
          this.auditTrailService.updateReturnMessage('');
          this.returnMessage = '';
          this.returnCode = '';
          this.auditLogChanges = response.results;
          this.total = response.meta.total;
          this.viewportScroller.scrollToPosition([0, 0]); // Replaces $anchorScroll
        },
        error: (error: any) => {
          this.showWait = false;
          
          // Show error message for all errors including 404
          this.hideMessage = false;
          this.auditTrailService.updateHideMessage(false);
          this.returnCode = error.status;
          
          // Handle 403 access denied errors
          if (error.status === 403) {
            this.accessDenied = error.error?.accessDenied || 'this action';
            this.returnMessage = error.error?.message || 'Access Denied';
          } else if (error.status === 404) {
            // 404 means no audit logs found - show message and clear results
            this.auditLogChanges = [];
            this.total = 0;
            this.returnMessage = error.error?.message || 'No audit logs found';
            this.accessDenied = false;
          } else {
            // Other errors
            this.returnMessage = error.error?.message || 'An error occurred';
            this.accessDenied = error.error?.accessDenied || false;
          }
          
          this.auditTrailService.updateReturnMessage(this.returnMessage);
          this.viewportScroller.scrollToPosition([0, 0]);
        },
      });

      this.auditStartDateErrorMessage = '';
      this.auditEndDateErrorMessage = '';
    } else if (!this.isInputSearch) {
      this.hideMessage = false;
      this.auditTrailService.updateHideMessage(this.hideMessage);
      this.returnCode = '700';
      this.returnMessage = 'Invalid input was detected. Please correct required/invalid fields.';
      this.auditTrailService.updateReturnMessage(this.returnMessage);
      this.auditTrailService.updateReturnMessageArray(this.captureErrorMessages());
      this.viewportScroller.scrollToPosition([0, 0]);
    }
  }

  callBack(event: any) {}

  /**
   * This is the "On Load" hook for Angular
   */
  ngOnInit(): void {
    this.loadModules();
    // Start with message hidden - only show on actual errors
    this.hideMessage = true;
    this.auditTrailService.updateHideMessage(true);
  }

  loadModules(): void {
    // .subscribe() replaces .then()
    this.auditTrailService.getModules().subscribe({
      next: (response: any) => {
        // In HttpClient, response is usually the body directly
        // Adjust based on your API structure (e.g., response.results)
        this.modules = response.results || response.data?.results;
        // Success - keep message hidden
        this.hideMessage = true;
        this.auditTrailService.updateHideMessage(true);
      },
      error: (error: any) => {
        // Only show error message on actual failure
        this.hideMessage = false;
        this.auditTrailService.updateHideMessage(false);
        this.returnCode = error.status;
        this.returnMessage = error.error?.message || 'Failed to load modules';
        this.auditTrailService.updateReturnMessage(this.returnMessage);
      },
    });
  }
  //getAuditWorker(type: number) { /* logic */ }
  getAuditWorker(type: number, search: boolean = true): void {
    const workerSearchText = this.getWorkSearchText(type);
    this.isInputSearch = true;
    this.auditTrailService.updateHideMessage(true);
    // 1. Check if worker details are already found
    if (!this.workerDetailsFound(type)) {
      if (workerSearchText) {
        this.showWait = true;

        // 2. HttpClient returns an Observable. Use .subscribe() instead of .then()
        this.auditTrailService.searchUsers(type, workerSearchText).subscribe({
          next: (response: any) => {
            this.showWait = false;
            // Success - keep message hidden
            this.hideMessage = true;
            this.auditTrailService.updateHideMessage(true);
            const workerData = response.results?.results ?? response.results;

            // 2. Check the length of the identified array
            if (response.results?.results?.length === 1) {
              //   response.results=workerData[0];
              this.captureWorkerSearchResults(type, response.results, search);
            } else if (response.results?.length === 1) {
              this.captureWorkerSearchResults(type, response, search);
            }
            // if (response.results.results.length === 1) {
            //   this.captureWorkerSearchResults(type, response.results, search);}
            else {
              this.isInputSearch = true;
              this.showMultipleEmployees(response.results, type, search);
            }
          },
          error: (error: HttpErrorResponse) => {
            this.showWait = false;
            
            // Show error message for all errors including 404
            this.hideMessage = false;
            this.returnCode = error.status;
            
            // Handle 403 access denied errors
            if (error.status === 403) {
              this.accessDenied = error.error?.accessDenied || 'search for workers';
              this.returnMessage = error.error?.message || 'Access Denied';
            } else {
              // For 404 and other errors, show the error message
              this.returnMessage = error.error?.message || 'An error occurred';
              this.accessDenied = error.error?.accessDenied || false;
            }
            
            this.auditTrailService.updateHideMessage(false);
            this.auditTrailService.updateReturnMessage(this.returnMessage);
          },
        });
      } else {
        // 4. Reset logic if search text is empty
        this.resetSearchText(type);
        if (search) {
          this.search(this.limit, 0);
        }
      }
    } else {
      // 5. If details already found and 'search' flag is true, trigger search
      if (search) {
        this.search(this.limit, 0);
      }
    }
  }

  // Define helper method stubs
  getWorkSearchText(type: number): string | undefined {
    switch (type) {
      case 0:
        return this.workerNamePerformedChange;
      case 1:
        return this.workerNumberPerformedChange;
      case 2:
        return this.workerNameChanged;
      case 3:
        return this.workerNumberChanged;
      default:
        // Handle cases where an invalid 'type' is passed        return undefined; // Or return a default value like ''
    }
  }
  showMultipleEmployees(workers: Worker[], type: number, search: boolean): void {
    //this.resetTimeout();

    // Configuration object for the Angular Material Dialog
    const dialogRef = this.dialog.open(WorkerSelectionDialogComponentComponent, {
      width: '750px', // Replaces className 'reportsToAssignDialog' CSS width
      data: {
        // Data object passed to the dialog
        workers: workers,
        isOrganizationRequired: false, // Changed 'false' string to boolean false
        type: 0,
        roleName: 'SUPERVISOR',
      },
      // className is handled in the component CSS/theming now
    });

    // Handle the result when the dialog closes (replaces .then() in ngDialog)
    dialogRef.afterClosed().subscribe((response: Worker | undefined) => {
      // this.resetTimeout();

      // The user closed the dialog without selecting anything (cancelled)
      if (!response) {
        return;
      }

      // Logic to update the correct component property based on 'type'
      const displayValue = `[${response.familyName}, ${response.givenName}]`;

      switch (type) {
        case 0:
          this.workerNamePerformedChangeFound = response;
          this.showWorkerNamePerformedChangeFound = displayValue;
          break;
        case 1:
          this.workerNumberPerformedChangeFound = response;
          this.showWorkerNumberPerformedChangeFound = displayValue;
          break;
        case 2:
          this.workerNameChangedFound = response;
          this.showWorkerNameChangedFound = displayValue;
          break;
        case 3:
          this.workerNumberChangedFound = response;
          this.showWorkerNumberChangedFound = displayValue;
          break;
      }

      if (search) {
        this.search(this.limit, 0);
      }
    });
  }

  keyupSearchAuditHistory(event: KeyboardEvent, type?: number) {
    if (event.key === 'Enter') {
      this.getAuditHistory();
    }
  }

  getAuditHistory(): void {
    this.currentPage = 1;
    if (this.pagination) {
      this.pagination.selected = 10;
      this.pagination.resetPagination();
    }
    this.limit = 10;
    this.isInputSearch = false;
    this.selectedOption = this.selectOptions[0];
    this.search(this.limit, 0);
  }
  captureErrorMessages(): string[] {
    const messages: string[] = [];

    if (!this.validAuditModule && !this.isInputSearch) {
      messages.push('Capability is required');
    }
    if (!this.validStartDate) {
      messages.push('Invalid start date');
    }
    if (!this.validEndDate) {
      messages.push('Invalid end date');
    }
    // Add other logic flags here...

    return messages;
  }
  clear() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    this.selectedModule = null;
    this.workerNamePerformedChange = '';
    this.workerNumberPerformedChange = '';
    this.workerNameChanged = '';
    this.workerNumberChanged = '';
    this.showWorkerNamePerformedChangeFound = '';
    this.showWorkerNumberPerformedChangeFound = '';
    this.showWorkerNameChangedFound = '';
    this.showWorkerNumberChangedFound = '';
    //  this.auditStartDate = null;
    //this.auditEndDate = null;
    this.auditField = null;
    this.workerNamePerformedChangeFound = null;
    this.workerNumberPerformedChangeFound = null;
    this.workerNameChangedFound = null;
    this.workerNumberChangedFound = null;
    this.auditStartDate = new Date(today);
    this.auditEndDate = new Date(today);

    this.auditTrailService.updateHideMessage(true);
    this.hideMessage = true;
    this.auditTrailService.updateReturnMessage('');
    this.returnCode = '';
    this.returnMessage = '';
    this.validAuditModule = true;
    this.validStartDate = true;
    this.validEndDate = true;
    this.auditLogChanges = [];
    this.total = 0;
    this.isInputSearch = false;
    this.cdr.detectChanges(); // Ensure the view updates after clearing
  }

  exportAuditReport(): void {
    const formData: AuditFormData = {
      infraModule: this.selectedModule?.auditTableId,
      startDate: this.datePipe.transform(this.auditStartDate, 'yyyy-MM-dd'),
      endDate: this.datePipe.transform(this.auditEndDate, 'yyyy-MM-dd'),
      infraField: this.auditField?.auditColumnId ?? null,
      updaterEmployeeNo: this.workerNumberPerformedChangeFound?.workerNumber ?? null,
      updaterFirstName: this.workerNamePerformedChangeFound?.givenName ?? null,
      updaterLastName: this.workerNamePerformedChangeFound?.familyName ?? null,
      workerFirstName: this.workerNameChangedFound?.givenName ?? null,
      workerLastName: this.workerNameChangedFound?.familyName ?? null,
      workerEmployeeNo: this.workerNumberChangedFound?.workerNumber ?? null,
      limit: this.total,
    };

    // Replaces the angular.element scope lookup
    // In 2026, components communicate via services, not DOM scope
    //this.loaderService.setShowWaitLoader(true);

    let params = new HttpParams();
    (Object.keys(formData) as (keyof AuditFormData)[]).forEach((key) => {
      const value = formData[key];

      if (value !== null && value !== undefined) {
        // FIX: Explicitly cast 'key' to 'string' before passing it to append()
        params = params.append(key as string, String(value));
      }
    });

    // Append parameters to the URL
    const urlWithParams = `/audit-log-changes/excelReport?${params.toString()}`;

    this.showWait = true;
    this.utilityService
      .exportTableService1(urlWithParams, 'AuditHistory.xls', 'application/vnd.ms-excel')
      .subscribe({
        next: (response) => {
          // Optional: Handle the blob response if the service doesn't trigger the save automatically
        },
        error: (err) => {          this.showWait = false; // Hide even on error
        },
        complete: () => {
          this.showWait = false; // Set to false when stream finishes
        },
      });
  }
}
