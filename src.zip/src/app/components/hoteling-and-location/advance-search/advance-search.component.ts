import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';

@Component({
  selector: 'app-hoteling-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss'],
})
export class HotelingAdvanceSearchComponent implements OnInit {
  @Input() advanceSearchOptions: any;
  @Input() jobClassCodeList: any[] = [];
  @Input() buildingCodeList: any[] = [];
  @Input() acronymInvalid: boolean = false;
  @Input() advanceSearchAcronym: string = '';
  @Output() advanceSearchAcronymChange = new EventEmitter<string>();
  @Input() applicationType: string = 'Worker';
  @Input() invalidAdvancedAcronym: boolean = false;
  @Output() public advanceSearch = new EventEmitter();
  @Output() public clearSearch = new EventEmitter();

  status: boolean = true;
  isContractor: boolean = false;

  constructor() {}

  ngOnInit(): void {
    // Data is now passed from parent
  }

  /**
   * Handle acronym change event from acronym-input component
   */
  onAcronymChange(acronym: string): void {    this.advanceSearchAcronym = acronym;
    this.advanceSearchAcronymChange.emit(acronym);
    
    // Parse the acronym to extract businessAreaCode and shortName
    if (acronym && acronym.includes('/')) {
      const parts = acronym.split('/');
      if (parts.length === 2) {
        this.advanceSearchOptions.businessAreaCode.description = parts[0].trim();
        this.advanceSearchOptions.shortName.description = parts[1].trim();      }
    } else {
      // Clear if acronym is empty or invalid
      this.advanceSearchOptions.businessAreaCode.description = '';
      this.advanceSearchOptions.shortName.description = '';
    }
  }

  /**
   * Handle acronym selection from dialog
   */
  onAcronymSelected(result: any): void {  }

  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }

  setSearchType(searchType: any) {
    if (!this.checkBlankAdvanceSearch()) {
      this.advanceSearch.emit(this.advanceSearchOptions);
    }
  }

  checkBlankAdvanceSearch() {
    return this.checkBlankAdvanceSearchHelper();
  }

  checkBlankAdvanceSearchHelper() {
    if (
      this.advanceSearchOptions.workerNumber.description ||
      this.advanceSearchOptions.lastName.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firstName.description ||
      this.advanceSearchOptions.preferredFirstName.description ||
      this.advanceSearchOptions.loginId.description
    ) {
      return false;
    }

    if (this.advanceSearchOptions.classCode?.description) {
      return false;
    }
    
    if (this.advanceSearchAcronym && this.advanceSearchAcronym.trim().length > 0) {
      return false;
    }
    
    if (this.advanceSearchOptions.businessAreaCode?.description ||
        this.advanceSearchOptions.shortName?.description) {
      return false;
    }
    
    return true;
  }

  clearAdvanvedSearch() {
    this.clearSearch.emit();
  }
}
