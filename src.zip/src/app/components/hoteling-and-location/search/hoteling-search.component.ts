import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

export interface SearchCriteria {
  value: string;
  description: string;
}

export interface SearchOptions {
  basicSearchText: string;
  selectedSearchCriteria: SearchCriteria;
  basicSearchBusinessAreaCode: string;
  basicSearchShortName: string;
  advanceSearchAcronym: string;
  activeWorker: string;
}

@Component({
  selector: 'app-hoteling-search',
  templateUrl: './hoteling-search.component.html',
  styleUrls: ['./hoteling-search.component.scss'],
})
export class HotelingSearchComponent implements OnInit {
  @Input() basicSearchCriteria: SearchCriteria[] = [];
  @Input() selectedSearchCriteria: SearchCriteria | null = null;
  @Input() advancedView = false;
  @Input() basicSearchText = '';
  @Input() basicSearchBusinessAreaCode = '';
  @Input() basicSearchShortName = '';
  @Input() advanceSearchAcronym = '';
  @Input() activeWorker = 'active';
  @Input() acronymInvalid = false;
  @Input() invalidBasicSearchText = false;
  @Input() basicSearchDiv = true;
  @Input() basicSearchAcronymDiv = false;
  @Input() basicSearchSSNDiv = false;
  @Input() basicSearchFirmnameDiv = false;
  @Input() basicSearchDOBDiv = false;
  @Input() basicSearchLoginDiv = false;

  @Output() searchTypeChanged = new EventEmitter<boolean>();
  @Output() advancedViewToggled = new EventEmitter<void>();
  @Output() searchCriteriaChanged = new EventEmitter<SearchCriteria>();
  @Output() basicSearchInputBoxChanged = new EventEmitter<void>();
  @Output() searchExecuted = new EventEmitter<SearchOptions>();
  @Output() activeWorkerChanged = new EventEmitter<boolean>();
  @Output() advancedSearchCleared = new EventEmitter<void>();
  @Output() acronymEntered = new EventEmitter<void>();
  @Output() keyEventBasic = new EventEmitter<KeyboardEvent>();
  @Output() keyEventAdvanced = new EventEmitter<KeyboardEvent>();

  constructor() {}

  ngOnInit(): void {
    // Initialize search component
  }

  toggleAdvancedView(): void {
    this.advancedViewToggled.emit();
  }

  onSearchCriteriaChange(): void {
    if (this.selectedSearchCriteria) {
      this.searchCriteriaChanged.emit(this.selectedSearchCriteria);
      this.basicSearchInputBoxChanged.emit();
    }
  }

  onBasicSearchInputChange(): void {
    this.basicSearchInputBoxChanged.emit();
  }

  executeBasicSearch(): void {
    if (this.basicSearchText.trim()) {
      const searchOptions: SearchOptions = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: this.selectedSearchCriteria || this.basicSearchCriteria[0],
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        advanceSearchAcronym: '',
        activeWorker: this.activeWorker,
      };
      this.searchExecuted.emit(searchOptions);
    }
  }

  executeAdvancedSearch(): void {
    if (this.advanceSearchAcronym.trim()) {
      const searchOptions: SearchOptions = {
        basicSearchText: '',
        selectedSearchCriteria: this.selectedSearchCriteria || this.basicSearchCriteria[0],
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        advanceSearchAcronym: this.advanceSearchAcronym,
        activeWorker: this.activeWorker,
      };
      this.searchExecuted.emit(searchOptions);
    }
  }

  setActiveWorkerList(active: boolean): void {
    this.activeWorkerChanged.emit(active);
  }

  clearAdvancedSearch(): void {
    this.advancedSearchCleared.emit();
  }

  onAcronymEnter(): void {
    this.acronymEntered.emit();
  }

  onKeyEventBasic(event: KeyboardEvent): void {
    this.keyEventBasic.emit(event);
  }

  onKeyEventAdvanced(event: KeyboardEvent): void {
    this.keyEventAdvanced.emit(event);
  }
}
