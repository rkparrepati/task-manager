import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { HotelingAndLocationService } from './services/hoteling-and-location.service';
import { HttpService } from '../../services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { AppService } from 'src/app/services/app.service';
import { LocationselectDialogComponent } from '../worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { MatDialog } from '@angular/material/dialog';

export interface SearchCriteria {
  value: string;
  description: string;
}

export interface Worker {
  workerId: string;
  workerNumber: string;
  familyName: string;
  givenName: string;
  preferredFirstName: string;
  loginId: string;
  organizationHistory: any[];
  communicationHistory: any[];
  primaryOrganization?: any;
  primaryCommunication?: any;
  teleworkProgram?: any;
  hotelDisplayIndicator?: boolean;
  editMode?: boolean;
  [key: string]: any;
}

export interface WorkerModel {
  workerList: Worker[];
  selectedWorker: any;
  newWorker: any;
}

@Component({
  selector: 'app-hoteling-and-location',
  templateUrl: './hoteling-and-location.component.html',
  styleUrls: ['./hoteling-and-location.component.scss'],
})
export class HotelingAndLocationComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  dialog = inject(MatDialog);
  // Component properties
  moduleName = 'Location and Hoteling Program Management';
  viewName = 'hotelingAndLocation';
  appTitle = 'Location and Hoteling Program Management';
  sortDirection = 'asc';
  limit = 10;
  total = 0;
  systemMessage = 'Please contact your system INFRA Administrator for assistance.';
  applicationType = 'Worker';
  advancedView = false;
  hideBuildingSearch = true;
  hidePhoneNumberSearch = true;
  showType = 'active';
  activeWorker = 'active';
  pageCount = 10;
  userInitiatedSearch = false;

  // Search properties
  invalidBasicSearchText = false;
  invalidAcronym = false;
  hideSSN = true;
  hideFirms = true;
  searchResultsCount = '';
  basicSearchCriteria: SearchCriteria[] = [
    { value: 'workerNumber', description: 'Worker number' },
    { value: 'familyName', description: 'Last name' },
    { value: 'givenName', description: 'First name' },
    { value: 'preferredFirstName', description: 'Preferred first name' },
  ];

  // UI state
  hideMessage = true;
  returnMessage = '';
  returnCode: number = 0;
  accessDenied: any = false;
  basicSearch = true;
  sortColumn = 'lastName';
  telephoneInvalid = false;
  locationInvalid = false;
  locationRequired = false;
  acronymInvalid = false;
  invalidAdvancedAcronym = false;
  advanceSearchAcronym = '';
  basicSearchText = '';
  basicSearchBusinessAreaCode = '';
  basicSearchShortName = '';
  basicSearchDiv = true;
  basicSearchAcronymDiv = false;
  basicSearchSSNDiv = false;
  basicSearchFirmnameDiv = false;
  basicSearchDOBDiv = false;
  basicSearchLoginDiv = false;
  advanceSearchEvent: any;
  basicSearchEvent: any;

  // Data models
  workerModel: WorkerModel = {
    workerList: [],
    selectedWorker: {},
    newWorker: {},
  };
  selectedSearchCriteria: SearchCriteria = this.basicSearchCriteria[0];
  savedSearchCriteria: any = {};
  advanceSearchOptions: any = {};
  userInfo: any = {};
  isAdmin = false;
  myOrg = '';
  buildingCodeList: any[] = [];
  buildingFloors: any[] = [];
  teleworkOptions: any[] = [];
  purposeList: any[] = [];
  workerLocationPurpose: any = {};
  workerEditModel: any = {};
  jobClassCodeList: any[] = [];

  constructor(
    private hotelingAndLocationService: HotelingAndLocationService,
    private httpService: HttpService,
    private utilityService: UtilityService,
    private appService: AppService
  ) {}

  ngOnInit(): void {
    this.initializeComponent();
    const userData = this.appService.getUserData();
    if (userData) {
      this.userRoleRetrieved(userData);
    } else {
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize component
   */
  private initializeComponent(): void {
    this.getTeleworkOptions();
    this.getBuildings();
    this.getLocationPurposes();
    this.getJobClassCodes();
  }

  /**
   * Get location purposes
   */
  private getLocationPurposes(): void {
    this.httpService
      .get('/references/location-purposes')
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.purposeList = response.data?.results || [];
          this.purposeList.forEach((purpose: any) => {
            if (purpose.description === 'Worker Location') {
              this.workerLocationPurpose = purpose;
            }
          });
        },
        (error: any) => {
          this.returnMessage = this.processFailureMessage(error, 'Error Getting location purposes');
          this.returnCode = error.status;
          this.accessDenied = error.accessDenied;
          this.hideMessage = false;
        }
      );
  }

  /**
   * Get telework options
   */
  private getTeleworkOptions(): void {
    this.httpService
      .get('/telework-programs')
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.buildTeleworkOptions(response.data?.results || []);
        },
        (error: any) => {
        }
      );
  }

  /**
   * Get buildings
   */
  private getBuildings(): void {
    this.httpService
      .get('/buildings')
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.buildingCodeList = response?.results || [];
        },
        (error: any) => {
          this.hideMessage = false;
          this.returnCode = error.status;
          this.returnMessage = this.processFailureMessage(error, 'No buildings found.');
        }
      );
    }
  
    /**
     * Get job class codes
     */
    private getJobClassCodes(): void {
      this.httpService
        .get('/references/job-classes')
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            this.jobClassCodeList = response?.results || [];
          },
          (error: any) => {
          }
        );
    }
  
    /**
     * Build telework options
     */
    private buildTeleworkOptions(teleworkOptions: any[]): void {
    this.teleworkOptions = [];
    teleworkOptions.forEach((teleworkOption: any) => {
      const anOption = {
        id: teleworkOption.id,
        description: teleworkOption.description,
        group: teleworkOption.hotelingIndicator ? 'Hoteling' : 'Telework',
      };
      this.teleworkOptions.push(anOption);
    });
  }

  /**
   * Set advanced search options
   */
  setAdvanceSearchOptions(): void {
    this.advanceSearchOptions = {
      ssn: { value: 'socialSecurityNumber', description: '' },
      workerNumber: { value: 'workerNumber', description: '' },
      lastName: { value: 'familyName', description: '' },
      firstName: { value: 'givenName', description: '' },
      preferredFirstName: { value: 'preferredFirstName', description: '' },
      loginId: { value: 'loginId', description: '' },
      ssn2: { value: 'ssn2', description: '' },
      birthDate: { value: 'birthDate', description: '' },
      classCode: { value: 'classCode', description: '' },
      firmName: { value: 'firmName', description: '' },
      businessAreaCode: { value: 'businessAreaCode', description: '' },
      shortName: { value: 'shortName', description: '' },
      workerAssociatedFirms: { value: 'workerAssociatedFirms', description: true },
      loginWorkerNumber: {
        value: 'loginWorkerNumber',
        description: this.userInfo?.workerNumber || '',
      },
      cedrRoles: { value: 'cedrRoles', description: '' },
      buildingCode: { value: 'buildingCode', description: '' },
      floorNumber: { value: 'floorNumber', description: '' },
      corridorId: { value: 'corridorId', description: '' },
      roomId: { value: 'roomId', description: '' },
      suiteId: { value: 'suiteId', description: '' },
      zoneId: { value: 'zoneId', description: '' },
    };
  }

  /**
   * Get search options
   */
  getSearchOptions(): void {
    // Set default selected search criteria
    this.basicSearchCriteria.forEach((basicSearch: SearchCriteria) => {
      if (basicSearch.value === 'workerNumber') {
        this.selectedSearchCriteria = basicSearch;
      }
    });
    this.setAdvanceSearchOptions();
    this.getMyGAUexaminers();
  }

  /**
   * User role retrieved callback
   */
  userRoleRetrieved(userInfo: any): void {
    if (!userInfo) {
      return;
    }

    this.userInfo = userInfo;
    this.isAdmin =
      (userInfo.roles?.indexOf('InfraAdmin') >= 0 ||
        userInfo.roles?.indexOf('InfraSupervisorAdmin') >= 0) ??
      false;
    if (!userInfo.workerNumber) {
      this.hideMessage = false;
      this.returnCode = 400;
      this.returnMessage = 'User worker number not found. Please contact your system administrator.';
      return;
    }

    this.getSearchOptions();
  }

  /**
   * Get my GAU examiners
   */
  private getMyGAUexaminers(): void {
    const params = new HttpParams()
      .set('workerNumber', this.userInfo.workerNumber)
      .set('includeInactive', 'true');

    this.httpService
      .getData('/workers', params)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          const worker = response.results?.[0];
          if (worker) {
            const org = this.getPrimaryOrganization(worker.organizationHistory);
            this.advanceSearchOptions.shortName.description = org.substring(2);
            this.advanceSearchOptions.businessAreaCode.description = org.substring(0, 1);
            this.myOrg = org;
            this.setSearchType(false, true);
          }
        },
        (error: any) => {
          this.hideMessage = false;
          this.returnCode = 400;
          this.returnMessage = this.processFailureMessage(error, 'Your home GAU cannot be found.');
        }
      );
  }

  /**
   * Get building floors
   */
  getBuildingFloors(): void {
    const buildingCode = this.workerEditModel.location?.assignmentLocation?.building?.code;
    this.workerEditModel.location.assignmentLocation = {
      building: { code: buildingCode },
    };

    this.buildingFloors = [];
    this.buildingCodeList.forEach((building: any) => {
      if (building.buildingCode === buildingCode) {
        this.httpService
          .get(`/buildings/${building.buildingId}`)
          .pipe(takeUntil(this.destroy$))
          .subscribe(
            (response: any) => {
              this.buildingFloors = (response?.buildingFloors || []).sort(
                (a: any, b: any) => parseInt(a.floorNumber, 10) - parseInt(b.floorNumber, 10)
              );
            },
            (error: any) => {
              this.returnMessage = this.processFailureMessage(error, 'Building not found.');
              this.returnCode = error.status;
              this.hideMessage = false;
            }
          );
      }
    });
  }

  /**
   * Resort table
   */
  resort(sortColumn: string, sortDirection: string): void {
    this.sortColumn = sortColumn;
    this.sortDirection = sortDirection;
    this.firstPage();
  }

  /**
   * Sort by column
   */
  sortBy(column: string): void {
    if (this.sortColumn === column) {
      // Toggle sort direction if clicking the same column
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and default to ascending
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.firstPage();
  }

  workerBasicSearch(event: any) {
    this.basicSearchEvent = event;
    this.basicSearch = true;
    this.hideMessage = true;
    this.userInitiatedSearch = true;
    this.firstPage();
  }

  workerAdvanceSearch(event: any) {
    this.advanceSearchEvent = event;
    this.userInitiatedSearch = true;
    this.setSearchType(false);
  }
  /**
   * Get workers list
   */
  getWorkersList(limit: number, skip: number): void {
    this.resetTimeout();
    this.searchResultsCount = '';
    this.acronymInvalid = false;

    if (this.basicSearch) {
      this.handleBasicSearch(limit, skip);
    } else {
      if (this.advanceSearchAcronym && this.advanceSearchAcronym.length < 3) {
        this.acronymInvalid = true;
        return;
      }
      this.handleAdvancedSearch(limit, skip);
    }
  }

  /**
   * Handle basic search
   */
  private handleBasicSearch(limit: number, skip: number): void {
    // Validate that we have search event data
    if (!this.basicSearchEvent || !this.basicSearchEvent.searchType || !this.basicSearchEvent.searchText) {
      this.searchResultsCount = 'Please enter search criteria.';
      return;
    }
    let params = new HttpParams()
      .set('limit', limit.toString())
      .set('skip', skip.toString())
      .set('sortColumn', this.sortColumn)
      .set('sortOrder', this.sortDirection)
      .set('includeInactive', this.activeWorker === 'active' ? 'false' : 'true');

    // Add the search parameter based on the selected search type
    const searchType = this.basicSearchEvent.searchType;
    const searchText = this.basicSearchEvent.searchText.trim();

    if (searchType === 'workerNumber') {
      params = params.set('workerNumberPrefix', searchText);
    } else if (searchType === 'familyName') {
      params = params.set('familyName', searchText);
    } else if (searchType === 'givenName') {
      params = params.set('givenName', searchText);
    } else if (searchType === 'preferredFirstName') {
      params = params.set('preferredFirstName', searchText);
    } else {
      // For any other search type, use it as-is
      params = params.set(searchType, searchText);
    }
    this.httpService
      .getData('/workers', params)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.processWorkerList(response);
          // Display search criteria message only after search is performed
          if (this.total > 0) {
            this.searchResultsCount = `${this.total} worker(s) have been found with the entered search criteria.`;
          } else {
            this.searchResultsCount = 'No workers have been found with the entered search criteria.';
          }
        },
        (error: any) => {
          this.returnMessage = this.processFailureMessage(error, 'Search failed.');
          this.returnCode = error.status;
          this.accessDenied = error.accessDenied;
          this.checkNoResults(error);
        }
      );
  }

  /**
   * Handle advanced search
   */
  private handleAdvancedSearch(limit: number, skip: number): void {
    this.savedSearchCriteria.allFirms = true;
    let params = new HttpParams()
      .set('limit', limit.toString())
      .set('skip', skip.toString())
      .set('sortColumn', this.sortColumn)
      .set('sortOrder', this.sortDirection)
      .set('includeInactive', this.activeWorker === 'active' ? 'false' : 'true');

    // Add search criteria parameters
    if (this.savedSearchCriteria.workerNumber?.description) {
      params = params.set('workerNumberPrefix', this.savedSearchCriteria.workerNumber.description);
    }
    if (this.savedSearchCriteria.lastName?.description) {
      params = params.set('familyName', this.savedSearchCriteria.lastName.description);
    }
    if (this.savedSearchCriteria.firstName?.description) {
      params = params.set('givenName', this.savedSearchCriteria.firstName.description);
    }
    if (this.savedSearchCriteria.preferredFirstName?.description) {
      params = params.set(
        'preferredFirstName',
        this.savedSearchCriteria.preferredFirstName.description
      );
    }
    if (this.savedSearchCriteria.loginId?.description) {
      params = params.set('loginId', this.savedSearchCriteria.loginId.description);
    }
    if (this.savedSearchCriteria.classCode?.description) {
      params = params.set('classCode', this.savedSearchCriteria.classCode.description);
    }
    if (this.savedSearchCriteria.businessAreaCode?.description) {
      params = params.set(
        'businessAreaCode',
        this.savedSearchCriteria.businessAreaCode.description
      );
    }
    if (this.savedSearchCriteria.shortName?.description) {
      params = params.set('shortName', this.savedSearchCriteria.shortName.description);
    }
    if (this.savedSearchCriteria.buildingCode?.description) {
      params = params.set('buildingCode', this.savedSearchCriteria.buildingCode.description);
    }
    if (this.savedSearchCriteria.floorNumber?.description) {
      params = params.set('floorNumber', this.savedSearchCriteria.floorNumber.description);
    }
    if (this.savedSearchCriteria.corridorId?.description) {
      params = params.set('corridorId', this.savedSearchCriteria.corridorId.description);
    }
    if (this.savedSearchCriteria.roomId?.description) {
      params = params.set('roomId', this.savedSearchCriteria.roomId.description);
    }
    if (this.savedSearchCriteria.suiteId?.description) {
      params = params.set('suiteId', this.savedSearchCriteria.suiteId.description);
    }
    if (this.savedSearchCriteria.zoneId?.description) {
      params = params.set('zoneId', this.savedSearchCriteria.zoneId.description);
    }
    this.httpService
      .getData('/workers', params)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.processWorkerList(response);
          // Display appropriate message based on whether this is initial load or user-initiated search
          if (this.total > 0) {
            if (this.userInitiatedSearch) {
              // User performed a search - show search criteria message
              this.searchResultsCount = `${this.total} worker(s) have been found with the entered search criteria.`;
            } else {
              // Initial page load - show home GAU message
              this.searchResultsCount = `${this.total} worker(s) have been found in my GAU/Organization (${this.myOrg})`;
            }
          } else {
            this.searchResultsCount = '';
          }
        },
        (error: any) => {
          this.returnCode = error.status;
          this.returnMessage = this.processFailureMessage(error, 'Search failed.');
          this.accessDenied = error.accessDenied;
          this.checkNoResults(error);
        }
      );
  }

  /**
   * Process worker list
   */
  private processWorkerList(response: any): void {
    const results = response.results || [];
    this.workerModel = {
      workerList: results,
      selectedWorker: {},
      newWorker: {},
    };
    this.total = response.meta?.total || 0;

    this.workerModel.workerList.forEach((worker: Worker) => {
      worker.primaryOrganization = {};
      worker.organizationHistory?.forEach((organization: any) => {
        if (organization.primaryOrganizationIndicator) {
          worker.primaryOrganization = organization;
        }
      });
      worker.primaryCommunication = {};
      worker.communicationHistory?.forEach((communication: any) => {
        if (communication.primaryIndicator) {
          worker.primaryCommunication = communication;
        }
      });
    });
  }

  /**
   * Check no results
   */
  private checkNoResults(error: any): void {
    if (error.status === 404) {
      this.hideMessage = true;
      this.showNoResults();
    } else {
      this.hideMessage = false;
    }
  }

  /**
   * Show no results
   */
  private showNoResults(): void {
    this.searchResultsCount = 'No workers have been found with the entered search criteria.';
    this.workerModel = {
      workerList: [],
      selectedWorker: {},
      newWorker: {},
    };
    this.total = 0;
  }

  /**
   * Set search type
   */
  setSearchType(searchType: boolean, useMyOrg: boolean = false): void {
    this.telephoneInvalid = false;
    if (!useMyOrg) {
      this.myOrg = '';
    }
    if (this.workerModel) {
      this.workerModel = { workerList: [], selectedWorker: {}, newWorker: {} };
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: { value: this.selectedSearchCriteria.value },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo.workerNumber,
      };
      this.clearAdvancedSearch();
      this.firstPage();
    } else {
      const isBlank = this.checkBlankAdvanceSearch();
      if (isBlank) {
        this.searchResultsCount = '';
        return;
      }
      this.savedSearchCriteria = JSON.parse(JSON.stringify(this.advanceSearchOptions));
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
      this.firstPage();
    }
  }

  /**
   * Check blank advance search
   */
  private checkBlankAdvanceSearch(): boolean {
    if (this.advanceSearchOptions.classCode?.description) {
      return false;
    }
    if (
      this.advanceSearchOptions.firmName?.description ||
      this.advanceSearchOptions.businessAreaCode?.description ||
      this.advanceSearchOptions.shortName?.description
    ) {
      return false;
    }
    if (
      this.advanceSearchOptions.workerNumber?.description ||
      this.advanceSearchOptions.lastName?.description
    ) {
      return false;
    }
    if (
      this.advanceSearchOptions.firstName?.description ||
      this.advanceSearchOptions.preferredFirstName?.description ||
      this.advanceSearchOptions.loginId?.description
    ) {
      return false;
    }
    return true;
  }

  /**
   * Set active worker list
   */
  setActiveWorkerList(active: boolean): void {
    this.activeWorker = active ? 'active' : 'all';
    this.firstPage();
  }

  /**
   * Clear advanced search
   */
  clearAdvancedSearch(): void {
    this.resetTimeout();
    
    // Reset form fields
    this.setAdvanceSearchOptions();
    this.advanceSearchAcronym = '';
    this.invalidAdvancedAcronym = false;
    this.acronymInvalid = false;
    
    // Reset search results
    this.workerModel = { workerList: [], selectedWorker: {}, newWorker: {} };
    this.total = 0;
    this.searchResultsCount = '';
    this.savedSearchCriteria = null;
    this.userInitiatedSearch = false;
    
    // Reload default home GAU search (matching ActingSPE pattern)
    if (this.userInfo) {
      // If myOrg is not set, load it from the user's worker info
      if (!this.myOrg) {
        this.loadUserHomeGAU();
      } else {
        const [businessAreaCode, shortName] = this.myOrg.split('/');
        if (businessAreaCode && shortName) {
          this.searchWorkersByHomeGAU(businessAreaCode, shortName, this.limit, 0);
        }
      }
    }
  }

  /**
   * Loads the logged-in user's worker info and performs search for their home GAU
   * This matches the ActingSPE loadUserHomeGAU function
   */
  private loadUserHomeGAU(): void {
    const workerNumber = this.userInfo?.workerNumber;
    
    if (!workerNumber) {
      return;
    }

    this.httpService.get(`/workers?workerNumber=${workerNumber}&includeInactive=true`).subscribe({
      next: (response: any) => {
        if (response.results && response.results.length > 0) {
          const worker = response.results[0];
          
          // Find primary organization (home GAU)
          const primaryOrg = worker.organizationHistory?.find(
            (org: any) => org.primaryOrganizationIndicator
          );
          
          if (primaryOrg && primaryOrg.organization) {
            const businessAreaCode = primaryOrg.organization.businessAreaCode;
            const shortName = primaryOrg.organization.shortName;
            this.myOrg = `${businessAreaCode}/${shortName}`;
            
            // Perform search for workers in user's home GAU
            this.searchWorkersByHomeGAU(businessAreaCode, shortName, this.limit, 0);
          } else {
          }
        } else {
        }
      },
      error: (error: any) => {
      }
    });
  }

  /**
   * Search for workers in the user's home GAU (default search on page load)
   * Uses the same approach as handleAdvancedSearch for consistency
   */
  private searchWorkersByHomeGAU(businessAreaCode: string, shortName: string, limit: number = 10, skip: number = 0): void {
    // Store search parameters for pagination
    this.savedSearchCriteria = {
      businessAreaCode: { description: businessAreaCode },
      shortName: { description: shortName }
    };
    this.basicSearch = false;
    
    // Build params using HttpParams like handleAdvancedSearch does
    const params = new HttpParams()
      .set('limit', limit.toString())
      .set('skip', skip.toString())
      .set('sortColumn', this.sortColumn)
      .set('sortOrder', this.sortDirection)
      .set('includeInactive', this.activeWorker === 'active' ? 'false' : 'true')
      .set('businessAreaCode', businessAreaCode)
      .set('shortName', shortName);
    this.httpService
      .getData('/workers', params)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          // Use the same processWorkerList method as handleAdvancedSearch
          this.processWorkerList(response);
          // Update message based on whether this is initial load or user-initiated search
          if (this.total > 0) {
            if (this.userInitiatedSearch) {
              // User performed a search - show search criteria message
              this.searchResultsCount = `${this.total} worker(s) have been found with the entered search criteria.`;
            } else {
              // Initial page load - show home GAU message
              this.searchResultsCount = `${this.total} worker(s) have been found in my GAU/Organization (${this.myOrg})`;
            }
          } else {
            this.searchResultsCount = '';
          }
        },
        (error: any) => {
          this.returnCode = error.status;
          this.returnMessage = this.processFailureMessage(error, 'Search failed.');
          this.accessDenied = error.accessDenied;
          this.checkNoResults(error);
        }
      );
  }

  /**
   * Set basic search input box
   */
  setBasicSearchInputBox(): void {
    this.invalidBasicSearchText = false;
    this.invalidAcronym = false;

    if (this.selectedSearchCriteria.value === 'acronym') {
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = true;
      this.basicSearchText = '';
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
    } else if (this.selectedSearchCriteria.value === 'SSN') {
      this.basicSearchSSNDiv = true;
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchLoginDiv = false;
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchDOBDiv = false;
    } else if (this.selectedSearchCriteria.value === 'firmName') {
      this.basicSearchSSNDiv = false;
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmnameDiv = true;
      this.basicSearchLoginDiv = false;
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchText = '';
      this.basicSearchDOBDiv = false;
    } else if (this.selectedSearchCriteria.value === 'birthDate') {
      this.basicSearchSSNDiv = false;
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchLoginDiv = false;
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchText = '';
      this.basicSearchDOBDiv = true;
    } else if (this.selectedSearchCriteria.value === 'loginId') {
      this.basicSearchSSNDiv = false;
      this.basicSearchDiv = false;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = true;
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchText = '';
    } else {
      this.basicSearchSSNDiv = false;
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchLoginDiv = false;
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchText = '';
      this.basicSearchDOBDiv = false;
    }
  }

  /**
   * Search key event basic
   */
  searchKeyEventBasic(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.hideMessage = true;
      this.setSearchType(true);
    }
  }

  /**
   * Search key event advanced
   */
  searchKeyEventAdvanced(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.hideMessage = true;
      this.setSearchType(false);
    }
  }

  /**
   * Get primary organization
   */
  getPrimaryOrganization(organizationHistory: any[]): string {
    let acronym = '';
    organizationHistory?.forEach((organization: any) => {
      if (organization.primaryOrganizationIndicator) {
        acronym =
          organization.organization?.businessAreaCode + '/' + organization.organization?.shortName;
      }
    });
    return acronym;
  }

  /**
   * Acronym enter
   */
  acronymEnter(): void {
    this.hideMessage = true;
    this.setSearchType(false);
  }

  /**
   * Get template hoteling
   */
  getTemplateHoteling(worker: Worker): string {
    return worker.editMode ? 'editHotelingMode' : 'viewHotelingMode';
  }

  /**
   * Edit hoteling
   */
  editHoteling(worker: Worker): void {
    this.hideMessage = true;
    this.telephoneInvalid = false;
    this.resetTimeout();

    if (!this.isAdmin) {
      return;
    }

    const primaryOrg = this.getPrimaryOrganization(worker.organizationHistory);
    if (!primaryOrg) {
      return;
    }

    this.hideMessage = true;
    this.workerEditModel = JSON.parse(JSON.stringify(worker));
    this.workerEditModel.location = { assignmentLocation: { building: {} } };
    // Initialize telephone object to prevent template binding errors
    this.workerEditModel.telephone = { telephoneNo: '' };
    worker.editMode = true;
    this.httpService
      .get(`/workers/${worker.workerId}/assignments`)
      .pipe(takeUntil(this.destroy$))
      .subscribe((response: any) => {
        const locations = response?.results || [];
        locations.forEach((location: any) => {
          if (location.primaryLocationIndicator) {
            this.workerEditModel.location = location;
          }
        });

        if (this.workerEditModel.location?.assignmentLocation?.building) {
          this.httpService
            .get(
              `/buildings/${this.workerEditModel.location.assignmentLocation.building.buildingId}`
            )
            .pipe(takeUntil(this.destroy$))
            .subscribe(
              (buildingResponse: any) => {
                this.buildingFloors = (buildingResponse?.buildingFloors || []).sort(
                  (a: any, b: any) => parseInt(a.floorNumber, 10) - parseInt(b.floorNumber, 10)
                );
              },
              (error: any) => {
                this.hideMessage = false;
                this.returnCode = error.status;
                this.returnMessage = this.processFailureMessage(
                  error,
                  'Not able to get building list.'
                );
              }
            );
        } else {
          this.workerEditModel.addLocation = true;
        }
      });

    this.getPrimaryTelephone(worker);
  }

  /**
   * Get primary telephone
   */
  private getPrimaryTelephone(worker: Worker): void {
    // First check if worker already has primary communication from search results
    if (worker.primaryCommunication && worker.primaryCommunication.telephoneNo) {
      // Deep clone to preserve all fields from the API response
      this.workerEditModel.telephone = JSON.parse(JSON.stringify(worker.primaryCommunication));
      this.formatPhoneNumber();
      return; // Don't fetch again if we already have it
    }
    
    // Fetch telecommunications from API
    this.httpService
      .get(`/workers/${worker.workerId}/telecommunications`)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          // Try multiple response structures to handle different API formats
          const telephones = response.data?.results || response.results || response || [];
          let foundTelephone = false;
          telephones.forEach((telephone: any) => {
            if (telephone.primaryIndicator) {
              // Deep clone to preserve all fields from the API response
              this.workerEditModel.telephone = JSON.parse(JSON.stringify(telephone));
              this.formatPhoneNumber();
              foundTelephone = true;
            }
          });

          if (!foundTelephone) {
            this.workerEditModel.addTelecommuncation = true;
            this.workerEditModel.telephone = { telephoneNo: '' };
          }
        },
        error: (error: any) => {
          // Handle 404 or other errors - worker has no telecommunications
          this.workerEditModel.addTelecommuncation = true;
          this.workerEditModel.telephone = { telephoneNo: '' };
        }
      });
  }

  /**
   * Cancel edit hoteling
   */
  cancelEditHoteling(worker: Worker): void {
    this.resetTimeout();
    this.telephoneInvalid = false;
    worker.editMode = false;
    this.workerEditModel = {};
    this.hideMessage = true;
  }

  /**
   * Save hoteling
   */
  saveHoteling(): void {
    this.resetTimeout();

    const hasLocation = this.workerEditModel.location?.assignmentLocation;
    const hasTelephone = this.workerEditModel.telephone?.telephoneNo;
    const telephoneLength = hasTelephone ? hasTelephone.length : 0;

    // Check if at least one field has data
    if (!hasLocation && !hasTelephone) {
      this.returnCode = 600;
      this.hideMessage = false;
      this.returnMessage = 'No valid data has been entered to save';
      return;
    }

    // Validate telephone if provided
    if (telephoneLength > 0 && telephoneLength < 14) {
      this.telephoneInvalid = true;
      this.returnCode = 400;
      this.hideMessage = false;
      this.returnMessage = 'Telephone number is invalid';
      return;
    }
    
    // Only prevent removal if telephone existed before (not adding new) and user cleared it
    // If addTelecommuncation is true, it means there was no telephone before, so empty is OK
    if (!this.workerEditModel.addTelecommuncation && telephoneLength === 0 && !hasLocation) {
      // Only show this error if they're trying to save with ONLY an empty telephone (no location update)
      this.telephoneInvalid = true;
      this.returnCode = 400;
      this.hideMessage = false;
      this.returnMessage = 'Telephone number cannot be removed';
      return;
    }

    if (hasLocation) {
      this.validateLocationAssignment(this.workerEditModel.location);
    } else {
      this.saveLocationAndPhone();
    }
  }

  /**
   * Validate location assignment
   */
  private validateLocationAssignment(location: any): void {
    this.httpService
      .get(`/locations/${location.assignmentLocation.locationId}`)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response === 'Not Found') {
            this.returnCode = 400;
            this.hideMessage = false;
            this.returnMessage = `Entered location is not a valid location. ${this.systemMessage}`;
          } else {
            this.saveLocationAndPhone(response);
          }
        },
        (error: any) => {
          this.returnCode = 400;
          this.hideMessage = false;
          this.returnMessage = `Entered location is not a valid location. ${this.systemMessage}`;
        }
      );
  }

  /**
   * Save location and phone
   */
  private saveLocationAndPhone(exactMatch?: any): void {
    if (exactMatch) {
      this.workerEditModel.location.assignmentLocation.locationId = exactMatch?.locationId;
    }

    this.hotelingAndLocationService
      .updateWorkerInformation(this.workerEditModel)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        () => {
          this.hideMessage = false;
          this.returnMessage = `Successfully updated worker information for ${this.workerEditModel.familyName}, ${this.workerEditModel.preferredFirstName} - ${this.workerEditModel.workerNumber}`;
          this.returnCode = 200;
          this.firstPage();
          this.workerEditModel = {};
          window.scrollTo(0, 0);
        },
        (error: any) => {
          this.hideMessage = false;
          this.returnCode = error.status || 500;
          this.returnMessage = this.processFailureMessage(error, 'Location Save failed');
          window.scrollTo(0, 0);
        }
      );
  }

  /**
   * Change location
   */
  changeLocation(): void {
    this.resetTimeout();
    const locationSelectDialogRef = this.dialog.open(LocationselectDialogComponent, {
      width: '90vw',
      height: '75vh',
      data: {
        building: this.workerEditModel.location?.assignmentLocation?.building,
        floorNumber: this.workerEditModel.location?.assignmentLocation?.floorNumber,
        corridorId: this.workerEditModel.location?.assignmentLocation?.corridorId,
        suiteId: this.workerEditModel.location?.assignmentLocation?.suiteId,
        roomId: this.workerEditModel.location?.assignmentLocation?.roomId,
        zoneId: this.workerEditModel.location?.assignmentLocation?.zoneId,
      },
    });

    locationSelectDialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.workerEditModel.location.assignmentLocation.building = result.building || {};
        this.workerEditModel.location.assignmentLocation.code = result.building?.code || '';
        this.workerEditModel.location.assignmentLocation.floorNumber =
          result.building?.floorNumber || '';
        this.workerEditModel.location.assignmentLocation.corridorId = result.corridorId || '';
        this.workerEditModel.location.assignmentLocation.suiteId = result.suiteId || '';
        this.workerEditModel.location.assignmentLocation.roomId = result.roomId || '';
        this.workerEditModel.location.assignmentLocation.zoneId = result.zoneId || '';
      }
    });
  }

  buildBasicWorkerSearchExportQuery(savedSearchCriteria: any, url: string): string {
    if (savedSearchCriteria.searchCriteria === 'workerNumber') {
      url += '&workerNumberPrefix=' + savedSearchCriteria.searchText;
    } else {
      url += '&' + savedSearchCriteria.searchCriteria + '=' + savedSearchCriteria.basicSearchText;
    }
    return url;
  }

  buildAdvancedWorkerSearchExportQueryParamOne(savedSearchCriteria: any, url: string): string {
    url += savedSearchCriteria.workerNumber.description
      ? '&workerNumberPrefix=' + savedSearchCriteria.workerNumber.description
      : '';
    url += savedSearchCriteria.lastName.description
      ? '&' + savedSearchCriteria.lastName.value + '=' + savedSearchCriteria.lastName.description
      : '';
    url += savedSearchCriteria.firstName.description
      ? '&' + savedSearchCriteria.firstName.value + '=' + savedSearchCriteria.firstName.description
      : '';
    url += savedSearchCriteria.preferredFirstName.description
      ? '&' +
        savedSearchCriteria.preferredFirstName.value +
        '=' +
        savedSearchCriteria.preferredFirstName.description
      : '';
    return url;
  }

  buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria: any, url: string): string {
    url += savedSearchCriteria.classCode.description
      ? '&' + savedSearchCriteria.classCode.value + '=' + savedSearchCriteria.classCode.description
      : '';
    url += savedSearchCriteria.firmName.description
      ? '&' + savedSearchCriteria.firmName.value + '=' + savedSearchCriteria.firmName.description
      : '';
    url += savedSearchCriteria.businessAreaCode.description
      ? '&' +
        savedSearchCriteria.businessAreaCode.value +
        '=' +
        savedSearchCriteria.businessAreaCode.description
      : '';
    url += savedSearchCriteria.shortName.description
      ? '&' + savedSearchCriteria.shortName.value + '=' + savedSearchCriteria.shortName.description
      : '';
    if (!savedSearchCriteria.allFirms) {
      url += savedSearchCriteria.loginWorkerNumber.description
        ? '&' +
          savedSearchCriteria.loginWorkerNumber.value +
          '=' +
          savedSearchCriteria.loginWorkerNumber.description
        : '';
      url += savedSearchCriteria.workerAssociatedFirms.description
        ? '&' +
          savedSearchCriteria.workerAssociatedFirms.value +
          '=' +
          savedSearchCriteria.workerAssociatedFirms.description
        : '';
    }
    url += savedSearchCriteria.buildingCode.description
      ? '&' +
        savedSearchCriteria.buildingCode.value +
        '=' +
        savedSearchCriteria.buildingCode.description
      : '';
    url += savedSearchCriteria.floorNumber.description
      ? '&' +
        savedSearchCriteria.floorNumber.value +
        '=' +
        savedSearchCriteria.floorNumber.description
      : '';
    url += savedSearchCriteria.corridorId.description
      ? '&' +
        savedSearchCriteria.corridorId.value +
        '=' +
        savedSearchCriteria.corridorId.description
      : '';
    url += savedSearchCriteria.roomId.description
      ? '&' + savedSearchCriteria.roomId.value + '=' + savedSearchCriteria.roomId.description
      : '';
    url += savedSearchCriteria.suiteId.description
      ? '&' + savedSearchCriteria.suiteId.value + '=' + savedSearchCriteria.suiteId.description
      : '';
    url += savedSearchCriteria.zoneId.description
      ? '&' + savedSearchCriteria.zoneId.value + '=' + savedSearchCriteria.zoneId.description
      : '';
    return url;
  }

  exportDataCallback(): void {
    let url;
    if (this.activeWorker === 'active') {
      url =
        this.applicationType === 'Contractor'
          ? '/workers/contractorExcelReport?includeInactive=false'
          : '/workers/workerHotelingExcelReport?includeInactive=false';
    } else {
      url =
        this.applicationType === 'Contractor'
          ? '/workers/contractorExcelReport?includeInactive=true'
          : '/workers/workerHotelingExcelReport?includeInactive=true';
    }
    url += this.applicationType === 'Contractor' ? '&isContractor=true' : '';
    if (this.basicSearch) {
      url = this.buildBasicWorkerSearchExportQuery(this.basicSearchEvent, url);
    } else {
      url = this.buildAdvancedWorkerSearchExportQueryParamOne(this.savedSearchCriteria, url);
      url = this.buildAdvancedWorkerSearchExportQueryParamTwo(this.savedSearchCriteria, url);
    }
    url += '&sortColumn=' + this.sortColumn;
    url += '&sortOrder=' + this.sortDirection;
    url += '&limit=1000';
    this.utilityService.exportTableService(
      url,
      'HotelingAndLocation.xls',
      'application/vnd.ms-excel'
    );
  }
  /**
   * First page
   */
  firstPage(): void {
    this.getWorkersList(this.limit, 0);
  }

  /**
   * Format phone number on input, paste, blur, or change events
   * Also used when phone number is assigned from TypeScript
   */
  formatPhoneNumber(): void {
    if (!this.workerEditModel.telephone?.telephoneNo) {
      return;
    }

    const phoneNumber = this.workerEditModel.telephone.telephoneNo
      .toString()
      .trim()
      .replace(/\D/g, '');

    if (phoneNumber.length === 0) {
      this.workerEditModel.telephone.telephoneNo = '';
      return;
    }

    let formatted = '';
    if (phoneNumber.length <= 3) {
      formatted = `(${phoneNumber}`;
    } else if (phoneNumber.length <= 6) {
      formatted = `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
    } else {
      formatted = `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3, 6)}-${phoneNumber.slice(6, 10)}`;
    }

    this.workerEditModel.telephone.telephoneNo = formatted;
  }

  /**
   * Set telephone number with automatic formatting
   * Use this method when assigning phone numbers from TypeScript
   */
  setFormattedPhoneNumber(phoneNumber: string): void {
    if (this.workerEditModel.telephone) {
      this.workerEditModel.telephone.telephoneNo = phoneNumber;
      this.formatPhoneNumber();
    }
  }

  /**
   * Reset timeout
   */
  resetTimeout(): void {
    // Reset timeout logic would be implemented here
  }

  /**
   * Process failure message
   * Removes URL from error messages to match old AngularJS app behavior
   */
  private processFailureMessage(error: any, defaultMessage: string): string {
    let message = '';
    
    if (error?.data?.message) {
      message = error.data.message;
    } else if (error?.error?.message) {
      message = error.error.message;
    } else if (error?.message) {
      message = error.message;
    } else {
      return defaultMessage;
    }
    
    // Remove URL from error message (Angular HttpErrorResponse includes URL by default)
    // Pattern: "Http failure response for http://...: 400 Bad Request"
    // We want to keep only the status and message part
    const urlPattern = /Http failure response for [^:]+:\s*/i;
    message = message.replace(urlPattern, '');
    
    // Also remove any remaining URLs
    const httpPattern = /https?:\/\/[^\s]+/gi;
    message = message.replace(httpPattern, '');
    
    return message.trim() || defaultMessage;
  }

  /**
   * Handle page size change event from pagination component
   */
  pageSizeChangedEvent(limit: number): void {
    this.limit = limit;
    this.getWorkersList(this.limit, 0);
  }

  /**
   * Handle page change event from pagination component
   */
  onPageChanged(pageNumber: number): void {
    const skip = (pageNumber - 1) * this.limit;
    this.getWorkersList(this.limit, skip);
  }

  /**
   * Check if any worker is in edit mode
   */
  isAnyWorkerInEditMode(): boolean {
    return this.workerModel.workerList.some((worker: Worker) => worker.editMode);
  }
}
