import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { HotelingAndLocationService } from '../services/hoteling-and-location.service';

export interface LocationData {
  building: string;
  floor: string;
  corridor: string;
  suite: string;
  room: string;
  zone: string;
}

export interface TelephoneData {
  telephoneNumber: string;
  extension: string;
  telephoneType: string;
}

export interface WorkerEditData {
  workerId: string;
  workerName: string;
  location: LocationData;
  telephone: TelephoneData;
  teleworkProgram: string;
  hotelingProgram: string;
}

@Component({
  selector: 'app-hoteling-edit',
  templateUrl: './hoteling-edit.component.html',
  styleUrls: ['./hoteling-edit.component.scss'],
})
export class HotelingEditComponent implements OnInit, OnDestroy {
  @Input() workerData: WorkerEditData | null = null;
  @Input() isEditMode = false;
  @Input() isSaving = false;
  @Input() saveError: string | null = null;

  @Output() saveClicked = new EventEmitter<WorkerEditData>();
  @Output() cancelClicked = new EventEmitter<void>();
  @Output() dataChanged = new EventEmitter<WorkerEditData>();

  private destroy$ = new Subject<void>();

  editData: WorkerEditData = {
    workerId: '',
    workerName: '',
    location: {
      building: '',
      floor: '',
      corridor: '',
      suite: '',
      room: '',
      zone: '',
    },
    telephone: {
      telephoneNumber: '',
      extension: '',
      telephoneType: '',
    },
    teleworkProgram: '',
    hotelingProgram: '',
  };

  locationFields = [
    { key: 'building', label: 'Building', placeholder: 'Enter building' },
    { key: 'floor', label: 'Floor', placeholder: 'Enter floor' },
    { key: 'corridor', label: 'Corridor', placeholder: 'Enter corridor' },
    { key: 'suite', label: 'Suite', placeholder: 'Enter suite' },
    { key: 'room', label: 'Room', placeholder: 'Enter room' },
    { key: 'zone', label: 'Zone', placeholder: 'Enter zone' },
  ];

  telephoneTypes = [
    { value: 'office', label: 'Office' },
    { value: 'mobile', label: 'Mobile' },
    { value: 'home', label: 'Home' },
    { value: 'other', label: 'Other' },
  ];

  isFormValid = true;
  formErrors: { [key: string]: string } = {};

  constructor(private hotelingService: HotelingAndLocationService) {}

  ngOnInit(): void {
    if (this.workerData) {
      this.editData = JSON.parse(JSON.stringify(this.workerData));
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onLocationFieldChange(fieldKey: string, event: Event): void {
    this.editData.location[fieldKey as keyof LocationData] = (
      event.target as HTMLInputElement
    ).value;
    this.validateForm();
    this.dataChanged.emit(this.editData);
  }

  onTelephoneFieldChange(fieldKey: string, event: Event): void {
    this.editData.telephone[fieldKey as keyof TelephoneData] = (
      event.target as HTMLInputElement
    ).value;
    this.validateForm();
    this.dataChanged.emit(this.editData);
  }

  onProgramChange(programType: string, event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    if (programType === 'telework') {
      this.editData.teleworkProgram = value;
    } else if (programType === 'hoteling') {
      this.editData.hotelingProgram = value;
    }
    this.validateForm();
    this.dataChanged.emit(this.editData);
  }

  validateForm(): void {
    this.formErrors = {};
    this.isFormValid = true;

    // Validate telephone number if provided
    if (this.editData.telephone.telephoneNumber.trim()) {
      if (!this.isValidPhoneNumber(this.editData.telephone.telephoneNumber)) {
        this.formErrors['telephoneNumber'] = 'Invalid telephone number format';
        this.isFormValid = false;
      }
    }

    // Validate extension if provided
    if (this.editData.telephone.extension.trim()) {
      if (!this.isValidExtension(this.editData.telephone.extension)) {
        this.formErrors['extension'] = 'Extension must be numeric';
        this.isFormValid = false;
      }
    }

    // Validate location fields - at least one should be filled
    const locationFilled = Object.values(this.editData.location).some((val) => val && val.trim());
    if (!locationFilled && !this.editData.telephone.telephoneNumber.trim()) {
      this.formErrors['location'] = 'At least one location or telephone field must be filled';
      this.isFormValid = false;
    }
  }

  isValidPhoneNumber(phoneNumber: string): boolean {
    // Simple validation: allow digits, spaces, dashes, parentheses, and plus sign
    const phoneRegex = /^[\d\s\-\+\(\)]+$/;
    return phoneRegex.test(phoneNumber) && phoneNumber.replace(/\D/g, '').length >= 10;
  }

  isValidExtension(extension: string): boolean {
    // Extension should be numeric
    return /^\d+$/.test(extension);
  }

  onSave(): void {
    this.validateForm();
    if (this.isFormValid) {
      this.saveClicked.emit(this.editData);
    }
  }

  onCancel(): void {
    this.cancelClicked.emit();
  }

  resetForm(): void {
    if (this.workerData) {
      this.editData = JSON.parse(JSON.stringify(this.workerData));
      this.formErrors = {};
      this.isFormValid = true;
    }
  }

  getLocationFieldValue(fieldKey: string): string {
    return this.editData.location[fieldKey as keyof LocationData] || '';
  }

  getTelephoneFieldValue(fieldKey: string): string {
    return this.editData.telephone[fieldKey as keyof TelephoneData] || '';
  }

  hasError(fieldName: string): boolean {
    return !!this.formErrors[fieldName];
  }

  getErrorMessage(fieldName: string): string {
    return this.formErrors[fieldName] || '';
  }
}
