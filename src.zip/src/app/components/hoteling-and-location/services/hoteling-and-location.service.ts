import { Injectable } from '@angular/core';
import { Observable, throwError, of } from 'rxjs';
import { catchError, switchMap, map } from 'rxjs/operators';
import { HttpService } from 'src/app/services/http.service';

export interface WorkerLocation {
  workerAssignmentId: string;
  primaryLocationIndicator: boolean;
  assignmentLocation: any;
  [key: string]: any;
}

export interface WorkerTelephone {
  workerTelecomeAddressId?: string;
  telephoneNo: string;
  primaryIndicator?: boolean;
  alphabeticalDirIndicator?: boolean;
  publishOrgDirIndicator?: boolean;
  lifecycle?: { beginDate: string };
  telecomAddressType?: { id: number };
  [key: string]: any;
}

export interface WorkerData {
  workerId: string;
  workerNumber: string;
  familyName: string;
  preferredFirstName: string;
  location?: WorkerLocation;
  telephone?: WorkerTelephone;
  addTelecommuncation?: boolean;
  addLocation?: boolean;
  [key: string]: any;
}

@Injectable({
  providedIn: 'root',
})
export class HotelingAndLocationService {
  constructor(private httpService: HttpService) {}

  /**
   * Gets worker primary location
   */
  getWorkerLocation(worker: WorkerData): Observable<WorkerLocation> {
    return this.httpService.get(`/workers/${worker.workerId}/assignments`).pipe(
      map((response: any) => {
        const locations = response.data?.results || [];
        let primaryLocation: WorkerLocation | undefined;
        locations.forEach((location: WorkerLocation) => {
          if (location.primaryLocationIndicator) {
            primaryLocation = location;
          }
        });
        return primaryLocation || ({} as WorkerLocation);
      }),
      catchError((error) => throwError(() => error))
    );
  }

  /**
   * Updates worker information including location and telephone
   * Matches the old AngularJS flow: save telephone first, then location
   */
  updateWorkerInformation(worker: WorkerData): Observable<any> {
    // Check if telephone has actual data to save
    const hasTelephoneData = worker.telephone && worker.telephone.telephoneNo && worker.telephone.telephoneNo.trim().length > 0;
    
    // If no telephone data, just save location
    if (!hasTelephoneData) {      return this.saveWorkerLocation(worker);
    }    const url = this.buildTelephoneUrl(worker);

    // Prepare the telephone payload
    const telephonePayload = this.prepareTelephonePayload(worker);

    // Use POST for adding new telephone, PUT for updating existing
    const httpCall = worker.addTelecommuncation
      ? this.httpService.post(url, telephonePayload)
      : this.httpService.put(url, telephonePayload);

    return httpCall.pipe(
      catchError((error) => {
        if (error.status === 409) {
          error.message = `Worker ${worker.workerNumber} has been changed by another user. Please refresh screen`;
        } else {
          error.message = `Worker ${worker.workerNumber}: ${error.data?.message || error.message}`;
        }
        return throwError(() => error);
      }),
      // After telephone is saved, check if we need to save location
      switchMap((response) => {
        // If no location to save, return the telephone response as a successful observable
        if (!worker.location?.assignmentLocation) {
          return of(response);
        }
        // Chain the location save after successful telephone save
        return this.saveWorkerLocation(worker);
      })
    );
  }

  /**
   * Prepares the complete telephone payload matching the old AngularJS app structure
   * This ensures all required fields are sent to the backend API
   */
  private prepareTelephonePayload(worker: WorkerData): any {
    const telephone = worker.telephone;
    
    if (worker.addTelecommuncation) {
      // For new telephone records (POST)
      return {
        telephoneNo: telephone?.telephoneNo || '',
        primaryIndicator: true,
        alphabeticalDirIndicator: false,
        publishOrgDirIndicator: false,
        lifecycle: {
          beginDate: this.getTimeNow(),
        },
        telecomAddressType: {
          id: 3,
          value: 'T',
          description: 'Telephone'
        },
        extensionNo: telephone?.extensionNo || null,
        hiddenIndicator: telephone?.hiddenIndicator || null,
        telephoneBookText: telephone?.telephoneBookText || null,
        telecomAddressStatus: 'A'
      };
    } else {
      // For updating existing telephone records (PUT)
      // Send the complete telephone object with all existing fields preserved
      return {
        workerTelecomeAddressId: telephone?.workerTelecomeAddressId,
        telephoneNo: telephone?.telephoneNo || '',
        primaryIndicator: telephone?.primaryIndicator !== undefined ? telephone.primaryIndicator : true,
        alphabeticalDirIndicator: telephone?.alphabeticalDirIndicator !== undefined ? telephone.alphabeticalDirIndicator : false,
        publishOrgDirIndicator: telephone?.publishOrgDirIndicator !== undefined ? telephone.publishOrgDirIndicator : false,
        extensionNo: telephone?.extensionNo || null,
        hiddenIndicator: telephone?.hiddenIndicator || null,
        telephoneBookText: telephone?.telephoneBookText || null,
        telecomAddressStatus: telephone?.telecomAddressStatus || 'A',
        telecomAddressType: telephone?.telecomAddressType || {
          id: 3,
          value: 'T',
          description: 'Telephone'
        },
        lifecycle: telephone?.lifecycle || {
          beginDate: telephone?.lifecycle?.beginDate || this.getTimeNow()
        },
        audit: telephone?.audit || null,
        assignment: telephone?.assignment || null,
        worker: telephone?.worker || {
          workerId: worker.workerId,
          workerNumber: worker.workerNumber,
          familyName: worker.familyName,
          givenName: worker.givenName || worker.preferredFirstName
        }
      };
    }
  }

  /**
   * Saves worker location
   */
  private saveWorkerLocation(worker: WorkerData): Observable<any> {
    const url = `/workers/${worker.workerId}/assignments/${worker.location?.workerAssignmentId}`;
    return this.httpService.put(url, worker.location).pipe(
      catchError((error) => {
        if (error.status === 409) {
          error.message = `Worker ${worker.workerNumber} has been changed by another user. Please refresh screen`;
        } else {
          error.message = `Worker ${worker.workerNumber}: ${error.data?.message || error.message}`;
        }
        return throwError(() => error);
      })
    );
  }

  /**
   * Builds telephone URL based on add or update operation
   */
  private buildTelephoneUrl(worker: WorkerData): string {
    if (worker.addTelecommuncation) {
      return `/workers/${worker.workerId}/telecommunications/`;
    }
    
    // Check for various possible ID field names in the telephone object
    const telephoneId = worker.telephone?.workerTelecomeAddressId
      || worker.telephone?.workerTelecomAddressId
      || worker.telephone?.id
      || worker.telephone?.telecommunicationId;
    
    if (!telephoneId) {      throw new Error('Telephone ID is required for updating existing telephone');
    }
    
    return `/workers/${worker.workerId}/telecommunications/${telephoneId}`;
  }

  /**
   * Gets current time in ISO format
   */
  private getTimeNow(): string {
    return new Date().toISOString();
  }
}
