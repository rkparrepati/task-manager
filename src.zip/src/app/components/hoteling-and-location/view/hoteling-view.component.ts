import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

export interface LocationData {
  building: string;
  floor: string;
  corridor: string;
  suite: string;
  room: string;
  zone: string;
}

export interface TelephoneData {
  telephoneNumber: string;
  extension: string;
  telephoneType: string;
}

export interface WorkerViewData {
  workerId: string;
  workerName: string;
  location: LocationData;
  telephone: TelephoneData;
  teleworkProgram: string;
  hotelingProgram: string;
  lastUpdated?: string;
  updatedBy?: string;
}

@Component({
  selector: 'app-hoteling-view',
  templateUrl: './hoteling-view.component.html',
  styleUrls: ['./hoteling-view.component.scss'],
})
export class HotelingViewComponent implements OnInit, OnDestroy {
  @Input() workerData: WorkerViewData | null = null;
  @Input() isViewMode = false;
  @Input() isLoading = false;

  @Output() editClicked = new EventEmitter<WorkerViewData>();
  @Output() closeClicked = new EventEmitter<void>();
  @Output() printClicked = new EventEmitter<WorkerViewData>();

  private destroy$ = new Subject<void>();

  locationFields = [
    { key: 'building', label: 'Building' },
    { key: 'floor', label: 'Floor' },
    { key: 'corridor', label: 'Corridor' },
    { key: 'suite', label: 'Suite' },
    { key: 'room', label: 'Room' },
    { key: 'zone', label: 'Zone' },
  ];

  telephoneTypeLabels: { [key: string]: string } = {
    office: 'Office',
    mobile: 'Mobile',
    home: 'Home',
    other: 'Other',
  };

  programStatusLabels: { [key: string]: string } = {
    enrolled: 'Enrolled',
    pending: 'Pending',
    inactive: 'Inactive',
    '': 'Not Enrolled',
  };

  constructor() {}

  ngOnInit(): void {
    // Initialize view component
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onEdit(): void {
    if (this.workerData) {
      this.editClicked.emit(this.workerData);
    }
  }

  onClose(): void {
    this.closeClicked.emit();
  }

  onPrint(): void {
    if (this.workerData) {
      this.printClicked.emit(this.workerData);
      window.print();
    }
  }

  getLocationFieldValue(fieldKey: string): string {
    if (!this.workerData) {
      return '';
    }
    return this.workerData.location[fieldKey as keyof LocationData] || '';
  }

  getTelephoneFieldValue(fieldKey: string): string {
    if (!this.workerData) {
      return '';
    }
    return this.workerData.telephone[fieldKey as keyof TelephoneData] || '';
  }

  hasLocationData(): boolean {
    if (!this.workerData) {
      return false;
    }
    return Object.values(this.workerData.location).some((val) => val && val.trim());
  }

  hasTelephoneData(): boolean {
    if (!this.workerData) {
      return false;
    }
    return Object.values(this.workerData.telephone).some((val) => val && val.trim());
  }

  getTelephoneTypeLabel(type: string): string {
    return this.telephoneTypeLabels[type] || type;
  }

  getProgramStatusLabel(status: string): string {
    return this.programStatusLabels[status] || status;
  }

  getProgramStatusClass(status: string): string {
    switch (status) {
      case 'enrolled':
        return 'badge-success';
      case 'pending':
        return 'badge-warning';
      case 'inactive':
        return 'badge-danger';
      default:
        return 'badge-secondary';
    }
  }

  formatPhoneNumber(phoneNumber: string): string {
    if (!phoneNumber) {
      return '';
    }
    // Remove all non-digit characters
    const cleaned = phoneNumber.replace(/\D/g, '');
    // Format as (XXX) XXX-XXXX if it's 10 digits
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phoneNumber;
  }

  isDataAvailable(): boolean {
    return this.isViewMode && this.workerData !== null;
  }
}
