import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, map, switchMap } from 'rxjs/operators';
import { AppService } from 'src/app/services/app.service';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';

@Component({
  selector: 'app-bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrls: ['./bread-crumb.component.scss'],
})
export class BreadCrumbComponent implements OnInit {
  breadcrumbs: Array<any> = [];
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    public appService: AppService,
    private breadcrumbService: BreadcrumbService
  ) {}

  ngOnInit() {
    // Listen to breadcrumb service updates (for dynamic breadcrumb changes)
    this.breadcrumbService.breadcrumb$.subscribe((breadcrumbs) => {
      if (breadcrumbs && breadcrumbs.length > 0) {
        this.breadcrumbs = breadcrumbs;
      } else {
        // If no breadcrumbs from service, use route data
        this.updateBreadcrumbs();
      }
    });

    // Trigger the breadcrumb logic on initial load
    this.updateBreadcrumbs();

    // Update breadcrumbs on navigation events
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      this.updateBreadcrumbs();
    });

    // Also listen for route data changes (for dynamic breadcrumb updates)
    this.activatedRoute.data.subscribe(() => {
      this.updateBreadcrumbs();
    });
  }

  private updateBreadcrumbs() {
    let route = this.activatedRoute;
    while (route.firstChild) {
      route = route.firstChild;
    }

    route.data.pipe(map((data) => data.breadcrumb || [])).subscribe((value) => {
      this.breadcrumbs = value;
    });
  }
}
