import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  getReportDetails(relocation: any, limit?: number, skip?: number) {
    const url = `/workerAssignmentPlans?relocationPlanId=${relocation.relocationPlanId || ''}&relocationPlanName=${relocation.relocationPlanName || ''}&limit=${limit?.toString() || ''}&skip=${skip?.toString() || ''}`;
    return this.httpService.get(url);
  }

  getReportInfo() {
    return this.httpService.get('/gaumove');
  }
}
