const reportUrl = {
  getReport: (reportId: string) => `/api/reports/${reportId}`,
  // getAllReports: () => '/api/reports',
  // createReport: () => '/api/reports',
  // updateReport: (reportId: string) => `/api/reports/${reportId}`,
  // deleteReport: (reportId: string) => `/api/reports/${reportId}`,
  // downloadReport: (reportId: string) => `/api/reports/${reportId}/download`,
};
const reportColumns: string[] = [
  'status',
  'applicationTypeNumber',
  'lastName',
  'firstName',
  'preferredFirstName',
  'loginId',
  'acronym',
  'building',
  'location',
  'jobClass',
  'firmName',
  'phoneNumber',
  'actions',
];
