import { Component, OnInit } from '@angular/core';

import { ReportModel } from './model/reportModel';
interface ColumnDefinition {
  key: string;
  header: string;
}

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
})
export class ReportsComponent implements OnInit {
  myData = [
    { name: 'John', age: 30 },
    { name: 'Jane', age: 25 },
  ];
  myColumns: ColumnDefinition[] = [
    { key: 'name', header: 'Name' },
    { key: 'age', header: 'Age' },
  ];
  public columns: any[] = [];
  public data: any[] = [];
  public model!: ReportModel;
  title: string = 'Reports Landing Page';
  constructor() {
    //  this.reportserviceService.getWorkersRelationships('200061', false).subscribe(reports => {
    //             this.model=reports;
    //         })
  }
  ngOnInit() {
    this.columns = [
      { field: 'reportName', header: 'Worker name' },
      { field: 'reportType', header: 'Organization' },
      { field: 'createdBy', header: 'Organization Suffix' },
      { field: 'employee', header: 'Employee #' },
      { field: 'defaultReporting', header: 'Default Reporting' },
      { field: 'appraisalsReporting', header: 'Performance Appraisals reporting' },
    ];
    this.data = [
      {
        reportName: 'Testing Relocation Plan Details',
        reportType: 'Relocation',
        createdBy: 'Admin',
        employee: 'Employee1',
        defaultReporting: 'Default Reporting',
        appraisalsReporting: 'Performance appraisalsReporting',
      },
      {
        reportName: 'Relocation Plan Details',
        reportType: 'Relocation1',
        createdBy: 'Admin1',
        employee: 'Employee2',
        defaultReporting: 'Default Reporting1',
        appraisalsReporting: 'Performance appraisalsReporting1',
      },
    ]; // Initialization logic can go here if needed
  }
  getReport() {
    // this.workerManagementService.validateContractorId(this.workerBase.worker.birthDate, this.workerBase.worker.ssnLast2Digits)
    //     .subscribe((response: any) => {
    //       this.validationBooleans.invalidContractorIdErrorMsg = "";
    //       this.validationBooleans.invalidContractorId = false;
    //       this.addWorker();
    //     }, (error: any) => {
    //       this.validationBooleans.invalidContractorIdErrorMsg =
    //         "Contractor ID (DOB + Last 2 SSN) already exists for user " +
    //         error.workerNumber + ". Please provide a different DOB/Last 2 SSN combination";
    //       this.validationBooleans.invalidContractorId = true;
    //       this.addWorker();
    //     });
  }
}
