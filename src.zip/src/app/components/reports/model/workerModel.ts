export interface WorkerModel {
  name: string;
  workerId: number;
  workerNumber: string;
  familyName: string;
  givenName: string;
  middleName: null;
  preferredFirstName: string;
  loginId: string;
  emailAddress: string;
  patronId: null;
  positionOrganizationListing: string;
  activeEmploymentIndicator: boolean;
  supervisorIndicator: boolean;
  otherFederalAgencyIndicator: boolean;
  publishOrganizationDirectoryIndicator: boolean;
  internetDisplayIndicator: boolean;
  intranetDisplayIndicator: boolean;
  hotelDisplayIndicator: boolean;
  rehireIndicator: boolean;
  notes: null;
  serviceAccountIndicator: null;
  jobClass: AppointmentType;
  directoryTitleType: null;
  employmentType: AppointmentType;
  contractorFirm: null;
  leaveAccrual: AppointmentType;
  appointmentType: AppointmentType;
  occupationalSeries: AppointmentType;
  occupationalSeriesTitle: OccupationalSeriesTitle;
  bargainUnitType: AppointmentType;
  positionSensitivity: AppointmentType;
  teleworkProgram: null;
  standardTourOfDuty: AppointmentType;
  communicationHistory: any[];
  organizationHistory: OrganizationHistory[];
  auxiliaryRoleSummary: any[];
  secure: null;
  capabilities: any[];
  payPlan: PayPlan;
  workerOrganizationSufix: WorkerOrganizationSufix;
  workerTrademarkFlag: null;
  lifecycle: Lifecycle;
  audit: Audit;
}

export interface AppointmentType {
  id: number;
  value: string;
  description: string;
  shortDescription?: string;
}

export interface Audit {
  createdDate: Date;
  createdUser: string;
  lastModifiedDate: Date;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface Lifecycle {
  beginDate: Date;
}

export interface OccupationalSeriesTitle {
  occupationalSeriesTitleId: number;
  value: string;
  description: string;
}

export interface OrganizationHistory {
  workerOrganizationId: number;
  primaryOrganizationIndicator: boolean;
  organization: Organization;
  organizationStatusCurrent: string;
  lifecycle: Lifecycle;
  locationSummary: LocationSummaryElement[];
  reportRoleList: any[];
  workerOrganizationQueue: null;
}

export interface LocationSummaryElement {
  workerAssignmentId: number;
  assignmentStatusCurrent: string;
  locationSummary: LocationSummaryLocationSummary;
  primaryLocationIn: boolean;
  suffixId: number;
}

export interface LocationSummaryLocationSummary {
  locationId: number;
  corridorId: string;
  roomId: string;
  suiteId: string;
  zoneId: string;
  building: Building;
}

export interface Building {
  buildingFloorId: number;
  floorNumber: string;
  buildingId: number;
  code: string;
  name: string;
}

export interface Organization {
  id: number;
  shortName: string;
  name: string;
  businessAreaCode: string;
}

export interface PayPlan {
  employeeGradeId: number;
  employeeGradeStepId: number;
  payPlanGradeId: number;
  currentGrade: AppointmentType;
  currentStep: AppointmentType;
  currentPayPlan: AppointmentType;
  gradeLifecycle: Lifecycle;
  stepLifecycle: Lifecycle;
  gradeAudit: Audit;
  stepAudit: Audit;
}

export interface WorkerOrganizationSufix {
  workerOrganizationSufixId: number;
  workerId: number;
  sufixTx: string;
  audit: Audit;
}
