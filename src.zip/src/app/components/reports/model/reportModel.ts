export interface ReportModel {
  meta: Meta;
  results: Result[];
}

export interface Meta {
  total: number;
  skip: any;
  limit: any;
}

export interface Result {
  workerRelationshipId: number;
  primaryIn: boolean;
  baseWorker: BaseWorker;
  relatedWorker: RelatedWorker;
  relationshipSummary: RelationshipSummary;
  organizationHistory: OrganizationHistory[];
  lifecycle: Lifecycle2;
  audit: Audit;
}

export interface BaseWorker {
  workerId: number;
  workerNumber: string;
  familyName: string;
  givenName: string;
  preferredFirstName: string;
  loginId?: string;
  activeEmploymentIndicator: boolean;
  emailAddress: string;
}

export interface RelatedWorker {
  workerId: number;
  workerNumber: string;
  familyName: string;
  givenName: string;
  preferredFirstName: string;
  loginId?: string;
  activeEmploymentIndicator: boolean;
  emailAddress: string;
}

export interface RelationshipSummary {
  id: number;
  value: string;
  description: string;
  primaryIn: boolean;
}

export interface OrganizationHistory {
  workerOrganizationId: number;
  primaryOrganizationIndicator: boolean;
  organization: Organization;
  organizationStatusCurrent: string;
  lifecycle: Lifecycle;
  locationSummary: LocationSummary[];
  reportRoleList: any[];
  workerOrganizationQueue: any;
}

export interface Organization {
  id: number;
  shortName: string;
  name: string;
  businessAreaCode: string;
}

export interface Lifecycle {
  beginDate: string;
}

export interface LocationSummary {
  workerAssignmentId: number;
  assignmentStatusCurrent: string;
  locationSummary?: LocationSummary2;
  primaryLocationIn: boolean;
  suffixId: number;
}

export interface LocationSummary2 {
  locationId: number;
  corridorId?: string;
  roomId?: string;
  suiteId: any;
  zoneId: any;
  building: Building;
}

export interface Building {
  buildingFloorId: number;
  floorNumber: string;
  buildingId: number;
  code: string;
  name: string;
}

export interface Lifecycle2 {
  beginDate: string;
}

export interface Audit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}
