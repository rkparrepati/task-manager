export interface ReportRequest {
  name: string;
  value: string;
  type: string;
}
