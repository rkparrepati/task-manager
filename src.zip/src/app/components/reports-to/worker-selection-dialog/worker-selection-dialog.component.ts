import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CustomDialogRef } from '../../../services/dialog.service';

export interface WorkerSelectionData {
  workers: any[];
  type: string;
  title?: string;
}

/**
 * Worker Selection Dialog Component
 * Allows users to select a worker from a list
 * No Material dependencies
 */
@Component({
  selector: 'app-worker-selection-dialog',
  templateUrl: './worker-selection-dialog.component.html',
  styleUrls: ['./worker-selection-dialog.component.scss'],
})
export class WorkerSelectionDialogComponent implements OnInit, OnDestroy {
  @Input() data: WorkerSelectionData = { workers: [], type: '' };
  @Output() selected = new EventEmitter<any>();
  @Output() cancelled = new EventEmitter<void>();

  selectedWorker: any = null;
  displayedColumns: string[] = ['workerNumber', 'firstName', 'lastName', 'organization', 'select'];
  private destroy$ = new Subject<void>();

  constructor(public dialogRef: CustomDialogRef<any>) {}

  ngOnInit(): void {
    if (this.data.workers && this.data.workers.length > 0) {
      this.selectedWorker = this.data.workers[0];
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  selectWorker(worker: any): void {
    this.selectedWorker = worker;
  }

  confirm(): void {
    if (this.selectedWorker) {
      this.selected.emit(this.selectedWorker);
      this.dialogRef.close({
        worker: this.selectedWorker,
        type: this.data.type,
      });
    }
  }

  cancel(): void {
    this.cancelled.emit();
    this.dialogRef.close(null);
  }

  getWorkerDisplayName(worker: any): string {
    return `${worker.firstName || ''} ${worker.lastName || ''} (${worker.workerNumber || ''})`.trim();
  }
}
