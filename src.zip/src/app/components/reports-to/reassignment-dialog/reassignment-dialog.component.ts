import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ReportserviceService } from '../../../services/reportservice.service';
import { FormValidationService } from '../../../services/form-validation.service';
import { CustomDialogRef } from '../../../services/dialog.service';

export interface ReassignmentData {
  worker: any;
  currentSupervisor: any;
  type: string;
  relationshipId: number;
}

export interface ReassignmentResult {
  action: 'assignToMe' | 'reassignToOther' | 'remove';
  supervisor?: any;
  worker: any;
  type: string;
}

/**
 * Reassignment Dialog Component
 * Allows users to reassign workers to different supervisors
 * No Material dependencies
 */
@Component({
  selector: 'app-reassignment-dialog',
  templateUrl: './reassignment-dialog.component.html',
  styleUrls: ['./reassignment-dialog.component.scss'],
})
export class ReassignmentDialogComponent implements OnInit, OnDestroy {
  @Input() data: ReassignmentData = {
    worker: null,
    currentSupervisor: null,
    type: '',
    relationshipId: 0,
  };
  @Output() reassigned = new EventEmitter<ReassignmentResult>();
  @Output() cancelled = new EventEmitter<void>();

  reassignmentForm: FormGroup;
  selectedAction: 'assignToMe' | 'reassignToOther' | 'remove' | null = null;
  supervisorList: any[] = [];
  filteredSupervisors: any[] = [];
  isLoading = false;
  errorMessage = '';
  successMessage = '';
  currentUserInfo: any = null;

  private destroy$ = new Subject<void>();
  private searchSubject = new Subject<string>();

  constructor(
    private fb: FormBuilder,
    private reportService: ReportserviceService,
    private formValidationService: FormValidationService,
    public dialogRef: CustomDialogRef<ReassignmentResult>
  ) {
    this.reassignmentForm = this.fb.group({
      supervisorSearch: ['', [Validators.minLength(2)]],
      selectedSupervisor: [null],
    });
  }

  ngOnInit(): void {
    this.loadCurrentUserInfo();
    this.setupSearchDebounce();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadCurrentUserInfo(): void {
    this.reportService
      .getUserInfo()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.currentUserInfo = response.data;
        },
        (error: any) => {        }
      );
  }

  private setupSearchDebounce(): void {
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((searchTerm: string) => {
        this.searchSupervisors(searchTerm);
      });
  }

  selectAction(action: 'assignToMe' | 'reassignToOther' | 'remove'): void {
    this.selectedAction = action;
    this.errorMessage = '';
    this.successMessage = '';

    if (action === 'assignToMe') {
      this.reassignmentForm.reset();
    } else if (action === 'reassignToOther') {
      this.loadSupervisorList();
    }
  }

  onSupervisorSearch(event: any): void {
    const searchTerm = event.target.value || '';
    this.searchSubject.next(searchTerm);
  }

  private searchSupervisors(searchTerm: string): void {
    if (searchTerm.length < 2) {
      this.filteredSupervisors = [];
      return;
    }

    this.isLoading = true;
    this.reportService
      .searchWorkerNumber(searchTerm, false)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.filteredSupervisors = response.results || [];
          this.isLoading = false;
        },
        (error: any) => {          this.filteredSupervisors = [];
          this.isLoading = false;
        }
      );
  }

  private loadSupervisorList(): void {
    this.isLoading = true;
    this.reportService
      .getSupervisorList(this.data.worker.id, false, 'name', 'asc')
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.supervisorList = response.data || [];
          this.filteredSupervisors = this.supervisorList;
          this.isLoading = false;
        },
        (error: any) => {          this.errorMessage = 'Failed to load supervisor list';
          this.isLoading = false;
        }
      );
  }

  selectSupervisor(supervisor: any): void {
    this.reassignmentForm.patchValue({
      selectedSupervisor: supervisor,
      supervisorSearch: this.getSupervisorDisplayName(supervisor),
    });
    this.filteredSupervisors = [];
  }

  getSupervisorDisplayName(supervisor: any): string {
    return `${supervisor.firstName || ''} ${supervisor.lastName || ''} (${supervisor.workerNumber || ''})`.trim();
  }

  confirm(): void {
    if (!this.selectedAction) {
      this.errorMessage = 'Please select an action';
      return;
    }

    if (this.selectedAction === 'assignToMe') {
      this.confirmAssignToMe();
    } else if (this.selectedAction === 'reassignToOther') {
      this.confirmReassignToOther();
    } else if (this.selectedAction === 'remove') {
      this.confirmRemove();
    }
  }

  private confirmAssignToMe(): void {
    if (!this.currentUserInfo) {
      this.errorMessage = 'Unable to determine current user';
      return;
    }

    const result: ReassignmentResult = {
      action: 'assignToMe',
      supervisor: this.currentUserInfo,
      worker: this.data.worker,
      type: this.data.type,
    };

    this.reassigned.emit(result);
    this.dialogRef.close(result);
  }

  private confirmReassignToOther(): void {
    const selectedSupervisor = this.reassignmentForm.get('selectedSupervisor')?.value;

    if (!selectedSupervisor) {
      this.errorMessage = 'Please select a supervisor';
      return;
    }

    const result: ReassignmentResult = {
      action: 'reassignToOther',
      supervisor: selectedSupervisor,
      worker: this.data.worker,
      type: this.data.type,
    };

    this.reassigned.emit(result);
    this.dialogRef.close(result);
  }

  private confirmRemove(): void {
    const result: ReassignmentResult = {
      action: 'remove',
      worker: this.data.worker,
      type: this.data.type,
    };

    this.reassigned.emit(result);
    this.dialogRef.close(result);
  }

  cancel(): void {
    this.cancelled.emit();
    this.dialogRef.close(undefined);
  }

  getActionDescription(action: string): string {
    switch (action) {
      case 'assignToMe':
        return 'Assign this worker to me as their supervisor';
      case 'reassignToOther':
        return 'Reassign this worker to another supervisor';
      case 'remove':
        return 'Remove this worker from the current assignment';
      default:
        return '';
    }
  }

  isConfirmDisabled(): boolean {
    if (!this.selectedAction) {
      return true;
    }

    if (this.selectedAction === 'reassignToOther') {
      return !this.reassignmentForm.get('selectedSupervisor')?.value;
    }

    return false;
  }
}
