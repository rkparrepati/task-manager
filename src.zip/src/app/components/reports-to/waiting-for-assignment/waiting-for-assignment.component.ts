import { Component, OnChanges, OnInit, SimpleChanges, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ColumnDefinition, IWaitingAssignment } from '../../reports-to/Models/IWorkerDetails';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import {
  buildAssignment,
  buildWaitingForAssignmentRows,
  sendEmail,
} from '../../reports-to/reportToUtil';
import { constants } from '../../reports-to/Models/MasterData';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-waiting-for-assignment',
  templateUrl: './waiting-for-assignment.component.html',
  styleUrls: ['./waiting-for-assignment.component.scss'],
})
export class WaitingForAssignmentComponent implements OnInit, OnChanges, OnDestroy {
  @Input() waitingList: any[] = [];
  @Input() reportToTypes: any[] = [];
  @Output() assignmentSuccess = new EventEmitter<{ returnCode: number; returnMessage: string }>();

readonly todayDate = new Date();
  endDate: string = '';
  formDate: string = '';
  showWait: boolean = false;
  showWaitSave: boolean = false;
  data: any[] = [];
  columns: ColumnDefinition[] = [];
  dataSource = new MatTableDataSource<IWaitingAssignment>([]);
  displayedColumns: string[] = [];
  tableTitle: string = 'Waiting for Assignment';
  waitsortColumn: string = 'name';
  waitsortDirection: string = 'asc';
  waitReverse: boolean = false;
  waittotal: number = 0;

  private destroy$ = new Subject<void>();

  constructor(
    private reportserviceService: ReportserviceService,
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['columns']) {
      this.displayedColumns = this.columns.map((column) => column.key);
    }
    if (changes['waitingList'] && changes['waitingList'].currentValue) {
      this.data = changes['waitingList'].currentValue;
      this.dataSource = new MatTableDataSource<IWaitingAssignment>(this.data);
      this.waittotal = this.data.length;
    }
  }

  ngOnInit(): void {
    this.initializeDateRange();
    this.initializeColumns();
    this.getWaitingForAssignments();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Initialize date range (14 days back from today)
   */
  private initializeDateRange(): void {
    const todate: Date = new Date();
    const startDate: Date = new Date(todate);
    startDate.setDate(todate.getDate() - 14);
    this.endDate = todate.toISOString().split('T')[0];
    this.formDate = startDate.toISOString().split('T')[0];
  }

  /**
   * Initialize table columns
   */
  private initializeColumns(): void {
    this.columns = constants.accessManagementgridColumns;
    this.displayedColumns = this.columns
      .filter((column) => column.visible !== false)
      .map((column) => column.key);
  }

  /**
   * Fetch waiting for assignments data based on date range
   * Converts AngularJS getWaitingForAssignments to Angular 15 with RxJS
   */
  getWaitingForAssignments(): void {
    this.showWait = true;

    const startDate = new Date(this.formDate).toISOString().split('T')[0];
    const endDate = new Date(this.endDate).toISOString().split('T')[0];

    const url = `/waiting-for-assignments/${startDate}/${endDate}`;

    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.data = buildWaitingForAssignmentRows(response.results || []);
          
          this.dataSource = new MatTableDataSource<IWaitingAssignment>(this.data);
          this.waittotal = this.data.length;
          this.showWait = false;
        },
        (error: any) => {          this.showWait = false;
          this.data = [];
          this.dataSource = new MatTableDataSource<IWaitingAssignment>([]);
        }
      );
  }

  /**
   * Perform auto assignment with optional email notification
   * Converts AngularJS saveWaitingForAssignments to Angular 15 with RxJS
   * @param silent - If 'silent', no emails are sent; otherwise emails are sent
   */
  assignSelectedRow(silent: string = ''): void {
    const selectedRows = this.data.filter((item: any) => item.selected);

    if (!selectedRows || selectedRows.length === 0) {      return;
    }

    this.showWaitSave = true;
   const beginDate = this.utilityService.getTimeNow();
    // Build assignments for all selected rows
    const assignments: any[] = [];
    const workers: any[] = [];

    selectedRows.forEach((row: any) => {
      if (row.object && row.object.worker && row.object.examiner) {
        workers.push(row.object.worker);

        // Create assignments for all 3 report types
        assignments.push(
          buildAssignment(row.object.examiner, row.object.worker, this.reportToTypes[0].id,beginDate)
        );
        assignments.push(
          buildAssignment(row.object.examiner, row.object.worker, this.reportToTypes[1].id,beginDate)
        );
        assignments.push(
          buildAssignment(row.object.examiner, row.object.worker, this.reportToTypes[2].id,beginDate)
        );
      }
    });

    if (assignments.length === 0) {
      this.showWaitSave = false;      return;
    }

    // Make the assignment request
    const url = '/workers-relationships/assign-users';
    this.httpService
      .post(url, assignments)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showWaitSave = false;
          this.assignmentSuccess.emit({
            returnCode: 200,
            returnMessage: "Successfully assigned " + selectedRows.length + " employee(s) to all report Types."
          });

          // If not silent mode, send emails
          if (silent !== 'silent' && workers.length > 0) {
            this.sendAssignmentEmails(selectedRows[0].object.examiner, workers);
          } else {
            // Clear selections after successful assignment
            this.clearSelections();
          }
        },
        (error: any) => {
          this.showWaitSave = false;        }
      );
  }

  /**
   * Send emails to all stakeholders about the assignment
   * @param supervisor - The supervisor/examiner being assigned
   * @param workers - Array of workers being assigned
   */
  private sendAssignmentEmails(supervisor: any, workers: any[]): void {
    const reportType = {
      id: -1,
      label: 'Set All',
    };

    // Build email list using the service method
    const emailList = this.buildEmailListForAssignment(supervisor, workers, reportType);

    if (emailList && emailList.length > 0) {
      this.sendEmails(emailList);
    } else {
      this.clearSelections();
    }
  }

  /**
   * Build email list for assignment notifications
   */
  private buildEmailListForAssignment(supervisor: any, workers: any[], reportType: any): any[] {
    const emailMessages: any[] = [];

    // Email to workers about supervisor change
    let workerList = '';
    let emailToWorkers = '';

    workers.forEach((worker) => {
      if (workerList) {
        workerList += ', ' + worker.givenName + ' ' + worker.familyName;
      } else {
        workerList = worker.givenName + ' ' + worker.familyName;
      }

      if (emailToWorkers) {
        emailToWorkers += '~' + worker.emailAddress;
      } else {
        emailToWorkers = worker.emailAddress;
      }
    });

    // Email to workers
    const workerSubject = 'Your supervisor has changed for report type ' + reportType.label;
    const workerEmailInfo = {
      toMail: emailToWorkers,
      fromEmail: emailToWorkers,
      subject: workerSubject,
      message: 'Your supervisor is now ' + supervisor.givenName + ' ' + supervisor.familyName,
    };

    if (this.hasValidEmailAddress(workerEmailInfo.toMail)) {
      emailMessages.push(workerEmailInfo);
    }

    // Email to supervisor
    const supervisorSubject =
      'Workers has been assigned to you for report type ' + reportType.label;
    const supervisorMessage = 'Workers: ' + workerList + '. Reporting type is: ' + reportType.label;

    const supervisorEmailInfo = {
      toMail: supervisor.emailAddress,
      fromEmail: supervisor.emailAddress,
      subject: supervisorSubject,
      message: supervisorMessage,
    };

    if (this.hasValidEmailAddress(supervisorEmailInfo.toMail)) {
      emailMessages.push(supervisorEmailInfo);
    }

    return emailMessages;
  }

  /**
   * Send emails via HTTP service
   */
  private sendEmails(emails: any[]): void {
    if (!emails || emails.length === 0) {
      this.clearSelections();
      return;
    }

    let successCount = 0;
    let totalEmails = emails.length;

    emails.forEach((email) => {
      this.httpService
        .post('email', email)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            successCount++;
            if (successCount === totalEmails) {              this.clearSelections();
            }
          },
          (error: any) => {            successCount++;
            if (successCount === totalEmails) {
              this.clearSelections();
            }
          }
        );
    });
  }

  /**
   * Clear all selections from the table
   */
  private clearSelections(): void {
    this.data.forEach((item) => {
      item.selected = false;
    });
    this.dataSource = new MatTableDataSource<IWaitingAssignment>(this.data);
  }

  /**
   * Resort the waiting list by column
   */
  resortWaiting(column: string, direction: string): void {
    this.waitsortColumn = column;
    this.waitsortDirection = direction;
    this.waitReverse = direction === 'desc';
  }

  /**
   * Validate email address
   */
  private hasValidEmailAddress(address: string): boolean {
    return !!(address && address !== 'none@uspto.gov');
  }
}
