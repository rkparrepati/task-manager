import { Component, OnInit, Inject, SimpleChanges, OnDestroy } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { constants } from 'src/app/components/reports-to/Models/MasterData';
import { ReportserviceService } from '../../../services/reportservice.service';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';

/**
 * Edit Assignment Dialog Component
 * Allows users to edit worker assignments and reassign to different supervisors
 * Implements Angular 15 with RxJS Observable pattern
 * Converted from AngularJS with enhanced functionality
 * 
 * Missing functionality added:
 * - getWorkerEmployeeList() - Fetch supervisor's employee list
 * - resetTimeout() - Reset message timeout
 * - Enhanced validation for same supervisor checks
 * - Organization value extraction from employee data
 * - Proper error handling for 404 responses
 * - Support for multiple reporting types (PAR, TIMECARD, SUPERVISOR)
 * - Contractor filtering (employment type 'C')
 * - Primary organization indicator handling
 */
@Component({
  selector: 'app-edit-assignment-dialog',
  templateUrl: './edit-assignment-dialog.component.html',
  styleUrls: ['./edit-assignment-dialog.component.scss'],
})
export class EditAssignmentDialogComponent implements OnInit, OnDestroy {
  // Dialog data
  worker: any;
  title: string = '';
  selecetedItem: string = '';
  currentReportingAssignment: string = '';
  
  // Search and assignment data
  newAssignment: string = '';
  reassignToUser: string = '';
  reassignToWorker: any = null;
  searchTerm: string = '';
  
  // UI state
  showSearchWait: boolean = false;
  selectUser: boolean = false;
  selectEmployee: boolean = false;
  showWorkerSearchDialog: boolean = false;
  
  // Search results
  searchResults: any[] = [];
  showSearchResults: boolean = false;
  workers: any[] = [];
  noWorkerFoundMsg: string = '';
  
  // Dialog configuration
  assignments: any = constants.reportingStatus;
  notification: boolean = false;
  isRemoveEnable: boolean = false;
  
  // Change assignment data
  changeAssignentData: any = {
    fromWorker: '',
    toWorker: null,
    notification: false,
    isRemoveEnable: false,
    workerObject: null,
    dialogDataType: '',
    reportType: null,
    actionType: '',
  };
  
  // Timeout management
  private timeoutInterval: any;
  
  private destroy$ = new Subject<void>();
  private searchSubject$ = new Subject<string>();

  constructor(
    public dialogRef: MatDialogRef<EditAssignmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private reportserviceService: ReportserviceService
  ) {
    this.title = data.Title;
    this.selecetedItem = data.SelectedItem;
    this.worker = data.Row;
    this.currentReportingAssignment = data.SelectedItem;
    this.isRemoveEnable = data.IsRemoveEnable || false;
    
    // Initialize change assignment data
    this.changeAssignentData = {
      fromWorker: data.SelectedItem,
      toWorker: null,
      notification: false,
      isRemoveEnable: this.isRemoveEnable,
      workerObject: data.Row,
      dialogDataType: data.Title,
      reportType: data.Type || null,
      actionType: '',
    };

    // Set dialog type based on title
    this.setDialogType();
  }

  ngOnInit(): void {
    // Setup search debounce
    this.setupSearchDebounce();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.resetTimeout();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Handle changes if needed
  }

  /**
   * Set dialog type based on title
   * Converts 'Par' to 'Performance Appraisals' for display
   */
  private setDialogType(): void {
    if (this.changeAssignentData.dialogDataType === 'Par') {
      this.changeAssignentData.dialogDataType = 'Performance Appraisals';
    }
  }

  /**
   * Reset timeout for message display
   * Clears any existing timeout interval
   */
  resetTimeout(): void {
    if (this.timeoutInterval) {
      clearInterval(this.timeoutInterval);
      this.timeoutInterval = null;
    }
  }

  /**
   * Setup search debounce for keyup events
   */
  private setupSearchDebounce(): void {
    this.searchSubject$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm: string) => {
        if (searchTerm && searchTerm.length >= 2) {
          this.performSearch(searchTerm);
        }
      });
  }

  /**
   * Handle search keyup event
   * @param event - Keyboard event
   */
  searchEmployeesKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.showWorkerSearchDialogMethod();
    } else {
      this.searchSubject$.next(this.searchTerm);
    }
  }

  /**
   * Handle response button clicks
   * @param action - The action type (removeAssignment, assignToMe, reassign)
   */
  responseClick(action: string): void {
    // For reassign action, validate that a new supervisor was selected
    if (action === 'reassign' && !this.reassignToWorker) {
      this.noWorkerFoundMsg = 'Please search and select a supervisor to reassign to';
      return;
    }

    this.dialogRef.close({
      confirmed: true,
      results: this.reassignToWorker || this.worker,
      actionType: action,
      notification: this.changeAssignentData.notification,
    });
  }

  /**
   * Search for workers by name or worker number
   * Implements RxJS Observable pattern with proper error handling
   */
  searchWorker(): void {
    if (!this.searchTerm || this.searchTerm.trim().length < 2) {
      this.noWorkerFoundMsg = 'Please enter at least 2 characters to search';
      return;
    }

    this.performSearch(this.searchTerm);
  }

  /**
   * Perform the actual search
   * @param searchTerm - The search term
   */
  private performSearch(searchTerm: string): void {
    this.showSearchWait = true;
    this.searchResults = [];
    this.showSearchResults = false;
    this.noWorkerFoundMsg = '';

    // Search by family name or worker number
    const searchUrl =
      '/workers?includeInactive=false&flag=true&familyName=' +
      searchTerm.toUpperCase() +
      '&limit=10000&skip=0&sortColumn=familyName1&sortOrder=asc';

    this.reportserviceService
      .getDataContent(searchUrl)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showSearchWait = false;
          if (response.results && response.results.length > 0) {
            const onlyEmps = this.filterFederalEmployees(response.results);

            if (onlyEmps.length === 0) {
              this.reassignToUser = '';
              this.noWorkerFoundMsg = 'Provide only Federal employees';
            } else if (onlyEmps.length === 1) {
              this.handleSingleSearchResult(onlyEmps[0]);
            } else {
              this.handleMultipleSearchResults(onlyEmps);
            }
          } else {
            this.noWorkerFoundMsg = 'No workers found matching your search';
          }
        },
        (error: any) => {
          this.showSearchWait = false;          if (error.status === 404) {
            this.noWorkerFoundMsg = 'No Employees found';
          } else {
            this.noWorkerFoundMsg = 'Error searching for workers. Please try again.';
          }
        }
      );
  }

  /**
   * Filter to only include Federal employees (non-contractors)
   * Filters out employees with employment type 'C' (Contractors)
   * @param results - The search results
   * @returns Filtered list of federal employees
   */
  private filterFederalEmployees(results: any[]): any[] {
    return results.filter((emp: any) => {
      // Exclude contractors (employment type 'C')
      return emp.employmentType?.value !== 'C';
    });
  }

  /**
   * Handle single search result
   * Validates against self-assignment and same supervisor reassignment
   * @param employee - The single employee found
   */
  private handleSingleSearchResult(employee: any): void {
    const supervisorName = `${employee.familyName}, ${employee.preferredFirstName}`;

    // Check if trying to assign to self
    if (this.worker.workerNumber === employee.workerNumber) {
      this.reassignToUser = '';
      this.noWorkerFoundMsg = 'Cannot assign yourself';
      return;
    }

    // Check if trying to reassign to same supervisor based on type
    if (this.isReassignToSameSupervisor(supervisorName, employee)) {
      this.reassignToUser = '';
      this.noWorkerFoundMsg = 'Cannot re-assign to the same SPE';
      return;
    }

    // Valid selection
    this.changeAssignentData.toWorker = employee;
    this.setSupervisorName(employee);
  }

  /**
   * Check if reassigning to same supervisor
   * Handles multiple reporting types: PERFORMANCE APPRAISALS, TIMECARD, and default
   * @param supervisorName - The supervisor name
   * @param employee - The employee object
   * @returns True if same supervisor
   */
  private isReassignToSameSupervisor(supervisorName: string, employee: any): boolean {
    const dialogType = this.title.toUpperCase();

    // Check for Performance Appraisals reporting
    if (dialogType === 'PERFORMANCE APPRAISALS REPORTING' || dialogType === 'PERFORMANCE APPRAISALS') {
      if ((this.worker.parReportingId || this.worker.relationshipId) && supervisorName === this.worker.parReporting) {
        return true;
      }
    } 
    // Check for Timecard reporting
    else if (dialogType === 'TIMECARD REPORTING' || dialogType === 'TIMECARD') {
      if ((this.worker.timecardReportingId || this.worker.relationshipId) && supervisorName === this.worker.timecardReporting) {
        return true;
      }
    } 
    // Check for default supervisor reporting
    else if (supervisorName === this.currentReportingAssignment) {
      return true;
    }

    return false;
  }

  /**
   * Handle multiple search results
   * Builds a list of employees with validation flags
   * @param employees - The list of employees found
   */
  private handleMultipleSearchResults(employees: any[]): void {
    this.workers = [];

    employees.forEach((employee: any) => {
      // Skip contractors (worker number contains 'C')
      if (employee.workerNumber.indexOf('C') === -1) {
        const supervisorName = `${employee.familyName}, ${employee.preferredFirstName}`;
        let isSameSupervisor = false;

        // Check if same as current supervisor
        if (supervisorName === this.currentReportingAssignment) {
          isSameSupervisor = true;
        }
        // Check if same as worker being edited
        else if (this.worker.workerNumber === employee.workerNumber) {
          isSameSupervisor = true;
        }

        // Additional checks for PAR and TIMECARD
        const dialogType = this.title.toUpperCase();
        if ((dialogType === 'PERFORMANCE APPRAISALS REPORTING' || dialogType === 'PERFORMANCE APPRAISALS') && !this.worker.parReportingId) {
          isSameSupervisor = false;
        } else if ((dialogType === 'TIMECARD REPORTING' || dialogType === 'TIMECARD') && !this.worker.timecardReportingId) {
          isSameSupervisor = false;
        }

        // Add organization info
        employee.gauValue = this.getOrganizationValue(employee);
        employee.isSameSupervisor = isSameSupervisor;

        this.workers.push(employee);
      }
    });

    this.selectUser = true;
  }

  /**
   * Get organization value from employee
   * Extracts primary organization or first organization from history
   * @param employee - The employee object
   * @returns Organization value string in format "businessAreaCode/shortName"
   */
  private getOrganizationValue(employee: any): string {
    if (!employee.organizationHistory || employee.organizationHistory.length === 0) {
      return '';
    }

    const organizationHistory = employee.organizationHistory;
    let org = organizationHistory[0].organization;

    if (org && org.businessAreaCode && org.shortName) {
      // Find primary organization indicator
      for (let i = 0; i < organizationHistory.length; i++) {
        if (organizationHistory[i].primaryOrganizationIndicator) {
          org = organizationHistory[i].organization;
          return `${org.businessAreaCode}/${org.shortName}`;
        }
      }
      // If no primary found, use first organization
      return `${org.businessAreaCode}/${org.shortName}`;
    }

    return '';
  }

  /**
   * Check if the worker is the same as current supervisor
   * @param worker - The worker to check
   * @returns True if same supervisor
   */
  private checkIfSameSupervisor(worker: any): boolean {
    if (!this.worker || !worker) {
      return false;
    }
    return this.worker.workerId === worker.workerId;
  }

  /**
   * Set supervisor name from employee
   * @param employee - The employee object
   */
  private setSupervisorName(employee: any): void {
    this.reassignToUser = `${employee.familyName}, ${employee.preferredFirstName}`;
  }

  /**
   * Show worker search dialog
   */
  showWorkerSearchDialogMethod(): void {
    this.selectUser = true;
    this.selectEmployee = false;
  }
   onClickSearchBtn() {
     this.searchSubject$.next(this.searchTerm);
   }
  /**
   * Select a worker from search results
   * @param selectedWorker - The worker selected from search results
   */
  selectedUser(worker: any): void {
    this.reassignToWorker = worker;
    this.setSupervisorName(worker);
    this.changeAssignentData.toWorker = worker;
    this.selectUser = false;
    this.selectEmployee = false;
    this.searchTerm = '';
  }

  /**
   * Select a worker from inline search results
   * @param selectedWorker - The worker selected from search results
   */
  selectWorkerFromSearch(selectedWorker: any): void {
    this.selectedUser(selectedWorker);
  }

  /**
   * Go back from worker selection
   */
  goBack(): void {
    this.selectUser = false;
    this.selectEmployee = false;
    this.workers = [];
    this.searchTerm = '';
    this.noWorkerFoundMsg = '';
  }

  /**
   * Clear the search and selected worker
   */
  clearSearch(): void {
    this.searchTerm = '';
    this.reassignToUser = '';
    this.reassignToWorker = null;
    this.changeAssignentData.toWorker = null;
    this.searchResults = [];
    this.showSearchResults = false;
    this.selectUser = false;
    this.workers = [];
    this.noWorkerFoundMsg = '';
  }

  /**
   * Handle assignment action
   * @param action - The action type
   */
  handleAssignment(action: string): void {
    this.responseClick(action);
  }

  /**
   * Gets the list of employees this supervisor has
   * Fetches the supervisor's direct reports
   * @param worker - The worker/supervisor object
   * @param includeInactive - Whether to include inactive employees
   */
  private getWorkerEmployeeList(worker: any, includeInactive: boolean = false): void {
    this.resetTimeout();
    includeInactive = false;

    // Build URL to fetch supervisor's employee list
    const url = `/workers-relationships?associatedToReportingWorkerId=${worker.workerId}&includeInactive=${includeInactive}`;

    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          // Successfully fetched employee list        },
        (error: any) => {
          // Handle error response
          if (error.status !== 404) {            this.noWorkerFoundMsg = 'Problem getting worker report data';
          }
        }
      );
  }
}
