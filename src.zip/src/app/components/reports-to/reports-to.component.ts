import { Component, EventEmitter, OnInit, OnDestroy, Output } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { IWorker, RelationshipType, Worker } from './Models/IWorkerDetails';
import { constants } from './Models/MasterData';
import { SelectionService } from './SelectionService';
import { Subject, BehaviorSubject, timer } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { getPrimaryOrganization } from './reportToUtil';
import { AppService } from 'src/app/services/app.service';
import { DialogService, CustomDialogRef } from 'src/app/services/dialog.service';
import { HistoryOfManagersComponent } from './history-of-managers/history-of-managers.component';
import { HistoryMngrDialogComponent } from './history-mngr-dialog/history-mngr-dialog.component';
import { EditAssignmentDialogComponent } from './edit-assignment-dialog/edit-assignment-dialog.component';
import { MultipleAssignmentsService, ReportType } from './multiple-assignments.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-reports-to',
  templateUrl: './reports-to.component.html',
  styleUrls: ['./reports-to.component.scss'],
})
export class ReportsToComponent implements OnInit, OnDestroy {
  // Observable subjects
  private destroy$ = new Subject<void>();
  private searchSubject$ = new BehaviorSubject<string>('');
  private messageTimeout$ = new Subject<void>();

  hasError: boolean = false;
  returnCode: number = 200;
  returnMessage: string = '';
  // UI State
  workerNumber: string = '';
  searchText: string = '';
  pageId: number = 0;
  tableTitle: string = 'Reporting Information';
  displayTitle: string = '';

  // Title mapping for menu items
  private titleMap: { [key: number]: string } = {
    0: 'All Unassigned Employees',
    1: 'Change Reporting Assignment for Multiple Individuals',
    2: 'Waiting For Assignments',
    4: 'All Unassigned Employees',
    5: 'History of Managers'
  };

  // Data properties
  workers: Worker[] = [];
  showAllWorkers: IWorker[] = [];
  worker: IWorker = this.initializeWorker();
  assignUser: any;
  workerId: number = 0;

  // Menu and constants
  menu = constants.menu;

  // Loading states
  showWait: boolean = false;
  showSaveWait: boolean = false;

  // Messages
  hideMessage: boolean = true;

  // Reports To specific properties
  limit: number = 100;
  skip: number = 0;
  total: number = 0;
  sortColumn: string = 'supervisorIndicator';
  sortDirection: string = 'asc';
  primaryWorker: Worker | null = null;
  primarySearchWorker: Worker | null = null;
  reportToTypes: ReportType[] = [];
  supervisor: Worker | null = null;
  usersToAssign: Worker[] = [];
  employeeListGlobal: IWorker[] = [];
  tableList: IWorker[] = [];
  workerList: IWorker[] = [];
  showAllWorkerList: IWorker[] = [];
  employeeList: IWorker[] = [];
  cachedWorkerList: IWorker[] = []; // Cache for "Show all" results
  lastShowAllWorkerId: number | null = null; // Track which worker's data is cached

  // View state
  viewNumber: number = 0;
  editViewNumber: number = -1;
  showPrimary: boolean = true;
  showPrimarySearch: boolean = false;
  unassignedWorkers: boolean = false;
  unassignedPWorkers: boolean = false;

  // Search properties
  reportsToSearchInput: string = '';
  employeeSearch: string = '';
  employeesUsersSearch: string = '';
  getEmployeesOnlytype2: Worker[] = [];
  noWorkerFoundMsg: string = '';
  noWorkersFound: boolean = false;
  mainNoWorkerFound: boolean = false;
  showWaitWorkerSearch: boolean = false;
  showMultiWait: boolean = false;

  // Waiting for assignment
  waitingList: any[] = [];
  startDateSearch: Date = new Date();
  endDateSearch: Date = new Date();

  // History
  managersHistoryList: any[] = [];
  showHistoryDialog: boolean = false;
  historyDialogRef: CustomDialogRef<any> | null = null;

  // Other properties
  person: any = null;
  includeAttrition: boolean = false;
  supervisorName: string = '';
  userInfo: any = null;
  accronym: string = '';
  emLocatorurl: string = '';
  exportWorkerId: string = '';
  subListSupervisorIndicator: boolean = false;
  originalList: IWorker[] = [];
  reportsToType: ReportType | string = '';

  // Section toggle properties
  showLinksSection: boolean = true;
  showSearchSection: boolean = true;
  showReportingSection: boolean = true;

  constructor(
    private appService: AppService,
    private reportserviceService: ReportserviceService,
    private selectionService: SelectionService,
    private router: Router,
    private dialogService: DialogService,
    private matDialog: MatDialog,
    private multipleAssignmentsService: MultipleAssignmentsService,
    private httpService: HttpService
  ) {
    this.initializeComponent();
  }

  private initializeComponent(): void {
    // Component initialization logic if needed
  }

  ngOnInit(): void {
    this.userInfo = this.appService.getUserData();
    this.setDefaultReportType();
    this.loadParameters();
    this.setupSearchDebounce();
    // Call userInfoRetrieved equivalent after getting user info
    this.userInfoRetrieved();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.messageTimeout$.next();
    this.messageTimeout$.complete();
  }

  get sortedEmployeeList(): IWorker[] {
    return [...this.employeeListGlobal].sort((a, b) => {
      const nameA = `${a.familyName}${a.preferredFirstName}`.toLowerCase();
      const nameB = `${b.familyName}${b.preferredFirstName}`.toLowerCase();
      return nameA.localeCompare(nameB);
    });
  }

  /**
   * Equivalent to AngularJS this.userInfoRetrieved()
   * Called when user info is retrieved from navbar/auth service
   * Loads primary worker and initializes the component
   */
  private userInfoRetrieved(): void {
    if (!this.userInfo || !this.userInfo.workerNumber) {
    
      return;
    }
    // Load primary worker using worker number
    this.reportserviceService
      .getWorkerByWorkerNumber(this.userInfo.workerNumber, true)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response.results && response.results.length) {
            this.primaryWorker = response.results[0];
             this.setSupervisor(response.results[0]);
            // Load the "Reporting to me" list on initial page load
            this.showAllBtn();
            // Call getWorkerSearchData equivalent to process primary worker
            this.getWorkerSearchData(this.primaryWorker as unknown as IWorker, true);
          }
        },
        (error: any) => {
          this.setMessage(400, 'Problem getting worker data.');
        }
      );
  }

  /**
   * Scroll to top of page (equivalent to AngularJS $anchorScroll())
   */
  private scrollToTop(): void {
    window.scrollTo(0, 0);
  }

  private initializeWorker(): IWorker {
    return {
      name: '',
      workerNumber: '',
      workerId: 0,
      id: 0,
      role: '',
      givenName: '',
      organization: '',
      organizationHistory: undefined,
      familyName: '',
      preferredFirstName: '',
      organizationSuffixTx: '',
      workerOrganizationSufix: undefined,
      defaultReportingId: '',
      employeeNumber: '',
      appraisalsReporting: '',
      prefix: '',
      editable: false,
      timecardReportingId: '',
      emailAddress: '',
    };
  }

  private setupSearchDebounce(): void {
    this.searchSubject$
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((searchTerm: string) => {
        if (searchTerm.length >= 2) {
          this.performSearch(searchTerm);
        }
      });
  }

  private loadParameters(): void {
    this.reportserviceService
      .getParameters()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response?.results) {
            response.results.forEach((param: any) => {
              if (param.parameterName === 'Employee Locator') {
                this.emLocatorurl = param.parameterValueText;
              }
            });
          }
        },
        (error: any) => {
        }
      );
  }

  private setDefaultReportType(): void {
    this.multipleAssignmentsService
      .getReportTypes()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.reportToTypes = response || [];
          const supervisorType = this.reportToTypes.find((t) => t.value === 'SUPERVISOR');
          if (supervisorType) {
            this.reportsToType = supervisorType;
          }
        },
        (error: any) => {
          this.setMessage(500, 'Failed to get Worker relationship data types');
        }
      );
  }

  users(id: number): void {
    this.pageId = id;
    if (this.pageId === 1 || this.pageId === 0) {
      this.selectionService.select(id.toString());
    }
  }

  receiveWorkerData(workers: IWorker[]): void {
    this.showAllWorkers = workers;
  }

  assignMultipleUsers(data: any): void {
    this.assignUser = data;
  }

  selectWorker(worker: IWorker): void {
    this.worker = worker;
    this.workerNumber = worker.workerNumber;
    this.pageId = 0;
    this.users(0);
    this.buildReportingTitle(worker);
  }

  buildReportingTitle(worker: IWorker): void {
    this.tableTitle = `Reporting Information for: ${worker.familyName}, ${worker.preferredFirstName}`;
  }

  onSearch(): void {
    this.searchSubject$.next(this.searchText);
  }

  private performSearch(searchTerm: string): void {
    this.showWaitWorkerSearch = true;
    this.workers = [];

    this.reportserviceService
      .getworkers(true, false, 200, 'familyName1', 'asc', searchTerm)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showWaitWorkerSearch = false;
          if (response?.results && response.results.length > 0) {
            this.workers = response.results as Worker[];
          }
        },
        (error: any) => {
          this.showWaitWorkerSearch = false;
          this.setMessage(400, 'Error searching for workers');
        }
      );
  }

  showView(number: number): void {
    this.viewNumber = number;
    this.editViewNumber = number;
    this.showWait = true;
    this.displayTitle = this.titleMap[number] || '';
  
    switch (number) {
      case 0:
        this.unassignedWorkers = true;
        this.showPrimary = false;
        this.workerList = [];
        this.tableList = [];
        this.sortColumn = 'workerNumber1';
        this.getUnassignedWorkers(this.limit, this.skip);
        break;
      case 2:
        this.unassignedWorkers = false;
        const currentTime = new Date();
        this.startDateSearch = new Date(currentTime.getTime() - 14 * 24 * 60 * 60 * 1000);
        this.endDateSearch = currentTime;
        this.getWaitingForAssignments();
        break;
      case 4:
        this.viewNumber = 4;
        this.unassignedPWorkers = true;
        this.showPrimary = false;
        this.workerList = [];
        this.tableList = [];
        this.sortColumn = 'workerNumber1';
        this.getUnassignedPWorkers(this.limit, this.skip);
        break;
      case 5:
        // History of Managers view
        this.viewNumber = 5;
        this.showWait = false;
        this.tableTitle = 'History of Managers';
        this.total = 0;
        this.managersHistoryList = [];
        this.tableList = [];
        this.sortColumn = 'workerNumber1';
        // Open dialog for manager history search and display
        this.openManagersHistoryDialog();
        break;
      case 3:
        this.viewNumber = 0;
        this.showWait = false;
        this.unassignedWorkers = false;
        break;
      default:
        this.showWait = false;
        this.unassignedWorkers = false;
        break;
    }
  }

  private getUnassignedWorkers(limit: number, skip: number, businessAreaCode?: string): void {
    this.showPrimarySearch = false;
    this.resetTimeout();
    this.showWait = true;

    let sortColumn = this.normalizeSortColumn(this.sortColumn, businessAreaCode === 'P');
    const queryParams = this.buildUnassignedWorkersQuery(limit, skip, sortColumn, businessAreaCode);
    const url = `/workers?${queryParams}`;

    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.total = response.meta?.total || 0;
          this.workerList = this.processWorkerList(response.results || []);
          this.tableList = [...this.workerList];
          this.showPrimary = false;
          this.showWait = false;
          this.scrollToTop();
        },
        (error: any) => {
          this.showWait = false;
          const errorMsg =
            businessAreaCode === 'P'
              ? 'Error loading unassigned P workers'
              : 'Error loading unassigned workers';
          this.setMessage(400, errorMsg);
        }
      );
  }

  private getUnassignedPWorkers(limit: number, skip: number): void {
    this.getUnassignedWorkers(limit, skip, 'P');
  }

  private normalizeSortColumn(sortColumn: string, isPWorkers: boolean = false): string {
    const validColumns = isPWorkers
      ? ['workerNumber1', 'workerNumber', 'shortName']
      : ['workerNumber1', 'workerNumber'];
    return validColumns.includes(sortColumn) ? sortColumn : 'familyName';
  }

  private buildUnassignedWorkersQuery(
    limit: number,
    skip: number,
    sortColumn: string,
    businessAreaCode?: string
  ): string {
    const params = [
      `notRelated=true`,
      `isContractor=false`,
      `limit=${limit}`,
      `skip=${skip}`,
      `sortColumn=${sortColumn}`,
      `sortOrder=${this.sortDirection}`,
    ];
    if (businessAreaCode) {
      params.unshift(`businessAreaCode=${businessAreaCode}`);
    }
    return params.join('&');
  }

  private processWorkerList(workerList: any) {
    // Process worker data - assign default reporting values (matching AngularJS pattern)
    return workerList.map((worker: any) => {
      this.initializeReportingValues(worker);
      worker.organization = getPrimaryOrganization(worker.organizationHistory || []);
      worker.name = this.formatWorkerName(worker);
      return worker;
    });
  }

  private initializeReportingValues(worker: any): void {
    worker.defaultReporting = 'UNASSIGNED';
    worker.parReporting = 'UNASSIGNED';
    worker.timecardReporting = 'UNASSIGNED';
  }

  private formatWorkerName(worker: any): string {
    return `${worker.familyName}, ${worker.preferredFirstName || worker.givenName}`;
  }

  private mapRelationshipToWorker(worker: any, row: any): void {
    const relationshipValue = row.relationshipSummary?.value;
    switch (relationshipValue) {
      case 'SUPERVISOR':
        worker.defaultReportingId = row.workerRelationshipId;
        worker.defaultReporting = this.formatWorkerName(row.relatedWorker);
        break;
      case 'PAR':
        worker.parReportingId = row.workerRelationshipId;
        worker.parReporting = this.formatWorkerName(row.relatedWorker);
        break;
      case 'TIMECARD':
        worker.timecardReportingId = row.workerRelationshipId;
        worker.timecardReporting = this.formatWorkerName(row.relatedWorker);
        break;
    }
  }

  private getWaitingForAssignments(): void {
    this.showWait = true;

    const startDate = this.formatDate(this.startDateSearch);
    const endDate = this.formatDate(this.endDateSearch);
    const url = `/waiting-for-assignments/${startDate}/${endDate}`;

    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.waitingList = response.results || [];
          this.showWait = false;
        },
        (error: any) => {
          this.showWait = false;
          this.setMessage(400, 'Error loading waiting for assignments');
        }
      );
  }

  private formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private setMessage(returnCode: number, returnMessage: string, accessDenied?: boolean): void {
    this.returnCode = returnCode;
    this.returnMessage = returnMessage;
    this.hideMessage = false;
    this.hideMessageTimeout();
  }

  /**
   * Hide message after 5 seconds using RxJS timer instead of setTimeout
   * Automatically cleans up on component destroy
   */
  private hideMessageTimeout(): void {
    this.messageTimeout$.next(); // Cancel any pending timeout
    timer(5000)
      .pipe(takeUntil(this.messageTimeout$), takeUntil(this.destroy$))
      .subscribe(() => {
        this.returnMessage = '';
        this.hideMessage = true;
        this.hasError = false;
      });
  }

  /**
   * Reset message timeout by canceling pending timer
   */
  resetTimeout(): void {
    this.messageTimeout$.next();
  }

  navigateTo(path: string): void {
    this.router.navigate([path]);
  }

  toggleSection(section: string): void {
    switch (section) {
      case 'links':
        this.showLinksSection = !this.showLinksSection;
        break;
      case 'search':
        this.showSearchSection = !this.showSearchSection;
        break;
      case 'reporting':
        this.showReportingSection = !this.showReportingSection;
        break;
    }
  }

  onSearchKeyup(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.getEmployees(2);
    }
  }

  /**
   * Consolidated search method to eliminate duplicate logic
   * Handles both getEmployees and employeeSearched functionality
   * @param searchTerm - The search term to use
   * @param type - The search type (0=supervisor, 1=users, 2=reports-to)
   * @param useMultipleAssigned - Whether to use searchMultipleAssignedWorkers (true) or searchWorkerNumber (false)
   */
  private performEmployeeSearch(searchTerm: string, type: number, useMultipleAssigned: boolean = false): void {
    this.noWorkerFoundMsg = '';
    this.resetTimeout();
    this.getEmployeesOnlytype2 = [];

    if (!searchTerm || searchTerm.length < 2) {
      return;
    }

    this.showWaitWorkerSearch = true;
    this.showMultiWait = true;
    this.mainNoWorkerFound = false;

    const includeInactive = type === 2 && this.includeAttrition;
    const searchObservable = useMultipleAssigned
      ? this.reportserviceService.searchMultipleAssignedWorkers(
          searchTerm,
          includeInactive,
          true,
          200,
          'familyName1',
          'asc'
        )
      : this.reportserviceService.searchWorkerNumber(
          searchTerm,
          includeInactive,
          true,
          200,
          'familyName1',
          'asc'
        );

    searchObservable
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.handleEmployeeSearchResponse(response, type);
        },
        (error: any) => {
          this.handleEmployeeSearchError(error, type);
        }
      );
  }

  /**
   * Handle employee search response
   * @param response - API response
   * @param type - Search type
   */
  private handleEmployeeSearchResponse(response: any, type: number): void {
    this.showWaitWorkerSearch = false;
    this.showMultiWait = false;

    const results = response?.results || [];
    const onlyEmps = results.filter((emp: any) => emp.employmentType?.value !== 'C');

    if (type !== 2 && onlyEmps.length === 0) {
      this.supervisorName = '';
      this.noWorkersFound = true;
      this.noWorkerFoundMsg = 'No workers found';
    } else if (onlyEmps.length === 1) {
      this.handleSingleEmployeeResult(onlyEmps[0], type);
    } else if (type === 2) {
      this.getEmployeesOnlytype2 = onlyEmps;
    }

    if (type === 2 && this.getEmployeesOnlytype2.length === 0) {
      this.mainNoWorkerFound = true;
    }
  }

  /**
   * Handle single employee search result
   * @param employee - The employee found
   * @param type - Search type
   */
  private handleSingleEmployeeResult(employee: Worker, type: number): void {
    if (type === 0) {
      this.setSupervisor(employee);
    } else if (type === 1) {
      if (this.supervisor?.workerNumber === employee.workerNumber) {
        this.supervisorName = '';
        this.noWorkersFound = true;
        this.noWorkerFoundMsg = 'Cannot assign yourself';
      } else {
        this.addToUsersList(employee);
      }
    } else if (type === 2) {
      this.getEmployeesOnlytype2.push(employee);
    }
  }

  /**
   * Handle employee search error
   * @param error - Error response
   * @param type - Search type
   */
  private handleEmployeeSearchError(error: any, type: number): void {
    this.showMultiWait = false;
    this.showWaitWorkerSearch = false;
    if (error.status === 404) {
      if (type === 0 || type === 1) {
        this.noWorkersFound = true;
        this.noWorkerFoundMsg = 'No workers found';
      } else if (type === 2) {
        this.mainNoWorkerFound = true;
      }
    }
  }

  /**
   * Public method for getEmployees - uses searchWorkerNumber
   * @param type - The search type
   */
  getEmployees(type: number): void {
    // Find the RelationshipType object matching the numeric type ID
    const reportType = this.reportToTypes.find((rt: any) => rt.id === type);
    if (reportType) {
      this.reportsToType = reportType;
    }
    const searchTerm = this.getSearchTerm(type);
    this.performEmployeeSearch(searchTerm, type, false);
  }

  /**
   * Public method for employeeSearched - uses searchMultipleAssignedWorkers
   * @param searchTerm - The search term
   * @param type - The search type
   */
  employeeSearched(searchTerm: string, type: number): void {
    this.performEmployeeSearch(searchTerm, type, true);
  }

  private getSearchTerm(type: number): string {
    if (type === 0) {
      return this.employeeSearch;
    } else if (type === 1) {
      return this.employeesUsersSearch;
    } else if (type === 2) {
      return this.reportsToSearchInput;
    }
    return '';
  }

  setSupervisor(employee: Worker): void {
    this.supervisor = employee;
    this.supervisorName = `${employee.familyName}, ${employee.preferredFirstName || employee.givenName}`;
  }

  private addToUsersList(worker: Worker): void {
    if (!this.usersToAssign.find((u) => u.workerNumber === worker.workerNumber)) {
      this.usersToAssign.push(worker);
      this.employeesUsersSearch = '';
    }
  }

  showAllBtn(): void {
    this.showPrimarySearch = false;
    const includeInactive = true;
    // Don't change viewNumber - keep displaying current view
    // The workerList will be populated in the sidebar "Reporting to me" section

    if (this.primaryWorker) {
      // Check if we have cached results for this worker
      if (this.lastShowAllWorkerId === this.primaryWorker.workerId && this.cachedWorkerList.length > 0) {
        // Use cached results - same records every time, no async operations
        this.workerList = JSON.parse(JSON.stringify(this.cachedWorkerList)); // Deep copy to prevent mutations
        this.showAllWorkerList = JSON.parse(JSON.stringify(this.cachedWorkerList)); // Set display list immediately
        this.showPrimary = true;
        this.scrollToTop();
        return;
      }

      this.reportserviceService
        .getSupervisorWorkersRelationshipsList(this.primaryWorker.workerId, includeInactive)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            // Process employee list (equivalent to AngularJS processEmployeeList)
            this.processEmployeeList(response.results || []);
            // Cache the results AFTER processing completes
            // Wait for async operations to complete before caching
            setTimeout(() => {
              this.cachedWorkerList = JSON.parse(JSON.stringify(this.workerList)); // Deep copy
              this.lastShowAllWorkerId = this.primaryWorker?.workerId || null;
              // Set showAllWorkerList only after all async operations complete
              this.showAllWorkerList = JSON.parse(JSON.stringify(this.workerList)); // Deep copy
            }, 500); // Wait for async operations to complete
            this.showPrimary = true;
           
            // Scroll to top after data loads
            this.scrollToTop();
          },
          (error: any) => {
            if (error.status !== 404) {
              this.setMessage(400, 'Problem getting worker report data');
            }
          }
        );
    } else {
    }
  }

  getWorkerSearchData(worker: IWorker, getSubList: boolean = false): void {
    this.exportWorkerId = worker.workerId.toString();
    if (worker) {
      this.total = 1;
    }
    this.employeeList = [];
    this.buildReportingTitle(worker);

    // Cast to Worker type for additional properties
    const workerData = worker as any as Worker;
    this.primarySearchWorker = workerData;

    // Set worker name
    if (workerData) {
      (workerData as any).name = `${workerData.familyName}, ${workerData.preferredFirstName}`;
    }

    // Set organization suffix
    if (workerData?.workerOrganizationSufix != null) {
      (workerData as any).organizationSuffixTx = workerData.workerOrganizationSufix.sufixTx;
    }

    if (this.resetTimeout) {
      this.resetTimeout();
    }
    // this.workerList = [];

    const primarySearchOrg = getPrimaryOrganization(workerData?.organizationHistory || []);
    if (primarySearchOrg) {
      (workerData as any).organization = primarySearchOrg;
      this.accronym = primarySearchOrg;
    } else {
      (workerData as any).organization = 'Home Organization missing';
    }

    const url = `/workers-relationships?workerId=${worker.workerId}`;
    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.processWorkerReportSearchInfo(worker, response.results || [], getSubList);
        },
        (error: any) => {
          if (error.status === 404) {
            this.processWorkerReportInfo(worker, null, getSubList);
          } else {
            this.setMessage(400, 'Problem getting worker report data');
          }
        }
      );
  }

  private processWorkerReportSearchInfo(
    worker: IWorker,
    response: any[],
    getSubList: boolean
  ): void {
    this.processWorkerReportInfo(worker, response, getSubList);
    this.showPrimarySearch = true;
  }

  private processWorkerReportInfo(worker: IWorker, data: any[] | null, getSubList: boolean): void {
    worker.name = this.formatWorkerName(worker as any);
    worker.organization = getPrimaryOrganization(worker.organizationHistory || []);
    this.initializeReportingValues(worker as any);

    if (data) {
      data.forEach((row: any) => {
        this.mapRelationshipToWorker(worker as any, row);
      });
    }

    this.showView(3);

    if (getSubList) {
      this.getWorkerEmployeeList(worker);
    } else {
      this.showWorkerData(worker);
    }
  }

  private getWorkerEmployeeList(worker: IWorker): void {
    this.resetTimeout();

    const url = `/workers-relationships?associatedToReportingWorkerId=${worker.workerId}&includeInactive=false`;
    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.processEmployeeList(response.results || []);
        },
        (error: any) => {
          if (error.status !== 404) {
            this.setMessage(400, 'Problem getting worker report data');
          } else {
            this.processEmployeeList([]);
          }
        }
      );
  }

  private processEmployeeList(data: any[]): void {
   
    this.workerList = [];
    this.employeeList = [];
    data.forEach((row: any) => this.addWorkerToLists(row, true));
    this.finalizeLists(true);
  }

  private processEmployeeListSearch(data: any[]): void {
    this.tableList = [];
    this.employeeList = [];
    data.forEach((row: any) => this.addWorkerToLists(row, false));
    this.finalizeLists(false);
  }

  private addWorkerToLists(row: any, addToWorkerList: boolean): void {
    const worker = row.baseWorker;
 

    worker.organizationHistory = row.organizationHistory;
    worker.workerOrganizationSufix = row.workerOrganizationSufix;
    this.mapRelationshipToWorker(worker, row);
    this.formatWorkerDisplay(worker);
    this.ensureReportingValuesSet(worker);

   
    this.reportserviceService
      .getWorkerByWorkerNumber(worker.workerNumber, false)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response.results && response.results.length) {
            // Search in the appropriate list based on context
            const searchList = addToWorkerList ? this.workerList : this.tableList;
            const _worker = searchList.find(
              (worker) => worker.workerNumber === row.baseWorker.workerNumber
            );
            worker.supervisorIndicator = response.results[0].supervisorIndicator;
            worker.organizationSuffixTx = response.results[0].workerOrganizationSufix.sufixTx;
            row.baseWorker.organizationSuffixTx =
              response.results[0].workerOrganizationSufix.sufixTx;
            if (_worker) {
              const relation = row.relationshipSummary?.value;
              if (relation === 'SUPERVISOR') {
                _worker.defaultReportingId = row.workerRelationshipId;
                _worker.defaultReporting = this.formatWorkerName(row.relatedWorker);
              } else if (relation === 'PAR') {
                _worker.parReportingId = row.workerRelationshipId;
                _worker.parReporting = this.formatWorkerName(row.relatedWorker);
              } else if (relation === 'TIMECARD') {
                _worker.timecardReportingId = row.workerRelationshipId;
                _worker.timecardReporting = this.formatWorkerName(row.relatedWorker);
              } else {
              }
            } else {
              // this.tableList.push(worker);
              this.tableList = [...this.tableList, worker];
              if (addToWorkerList) {
                this.workerList.push(worker);
              }
              if (['PAR', 'SUPERVISOR', 'TIMECARD'].includes(row.relationshipSummary?.value)) {
                this.employeeList.push(worker);
              }
            }
          }
        },
        (error: any) => {
          this.setMessage(400, 'Problem getting worker data.');
        }
      );
  }

  private formatWorkerDisplay(worker: any): void {
    const org = getPrimaryOrganization(worker.organizationHistory || []);
    worker.organization = org || 'N/A';
    worker.organizationSuffixTx = worker.workerOrganizationSufix?.sufixTx || 'N/A';
    worker.name = this.formatWorkerName(worker);
  }

  private ensureReportingValuesSet(worker: any): void {
    if (!worker.defaultReporting) {
      worker.defaultReporting = 'UNASSIGNED';
    }
    if (!worker.parReporting) {
      worker.parReporting = 'UNASSIGNED';
    }
    if (!worker.timecardReporting) {
      worker.timecardReporting = 'UNASSIGNED';
    }
  }

  private finalizeLists(updateWorkerList: boolean): void {
    // Sort and filter the tableList to remove duplicates and apply sorting
    this.sortRecords(this.tableList);

    if (updateWorkerList && (!this.originalList || this.originalList.length === 0)) {
      this.originalList = [...this.workerList];
    }
  }

  showWorkerData(person: IWorker): void {
    this.person = person;
    this.tableList = [];
    this.showPrimarySearch = true;
    this.subListSupervisorIndicator = false;
    this.showPrimary = false;

    const url = `/workers-relationships?associatedToReportingWorkerId=${person.workerId}&includeInactive=false`;
    this.reportserviceService
      .getData(url)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.processEmployeeListSearch(response.results || []);
        },
        (error: any) => {
          if (error.status !== 404) {
            this.setMessage(400, 'Problem getting worker report data');
          }
        }
      );

    this.showView(3);
  }

  /**
   * Sort and filter tableList array based on sortColumn and sortDirection
   * Removes duplicate entries by workerId and updates total count
   * Equivalent to AngularJS sortRecords(records)
   */
  sortRecords(records: IWorker[]): void {
    if (this.sortColumn && this.sortDirection && records && records.length > 0) {
      const sortColumn = this.sortColumn;
      const sortOrder = this.sortDirection;

      // Sort the records based on column and direction
      const sortedList = records.sort((worker1: any, worker2: any) => {
        let sortColumnValue1: any;
        let sortColumnValue2: any;

        // Extract sort values based on column
        if (sortColumn === 'workerNumber1') {
          sortColumnValue1 = Number(worker1.workerNumber);
          sortColumnValue2 = Number(worker2.workerNumber);
        } else if (sortColumn === 'name') {
          sortColumnValue1 = worker1.name;
          sortColumnValue2 = worker2.name;
        } else if (sortColumn === 'organization') {
          sortColumnValue1 = worker1.workerOrganizationSufix;
          sortColumnValue2 = worker2.workerOrganizationSufix;
        } else if (sortColumn === 'shortName') {
          sortColumnValue1 = worker1.organizationHistory?.[0]?.organization?.shortName || '';
          sortColumnValue2 = worker2.organizationHistory?.[0]?.organization?.shortName || '';
        } else if (sortColumn === 'supervisorIndicator') {
          sortColumnValue1 = worker1.supervisorIndicator ? worker1.supervisorIndicator : 2;
          sortColumnValue2 = worker2.supervisorIndicator ? worker2.supervisorIndicator : 2;
        }

        // Compare values based on sort order
        if (sortOrder === 'asc') {
          if (sortColumnValue1 < sortColumnValue2) {
            return -1;
          } else if (sortColumnValue1 > sortColumnValue2) {
            return 1;
          } else {
            return 0;
          }
        } else if (sortOrder === 'desc') {
          if (sortColumnValue1 < sortColumnValue2) {
            return 1;
          } else if (sortColumnValue1 > sortColumnValue2) {
            return -1;
          } else {
            return 0;
          }
        }
        return 0;
      });

      // Remove duplicate entries by workerId
      const uniqueList: IWorker[] = [];
      for (let i = 0; i < sortedList.length; i++) {
        let isFound = false;
        for (let j = 0; j < uniqueList.length; j++) {
          if (sortedList[i].workerId === uniqueList[j].workerId) {
            isFound = true;
            break;
          }
        }
        if (!isFound) {
          uniqueList.push(sortedList[i]);
        }
      }

      // Update tableList and total count
      this.tableList = uniqueList;
      this.total = uniqueList.length + 1;
    }
  }

  getWorkerSearchDataUpdated(worker: any, getSubList: boolean = false): void {
    // Handle pagination events from child component
    if (worker && worker.limit !== undefined && worker.skip !== undefined) {
      this.limit = worker.limit;
      this.skip = worker.skip;
      // Reload data with new pagination parameters based on current view
      if (this.viewNumber === 0) {
        this.getUnassignedWorkers(this.limit, this.skip);
      } else if (this.viewNumber === 4) {
        this.getUnassignedPWorkers(this.limit, this.skip);
      }
    } else {
      // Handle regular worker selection
      this.getWorkerSearchData(worker, getSubList);
    }
  }

  /**
   * Handle user removal from the assignment list
   * Called when a user is removed from usersToAssign in the child component
   * @param index - The index of the user to remove from usersToAssign array
   */
  userRemoved(index: number): void {
    if (index >= 0 && index < this.usersToAssign.length) {
      this.usersToAssign.splice(index, 1);
    }
  }

  /**
   * Save reports-to assignment for multiple users
   * Converts AngularJS promise-based code to Angular 15 RxJS Observable pattern
   */
  saveReportsToAssignment(): void {
    this.showSaveWait = true;
    this.resetTimeout();

    // Initialize changeAssignmentData if not exists
    const changeAssignmentData = {
      notification: false,
    };

    // Validate required data before making the request
    if (!this.supervisor || !this.usersToAssign || this.usersToAssign.length === 0) {
      this.showSaveWait = false;
      this.setMessage(400, 'Please select a supervisor and at least one employee to assign.');
      return;
    }

    // Validate reportToType is set
    if (!this.reportsToType || typeof this.reportsToType === 'string') {
      this.showSaveWait = false;
      this.setMessage(400, 'Please select a report type.');
      return;
    }
    // Call the service to assign workers using RxJS Observable
    this.reportserviceService
      .assignWorkers(
        this.supervisor,
        this.reportsToType,
        this.usersToAssign,
        this.reportToTypes,
        changeAssignmentData.notification
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          // Success handler
          this.showSaveWait = false;
          this.returnCode = 200;
          this.hasError = true;
          if (this.supervisor) {
            this.returnMessage = `Successfully added ${this.usersToAssign.length} employee(s) to ${this.supervisor.familyName}, ${this.supervisor.preferredFirstName} - ${this.supervisor.workerNumber}`;
          } else {
            this.returnMessage = `Successfully added ${this.usersToAssign.length} employee(s).`;
          }

          // Reset the form and UI state
          this.cancelMultiple();
          this.hideMessage = false;
          this.hideMessageTimeout();

          // Reset lists and reload data
          this.showPrimary = true;
          this.employeeList = [];
          this.tableList = [];
          this.usersToAssign = [];

          // Reload report types
          this.setDefaultReportType();
          this.loadParameters();
          
          // Stay on assignment view (viewNumber = 1) but reset the wizard to screen 0
          // This keeps the user in the assignment wizard for another round
          this.viewNumber = 1;
        },
        (error: any) => {
          // Error handler
          this.showSaveWait = false;
          this.hideMessage = false;
          this.hideMessageTimeout();
          this.returnCode = error.status?.toString() || 500;

          // Process failure message (using a generic error message if service method not available)
          const errorMessage = error.error?.message || 'Not able to assign workers.';
          this.returnMessage = errorMessage;
        }
      );
  }

  /**
   * Cancel multiple assignment operation
   * Resets the multi-assignment form and state
   */
  private cancelMultiple(): void {
    this.usersToAssign = [];
    this.supervisor = null;
    this.supervisorName = '';
    this.employeeSearch = '';
    this.employeesUsersSearch = '';
    this.noWorkersFound = false;
    this.noWorkerFoundMsg = '';
  }

  /**
   * Get managers history for a worker
   * Fetches the complete history of managers for the selected worker
   * Uses RxJS Observable pattern with proper error handling
   * @param worker The worker to fetch manager history for
   */
  private getManagersHistory(worker: IWorker): void {
    if (!worker || !worker.workerId) {
      return;
    }

    this.reportserviceService
      .getManagersHistory(worker.workerId, 100, 0)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.managersHistoryList = response?.results || [];
          // Sort by end date (descending)
          this.managersHistoryList = this.getSortedManagerHistoryOnEndDate(
            this.managersHistoryList
          );
          // Detect gaps > 2 days
          this.managersHistoryList = this.detectManagerAssignmentGaps(this.managersHistoryList);
        },
        (error: any) => {
          this.setMessage(400, 'Error loading manager history');
        }
      );
  }

  /**
   * Sort manager history by lifecycle end date in descending order
   * Most recent assignments appear first
   * @param data Manager history records
   * @returns Sorted manager history
   */
  private getSortedManagerHistoryOnEndDate(data: any[]): any[] {
    return data.sort((a, b) => {
      const endDateA = a.lifecycle?.endDate ? new Date(a.lifecycle.endDate) : null;
      const endDateB = b.lifecycle?.endDate ? new Date(b.lifecycle.endDate) : null;

      if (!endDateA && !endDateB) return 0;
      if (!endDateA) return -1;
      if (!endDateB) return 1;

      return endDateB.getTime() - endDateA.getTime();
    });
  }

  /**
   * Calculate the difference in days between two dates
   * @param date1 First date
   * @param date2 Second date
   * @returns Number of days between dates
   */
  private getDifferenceInDays(date1: string | Date, date2: string | Date): number {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diffTime = Math.abs(d2.getTime() - d1.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  }

  /**
   * Detect gaps > 2 days between manager assignments
   * Marks records with gaps by setting index flag for highlighting
   * @param data Manager history records
   * @returns Manager history with gap detection flags
   */
  private detectManagerAssignmentGaps(data: any[]): any[] {
    if (data.length < 3) {
      return data;
    }

    for (let i = data.length - 1; i > 0; i--) {
      const lastRecord = data[i];
      const secondToLastRecord = data[i - 1];

      if (lastRecord && lastRecord.lifecycle?.endDate) {
        const endDateLastRecord = lastRecord.lifecycle.endDate;
        const startDateSecondToLastRecord = secondToLastRecord.lifecycle?.beginDate;

        if (startDateSecondToLastRecord) {
          const gapDays = this.getDifferenceInDays(startDateSecondToLastRecord, endDateLastRecord);

          if (gapDays > 2) {
            data[i - 1].index = true; // Mark for highlighting
          }
        }
      }
    }

    return data;
  }

  /**
   * Open managers history dialog
   * Displays the history of managers in a modal dialog using MatDialog
   * Dialog opens with search functionality, user searches for worker
   * Then manager history is fetched and displayed
   * Implements Angular 15 Material Dialog pattern with RxJS Observable handling
   */
  private openManagersHistoryDialog(): void {
    // Open dialog with empty manager history list initially
    // User will search for worker in dialog, then history will be fetched
    const dialogRef: MatDialogRef<HistoryMngrDialogComponent> = this.matDialog.open(
      HistoryMngrDialogComponent,
      {
        width: '700px',
        data: {
          managersHistoryList: this.managersHistoryList,
          parentComponent: this,
        },
        disableClose: false,
        autoFocus: true,
        panelClass: 'history-manager-dialog',
      }
    );

    // Handle dialog closure
    dialogRef
      .afterClosed()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (result: any) => {
          // Dialog closed, perform any cleanup if needed
          this.showWait = false;
        },
        (error: any) => {
          this.showWait = false;
        }
      );
  }

  /**
   * Handle History of Managers view (View 5)
   * Triggered when user clicks "History of Managers" link
   * Fetches manager history for the selected worker
   */
  getSelectedMngrHistory(worker: IWorker): void {
    if (!worker) {
      return;
    }

    // Fetch and display manager history
    this.getManagersHistory(worker);
  }

  organizationSuffixSaved(event: any): void {
    if (event.success) {
      this.hasError = true;
      this.returnCode = 200;
      this.returnMessage = `Successfully Updated OrganzationSuffix for ${event.worker.name} ${event.worker.workerId} : ${event.organizationSuffixTx}`;
       this.hideMessageTimeout();
    }
  }

  /**
   * Handle edit assignment request from reports-to-search-results component
   * Opens the EditAssignmentDialogComponent with the worker and assignment type data
   * @param event - Contains worker, type (SUPERVISOR/PAR/TIMECARD), and isDefault flag
   */
  onAssignmentEditRequested(event: any): void {
    if (!event || !event.worker) {
      return;
    }

    this.openEditAssignmentDialog(event.worker, event.type, event.isDefault);
  }

  /**
   * Open the Edit Assignment Dialog
   * Displays a modal dialog for editing worker reporting assignments
   * Handles the dialog response and processes the selected action
   * @param worker - The worker whose assignment is being edited
   * @param type - The type of reporting (SUPERVISOR, PAR, TIMECARD)
   * @param isDefault - Whether this is the default reporting assignment
   */
  private openEditAssignmentDialog(worker: any, type: string, isDefault: boolean): void {
    // Determine the title based on the reporting type
    let title = '';
    let selectedItem = '';

    switch (type) {
      case 'SUPERVISOR':
        title = 'Default Reporting';
        selectedItem = worker.defaultReporting || 'UNASSIGNED';
        break;
      case 'PAR':
        title = 'Performance Appraisals Reporting';
        selectedItem = worker.parReporting || 'UNASSIGNED';
        break;
      case 'TIMECARD':
        title = 'Timecard Reporting';
        selectedItem = worker.timecardReporting || 'UNASSIGNED';
        break;
      default:
        title = 'Reporting Assignment';
        selectedItem = 'UNASSIGNED';
    }

    // Prepare dialog data
    const dialogData = {
      Title: title,
      SelectedItem: selectedItem,
      Row: worker,
      Type: type,
      IsDefault: isDefault,
    };

    // Open the dialog
    const dialogRef: MatDialogRef<EditAssignmentDialogComponent> = this.matDialog.open(
      EditAssignmentDialogComponent,
      {
        width: '1200px',
        data: dialogData,
        disableClose: false,
        autoFocus: true,
        panelClass: 'edit-assignment-dialog',
      }
    );

    // Handle dialog closure and process the result
    dialogRef
      .afterClosed()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (result: any) => {
          if (result && result.confirmed) {
            this.handleAssignmentDialogResult(result, worker, type, isDefault);
          }
        },
        (error: any) => {
        }
      );
  }

  /**
   * Handle the result from the Edit Assignment Dialog
   * Processes the selected action (removeAssignment, assignToMe, or reassign)
   * @param result - The dialog result containing the action and data
   * @param worker - The worker being edited
   * @param type - The type of reporting assignment
   * @param isDefault - Whether this is the default reporting assignment
   */
  private handleAssignmentDialogResult(
    result: any,
    worker: any,
    type: string,
    isDefault: boolean
  ): void {
    const actionType = result.actionType;

    switch (actionType) {
      case 'removeAssignment':
        this.removeReportingAssignment(worker, type, isDefault);
        break;
      case 'assignToMe':
        this.assignToCurrentUser(worker, type, isDefault);
        break;
      case 'reassign':
        this.reassignReportingAssignment(worker, type, isDefault, result.results);
        break;
      default:
    }
  }

  /**
   * Remove reporting assignment for a worker
   * @param worker - The worker whose assignment is being removed
   * @param type - The type of reporting assignment
   * @param isDefault - Whether this is the default reporting assignment
   */
  private removeReportingAssignment(worker: any, type: string, isDefault: boolean): void {
    this.showSaveWait = true;
    this.resetTimeout();

    // Get the relationship ID to remove
    const relationshipId = this.getRelationshipIdForWorker(worker, type);
    
    if (!relationshipId) {
      this.showSaveWait = false;
      this.setMessage(400, 'Unable to find assignment to remove');
      return;
    }

    // Call service to remove assignment
    this.reportserviceService
      .removeAssignment(relationshipId)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showSaveWait = false;
          this.returnCode = 200;
          this.returnMessage = `${type} reporting assignment removed for ${worker.familyName}, ${worker.preferredFirstName} - ${worker.workerNumber}`;
          this.hideMessage = false;
          this.hideMessageTimeout();

          // Update worker object based on type
          if (type === 'SUPERVISOR') {
            worker.defaultReporting = 'UNASSIGNED';
            worker.defaultReportingId = '';
          } else if (type === 'PAR') {
            worker.parReporting = 'UNASSIGNED';
            worker.parReportingId = '';
          } else if (type === 'TIMECARD') {
            worker.timecardReporting = 'UNASSIGNED';
            worker.timecardReportingId = '';
          }

          // Update only the specific worker in the lists instead of clearing everything
          this.updateWorkerInLists(worker);
          this.scrollToTop();
        },
        (error: any) => {
          this.showSaveWait = false;
          this.returnCode = error.status || 500;
          this.returnMessage = error.error?.message || 'Failed to remove assignment';
          this.hideMessage = false;
          this.hideMessageTimeout();
        }
      );
  }

  /**
   * Get relationship ID for a worker based on assignment type
   * @param worker - The worker object
   * @param type - The type of reporting assignment
   * @returns The relationship ID or empty string
   */
  private getRelationshipIdForWorker(worker: any, type: string): string {
    switch (type) {
      case 'SUPERVISOR':
        return worker.defaultReportingId || '';
      case 'PAR':
        return worker.parReportingId || '';
      case 'TIMECARD':
        return worker.timecardReportingId || '';
      default:
        return '';
    }
  }

  /**
   * Assign reporting to the current user
   * @param worker - The worker being assigned
   * @param type - The type of reporting assignment
   * @param isDefault - Whether this is the default reporting assignment
   */
  private assignToCurrentUser(worker: any, type: string, isDefault: boolean): void {
    if (!this.userInfo || !this.userInfo.workerNumber) {
      this.setMessage(400, 'Current user information not available');
      return;
    }

    this.showSaveWait = true;
    this.resetTimeout();

    // Get current user's worker data
    this.reportserviceService
      .getWorkerByWorkerNumber(this.userInfo.workerNumber, false)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          if (response.results && response.results.length > 0) {
            const currentUser = response.results[0];
            this.assignWorkerToSupervisor(worker, currentUser, type, isDefault);
          } else {
            this.showSaveWait = false;
            this.setMessage(400, 'Unable to retrieve current user information');
          }
        },
        (error: any) => {
          this.showSaveWait = false;
          this.setMessage(400, 'Error retrieving current user information');
        }
      );
  }

  /**
   * Reassign reporting to a different supervisor
   * @param worker - The worker being reassigned
   * @param type - The type of reporting assignment
   * @param isDefault - Whether this is the default reporting assignment
   * @param newSupervisor - The new supervisor to assign to
   */
  private reassignReportingAssignment(
    worker: any,
    type: string,
    isDefault: boolean,
    newSupervisor: any
  ): void {
    if (!newSupervisor || !newSupervisor.workerId) {
      this.setMessage(400, 'Invalid supervisor selected for reassignment');
      return;
    }

    this.showSaveWait = true;
    this.resetTimeout();

    this.assignWorkerToSupervisor(worker, newSupervisor, type, isDefault);
  }

  /**
   * Assign a worker to a supervisor for a specific reporting type
   * @param worker - The worker being assigned
   * @param supervisor - The supervisor to assign to
   * @param type - The type of reporting assignment
   * @param isDefault - Whether this is the default reporting assignment
   */
  private assignWorkerToSupervisor(
    worker: any,
    supervisor: any,
    type: string,
    isDefault: boolean
  ): void {
    const reportingType = this.reportToTypes.find((t) => t.value === type);
    
    if (!reportingType) {
      this.showSaveWait = false;
      this.setMessage(400, 'Invalid reporting type selected');
      return;
    }

    // Use assignWorkers method with single worker array
    this.reportserviceService
      .assignWorkers(supervisor, reportingType, [worker], this.reportToTypes, false)
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showSaveWait = false;
          this.returnCode = 200;
          this.hasError = true;
          this.returnMessage = `${type} reporting assignment updated for ${worker.familyName}, ${worker.preferredFirstName} - ${worker.workerNumber}`;
          this.hideMessage = false;
          this.hideMessageTimeout();

          // Update worker object based on type
          const supervisorName = `${supervisor.familyName}, ${supervisor.preferredFirstName}`;
          if (type === 'SUPERVISOR') {
            worker.defaultReporting = supervisorName;
            worker.defaultReportingId = response.workerRelationshipId || '';
          } else if (type === 'PAR') {
            worker.parReporting = supervisorName;
            worker.parReportingId = response.workerRelationshipId || '';
          } else if (type === 'TIMECARD') {
            worker.timecardReporting = supervisorName;
            worker.timecardReportingId = response.workerRelationshipId || '';
          }

          // Update only the specific worker in the lists instead of clearing everything
          this.updateWorkerInLists(worker);
          this.scrollToTop();
        },
        (error: any) => {
          this.showSaveWait = false;
          this.returnCode = error.status || 500;
          this.returnMessage = error.error?.message || 'Failed to update assignment';
          this.hideMessage = false;
          this.hideMessageTimeout();
        }
      );
  }

  /**
   * Update a specific worker in the tableList and employeeList
   * Only updates the worker's data without reloading the entire list
   * @param updatedWorker - The worker object with updated assignment data
   */
  private updateWorkerInLists(updatedWorker: any): void {
    // Update in tableList
    const tableListIndex = this.tableList.findIndex(
      (w) => w.workerId === updatedWorker.workerId
    );
    if (tableListIndex !== -1) {
      this.tableList[tableListIndex] = { ...this.tableList[tableListIndex], ...updatedWorker };
      // Trigger change detection by creating a new array reference
      this.tableList = [...this.tableList];
    }

    // Update in employeeList
    const employeeListIndex = this.employeeList.findIndex(
      (w) => w.workerId === updatedWorker.workerId
    );
    if (employeeListIndex !== -1) {
      this.employeeList[employeeListIndex] = { ...this.employeeList[employeeListIndex], ...updatedWorker };
      // Trigger change detection by creating a new array reference
      this.employeeList = [...this.employeeList];
    }

    // Update in workerList if it exists
    const workerListIndex = this.workerList.findIndex(
      (w) => w.workerId === updatedWorker.workerId
    );
    if (workerListIndex !== -1) {
      this.workerList[workerListIndex] = { ...this.workerList[workerListIndex], ...updatedWorker };
      // Trigger change detection by creating a new array reference
      this.workerList = [...this.workerList];
    }
  }

 /**
  * Get reporting worker search data and update
  * Converted from AngularJS promise-based code to Angular 15 RxJS Observable
  * Searches for a worker by their default reporting worker number
  * Updates sort column and direction, then calls getWorkerSearchDataUpdated
  * @param worker - The worker object containing workerNumber
  */
 getReportingWorkerSearchDataUpdated(worker: any): void {
  
   if (!worker || !worker.workerNumber) {
     return;
   }

   // Search for the worker using MultipleAssignmentsService
   this.multipleAssignmentsService
     .searchUsers(worker.workerNumber, false, true, 'reportsToPage')
     .pipe(takeUntil(this.destroy$))
     .subscribe(
       (response: any) => {
         // Success handler - process the worker data
         if (response && response.results && response.results.length > 0) {
           const workerData = response.results[0];

           // Ensure supervisorIndicator is set to true if it exists
           if (workerData.supervisorIndicator) {
             workerData.supervisorIndicator = true;
           }

           // Set organization suffix text
           if (workerData.workerOrganizationSufix) {
             workerData.workerOrganizationSufix.sufixTx = workerData.workerOrganizationSufix.sufixTx || '';
             workerData.organizationSuffixTx = workerData.workerOrganizationSufix.sufixTx;
           }

           // Update sort settings
           this.sortColumn = 'supervisorIndicator';
           this.sortDirection = 'asc';

           // Call the update method with the processed worker data
           this.getWorkerSearchDataUpdated(workerData);
         } else {
         }
       },
       (error: any) => {
         // Error handler - log error but don't throw
       }
     );
 }

 /**
  * Handle assignment success event from waiting-for-assignment component
  * @param event - Event containing returnCode and returnMessage
  */
 onAssignmentSuccess(event: { returnCode: number; returnMessage: string }): void {
  //  this.setMessage(event.returnCode, event.returnMessage);
   this.hasError = true;
   this.returnCode = event.returnCode;
   this.returnMessage = event.returnMessage;
 }

 /**
  * Get worker EM locator URL and open in new window
  * Equivalent to AngularJS vm.getWorkerEMLocator(workerNo)
  * Opens the Employee Locator page for the specified worker number
  * @param workerNo - The worker number to look up
  */
 getWorkerEMLocator(workerNo: string | undefined): void {
   if (typeof this.resetTimeout === 'function') {
     this.resetTimeout();
   }
   
   if (!workerNo) {
     return;
   }

   const page = this.emLocatorurl + 'ListEmployeeByEmpNo.action?qryEmployeeForm.action=ListEmployeeByEmpNo&qryEmployeeForm.empNo=' + workerNo;
   window.open(page);
 }

 getAccronymEMLocator(accronym: string | undefined): void {
   if (typeof this.resetTimeout === 'function') {
     this.resetTimeout();
   }
   
   if (!accronym) {
     return;
   }

   const page = this.emLocatorurl + 'runEmployeeQry.do?action=ListEmployeeByOrg&orderBy=NAME&acronym=' + accronym;
   window.open(page);
 }
}
