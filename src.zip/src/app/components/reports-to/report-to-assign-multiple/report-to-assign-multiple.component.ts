import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import { Worker, RelationshipType } from '../Models/IWorkerDetails';
import { ReportType } from '../multiple-assignments.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-report-to-assign-multiple',
  templateUrl: './report-to-assign-multiple.component.html',
  styleUrls: ['./report-to-assign-multiple.component.scss'],
})
export class ReportToAssignMultipleComponent implements OnInit, OnDestroy, OnChanges {
  @Input() supervisor: any = {};
  @Input() usersToAssign: Worker[] = [];
  @Input() reportToTypes: ReportType[] = [];
  @Input() showSaveWait: boolean = false;
  @Input() noWorkersFound: boolean = false;
  @Input() noWorkerFoundMsg: string = '';
  @Input() showMultiWait: boolean = false;
  @Input() loggedInUser: any = null;
  @Input() searchResults: Worker[] = [];

  // @Output() supervisorSelected = new EventEmitter<Worker>();
  @Output() employeeSearched = new EventEmitter<{ searchTerm: string; type: number }>();
  @Output() supervisorSelected = new EventEmitter<Worker>();
  // @Output() userAdded = new EventEmitter<Worker>();
  @Output() userRemoved = new EventEmitter<number>();
  @Output() assignmentSaved = new EventEmitter<void>();
  @Output() screenChanged = new EventEmitter<number>();
  // @Output() cancelled = new EventEmitter<void>();
  private destroy$ = new Subject<void>();

  // Component state
  screen: number = 0;
  supervisorName: string = '';
  employeeSearch: string = '';
  employeesUsersSearch: string = '';
  reportToType: ReportType | null = null;
  selectedUsers: string[] = [];
  loggedInUserName: string = '';
  changeAssignmentData = {
    notification: false,
  };

  constructor() {}
  ngOnChanges(changes: SimpleChanges) {
    if (this.supervisor) {
      this.supervisorName = `${this.supervisor.familyName}, ${this.supervisor.preferredFirstName || this.supervisor.givenName}`;
    }
    // Set default logged-in user when loggedInUser input changes
    if (this.loggedInUser) {
      this.setDefaultLoggedInUserSearch();
    }
  }
  ngOnInit(): void {
    if (this.reportToTypes && this.reportToTypes.length > 0) {
      // Set report type to default (SUPERVISOR)
      const defaultType = this.reportToTypes.find((t) => t.value === 'SUPERVISOR');
      this.reportToType = defaultType ? defaultType : this.reportToTypes[0];
    }
    // Set default logged-in user in screen 2 employee search
    this.setDefaultLoggedInUserSearch();
  }

  /**
   * Set default logged-in user in the employee search boxes (screen 0 only)
   * Also set the logged-in user's name for display
   */
  private setDefaultLoggedInUserSearch(): void {
    if (this.loggedInUser) {
      // Set for screen 0 (supervisor search)
      this.employeeSearch = this.loggedInUser.workerNumber || '';
      // Screen 2 (users to assign search) should start empty
      this.employeesUsersSearch = '';
      // Set logged-in user's name for display
      this.loggedInUserName = `${this.loggedInUser.familyName}, ${this.loggedInUser.preferredFirstName || this.loggedInUser.givenName}`;
      this.supervisorName = this.loggedInUserName;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Advance to next screen
   */
  advance(): void {
    this.screen++;
    // this.screenChanged.emit(this.screen);
  }

  /**
   * Go back to previous screen
   */
  retreat(): void {
    if (this.screen > 0) {
      this.screen--;
      // this.screenChanged.emit(this.screen);
    }
  }

  /**
   * Cancel the assignment wizard
   */
  cancel(): void {
    this.screen = 0;
    this.supervisor = null;
    this.supervisorName = '';
    this.usersToAssign = [];
    this.employeeSearch = '';
    this.employeesUsersSearch = '';
    this.selectedUsers = [];
    // this.cancelled.emit();
  }

  /**
   * Search for employees on screen 0 (supervisor search)
   */
  searchEmployeesScreen0(event?: KeyboardEvent): void {
    if (event && event.keyCode !== 13) {
      return;
    }
    this.noWorkersFound = false;
    if (this.employeeSearch) {
      this.employeeSearched.emit({ searchTerm: this.employeeSearch, type: 0 });
    }
  }

  /**
   * Search for employees on screen 2 (users to assign search)
   */
  searchEmployeesScreen2(event?: KeyboardEvent): void {
    if (event && event.keyCode !== 13) {
      return;
    }
    if (this.employeesUsersSearch) {
      this.employeeSearched.emit({ searchTerm: this.employeesUsersSearch, type: 1 });
    }
  }

  /**
   * Clear supervisor selection
   */
  clearSupervisor(): void {
    this.supervisor = null;
    this.supervisorName = '';
    this.employeeSearch = '';
  }

  /**
   * Remove selected users from the assignment list
   * Removes users from usersToAssign array and emits userRemoved event for each removed user
   */
  removeSelectedUsers(): void {
    if (!this.selectedUsers || this.selectedUsers.length === 0) {
      return;
    }

    // Sort indices in descending order to avoid index shifting issues when removing
    const indicesToRemove: number[] = [];

    this.selectedUsers.forEach((workerNumber) => {
      const index = this.usersToAssign.findIndex((u) => u.workerNumber === workerNumber);
      if (index > -1) {
        indicesToRemove.push(index);
      }
    });

    // Sort in descending order and remove from highest index to lowest
    indicesToRemove.sort((a, b) => b - a);

    indicesToRemove.forEach((index) => {
      // Emit event for each removed user
      this.userRemoved.emit(index);
      // Remove from array
      this.usersToAssign.splice(index, 1);
    });

    // Clear selected users
    this.selectedUsers = [];
  }

  /**
   * Save the assignment
   */
  saveAssignment(): void {
    if (!this.supervisor || this.usersToAssign.length === 0) {
      return;
    }
    this.assignmentSaved.emit();
  }

  /**
   * Check if user has access to perform assignments
   */
  checkRoleHasAccess(): boolean {
    // This should be implemented based on your authorization service
    return true;
  }

  /**
   * Get formatted supervisor name
   */
  getSupervisorName(): string {
    if (!this.supervisor) return '';
    return `${this.supervisor.familyName}, ${this.supervisor.preferredFirstName || this.supervisor.givenName}`;
  }

  /**
   * Get formatted user name
   */
  getFormattedName(worker: Worker): string {
    return `${worker.familyName}, ${worker.preferredFirstName || worker.givenName}`;
  }

  /**
   * Select a supervisor from search results
   */
  selectSupervisor(worker: Worker): void {
    this.supervisor = worker;
    this.supervisorName = this.getSupervisorName();
    this.supervisorSelected.emit(worker);
    this.employeeSearch = '';
    this.noWorkersFound = false;
  }

  /**
   * Check if supervisor is selected
   */
  isSupervisorSelected(): boolean {
    return !!this.supervisor;
  }

  /**
   * Check if users are selected for assignment
   */
  areUsersSelected(): boolean {
    return this.usersToAssign && this.usersToAssign.length > 0;
  }
}
