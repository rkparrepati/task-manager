import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AdvancedSearchService } from './advanced-search.service';
import { ApplicationReferenceService } from 'src/app/components/application-reference/application-reference.service';

/**
 * Interface for report type
 */
export interface ReportType {
  value: string;
  label: string;
  id?: number;
}

/**
 * Interface for search results
 */
export interface SearchResult {
  results: any[];
  meta?: {
    total: number;
  };
}

/**
 * Helper service for multiple assignments controller
 * Converted from AngularJS factory to Angular 15 service
 * Provides methods for searching users and retrieving report types
 */
@Injectable({
  providedIn: 'root'
})
export class MultipleAssignmentsService {

  constructor(
    private advancedSearchService: AdvancedSearchService,
    private applicationReferenceService: ApplicationReferenceService
  ) { }

  /**
   * Search for users based on text input
   * Converts AngularJS promise-based search to RxJS Observable
   * @param text - Search text input
   * @param includeInactive - Flag to include inactive users
   * @param flag - Additional search flag
   * @param pageName - Name of the page making the request
   * @returns Observable of search results
   */
  searchUsers(text: string, includeInactive: boolean, flag: boolean, pageName: string): Observable<SearchResult> {
    return this.advancedSearchService.multipleTextSearch(text, includeInactive, flag, pageName);
  }

  /**
   * Get the report types and map to labels
   * Converts AngularJS promise-based retrieval to RxJS Observable
   * Filters report types to only include SUPERVISOR, PAR, and TIMECARD
   * Adds a "Set All" option at the end
   * @returns Observable of filtered report types with labels
   */
  getReportTypes(): Observable<ReportType[]> {
    const typesUsed = ['SUPERVISOR', 'PAR', 'TIMECARD'];
    const labels = ['Default', 'Performance Appraisals', 'Timecard'];

    // Call getApplReferenceList with required parameters
    // includeInactive: false, limit: 1000, skip: 0
    return this.applicationReferenceService.getApplReferenceList(
      'worker-relationship-types',
      false,
      1000,
      0
    ).pipe(
      map((response: any) => {
        const reportType: ReportType[] = [];

        // Filter and map the response results
        if (response && response.results) {
          response.results.forEach((type: any) => {
            const index = typesUsed.indexOf(type.value);
            if (index >= 0) {
              reportType.push({
                value: type.value,
                label: labels[index],
                id: type.id
              });
            }
          });
        }

        // Add "Set All" option
        reportType.push({
          value: 'SET_ALL',
          label: 'Set All',
          id: -1
        });

        return reportType;
      }),
      catchError((error: any) => {        return throwError(() => new Error('Failed to retrieve report types'));
      })
    );
  }
}
