import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  OnChanges,
  Output,
  EventEmitter,
  SimpleChanges,
} from '@angular/core';
import { IWorker } from '../Models/IWorkerDetails';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { getPrimaryOrganization } from '../reportToUtil';
import { UtilityService } from 'src/app/services/utility.service';
import { HttpService } from 'src/app/services/http.service';
import { ReportserviceService } from 'src/app/services/reportservice.service';

@Component({
  selector: 'app-reports-to-search-results',
  templateUrl: './reports-to-search-results.component.html',
  styleUrls: ['./reports-to-search-results.component.scss'],
})
export class ReportsToSearchResultsComponent implements OnInit, OnChanges, OnDestroy {
  _workers: IWorker[] = [];
  totalRecords: number = 0;
  pageSizeOptions:any = [ { name: '100', value: 100 },
    { name: '250', value: 250 },];
  @Input() set workers(workers: IWorker[]) {
    const supervisors = workers
      .filter((worker) => worker.supervisorIndicator)
      .sort((worker1, worker2) => {
        return worker1.familyName.localeCompare(worker2.familyName);
      });

    const list = workers
      .filter((worker) => !worker.supervisorIndicator)
      .sort((worker1, worker2) => {
        return worker1.familyName.localeCompare(worker2.familyName);
      });

    this._workers = [...supervisors, ...list];
    this.totalRecords = this._workers.length + 1;
  }
  @Input() total: number = 0;
  @Input() sortColumn: string = 'familyName';
  @Input() sortDirection: string = 'asc';
  @Input() limit: number = 100;
  @Input() skip: number = 0;
  @Input() primaryWorker: any | null = null;
  @Input() showPrimary = false;
  @Input() primarySearchWorker: any | null = null;
  @Input() showPrimarySearch = false;
  @Input() unassignedWorkers: boolean = false;
  @Input() viewNumber: number = 0;
  @Input() reportsToSearchInput: string = '';
  @Input() exportWorkerId: string | undefined = undefined;
  @Input() displayTitle: string = '';

  @Output() workerSearchDataRequested = new EventEmitter<any>();
  @Output() assignmentEditRequested = new EventEmitter<any>();
  @Output() organizationSuffixSaved = new EventEmitter<any>();
  @Output() organizationSuffixEditModeToggled = new EventEmitter<any>();
  @Output() reportingWorkerSearchRequested = new EventEmitter<any>();
  @Output() workerEMLocatorRequested = new EventEmitter<any>();
  @Output() accronymEMLocatorRequested = new EventEmitter<any>();
  @Input() showWait: boolean = false;


  tableTitle: string = 'Reporting Information';
  showWaitUnassignedExport: boolean = false;
  showLoadingButton: boolean = false;

  private destroy$ = new Subject<void>();

  /**
   * Build reporting title based on worker information
   */
  buildReportingTitle(worker: any): void {
    if (worker && worker.familyName && worker.preferredFirstName) {
      this.tableTitle = `Reporting Information for: ${worker.familyName}, ${worker.preferredFirstName} - ${worker.workerNumber} - ${worker.organization}`;
    } else {
      this.tableTitle = 'Reporting Information';
    }
  }
  displayedColumns: string[] = [
    'workerNumber',
    'name',
    'organization',
    'defaultReporting',
    'parReporting',
    'timecardReporting',
  ];

  showValueOrgSuffix: string = '';
  organizationSuffixModel: any = {};
  userRole: string = ''; // To be set from parent component

  constructor(
    private utilityService: UtilityService,
    private httpService: HttpService,
    private reportserviceService: ReportserviceService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {


    // Update title when primary worker changes
    if (this.primaryWorker) {
      this.buildReportingTitle(this.primaryWorker);
    } else if (this.primarySearchWorker) {
      this.buildReportingTitle(this.primarySearchWorker);
    }
  }

  ngOnInit(): void {

  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Sort handler for table columns
   * Updates sort column and direction, then re-sorts the workers array
   */
  onSort(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    
    // Re-sort the workers array based on new sort column and direction
    this.sortWorkers();
  }

  /**
   * Sort workers array based on current sortColumn and sortDirection
   * Handles sorting for familyName, workerNumber, and other columns
   */
  private sortWorkers(): void {
    if (!this._workers || this._workers.length === 0) {
      return;
    }

    this._workers.sort((worker1: any, worker2: any) => {
      let value1: any;
      let value2: any;

      // Extract values based on sort column
      switch (this.sortColumn) {
        case 'familyName':
          value1 = worker1.familyName || '';
          value2 = worker2.familyName || '';
          break;
        case 'workerNumber':
        case 'workerNumber1':
          value1 = worker1.workerNumber || '';
          value2 = worker2.workerNumber || '';
          // Convert to numbers for numeric comparison
          if (!isNaN(Number(value1)) && !isNaN(Number(value2))) {
            value1 = Number(value1);
            value2 = Number(value2);
          }
          break;
        case 'name':
          value1 = `${worker1.familyName || ''} ${worker1.preferredFirstName || ''}`.trim();
          value2 = `${worker2.familyName || ''} ${worker2.preferredFirstName || ''}`.trim();
          break;
        case 'organization':
          value1 = worker1.organization || '';
          value2 = worker2.organization || '';
          break;
        case 'supervisorIndicator':
          value1 = worker1.supervisorIndicator ? 1 : 0;
          value2 = worker2.supervisorIndicator ? 1 : 0;
          break;
        default:
          value1 = worker1[this.sortColumn] || '';
          value2 = worker2[this.sortColumn] || '';
      }

      // Compare values
      if (typeof value1 === 'string' && typeof value2 === 'string') {
        // String comparison (case-insensitive)
        const comparison = value1.toLowerCase().localeCompare(value2.toLowerCase());
        return this.sortDirection === 'asc' ? comparison : -comparison;
      } else {
        // Numeric comparison
        if (value1 < value2) {
          return this.sortDirection === 'asc' ? -1 : 1;
        } else if (value1 > value2) {
          return this.sortDirection === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      }
    });
  }

  /**
   * Get sort icon for column header
   */
  getSortIcon(column: string): string {
    if (this.sortColumn !== column) {
      return 'fa-sort';
    }
    return this.sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
  }

  /**
   * Check if current user role has access to edit
   * Equivalent to AngularJS vm.checkRoleHasAccess()
   */
  checkRoleHasAccess(): boolean {
    // This should be implemented based on your authorization service
    // For now, returning true as placeholder
    return true;
  }

  /**
   * Save organization suffix for worker
   * Equivalent to AngularJS vm.saveOrgSuffix(worker)
   * Calls the service to persist the organization suffix and emits event on success
   */
  saveOrgSuffix(worker: any): void {
    if (worker && this.organizationSuffixModel.organizationSuffixTx) {
      const organizationSuffixValue = this.organizationSuffixModel.organizationSuffixTx;

      // Call service to save organization suffix
      this.reportserviceService
        .saveOrganizationSuffix(worker.workerId, organizationSuffixValue)
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          (response: any) => {
            // Update worker object with new suffix
            worker.organizationSuffixTx = organizationSuffixValue;

            // Reset UI state
            this.showValueOrgSuffix = '';
            this.organizationSuffixModel = {};

            // Emit event to parent component with updated worker data
            this.organizationSuffixSaved.emit({
              worker: worker,
              organizationSuffixTx: organizationSuffixValue,
              success: true,
            });
          },
          (error: any) => {
            // Handle error - reset UI state but don't update worker
            this.showValueOrgSuffix = '';
            this.organizationSuffixModel = {};

            // Emit error event to parent component
            this.organizationSuffixSaved.emit({
              worker: worker,
              organizationSuffixTx: organizationSuffixValue,
              success: false,
              error: error,
            });
          }
        );
    }
  }

  /**
   * Get reporting worker search data and update
   * Equivalent to AngularJS vm.getReportingWorkerSearchDataUpdated(worker)
   */
  getReportingWorkerSearchDataUpdated(worker: any): void {
    
    if (worker) {
      this.reportingWorkerSearchRequested.emit(worker);
    }
  }

  /**
   * Get worker EM locator URL and navigate
   * Equivalent to AngularJS vm.getWorkerEMLocator(workerNumber)
   */
  getWorkerEMLocator(workerNumber: string | undefined): void {
    if (workerNumber) {
      this.workerEMLocatorRequested.emit(workerNumber);
    }
  }

  /**
   * Toggle organization suffix edit mode
   * Equivalent to AngularJS vm.organizationSuffixEditMode(workerNumber, organizationSuffixTx)
   */
  organizationSuffixEditMode(workerNumber: any, organizationSuffixTx: any): void {
    if (this.showValueOrgSuffix === workerNumber) {
      this.showValueOrgSuffix = '';
    } else {
      this.showValueOrgSuffix = workerNumber;
      this.organizationSuffixModel = {
        organizationSuffixTx: organizationSuffixTx || '',
      };
    }

    this.organizationSuffixEditModeToggled.emit({
      workerNumber: workerNumber,
      isEditMode: this.showValueOrgSuffix === workerNumber,
    });
  }

  /**
   * Edit assignment for worker
   * Equivalent to AngularJS vm.editAssignment(worker, type, isDefault)
   */
  editAssignment(worker: any, type: string, isDefault: boolean): void {
    if (worker) {
      this.assignmentEditRequested.emit({
        worker: worker,
        type: type,
        isDefault: isDefault,
      });
    }
  }

  /**
   * Get accronym EM locator
   * Equivalent to AngularJS vm.getAccronymEMLocator()
   */
  getAccronymEMLocator(accronym: string): void {
     if (accronym) {
      this.accronymEMLocatorRequested.emit(accronym);
    }
  }

  /**
   * Get worker search data
   * Equivalent to AngularJS vm.getWorkerSearchData(getSubList)
   */
  getWorkerSearchData(worker: IWorker): void {
    // if (this.primarySearchWorker) {
    // this.workerSearchDataRequested.emit({
    //   worker: this.primarySearchWorker,
    //   getSubList: getSubList,
    // });
    // }
    this.showPrimary = true;
    this.primaryWorker = worker;
    this.workerSearchDataRequested.emit(worker);
  }

  /**
   * Get worker name from worker number
   */
  getWorkerName(workerNumber: string): string {
    return workerNumber;
  }

  /**
   * Get primary organization from organization history
   * Equivalent to AngularJS vm.getPrimaryOrganization(organizationHistory)
   */
  getPrimaryOrganization(organizationHistory: any[]): string {
    return getPrimaryOrganization(organizationHistory || []);
  }

  /**
   * Export reporting data to Excel
   * Equivalent to AngularJS vm.exportDataCallback()
   * Exports the current reporting information table to an Excel file
   * Handles multiple export scenarios: unassigned workers, P workers, and regular reporting
   */
  exportDataCallback(): void {
    let url = '';
    let fileName = '';
    const defaultWorkerNumber = this.primaryWorker?.workerNumber;

    // Scenario 1: Unassigned Workers Export
    if (this.unassignedWorkers === true) {
      this.showWaitUnassignedExport = true;
      url =
        '/workers/speUnassignedEmployeeExcelReport?skip=0&notRelated=true&limit=' +
        this.total +
        '&sortColumn=' +
        this.sortColumn +
        '&sortDirection=' +
        this.sortDirection;

      // Add P business area code if viewing P workers
      if (this.viewNumber === 4) {
        url = url + '&businessAreaCode=P';
      }
      fileName = 'SPEUnassignedEmployeeExport.xls';
    }
    // Scenario 2: P Workers (viewNumber === 4)
    else if (this.viewNumber === 4) {
      url =
        '/workers/speUnassignedEmployeeExcelReport?businessAreaCode=P&skip=0&notRelated=true&limit=' +
        this.total +
        '&sortColumn=' +
        this.sortColumn +
        '&sortDirection=' +
        this.sortDirection;
      fileName = 'SPEReportingInformationExport.xls';
    }
    // Scenario 3: Export by associated worker ID
    else if (this.exportWorkerId && this.exportWorkerId !== '' && this.exportWorkerId !== null) {
      url =
        '/workers/speEmployeeExcelReport?includeInactive=false&associatedToReportingWorkerId=' +
        this.exportWorkerId;
      fileName = 'SPEReportingInformationExport.xls';
    }
    // Scenario 4: Default - Export by primary worker number
    else {
      url =
        '/workers/speEmployeeExcelReport?includeInactive=false&workerNumber=' +
        defaultWorkerNumber;
      fileName = 'SPEReportingInformationExport.xls';
    }

    // Export the file using utility service (pass relative path only, httpService will add DOMAIN)
    this.utilityService.exportTableService(url, fileName, 'application/vnd.ms-excel');

    // Reset loading state
    this.showWait = false;
  }

  getWorkerOrganisationSuffix(orgSuffix: string | null): string {
    return orgSuffix || '';
  }

  /**
   * Handle page size change event from pagination component
   * Resets skip to 0 and updates limit when page size changes
   * Emits event to parent component to fetch data with new page size
   */
  pageSizeChangedEvent(limit: number): void {
    this.limit = limit;
    this.skip = 0;
    // Emit event to parent component to reload data with new page size
    this.workerSearchDataRequested.emit({
      limit: this.limit,
      skip: this.skip,
    });
  }

  /**
   * Handle page change event from pagination component
   * Updates skip value based on page number and limit
   * Emits event to parent component to fetch data for the selected page
   */
  onPageChanged(pageNumber: number): void {
    this.skip = (pageNumber - 1) * this.limit;
    // Emit event to parent component to reload data for new page
    this.workerSearchDataRequested.emit({
      limit: this.limit,
      skip: this.skip,
    });
  }
}
