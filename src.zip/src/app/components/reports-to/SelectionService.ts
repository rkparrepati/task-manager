// selection.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class SelectionService {
  private selectedItem = new BehaviorSubject<string | null>(null);
  selectedItem$ = this.selectedItem.asObservable();

  select(item: string) {
    this.selectedItem.next(item);
  }
}
