import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpService } from 'src/app/services/http.service';

/**
 * Interface for search results
 */
export interface SearchResult {
  results: any[];
  meta?: {
    total: number;
  };
}

/**
 * Interface for advanced search options
 */
export interface AdvancedSearchOptions {
  [key: string]: {
    value?: string;
    description?: string;
  };
}

/**
 * Advanced search service for multiple search types
 * Converted from AngularJS SearchHelperService to Angular 15 with RxJS Observables
 * Provides methods for searching workers by organization, character pattern, and worker number
 */
@Injectable({
  providedIn: 'root'
})
export class AdvancedSearchService {

  constructor(private httpService: HttpService) { }

  /**
   * Perform multiple text search based on input type
   * Routes to appropriate search method based on text pattern
   * @param text - Search text input
   * @param includeInactive - Flag to include inactive records
   * @param flag - Additional search flag
   * @param pageName - Name of the page making the request
   * @returns Observable of search results
   */
  multipleTextSearch(text: string, includeInactive: boolean, flag: boolean, pageName: string): Observable<SearchResult> {    let defaultLimit = 100;
    if (pageName === 'reportsToPage') {
      defaultLimit = 200;
    }
    if (pageName === 'tableDataPage') {
      defaultLimit = 100000;
    }

    // Check if searching by organization (contains '/')
    if (text.indexOf('/') === 1) {
      return this.searchOrganization(text, includeInactive, flag, defaultLimit);
    }

    // Check if searching by character pattern (starts with 'C' followed by non-numeric)
    if (text.substring(0, 1) === 'C') {
      if (isNaN(parseInt(text.substring(1, text.length)))) {
        return this.characterSearch(text, includeInactive, flag, defaultLimit);
      }
    } else {
      // Check if text is non-numeric
      if (isNaN(parseInt(text))) {
        return this.characterSearch(text, includeInactive, flag, defaultLimit);
      }
    }

    // Default to worker number search
    return this.searchWorkerNumber(text, includeInactive, flag, defaultLimit);
  }

  /**
   * Search by organization
   * Validates text length and extracts business area code and short name
   * @param text - Organization search text (format: "X/shortName")
   * @param includeInactive - Include inactive organizations
   * @param flag - Flag to identify search from ReportsTo page
   * @param limit - Result limit
   * @returns Observable of search results
   */
  private searchOrganization(text: string, includeInactive: boolean, flag: boolean, limit: number): Observable<SearchResult> {
    // Validate text length (must be at least 4 characters: X/XX)
    if (text.length < 4) {
      return throwError(() => ({
        statusCode: 404,
        message: 'Organization search text must be at least 4 characters'
      }));
    }

    // Extract business area code and short name
    const businessAreaCode = text.substring(0, 1);
    const shortName = text.substring(2);

    // Build query parameters
    const params = {
      businessAreaCode: businessAreaCode,
      shortName: shortName,
      includeInactive: !!includeInactive,
      limit: limit
    };

    const queryString = this.buildQueryString(params);
    const url = `/workers/search/organization?${queryString}`;

    return this.httpService.get(url).pipe(
      map((response: any) => response.data || response),
      catchError((error: any) => {        return throwError(() => error);
      })
    ) as Observable<SearchResult>;
  }

  /**
   * Search by character pattern (name-based search)
   * Splits text by spaces and searches by lastName and preferredFirstName
   * @param text - Character search text (can be "LastName" or "FirstName LastName")
   * @param includeInactive - Include inactive records
   * @param flag - Flag to identify search from ReportsTo page
   * @param limit - Result limit
   * @returns Observable of search results
   */
  private characterSearch(text: string, includeInactive: boolean, flag: boolean, limit: number): Observable<SearchResult> {
    const names = text.split(' ');

    // Build advanced search options
    const advanceSearchOptions: AdvancedSearchOptions = {
      lastName: {
        value: 'familyName',
        description: ''
      },
      preferredFirstName: {
        value: 'preferredFirstName',
        description: ''
      },
      ssn: {},
      ssn2: {
        description: ''
      },
      birthDate: {
        description: ''
      },
      cedrRoles: {
        value: 'cedrRoles',
        description: ''
      }
    };

    // Add flag if provided
    if (flag != null && flag !== undefined) {
      advanceSearchOptions.flag = {
        value: 'flag',
        description: 'true'
      };
    }

    // Parse names
    if (names.length > 1) {
      advanceSearchOptions.preferredFirstName.description = names[1];
      advanceSearchOptions.lastName.description = names[0];
    } else {
      advanceSearchOptions.lastName.description = names[0];
    }

    // Determine sort column based on flag
    const sortColumn = flag ? 'familyName1' : 'familyName';

    return this.getWorkerListAdvancedSearch(
      advanceSearchOptions,
      includeInactive,
      false,
      limit,
      0,
      sortColumn,
      'asc'
    );
  }

  /**
   * Search by worker number
   * Performs GET request to fetch worker details by worker number
   * @param text - Worker number search text
   * @param includeInactive - Include inactive workers
   * @param flag - Flag to identify search from ReportsTo page
   * @param limit - Result limit
   * @returns Observable of search results
   */
  private searchWorkerNumber(text: string, includeInactive: boolean, flag: boolean, limit: number): Observable<SearchResult> {
    const includeInactiveValue = this.getIncludeInactive(includeInactive);

    let params: any;
    if (flag) {
      params = {
        workerNumber: text,
        includeInactive: !!includeInactiveValue,
        flag: true,
        limit: limit,
        sortColumn: 'familyName1',
        sortOrder: 'asc'
      };
    } else {
      params = {
        workerNumber: text,
        includeInactive: !!includeInactiveValue
      };
    }

    const queryString = this.buildQueryString(params);
    const url = `/workers?${queryString}`;

    return this.httpService.get(url).pipe(
      map((response: any) => response.data || response),
      catchError((error: any) => {        return throwError(() => error);
      })
    ) as Observable<SearchResult>;
  }

  /**
   * Get worker list using advanced search
   * Performs advanced search with multiple criteria
   * @param advanceSearchOptions - Advanced search options object
   * @param includeInactive - Include inactive workers
   * @param isContractor - Filter for contractors
   * @param limit - Result limit
   * @param skip - Number of records to skip
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @returns Observable of search results
   */
  private getWorkerListAdvancedSearch(
    advanceSearchOptions: AdvancedSearchOptions,
    includeInactive: boolean,
    isContractor: boolean,
    limit: number,
    skip: number,
    sortColumn: string,
    sortOrder: string
  ): Observable<SearchResult> {
    const params = {
      ...advanceSearchOptions,
      includeInactive: !!includeInactive,
      isContractor: !!isContractor,
      limit: limit,
      skip: skip,
      sortColumn: sortColumn,
      sortOrder: sortOrder
    };

    const queryString = this.buildQueryString(params);
    const url = `/workers/search/advanced?${queryString}`;

    return this.httpService.get(url).pipe(
      map((response: any) => response.data || response),
      catchError((error: any) => {        return throwError(() => error);
      })
    ) as Observable<SearchResult>;
  }

  /**
   * Convert includeInactive string value to boolean
   * @param includeInactive - String value ('active' or 'inactive')
   * @returns Boolean value
   */
  private getIncludeInactive(includeInactive: any): boolean {
    if (includeInactive === 'active' || includeInactive === false) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * Build query string from parameters object
   * @param params - Parameters object
   * @returns Query string
   */
  private buildQueryString(params: any): string {
    const queryParts: string[] = [];

    for (const key in params) {
      if (params.hasOwnProperty(key)) {
        const value = params[key];
        if (value !== null && value !== undefined && value !== '') {
          if (typeof value === 'object') {
            // Handle nested objects
            if (value.description) {
              queryParts.push(`${key}=${encodeURIComponent(value.description)}`);
            }
          } else {
            queryParts.push(`${key}=${encodeURIComponent(value)}`);
          }
        }
      }
    }

    return queryParts.join('&');
  }
}
