import { Component, Input, OnInit, OnDestroy, Optional, OnChanges, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CustomDialogRef } from 'src/app/services/dialog.service';
import { UtilityService } from 'src/app/services/utility.service';
import { PageSizeOption } from 'src/app/components/core/pagination/pagination.interface';

/**
 * History of Managers Component
 * Displays manager history in a table format
 * Features:
 * - Displays manager name, relationship type, start date, end date
 * - Highlights rows with gaps > 2 days in red
 * - Supports both standalone and dialog modes
 * - Proper date formatting (MM/dd/yyyy)
 * - Lifecycle field mapping (lifecycle.beginDate, lifecycle.endDate)
 */
@Component({
  selector: 'app-history-of-managers',
  templateUrl: './history-of-managers.component.html',
  styleUrls: ['./history-of-managers.component.scss'],
})
export class HistoryOfManagersComponent implements OnInit,OnChanges, OnDestroy {
  @Input() managersHistoryList: any[] = [];
  @Input() selectedWorker: any = null;

  private destroy$ = new Subject<void>();
  displayedColumns: string[] = ['managerName', 'relationshipType', 'startDate', 'endDate'];
  isDialogMode: boolean = false;

  // Pagination properties
  total: number = 0;
  limit: number = 100;
  currentPage: number = 1;
  selectOptions: PageSizeOption[] = [ { name: '100', value: 100 },
    { name: '250', value: 250 },];
  firstPage: boolean = true;

  // UI State
  showWait: boolean = false;
  tableTitle: string = 'History of Managers';

  constructor(
    @Optional() private dialogRef?: CustomDialogRef<any>,
    private utilityService?: UtilityService
  ) {
    this.isDialogMode = !!dialogRef;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['managersHistoryList']) {
      this.updateTotal();
    }
  }
  ngOnInit(): void {

  }

  /**
   * Update total count from managers history list
   */
  private updateTotal(): void {
    this.total = this.managersHistoryList ? this.managersHistoryList.length : 0;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Close the dialog if in dialog mode
   * Equivalent to AngularJS $modalInstance.close()
   */
  closeDialog(): void {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

  /**
   * Format date to MM/dd/yyyy format
   * @param date Date string or Date object
   * @returns Formatted date string
   */
  formatDate(date: string | Date): string {
    if (!date) return '';
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const year = d.getFullYear();
    return `${month}/${day}/${year}`;
  }

  /**
   * Get display text for relationship type
   * @param type Relationship type code
   * @returns Display text for relationship type
   */
  getRelationshipTypeDisplay(type: string): string {
    const typeMap: { [key: string]: string } = {
      SUPERVISOR: 'Supervisor',
      PAR: 'PAR',
      TIMECARD: 'Timecard',
    };
    return typeMap[type] || type;
  }

  /**
   * Check if row has gap detection flag
   * Used for conditional styling (red highlighting)
   * @param manager Manager record
   * @returns True if gap > 2 days detected
   */
  hasGapDetected(manager: any): boolean {
    return manager && manager.index === true;
  }

  /**
   * Export manager history data to Excel
   * Equivalent to AngularJS vm.exportDataCallbackHisMngrs()
   */
  exportDataCallbackHisMngrs(): void {
    if (!this.managersHistoryList || this.managersHistoryList.length === 0) {      return;
    }

    if (!this.utilityService) {      return;
    }

    const exportWorkerId = this.managersHistoryList[0].fkBaseWorkerId;
    const url = `/manager-history/excelReport/${exportWorkerId}?limit=100000&skip=0`;
    this.utilityService.exportTableService(url, 'HistMngrExport.xls', 'application/vnd.ms-excel');
    this.showWait = false;
  }

  /**
   * Handle pagination page change
   * Equivalent to AngularJS pagination update function
   */
  getManagersHistory(pageData: any): void {
    // Update pagination state based on page change
    if (pageData) {
      this.currentPage = pageData.currentPage || 1;
      this.limit = pageData.pageSize || 10;
      this.firstPage = this.currentPage === 1;
    }

    // Trigger data refresh if needed
    // This can be overridden by parent component if needed
    this.showWait = false;
  }
}
