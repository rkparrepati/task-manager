import { WorkerModel } from '../../reports/model/workerModel';

export interface columnDefinition {
  key: string;
  header: string;
}
export interface ISearchWorker {
  name: string;
  workerNumber: string;
  workerId: number;
}
export interface IWorkerVM {
  userInfo: any;
  total: number;
  editable: boolean;
  originalList: any[];
  workerList: any[];
  reportsToSearchInput: any;
  limit: number;
  tableTitle: string;
  employeeSearch: string;
  supervisorData: any;
  skip: number;
  primaryWorkerId: number;
  reportsToType: any;
  links: any;
  workerNumber: string;
  primaryWorker: any;
  isPrimary: boolean;
  usersToAssign: any[];
  employeeList: any[];
  tableList: any[];
  screen: number;
  showPrimary: boolean;
  titles: string[];
  showValueOrgSuffix: string;
  unassignedPWorkers: boolean;
  orgSuffixUpdateValue: string;
  moduleName: string;
  includeAttrition: boolean; // <-- Added property
  employeesUsersSearch: string;
  viewName: string;
  appTitle: string;
  sortDirection: string;
  sortColumn: string;
  showPrimarySearch: boolean;
  getEmployeesOnlytype2: any[];
  subListSupervisorIndicator: boolean;
  showWait: boolean;
  showWaitUnassignedExport: boolean;
  accronym: string;
  emLocatorurl: string;
  exportWorkerId: string;
  parReportTypeObject: string;
  timecardReportTypeObject: string;
  defaultUpdateOfPar: boolean;
  defaultUpdateOfTimecard: boolean;
  employeeListGlobal: any[];
  managersHistoryList: any[];
  noWorkersFound: boolean;
  noWorkerFoundMsg: string;
  editViewNumber: number;
  selectOptions: any[];
  person: any;
  setTimeoutInterval: any;
  supervisor: any;
  supervisorName: string;
  reportToType?: any;
}
