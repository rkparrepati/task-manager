import { Component, OnInit, OnDestroy, Optional, Inject } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportserviceService } from 'src/app/services/reportservice.service';
import { IWorker, Worker } from '../Models/IWorkerDetails';

/**
 * History Manager Dialog Component
 * Displays a dialog for searching and viewing manager history
 * Converted from AngularJS to Angular 15 with RxJS patterns
 * Uses Angular Material Dialog for modal display
 *
 * Dialog Data Input:
 * - managersHistoryList: Array of manager history records to display
 * - parentComponent: Reference to parent ReportsToComponent for fetching manager history
 *
 * Dialog Result:
 * - Returns selected worker data when a manager is selected
 * - Returns undefined if dialog is closed without selection
 *
 * Workflow:
 * 1. Dialog opens with search bar
 * 2. User searches for worker (e.g., 87666)
 * 3. API call fetches matching workers
 * 4. User selects worker from results
 * 5. Manager history is fetched for selected worker
 * 6. Manager history is displayed in the dialog
 */
@Component({
  selector: 'app-history-mngr-dialog',
  templateUrl: './history-mngr-dialog.component.html',
  styleUrls: ['./history-mngr-dialog.component.scss'],
})
export class HistoryMngrDialogComponent implements OnInit, OnDestroy {
  // Observable subjects
  managersHistoryList: any[] = [];

  private destroy$ = new Subject<void>();
  private searchSubject$ = new Subject<string>();

  // UI State
  viewNumber: number = 5;

  // Search and filter properties
  reportsToSearchInput: string = '';
  includeAttrition: boolean = false;
  showWaitWorkerSearch: boolean = false;
  showSaveWait: boolean = false;
  mainNoWorkerFound: boolean = false;

  // Data properties
  getEmployeesOnlytype2: Worker[] = [];
  selectedWorker: IWorker | null = null;
  parentComponent: any = null;

  constructor(
    private reportserviceService: ReportserviceService,
    public dialogRef: MatDialogRef<HistoryMngrDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    // Initialize managers history list from dialog data
    if (data && data.managersHistoryList) {
      this.managersHistoryList = data.managersHistoryList;
    }
    // Get reference to parent component for fetching manager history
    if (data && data.parentComponent) {
      this.parentComponent = data.parentComponent;
    }
  }

  ngOnInit(): void {
    this.setupSearchDebounce();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Setup search debouncing for employee search
   * Equivalent to AngularJS ng-keyup with debounce
   */
  private setupSearchDebounce(): void {
    this.searchSubject$
      .pipe(debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$))
      .subscribe((searchTerm: string) => {
        if (searchTerm.length >= 2) {
          this.getEmployees(2);
        }
      });
  }

  /**
   * Handle search input keyup event
   * Equivalent to AngularJS ng-keyup="vm.menuSearchEmployeesKeyEvent($event, 2)"
   */
  onSearchKeyup(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      this.getEmployees(2);
    } else {
      this.searchSubject$.next(this.reportsToSearchInput);
    }
  }

  /**
   * Search for employees
   * Equivalent to AngularJS vm.getEmployees(type)
   */
  getEmployees(type: number): void {
    if (!this.reportsToSearchInput || this.reportsToSearchInput.length < 2) {
      return;
    }

    this.showWaitWorkerSearch = true;
    this.mainNoWorkerFound = false;
    this.getEmployeesOnlytype2 = [];

    const includeInactive = this.includeAttrition;

    this.reportserviceService
      .searchWorkerNumber(
        this.reportsToSearchInput,
        includeInactive,
        true,
        200,
        'familyName1',
        'asc'
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.showWaitWorkerSearch = false;

          const results = response?.results || [];
          const onlyEmps = results.filter((emp: any) => emp.employmentType?.value !== 'C');

          if (onlyEmps.length === 0) {
            this.mainNoWorkerFound = true;
          } else {
            this.getEmployeesOnlytype2 = onlyEmps;
          }
        },
        (error: any) => {
          this.showWaitWorkerSearch = false;
          if (error.status === 404) {
            this.mainNoWorkerFound = true;
          }
        }
      );
  }

  /**
   * Handle manager history selection
   * When user selects a worker from search results:
   * 1. Fetch manager history for the selected worker
   * 2. Display manager history in the dialog
   * Equivalent to AngularJS vm.getSelectedMngrHistory(worker)
   */
  getSelectedMngrHistory(worker: Worker): void {
    if (!worker) {      return;
    }
    this.selectedWorker = worker as unknown as IWorker;

    // Fetch manager history for selected worker using parent component method
    if (this.parentComponent && this.parentComponent.getManagersHistory) {
      this.showSaveWait = true;
      this.parentComponent.getManagersHistory(this.selectedWorker);

      // Update managers history list after fetch
      // The parent component will update managersHistoryList
      setTimeout(() => {
        this.managersHistoryList = this.parentComponent.managersHistoryList;
        this.showSaveWait = false;
        this.closeThisDialog();
      }, 500);
    } else {    }
  }

  /**
   * Toggle include inactive employees checkbox
   * Equivalent to AngularJS ng-click="vm.getEmployees(2);"
   */
  onIncludeAttritionChange(): void {
    this.getEmployees(2);
  }

  /**
   * Close the dialog
   * Equivalent to AngularJS closeThisDialog()
   */
  closeThisDialog(): void {
    this.dialogRef.close();
  }

  /**
   * Clear search input
   */
  clearSearch(): void {
    this.reportsToSearchInput = '';
    this.getEmployeesOnlytype2 = [];
    this.mainNoWorkerFound = false;
  }
}
