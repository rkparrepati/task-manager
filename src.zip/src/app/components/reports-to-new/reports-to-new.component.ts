import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ReportsToAPIService } from './Services/reports-to-api.service';
import { ReportsToBusinessService } from './Services/reports-to-business.service';
import {
  IWorker,
  Worker,
  Assignment,
  RelationshipType
} from './Models/IWorkerDetails';

@Component({
  selector: 'app-reports-to-new',
  templateUrl: './reports-to-new.component.html',
  styleUrls: ['./reports-to-new.component.scss']
})
export class ReportsToNewComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private searchSubject$ = new Subject<string>();

  // View state
  viewNumber: number = 0;
  titles: string[] = [
    'Unassigned Workers',
    'Multiple Assignments',
    'Waiting for Assignment',
    'Manager History',
    'Unassigned P Workers',
    'Manager History'
  ];

  // Worker and search data
  workers: IWorker[] = [];
  workerList: IWorker[] = [];
  employeeListGlobal: IWorker[] = [];
  getEmployeesOnlytype2: IWorker[] = [];
  currentWorker: IWorker | null = null;
  currentSupervisor: Worker | null = null;

  // UI state
  showMessage: boolean = false;
  messageType: string = '';
  messageText: string = '';
  setTimeoutInterval: any;
  notificationCheckbox: boolean = false;
  organizationSuffixEditMode: boolean = false;
  organizationSuffixModel: any = {};

  // Data collections
  reportToTypes: RelationshipType[] = [];
  waitingForAssignmentList: Assignment[] = [];
  managersHistoryList: Assignment[] = [];
  unassignedWorkersList: IWorker[] = [];
  unassignedPWorkersList: IWorker[] = [];
  multipleAssignmentWorkers: IWorker[] = [];

  // Pagination and sorting
  sortColumn: string = 'workerNumber';
  sortOrder: string = 'asc';
  limit: number = 50;
  skip: number = 0;

  // Search parameters
  searchTerm: string = '';
  selectedReportType: number = 1;
  businessAreaCode: string = '';

  // Flags
  isLoading: boolean = false;
  hasNoResults: boolean = false;
  accessDenied: boolean = false;

  // Section visibility
  showLinksSection: boolean = true;
  showSearchSection: boolean = true;
  showReportingSection: boolean = true;

  // Search input
  reportsToSearchInput: string = '';
  includeAttrition: boolean = false;

  constructor(
    private apiService: ReportsToAPIService,
    private businessService: ReportsToBusinessService
  ) {
    this.currentWorker = this.businessService.initializeWorker();
  }

  ngOnInit(): void {
    this.userInfoRetrieved();
    this.setupSearchDebounce();
    this.loadParameters();
    this.setDefaultReportType();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Get report type value (string) from selected report type ID
   */
  get selectedReportTypeValue(): string {
    const reportType = this.reportToTypes.find(rt => rt.id === this.selectedReportType);
    return reportType ? reportType.value : 'SUPERVISOR';
  }

  /**
   * Get sorted employee list
   */
  get sortedEmployeeList(): IWorker[] {
    return this.businessService.sortEmployeeList(
      this.employeeListGlobal,
      this.sortColumn,
      this.sortOrder
    );
  }

  /**
   * Load current user information on component init
   */
  private userInfoRetrieved(): void {
    this.businessService
      .loadUserInfo(this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && response.data) {
            this.currentWorker = response.data;
          }
        },
        error: (error: any) => {          this.setMessage('ERROR', 'Failed to retrieve user information');
        }
      });
  }

  /**
   * Setup search debounce to prevent excessive API calls
   */
  private setupSearchDebounce(): void {
    this.searchSubject$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm: string) => {
        this.performSearch(searchTerm);
      });
  }

  /**
   * Load system parameters
   */
  private loadParameters(): void {
    this.businessService
      .loadParameters(this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.businessAreaCode = this.businessService.extractBusinessAreaCode(response);
        },
        error: (error: any) => {        }
      });
  }

  /**
   * Load and set default report type
   */
  private setDefaultReportType(): void {
    this.businessService
      .loadReportTypes(this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && response.data) {
            this.reportToTypes = response.data;
            this.selectedReportType = this.businessService.getDefaultReportType(
              this.reportToTypes
            );
          }
        },
        error: (error: any) => {          this.setMessage('ERROR', 'Failed to load report types');
        }
      });
  }

  /**
   * Navigate to view by ID
   */
  users(id: number): void {
    this.showView(id);
  }

  /**
   * Select a worker and show their data
   */
  selectWorker(worker: IWorker): void {
    this.currentWorker = worker;
    this.showWorkerData(worker);
  }

  /**
   * Perform worker search with debounce
   */
  private performSearch(searchTerm: string): void {
    if (!searchTerm || searchTerm.trim().length === 0) {
      this.workers = [];
      return;
    }

    this.isLoading = true;
    this.hasNoResults = false;

    this.businessService
      .searchWorkers(searchTerm, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.results) {
            this.workers = this.businessService.processSearchResults(
              response.results
            );
            this.hasNoResults = this.workers.length === 0;
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.hasNoResults = true;
          this.setMessage('ERROR', 'Error searching workers');
        }
      });
  }

  /**
   * Show specific view by number
   */
  showView(number: number): void {
    this.viewNumber = number;
    this.hasNoResults = false;
    this.showMessage = false;

    switch (number) {
      case 0:
        this.getUnassignedWorkers(this.limit, this.skip);
        break;
      case 2:
        this.getWaitingForAssignments();
        break;
      case 4:
        this.getUnassignedPWorkers(this.limit, this.skip);
        break;
      case 3:
      case 5:
        this.getManagersHistory(this.currentWorker?.workerId || 0, this.limit, this.skip);
        break;
      default:
        break;
    }
  }

  /**
   * Get unassigned P workers
   */
  private getUnassignedPWorkers(limit: number, skip: number, businessAreaCode?: string): void {
    this.isLoading = true;
    this.businessService
      .getUnassignedPWorkers(
        this.currentWorker?.workerId || 0,
        this.sortColumn,
        this.sortOrder,
        this.destroy$
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.unassignedPWorkersList = this.businessService.processWorkerList(
              response.data
            );
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Failed to load unassigned P workers');
        }
      });
  }

  /**
   * Get unassigned workers
   */
  private getUnassignedWorkers(limit: number, skip: number, businessAreaCode?: string): void {
    this.isLoading = true;
    this.businessService
      .getUnassignedWorkers(
        this.currentWorker?.workerId || 0,
        this.sortColumn,
        this.sortOrder,
        this.destroy$
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.unassignedWorkersList = this.businessService.processWorkerList(
              response.data
            );
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Failed to load unassigned workers');
        }
      });
  }

  /**
   * Get waiting for assignments
   */
  private getWaitingForAssignments(): void {
    this.isLoading = true;
    this.businessService
      .getWaitingForAssignments(this.currentWorker?.workerNumber || '', this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          this.waitingForAssignmentList = this.businessService.processWaitingForAssignments(
            response
          );
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Failed to load waiting for assignments');
        }
      });
  }

  /**
   * Get employees for current worker
   */
  getEmployees(type: number): void {
    if (!this.currentWorker) return;

    this.isLoading = true;
    const searchTerm = this.businessService.getSearchTermForRelationshipType(type);

    this.businessService
      .getSupervisorWorkers(this.currentWorker.workerId, searchTerm, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.processWorkerReportSearchInfo(this.currentWorker!, response.data, false);
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error loading employees');
        }
      });
  }

  /**
   * Show all employees for current worker
   */
  showAllBtn(): void {
    if (!this.currentWorker) return;

    this.isLoading = true;
    this.businessService
      .getAllSupervisorWorkers(this.currentWorker.workerId, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.processWorkerReportSearchInfo(this.currentWorker!, response.data, false);
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error loading all employees');
        }
      });
  }

  /**
   * Get worker search data
   */
  getWorkerSearchData(worker: IWorker, getSubList: boolean = false): void {
    this.currentWorker = worker;
    this.isLoading = true;

    this.businessService
      .getWorkerSearchData(worker.workerNumber, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.processWorkerReportSearchInfo(worker, response.data, getSubList);
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error loading worker search data');
        }
      });
  }

  /**
   * Process worker report search info
   */
  private processWorkerReportSearchInfo(
    worker: IWorker,
    data: any[],
    getSubList: boolean
  ): void {
    this.processWorkerReportInfo(worker, data, getSubList);
  }

  /**
   * Process worker report info
   */
  private processWorkerReportInfo(worker: IWorker, data: any[] | null, getSubList: boolean): void {
    if (!data) {
      this.getWorkerEmployeeList(worker);
      return;
    }

    this.employeeListGlobal = this.businessService.processWorkerReportInfo(data);
    this.workerList = [...this.employeeListGlobal];

    if (getSubList) {
      this.getWorkerEmployeeList(worker);
    } else {
      this.finalizeLists(true);
    }
  }

  /**
   * Get worker employee list
   */
  private getWorkerEmployeeList(worker: IWorker): void {
    this.businessService
      .getWorkerSearchData(worker.workerNumber, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && response.data) {
            this.processEmployeeList(response.data);
          }
        },
        error: (error: any) => {          this.setMessage('ERROR', 'Error loading worker employee list');
        }
      });
  }

  /**
   * Process employee list
   */
  private processEmployeeList(data: any[]): void {
    this.employeeListGlobal = this.businessService.processWorkerReportInfo(data);
    this.finalizeLists(false);
  }

  /**
   * Finalize employee lists
   */
  private finalizeLists(updateWorkerList: boolean): void {
    if (updateWorkerList) {
      this.workerList = this.employeeListGlobal;
    }
    this.getEmployeesOnlytype2 = this.businessService.filterEmployeesWithReportingToMe(
      this.employeeListGlobal
    );
  }

  /**
   * Show worker data
   */
  showWorkerData(person: IWorker): void {
    this.currentWorker = person;
    this.isLoading = true;

    this.businessService
      .getWorkerSearchData(person.workerNumber, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.processWorkerReportInfo(person, response.data, false);
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error loading worker data');
        }
      });
  }

  /**
   * Get managers history
   */
  private getManagersHistory(workerId: number, limit: number, skip: number): void {
    this.isLoading = true;
    this.businessService
      .getManagersHistory(workerId, limit, skip, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          if (response && response.data) {
            this.managersHistoryList = this.businessService.sortManagerHistoryByEndDate(
              response.data
            );
          }
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error loading managers history');
        }
      });
  }

  /**
   * Toggle organization suffix edit mode
   */
  organizationSuffixEditModeToggle(workerNumber: string, organizationSuffixTx: string): void {
    this.organizationSuffixEditMode = !this.organizationSuffixEditMode;
    this.organizationSuffixModel = {
      workerNumber,
      organizationSuffixTx
    };
  }

  /**
   * Save organization suffix
   */
  saveOrgSuffix(workerId: number, organizationSuffixValue: string): void {
    this.isLoading = true;
    this.businessService
      .saveOrganizationSuffix(workerId, organizationSuffixValue, this.destroy$)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isLoading = false;
          this.organizationSuffixEditMode = false;
          this.setMessage('SUCCESS', 'Organization suffix saved successfully');
        },
        error: (error: any) => {
          this.isLoading = false;          this.setMessage('ERROR', 'Error saving organization suffix');
        }
      });
  }

  /**
   * Export data callback
   */
  exportDataCallback(url: string, fileName: string): void {
    window.open(url, '_blank');
  }

  /**
   * Export data callback for managers
   */
  exportDataCallbackHisMngrs(url: string, fileName: string): void {
    window.open(url, '_blank');
  }

  /**
   * Get worker EM Locator URL
   */
  getWorkerEMLocator(workerNumber: string): void {
    const emLocatorUrl = `/em-locator?workerNumber=${workerNumber}`;
    window.open(emLocatorUrl, '_blank');
  }

  /**
   * Get acronym EM Locator URL
   */
  getAccronymEMLocator(acronym: string): void {
    const emLocatorUrl = `/em-locator?acronym=${acronym}`;
    window.open(emLocatorUrl, '_blank');
  }

  /**
   * Handle sort change event from search results component
   */
  onSortChanged(event: { column: string; direction: string }): void {
    this.sortColumn = event.column;
    this.sortOrder = event.direction;
  }

  /**
   * Handle assignment request event from assign multiple component
   */
  onAssignmentRequested(event: { supervisor: any; workers: IWorker[]; reportType: string }): void {
    const validation = this.businessService.validateAssignmentRequest(
      event.supervisor,
      event.workers
    );

    if (!validation.valid) {
      this.setMessage('ERROR', validation.message || 'Invalid assignment request');
      return;
    }    // TODO: Implement assignment logic with business service
  }

  /**
   * Handle worker removed event from assign multiple component
   */
  onWorkerRemoved(index: number): void {  }

  /**
   * Handle search keyup event
   */
  onSearchKeyup(event: KeyboardEvent): void {
    const target = event.target as HTMLInputElement;
    this.searchSubject$.next(target.value);
  }

  /**
   * Toggle section visibility
   */
  toggleSection(section: string): void {
    switch (section) {
      case 'links':
        this.showLinksSection = !this.showLinksSection;
        break;
      case 'search':
        this.showSearchSection = !this.showSearchSection;
        break;
      case 'reporting':
        this.showReportingSection = !this.showReportingSection;
        break;
    }
  }

  /**
   * Set message for user feedback
   */
  private setMessage(returnCode: string, returnMessage: string, accessDenied?: boolean): void {
    this.showMessage = true;
    this.messageType = returnCode;
    this.messageText = returnMessage;
    this.accessDenied = accessDenied || false;
    this.hideMessageTimeout();
  }

  /**
   * Hide message after timeout
   */
  private hideMessageTimeout(): void {
    if (this.setTimeoutInterval) {
      clearTimeout(this.setTimeoutInterval);
    }
    this.setTimeoutInterval = setTimeout(() => {
      this.showMessage = false;
    }, 5000);
  }

  /**
   * Reset message timeout
   */
  resetTimeout(): void {
    if (this.setTimeoutInterval) {
      clearTimeout(this.setTimeoutInterval);
    }
  }
}
