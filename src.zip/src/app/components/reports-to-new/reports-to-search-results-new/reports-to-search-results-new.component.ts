import { Component, Input, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { IWorker } from '../Models/IWorkerDetails';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-reports-to-search-results-new',
  templateUrl: './reports-to-search-results-new.component.html',
  styleUrls: ['./reports-to-search-results-new.component.scss']
})
export class ReportsToSearchResultsNewComponent implements OnInit, OnDestroy {
  @Input() workers: IWorker[] = [];
  @Input() sortColumn: string = 'workerNumber';
  @Input() sortDirection: string = 'asc';
  @Input() total: number = 0;

  @Output() workerSelected = new EventEmitter<IWorker>();
  @Output() sortChanged = new EventEmitter<{ column: string; direction: string }>();

  private destroy$ = new Subject<void>();
  displayedColumns: string[] = [
    'workerNumber',
    'firstName',
    'lastName',
    'organization',
    'actions'
  ];

  constructor() {}

  ngOnInit(): void {  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Handle sort column click
   */
  onSort(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.sortChanged.emit({ column: this.sortColumn, direction: this.sortDirection });
  }

  /**
   * Get sort icon for column header
   */
  getSortIcon(column: string): string {
    if (this.sortColumn !== column) {
      return 'fa-sort';
    }
    return this.sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
  }

  /**
   * Select worker
   */
  selectWorker(worker: IWorker): void {
    this.workerSelected.emit(worker);
  }

  /**
   * Get worker display name
   */
  getWorkerName(worker: IWorker): string {
    return `${worker.lastName}, ${worker.firstName}`;
  }
}
