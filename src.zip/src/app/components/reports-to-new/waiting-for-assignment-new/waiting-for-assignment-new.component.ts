import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Assignment } from '../Models/IWorkerDetails';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-waiting-for-assignment-new',
  templateUrl: './waiting-for-assignment-new.component.html',
  styleUrls: ['./waiting-for-assignment-new.component.scss']
})
export class WaitingForAssignmentNewComponent implements OnInit, OnDestroy {
  @Input() assignments: Assignment[] = [];

  private destroy$ = new Subject<void>();
  displayedColumns: string[] = ['name', 'organization', 'newSupervisor', 'note'];

  constructor() {}

  ngOnInit(): void {  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Format date to readable format
   * @param date - Date string to format
   * @returns Formatted date string
   */
  formatDate(date: string): string {
    if (!date) return 'N/A';
    try {
      const dateObj = new Date(date);
      return dateObj.toLocaleDateString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
    } catch (error) {
      return 'N/A';
    }
  }

  /**
   * Get relationship type display
   * @param type - Relationship type code
   * @returns Relationship type display name
   */
  getRelationshipTypeDisplay(type: string): string {
    const relationshipMap: { [key: string]: string } = {
      'SUPERVISOR': 'Supervisor',
      'PAR': 'Performance Appraisal Rater',
      'TIMECARD': 'Timecard Approver'
    };
    return relationshipMap[type] || type;
  }
}
