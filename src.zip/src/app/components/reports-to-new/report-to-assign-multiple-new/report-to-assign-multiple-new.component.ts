import { Component, Input, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { IWorker, Worker } from '../Models/IWorkerDetails';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-report-to-assign-multiple-new',
  templateUrl: './report-to-assign-multiple-new.component.html',
  styleUrls: ['./report-to-assign-multiple-new.component.scss']
})
export class ReportToAssignMultipleNewComponent implements OnInit, OnDestroy {
  @Input() supervisor: Worker | null = null;
  @Input() usersToAssign: IWorker[] = [];
  @Input() reportType: string = 'SUPERVISOR';

  @Output() assignmentRequested = new EventEmitter<{ supervisor: Worker; workers: IWorker[]; reportType: string }>();
  @Output() workerRemoved = new EventEmitter<number>();

  private destroy$ = new Subject<void>();
  displayedColumns: string[] = ['workerNumber', 'firstName', 'lastName', 'organization', 'actions'];

  constructor() {}

  ngOnInit(): void {  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Get supervisor name
   */
  getSupervisorName(): string {
    if (!this.supervisor) return 'No Supervisor Selected';
    return `${this.supervisor.familyName}, ${this.supervisor.givenName}`;
  }

  /**
   * Get worker display name
   */
  getWorkerName(worker: IWorker): string {
    return `${worker.lastName}, ${worker.firstName}`;
  }

  /**
   * Remove worker from assignment list
   */
  removeWorker(index: number): void {
    this.usersToAssign.splice(index, 1);
    this.workerRemoved.emit(index);
  }

  /**
   * Assign all workers to supervisor
   */
  assignAll(): void {
    if (!this.supervisor || this.usersToAssign.length === 0) {      return;
    }
    this.assignmentRequested.emit({
      supervisor: this.supervisor,
      workers: this.usersToAssign,
      reportType: this.reportType
    });
  }

  /**
   * Get organization name
   */
  getOrganization(worker: IWorker): string {
    if (worker.organizationHistory && worker.organizationHistory.length > 0) {
      return worker.organizationHistory[0].organization?.shortName || 'N/A';
    }
    return 'N/A';
  }
}
