import { Injectable } from '@angular/core';
import { Assignment, RelationshipType, Worker, WorkerSearch } from '../Models/IWorkerDetails';
import { constants } from '../Models/MasterData';
import { IWorkerVM } from '../Models/IWorkerVM';

@Injectable({
  providedIn: 'root'
})
export class ReportsToUtilityService {
  constructor() {}

  /**
   * Get search term based on type
   */
  getSearchTerm(type: number, workerSearch: WorkerSearch): string {
    let searchTerm = '';
    if (type === 0) {
      searchTerm = workerSearch.employeeSearch;
    } else if (type === 1) {
      searchTerm = workerSearch.employeesUsersSearch;
    } else if (type === 2) {
      searchTerm = workerSearch.reportsToSearchInput;
    }
    return searchTerm ?? '';
  }

  /**
   * Send email notifications
   */
  sendEmail(emails: any[]): void {
    const emailPromises: any[] = [];
    // Email sending logic would be implemented here
  }

  /**
   * Build email message for supervisor and workers
   */
  private buildEmail(supervisor: any, reportType: any, workers: any): any[] {
    const toEmail = supervisor.emailAddress;
    let workerList = '';

    let emailInfo;
    let emailToWorkers = '';

    if (reportType.id === -1) {
      reportType.label = 'All Reports';
    }

    const emailMessages: any[] = [];
    const workerSubject = 'Your supervisor has changed for report type ' + reportType.label;
    workers.forEach((item: any) => {
      if (workerList) {
        workerList += ', ' + item.givenName + ' ' + item.familyName;
      } else {
        workerList = item.givenName + ' ' + item.familyName;
      }

      if (emailToWorkers) {
        emailToWorkers += '~' + item.emailAddress;
      } else {
        emailToWorkers = item.emailAddress;
      }
    });

    emailInfo = {
      toMail: emailToWorkers,
      fromEmail: emailToWorkers,
      subject: workerSubject,
      message: 'Your supervisor is now ' + supervisor.givenName + ' ' + supervisor.familyName,
    };

    if (this.hasAnEmailAddress(emailInfo.toMail)) {
      emailMessages.push(emailInfo);
    }

    const subject = 'Workers has been assigned to you for report type ' + reportType.label;
    let message = 'Workers:' + workerList;
    message += ' .  Reporting type is: ' + reportType.label;

    emailInfo = {
      toMail: toEmail,
      fromEmail: toEmail,
      subject: subject,
      message: message,
    };
    if (this.hasAnEmailAddress(emailInfo.toMail)) {
      emailMessages.push(emailInfo);
    }
    return emailMessages;
  }

  /**
   * Check if email address is valid
   */
  private hasAnEmailAddress(address: string): boolean {
    let returnvalue = false;
    if (address && address !== 'none@uspto.gov') returnvalue = true;
    return returnvalue;
  }

  /**
   * Get waiting for assignments with date range
   */
  getWaitingForAssignments(): Date {
    const currentTime = new Date();
    const startDateSearch = new Date().setDate(currentTime.getDate() - 14);
    return new Date(startDateSearch);
  }

  /**
   * Get formatted name from worker data
   */
  private getName(data: any): string {
    if (data.preferredFirstName) {
      return data.familyName + ', ' + data.preferredFirstName;
    } else {
      return data.familyName + ', ' + data.givenName;
    }
  }

  /**
   * Get primary organization from organization history
   */
  getPrimaryOrganization(organizationHistory: any[]): string {
    const organization: any = organizationHistory.filter((org) => org.primaryOrganizationIndicator)[0];
    let acronym = '';
    if (organization && organization.organization) {
      const org = organization.organization;
      if (org.businessAreaCode && org.shortName) {
        return org.businessAreaCode + '/' + org.shortName;
      } else if (org.shortName) {
        return org.shortName;
      } else if (org.businessAreaCode) {
        return org.businessAreaCode;
      }
    }
    return acronym;
  }

  /**
   * Build waiting for assignment rows
   */
  buildWaitingForAssignmentRows(rows: any[]): Assignment[] {
    const outputRows: Assignment[] = [];
    let rowOutput: any = {};
    rows.forEach((aRow: any) => {
      rowOutput = {
        name: this.getName(aRow.worker),
        organization: this.getPrimaryOrganization(aRow.worker.organizationHistory),
        newSupervisor: '',
        note: '',
        selected: false,
      };
      if (aRow.examiner) {
        rowOutput.newSupervisor = this.getName(aRow.examiner);
      }
      if (aRow.numberOfExaminersFound === 0) {
        rowOutput.note = 'No data available in table';
      } else if (aRow.numberOfExaminersFound === 1) {
        rowOutput.selected = true;
        rowOutput.note = 'Single SPE - Assigned to that SPE';
      } else if (aRow.numberOfExaminersFound > 1) {
        rowOutput.selected = true;
        rowOutput.note = 'Multiple SPEs - Assigned to highest SPE No.';
      }
      rowOutput.object = aRow;
      outputRows.push(rowOutput);
    });
    return outputRows;
  }

  /**
   * Build assignment object for API call
   */
  buildAssignment(supervisor: any, worker: any, reportType: number): any {
    const anAssignment = {
      primaryIn: true,
      baseWorker: {
        workerId: worker == undefined ? 0 : worker?.workerId,
      },
      relatedWorker: {
        workerId: supervisor.workerId,
      },
      relationshipSummary: {
        id: reportType,
        primaryIn: true,
      },
      lifecycle: {
        beginDate: new Date().toISOString(),
      },
    };
    return anAssignment;
  }

  /**
   * Get report type object by value
   */
  private getReportTypeObject(reportType: string, reportToTypes: RelationshipType[]): any {
    let reportTypeObject: RelationshipType | null = null;
    reportToTypes.forEach((type) => {
      if (type.value && type.value.toUpperCase() === reportType.toUpperCase()) {
        reportTypeObject = type;
      }
    });
    return reportTypeObject;
  }

  /**
   * Calculate difference in days between two dates
   */
  getDifferenceInDays(startDate: any, endDate: any): number {
    const ONE_DAY = 1000 * 3600 * 24;
    const start = new Date(startDate);
    const end = new Date(endDate);
    const timeDiff = Math.abs(end.getTime() - start.getTime());
    const difference = Math.ceil(timeDiff / ONE_DAY);
    return difference;
  }

  /**
   * Get filtered report type data
   */
  getReportTypeFilterData(results: any[]): any[] {
    const relationshipTypes: any[] = ['SUPERVISOR', 'PAR', 'TIMECARD'];
    const reportTypes: any[] = [];
    results.forEach((result) => {
      const index = relationshipTypes.indexOf(result.value);
      if (index >= 0) {
        reportTypes.push({ id: result.id, label: result.value });
      }
    });
    reportTypes.push({ label: 'Set All', id: -1 });
    return reportTypes;
  }

  /**
   * Check for duplicate entries in array
   */
  checkDuplicate(emp: any[], obj: any): boolean {
    const seen = new Set();
    let hasduplicate = false;
    emp.forEach((item: any) => {
      const str = JSON.stringify(item);
      if (!seen.has(str)) {
        seen.add(str);
      } else {
        hasduplicate = true;
      }
    });
    return hasduplicate;
  }

  /**
   * Add days to current date
   */
  addDays(addDay: number): Date {
    const today: Date = new Date();
    today.setDate(today.getDate() + addDay);
    return today;
  }

  /**
   * Multiple text search with pagination
   */
  multipleTextSearch(
    text: string,
    includeInactive: boolean,
    flag: string,
    pageName: string
  ): number {
    let defaultLimit = 100;
    if (pageName == 'reportsToPage') {
      defaultLimit = 200;
    }
    if (pageName == 'tableDataPage') {
      defaultLimit = 100000;
    }
    return defaultLimit;
  }

  /**
   * Initialize worker view model with default values
   */
  initWorkerVM(): IWorkerVM {
    return {
      isPrimary: false,
      limit: 10,
      supervisorData: null,
      tableTitle: '',
      skip: 0,
      total: 0,
      editable: false,
      originalList: [],
      tableList: [],
      workerList: [],
      employeeSearch: '',
      primaryWorker: null,
      usersToAssign: [],
      workerNumber: '',
      titles: [
        'All Unassigned Employees',
        'Change Reporting Assignment for Multiple Individuals',
        'Waiting For Assignments',
      ],
      links: null,
      primaryWorkerId: 0,
      employeesUsersSearch: '',
      reportsToSearchInput: '',
      screen: 0,
      employeeList: [],
      reportsToType: '',
      showValueOrgSuffix: '',
      unassignedPWorkers: false,
      orgSuffixUpdateValue: '',
      moduleName: 'ReportsTo',
      viewName: 'ReportsTo',
      appTitle: 'Reports To',
      sortDirection: 'asc',
      sortColumn: 'name',
      showPrimary: true,
      showPrimarySearch: false,
      getEmployeesOnlytype2: [],
      subListSupervisorIndicator: false,
      showWait: false,
      showWaitUnassignedExport: false,
      accronym: '',
      emLocatorurl: '',
      exportWorkerId: '',
      parReportTypeObject: '',
      timecardReportTypeObject: '',
      defaultUpdateOfPar: false,
      defaultUpdateOfTimecard: false,
      employeeListGlobal: [],
      managersHistoryList: [],
      noWorkerFoundMsg: 'No worker found',
      noWorkersFound: false,
      editViewNumber: 0,
      selectOptions: [
        { text: '100', value: 100 },
        { text: '250', value: 250 },
      ],
      person: '',
      setTimeoutInterval: null,
      includeAttrition: false,
      supervisor: null,
      supervisorName: '',
      userInfo: [],
    };
  }
}
