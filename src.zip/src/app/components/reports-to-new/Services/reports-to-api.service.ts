import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { HttpService } from 'src/app/services/http.service';

/**
 * ReportsToAPIService
 * Centralized service for all Reports To Management API calls
 * Aligned with ReportserviceService API paths for consistency
 */
@Injectable({
  providedIn: 'root'
})
export class ReportsToAPIService {
  constructor(private httpservice: HttpService) {}

  /**
   * Get current user information
   * @returns Observable with user info response
   */
  getUserInfo(): Observable<any> {
    const url = '/who-am-i';
    return this.httpservice.get(url);
  }

  /**
   * Get system parameters
   * @returns Observable with parameters response
   */
  getParameters(): Observable<any> {
    const url = '/parameters';
    return this.httpservice.get(url);
  }

  /**
   * Get report types (relationship types)
   * @param includeInactive - Whether to include inactive report types
   * @returns Observable with report types response
   */
  getReportTypes(includeInactive: boolean): Observable<any> {
    const url = '/references/worker-relationship-types?includeInactive=' + includeInactive;
    return this.httpservice.get(url);
  }

  /**
   * Search for workers by worker number
   * @param text - Worker number or name to search for
   * @param includeInactive - Whether to include inactive workers
   * @param flag - Search flag
   * @param defaultLimit - Limit for results
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @returns Observable with search results
   */
  searchWorkerNumber(
    text: string,
    includeInactive: boolean,
    flag: boolean = false,
    defaultLimit: number = 0,
    sortColumn: string = '',
    sortOrder: string = ''
  ): Observable<any> {
    let geturl = '/worker?workerNumber=' + text + '&includeInactive=' + !!includeInactive;
    if (flag) {
      geturl +=
        '&flag=' + flag + '&limit=' + defaultLimit + "&sortColumn='familyName1'+&sortOrder:'asc'";
    }
    return this.httpservice.get(geturl);
  }

  /**
   * Get workers by worker number
   * @param flag - Search flag
   * @param includeInactive - Whether to include inactive workers
   * @param limit - Number of records to retrieve
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @param workerNumber - Worker number to search for
   * @returns Observable with workers
   */
  getworkers(
    flag: boolean,
    includeInactive: boolean,
    limit: number,
    sortColumn: string,
    sortOrder: string,
    workerNumber: string
  ): Observable<any> {
    const url = `/workers?flag=${flag}&includeInactive=${includeInactive}&limit=${limit}&sortColumn=${sortColumn}&sortOrder=${sortOrder}&workerNumber=${workerNumber}`;
    return this.httpservice.get(url);
  }

  /**
   * Get worker information by worker number
   * @param workerNumber - Worker number to retrieve
   * @param includeInactive - Whether to include inactive data
   * @returns Observable with worker data
   */
  getWorkerByWorkerNumber(workerNumber: string, includeInactive: boolean): Observable<any> {
    const url = `/workers?workerNumber=${workerNumber}&includeInactive=${includeInactive}`;
    return this.httpservice.get(url);
  }

  /**
   * Get workers relationships
   * @param associatedToReportingWorkerId - ID of the worker
   * @param includeInactive - Whether to include inactive relationships
   * @returns Observable with relationships
   */
  getWorkersRelationships(
    associatedToReportingWorkerId: string,
    includeInactive: boolean
  ): Observable<any> {
    const url = '/workers-relationships?workerId=' + associatedToReportingWorkerId;
    return this.httpservice.get(url);
  }

  /**
   * Get supervisor workers relationships list
   * @param id - ID of the supervisor
   * @param includeInactive - Whether to include inactive workers
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @returns Observable with supervisor workers list
   */
  getSupervisorWorkersRelationshipsList(
    id: number,
    includeInactive: boolean,
    sortColumn: any = null,
    sortOrder: any = null
  ): Observable<any> {
    let url: string =
      '/workers-relationships?associatedToReportingWorkerId=' +
      id +
      '&includeInactive=' +
      !!includeInactive;
    if (sortColumn) {
      url = url + '&sortColumn=' + sortColumn + '&sortOrder=' + sortOrder;
    }
    return this.httpservice.get(url);
  }

  /**
   * Get supervisor list for a worker
   * @param id - ID of the worker
   * @param includeInactive - Whether to include inactive supervisors
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @returns Observable with supervisor list
   */
  getSupervisorList(
    id: string,
    includeInactive: boolean,
    sortColumn: string,
    sortOrder: string
  ): Observable<any> {
    const url = `/supervisors?workerId=${id}&includeInactive=${includeInactive}&sortColumn=${sortColumn}&sortOrder=${sortOrder}`;
    return this.httpservice.get(url);
  }

  /**
   * Get manager history for a worker
   * @param relatedWorkerId - ID of the worker
   * @param limit - Number of records to retrieve
   * @param skip - Number of records to skip (pagination)
   * @returns Observable with manager history
   */
  getManagersHistory(relatedWorkerId: number, limit: number, skip: number): Observable<any> {
    const url =
      '/manager-history/' +
      relatedWorkerId +
      '?limit=' +
      limit +
      '&skip=' +
      skip +
      '&notRelated=true&isContractor=false';
    return this.httpservice.get(url);
  }

  /**
   * Save organization suffix for a worker
   * @param workerId - ID of the worker
   * @param organizationSuffixValue - New organization suffix value
   * @returns Observable with save response
   */
  saveOrganizationSuffix(
    workerId: number,
    organizationSuffixValue: string
  ): Observable<any> {
    const processItem = [
      {
        workerId: workerId,
        suffixTx: organizationSuffixValue,
        audit: {
          createdDate: '',
          createdUser: '',
          lastModifiedDate: '',
          lastModifiedUser: '',
          lockControlNumber: '',
        },
      },
    ];
    const url = `/worker-organization-suffix`;
    return this.httpservice.post(url, processItem);
  }

  /**
   * Get worker organization suffix
   * @param workerId - ID of the worker
   * @returns Observable with organization suffix data
   */
  getWorkerOrgSuffix(workerId: number): Observable<any> {
    const url = '/worker-organization-suffix?workerId=' + workerId;
    return this.httpservice.get(url);
  }

  /**
   * Remove an assignment relationship
   * @param relationshipId - ID of the relationship to remove
   * @returns Observable with removal response
   */
  removeAssignment(relationshipId: any): Observable<any> {
    const url = '/workers-relationships/' + relationshipId;
    return this.httpservice.delete(url);
  }

  /**
   * Get generic data from URL
   * @param url - URL to fetch data from
   * @returns Observable with data
   */
  getData(url: string): Observable<any> {
    return this.httpservice.get(url);
  }

  /**
   * Get generic data content
   * @param url - URL to fetch data from
   * @returns Observable with data content
   */
  getDataContent(url: string): Observable<any> {
    return this.httpservice.get(url);
  }

  /**
   * Get worker data with params
   * @param url - URL to fetch data from
   * @param params - HTTP parameters
   * @returns Observable with worker data
   */
  getworkerData(url: string, params: HttpParams): Observable<any> {
    return this.httpservice.getData(url, params);
  }

  /**
   * Get binding data
   * @param url - URL to fetch data from
   * @returns Observable with binding data
   */
  getBindingData(url: string): Observable<any> {
    return this.httpservice.get(url);
  }
}
