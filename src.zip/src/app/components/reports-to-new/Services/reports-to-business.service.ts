import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
  IWorker,
  Worker,
  Assignment,
  RelationshipType
} from '../Models/IWorkerDetails';
import { ReportsToAPIService } from './reports-to-api.service';
import { ReportsToUtilityService } from './reports-to-utility.service';

/**
 * ReportsToBusinessService
 * Handles all business logic for Reports To Management
 * Separates business logic from component presentation logic
 */
@Injectable({
  providedIn: 'root'
})
export class ReportsToBusinessService {
  constructor(
    private apiService: ReportsToAPIService,
    private utilityService: ReportsToUtilityService
  ) {}

  /**
   * Initialize a worker object with default values
   * @returns Initialized IWorker object
   */
  initializeWorker(): IWorker {
    return {
      workerId: 0,
      workerNumber: '',
      firstName: '',
      lastName: '',
      middleName: '',
      organizationHistory: [],
      reportingTo: [],
      reportingToMe: [],
      waitingForAssignment: [],
      managerHistory: []
    };
  }

  /**
   * Load user information
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with user info response
   */
  loadUserInfo(destroy$: Subject<void>): Observable<any> {
    return this.apiService.getUserInfo();
  }

  /**
   * Load system parameters and extract business area code
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with parameters response
   */
  loadParameters(destroy$: Subject<void>): Observable<any> {
    return this.apiService.getParameters();
  }

  /**
   * Extract business area code from parameters response
   * @param response - Parameters response object
   * @returns Business area code string
   */
  extractBusinessAreaCode(response: any): string {
    if (response && response.data && response.data.results) {
      for (const param of response.data.results) {
        if (param.parameterName === 'BUSINESS_AREA_CODE') {
          return param.parameterValue;
        }
      }
    }
    return '';
  }

  /**
   * Load report types and set default selected type
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with report types response
   */
  loadReportTypes(destroy$: Subject<void>): Observable<any> {
    return this.apiService.getReportTypes(false);
  }

  /**
   * Get default selected report type from list
   * @param reportTypes - Array of report types
   * @returns Default report type ID
   */
  getDefaultReportType(reportTypes: RelationshipType[]): number {
    if (reportTypes && reportTypes.length > 0) {
      return reportTypes[0].relationshipTypeId || reportTypes[0].id || 1;
    }
    return 1;
  }

  /**
   * Search for workers by search term
   * @param searchTerm - Worker number or name to search
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with search results
   */
  searchWorkers(searchTerm: string, destroy$: Subject<void>): Observable<any> {
    return this.apiService.searchWorkerNumber(searchTerm, false);
  }

  /**
   * Process search results and map to IWorker objects
   * @param results - Raw search results
   * @returns Mapped IWorker array
   */
  processSearchResults(results: any[]): IWorker[] {
    return results.map((result: any) => ({
      workerId: result.workerId,
      workerNumber: result.workerNumber,
      firstName: result.firstName,
      lastName: result.lastName,
      middleName: result.middleName || '',
      organizationHistory: result.organizationHistory || [],
      reportingTo: [],
      reportingToMe: [],
      waitingForAssignment: [],
      managerHistory: []
    }));
  }

  /**
   * Get unassigned workers for current supervisor
   * @param workerId - Supervisor worker ID
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with unassigned workers
   */
  getUnassignedWorkers(
    workerId: number,
    sortColumn: string,
    sortOrder: string,
    destroy$: Subject<void>
  ): Observable<any> {
    const normalizedColumn = this.normalizeSortColumn(sortColumn, false);
    return this.apiService.getSupervisorList(
      String(workerId),
      false,
      normalizedColumn,
      sortOrder
    );
  }

  /**
   * Get unassigned P (probationary) workers for current supervisor
   * @param workerId - Supervisor worker ID
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with unassigned P workers
   */
  getUnassignedPWorkers(
    workerId: number,
    sortColumn: string,
    sortOrder: string,
    destroy$: Subject<void>
  ): Observable<any> {
    const normalizedColumn = this.normalizeSortColumn(sortColumn, true);
    return this.apiService.getSupervisorList(
      String(workerId),
      false,
      normalizedColumn,
      sortOrder
    );
  }

  /**
   * Normalize sort column name for API
   * @param sortColumn - Column name from UI
   * @param isPWorkers - Whether sorting P workers
   * @returns Normalized column name for API
   */
  normalizeSortColumn(sortColumn: string, isPWorkers: boolean = false): string {
    const columnMap: { [key: string]: string } = {
      workerNumber: 'workerNumber',
      firstName: 'firstName',
      lastName: 'lastName',
      organizationName: 'organizationName'
    };
    return columnMap[sortColumn] || 'workerNumber';
  }

  /**
   * Process worker list and initialize reporting values
   * @param workerList - Raw worker list from API
   * @returns Processed worker list with initialized values
   */
  processWorkerList(workerList: any[]): any[] {
    return workerList.map((worker: any) => {
      this.initializeReportingValues(worker);
      return worker;
    });
  }

  /**
   * Initialize reporting arrays for a worker
   * @param worker - Worker object to initialize
   */
  private initializeReportingValues(worker: any): void {
    if (!worker.reportingTo) {
      worker.reportingTo = [];
    }
    if (!worker.reportingToMe) {
      worker.reportingToMe = [];
    }
    if (!worker.waitingForAssignment) {
      worker.waitingForAssignment = [];
    }
  }

  /**
   * Map relationship data to worker object
   * @param worker - Worker object to update
   * @param row - Relationship data row
   */
  mapRelationshipToWorker(worker: any, row: any): void {
    const relationshipValue = row.relationshipTypeId;

    switch (relationshipValue) {
      case 'SUPERVISOR':
        if (!worker.reportingTo) worker.reportingTo = [];
        worker.reportingTo.push(row);
        break;
      case 'PAR':
        if (!worker.reportingToMe) worker.reportingToMe = [];
        worker.reportingToMe.push(row);
        break;
      case 'TIMECARD':
        if (!worker.reportingToMe) worker.reportingToMe = [];
        worker.reportingToMe.push(row);
        break;
    }
  }

  /**
   * Get waiting for assignments
   * @param workerNumber - Worker number to get assignments for
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with waiting assignments
   */
  getWaitingForAssignments(
    workerNumber: string,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.getWorkerByWorkerNumber(workerNumber, false);
  }

  /**
   * Process waiting for assignments response
   * @param response - API response
   * @returns Processed assignment list
   */
  processWaitingForAssignments(response: any): Assignment[] {
    if (response && response.data) {
      return this.utilityService.buildWaitingForAssignmentRows(response.data);
    }
    return [];
  }

  /**
   * Get workers for supervisor with relationship type
   * @param workerId - Supervisor worker ID
   * @param relationshipType - Type of relationship (SUPERVISOR, PAR, TIMECARD)
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with workers
   */
  getSupervisorWorkers(
    workerId: number,
    relationshipType: string,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.getSupervisorWorkersRelationshipsList(
      workerId,
      false,
      relationshipType
    );
  }

  /**
   * Get all workers for supervisor (no relationship filter)
   * @param workerId - Supervisor worker ID
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with all workers
   */
  getAllSupervisorWorkers(
    workerId: number,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.getSupervisorWorkersRelationshipsList(
      workerId,
      false,
      ''
    );
  }

  /**
   * Get worker search data
   * @param workerNumber - Worker number to search
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with worker data
   */
  getWorkerSearchData(
    workerNumber: string,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.getWorkerByWorkerNumber(workerNumber, false);
  }

  /**
   * Process worker report info
   * @param data - Worker data from API
   * @returns Processed worker list
   */
  processWorkerReportInfo(data: any[]): any[] {
    const employeeList: any[] = [];
    if (data) {
      data.forEach((row: any) => {
        this.formatWorkerDisplay(row);
        this.ensureReportingValuesSet(row);
        employeeList.push(row);
      });
    }
    return employeeList;
  }

  /**
   * Format worker display name
   * @param worker - Worker object to format
   */
  private formatWorkerDisplay(worker: any): void {
    worker.displayName = `${worker.lastName}, ${worker.firstName}`;
    if (worker.middleName) {
      worker.displayName += ` ${worker.middleName}`;
    }
  }

  /**
   * Ensure reporting arrays are initialized
   * @param worker - Worker object to check
   */
  private ensureReportingValuesSet(worker: any): void {
    if (!worker.reportingTo) {
      worker.reportingTo = [];
    }
    if (!worker.reportingToMe) {
      worker.reportingToMe = [];
    }
  }

  /**
   * Filter employees to get only those with reportingToMe
   * @param employees - Full employee list
   * @returns Filtered employee list
   */
  filterEmployeesWithReportingToMe(employees: any[]): any[] {
    return employees.filter(
      (emp: any) => emp.reportingToMe && emp.reportingToMe.length > 0
    );
  }

  /**
   * Get managers history for a worker
   * @param workerId - Worker ID
   * @param limit - Number of records
   * @param skip - Skip count for pagination
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with manager history
   */
  getManagersHistory(
    workerId: number,
    limit: number,
    skip: number,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.getManagersHistory(workerId, limit, skip);
  }

  /**
   * Sort manager history by end date (descending)
   * @param data - Manager history data
   * @returns Sorted assignment list
   */
  sortManagerHistoryByEndDate(data: any[]): Assignment[] {
    return data.sort((a: any, b: any) => {
      const dateA = a.endDate ? new Date(a.endDate).getTime() : 0;
      const dateB = b.endDate ? new Date(b.endDate).getTime() : 0;
      return dateB - dateA;
    });
  }

  /**
   * Save organization suffix for a worker
   * @param workerId - Worker ID
   * @param organizationSuffixValue - New suffix value
   * @param destroy$ - Subject for unsubscribe management
   * @returns Observable with save response
   */
  saveOrganizationSuffix(
    workerId: number,
    organizationSuffixValue: string,
    destroy$: Subject<void>
  ): Observable<any> {
    return this.apiService.saveOrganizationSuffix(
      workerId,
      organizationSuffixValue
    );
  }

  /**
   * Get search term for relationship type
   * @param type - Relationship type code (1=SUPERVISOR, 2=PAR, 3=TIMECARD)
   * @returns Relationship type string
   */
  getSearchTermForRelationshipType(type: number): string {
    switch (type) {
      case 1:
        return 'SUPERVISOR';
      case 2:
        return 'PAR';
      case 3:
        return 'TIMECARD';
      default:
        return '';
    }
  }

  /**
   * Check if worker is duplicate in list
   * @param list - Worker list to check
   * @param worker - Worker to check for duplication
   * @returns True if duplicate exists
   */
  checkDuplicate(list: any[], worker: any): boolean {
    return this.utilityService.checkDuplicate(list, worker);
  }

  /**
   * Format date to MM/DD/YYYY format
   * @param date - Date to format
   * @returns Formatted date string
   */
  formatDate(date: Date): string {
    if (!date) return '';
    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const year = d.getFullYear();
    return `${month}/${day}/${year}`;
  }

  /**
   * Sort employee list by column and order
   * @param employees - Employee list to sort
   * @param sortColumn - Column to sort by
   * @param sortOrder - Sort order (asc/desc)
   * @returns Sorted employee list
   */
  sortEmployeeList(
    employees: IWorker[],
    sortColumn: string,
    sortOrder: string
  ): IWorker[] {
    return [...employees].sort((a, b) => {
      const aVal = a[sortColumn as keyof IWorker] || '';
      const bVal = b[sortColumn as keyof IWorker] || '';
      const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }

  /**
   * Validate assignment request
   * @param supervisor - Supervisor object
   * @param workers - Workers array
   * @returns Validation result with error message if invalid
   */
  validateAssignmentRequest(
    supervisor: any,
    workers: IWorker[]
  ): { valid: boolean; message?: string } {
    if (!supervisor) {
      return { valid: false, message: 'Please select a supervisor' };
    }
    if (!workers || workers.length === 0) {
      return { valid: false, message: 'Please select at least one worker' };
    }
    return { valid: true };
  }

  /**
   * Build assignment payload for API
   * @param supervisor - Supervisor object
   * @param workers - Workers to assign
   * @param reportType - Report type
   * @param notification - Whether to send notification
   * @returns Assignment payload
   */
  buildAssignmentPayload(
    supervisor: any,
    workers: IWorker[],
    reportType: string,
    notification: boolean
  ): any {
    return {
      supervisor,
      workers,
      reportType,
      notification
    };
  }

  /**
   * Process assignment response
   * @param response - API response
   * @returns Processed result
   */
  processAssignmentResponse(response: any): any {
    return {
      success: response && response.returnCode === 'SUCCESS',
      message: response?.returnMessage || 'Assignment processed',
      data: response?.data
    };
  }
}
