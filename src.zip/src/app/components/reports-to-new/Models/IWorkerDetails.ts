import { AssignmentSelectComponent } from '../../worker-management/add-worker/assignment-select/assignment-select.component';

interface IWorkerDetails {
  limit: number;
  supervisorData: string;
  skip: number;
  primaryWorkerId: string;
  reportsToType: string;
  showValueOrgSuffix: string;
  unassignedPWorkers: boolean;
  orgSuffixUpdateValue: string;
  moduleName: string;
  viewName: string;
  appTitle: string;
  sortDirection: string;
  sortColumn: string;
  showPrimary: boolean;
  showPrimarySearch: boolean;
  getEmployeesOnlytype2: any;
  subListSupervisorIndicator: boolean;
  showWait: boolean;
  showWaitUnassignedExport: boolean;
  accronym: string;
  emLocatorurl: string;
  exportWorkerId: string;
  parReportTypeObject: string;
  timecardReportTypeObject: string;
  defaultUpdateOfPar: boolean;
  defaultUpdateOfTimecard: boolean;
  employeeListGlobal: any;
  managersHistoryList: any;
  noWorkerFoundMsg: string;
  editViewNumber: number;
  person: string;
  setTimeoutInterval: any;
}
export interface WorkerRoot {
  meta: Meta;
  results: Worker[];
}

export interface Meta {
  total: number;
  skip: any;
  limit: number;
}
export interface EmailInfo {
  toMail: string;
  fromEmail: string;
  subject: string;
  message: string;
}
export interface Worker {
  workerId: number;
  workerNumber: string;
  familyName: string;
  givenName: string;
  middleName: any;
  preferredFirstName: string;
  loginId: string;
  emailAddress: string;
  patronId: any;
  positionOrganizationListing: string;
  activeEmploymentIndicator: boolean;
  supervisorIndicator: boolean;
  otherFederalAgencyIndicator: boolean;
  publishOrganizationDirectoryIndicator: boolean;
  internetDisplayIndicator: boolean;
  intranetDisplayIndicator: boolean;
  hotelDisplayIndicator: boolean;
  rehireIndicator: boolean;
  notes: any;
  serviceAccountIndicator: any;
  jobClass: JobClass;
  directoryTitleType: any;
  employmentType: EmploymentType;
  contractorFirm: any;
  leaveAccrual: LeaveAccrual;
  appointmentType: AppointmentType;
  occupationalSeries: OccupationalSeries;
  occupationalSeriesTitle: OccupationalSeriesTitle;
  bargainUnitType: BargainUnitType;
  positionSensitivity: PositionSensitivity;
  teleworkProgram: any;
  standardTourOfDuty: StandardTourOfDuty;
  communicationHistory: any[];
  organizationHistory: OrganizationHistory[];
  auxiliaryRoleSummary: any[];
  secure: any;
  capabilities: any[];
  payPlan: PayPlan;
  workerOrganizationSufix: WorkerOrganizationSufix;
  workerTrademarkFlag: any;
  lifecycle: Lifecycle2;
  audit: Audit2;
  defaultReporting: any;
}

export interface JobClass {
  id: number;
  value: string;
  description: string;
}

export interface EmploymentType {
  id: number;
  value: string;
  description: string;
}

export interface LeaveAccrual {
  id: number;
  value: string;
  description: string;
}

export interface AppointmentType {
  id: number;
  value: string;
  description: string;
  shortDescription: string;
}

export interface OccupationalSeries {
  id: number;
  value: string;
  description: string;
}

export interface OccupationalSeriesTitle {
  occupationalSeriesTitleId: number;
  value: string;
  description: string;
}

export interface BargainUnitType {
  id: number;
  value: string;
  description: string;
}

export interface PositionSensitivity {
  id: number;
  value: string;
  description: string;
}

export interface StandardTourOfDuty {
  id: number;
  value: string;
  description: string;
}

export interface OrganizationHistory {
  workerOrganizationId: number;
  primaryOrganizationIndicator: boolean;
  organization: Organization;
  organizationStatusCurrent: string;
  lifecycle: Lifecycle;
  locationSummary: LocationSummary[];
  reportRoleList: any[];
  workerOrganizationQueue: any;
}

export interface Organization {
  id: number;
  shortName: string;
  name: string;
  businessAreaCode: string;
}

export interface Lifecycle {
  beginDate: string;
}

export interface LocationSummary {
  workerAssignmentId: number;
  assignmentStatusCurrent: string;
  locationSummary: LocationSummary2;
  primaryLocationIn: boolean;
  suffixId: number;
}

export interface LocationSummary2 {
  locationId: number;
  corridorId: string;
  roomId: string;
  suiteId: string;
  zoneId: string;
  building: Building;
}

export interface Building {
  buildingFloorId: number;
  floorNumber: string;
  buildingId: number;
  code: string;
  name: string;
}

export interface PayPlan {
  employeeGradeId: number;
  employeeGradeStepId: number;
  payPlanGradeId: number;
  currentGrade: CurrentGrade;
  currentStep: CurrentStep;
  currentPayPlan: CurrentPayPlan;
  gradeLifecycle: GradeLifecycle;
  stepLifecycle: StepLifecycle;
  gradeAudit: GradeAudit;
  stepAudit: StepAudit;
}

export interface CurrentGrade {
  id: number;
  value: string;
  description: string;
}

export interface CurrentStep {
  id: number;
  value: string;
  description: string;
}

export interface CurrentPayPlan {
  id: number;
  value: string;
  description: string;
}

export interface GradeLifecycle {
  beginDate: string;
}

export interface StepLifecycle {
  beginDate: string;
}

export interface GradeAudit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface StepAudit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface WorkerOrganizationSufix {
  workerOrganizationSufixId: number;
  workerId: number;
  sufixTx: any;
  audit: Audit;
}

export interface Audit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface Lifecycle2 {
  beginDate: string;
}

export interface Audit2 {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}

export interface WorkerSearch {
  reportsToSearchInput: string;
  employeeSearch: string;
  employeesUsersSearch: string;
}

export interface RelationshipType {
  id?: number;
  relationshipTypeId?: number;
  value: string;
  description: string;
  lifecycle?: Lifecycle;
  audit?: Audit;
}

export interface Assignment {
  name: string;
  organization: string;
  newSupervisor: string;
  note: string;
  selected: boolean;
  object?: any;
}
export interface ColumnDefinition {
  key: string;
  header: string;
  editable: boolean;
  type?: string;
  visible?: boolean;
  popup?: boolean;
}
export interface IReportTo {
  id: string;
  name: string;
  workerNumber: string;
  defaultReporting: string;
  organization: string;
  organizationSuffixTx: string;
  employeeNumber: string;
  appraisalsReporting: string;
  timecardReporting: string;
  prefix: string;
  parReporting: string;
}
export interface IWaitingAssignment {
  organization: string;
  name: string;
  newSupervisor: string;
  note: string;
  assign: boolean;
}
export interface IWorker {
  id?: number;
  name?: string;
  role?: string;
  givenName?: string;
  workerNumber: string;
  organization?: string;
  defaultReporting?: any;
  parReporting?: any;
  parReportingId?: any;
  timecardReporting?: any;
  organizationHistory: any;
  familyName?: string;
  preferredFirstName?: string;
  organizationSuffixTx?: string;
  workerOrganizationSufix?: any;
  workerId: number;
  defaultReportingId?: string;
  defaultReportingWorkerNumber?: string;
  defaultReportingWorkerId?: string;
  employeeNumber?: string;
  appraisalsReporting?: string;
  prefix?: string;
  editable?: boolean;
  isVisible?: boolean;
  timecardReportingId?: string;
  emailAddress?: string;
  activeEmploymentIndicator?: boolean;
  firstName?: string;
  lastName?: string;
  middleName?: string;
  reportingTo?: any[];
  reportingToMe?: any[];
  waitingForAssignment?: any[];
  managerHistory?: any[];
  displayName?: string;
}
