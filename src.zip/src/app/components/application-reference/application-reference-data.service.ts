import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ApplicationReferenceDataService {
  private readonly referenceDataList = [
    { code: 'grades', description: 'Grade Number', maxValLength: 2, maxDescLength: 200 },
    {
      code: 'tour-of-duties',
      description: 'Worker Tour Of Duty',
      maxValLength: 2,
      maxDescLength: 200,
    },
    {
      code: 'directory-title-types',
      description: 'Worker Phone Title Code',
      maxValLength: 15,
      maxDescLength: 100,
    },
    { code: 'leave-accruals', description: 'Leave Accrual', maxValLength: 1, maxDescLength: 200 },
    {
      code: 'bargain-unit-types',
      description: 'Business Code',
      maxValLength: 4,
      maxDescLength: 200,
    },
    { code: 'steps', description: 'Grade Step Number', maxValLength: 2, maxDescLength: 200 },
    {
      code: 'job-classes',
      description: 'Worker Job Class Code',
      maxValLength: 8,
      maxDescLength: 100,
    },
    {
      default: true,
      code: 'contractor-firms',
      description: 'Contractor Firm Name',
      maxValLength: 250,
      maxDescLength: 1000,
    },
    {
      code: 'employment-types',
      description: 'The Employment Type',
      maxValLength: 1,
      maxDescLength: 200,
    },
    {
      code: 'pay-plans',
      description: 'Grade Federal Appointment Type',
      maxValLength: 3,
      maxDescLength: 100,
    },
    {
      code: 'position-sensitivities',
      description: 'Position Sensitivity Code',
      maxValLength: 2,
      maxDescLength: 200,
    },
    {
      code: 'telcom-address-types',
      description: 'Communication Type',
      maxValLength: 1,
      maxDescLength: 30,
    },
    {
      code: 'search-purposes',
      description: 'TC Search Assistance Role',
      maxValLength: 20,
      maxDescLength: 200,
    },
    {
      code: 'signatory-authorities',
      description: 'Worker Examiner Authority Code (Sig Level)',
      maxValLength: 10,
      maxDescLength: 30,
    },
    {
      code: 'telework-programs',
      description: 'Telework Programs',
      maxValLength: 20,
      maxDescLength: 1000,
    },
    {
      code: 'location-purposes',
      description: 'Location Purpose',
      maxValLength: 2,
      maxDescLength: 100,
    },
    {
      code: 'worker-relationship-types',
      description: 'Worker Relationship Types',
      maxValLength: 10,
      maxDescLength: 50,
    },
    { code: 'report-roles', description: 'Report Role', maxValLength: 6, maxDescLength: 64 },
    {
      code: 'alternate-coordinators',
      description: 'Alternative Coordinator',
      maxValLength: 129,
      maxDescLength: 129,
    },
    {
      code: 'satellite-offices',
      description: 'Satellite Office',
      maxValLength: 2,
      maxDescLength: 100,
    },
    {
      code: 'capabilities',
      description: 'SPE Capabilities',
      maxValLength: 32,
      maxDescLength: 100,
    },
    {
      code: 'auxiliary-roles',
      description: 'Auxiliary Roles',
      maxValLength: 32,
      maxDescLength: 100,
    },
  ];
  getReferenceData() {
    return this.referenceDataList;
  }
}
