export interface Audit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: string;
}

export interface Lifecycle {
  beginDate: string;
  endDate: string | null;
}

export interface ApplReferenceBase {
  id?: number;
  code?: string;
  description: string;
  value: string;
  beginDate?: string;
  endDate?: string | null;
  hotelingIndicator?: boolean;
  lifecycle: Lifecycle;
  audit?: Audit;
  highlighted?: string;
}

export interface ApplReference extends ApplReferenceBase {}

export interface ApplReferenceModel {
  applReferenceDataTypeList: any;
  selectedApplReference: ApplReference;
  newApplReference: ApplReference;
  applReferenceList: ApplReference[];
  totalApplReferenceList: any[];
}

export interface Messages {
  Update: string;
  Create: string;
  Inactivate: string;
}

export interface ReferenceDataTypesSelected {
  code: string;
  description: string;
  maxValLength: number;
  maxDescLength: number;
}
