import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, switchMap } from 'rxjs';
import { throwError } from 'rxjs/internal/observable/throwError';
import { HttpService } from 'src/app/services/http.service';
import { UtilityService } from 'src/app/services/utility.service';
import { ApplReference, ApplReferenceBase, Messages } from './application-reference';

@Injectable({
  providedIn: 'root',
})
export class ApplicationReferenceService {
  readonly MESSAGES: Messages = {
    Update: 'Successfully updated application reference: ',
    Create: 'Successfully created application reference: ',
    Inactivate: 'Successfully inactivated the application reference: ',
  };

  constructor(
    private httpService: HttpService,
    private utilityService: UtilityService
  ) {}

  getApplReferenceDataTypeList(): Promise<any> {
    const applReferenceDataTypeCodeList: string[] = [];
    const localApplReferenceDataTypeCodeList: string[] = [];
    const responseApplReferenceDataTypeList: any[] = [];
    const localListUrl = 'app/applicationReference/applicationReferenceDataType.txt';

    return this.httpService
      .get(localListUrl)
      .toPromise()
      .then((response: any) => {
        applReferenceDataTypeCodeList.push(...response.data, 'telework-programs');
        return this.httpService
          .get(`references`)
          .toPromise()
          .then((response: any) => {
            localApplReferenceDataTypeCodeList.push(...response.data);
            localApplReferenceDataTypeCodeList.forEach((type: any) => {
              for (let i = 0; i < applReferenceDataTypeCodeList.length; i++) {
                if (applReferenceDataTypeCodeList[i] === type.code) {
                  responseApplReferenceDataTypeList.push(type);
                }
              }
            });
            const responseGet = {
              applReferenceDataTypeList: responseApplReferenceDataTypeList,
              status: '',
              statusText: '',
            };
            return responseGet;
          })
          .catch((response) => {            return Promise.reject(response);
          });
      })
      .catch((response) => {        return Promise.reject(response);
      });
  }
  /**
   * Gets list of application references
   */
  getApplReferenceList(
    type: string,
    includeInactive: boolean,
    limit: number,
    skip: number,
    sortColumn?: string,
    sortOrder?: string
  ) {
    if (type !== 'telework-programs') {
      type = '/references/' + type;
    } else {
      type = '/telework-programs';
    }
    const params = new HttpParams()
      .set('includeInactive', !!includeInactive)
      .set('skip', skip)
      .set('limit', limit)
      .set('sortColumn', sortColumn || '')
      .set('sortOrder', sortOrder || '')
      .toString();

    return this.httpService.get(`${type}?${params}`).pipe(
      catchError((response) => {        return throwError(() => response);
      })
    );
  }
  /**
   * Adds/creates new application reference.
   */
  createApplReference(type: string, applReference: ApplReference): Observable<any> {
    const url = type === 'telework-programs' ? `/${type}` : `/references/${type}`;

    // check and convert Date to milliseconds
    if (!applReference.beginDate || new Date(applReference.beginDate).getTime() === 0) {
      applReference.beginDate = this.utilityService.dateFormatter(new Date());
    } else {
      applReference.beginDate = this.utilityService.dateFormatter(
        new Date(applReference.beginDate)
      );
    }

    // check and convert Date to milliseconds
    if (!applReference.endDate || new Date(applReference.endDate).getTime() === 0) {
      applReference.endDate = null;
    } else {
      applReference.endDate = this.utilityService.dateFormatter(new Date(applReference.endDate));
    }

    const requestObject = {
      id: null,
      value: applReference.value,
      description: applReference.description,
      // hotelingIndicator: false,
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lastModifiedUser: '',
        lockControlNumber: '',
      },
      lifecycle: {
        beginDate: applReference.beginDate,
        endDate: applReference.endDate,
      },
    };

    if (type === 'telework-programs') {
      // requestObject['hotelingIndicator'] = !!applReference.hotelingIndicator ? true : false;
    }

    return this.httpService.post(url, requestObject).pipe(
      catchError((response) => {        return throwError(() => response);
      })
    );
  }
  /**
   * Edit/update new application reference.
   */
  updateApplReference(
    type: string,
    applReference: ApplReference,
    lockControlNumber: Number
  ): Observable<any> {
    const applReferenceId = applReference.id;
    const url =
      type === 'telework-programs'
        ? `/${type}/${applReferenceId}`
        : `/references/${type}/${applReferenceId}?lockControlNumber=${lockControlNumber}`;

    const requestObject: ApplReferenceBase = {
      id: applReferenceId,
      value: applReference.value,
      description: applReference.description,
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lastModifiedUser: '',
        lockControlNumber: '',
      },
      lifecycle: {
        beginDate: applReference.lifecycle
          ? (this.utilityService.adjustDateFormatter(
              this.utilityService.dateFormatter(new Date(applReference.lifecycle.beginDate))
            ) as string)
          : '',
        endDate: applReference.lifecycle?.endDate
          ? (this.utilityService.adjustEndDateFormatter(
              this.utilityService.dateFormatterEndDate(new Date(applReference.lifecycle.endDate))
            ) as string)
          : '',
      },
    };

    if (type === 'telework-programs') {
      requestObject.hotelingIndicator = !!applReference.hotelingIndicator ? true : false;
    }

    const params = new HttpParams().set(
      'lockControlNumber',
      applReference?.audit?.lockControlNumber ?? ''
    );

    return this.httpService.put(url, requestObject).pipe(
      catchError((response) => {        return throwError(() => response);
      })
    );
  }

  adjustDateFormatter(dateInput: string) {
    return new Date(Date.parse(dateInput) - new Date().getTimezoneOffset() * 60000)
      .toISOString()
      .split('T')[0];
  }

  getMessage(action: 'Update' | 'Create' | 'Inactivate'): string {
    return this.MESSAGES[action];
  }

  getApplReferenceListForSearch(
    type: string,
    includeInactive: boolean,
    sortColumn?: string,
    sortOrder?: string
  ) {
    if (type !== 'telework-programs') {
      type = '/references/' + type;
    } else {
      type = '/telework-programs';
    }
    const params = new HttpParams()
      .set('includeInactive', !!includeInactive)
      .set('skip', 0)
      .set('sortColumn', sortColumn || '')
      .set('sortOrder', sortOrder || '')
      .toString();

    return this.httpService.get(`${type}?${params}`).pipe(
      catchError((response) => {        return throwError(() => response);
      })
    );
  }
}
