import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'referenceDataTypeFormat',
})
export class ReferenceDataTypeFormatPipe implements PipeTransform {
  transform(input: string): string {
    if (input) {
      return input.replace(/[^a-zA-Z0-9]+/g, '');
    }
    return '';
  }
}
