import { Component, OnInit } from '@angular/core';
import {
  ApplReference,
  ApplReferenceModel,
  ReferenceDataTypesSelected,
} from './application-reference';
import { ApplicationReferenceService } from './application-reference.service';
import { UtilityService } from 'src/app/services/utility.service';
import { ROLES_ENUM } from 'src/app/enums/roles';
import { AppService } from 'src/app/services/app.service';
import { ApplicationReferenceDataService } from './application-reference-data.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-application-reference',
  templateUrl: './application-reference.component.html',
  styleUrls: ['./application-reference.component.scss'],
})
export class ApplicationReferenceComponent implements OnInit {
  public rolesEnum = ROLES_ENUM;
  public editedIndex: number = -1;
  readonly todayDate = new Date();
  createApplReferenceButton: any;
  resetApplReferenceButton: any;
  cancelApplReferenceButton: any;
  addApplReferenceButton: any;
  editApplReferenceButton: any;
  addApplReference = false;
  editApplReference = false;
  basicSearchText: string = '';
  searchResultsMode: boolean = false;
  newApplReferenceDescriptionInvalidMsg: string = '';
  editApplReferenceDescriptionInvalidMsg: string = '';
  editApplReferenceValueInvalidMsg: string = '';
  newApplReferenceValueInvalidMsg: string = '';
  referenceDataSearchSelected: any;
  editApplReferenceValueInvalid = '';
  editApplReferenceDescriptionInvalid = '';
  editApplReferenceStartDateInvalid = '';
  editApplReferenceEndDateInvalid = '';
  hasError: boolean = false;
  applReferenceModel: ApplReferenceModel = {
    applReferenceDataTypeList: [],
    selectedApplReference: {
      code: '',
      description: '',
      value: '',
      beginDate: '',
      endDate: '',
      lifecycle: { beginDate: '', endDate: '' },
    },
    newApplReference: {
      code: '',
      description: '',
      value: '',
      beginDate: '',
      endDate: '',
      // hotelingIndicator: false,
      lifecycle: {
        beginDate: this.utilityService.formatDate(new Date(), 'MM/dd/yyyy'),
        endDate: '',
      },
    },
    applReferenceList: [],
    totalApplReferenceList: [],
  };
  appTitle = 'Application Reference Data Management';

  moduleName = 'Application Reference Data Management';
  showType = 'active';
  tomorrow: Date;

  referenceDataTypesSelected: ReferenceDataTypesSelected = {
    code: 'contractor-firms',
    description: 'Contractor Firm Name',
    maxValLength: 250,
    maxDescLength: 1000,
  };

  applReferenceValueHeader = 'Value';
  applReferenceDescriptionHeader = 'Description';
  applReferenceStartDateHeader = 'Start date';

  responseCreate: any;
  responseUpdate: any;

  includeInactive: boolean = false;

  sortColumn: string = 'value';
  sortDirection: string = 'asc';
  limit: number = 10;
  total: number = 0;
  skip: number = 0;
  newApplReferenceStartDateInvalid: any;
  newApplReferenceEndDateInvalid: any;
  newApplReferenceValueInvalid: any;
  newApplReferenceDescriptionInvalid: any;
  returnMessage: string = '';
  wholeMessage: string = '';
  continueMessage: boolean = false;
  hideMessage: boolean = false;
  lastModifiedLoginId: number = 0;
  lastModifiedDate: Date = new Date();
  returnCode: any;
  accessDenied: any;
  searchResults: string = '';
  dropDownList = this.applicationReferenceDataService.getReferenceData();

  constructor(
    private applicationReferenceDataService: ApplicationReferenceDataService,
    private applicationReferenceService: ApplicationReferenceService,
    private utilityService: UtilityService,
    public appService: AppService,
    private httpService: HttpService,
  ) {
    this.tomorrow = new Date();
    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
  }

  ngOnInit(): void {
    this.referenceDataTypesSelected = this.dropDownList.find(
      (o) => o.default
    ) as ReferenceDataTypesSelected;
    this.getLastModifiedInfo();
    this.getAppleReferenceList();
  }

  private validateNewAppReferenceDates(): boolean {
    this.newApplReferenceStartDateInvalid = '';
    this.newApplReferenceEndDateInvalid = '';

    this.newApplReferenceStartDateInvalid = this.utilityService.validateBeginDate(
      this.applReferenceModel.newApplReference.beginDate,
      true
    );

    this.newApplReferenceEndDateInvalid = this.utilityService.validateEndDate(
      this.applReferenceModel.newApplReference.beginDate as string,
      this.applReferenceModel.newApplReference.endDate as string
    );

    return !this.newApplReferenceStartDateInvalid || !this.newApplReferenceEndDateInvalid;
  }

  private validateNewAppReferenceValue(): void {
    this.newApplReferenceValueInvalid = '';
    if (!this.applReferenceModel.newApplReference.value) {
      this.hasError = true;
      this.newApplReferenceValueInvalid = 'Application reference value is required';
    }
  }

  private validateNewAppReferenceDescription(): void {
    this.newApplReferenceDescriptionInvalid = '';
    if (!this.applReferenceModel.newApplReference.description) {
      this.hasError = true;
      this.newApplReferenceDescriptionInvalid = 'Application reference description is required';
    }
  }

  /**
   * Validates add/create new application reference.
   */
  newApplReferenceValid(): boolean {
    this.validateNewAppReferenceValue();
    this.validateNewAppReferenceDescription();
    const newDatesValid = this.validateNewAppReferenceDates();
    return (
      !this.newApplReferenceValueInvalid &&
      !this.newApplReferenceDescriptionInvalid &&
      newDatesValid
    );
  }

  setMessages = (messages: string[]) => {
    if (!messages) {
      this.returnMessage = 'Unknown error message found';
      this.continueMessage = false;
      return;
    }

    if (messages.length > 1) {
      this.returnMessage = messages[1];
      this.wholeMessage = messages[0];
      this.continueMessage = true;
    } else {
      this.returnMessage = messages[0];
      this.continueMessage = false;
    }
  };
  getLastModifiedInfo(): void {
    const type = this.referenceDataTypesSelected.code;
    let modifiedUrl = type;
    if (type !== 'telework-programs') {
      modifiedUrl = `/references/${type}`;
    } else {
      modifiedUrl = '/telework-programs';
    }

    this.utilityService.getLastModifiedInfo(modifiedUrl).subscribe(
      (response: any) => {
        if (response.results && response.results.length > 0) {
          this.setLastModifiedInfo(response.results[0].audit);
        }
      },
      (error: any) => {      }
    );
  }

  private setLastModifiedInfo(auditObject: any): void {
    this.lastModifiedLoginId = auditObject.lastModifiedLoginId;
    this.lastModifiedDate = auditObject.lastModifiedDate;
  }

  setMessage(returnCode: number, returnMessage: string, response?: any): void {
    this.returnCode = returnCode;
    this.returnMessage = returnMessage;
    this.hideMessage = false;
    if (response) {
      this.accessDenied = response.accessDenied;
    }
  }

  resetValidations() {
    this.hideMessage = true;
    this.hasError = false;
    this.newApplReferenceValueInvalid = '';
    this.newApplReferenceDescriptionInvalid = '';
    this.newApplReferenceStartDateInvalid = '';
    this.newApplReferenceEndDateInvalid = '';
  }

  resetApplReferenceList() {
    this.applReferenceModel.newApplReference = {
      code: '',
      description: '',
      value: '',
      beginDate: this.utilityService.formatDate(new Date(), 'MM/dd/yyyy'),
      endDate: '',
      // hotelingIndicator: false,
      lifecycle: { beginDate: new Date().toISOString(), endDate: '' },
    };
  }
  resetApplReference() {
    this.hasError = false;
    this.resetValidations();
    this.resetApplReferenceList();
  }

  cancelApplReference() {
    this.editedIndex = -1;
    this.hasError = false;
    this.applReferenceValueHeader = 'Value';
    this.applReferenceDescriptionHeader = 'Description';
    this.applReferenceStartDateHeader = 'Start date';
    this.resetValidations();
    this.addApplReference = false;
    this.resetApplReferenceList();
  }

  createApplReference(): void {
    // filter will be removed
    if (this.newApplReferenceValid()) {
      this.hasError = false;
      this.applicationReferenceService
        .createApplReference(
          this.referenceDataTypesSelected.code,
          this.applReferenceModel.newApplReference
        )
        .toPromise()
        .then(
          (response: any) => {
            this.responseCreate = response;
            const errorMessage = this.applicationReferenceService.getMessage('Create');
            this.setMessages(
              this.utilityService.getMessages(errorMessage + this.responseCreate.value)
            );
            this.getAppleReferenceList();
            this.getLastModifiedInfo();
            this.cancelApplReference();
            this.hideMessage = false;
            this.hasError = true;
            this.returnCode = 200;
            this.returnMessage = errorMessage + this.responseCreate.value;
          },
          (response) => {
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Error creating Application reference - ' +
                this.referenceDataTypesSelected.description +
                ' already exists'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
            this.accessDenied = response.accessDenied;
          }
        );
    } else {
      this.setMessage(700, this.utilityService.getInvalidInputErrorMessage());
    }
  }
  showApplReferenceAdd() {
    this.hideMessage = true;
    this.hasError = false;
    this.applReferenceValueHeader = 'Value *';
    this.applReferenceDescriptionHeader = 'Description *';
    this.applReferenceStartDateHeader = 'Start date *';
    this.addApplReference = true;
    this.resetApplReferenceList();
  }

  applReferenceReloadHandler(event?: any) {
    this.hideMessage = true;
    this.cancelApplReference();
    this.cancelEditApplReference();
    this.basicSearchText = '';
    this.searchResultsMode = false;
    if (event) {
      this.referenceDataTypesSelected = this.dropDownList.find(
        (o) => o.code === event.target.value
      ) as ReferenceDataTypesSelected;

      this.skip = 0;
      this.total = 0;
      this.getAppleReferenceList();
      this.getLastModifiedInfo();
    } else {
      // this.referenceDataTypesSelected = this.dropDownList.find(
      //   (o) => o.default
      // ) as ReferenceDataTypesSelected;
      this.skip = 0;
      this.total = 0;
      this.getAppleReferenceList();
      this.getLastModifiedInfo();
    }
  }

  getAppleReferenceList() {
    this.applicationReferenceService
      .getApplReferenceList(
        this.referenceDataTypesSelected.code,
        this.includeInactive,
        this.limit,
        this.skip,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response: any) => {
          this.getAppleReferenceListForSearch();
          this.applReferenceModel.applReferenceList = [];
          this.total = response.meta.total;
          const applReferenceDisplayList: ApplReference[] = [];
          response.results.forEach((applReference: any) => {
            applReference.value = applReference.value || '';
            applReference.description = applReference.description || '';
            applReference.lifecycle = applReference.lifecycle || { beginDate: '', endDate: '' };

            if (!this.includeInactive) {
              applReference.lifecycle.endDate = null;
            }

            applReferenceDisplayList.push(applReference);
          });
          this.applReferenceModel.applReferenceList = applReferenceDisplayList;
        },
        (error) => {
          this.hideMessage = false;
          this.returnCode = error.status;
          this.returnMessage = this.utilityService.processFailureMessage(
            error,
            'Error retrieving Application reference list'
          );
          this.accessDenied = error.accessDenied;
        }
      );
  }

  getAppleReferenceListForSearch() {
    this.applicationReferenceService
      .getApplReferenceListForSearch(
        this.referenceDataTypesSelected.code,
        this.includeInactive,
        this.sortColumn,
        this.sortDirection
      )
      .subscribe(
        (response: any) => {
          this.applReferenceModel.totalApplReferenceList = response.results;
        },
        (error) => {
          this.hideMessage = false;
          this.returnCode = error.status;
          this.returnMessage = this.utilityService.processFailureMessage(
            error,
            'Error retrieving Application reference list'
          );
          this.accessDenied = error.accessDenied;
        }
      );
  }

  cancelEditApplReference() {
    this.editedIndex = -1;
    this.applReferenceModel.selectedApplReference = {
      code: '',
      description: '',
      value: '',
      beginDate: '',
      endDate: '',
      lifecycle: { beginDate: '', endDate: '' },
    };
    this.applReferenceValueHeader = 'Value';
    this.applReferenceDescriptionHeader = 'Description';
    this.applReferenceStartDateHeader = 'Start date';
    this.resetEditValidation();
    this.editApplReference = false;
  }
  private resetEditValidation(): void {
    this.hideMessage = true;
    this.hasError = false;
    this.editApplReferenceValueInvalid = '';
    this.editApplReferenceDescriptionInvalid = '';
    this.editApplReferenceStartDateInvalid = '';
    this.editApplReferenceEndDateInvalid = '';
  }

  clearSearchResults() {
    this.basicSearchText = '';
    this.searchResultsMode = false;
    this.applReferenceReloadHandler();
  }

  exportDataCallback() {
    let url;
    if (this.referenceDataTypesSelected.code === 'telework-programs') {
      url = '/telework-programs/excelReport?';
    } else {
      url = `/references/${this.referenceDataTypesSelected.code}/excelReport?`;
    }

    url += this.showType === 'all' ? 'includeInactive=true' : 'includeInactive=false';

    this.utilityService.exportTableService(
      url,
      'ApplicationReferences.xls',
      'application/vnd.ms-excel'
    );
  }

  applicationReferenceSearch() {
    this.basicSearchText = (this.basicSearchText || '').toLowerCase();
    this.applReferenceModel.applReferenceList = this.applReferenceModel.totalApplReferenceList;
    const matchedapplicationReferenceSearchResults: any[] = [];
    if (this.referenceDataSearchSelected === 'Value') {
      this.applReferenceModel.applReferenceList.forEach((response: any) => {
        const responseDescription = response.value.toLowerCase();
        if (responseDescription.includes(this.basicSearchText)) {
          matchedapplicationReferenceSearchResults.push(response);
        }
      });
    } else if (this.referenceDataSearchSelected === 'Description') {
      this.applReferenceModel.applReferenceList.forEach((response: any) => {
        const responseDescription = response.description.toLowerCase();
        if (responseDescription.includes(this.basicSearchText)) {
          matchedapplicationReferenceSearchResults.push(response);
        }
      });
    }
    if (matchedapplicationReferenceSearchResults.length > 0) {
      this.applReferenceModel.applReferenceList =
        matchedapplicationReferenceSearchResults as ApplReference[];
      this.searchResults =
        matchedapplicationReferenceSearchResults.length +
        ' results found with ' +
        this.referenceDataSearchSelected +
        ' ' +
        this.basicSearchText.toUpperCase();
    } else {
      this.applReferenceModel.applReferenceList = [];
      this.searchResults = 'No results found ';
      this.total = 0;
    }
    this.searchResultsMode = true;
  }

  searchKeyEventBasic(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.hideMessageDiv();
      this.applicationReferenceSearch();
    }
  }

  hideMessageDiv() {
    this.hideMessage = true;
  }

  toggleActiveAll(val: boolean) {
    this.includeInactive = val;
    this.skip = 0;
    this.total = 0;
    this.getAppleReferenceList();
  }

  sortBy(column: string): void {
    if (this.sortColumn === column) {
      // Toggle sort direction if clicking the same column
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and default to ascending
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.skip = 0;
    this.total = 0;
    this.getAppleReferenceList();
  }

  showApplReferenceEdit(applReference: ApplReference, index: number = -1) {
    // this.applReferenceModel.selectedApplReference.lifecycle.endDate = null;
    if (
      this.editApplReference ||
      this.addApplReference ||
      !this.appService.checkRoleExists(this.rolesEnum.INFRA_ADMIN)
    ) {
      return;
    }
    this.hasError = false;
    this.editedIndex = index;
    this.applReferenceModel.selectedApplReference = { ...applReference };

    if (this.applReferenceModel.selectedApplReference.lifecycle === undefined) {
      this.applReferenceModel.selectedApplReference.lifecycle = { endDate: null, beginDate: '' };
    } else if (this.applReferenceModel.selectedApplReference.lifecycle.endDate === undefined) {
      this.applReferenceModel.selectedApplReference.lifecycle.endDate = null;
    }

    this.applReferenceValueHeader = 'Value *';
    this.applReferenceDescriptionHeader = 'Description *';
    this.applReferenceStartDateHeader = 'Start date *';
    this.editApplReference = true;
    this.hideMessage = true;
    // this.applReferenceModel.selectedApplReference.lifecycle.endDate = null;
  }
  confirmUpdateApplReference(applReference: ApplReference) {
    if (this.editApplReferenceValid()) {
      if (!applReference.lifecycle) {
        applReference.lifecycle = { beginDate: '', endDate: null };
      }
      if (!applReference.lifecycle?.endDate) {
        applReference.lifecycle.endDate = null;
      }
      this.updateApplReference(applReference);
    } else {
      this.setMessage(700, this.utilityService.getInvalidInputErrorMessage());
    }
  }

  updateApplReference(applReference: ApplReference) {
    // get todays date
    const todayDate = this.utilityService.dateFormatter(new Date(), 'yyyy-MM-dd');
    // get original applReference
    const originalApplReference = { ...applReference };
    // check if the record was inactivated before filter will be removed
    const isInactivated =
      this.utilityService.dateFormatter(
        originalApplReference.lifecycle?.endDate || new Date(),
        'yyyy-MM-dd'
      ) < todayDate
        ? true
        : false;
    if (this.editApplReferenceValid()) {
      this.applicationReferenceService
        .updateApplReference(
          this.referenceDataTypesSelected.code,
          this.applReferenceModel.selectedApplReference,
          Number(applReference?.audit?.lockControlNumber)
        )
        .subscribe(
          (response) => {
            this.responseUpdate = response;

            const endDate = this.utilityService.dateFormatter(
              this.applReferenceModel.selectedApplReference.lifecycle?.endDate || new Date(),
              'yyyy-MM-dd'
            );
            let actionCode: 'Update' | 'Create' | 'Inactivate' = 'Update';
            // if endDate < todayDate and was not inactivated before
            if (endDate && endDate < todayDate && !isInactivated) {
              actionCode = 'Inactivate';
            }

            const theMessages = this.applicationReferenceService.getMessage(actionCode);
            this.setMessages(
              this.utilityService.getMessages(theMessages + this.responseUpdate.value)
            );
            let message: any = this.utilityService.getMessages(
              theMessages + this.responseUpdate.value
            );
            this.applReferenceModel.applReferenceList.map((applReference) => {
              if (applReference.id === this.applReferenceModel.selectedApplReference.id) {
                applReference.value = this.applReferenceModel.selectedApplReference.value;
                applReference.description =
                  this.applReferenceModel.selectedApplReference.description;
                applReference.lifecycle.beginDate =
                  this.applReferenceModel.selectedApplReference.lifecycle.beginDate;
                applReference.lifecycle.endDate =
                  this.applReferenceModel.selectedApplReference.lifecycle.endDate;
              }
            });

            this.cancelEditApplReference();
            this.getLastModifiedInfo();
            this.hideMessage = false;
            setTimeout(() => {
              this.hasError = true;
              this.returnCode = 200;
              this.returnMessage = message;
            }, 2000);
          },
          (response) => {
            this.returnMessage = this.utilityService.processFailureMessage(
              response,
              'Error updating Application reference'
            );
            this.returnCode = response.status;
            this.hideMessage = false;
            this.accessDenied = response.accessDenied;
          }
        );
    } else {
      this.setMessage(700, this.utilityService.getInvalidInputErrorMessage());
    }
  }
  private editApplReferenceValid(): boolean {
    this.editApplReferenceStartDateInvalid = '';
    this.editApplReferenceEndDateInvalid = '';
    this.checkReferenceValue();
    this.checkReferenceDescription();
    const datesInvalid = this.validateDates();

    return (
      !this.editApplReferenceValueInvalid &&
      !this.editApplReferenceDescriptionInvalid &&
      !datesInvalid
    );
  }
  private checkReferenceValue(): void {
    this.editApplReferenceValueInvalid = '';
    if (!this.applReferenceModel.selectedApplReference.value) {
      this.hasError = true;
      this.editApplReferenceValueInvalid = 'Application reference value is required';
    }
  }

  /**
   * Validate Reference Description
   */
  private checkReferenceDescription(): void {
    this.editApplReferenceDescriptionInvalid = '';
    if (!this.applReferenceModel.selectedApplReference.description) {
      this.hasError = true;
      this.editApplReferenceDescriptionInvalid = 'Application reference description is required';
    }
  }

  /**
   * Validate begin and end date
   */
  private validateDates(): boolean {
    if (!this.applReferenceModel.selectedApplReference.lifecycle) {
      this.applReferenceModel.selectedApplReference.lifecycle = { endDate: '', beginDate: '' };
    }
    this.editApplReferenceStartDateInvalid = this.utilityService.validateBeginDate(
      this.applReferenceModel.selectedApplReference.lifecycle.beginDate,
      true
    ) as string;
    this.editApplReferenceEndDateInvalid = this.utilityService.validateEndDate(
      this.applReferenceModel.selectedApplReference.lifecycle.beginDate as string,
      this.applReferenceModel.selectedApplReference.lifecycle.endDate as string
    ) as string;

    return !!this.editApplReferenceEndDateInvalid || !!this.editApplReferenceStartDateInvalid;
  }

  resetEditApplReference(applReference: ApplReference) {
    this.applReferenceModel.selectedApplReference = { ...applReference };
    if (!this.applReferenceModel.selectedApplReference.lifecycle) {
      this.applReferenceModel.selectedApplReference.lifecycle = { endDate: '', beginDate: '' };
    }
    if (this.applReferenceModel.selectedApplReference.lifecycle?.endDate === undefined) {
      this.applReferenceModel.selectedApplReference.lifecycle.endDate = null;
    }
    this.resetEditValidation();
  }
  convertToDate(date: string | null | undefined = ''): Date | null {
    if (!date || date === null || date === undefined || date === '') {
      return null;
    }
    return new Date(date);
  }

  pageSizeChangedEvent(limit: number) {
    this.limit = limit;
    this.skip = 0;
    this.total = 0;
    this.getAppleReferenceList();
  }

  onPageChanged(pageNumber: number) {
    this.skip = (pageNumber - 1) * this.limit;
    this.getAppleReferenceList();
  }
}
