import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss'],
})
export class TabsComponent implements OnInit {
  // Ensure your variable name matches your template exactly
  @Input() tabsArray: string[] = [];
  @Output() onTabChange = new EventEmitter<number>();
  activatedTab: number = 0; // Internal tracker for highlighting
  constructor(private appService: AppService) {}
  ngOnInit() {}

  setTab(index: number) {
    this.activatedTab = index;
    this.onTabChange.emit(index);
  }
}
