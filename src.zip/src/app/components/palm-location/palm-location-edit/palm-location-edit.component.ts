import { Component, Input, Output, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { PalmLocation } from '../PalmLocation';

interface PalmLocationModel {
  selectedPalmLocation: PalmLocation;
}

@Component({
  selector: 'app-palm-location-edit',
  templateUrl: './palm-location-edit.component.html',
  styleUrls: ['./palm-location-edit.component.scss'],
  standalone: false,
})
export class PalmLocationEditComponent implements OnInit {
  @Input() palmLocation: PalmLocation | null = null;
  @Input() palmLocationModel: PalmLocation | null = null;
  @Input() edit: boolean = false;

  @Output() cancel = new EventEmitter<PalmLocation>();
  // @Output() reset = new EventEmitter<PalmLocation>();
  @Output() save = new EventEmitter<{ index: number; data: PalmLocation }>();

  @ViewChild('editForm') editForm!: NgForm;

  invalidVisualLocationCode: string = '';
  invalidDescription: string = '';
  invalidSystemName: string = '';
  beginDateErrorMessage: string = '';
  endDateErrorMessage: string = '';

  // Form model for template-driven forms
  formModel = {
    visualLocationCode: '',
    description: '',
    systemName: '',
    beginDate: null as any,
    endDate: null as any,
  };

  ngOnInit(): void {
    this.initializeFormModel();
  }

  private initializeFormModel(): void {
    if (!this.palmLocationModel) {
      return;
    }

    const palmLoc = this.palmLocationModel;
    this.formModel = {
      visualLocationCode: palmLoc.visualLocationCode || '',
      description: palmLoc.description || '',
      systemName: palmLoc.systemName || '',
      beginDate: palmLoc.lifecycle?.beginDate,
      endDate: palmLoc.lifecycle?.endDate,
    };
  }

  validateVisualLocationCode(): void {
    const value = this.formModel.visualLocationCode;
    if (!value || value.trim() === '') {
      this.invalidVisualLocationCode = 'Visual location code is required';
    } else if (value.length > 4) {
      this.invalidVisualLocationCode = 'Visual location code cannot exceed 4 characters';
    } else {
      this.invalidVisualLocationCode = '';
    }
  }

  validateDescription(): void {
    const value = this.formModel.description;
    if (!value || value.trim() === '') {
      this.invalidDescription = 'Description is required';
    } else if (value.length > 100) {
      this.invalidDescription = 'Description cannot exceed 100 characters';
    } else {
      this.invalidDescription = '';
    }
  }

  validateSystemName(): void {
    const value = this.formModel.systemName;
    if (!value || value.trim() === '') {
      this.invalidSystemName = 'System code is required';
    } else if (value.length > 10) {
      this.invalidSystemName = 'System code cannot exceed 10 characters';
    } else {
      this.invalidSystemName = '';
    }
  }

  validateBeginDate(): void {
    const value = this.formModel.beginDate;
    if (!value) {
      this.beginDateErrorMessage = 'Start date is required';
    } else {
      this.beginDateErrorMessage = '';
      this.validateEndDate();
    }
  }

  validateEndDate(): void {
    const beginDate = this.formModel.beginDate;
    const endDate = this.formModel.endDate;

    if (endDate && beginDate && new Date(endDate) < new Date(beginDate)) {
      this.endDateErrorMessage = 'End date must be after start date';
    } else {
      this.endDateErrorMessage = '';
    }
  }

  cancelPalmLocation(palmLocation: PalmLocation | null): void {
    if (palmLocation) {
      this.cancel.emit(palmLocation);
    }
  }

  resetPalmLocation(palmLocation: PalmLocation | null): void {
    if (palmLocation) {
      // this.reset.emit(palmLocation);
      this.initializeFormModel();
      // if (this.editForm) {
      //   this.editForm.resetForm();
      // }
    }
  }

  savePalmLocation(index: number): void {
    this.validateAllFields();

    // if (this.isFormValid() && this.palmLocation) {
    const updatedLocation: any = {
      ...this.palmLocation,
      visualLocationCode: this.formModel.visualLocationCode,
      description: this.formModel.description,
      systemName: this.formModel.systemName,
      lifecycle: {
        beginDate: this.formModel.beginDate,
        endDate: this.formModel.endDate,
      },
    };
    this.save.emit({ index, data: updatedLocation });
    // }
  }

  private validateAllFields(): void {
    this.validateVisualLocationCode();
    this.validateDescription();
    this.validateSystemName();
    this.validateBeginDate();
    this.validateEndDate();
  }

  private isFormValid(): boolean {
    return (
      !this.invalidVisualLocationCode &&
      !this.invalidDescription &&
      !this.invalidSystemName &&
      !this.beginDateErrorMessage &&
      !this.endDateErrorMessage &&
      this.formModel.visualLocationCode &&
      this.formModel.description &&
      this.formModel.systemName &&
      this.formModel.beginDate
    );
  }

  isFieldInvalid(fieldName: string): boolean {
    if (!this.editForm) {
      return false;
    }

    const field = this.editForm.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }
}
