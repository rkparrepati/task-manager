export interface PalmLocation {
  visualLocationCode: string;
  description: string;
  palmLocationId: number;
  viewMode: number;
  dbLocationCode: string | null;
  systemName: string;
  lifecycle?: Lifecycle;
  audit?: Audit;
  selectedPalmLocation: any;
}
export interface Lifecycle {
  beginDate: string;
  endDate: string | null;
}
export interface SelectedPalmLocation {}
export interface Audit {
  createdDate: string;
  createdUser: string;
  lastModifiedDate: string;
  lastModifiedUser: string;
  lockControlNumber: string;
}
