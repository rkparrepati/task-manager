import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { PalmLocation } from './PalmLocation';
import { PalmLocationService } from '../../services/palm-location.service';
import { UtilityService } from 'src/app/services/utility.service';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-palm-location',
  templateUrl: './palm-location.component.html',
  styleUrls: ['./palm-location.component.scss'],
})
export class PalmLocationComponent implements OnInit {
  edit: boolean = false;
  searchBoxtext = '';
  hasError: boolean = false;
  resultMessage: string = '';
  returnCode: number = 0;
  errors: any[] = [];
  limit: number = 10;
  skip: number = 0;
  currentPage: number = 1;
  add: boolean = false;
  showType: string = 'active';
  total: number = 0;
  searchText: string = '';
  searchResultsMode: boolean = false;
  currentSearchText: string | null = '';
  palmLocationModel: PalmLocation = {
    visualLocationCode: '',
    description: '',
    dbLocationCode: '',
    selectedPalmLocation: {},
    systemName: '',
    lifecycle: {
      beginDate: '',
      endDate: '',
    },
    audit: {
      createdDate: '',
      createdUser: '',
      lastModifiedDate: '',
      lastModifiedUser: '',
      lockControlNumber: '',
    },
    palmLocationId: 0,
    viewMode: 0,
  };
  pamLocation: PalmLocation | undefined;
  palmLocations: PalmLocation[] = [];
  userRoles: any;
  visualLocationCodeHeader: string = 'Visual location code';
  descriptionHeader: string = 'Description';
  disableShowRadioButton: boolean = true;
  invalidVisualLocationCode: string = '';
  sortDirection: string = 'asc';
  sortColumn: string = 'visualLocationCode';
  invalidDescription: string = '';
  beginDateErrorMessage: string | null = '';
  endDateErrorMessage: string | null = '';
  invalidSystemName: string = '';
  searchResults: string | null = '';
  constructor(
    private palmLocationService: PalmLocationService,
    private utilityService: UtilityService,
    private datePipe: DatePipe,
    private ctr: ChangeDetectorRef,
    private httpService: HttpService,
  ) {}
  ngOnInit(): void {
    this.getPalmLocationsList();
    // throw new Error('Method not implemented.');
  }
  hideMessageDiv(): void {}
  resort(event: any): void {}
  setshowMode(palmLocation: any, mode: string = 'expand'): void {
    if (mode === 'expand') {
      // this.palmLocations[index].viewMode = this.palmLocations[index].viewMode === 0 ? 1 : 0;
      palmLocation.viewMode === 0 ? (palmLocation.viewMode = 1) : (palmLocation.viewMode = 0);
    }
    if (palmLocation.viewMode === 2) {
      return;
    }

    // this.palmLocationModel.selectedPalmLocation = {

    // };

    this.palmLocationModel.selectedPalmLocation = palmLocation;
    this.visualLocationCodeHeader = 'Visual location code';
    this.descriptionHeader = 'Description';
    this.cancelAllInvalidates();
    this.ctr.detectChanges();
  }
  firstPage(): void {}
  toggleActiveAll(): void {
    this.getPalmLocationsList();
  }
  clearSearchResults(): void {}
  getPalmLocationTemplate(palmLocation: any): string {
    if (palmLocation.viewMode === 2) {
      return '#editPalmLocationRow';
    } else if (palmLocation.viewMode === 1) {
      return '#detailsPalmLocationRow';
    } else {
      return '#displayPalmLocationRow';
    }
  }

  editcancelPalmLocation(event: any): void {
    event.viewMode = 0;
    this.edit = false;
    this.cancelPalmLocation();
  }
  cancelPalmLocation(): void {
    this.resetPalmLocation();
    this.add = false;
  }
  resetPalmLocation(): void {
    this.palmLocationModel.selectedPalmLocation = {
      lifecycle: {
        beginDate: this.datePipe.transform(new Date(), 'yyyy-MM-dd') as string,
        endDate: '',
      },
      systemName: 'PALM',
      visualLocationCode: '',
      dbLocationCode: null,
      audit: {
        lockControlNumber: 0,
      },
    };
    this.invalidVisualLocationCode = '';
    this.invalidDescription = '';
  }
  createNewPalmLocation(): void {
    this.resetPalmLocation();
    this.hasError = false;
    this.add = true;
  }
  search(): void {
    if (!this.edit && !this.add) {
      this.hideMessageDiv();
      if (this.searchText.length) {
        this.searchResultsMode = true;
        this.currentSearchText = this.searchText.toUpperCase();
        this.currentPage = 1;
        this.skip = 0;
        this.getPalmLocationsList();
        this.searchBoxtext = `No active locations found for ${this.searchText}`;
      }
    }
  }
  editPalmLocation(palmLocation?: any): void {
    // if (!this.edit && !this.add && this.userRoles?.indexOf('InfraAdmin') >= 0) {
    if (!this.edit && !this.add) {
      if (palmLocation) {
        this.palmLocationModel.selectedPalmLocation = JSON.parse(JSON.stringify(palmLocation));
        palmLocation.viewMode = 2;
        this.edit = true;
        this.hasError = false;
        if (!this.palmLocationModel.selectedPalmLocation.lifecycle.endDate) {
          this.palmLocationModel.selectedPalmLocation.lifecycle.endDate = '';
        }
      } else {
        this.createNewPalmLocation();
      }
      this.visualLocationCodeHeader = 'Visual location code *';
      this.descriptionHeader = 'Description *';
      this.hideMessageDiv();
      this.disableShowRadioButton = true;
    }

    if (this.edit) {
      palmLocation.viewMode = 2;
    }
  }
  getPalmLocationsList(): void {
    if (!this.add && !this.edit) {
      const includeInactive = this.showType === 'all';
      this.palmLocationService
        .getPalmLocations(
          includeInactive,
          this.currentSearchText,
          this.limit,
          this.skip,
          this.sortColumn,
          this.sortDirection
        )
        .subscribe(
          (response: any) => {
            this.palmLocations = [];
            // Check if response contains error message (backend returns 200 with error message)
            if (response && response.message && !response.results) {
              this.hasError = true;
              this.returnCode = 404;
              this.resultMessage = response.message;
              this.searchBoxtext = response.message;
              this.ctr.detectChanges();
            } else if (response && response.results) {
              for (let i = 0; i < response.results.length; i++) {
                response.results[i].viewMode = 0;
                this.palmLocations.push(response.results[i]);
              }
              this.total = response.meta.total;
              this.searchBoxtext = `${this.total} result(s) found for ${this.searchText}`;
              this.hasError = false;
              this.ctr.detectChanges();
            }
          },
          (error: any) => {
            this.hasError = true;
            this.returnCode = error.status || 400;
            this.resultMessage = error.error?.message || `No active locations found for ${this.searchText}`;
            this.searchBoxtext = this.resultMessage;
            this.ctr.detectChanges();
          }
        );
      // TODO: Implement actual service call
      // PalmLocationService.getPalmLocations(
      //   this.currentSearchText,
      //   includeInactive,
      //   limit,
      //   skip,
      //   this.sortColumn,
      //   this.sortDirection
      // ).then(
      //   (palmLocationsData: PalmLocationsResponse) => {
      //     this.palmLocations = palmLocationsData.results;
      //     this.total = palmLocationsData.meta.total;
      //     this.palmLocationModel.palmLocations = this.palmLocations;
      //
      //     if (this.searchResultsMode) {
      //       this.searchResults = `${this.total} results found for ${this.currentSearchText}`;
      //     }
      //   },
      //   (response: any) => {
      //     this.processFailureResponse(response, includeInactive);
      //   }
      // );
    }
  }

  updateSavePalmLocation(event: any): void {
    this.validateBeginDate();
    this.validateEndDate();

    if (!this.invalidatePalmLocationParameters(event.data)) {
      this.palmLocationService.updatePalmLocation(event.data, '').subscribe((response: any) => {
        this.returnCode = 200;
        this.hasError = true;
        this.resultMessage = 'Successfully updated PALM Location ' + event.data.visualLocationCode;
        this.edit = false;
        this.add = false;
        this.getPalmLocationsList();
        this.editcancelPalmLocation(response);
      });
    }
  }
  savePalmLocation(): void {
    this.validateBeginDate();
    this.validateEndDate();
    if (!this.invalidatePalmLocationParameters(this.palmLocationModel.selectedPalmLocation)) {
      this.palmLocationService
        .savePalmLocation(this.palmLocationModel.selectedPalmLocation, '')
        .subscribe((response: any) => {
          this.returnCode = 200;
          this.hasError = true;
          this.resultMessage =
            'Successfully saved PALM Location ' +
            this.palmLocationModel.selectedPalmLocation.visualLocationCode;
          this.edit = false;
          this.add = false;
          this.getPalmLocationsList();
          this.editcancelPalmLocation(response);
        });
      // TODO: Implement actual service call
      // PalmLocationService.savePalmLocation(
      //   this.palmLocationModel.selectedPalmLocation
      // ).then(
      //   () => {
      //     const typeMessage = this.edit ? 'updated' : 'created';
      //     this.scrollToTop();
      //     this.returnMessage = `Successfully ${typeMessage} PALM Location ${
      //       this.palmLocationModel.selectedPalmLocation.visualLocationCode
      //     }`;
      //     this.returnCode = '200';
      //     this.hideMessage = false;
      //     this.edit = false;
      //     this.add = false;
      //     this.firstPage();
      //     this.disableShowRadioButton = false;
      //   },
      //   (response: any) => {
      //     this.hideMessage = false;
      //     this.returnCode = response.status;
      //     this.returnMessage = this.utilityService.processFailureMessage(
      //       response,
      //       'Error saving PALM Location'
      //     );
      //     this.accessDenied = response.accessDenied;
      //     this.scrollToTop();
      //   }
      // );
    } else {
      //this.setMessage('700', this.utilityService.getInvalidInputErrorMessage());
    }
  }
  cancelAllInvalidates(): void {
    this.invalidVisualLocationCode = '';

    this.invalidDescription = '';
    this.invalidSystemName = '';
    this.endDateErrorMessage = '';
    this.beginDateErrorMessage = '';
  }
  private invalidatePalmLocationParameters(thePalmLocation: any): boolean {
    this.cancelAllInvalidates();
    let thePalmLocationInvalid = false;

    if (JSON.stringify(thePalmLocation) !== '{}') {
      if (!thePalmLocation.visualLocationCode) {
        this.invalidVisualLocationCode = 'Visual location code required';
        thePalmLocationInvalid = true;
      } else {
        this.palmLocationModel.selectedPalmLocation.visualLocationCode =
          thePalmLocation.visualLocationCode.toUpperCase().trim();
      }

      if (!thePalmLocation.description) {
        this.invalidDescription = 'Description required';
        thePalmLocationInvalid = true;
      }

      if (!thePalmLocation.systemName) {
        this.invalidSystemName = 'System name required';
        thePalmLocationInvalid = true;
      } else {
        this.palmLocationModel.selectedPalmLocation.systemName = thePalmLocation.systemName
          .toUpperCase()
          .trim();
      }

      // this.beginDateErrorMessage = this.utilityService.validateBeginDate(
      //   thePalmLocation.lifecycle.beginDate
      // );

      if (this.beginDateErrorMessage) {
        thePalmLocationInvalid = true;
      }

      // this.endDateErrorMessage = this.utilityService.validateEndDate(
      //   thePalmLocation.lifecycle.beginDate,
      //   thePalmLocation.lifecycle.endDate
      // );

      if (this.endDateErrorMessage) {
        thePalmLocationInvalid = true;
      }
    }
    this.hasError = thePalmLocationInvalid;
    if (this.hasError) {
      this.returnCode = 700;
      this.resultMessage = 'Invalid input was detected. Please correct required/invalid fields.';
    }
    return thePalmLocationInvalid;
  }
  exportDataCallback(): void {
    let url = `/palmlocations/excelReport?includeInactive=${this.showType === 'all' ? 'true' : 'false'}`;
    if (this.searchText) {
      url += `&codePrefix=${this.searchText}`;
    }
    this.utilityService.exportTableService(
      url,
      'PALM Location Management.xls',
      'application/vnd.ms-excel'
    );
  }
  changeState(state: number): void {
    if (!this.add && !this.edit) {
      this.palmLocations.forEach((palmLocation: any) => {
        palmLocation.lifecycle.beginDate = palmLocation?.lifecycle?.beginDate || '';
        palmLocation.lifecycle.endDate = palmLocation?.lifecycle?.endDate || '';
        palmLocation.viewMode = state;
      });
    }
  }
  searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13 && !this.add && !this.edit) {
      this.search();
    }
  }
  clickedOnSort(event: any, columnName: string): void {
    this.sortColumn = columnName;
    this.sortDirection = event;
    this.skip = 0;
    this.currentPage = 1;
    this.getPalmLocationsList();
  }

  onPageChanged(page: number): void {
    this.currentPage = page;
    this.skip = (page - 1) * this.limit;
    this.getPalmLocationsList();
  }

  onPageSizeChanged(size: number): void {
    this.limit = size;
    this.currentPage = 1;
    this.skip = 0;
    this.getPalmLocationsList();
  }
  clearSearch() {
    this.searchResultsMode = false;
    this.searchText = '';
    this.currentPage = 1;
    this.skip = 0;
    this.currentSearchText = '';
    this.getPalmLocationsList();
    this.searchBoxtext = '';
  }

  validateBeginDate(): void {
    const value = this.palmLocationModel.selectedPalmLocation.lifecycle.beginDate;
    if (!value) {
      this.beginDateErrorMessage = 'Start date is required';
    } else {
      this.beginDateErrorMessage = '';
      this.validateEndDate();
    }
  }

  validateEndDate(): void {
    const beginDate = this.palmLocationModel.selectedPalmLocation.lifecycle.beginDate;
    const endDate = this.palmLocationModel.selectedPalmLocation.lifecycle.endDate;

    if (endDate && beginDate && new Date(endDate) < new Date(beginDate)) {
      this.endDateErrorMessage = 'End date must be after start date';
    } else {
      this.endDateErrorMessage = '';
    }
  }
}
