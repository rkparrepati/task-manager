import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-palm-location-details',
  templateUrl: './palm-location-details.component.html',
  styleUrls: ['./palm-location-details.component.scss'],
})
export class PalmLocationDetailsComponent {
  @Input() palmLocation: any;
}
