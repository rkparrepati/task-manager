import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
})
export class DataGridComponent implements OnInit {
  @Input() data: any[] = [];
  @Input() columns: { field: string; header: string }[] = [];
  @Input() intialSort: { column: string; direction: 'asc' | 'desc' } | null = null;
  currentSort: { column: string; direction: 'asc' | 'desc' } | null = null;
  @Input() totalRecordsCount: number = 0;
  @Input() title: string = '';
  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25, 50];

  pageEvent: any = {};
  ngOnInit() {
    if (this.intialSort) {
      this.currentSort = this.intialSort;
      this.sortData(this.currentSort.column);
    }
  }
  sortData(column: string) {
    if (this.currentSort?.column === column) {
      this.currentSort.direction = this.currentSort.direction === 'asc' ? 'desc' : 'asc';
    } else {
      this.currentSort = { column, direction: 'asc' };
    }

    this.data.sort((a, b) => {
      const valueA = a[column];
      const valueB = b[column];
      const direction = this.currentSort?.direction === 'asc' ? 1 : -1;

      if (valueA < valueB) {
        return -1 * direction;
      }
      if (valueA > valueB) {
        return 1 * direction;
      }
      return 0;
    });
  }
}
