import { Injectable } from '@angular/core';
import { UtilityService } from 'src/app/services/utility.service';
@Injectable({
  providedIn: 'root',
})
export class ActingSPEValidationsService {
  constructor(private utilityService: UtilityService) {}
  ActingSPEDetailsInfomationInvalid(
    validationBooleans: any,
    ActingSPE: any,
    userRoles: any,
    ActingSPEEmploymentType: string,
    ActingSPEAccession: any
  ) {
    let ActingSPEDetailsInfomationInvalidBoolean = false;
    if (ActingSPEEmploymentType === 'C') {
      validationBooleans.invalidFirmName = !!ActingSPE.contractorFirm ? false : true;
      ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidFirmName
        ? true
        : ActingSPEDetailsInfomationInvalidBoolean;
    }
    validationBooleans.invalidJobClassCode = !!ActingSPE.jobClass ? false : true;
    ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidJobClassCode
      ? true
      : ActingSPEDetailsInfomationInvalidBoolean;

    ActingSPEDetailsInfomationInvalidBoolean = this.validateOrgCode(
      validationBooleans,
      ActingSPE,
      ActingSPEDetailsInfomationInvalidBoolean,
      userRoles,
      ActingSPEEmploymentType
    );

    ActingSPEDetailsInfomationInvalidBoolean = this.validateEmployeeOnly(
      validationBooleans,
      ActingSPE,
      ActingSPEDetailsInfomationInvalidBoolean,
      userRoles,
      ActingSPEEmploymentType
    );

    ActingSPEDetailsInfomationInvalidBoolean = this.validateNonCoordinatorBoolean(
      validationBooleans,
      ActingSPE,
      ActingSPEDetailsInfomationInvalidBoolean,
      userRoles
    );

    ActingSPEDetailsInfomationInvalidBoolean = this.validateAccessionDate(
      validationBooleans,
      ActingSPEDetailsInfomationInvalidBoolean,
      userRoles,
      ActingSPEAccession,
      ActingSPEEmploymentType
    );

    validationBooleans.invalidTourOfDuty = !!ActingSPE.standardTourOfDuty ? false : true;
    ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidTourOfDuty
      ? true
      : ActingSPEDetailsInfomationInvalidBoolean;

    ActingSPEDetailsInfomationInvalidBoolean = this.validateSeriesCode(
      validationBooleans,
      ActingSPE,
      ActingSPEDetailsInfomationInvalidBoolean,
      userRoles,
      ActingSPEEmploymentType
    );

    return ActingSPEDetailsInfomationInvalidBoolean;
  }
  primaryInfomationInvalid(
    validationBooleans: any,
    ActingSPE: any,
    userRoles: any,
    ActingSPEEmploymentType: string,
    legacyData: any
  ) {
    validationBooleans.invalidLastName = !ActingSPE.familyName;
    let primaryInfomationInvalidBoolean = !ActingSPE.familyName;
    if (!ActingSPE.givenName) {
      validationBooleans.invalidFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidFirstName = false;
    }
    if (!ActingSPE.preferredFirstName) {
      validationBooleans.invalidPreferredFirstName = true;
      primaryInfomationInvalidBoolean = true;
    } else {
      validationBooleans.invalidPreferredFirstName = false;
    }
    // if (this.ActingSPEManagementService.canViewSecureData(userRoles, ActingSPEEmploymentType) && ActingSPEEmploymentType === 'C') {
    //     if (ActingSPE.birthDate === '01/01/0001') {
    //         validationBooleans.birthDateErrorMessage = null;
    //         validationBooleans.invalidBirthDate = false;
    //     } else {
    //         validationBooleans.birthDateErrorMessage = this.utilityService.validateDateOfBirth('Date of birth',
    //             ActingSPE.birthDate, true);
    //     }
    //     if (!!validationBooleans.birthDateErrorMessage) {
    //         validationBooleans.invalidBirthDate = true;
    //         primaryInfomationInvalidBoolean = true;
    //     }

    //     /** If legacy data is present and last 2 digits is not entered by user, then data is valid.
    //      If there is legacy data and user entered value then we validiate as before.
    //      If no legqacy data then field is required.*/
    //     if (legacyData && !ActingSPE.ssnLast2Digits) {
    //         validationBooleans.lastTwoSSNErrorMessage = false;
    //     } else {
    //         validationBooleans.lastTwoSSNErrorMessage = this.utilityService.validateLastTwoSSNInput('SSN (last 2 digits)',
    //             ActingSPE.ssnLast2Digits, true);
    //     }
    //     if (!!validationBooleans.lastTwoSSNErrorMessage) {
    //         validationBooleans.invalidLastTwoSSN = true;
    //         primaryInfomationInvalidBoolean = true;
    //     } else {
    //         validationBooleans.invalidLastTwoSSN = false;
    //     }
    // }

    return primaryInfomationInvalidBoolean;
  }
  validateOrgCode(
    validationBooleans: any,
    ActingSPE: any,
    ActingSPEDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    ActingSPEEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      ActingSPEEmploymentType === 'E'
    ) {
      if (!!validationBooleans.invalidOrgCodeErrorMsg) {
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        if (!ActingSPE.positionOrganizationListing) {
          validationBooleans.invalidOrgCodeErrorMsg = 'Org code is required';
          validationBooleans.invalidOrgCode = true;
          ActingSPEDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidOrgCodeErrorMsg = '';
          validationBooleans.invalidOrgCode = false;
        }
      }
    }
    return ActingSPEDetailsInfomationInvalidBoolean;
  }
  validateEmployeeOnly(
    validationBooleans: any,
    ActingSPE: any,
    ActingSPEDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    ActingSPEEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraContractorAdmin') < 0 && ActingSPEEmploymentType === 'E') {
      validationBooleans.invalidGrade = !!ActingSPE.grade ? false : true;
      ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidGrade
        ? true
        : ActingSPEDetailsInfomationInvalidBoolean;
      validationBooleans.invalidGradeStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Grade start date',
          ActingSPE.gradeStartDate,
          true
        );
      if (!!validationBooleans.invalidGradeStartDateErrorMsg) {
        validationBooleans.invalidGradeStartDate = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidGradeStartDate = false;
      }

      validationBooleans.invalidStep = !!ActingSPE.step ? false : true;
      ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidStep
        ? true
        : ActingSPEDetailsInfomationInvalidBoolean;
      validationBooleans.invalidStepStartDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Step start date',
          ActingSPE.stepStartDate,
          true
        );
      if (!!validationBooleans.invalidStepStartDateErrorMsg) {
        validationBooleans.invalidStepStartDate = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidStepStartDate = false;
      }
      // validationBooleans.invalidTypeAppointment = !!ActingSPE.TypeAppointment ? false : true;
      // ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidTypeAppointment ?
      //         true : ActingSPEDetailsInfomationInvalidBoolean;
      if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
        if (!ActingSPE.appointmentType) {
          validationBooleans.invalidTypeAppointment = true;
          ActingSPEDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidTypeAppointment = false;
        }
        // validationBooleans.invalidPositionSensitivity = !!ActingSPE.PositionSensitivity ? false : true;
        // ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidPositionSensitivity ?
        //         true : ActingSPEDetailsInfomationInvalidBoolean;
        if (!ActingSPE.positionSensitivity) {
          validationBooleans.invalidPositionSensitivity = true;
          ActingSPEDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidPositionSensitivity = false;
        }
        // validationBooleans.invalidLeaveAccrual = !!ActingSPE.LeaveAccural ? false : true;
        // ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidLeaveAccrual ?
        //         true : ActingSPEDetailsInfomationInvalidBoolean;
        if (!ActingSPE.leaveAccrual) {
          validationBooleans.invalidLeaveAccural = true;
          ActingSPEDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidLeaveAccural = false;
        }
        // validationBooleans.invalidBusCode = !!ActingSPE.BusCode ? false : true;
        // ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidBusCode ?
        //         true : ActingSPEDetailsInfomationInvalidBoolean;
        if (!ActingSPE.bargainUnitType) {
          validationBooleans.invalidBusCode = true;
          ActingSPEDetailsInfomationInvalidBoolean = true;
        } else {
          validationBooleans.invalidBusCode = false;
        }
      }
      if (!ActingSPE.payplan) {
        validationBooleans.invalidPayPlan = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidPayPlan = false;
      }
    }

    return ActingSPEDetailsInfomationInvalidBoolean;
  }
  validateNonCoordinatorBoolean(
    validationBooleans: any,
    ActingSPE: any,
    ActingSPEDetailsInfomationInvalidBoolean: boolean,
    userRoles: any
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0) {
      validationBooleans.invalidEntranceDutyDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Entrance on duty date',
          ActingSPE.lifecycle.beginDate,
          true
        );
      if (!!validationBooleans.invalidEntranceDutyDateErrorMsg) {
        validationBooleans.invalidEntranceDutyDate = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEntranceDutyDate = false;
      }
      validationBooleans.invalidEndDutyDateErrorMsg = this.utilityService.validateEndOfDutyDate(
        ActingSPE.lifecycle.beginDate,
        !!ActingSPE.lifecycle.endDate ? ActingSPE.lifecycle.endDate : null
      );
      if (!!validationBooleans.invalidEndDutyDateErrorMsg) {
        validationBooleans.invalidEndDutyDate = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidEndDutyDate = false;
      }
    }

    return ActingSPEDetailsInfomationInvalidBoolean;
  }
  validateAccessionDate(
    validationBooleans: any,
    ActingSPEDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    ActingSPEAccession: any,
    ActingSPEEmploymentType: string
  ) {
    if (userRoles.indexOf('InfraOfficeCoordinator') < 0 && ActingSPEEmploymentType === 'E') {
      validationBooleans.invalidAccessionDateErrorMsg =
        this.utilityService.validateGeneralDateInput(
          'Accession date',
          ActingSPEAccession.accessionDt,
          true
        );
      if (!!validationBooleans.invalidAccessionDateErrorMsg) {
        validationBooleans.invalidAccessionDate = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidAccessionDate = false;
      }
    }

    return ActingSPEDetailsInfomationInvalidBoolean;
  }

  validateSeriesCode(
    validationBooleans: any,
    ActingSPE: any,
    ActingSPEDetailsInfomationInvalidBoolean: boolean,
    userRoles: any,
    ActingSPEEmploymentType: string
  ) {
    if (
      userRoles.indexOf('InfraOfficeCoordinator') < 0 &&
      userRoles.indexOf('InfraContractorAdmin') < 0 &&
      ActingSPEEmploymentType === 'E'
    ) {
      validationBooleans.invalidOccSeriesCode = !!ActingSPE.occupationalSeries ? false : true;
      ActingSPEDetailsInfomationInvalidBoolean = validationBooleans.invalidOccSeriesCode
        ? true
        : ActingSPEDetailsInfomationInvalidBoolean;
      if (validationBooleans.occSeriesCodeLookupNoResults) {
        ActingSPEDetailsInfomationInvalidBoolean = true;
      }
      if (!ActingSPE.occupationalSeriesTitle) {
        validationBooleans.invalidTitleCode = true;
        ActingSPEDetailsInfomationInvalidBoolean = true;
      } else {
        validationBooleans.invalidTitleCode = false;
      }
      if (validationBooleans.titleCodeLookupNoResults) {
        ActingSPEDetailsInfomationInvalidBoolean = true;
      }
    }

    return ActingSPEDetailsInfomationInvalidBoolean;
  }
  confidentialInfomationInvalid(validationBooleans: any, ActingSPESecure: any) {
    let confidentialInformationInvalid = false;
    if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
      confidentialInformationInvalid = true;
    } else {
      if (ActingSPESecure) {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          this.utilityService.validateSSNInput(
            'Social security number',
            ActingSPESecure.employeeSocialSecurity,
            true
          );
      } else {
        validationBooleans.invalidEmployeeSocialSecurityErrorMsg =
          'Social security number is required';
      }

      if (!!validationBooleans.invalidEmployeeSocialSecurityErrorMsg) {
        validationBooleans.invalidEmployeeSocialSecurity = true;
        confidentialInformationInvalid = true;
      } else {
        validationBooleans.invalidEmployeeSocialSecurity = false;
      }
    }

    if (ActingSPESecure && ActingSPESecure.birthDate === '01/01/0001') {
      validationBooleans.invalidDateOfBirthErrorMsg = null;
    } else if (ActingSPESecure) {
      validationBooleans.invalidDateOfBirthErrorMsg = this.utilityService.validateDateOfBirth(
        'Date of birth',
        ActingSPESecure.birthDate,
        true
      );
    } else {
      validationBooleans.invalidDateOfBirthErrorMsg = 'Date of birth is required';
    }
    if (!!validationBooleans.invalidDateOfBirthErrorMsg) {
      validationBooleans.invalidDateOfBirth = true;
      confidentialInformationInvalid = true;
    } else {
      validationBooleans.invalidDateOfBirth = false;
    }

    return confidentialInformationInvalid;
  }
  getActingSPEAddObject(ActingSPEObj: any, employmentTypes: any) {
    let ActingSPE = this.getActingSPEPrimaryAndDetails(ActingSPEObj);
    /**
     * Set employment type
     */
    if (ActingSPE.employmentType) {
      employmentTypes.map(function (employmentType: any) {
        if (employmentType.value === ActingSPE.employmentType) {
          ActingSPE.employmentType = {
            id: employmentType.id,
            value: employmentType.value,
            description: employmentType.description,
          };
        }
      });
    }

    return ActingSPE;
  }
  getActingSPEPrimaryAndDetails(ActingSPE: any) {
    let teleworkProgram;
    if (ActingSPE.teleworkProgram && ActingSPE.teleworkProgram.id) {
      teleworkProgram = {
        teleworkProgramId: ActingSPE.teleworkProgram.id,
        hotelingIndicator: ActingSPE.teleworkProgram.hotelingIndicator,
      };
    }
    ActingSPE.teleworkProgram = teleworkProgram || null;
    ActingSPE.lifecycle = {
      beginDate: !!ActingSPE.lifecycle.beginDate
        ? this.utilityService.adjustDateFormatter(
            this.utilityService.dateFormatter(new Date(ActingSPE.lifecycle.beginDate))
          )
        : null,
      endDate: !!ActingSPE.lifecycle.endDate
        ? this.utilityService.adjustEndDateFormatter(
            this.utilityService.dateFormatterEndDate(new Date(ActingSPE.lifecycle.endDate))
          )
        : null,
    };

    /**
     * if lifecycle.endDate exists, use that value and set to organization.lifecycle.endDate
     */
    if (ActingSPE.lifecycle.endDate != undefined && ActingSPE.lifecycle.endDate != '') {
      if (ActingSPE.organizationHistory != undefined && ActingSPE.organizationHistory.length > 0) {
        ActingSPE.organizationHistory.map(function (organizationData: any, index: number) {
          organizationData.primaryOrganizationIndicator = false;
          if (
            organizationData.locationSummary != undefined &&
            organizationData.locationSummary.length > 0
          ) {
            organizationData.locationSummary[0].primaryLocationIn = false;
          }
          organizationData.lifecycle.endDate = ActingSPE.lifecycle.endDate + '.000Z';
        });
      }
    }
    if (ActingSPE.gradeStartDate) {
      ActingSPE.gradeStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(ActingSPE.gradeStartDate))
      );
    } else {
      ActingSPE.gradeStartDate = null;
    }

    if (ActingSPE.stepStartDate) {
      ActingSPE.stepStartDate = this.utilityService.adjustDateFormatter(
        this.utilityService.dateFormatter(new Date(ActingSPE.stepStartDate))
      );
    } else {
      ActingSPE.stepStartDate = null;
    }
    ActingSPE.supervisorIndicator = ActingSPE.supervisorIndicator
      ? ActingSPE.supervisorIndicator
      : false;

    if (!ActingSPE.activeEmploymentIndicator) {
      ActingSPE.activeEmploymentIndicator = false;
    } else {
      ActingSPE.activeEmploymentIndicator = true;
    }
    ActingSPE.occupationalSeriesTitle = this.getOccupationalSeries(
      ActingSPE.occupationalSeriesTitle
    );
    ActingSPE.directoryTitleType = this.getDirectoryTitleType(ActingSPE.directoryTitleType);

    return ActingSPE;
  }
  getOccupationalSeries(occupationalSeriesTitle: any) {
    let newOccupationalSeriesTitle;

    if (occupationalSeriesTitle && occupationalSeriesTitle.id) {
      newOccupationalSeriesTitle = {
        occupationalSeriesTitleId: occupationalSeriesTitle.id,
      };
    } else {
    }
    return newOccupationalSeriesTitle;
  }
  getDirectoryTitleType(directoryTitleType: any) {
    let newDirectoryTitleType: any;
    if (directoryTitleType && directoryTitleType.id) {
      newDirectoryTitleType = {
        id: directoryTitleType.id,
      };
    }
    return newDirectoryTitleType;
  }
}
