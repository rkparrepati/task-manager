import { Injectable } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { ActingSPEValidationsService } from './actingspe-validations.service';
import { Observable, forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ActingSPEService {
  constructor(
    private httpservice: HttpService,
    private appservice: AppService,
    private ActingSPEValidationsService: ActingSPEValidationsService
  ) {}

  validateContractorId(dateOfBirth: string, contractorSSN: string) {
    const url = 'actingSPEs';
    const params = {
      isContractor: true,
      includeInactive: true,
      dateOfBirth: dateOfBirth,
      contractorSSN: contractorSSN,
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const _url = `${url}?${queryParams}`;
    return this.httpservice.get(_url);
  }

  public getActingSPEs(showAll: boolean, searchText: string): Observable<any> {
    const url = `/workers?includeInactive=${showAll}&workerNumberPrefix=${searchText}&limit=10&skip=0&sortColumn=lastName&sortOrder=asc`;
    return this.httpservice.get(url);
  }

  canViewSecureData(userRoles: any, employmentType: string) {
    if (
      (employmentType === 'E' &&
        (userRoles.indexOf('InfraAdmin') >= 0 || userRoles.indexOf('InfraHRAdmin') >= 0)) ||
      userRoles.indexOf('InfraHRViewer') >= 0
    ) {
      return true;
    }

    const canViewContractorSecure =
      userRoles.indexOf('InfraAdmin') >= 0 ||
      userRoles.indexOf('InfraHRAdmin') >= 0 ||
      userRoles.indexOf('InfraContractorAdmin') >= 0 ||
      userRoles.indexOf('InfraOfficeCoordinator') >= 0;

    return employmentType === 'C' && canViewContractorSecure;
  }

  /**
   * Update Acting SPE capabilities for a worker
   * Creates, updates, and deletes capabilities based on the provided lists
   */
  public updateActingSPE(
    worker: any,
    postList: any[],
    putList: any[],
    removeList: any[],
    beginDate: string,
    endDate: string,
    userInfo: any
  ): Observable<any> {
    const requests: Observable<any>[] = [];

    // Convert dates to ISO format
    const beginDateISO = new Date(beginDate).toISOString();
    const endDateISO = new Date(endDate).toISOString();

    // Create new capabilities (POST to assign-capabilities)
    if (postList.length > 0) {
      const assignPayload = postList.map((capability: any) => ({
        worker: {
          workerId: worker.workerId
        },
        stndCapability: {
          id: capability.id
        },
        lifecycle: {
          beginDate: beginDateISO,
          endDate: endDateISO
        }
      }));
      requests.push(
        this.httpservice.post(`/workers/${worker.workerId}/assign-capabilities`, assignPayload)
      );
    }

    // Update existing capabilities (POST to update-capabilities with array payload)
    if (putList.length > 0) {
      const updatePayload = putList.map((capability: any) => ({
        workerCapabilityId: capability.workerCapabilityId,
        worker: {
          workerId: worker.workerId
        },
        stndCapability: {
          id: capability.stndCapability.id
        },
        lifecycle: {
          beginDate: beginDateISO,
          endDate: endDateISO
        }
      }));
      requests.push(
        this.httpservice.post(`/workers/${worker.workerId}/update-capabilities`, updatePayload)
      );
    }

    // Unassign/delete removed capabilities (POST to unassign-capabilities with array payload)
    if (removeList.length > 0) {
      const unassignPayload = removeList.map((capability: any) => ({
        workerCapabilityId: capability.workerCapabilityId,
        worker: {
          workerId: worker.workerId
        },
        stndCapability: {
          id: capability.stndCapability.id
        },
        lifecycle: {
          beginDate: new Date().toISOString() // Current timestamp for unassign
        }
      }));
      requests.push(
        this.httpservice.post(`/workers/${worker.workerId}/unassign-capabilities`, unassignPayload)
      );
    }

    // Execute all requests in parallel
    if (requests.length > 0) {
      return forkJoin(requests);
    } else {
      // Return empty observable if no changes
      return new Observable(observer => {
        observer.next([]);
        observer.complete();
      });
    }
  }
}
