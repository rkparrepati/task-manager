import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-capabilities-dialog',
  templateUrl: './edit-capabilities-dialog.component.html',
  styleUrls: ['./edit-capabilities-dialog.component.scss']
})
export class EditCapabilitiesDialogComponent implements OnInit {
  worker: any = {
    newCapabilityList: [],
    availableCapabilities: [],
    beginDate: null,
    endDate: null
  };
  
  allCapabilities: any[] = [];
  selectedAvailableCapabilities: any[] = [];
  selectedCapabilities: any[] = [];
  invalidStartDate: boolean = false;
  invalidEndStartDate: boolean = false;
  showValidationMessage: boolean = false;
  errorMessage: string = '';

  constructor(
    public dialogRef: MatDialogRef<EditCapabilitiesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogInfo: any
  ) {}

  ngOnInit(): void {
    // Initialize dates from existing capabilities
    if (this.dialogInfo.worker.capabilities && this.dialogInfo.worker.capabilities.length > 0) {
      const beginDate = this.dialogInfo.worker.capabilities[0].lifecycle.beginDate;
      const endDate = this.dialogInfo.worker.capabilities[0].lifecycle.endDate;
      
      // Convert dates to YYYY-MM-DD format for HTML5 date input
      this.worker.beginDate = this.formatDateForInput(beginDate);
      this.worker.endDate = this.formatDateForInput(endDate);
    } else {
      // Set empty strings when no capabilities
      this.worker.beginDate = '';
      this.worker.endDate = '';
    }

    this.allCapabilities = [];

    // Separate capabilities into available and assigned lists
    this.dialogInfo.capabilities.forEach((capability: any) => {
      if (!this.inList(capability)) {
        this.worker.availableCapabilities.push(capability);
      } else {
        this.worker.newCapabilityList.push(capability);
      }
      this.allCapabilities.push(capability);
    });

    this.worker.originalList = [...this.worker.newCapabilityList];
  }

  /**
   * Format date to YYYY-MM-DD for HTML5 date input
   */
  private formatDateForInput(dateValue: any): string {
    if (!dateValue) {
      return '';
    }

    let date: Date;
    
    // Handle different date formats
    if (dateValue instanceof Date) {
      date = dateValue;
    } else if (typeof dateValue === 'string') {
      date = new Date(dateValue);
    } else if (typeof dateValue === 'number') {
      date = new Date(dateValue);
    } else {
      return '';
    }

    // Check if date is valid
    if (isNaN(date.getTime())) {
      return '';
    }

    // Format to YYYY-MM-DD
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
  }

  /**
   * Check if capability is already assigned to worker
   */
  inList(capability: any): boolean {
    let inList = false;
    if (this.dialogInfo.worker.capabilities) {
      this.dialogInfo.worker.capabilities.forEach((item: any) => {
        if (item.stndCapability.value === capability.value) {
          inList = true;
        }
      });
    }
    return inList;
  }

  /**
   * Check if capability is in a select list
   */
  inSelectList(list: any[], capability: any): boolean {
    let inList = false;
    list.forEach((item: any) => {
      if (item.value === capability.value) {
        inList = true;
      }
    });
    return inList;
  }

  /**
   * Move selected capabilities from available to assigned
   */
  moveToAssigned(): void {
    this.selectedAvailableCapabilities.forEach((capability: any) => {
      this.worker.newCapabilityList.push(capability);
    });

    this.worker.availableCapabilities = [];
    this.allCapabilities.forEach((capability: any) => {
      if (!this.inSelectList(this.worker.newCapabilityList, capability)) {
        this.worker.availableCapabilities.push(capability);
      }
    });

    this.selectedAvailableCapabilities = [];
  }

  /**
   * Move selected capabilities from assigned to available
   */
  moveToUnassigned(): void {
    this.selectedCapabilities.forEach((aRole: any) => {
      this.worker.availableCapabilities.push(aRole);
    });

    this.selectedCapabilities = [];
    this.worker.newCapabilityList = [];
    this.allCapabilities.forEach((capability: any) => {
      if (!this.inSelectList(this.worker.availableCapabilities, capability)) {
        this.worker.newCapabilityList.push(capability);
      }
    });
  }

  /**
   * Validate and save capabilities
   */
  save(): void {
    // Validate dates
    if (!this.worker.beginDate) {
      this.invalidStartDate = true;
      this.showValidationMessage = true;
      this.errorMessage = 'Valid start date is required';
      return;
    }

    if (!this.worker.endDate) {
      this.invalidEndStartDate = true;
      this.showValidationMessage = true;
      this.errorMessage = 'Valid end date is required';
      return;
    }

    // Validate end date is after start date
    const beginDate = new Date(this.worker.beginDate);
    const endDate = new Date(this.worker.endDate);
    
    if (endDate < beginDate) {
      this.invalidEndStartDate = true;
      this.showValidationMessage = true;
      this.errorMessage = 'End date must be after start date';
      return;
    }

    // Return the updated worker data
    this.dialogRef.close(this.worker);
  }

  /**
   * Cancel and close dialog
   */
  cancel(): void {
    this.dialogRef.close();
  }
}
