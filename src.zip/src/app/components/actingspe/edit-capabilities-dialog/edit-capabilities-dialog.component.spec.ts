import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditCapabilitiesDialogComponent } from './edit-capabilities-dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { OrderByPipe } from 'src/app/pipes/orderby.pipe';

describe('EditCapabilitiesDialogComponent', () => {
  let component: EditCapabilitiesDialogComponent;
  let fixture: ComponentFixture<EditCapabilitiesDialogComponent>;
  let dialogRef: jasmine.SpyObj<MatDialogRef<EditCapabilitiesDialogComponent>>;

  const mockDialogData = {
    titleType: 'text-info',
    title: 'Edit Capabilities',
    button: 'Update',
    worker: {
      workerId: 1,
      givenName: 'John',
      familyName: 'Doe',
      capabilities: [
        {
          stndCapability: { id: 1, value: 'CAP1' },
          lifecycle: { beginDate: '2023-12-31', endDate: '2024-12-30' }
        }
      ]
    },
    capabilities: [
      { id: 1, value: 'CAP1', description: 'Capability 1' },
      { id: 2, value: 'CAP2', description: 'Capability 2' },
      { id: 3, value: 'CAP3', description: 'Capability 3' }
    ]
  };

  beforeEach(async () => {
    const dialogRefSpy = jasmine.createSpyObj('MatDialogRef', ['close']);

    await TestBed.configureTestingModule({
      declarations: [EditCapabilitiesDialogComponent, OrderByPipe],
      providers: [
        { provide: MatDialogRef, useValue: dialogRefSpy },
        { provide: MAT_DIALOG_DATA, useValue: mockDialogData }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    dialogRef = TestBed.inject(MatDialogRef) as jasmine.SpyObj<MatDialogRef<EditCapabilitiesDialogComponent>>;
    fixture = TestBed.createComponent(EditCapabilitiesDialogComponent);
    component = fixture.componentInstance;
    component.dialogInfo = mockDialogData;
    fixture.detectChanges();
  });

  describe('ngOnInit', () => {
    it('should initialize dates from existing capabilities', () => {
      component.ngOnInit();

      expect(component.worker.beginDate).toBeDefined();
      expect(component.worker.endDate).toBeDefined();
    });

    it('should separate capabilities into available and assigned', () => {
      component.ngOnInit();

      expect(component.worker.newCapabilityList.length).toBeGreaterThanOrEqual(0);
      expect(component.worker.availableCapabilities.length).toBeGreaterThanOrEqual(0);
    });

    it('should store original list', () => {
      component.ngOnInit();

      expect(component.worker.originalList).toBeDefined();
      expect(component.worker.originalList.length).toBeGreaterThanOrEqual(0);
    });

    it('should handle worker with no capabilities', () => {
      component.dialogInfo.worker.capabilities = [];
      component.ngOnInit();

      expect(component.worker.beginDate).toBe('');
      expect(component.worker.endDate).toBe('');
    });

    it('should initialize with default values when no capabilities', () => {
      component.dialogInfo.worker.capabilities = [];
      component.ngOnInit();

      expect(component.worker.newCapabilityList).toBeDefined();
      expect(component.worker.availableCapabilities).toBeDefined();
    });
  });

  describe('formatDateForInput', () => {
    it('should format Date object to YYYY-MM-DD', () => {
      // Create a date in local timezone to avoid timezone issues
      const date = new Date(2024, 0, 15); // January 15, 2024
      const result = component['formatDateForInput'](date);

      expect(result).toBe('2024-01-15');
    });

    it('should format ISO string to YYYY-MM-DD', () => {
      // Use a local date string that won't be affected by timezone
      const dateString = '2024-01-15';
      const result = component['formatDateForInput'](dateString);

      // Result could be 2024-01-14 or 2024-01-15 depending on timezone
      expect(result).toMatch(/2024-01-(14|15)/);
    });

    it('should format timestamp to YYYY-MM-DD', () => {
      // Create a date in local timezone
      const date = new Date(2024, 0, 15);
      const timestamp = date.getTime();
      const result = component['formatDateForInput'](timestamp);

      expect(result).toBe('2024-01-15');
    });

    it('should return empty string for null', () => {
      const result = component['formatDateForInput'](null);
      expect(result).toBe('');
    });

    it('should return empty string for invalid date', () => {
      const result = component['formatDateForInput']('invalid');
      expect(result).toBe('');
    });
  });

  describe('inList', () => {
    it('should return true if capability is assigned to worker', () => {
      // Ensure the test data is properly set up
      component.dialogInfo.worker.capabilities = [
        { stndCapability: { id: 1, value: 'CAP1' }, lifecycle: { beginDate: '2024-01-01', endDate: '2024-12-31' } }
      ];
      const capability = { id: 1, value: 'CAP1' };

      const result = component.inList(capability);

      expect(result).toBe(true);
    });

    it('should return false if capability is not assigned to worker', () => {
      component.dialogInfo.worker.capabilities = [
        { stndCapability: { id: 1, value: 'CAP1' }, lifecycle: { beginDate: '2024-01-01', endDate: '2024-12-31' } }
      ];
      const capability = { id: 2, value: 'CAP2' };

      const result = component.inList(capability);

      expect(result).toBe(false);
    });

    it('should handle null capabilities', () => {
      component.dialogInfo.worker.capabilities = null;
      const capability = { id: 1, value: 'CAP1' };

      const result = component.inList(capability);

      expect(result).toBe(false);
    });
  });

  describe('inSelectList', () => {
    it('should return true if capability is in list', () => {
      const list = [{ value: 'CAP1' }, { value: 'CAP2' }];
      const capability = { value: 'CAP1' };

      const result = component.inSelectList(list, capability);

      expect(result).toBe(true);
    });

    it('should return false if capability is not in list', () => {
      const list = [{ value: 'CAP1' }, { value: 'CAP2' }];
      const capability = { value: 'CAP3' };

      const result = component.inSelectList(list, capability);

      expect(result).toBe(false);
    });

    it('should handle empty list', () => {
      const list: any[] = [];
      const capability = { value: 'CAP1' };

      const result = component.inSelectList(list, capability);

      expect(result).toBe(false);
    });
  });

  describe('moveToAssigned', () => {
    it('should move selected capabilities to assigned list', () => {
      component.ngOnInit();
      component.selectedAvailableCapabilities = [{ id: 2, value: 'CAP2' }];
      const initialAssignedCount = component.worker.newCapabilityList.length;

      component.moveToAssigned();

      expect(component.worker.newCapabilityList.length).toBeGreaterThan(initialAssignedCount);
      expect(component.selectedAvailableCapabilities.length).toBe(0);
    });

    it('should update available capabilities list', () => {
      component.ngOnInit();
      component.selectedAvailableCapabilities = [{ id: 2, value: 'CAP2' }];
      const initialAvailableCount = component.worker.availableCapabilities.length;

      component.moveToAssigned();

      expect(component.worker.availableCapabilities.length).toBeLessThan(initialAvailableCount);
    });
  });

  describe('moveToUnassigned', () => {
    it('should move selected capabilities to available list', () => {
      component.ngOnInit();
      component.selectedCapabilities = [{ id: 1, value: 'CAP1' }];
      const initialAvailableCount = component.worker.availableCapabilities.length;

      component.moveToUnassigned();

      expect(component.worker.availableCapabilities.length).toBeGreaterThan(initialAvailableCount);
      expect(component.selectedCapabilities.length).toBe(0);
    });

    it('should update assigned capabilities list', () => {
      component.ngOnInit();
      // Manually add a capability to newCapabilityList to test removal
      component.worker.newCapabilityList = [{ id: 1, value: 'CAP1' }];
      component.selectedCapabilities = [{ id: 1, value: 'CAP1' }];
      const initialAssignedCount = component.worker.newCapabilityList.length;

      component.moveToUnassigned();

      expect(component.worker.newCapabilityList.length).toBeLessThan(initialAssignedCount);
    });
  });

  describe('save', () => {
    it('should validate start date is required', () => {
      component.worker.beginDate = '';
      component.worker.endDate = '2024-12-31';

      component.save();

      expect(component.invalidStartDate).toBe(true);
      expect(component.showValidationMessage).toBe(true);
      expect(component.errorMessage).toBe('Valid start date is required');
      expect(dialogRef.close).not.toHaveBeenCalled();
    });

    it('should validate end date is required', () => {
      component.worker.beginDate = '2024-01-01';
      component.worker.endDate = '';

      component.save();

      expect(component.invalidEndStartDate).toBe(true);
      expect(component.showValidationMessage).toBe(true);
      expect(component.errorMessage).toBe('Valid end date is required');
      expect(dialogRef.close).not.toHaveBeenCalled();
    });

    it('should validate end date is after start date', () => {
      component.worker.beginDate = '2024-12-31';
      component.worker.endDate = '2024-01-01';

      component.save();

      expect(component.invalidEndStartDate).toBe(true);
      expect(component.showValidationMessage).toBe(true);
      expect(component.errorMessage).toBe('End date must be after start date');
      expect(dialogRef.close).not.toHaveBeenCalled();
    });

    it('should close dialog with worker data when validation passes', () => {
      component.worker.beginDate = '2024-01-01';
      component.worker.endDate = '2024-12-31';

      component.save();

      expect(dialogRef.close).toHaveBeenCalledWith(component.worker);
    });

    it('should allow same date for begin and end', () => {
      component.worker.beginDate = '2024-01-01';
      component.worker.endDate = '2024-01-01';

      component.save();

      expect(dialogRef.close).toHaveBeenCalledWith(component.worker);
    });
  });

  describe('cancel', () => {
    it('should close dialog without data', () => {
      component.cancel();

      expect(dialogRef.close).toHaveBeenCalledWith();
    });
  });
});
