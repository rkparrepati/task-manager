import { TestBed } from '@angular/core/testing';
import { ActingSPEValidationsService } from './actingspe-validations.service';
import { UtilityService } from 'src/app/services/utility.service';

describe('ActingSPEValidationsService', () => {
  let service: ActingSPEValidationsService;
  let utilityService: jasmine.SpyObj<UtilityService>;

  beforeEach(() => {
    const utilityServiceSpy = jasmine.createSpyObj('UtilityService', [
      'validateDateOfBirth',
      'validateLastTwoSSNInput',
      'validateGeneralDateInput',
      'validateEndOfDutyDate',
      'validateSSNInput',
      'adjustDateFormatter',
      'dateFormatter',
      'adjustEndDateFormatter',
      'dateFormatterEndDate'
    ]);

    TestBed.configureTestingModule({
      providers: [
        ActingSPEValidationsService,
        { provide: UtilityService, useValue: utilityServiceSpy }
      ]
    });

    service = TestBed.inject(ActingSPEValidationsService);
    utilityService = TestBed.inject(UtilityService) as jasmine.SpyObj<UtilityService>;
  });

  describe('ActingSPEDetailsInfomationInvalid', () => {
    it('should validate contractor firm name is required', () => {
      const validationBooleans: any = {};
      const actingSPE = { contractorFirm: null, jobClass: 'JC1', lifecycle: { beginDate: null, endDate: null } };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';
      const accession = {};

      service.ActingSPEDetailsInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, accession);

      expect(validationBooleans.invalidFirmName).toBe(true);
    });

    it('should validate job class code is required', () => {
      const validationBooleans: any = {};
      const actingSPE = { contractorFirm: 'Firm1', jobClass: null, lifecycle: { beginDate: null, endDate: null } };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';
      const accession = {};

      service.ActingSPEDetailsInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, accession);

      expect(validationBooleans.invalidJobClassCode).toBe(true);
    });

    it('should validate tour of duty is required', () => {
      const validationBooleans: any = {};
      const actingSPE = {
        contractorFirm: 'Firm1',
        jobClass: 'JC1',
        standardTourOfDuty: null,
        positionOrganizationListing: 'ORG1',
        lifecycle: { beginDate: null, endDate: null }
      };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';
      const accession = {};

      service.ActingSPEDetailsInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, accession);

      expect(validationBooleans.invalidTourOfDuty).toBe(true);
    });

    it('should return true if any validation fails', () => {
      const validationBooleans: any = {};
      const actingSPE = { contractorFirm: null, jobClass: 'JC1', lifecycle: { beginDate: null, endDate: null } };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';
      const accession = {};

      const result = service.ActingSPEDetailsInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, accession);

      expect(result).toBe(true);
    });
  });

  describe('primaryInfomationInvalid', () => {
    it('should validate last name is required', () => {
      const validationBooleans: any = {};
      const actingSPE = { familyName: '', givenName: 'John', preferredFirstName: 'Johnny' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';
      const legacyData = null;

      const result = service.primaryInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, legacyData);

      expect(validationBooleans.invalidLastName).toBe(true);
      expect(result).toBe(true);
    });

    it('should validate first name is required', () => {
      const validationBooleans: any = {};
      const actingSPE = { familyName: 'Doe', givenName: '', preferredFirstName: 'Johnny' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';
      const legacyData = null;

      const result = service.primaryInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, legacyData);

      expect(validationBooleans.invalidFirstName).toBe(true);
      expect(result).toBe(true);
    });

    it('should validate preferred first name is required', () => {
      const validationBooleans: any = {};
      const actingSPE = { familyName: 'Doe', givenName: 'John', preferredFirstName: '' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';
      const legacyData = null;

      const result = service.primaryInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, legacyData);

      expect(validationBooleans.invalidPreferredFirstName).toBe(true);
      expect(result).toBe(true);
    });

    it('should return false if all required fields are present', () => {
      const validationBooleans: any = {};
      const actingSPE = { familyName: 'Doe', givenName: 'John', preferredFirstName: 'Johnny' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';
      const legacyData = null;

      const result = service.primaryInfomationInvalid(validationBooleans, actingSPE, userRoles, employmentType, legacyData);

      expect(result).toBe(false);
    });
  });

  describe('validateOrgCode', () => {
    it('should require org code for non-coordinator, non-contractor-admin employee', () => {
      const validationBooleans: any = {};
      const actingSPE = { positionOrganizationListing: null };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      utilityService.validateGeneralDateInput.and.returnValue(null);

      const result = service.validateOrgCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOrgCode).toBe(true);
      expect(result).toBe(true);
    });

    it('should not require org code for coordinator', () => {
      const validationBooleans: any = {};
      const actingSPE = { positionOrganizationListing: null };
      const userRoles = ['InfraOfficeCoordinator'];
      const employmentType = 'E';

      const result = service.validateOrgCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOrgCode).toBeUndefined();
      expect(result).toBe(false);
    });

    it('should not require org code for contractor', () => {
      const validationBooleans: any = {};
      const actingSPE = { positionOrganizationListing: null };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';

      const result = service.validateOrgCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOrgCode).toBeUndefined();
      expect(result).toBe(false);
    });
  });

  describe('validateEmployeeOnly', () => {
    it('should validate grade for non-contractor-admin employee', () => {
      const validationBooleans: any = {};
      const actingSPE = { grade: null, gradeStartDate: '2024-01-01', step: 'S1', stepStartDate: '2024-01-01', payplan: 'PP1' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      utilityService.validateGeneralDateInput.and.returnValue(null);

      const result = service.validateEmployeeOnly(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidGrade).toBe(true);
      expect(result).toBe(true);
    });

    it('should not validate grade for contractor admin', () => {
      const validationBooleans: any = {};
      const actingSPE = { grade: null };
      const userRoles = ['InfraContractorAdmin'];
      const employmentType = 'E';

      const result = service.validateEmployeeOnly(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidGrade).toBeUndefined();
      expect(result).toBe(false);
    });

    it('should validate step start date', () => {
      const validationBooleans: any = {};
      const actingSPE = { grade: 'G1', gradeStartDate: '2024-01-01', step: 'S1', stepStartDate: '', payplan: 'PP1' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      utilityService.validateGeneralDateInput.and.returnValue('Invalid date');

      const result = service.validateEmployeeOnly(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidStepStartDate).toBe(true);
    });
  });

  describe('validateNonCoordinatorBoolean', () => {
    it('should validate entrance on duty date for non-coordinator', () => {
      const validationBooleans: any = {};
      const actingSPE = { lifecycle: { beginDate: '', endDate: null } };
      const userRoles = ['InfraAdmin'];

      utilityService.validateGeneralDateInput.and.returnValue('Invalid date');
      utilityService.validateEndOfDutyDate.and.returnValue(null);

      const result = service.validateNonCoordinatorBoolean(validationBooleans, actingSPE, false, userRoles);

      expect(validationBooleans.invalidEntranceDutyDate).toBe(true);
      expect(result).toBe(true);
    });

    it('should not validate for coordinator', () => {
      const validationBooleans: any = {};
      const actingSPE = { lifecycle: { beginDate: '', endDate: null } };
      const userRoles = ['InfraOfficeCoordinator'];

      const result = service.validateNonCoordinatorBoolean(validationBooleans, actingSPE, false, userRoles);

      expect(validationBooleans.invalidEntranceDutyDate).toBeUndefined();
      expect(result).toBe(false);
    });

    it('should validate end of duty date', () => {
      const validationBooleans: any = {};
      const actingSPE = { lifecycle: { beginDate: '2024-01-01', endDate: '2024-12-31' } };
      const userRoles = ['InfraAdmin'];

      utilityService.validateGeneralDateInput.and.returnValue(null);
      utilityService.validateEndOfDutyDate.and.returnValue('End date must be after start date');

      const result = service.validateNonCoordinatorBoolean(validationBooleans, actingSPE, false, userRoles);

      expect(validationBooleans.invalidEndDutyDate).toBe(true);
      expect(result).toBe(true);
    });
  });

  describe('validateAccessionDate', () => {
    it('should validate accession date for non-coordinator employee', () => {
      const validationBooleans: any = {};
      const accession = { accessionDt: '' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      utilityService.validateGeneralDateInput.and.returnValue('Invalid date');

      const result = service.validateAccessionDate(validationBooleans, false, userRoles, accession, employmentType);

      expect(validationBooleans.invalidAccessionDate).toBe(true);
      expect(result).toBe(true);
    });

    it('should not validate for coordinator', () => {
      const validationBooleans: any = {};
      const accession = { accessionDt: '' };
      const userRoles = ['InfraOfficeCoordinator'];
      const employmentType = 'E';

      const result = service.validateAccessionDate(validationBooleans, false, userRoles, accession, employmentType);

      expect(validationBooleans.invalidAccessionDate).toBeUndefined();
      expect(result).toBe(false);
    });

    it('should not validate for contractor', () => {
      const validationBooleans: any = {};
      const accession = { accessionDt: '' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'C';

      const result = service.validateAccessionDate(validationBooleans, false, userRoles, accession, employmentType);

      expect(validationBooleans.invalidAccessionDate).toBeUndefined();
      expect(result).toBe(false);
    });
  });

  describe('validateSeriesCode', () => {
    it('should validate occupational series code for non-coordinator, non-contractor-admin employee', () => {
      const validationBooleans: any = {};
      const actingSPE = { occupationalSeries: null, occupationalSeriesTitle: 'Title1' };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      const result = service.validateSeriesCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOccSeriesCode).toBe(true);
      expect(result).toBe(true);
    });

    it('should validate title code', () => {
      const validationBooleans: any = {};
      const actingSPE = { occupationalSeries: 'Series1', occupationalSeriesTitle: null };
      const userRoles = ['InfraAdmin'];
      const employmentType = 'E';

      const result = service.validateSeriesCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidTitleCode).toBe(true);
      expect(result).toBe(true);
    });

    it('should not validate for coordinator', () => {
      const validationBooleans: any = {};
      const actingSPE = { occupationalSeries: null, occupationalSeriesTitle: null };
      const userRoles = ['InfraOfficeCoordinator'];
      const employmentType = 'E';

      const result = service.validateSeriesCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOccSeriesCode).toBeUndefined();
      expect(result).toBe(false);
    });

    it('should not validate for contractor admin', () => {
      const validationBooleans: any = {};
      const actingSPE = { occupationalSeries: null, occupationalSeriesTitle: null };
      const userRoles = ['InfraContractorAdmin'];
      const employmentType = 'E';

      const result = service.validateSeriesCode(validationBooleans, actingSPE, false, userRoles, employmentType);

      expect(validationBooleans.invalidOccSeriesCode).toBeUndefined();
      expect(result).toBe(false);
    });
  });

  describe('confidentialInfomationInvalid', () => {
    it('should validate SSN is required', () => {
      const validationBooleans: any = {};
      const actingSPESecure = { employeeSocialSecurity: '', birthDate: '01/15/1990' };

      utilityService.validateSSNInput.and.returnValue('Invalid SSN');
      utilityService.validateDateOfBirth.and.returnValue(null);

      const result = service.confidentialInfomationInvalid(validationBooleans, actingSPESecure);

      expect(validationBooleans.invalidEmployeeSocialSecurity).toBe(true);
      expect(result).toBe(true);
    });

    it('should validate date of birth', () => {
      const validationBooleans: any = {};
      const actingSPESecure = { employeeSocialSecurity: '123-45-6789', birthDate: '01/15/1990' };

      utilityService.validateSSNInput.and.returnValue(null);
      utilityService.validateDateOfBirth.and.returnValue('Invalid date');

      const result = service.confidentialInfomationInvalid(validationBooleans, actingSPESecure);

      expect(validationBooleans.invalidDateOfBirth).toBe(true);
      expect(result).toBe(true);
    });

    it('should skip validation for default birth date', () => {
      const validationBooleans: any = {};
      const actingSPESecure = { employeeSocialSecurity: '123-45-6789', birthDate: '01/01/0001' };

      utilityService.validateSSNInput.and.returnValue(null);

      const result = service.confidentialInfomationInvalid(validationBooleans, actingSPESecure);

      expect(validationBooleans.invalidDateOfBirthErrorMsg).toBeNull();
      expect(result).toBe(false);
    });

    it('should handle missing secure data', () => {
      const validationBooleans: any = {};
      const actingSPESecure = null;

      utilityService.validateSSNInput.and.returnValue('Social security number is required');

      const result = service.confidentialInfomationInvalid(validationBooleans, actingSPESecure);

      expect(validationBooleans.invalidEmployeeSocialSecurityErrorMsg).toBe('Social security number is required');
      expect(result).toBe(true);
    });
  });

  describe('getActingSPEAddObject', () => {
    it('should map employment type correctly', () => {
      const actingSPEObj = {
        employmentType: 'E',
        givenName: 'John',
        lifecycle: { beginDate: null, endDate: null }
      };
      const employmentTypes = [
        { id: 1, value: 'E', description: 'Employee' },
        { id: 2, value: 'C', description: 'Contractor' }
      ];

      utilityService.dateFormatter.and.returnValue('2024-01-15');
      utilityService.adjustDateFormatter.and.returnValue('2024-01-15');
      utilityService.dateFormatterEndDate.and.returnValue('2024-01-15');
      utilityService.adjustEndDateFormatter.and.returnValue('2024-01-15');

      const result = service.getActingSPEAddObject(actingSPEObj, employmentTypes);

      expect(result.employmentType.id).toBe(1);
      expect(result.employmentType.value).toBe('E');
    });

    it('should handle missing employment type', () => {
      const actingSPEObj = {
        givenName: 'John',
        lifecycle: { beginDate: null, endDate: null }
      };
      const employmentTypes = [
        { id: 1, value: 'E', description: 'Employee' }
      ];

      utilityService.dateFormatter.and.returnValue('2024-01-15');
      utilityService.adjustDateFormatter.and.returnValue('2024-01-15');
      utilityService.dateFormatterEndDate.and.returnValue('2024-01-15');
      utilityService.adjustEndDateFormatter.and.returnValue('2024-01-15');

      const result = service.getActingSPEAddObject(actingSPEObj, employmentTypes);

      expect(result.employmentType).toBeUndefined();
    });
  });

  describe('getActingSPEPrimaryAndDetails', () => {
    it('should handle null dates', () => {
      const actingSPE = {
        lifecycle: { beginDate: null, endDate: null },
        gradeStartDate: null,
        stepStartDate: null,
        supervisorIndicator: false,
        activeEmploymentIndicator: false,
        occupationalSeriesTitle: null,
        directoryTitleType: null,
        organizationHistory: []
      };

      utilityService.dateFormatter.and.returnValue('2024-01-01');
      utilityService.adjustDateFormatter.and.returnValue('2024-01-01');

      const result = service.getActingSPEPrimaryAndDetails(actingSPE);

      expect(result.lifecycle.beginDate).toBeNull();
      expect(result.lifecycle.endDate).toBeNull();
      expect(result.gradeStartDate).toBeNull();
      expect(result.stepStartDate).toBeNull();
    });

    it('should set supervisorIndicator to false if not provided', () => {
      const actingSPE = {
        lifecycle: { beginDate: null, endDate: null },
        activeEmploymentIndicator: true,
        occupationalSeriesTitle: null,
        directoryTitleType: null,
        organizationHistory: []
      };

      const result = service.getActingSPEPrimaryAndDetails(actingSPE);

      expect(result.supervisorIndicator).toBe(false);
    });

    it('should set activeEmploymentIndicator to false if not provided', () => {
      const actingSPE = {
        lifecycle: { beginDate: null, endDate: null },
        supervisorIndicator: false,
        occupationalSeriesTitle: null,
        directoryTitleType: null,
        organizationHistory: []
      };

      const result = service.getActingSPEPrimaryAndDetails(actingSPE);

      expect(result.activeEmploymentIndicator).toBe(false);
    });

    describe('Organization History EndDate Mapping', () => {
      it('should set endDate on organizationHistory when lifecycle.endDate is defined', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].lifecycle.endDate).toBe('2024-12-31.000Z');
      });

      it('should skip endDate mapping when lifecycle.endDate is undefined', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: undefined },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: 'original-value' },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].lifecycle.endDate).toBe('original-value');
      });

      it('should skip endDate mapping when lifecycle.endDate is empty string', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: 'original-value' },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('');
        utilityService.adjustDateFormatter.and.returnValue('');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].lifecycle.endDate).toBe('original-value');
      });

      it('should skip organizationHistory mapping when organizationHistory is undefined', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: undefined
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory).toBeUndefined();
      });

      it('should skip organizationHistory mapping when organizationHistory is empty array', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: []
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory.length).toBe(0);
      });

      it('should set primaryOrganizationIndicator to false for all organizations', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            },
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].primaryOrganizationIndicator).toBe(false);
        expect(result.organizationHistory[1].primaryOrganizationIndicator).toBe(false);
      });

      it('should set primaryLocationIn to false for first location when locationSummary exists', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: [
                { primaryLocationIn: true, buildingCode: 'BLD001' },
                { primaryLocationIn: true, buildingCode: 'BLD002' }
              ]
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].locationSummary[0].primaryLocationIn).toBe(false);
        expect(result.organizationHistory[0].locationSummary[1].primaryLocationIn).toBe(true);
      });

      it('should not set primaryLocationIn when locationSummary is undefined', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: undefined
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].locationSummary).toBeUndefined();
      });

      it('should not set primaryLocationIn when locationSummary is empty array', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].locationSummary.length).toBe(0);
      });

      it('should append .000Z to endDate for all organizations in organizationHistory', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            },
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            },
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].lifecycle.endDate).toBe('2024-12-31.000Z');
        expect(result.organizationHistory[1].lifecycle.endDate).toBe('2024-12-31.000Z');
        expect(result.organizationHistory[2].lifecycle.endDate).toBe('2024-12-31.000Z');
      });

      it('should handle complex organizationHistory with mixed locationSummary states', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-06-15' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: [
                { primaryLocationIn: true, buildingCode: 'BLD001' }
              ]
            },
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: undefined
            },
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-06-15');
        utilityService.dateFormatterEndDate.and.returnValue('2024-06-15');
        utilityService.adjustDateFormatter.and.returnValue('2024-06-15');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-06-15');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].primaryOrganizationIndicator).toBe(false);
        expect(result.organizationHistory[0].locationSummary[0].primaryLocationIn).toBe(false);
        expect(result.organizationHistory[0].lifecycle.endDate).toBe('2024-06-15.000Z');

        expect(result.organizationHistory[1].primaryOrganizationIndicator).toBe(false);
        expect(result.organizationHistory[1].locationSummary).toBeUndefined();
        expect(result.organizationHistory[1].lifecycle.endDate).toBe('2024-06-15.000Z');

        expect(result.organizationHistory[2].primaryOrganizationIndicator).toBe(false);
        expect(result.organizationHistory[2].locationSummary.length).toBe(0);
        expect(result.organizationHistory[2].lifecycle.endDate).toBe('2024-06-15.000Z');
      });

      it('should preserve other organization properties while mapping endDate', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2024-12-31' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              organizationId: 'ORG123',
              organizationName: 'Test Organization',
              primaryOrganizationIndicator: true,
              lifecycle: { beginDate: '2020-01-01', endDate: null },
              locationSummary: [
                { buildingCode: 'BLD001', floor: '1' }
              ]
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2024-12-31');
        utilityService.dateFormatterEndDate.and.returnValue('2024-12-31');
        utilityService.adjustDateFormatter.and.returnValue('2024-12-31');
        utilityService.adjustEndDateFormatter.and.returnValue('2024-12-31');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].organizationId).toBe('ORG123');
        expect(result.organizationHistory[0].organizationName).toBe('Test Organization');
        expect(result.organizationHistory[0].lifecycle.beginDate).toBe('2020-01-01');
        expect(result.organizationHistory[0].lifecycle.endDate).toBe('2024-12-31.000Z');
        expect(result.organizationHistory[0].locationSummary[0].buildingCode).toBe('BLD001');
        expect(result.organizationHistory[0].locationSummary[0].floor).toBe('1');
      });

      it('should handle different endDate formats correctly', () => {
        const actingSPE = {
          lifecycle: { beginDate: null, endDate: '2025-03-15' },
          gradeStartDate: null,
          stepStartDate: null,
          supervisorIndicator: false,
          activeEmploymentIndicator: false,
          occupationalSeriesTitle: null,
          directoryTitleType: null,
          organizationHistory: [
            {
              primaryOrganizationIndicator: true,
              lifecycle: { endDate: null },
              locationSummary: []
            }
          ]
        };

        utilityService.dateFormatter.and.returnValue('2025-03-15');
        utilityService.dateFormatterEndDate.and.returnValue('2025-03-15');
        utilityService.adjustDateFormatter.and.returnValue('2025-03-15');
        utilityService.adjustEndDateFormatter.and.returnValue('2025-03-15');

        const result = service.getActingSPEPrimaryAndDetails(actingSPE);

        expect(result.organizationHistory[0].lifecycle.endDate).toBe('2025-03-15.000Z');
      });
    });
  });

  describe('getOccupationalSeries', () => {
    it('should return object with occupationalSeriesTitleId', () => {
      const occupationalSeriesTitle = { id: 1, description: 'Series 1' };

      const result = service.getOccupationalSeries(occupationalSeriesTitle);

      expect(result).toEqual({ occupationalSeriesTitleId: 1 });
    });

    it('should return undefined if no id', () => {
      const occupationalSeriesTitle = { description: 'Series 1' };

      const result = service.getOccupationalSeries(occupationalSeriesTitle);

      expect(result).toBeUndefined();
    });
  });

  describe('getDirectoryTitleType', () => {
    it('should return object with id', () => {
      const directoryTitleType = { id: 1, description: 'Title 1' };

      const result = service.getDirectoryTitleType(directoryTitleType);

      expect(result).toEqual({ id: 1 });
    });

    it('should return undefined if no id', () => {
      const directoryTitleType = { description: 'Title 1' };

      const result = service.getDirectoryTitleType(directoryTitleType);

      expect(result).toBeUndefined();
    });
  });
});
