import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { of } from 'rxjs';
import { ActingSPEComponent } from './actingspe.component';
import { ActingSPEService } from './actingspe.service';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { HttpService } from 'src/app/services/http.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';

/**
 * Test suite for ActingSPEComponent query parameter building in handleAdvancedSearch
 * Tests the code snippet provided for building query parameters from search criteria
 */
describe('ActingSPEComponent - Query Parameter Building', () => {
  let component: ActingSPEComponent;
  let fixture: ComponentFixture<ActingSPEComponent>;
  let httpService: jasmine.SpyObj<HttpService>;

  const mockSearchResults = {
    meta: { total: 2 },
    results: [
      {
        workerId: 1,
        workerNumber: '12345',
        givenName: 'John',
        familyName: 'Doe',
        organizationHistory: [
          {
            primaryOrganizationIndicator: true,
            organization: {
              businessAreaCode: 'BA1',
              shortName: 'ORG1'
            }
          }
        ]
      }
    ]
  };

  beforeEach(async () => {
    const appServiceSpy = jasmine.createSpyObj('AppService', ['getUserData', 'changePage']);
    const localStorageServiceSpy = jasmine.createSpyObj('LocalStorageService', ['setItem', 'removeItem']);
    const actingSPEServiceSpy = jasmine.createSpyObj('ActingSPEService', ['getActingSPEs', 'updateActingSPE']);
    const httpServiceSpy = jasmine.createSpyObj('HttpService', ['get', 'post']);
    const matDialogSpy = jasmine.createSpyObj('MatDialog', ['open']);

    await TestBed.configureTestingModule({
      declarations: [ActingSPEComponent],
      imports: [HttpClientTestingModule, MatDialogModule],
      providers: [
        { provide: AppService, useValue: appServiceSpy },
        { provide: LocalStorageService, useValue: localStorageServiceSpy },
        { provide: ActingSPEService, useValue: actingSPEServiceSpy },
        { provide: HttpService, useValue: httpServiceSpy },
        { provide: MatDialog, useValue: matDialogSpy }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    httpService = TestBed.inject(HttpService) as jasmine.SpyObj<HttpService>;
    fixture = TestBed.createComponent(ActingSPEComponent);
    component = fixture.componentInstance;
  });

  describe('handleAdvancedSearch - preferredFirstName parameter', () => {
    it('should add preferredFirstName to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: 'Johnny' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(httpService.get).toHaveBeenCalled();
      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('preferredFirstName=Johnny');
    }));

    it('should skip preferredFirstName when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('preferredFirstName=');
    }));

    it('should skip preferredFirstName when description is undefined', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('preferredFirstName=');
    }));

    it('should encode special characters in preferredFirstName', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: 'John & Jane' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      // encodeURIComponent encodes & as %26 and spaces as %20
      expect(callArgs).toContain('preferredFirstName=John%20%26%20Jane');
    }));
  });

  describe('handleAdvancedSearch - loginId parameter', () => {
    it('should add loginId to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        loginId: { value: 'loginId', description: 'jdoe' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('loginId=jdoe');
    }));

    it('should encode email addresses in loginId', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        loginId: { value: 'loginId', description: 'user@domain.com' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('loginId=user%40domain.com');
    }));

    it('should skip loginId when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        loginId: { value: 'loginId', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('loginId=');
    }));
  });

  describe('handleAdvancedSearch - ssn2 parameter', () => {
    it('should add ssn2 to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        ssn2: { value: 'ssn2', description: '123-45-6789' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('ssn2=123-45-6789');
    }));

    it('should skip ssn2 when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        ssn2: { value: 'ssn2', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('ssn2=');
    }));
  });

  describe('handleAdvancedSearch - birthDate parameter', () => {
    it('should add birthDate to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        birthDate: { value: 'birthDate', description: '1990-01-15' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('birthDate=1990-01-15');
    }));

    it('should skip birthDate when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        birthDate: { value: 'birthDate', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('birthDate=');
    }));
  });

  describe('handleAdvancedSearch - classCode parameter', () => {
    it('should add classCode to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        classCode: { value: 'classCode', description: 'CC001' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('classCode=CC001');
    }));

    it('should skip classCode when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        classCode: { value: 'classCode', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('classCode=');
    }));
  });

  describe('handleAdvancedSearch - firmName parameter', () => {
    it('should add firmName to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        firmName: { value: 'firmName', description: 'Acme Corp' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('firmName=Acme%20Corp');
    }));

    it('should encode special characters in firmName', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        firmName: { value: 'firmName', description: 'Smith & Associates' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('firmName=Smith%20%26%20Associates');
    }));

    it('should skip firmName when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        firmName: { value: 'firmName', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('firmName=');
    }));
  });

  describe('handleAdvancedSearch - firmAdministrator parameter', () => {
    it('should add firmAdministrator to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        firmAdministrator: { value: 'firmAdministrator', description: 'Admin User' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('firmAdministrator=Admin%20User');
    }));

    it('should skip firmAdministrator when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        firmAdministrator: { value: 'firmAdministrator', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('firmAdministrator=');
    }));
  });

  describe('handleAdvancedSearch - businessAreaCode parameter', () => {
    it('should add businessAreaCode to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        businessAreaCode: { value: 'businessAreaCode', description: 'BA001' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('businessAreaCode=BA001');
    }));

    it('should skip businessAreaCode when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        businessAreaCode: { value: 'businessAreaCode', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('businessAreaCode=');
    }));
  });

  describe('handleAdvancedSearch - shortName parameter', () => {
    it('should add shortName to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        shortName: { value: 'shortName', description: 'ORG1' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('shortName=ORG1');
    }));

    it('should skip shortName when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        shortName: { value: 'shortName', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('shortName=');
    }));
  });

  describe('handleAdvancedSearch - phoneNumber parameter', () => {
    it('should add phoneNumber to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        phoneNumber: { value: 'phoneNumber', description: '555-1234' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('phoneNumber=555-1234');
    }));

    it('should encode special characters in phoneNumber', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        phoneNumber: { value: 'phoneNumber', description: '(555) 123-4567' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('phoneNumber=(555)%20123-4567');
    }));

    it('should skip phoneNumber when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        phoneNumber: { value: 'phoneNumber', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('phoneNumber=');
    }));
  });

  describe('handleAdvancedSearch - buildingCode parameter', () => {
    it('should add buildingCode to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        buildingCode: { value: 'buildingCode', description: 'BLDG-001' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('buildingCode=BLDG-001');
    }));

    it('should skip buildingCode when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        buildingCode: { value: 'buildingCode', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('buildingCode=');
    }));
  });

  describe('handleAdvancedSearch - floorNumber parameter', () => {
    it('should add floorNumber to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        floorNumber: { value: 'floorNumber', description: '5' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('floorNumber=5');
    }));

    it('should skip floorNumber when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        floorNumber: { value: 'floorNumber', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('floorNumber=');
    }));
  });

  describe('handleAdvancedSearch - corridorId parameter', () => {
    it('should add corridorId to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        corridorId: { value: 'corridorId', description: 'COR-A' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('corridorId=COR-A');
    }));

    it('should skip corridorId when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        corridorId: { value: 'corridorId', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('corridorId=');
    }));
  });

  describe('handleAdvancedSearch - roomId parameter', () => {
    it('should add roomId to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        roomId: { value: 'roomId', description: 'ROOM-101' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('roomId=ROOM-101');
    }));

    it('should skip roomId when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        roomId: { value: 'roomId', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('roomId=');
    }));
  });

  describe('handleAdvancedSearch - suiteId parameter', () => {
    it('should add suiteId to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        suiteId: { value: 'suiteId', description: 'SUITE-A' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('suiteId=SUITE-A');
    }));

    it('should skip suiteId when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        suiteId: { value: 'suiteId', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('suiteId=');
    }));
  });

  describe('handleAdvancedSearch - zoneId parameter', () => {
    it('should add zoneId to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        zoneId: { value: 'zoneId', description: 'ZONE-1' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('zoneId=ZONE-1');
    }));

    it('should skip zoneId when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        zoneId: { value: 'zoneId', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('zoneId=');
    }));
  });

  describe('handleAdvancedSearch - cedrRoles parameter', () => {
    it('should add cedrRoles to query params when description is provided', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        cedrRoles: { value: 'cedrRoles', description: 'ROLE-001' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('cedrRoles=ROLE-001');
    }));

    it('should skip cedrRoles when description is empty', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        cedrRoles: { value: 'cedrRoles', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('cedrRoles=');
    }));
  });

  describe('handleAdvancedSearch - Multiple parameters with special characters', () => {
    it('should handle all parameters together with proper encoding', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: 'O\'Brien' },
        loginId: { value: 'loginId', description: 'user@domain.com' },
        ssn2: { value: 'ssn2', description: '123-45-6789' },
        birthDate: { value: 'birthDate', description: '1990-01-15' },
        classCode: { value: 'classCode', description: 'CC001' },
        firmName: { value: 'firmName', description: 'Smith & Associates' },
        firmAdministrator: { value: 'firmAdministrator', description: 'Admin User' },
        businessAreaCode: { value: 'businessAreaCode', description: 'BA001' },
        shortName: { value: 'shortName', description: 'ORG1' },
        phoneNumber: { value: 'phoneNumber', description: '(555) 123-4567' },
        buildingCode: { value: 'buildingCode', description: 'BLDG1' },
        floorNumber: { value: 'floorNumber', description: '5' },
        corridorId: { value: 'corridorId', description: 'COR1' },
        roomId: { value: 'roomId', description: 'ROOM1' },
        suiteId: { value: 'suiteId', description: 'SUITE1' },
        zoneId: { value: 'zoneId', description: 'ZONE1' },
        cedrRoles: { value: 'cedrRoles', description: 'ROLE1' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(httpService.get).toHaveBeenCalled();
      const callArgs = httpService.get.calls.mostRecent().args[0];
      
      // Verify all parameters are encoded and included
      expect(callArgs).toContain('preferredFirstName=O\'Brien');
      expect(callArgs).toContain('loginId=user%40domain.com');
      expect(callArgs).toContain('ssn2=123-45-6789');
      expect(callArgs).toContain('birthDate=1990-01-15');
      expect(callArgs).toContain('classCode=CC001');
      expect(callArgs).toContain('firmName=Smith%20%26%20Associates');
      expect(callArgs).toContain('firmAdministrator=Admin%20User');
      expect(callArgs).toContain('businessAreaCode=BA001');
      expect(callArgs).toContain('shortName=ORG1');
      expect(callArgs).toContain('phoneNumber=(555)%20123-4567');
      expect(callArgs).toContain('buildingCode=BLDG1');
      expect(callArgs).toContain('floorNumber=5');
      expect(callArgs).toContain('corridorId=COR1');
      expect(callArgs).toContain('roomId=ROOM1');
      expect(callArgs).toContain('suiteId=SUITE1');
      expect(callArgs).toContain('zoneId=ZONE1');
      expect(callArgs).toContain('cedrRoles=ROLE1');
    }));

    it('should include default parameters in URL', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: 'John' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('includeInactive=false');
      expect(callArgs).toContain('limit=10');
      expect(callArgs).toContain('skip=0');
      expect(callArgs).toContain('sortColumn=lastName');
      expect(callArgs).toContain('sortOrder=asc');
    }));

    it('should save search criteria for pagination', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: 'John' },
        loginId: { value: 'loginId', description: 'jdoe' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(component.savedSearchCriteria).toEqual(searchCriteria);
      expect(component.basicSearch).toBe(false);
    }));

    it('should skip multiple empty criteria', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        preferredFirstName: { value: 'preferredFirstName', description: '' },
        loginId: { value: 'loginId', description: 'jdoe' },
        ssn2: { value: 'ssn2', description: '' },
        birthDate: { value: 'birthDate', description: '' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).not.toContain('preferredFirstName=');
      expect(callArgs).toContain('loginId=jdoe');
      expect(callArgs).not.toContain('ssn2=');
      expect(callArgs).not.toContain('birthDate=');
    }));
  });
});
