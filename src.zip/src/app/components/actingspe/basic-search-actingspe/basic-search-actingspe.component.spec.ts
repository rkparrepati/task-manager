import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BasicSearchActingSPEComponent } from './basic-search-actingspe.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('BasicSearchActingSPEComponent', () => {
  let component: BasicSearchActingSPEComponent;
  let fixture: ComponentFixture<BasicSearchActingSPEComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BasicSearchActingSPEComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(BasicSearchActingSPEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('constructor', () => {
    it('should initialize with default search criteria', () => {
      expect(component.basicSearchCriteria).toBeDefined();
      expect(component.basicSearchCriteria.length).toBe(4);
      expect(component.selectedSearchCriteria).toBe('workerNumber');
    });

    it('should have correct search criteria options', () => {
      const criteria = component.basicSearchCriteria;
      expect(criteria[0].value).toBe('workerNumber');
      expect(criteria[1].value).toBe('familyName');
      expect(criteria[2].value).toBe('givenName');
      expect(criteria[3].value).toBe('preferredFirstName');
    });
  });

  describe('setSearchType', () => {
    it('should emit search event with selected criteria and text', () => {
      spyOn(component.search, 'emit');
      component.selectedSearchCriteria = { value: 'workerNumber' };
      component.basicSearchText = 'test123';

      component.setSearchType();

      expect(component.search.emit).toHaveBeenCalledWith({
        searchType: { value: 'workerNumber' },
        searchText: 'test123'
      });
    });
  });

  describe('setBasicSearchInputBox', () => {
    it('should show acronym input when acronym is selected', () => {
      component.selectedSearchCriteria = { value: 'acronym' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchDiv).toBe(false);
      expect(component.basicSearchAcronymDiv).toBe(true);
      expect(component.basicSearchSSNDiv).toBe(false);
      expect(component.basicSearchText).toBe('');
    });

    it('should show SSN input when SSN is selected', () => {
      component.selectedSearchCriteria = { value: 'SSN' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchSSNDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
      expect(component.basicSearchAcronymDiv).toBe(false);
    });

    it('should show firm name input when firmName is selected', () => {
      component.selectedSearchCriteria = { value: 'firmName' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchFirmnameDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
      expect(component.basicSearchSSNDiv).toBe(false);
    });

    it('should show firm administrator input when firmAdministrator is selected', () => {
      component.selectedSearchCriteria = { value: 'firmAdministrator' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchfirmAdministratorDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
    });

    it('should show CEDR roles input when cedrRoles is selected', () => {
      component.selectedSearchCriteria = { value: 'cedrRoles' };

      component.setBasicSearchInputBox();

      expect(component.cedrRolesDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
    });

    it('should show DOB input when birthDate is selected', () => {
      component.selectedSearchCriteria = { value: 'birthDate' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchDOBDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
    });

    it('should show login input when loginId is selected', () => {
      component.selectedSearchCriteria = { value: 'loginId' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchLoginDiv).toBe(true);
      expect(component.basicSearchDiv).toBe(false);
    });

    it('should show default text input for other criteria', () => {
      component.selectedSearchCriteria = { value: 'workerNumber' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchDiv).toBe(true);
      expect(component.basicSearchAcronymDiv).toBe(false);
      expect(component.basicSearchSSNDiv).toBe(false);
    });

    it('should reset validation flags', () => {
      component.invalidBasicSearchText = true;
      component.invalidAcronym = true;

      component.setBasicSearchInputBox();

      expect(component.invalidBasicSearchText).toBe(false);
      expect(component.invalidAcronym).toBe(false);
    });

    it('should clear search text when changing input type', () => {
      component.basicSearchText = 'previous search';
      component.selectedSearchCriteria = { value: 'SSN' };

      component.setBasicSearchInputBox();

      expect(component.basicSearchText).toBe('');
    });
  });

  describe('searchKeyEventBasic', () => {
    it('should trigger search on Enter key (keyCode 13)', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 13 };

      component.searchKeyEventBasic(event);

      expect(component.setSearchType).toHaveBeenCalled();
    });

    it('should not trigger search on other keys', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 65 };

      component.searchKeyEventBasic(event);

      expect(component.setSearchType).not.toHaveBeenCalled();
    });
  });
});
