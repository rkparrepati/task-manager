import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ActingSPEService } from './actingspe.service';
import { ActingSPEValidationsService } from './actingspe-validations.service';
import { HttpService } from 'src/app/services/http.service';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

describe('ActingSPEService', () => {
  let service: ActingSPEService;
  let httpService: jasmine.SpyObj<HttpService>;
  let appService: jasmine.SpyObj<AppService>;
  let validationsService: ActingSPEValidationsService;

  beforeEach(() => {
    const httpServiceSpy = jasmine.createSpyObj('HttpService', ['get', 'post']);
    const appServiceSpy = jasmine.createSpyObj('AppService', ['mergeQueryParams']);

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ActingSPEService,
        ActingSPEValidationsService,
        UtilityService,
        DatePipe,
        { provide: HttpService, useValue: httpServiceSpy },
        { provide: AppService, useValue: appServiceSpy }
      ]
    });

    service = TestBed.inject(ActingSPEService);
    httpService = TestBed.inject(HttpService) as jasmine.SpyObj<HttpService>;
    appService = TestBed.inject(AppService) as jasmine.SpyObj<AppService>;
    validationsService = TestBed.inject(ActingSPEValidationsService);
  });

  describe('validateContractorId', () => {
    it('should call httpservice.get with correct parameters', () => {
      const dateOfBirth = '01/15/1990';
      const contractorSSN = '123-45-6789';
      appService.mergeQueryParams.and.returnValue('isContractor=true&includeInactive=true&dateOfBirth=01/15/1990&contractorSSN=123-45-6789');
      httpService.get.and.returnValue(of({ results: [] }));

      service.validateContractorId(dateOfBirth, contractorSSN);

      expect(appService.mergeQueryParams).toHaveBeenCalledWith({
        isContractor: true,
        includeInactive: true,
        dateOfBirth: dateOfBirth,
        contractorSSN: contractorSSN
      });
      expect(httpService.get).toHaveBeenCalled();
    });

    it('should return observable with results', (done) => {
      const mockResponse = { results: [{ id: 1, name: 'Test' }] };
      appService.mergeQueryParams.and.returnValue('params');
      httpService.get.and.returnValue(of(mockResponse));

      service.validateContractorId('01/15/1990', '123-45-6789').subscribe((result) => {
        expect(result).toEqual(mockResponse);
        done();
      });
    });
  });

  describe('getActingSPEs', () => {
    it('should call httpservice.get with correct URL for active workers', (done) => {
      const mockResponse = { results: [] };
      httpService.get.and.returnValue(of(mockResponse));

      service.getActingSPEs(false, 'test').subscribe((result) => {
        expect(result).toEqual(mockResponse);
        expect(httpService.get).toHaveBeenCalledWith(
          '/workers?includeInactive=false&workerNumberPrefix=test&limit=10&skip=0&sortColumn=lastName&sortOrder=asc'
        );
        done();
      });
    });

    it('should call httpservice.get with includeInactive=true for inactive workers', (done) => {
      const mockResponse = { results: [] };
      httpService.get.and.returnValue(of(mockResponse));

      service.getActingSPEs(true, 'test').subscribe((result) => {
        expect(result).toEqual(mockResponse);
        expect(httpService.get).toHaveBeenCalledWith(
          '/workers?includeInactive=true&workerNumberPrefix=test&limit=10&skip=0&sortColumn=lastName&sortOrder=asc'
        );
        done();
      });
    });

    it('should handle empty search text', (done) => {
      const mockResponse = { results: [] };
      httpService.get.and.returnValue(of(mockResponse));

      service.getActingSPEs(false, '').subscribe((result) => {
        expect(result).toEqual(mockResponse);
        expect(httpService.get).toHaveBeenCalledWith(
          '/workers?includeInactive=false&workerNumberPrefix=&limit=10&skip=0&sortColumn=lastName&sortOrder=asc'
        );
        done();
      });
    });
  });

  describe('canViewSecureData', () => {
    it('should return true for employee with InfraAdmin role', () => {
      const userRoles = ['InfraAdmin'];
      const result = service.canViewSecureData(userRoles, 'E');
      expect(result).toBe(true);
    });

    it('should return true for employee with InfraHRAdmin role', () => {
      const userRoles = ['InfraHRAdmin'];
      const result = service.canViewSecureData(userRoles, 'E');
      expect(result).toBe(true);
    });

    it('should return true for employee with InfraHRViewer role', () => {
      const userRoles = ['InfraHRViewer'];
      const result = service.canViewSecureData(userRoles, 'E');
      expect(result).toBe(true);
    });

    it('should return true for contractor with InfraAdmin role', () => {
      const userRoles = ['InfraAdmin'];
      const result = service.canViewSecureData(userRoles, 'C');
      expect(result).toBe(true);
    });

    it('should return true for contractor with InfraHRAdmin role', () => {
      const userRoles = ['InfraHRAdmin'];
      const result = service.canViewSecureData(userRoles, 'C');
      expect(result).toBe(true);
    });

    it('should return true for contractor with InfraContractorAdmin role', () => {
      const userRoles = ['InfraContractorAdmin'];
      const result = service.canViewSecureData(userRoles, 'C');
      expect(result).toBe(true);
    });

    it('should return true for contractor with InfraOfficeCoordinator role', () => {
      const userRoles = ['InfraOfficeCoordinator'];
      const result = service.canViewSecureData(userRoles, 'C');
      expect(result).toBe(true);
    });

    it('should return false for user without required roles', () => {
      const userRoles = ['User'];
      const result = service.canViewSecureData(userRoles, 'E');
      expect(result).toBe(false);
    });

    it('should return false for contractor without required roles', () => {
      const userRoles = ['User'];
      const result = service.canViewSecureData(userRoles, 'C');
      expect(result).toBe(false);
    });
  });

  describe('updateActingSPE', () => {
    it('should create POST request for new capabilities', (done) => {
      const worker = { workerId: 1 };
      const postList = [{ id: 1 }];
      const putList: any[] = [];
      const removeList: any[] = [];
      const beginDate = '2024-01-01';
      const endDate = '2024-12-31';
      const userInfo = { workerNumber: '12345' };

      httpService.post.and.returnValue(of({}));

      service.updateActingSPE(worker, postList, putList, removeList, beginDate, endDate, userInfo).subscribe(() => {
        expect(httpService.post).toHaveBeenCalled();
        const callArgs = httpService.post.calls.mostRecent().args;
        expect(callArgs[0]).toContain('/workers/1/assign-capabilities');
        done();
      });
    });

    it('should create POST request for updated capabilities', (done) => {
      const worker = { workerId: 1 };
      const postList: any[] = [];
      const putList = [{ workerCapabilityId: 1, stndCapability: { id: 1 } }];
      const removeList: any[] = [];
      const beginDate = '2024-01-01';
      const endDate = '2024-12-31';
      const userInfo = { workerNumber: '12345' };

      httpService.post.and.returnValue(of({}));

      service.updateActingSPE(worker, postList, putList, removeList, beginDate, endDate, userInfo).subscribe(() => {
        expect(httpService.post).toHaveBeenCalled();
        const callArgs = httpService.post.calls.mostRecent().args;
        expect(callArgs[0]).toContain('/workers/1/update-capabilities');
        done();
      });
    });

    it('should create POST request for removed capabilities', (done) => {
      const worker = { workerId: 1 };
      const postList: any[] = [];
      const putList: any[] = [];
      const removeList = [{ workerCapabilityId: 1, stndCapability: { id: 1 } }];
      const beginDate = '2024-01-01';
      const endDate = '2024-12-31';
      const userInfo = { workerNumber: '12345' };

      httpService.post.and.returnValue(of({}));

      service.updateActingSPE(worker, postList, putList, removeList, beginDate, endDate, userInfo).subscribe(() => {
        expect(httpService.post).toHaveBeenCalled();
        const callArgs = httpService.post.calls.mostRecent().args;
        expect(callArgs[0]).toContain('/workers/1/unassign-capabilities');
        done();
      });
    });

    it('should handle no changes', (done) => {
      const worker = { workerId: 1 };
      const postList: any[] = [];
      const putList: any[] = [];
      const removeList: any[] = [];
      const beginDate = '2024-01-01';
      const endDate = '2024-12-31';
      const userInfo = { workerNumber: '12345' };

      service.updateActingSPE(worker, postList, putList, removeList, beginDate, endDate, userInfo).subscribe((result) => {
        expect(result).toEqual([]);
        done();
      });
    });

    it('should convert dates to ISO format', (done) => {
      const worker = { workerId: 1 };
      const postList = [{ id: 1 }];
      const putList: any[] = [];
      const removeList: any[] = [];
      const beginDate = '2024-01-01';
      const endDate = '2024-12-31';
      const userInfo = { workerNumber: '12345' };

      httpService.post.and.returnValue(of({}));

      service.updateActingSPE(worker, postList, putList, removeList, beginDate, endDate, userInfo).subscribe(() => {
        const callArgs = httpService.post.calls.mostRecent().args;
        const payload = callArgs[1];
        expect(payload[0].lifecycle.beginDate).toContain('2024-01-01');
        expect(payload[0].lifecycle.endDate).toContain('2024-12-31');
        done();
      });
    });
  });

});
