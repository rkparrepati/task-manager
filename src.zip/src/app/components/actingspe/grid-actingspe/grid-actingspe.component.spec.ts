import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GridActingSPEComponent } from './grid-actingspe.component';
import { AppService } from 'src/app/services/app.service';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('GridActingSPEComponent', () => {
  let component: GridActingSPEComponent;
  let fixture: ComponentFixture<GridActingSPEComponent>;
  let appService: jasmine.SpyObj<AppService>;

  beforeEach(async () => {
    const appServiceSpy = jasmine.createSpyObj('AppService', ['changePage']);

    await TestBed.configureTestingModule({
      declarations: [GridActingSPEComponent],
      providers: [{ provide: AppService, useValue: appServiceSpy }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    appService = TestBed.inject(AppService) as jasmine.SpyObj<AppService>;
    fixture = TestBed.createComponent(GridActingSPEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('initialization', () => {
    it('should initialize with default values', () => {
      expect(component.applicationType).toBe('Worker');
      expect(component.dataSource).toEqual({ meta: {}, results: [] });
      expect(component.capabilityList).toEqual([]);
    });
  });

  describe('editCapabilities', () => {
    it('should emit editCapabilitiesEvent for admin user', () => {
      spyOn(component.editCapabilitiesEvent, 'emit');
      component.userInfo = { roles: ['InfraAdmin'] };
      const worker = { workerId: 1, givenName: 'John', familyName: 'Doe' };
      const event = jasmine.createSpyObj('Event', ['stopPropagation']);

      component.editCapabilities(event, worker);

      expect(event.stopPropagation).toHaveBeenCalled();
      expect(component.editCapabilitiesEvent.emit).toHaveBeenCalledWith(worker);
    });

    it('should emit editCapabilitiesEvent for supervisor admin user', () => {
      spyOn(component.editCapabilitiesEvent, 'emit');
      component.userInfo = { roles: ['InfraSupervisorAdmin'] };
      const worker = { workerId: 1 };
      const event = jasmine.createSpyObj('Event', ['stopPropagation']);

      component.editCapabilities(event, worker);

      expect(component.editCapabilitiesEvent.emit).toHaveBeenCalledWith(worker);
    });

    it('should not emit event for non-admin user', () => {
      spyOn(component.editCapabilitiesEvent, 'emit');
      component.userInfo = { roles: ['User'] };
      const worker = { workerId: 1 };
      const event = jasmine.createSpyObj('Event', ['stopPropagation']);

      component.editCapabilities(event, worker);

      expect(component.editCapabilitiesEvent.emit).not.toHaveBeenCalled();
    });

    it('should not emit event if userInfo is missing', () => {
      spyOn(component.editCapabilitiesEvent, 'emit');
      component.userInfo = null;
      const worker = { workerId: 1 };
      const event = jasmine.createSpyObj('Event', ['stopPropagation']);

      component.editCapabilities(event, worker);

      expect(component.editCapabilitiesEvent.emit).not.toHaveBeenCalled();
    });
  });

  describe('getWorkerUpdateObject', () => {
    it('should navigate to worker update page with type A for admin', () => {
      component.userInfo = { roles: ['InfraAdmin'] };
      component.applicationType = 'Worker';
      const worker = { workerId: 1, workerNumber: '12345' };

      component.getWorkerUpdateObject(worker);

      expect(appService.changePage).toHaveBeenCalledWith('/workerUpdate/1/12345/Worker/A');
    });

    it('should navigate to worker update page with type N for non-admin', () => {
      component.userInfo = { roles: ['User'] };
      component.applicationType = 'Worker';
      const worker = { workerId: 1, workerNumber: '12345' };

      component.getWorkerUpdateObject(worker);

      expect(appService.changePage).toHaveBeenCalledWith('/workerUpdate/1/12345/Worker/N');
    });

    it('should use provided type parameter', () => {
      component.userInfo = { roles: ['InfraAdmin'] };
      component.applicationType = 'Worker';
      const worker = { workerId: 1, workerNumber: '12345' };

      component.getWorkerUpdateObject(worker, 'C');

      expect(appService.changePage).toHaveBeenCalledWith('/workerUpdate/1/12345/Worker/C');
    });
  });

  describe('getTemplateWorkerSearch', () => {
    it('should return detail template when worker is selected', () => {
      component.workerModel = {
        selectedWorker: { workerId: 1 }
      };
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('detail');
    });

    it('should return view template when worker is not selected', () => {
      component.workerModel = {
        selectedWorker: { workerId: 2 }
      };
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('view');
    });

    it('should return view template when no worker is selected', () => {
      component.workerModel = {
        selectedWorker: {}
      };
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('view');
    });
  });

  describe('expandPhoneNumber', () => {
    it('should set selected worker', () => {
      const worker = { workerId: 1, givenName: 'John' };
      component.workerModel = { selectedWorker: {} };

      component.expandPhoneNumber(worker);

      expect(component.workerModel.selectedWorker).toEqual(worker);
    });

    it('should clear phone number detail', () => {
      component.phoneNumberDetail = { number: '555-1234' };
      const worker = { workerId: 1 };
      component.workerModel = { selectedWorker: {} };

      component.expandPhoneNumber(worker);

      expect(component.phoneNumberDetail).toBeNull();
    });
  });

  describe('getPrimaryOrganization', () => {
    it('should return primary organization acronym', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
        },
        {
          primaryOrganizationIndicator: true,
          organization: { businessAreaCode: 'BA2', shortName: 'ORG2' }
        }
      ];

      const result = component.getPrimaryOrganization(organizationHistory);

      expect(result).toBe('BA2/ORG2');
    });

    it('should return undefined if no primary organization', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
        }
      ];

      const result = component.getPrimaryOrganization(organizationHistory);

      expect(result).toBeUndefined();
    });
  });

  describe('getBuildingData', () => {
    it('should return building code', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: { building: { code: 'BLDG1' } }
            }
          ]
        }
      ];

      const result = component.getBuildingData(organizationHistory);

      expect(result).toBe('BLDG1');
    });

    it('should return empty string if no location summary', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: []
        }
      ];

      const result = component.getBuildingData(organizationHistory);

      expect(result).toBe('');
    });
  });

  describe('getLocation', () => {
    it('should return floor only', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: null,
                roomId: null,
                zoneId: null,
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1');
    });

    it('should return floor and room', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: null,
                roomId: '101',
                zoneId: null,
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1/101');
    });

    it('should return floor and corridor', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: 'A',
                roomId: null,
                zoneId: null,
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1/A');
    });

    it('should return floor, corridor, and room', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: 'A',
                roomId: '101',
                zoneId: null,
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1/A101');
    });

    it('should return floor, corridor, room, and zone', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: 'A',
                roomId: '101',
                zoneId: 'Z1',
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1/A101/Z1');
    });

    it('should return floor, suite, corridor, room, and zone', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '1' },
                corridorId: 'A',
                roomId: '101',
                zoneId: 'Z1',
                suiteId: 'S1'
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('1-S1/A101/Z1');
    });
  });

  describe('getLocation - Additional Branch Coverage', () => {
    it('should handle null locationSummary', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: null
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('');
    });

    it('should handle empty organizationHistory', () => {
      const organizationHistory: any[] = [];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('');
    });

    it('should handle organization with no matching location', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          locationSummary: []
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('');
    });

    it('should return floor and zone with null corridor and room', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '2' },
                corridorId: null,
                roomId: null,
                zoneId: 'Z2',
                suiteId: null
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('2/  /Z2');
    });

    it('should return floor and suite with null corridor, room, and zone', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '3' },
                corridorId: null,
                roomId: null,
                zoneId: null,
                suiteId: 'S2'
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('3-S2/   ');
    });

    it('should return floor and suite with values for corridor, room, and zone', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: {
                building: { floorNumber: '4' },
                corridorId: 'B',
                roomId: '202',
                zoneId: 'Z3',
                suiteId: 'S3'
              }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('4-S3/B202/Z3');
    });

    it('should find primary location by primaryLocationIn flag', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          locationSummary: [
            {
              primaryLocationIn: false,
              locationSummary: { building: { floorNumber: '1' }, corridorId: null, roomId: null, zoneId: null, suiteId: null }
            }
          ]
        },
        {
          primaryOrganizationIndicator: false,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: { building: { floorNumber: '5' }, corridorId: null, roomId: null, zoneId: null, suiteId: null }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('5');
    });

    it('should handle multiple organizations and select correct one', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          locationSummary: [
            {
              primaryLocationIn: false,
              locationSummary: { building: { floorNumber: '1' }, corridorId: null, roomId: null, zoneId: null, suiteId: null }
            }
          ]
        },
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: false,
              locationSummary: { building: { floorNumber: '6' }, corridorId: 'C', roomId: null, zoneId: null, suiteId: null }
            }
          ]
        }
      ];

      const result = component.getLocation(organizationHistory);

      expect(result).toBe('6/C');
    });
  });

  describe('getBuildingData - Additional Branch Coverage', () => {
    it('should handle null locationSummary in building data', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: true,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: null
            }
          ]
        }
      ];

      const result = component.getBuildingData(organizationHistory);

      expect(result).toBe('');
    });

    it('should find building by primaryLocationIn flag', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          locationSummary: [
            {
              primaryLocationIn: false,
              locationSummary: { building: { code: 'BLDG2' } }
            }
          ]
        },
        {
          primaryOrganizationIndicator: false,
          locationSummary: [
            {
              primaryLocationIn: true,
              locationSummary: { building: { code: 'BLDG3' } }
            }
          ]
        }
      ];

      const result = component.getBuildingData(organizationHistory);

      expect(result).toBe('BLDG3');
    });

    it('should handle empty organizationHistory for building', () => {
      const organizationHistory: any[] = [];

      const result = component.getBuildingData(organizationHistory);

      expect(result).toBe('');
    });
  });

  describe('getTemplateWorkerSearch - Additional Branch Coverage', () => {
    it('should return view when worker is null', () => {
      component.workerModel = {
        selectedWorker: { workerId: 1 }
      };

      const result = component.getTemplateWorkerSearch(null);

      expect(result).toBe('view');
    });

    it('should return view when workerModel is null', () => {
      component.workerModel = null;
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('view');
    });

    it('should return view when selectedWorker is null', () => {
      component.workerModel = {
        selectedWorker: null
      };
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('view');
    });

    it('should return view when selectedWorker has no workerId', () => {
      component.workerModel = {
        selectedWorker: {}
      };
      const worker = { workerId: 1 };

      const result = component.getTemplateWorkerSearch(worker);

      expect(result).toBe('view');
    });
  });

  describe('collapsePhoneNumber', () => {
    it('should clear selected worker', () => {
      component.workerModel = { selectedWorker: { workerId: 1 } };

      component.collapsePhoneNumber();

      expect(component.workerModel.selectedWorker).toEqual({});
    });
  });

  describe('clickedOnSort', () => {
    it('should be defined', () => {
      expect(component.clickedOnSort).toBeDefined();
    });
  });

  describe('pageSizeChangedEvent', () => {
    it('should be defined', () => {
      expect(component.pageSizeChangedEvent).toBeDefined();
    });
  });
});
