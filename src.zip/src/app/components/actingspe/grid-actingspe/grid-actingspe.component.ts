import { Component, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-grid-actingspe',
  templateUrl: './grid-actingspe.component.html',
  styleUrls: ['./grid-actingspe.component.scss'],
})
export class GridActingSPEComponent {
  @Input() dataSource: any = { meta: {}, results: [] };
  @Input() userInfo: any;
  @Input() capabilityList: any[] = [];
  @Output() editCapabilitiesEvent = new EventEmitter<any>();

  applicationType: String = 'Worker';
  sortColumn: any;
  sortDirection: any;
  resort: any;
  userRoles: any;
  updateWorkerButton: any;
  workerModel: any = { workerList: [] };
  worker: any = {};
  phoneNumberDetail: any = {};
  constructor(private appService: AppService) {}

  editCapabilities(event: Event, worker: any) {
    // Stop event propagation to prevent row click
    event.stopPropagation();
    
    // Check if user has admin role
    if (!this.userInfo ||
        (this.userInfo.roles.indexOf('InfraAdmin') < 0 &&
         this.userInfo.roles.indexOf('InfraSupervisorAdmin') < 0)) {
      return;
    }
    
    // Emit event to parent component
    this.editCapabilitiesEvent.emit(worker);
  }
  getWorkerUpdateObject(worker: any, type: string = '') {
    if (!type && this.userInfo.roles.indexOf('InfraAdmin') !== -1) {
      type = 'A';
    } else if (!type) {
      type = 'N';
    }
    this.appService.changePage(
      '/workerUpdate/' +
        worker.workerId +
        '/' +
        worker.workerNumber +
        '/' +
        this.applicationType +
        '/' +
        type
    );
  }
  getTemplateWorkerSearch(worker: any) {
    if (
      worker &&
      this.workerModel &&
      this.workerModel.selectedWorker &&
      this.workerModel.selectedWorker.workerId &&
      worker.workerId === this.workerModel.selectedWorker.workerId
    ) {
      return 'detail';
    } else {
      return 'view';
    }
  }
  expandPhoneNumber(worker: any) {
    this.phoneNumberDetail = null;
    this.workerModel.selectedWorker = worker;

    // WorkerSearchService.getPhoneNumberDetail(worker.workerId).then(function(response) {
    //     vm.phoneNumberDetail = response;
    // }, function() {

    // });
  }
  clickedOnSort(event: any) {}
  getPrimaryOrganization(organizationHistory: Array<any>) {
    let acronym;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organization = organizationHistory[i];
      if (organization.primaryOrganizationIndicator) {
        acronym =
          organization.organization.businessAreaCode + '/' + organization.organization.shortName;
      }
    }
    return acronym;
  }
  getBuildingData(organizationHistory: Array<any>) {
    let building = '';
    let position = -1;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    if (position >= 0) {
      const locationSummary = organizationHistory[position].locationSummary[0].locationSummary;
      if (locationSummary != null) {
        building = locationSummary.building.code;
      }
    }
    return building;
  }
  getLocation = function (organizationHistory: Array<any>) {
    let location = '';
    let position = -1;
    const len = organizationHistory.length;
    for (let i = 0; i < len; i++) {
      const organizationData = organizationHistory[i];
      if (
        organizationData.locationSummary.length > 0 &&
        (organizationData.locationSummary[0].primaryLocationIn ||
          organizationData.primaryOrganizationIndicator)
      ) {
        position = i;
      }
    }
    if (position >= 0) {
      const locationSummary = organizationHistory[position].locationSummary[0].locationSummary;
      if (locationSummary != null) {
        let floor = locationSummary.building.floorNumber;
        let corridor = locationSummary.corridorId;
        let room = locationSummary.roomId;
        let zone = locationSummary.zoneId;
        let suite = locationSummary.suiteId;
        if (corridor == null && room == null && zone == null && suite == null) {
          location = floor;
        } else if (corridor == null && zone == null && suite == null) {
          location = floor + '/' + room;
        } else if (room == null && zone == null && suite == null) {
          location = floor + '/' + corridor;
        } else if (zone == null && suite == null) {
          location = floor + '/' + corridor + room;
        } else if (suite == null) {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '/' + corridor + room + zone;
        } else {
          corridor = corridor == null ? ' ' : corridor;
          room = room == null ? ' ' : room;
          zone = zone == null ? ' ' : '/' + zone;
          location = floor + '-' + suite + '/' + corridor + room + zone;
        }
      }
    }
    return location;
  };
  collapsePhoneNumber() {
    this.workerModel.selectedWorker = {};
  }
  pageSizeChangedEvent(pageSize: number) {}
}
