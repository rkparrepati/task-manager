import { ComponentFixture, TestBed, fakeAsync, tick, flush } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { of, throwError } from 'rxjs';
import { ActingSPEComponent } from './actingspe.component';
import { ActingSPEService } from './actingspe.service';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { HttpService } from 'src/app/services/http.service';
import { EditCapabilitiesDialogComponent } from './edit-capabilities-dialog/edit-capabilities-dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ActingSPEComponent', () => {
  let component: ActingSPEComponent;
  let fixture: ComponentFixture<ActingSPEComponent>;
  let appService: jasmine.SpyObj<AppService>;
  let localStorageService: jasmine.SpyObj<LocalStorageService>;
  let actingSPEService: jasmine.SpyObj<ActingSPEService>;
  let httpService: jasmine.SpyObj<HttpService>;
  let matDialog: jasmine.SpyObj<MatDialog>;

  const mockUserData = {
    workerNumber: '12345',
    roles: ['InfraAdmin'],
    infraAdminEmailAddress: 'testadmin@example.com'
  };

  const mockCapabilities = {
    results: [
      { id: 1, value: 'CAP1', description: 'Capability 1' },
      { id: 2, value: 'CAP2', description: 'Capability 2' }
    ]
  };

  const mockJobClasses = {
    results: [
      { id: 1, code: 'JC1', description: 'Job Class 1' },
      { id: 2, code: 'JC2', description: 'Job Class 2' }
    ]
  };

  const mockParameters = {
    results: [
      { parameterName: 'INFRA_ADMIN_EMAIL_ADDRESS', parameterValueText: 'testadmin@example.com' }
    ]
  };

  const mockWorkerResponse = {
    results: [
      {
        workerId: 1,
        workerNumber: '12345',
        givenName: 'John',
        familyName: 'Doe',
        organizationHistory: [
          {
            primaryOrganizationIndicator: true,
            organization: {
              businessAreaCode: 'BA1',
              shortName: 'ORG1'
            }
          }
        ]
      }
    ]
  };

  const mockSearchResults = {
    meta: { total: 2 },
    results: [
      {
        workerId: 1,
        workerNumber: '12345',
        givenName: 'John',
        familyName: 'Doe',
        organizationHistory: [
          {
            primaryOrganizationIndicator: true,
            organization: {
              businessAreaCode: 'BA1',
              shortName: 'ORG1'
            }
          }
        ]
      },
      {
        workerId: 2,
        workerNumber: '12346',
        givenName: 'Jane',
        familyName: 'Smith',
        organizationHistory: [
          {
            primaryOrganizationIndicator: true,
            organization: {
              businessAreaCode: 'BA1',
              shortName: 'ORG1'
            }
          }
        ]
      }
    ]
  };

  beforeEach(async () => {
    const appServiceSpy = jasmine.createSpyObj('AppService', ['getUserData', 'changePage', 'mergeQueryParams']);
    const localStorageServiceSpy = jasmine.createSpyObj('LocalStorageService', ['setItem', 'removeItem', 'getItem']);
    const actingSPEServiceSpy = jasmine.createSpyObj('ActingSPEService', ['getActingSPEs', 'updateActingSPE']);
    const httpServiceSpy = jasmine.createSpyObj('HttpService', ['get', 'post']);
    const matDialogSpy = jasmine.createSpyObj('MatDialog', ['open']);

    await TestBed.configureTestingModule({
      declarations: [ActingSPEComponent],
      imports: [HttpClientTestingModule, MatDialogModule],
      providers: [
        { provide: AppService, useValue: appServiceSpy },
        { provide: LocalStorageService, useValue: localStorageServiceSpy },
        { provide: ActingSPEService, useValue: actingSPEServiceSpy },
        { provide: HttpService, useValue: httpServiceSpy },
        { provide: MatDialog, useValue: matDialogSpy }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    appService = TestBed.inject(AppService) as jasmine.SpyObj<AppService>;
    localStorageService = TestBed.inject(LocalStorageService) as jasmine.SpyObj<LocalStorageService>;
    actingSPEService = TestBed.inject(ActingSPEService) as jasmine.SpyObj<ActingSPEService>;
    httpService = TestBed.inject(HttpService) as jasmine.SpyObj<HttpService>;
    matDialog = TestBed.inject(MatDialog) as jasmine.SpyObj<MatDialog>;

    fixture = TestBed.createComponent(ActingSPEComponent);
    component = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('should initialize component and load user data', fakeAsync(() => {
      appService.getUserData.and.returnValue(mockUserData);
      httpService.get.and.returnValue(of(mockCapabilities));

      component.ngOnInit();
      tick(500);

      expect(appService.getUserData).toHaveBeenCalled();
      expect(component.userInfo).toEqual(mockUserData);
    }));

    it('should retry getting user data up to 10 times', fakeAsync(() => {
      appService.getUserData.and.returnValues(null, null, mockUserData);
      httpService.get.and.returnValue(of(mockCapabilities));

      component.ngOnInit();
      tick(1500);

      expect(appService.getUserData).toHaveBeenCalledTimes(3);
    }));

    it('should log error after 10 failed retries', fakeAsync(() => {
      appService.getUserData.and.returnValue(null);

      component.ngOnInit();
      tick(5500);

      expect(appService.getUserData).toHaveBeenCalled();
    }));
  });

  describe('initializeComponent', () => {
    it('should load capabilities, job classes, and parameters', fakeAsync(() => {
      appService.getUserData.and.returnValue(mockUserData);
      httpService.get.and.callFake((url: string) => {
        if (url === '/references/capabilities') return of(mockCapabilities);
        if (url === '/references/job-classes') return of(mockJobClasses);
        if (url === '/parameters') return of(mockParameters);
        return of({});
      });

      component.ngOnInit();
      tick(500);

      expect(component.capabilityList).toEqual(mockCapabilities.results);
      expect(component.jobClassCodeList).toEqual(mockJobClasses.results);
      expect(component.infraAdminEmailAddress).toBe('testadmin@example.com');
    }));

    it('should handle error loading initial data', fakeAsync(() => {
      appService.getUserData.and.returnValue(mockUserData);
      httpService.get.and.returnValue(throwError({ status: 500 }));

      component.ngOnInit();
      tick(500);

      expect(component.userInfo).toEqual(mockUserData);
    }));
  });

  describe('loadUserHomeGAU', () => {
    it('should load user home GAU and search workers', fakeAsync(() => {
      component.userInfo = mockUserData;
      httpService.get.and.callFake((url: string) => {
        if (url.includes('workerNumber=12345')) return of(mockWorkerResponse);
        if (url.includes('/references/capabilities')) return of(mockCapabilities);
        if (url.includes('/references/job-classes')) return of(mockJobClasses);
        if (url.includes('/parameters')) return of(mockParameters);
        if (url.includes('/workers?includeInactive=false')) return of(mockSearchResults);
        return of({});
      });

      component.ngOnInit();
      flush();

      expect(component.myOrg).toBe('BA1/ORG1');
      expect(component.workerModel.workerList.length).toBeGreaterThan(0);
    }));

    it('should handle error loading user home GAU', fakeAsync(() => {
      component.userInfo = mockUserData;
      httpService.get.and.callFake((url: string) => {
        if (url.includes('/references/capabilities')) return of(mockCapabilities);
        if (url.includes('/references/job-classes')) return of(mockJobClasses);
        if (url.includes('/parameters')) return of(mockParameters);
        if (url.includes('workerNumber=12345')) return throwError({ status: 500 });
        return of({});
      });

      component.ngOnInit();
      flush();

      expect(component.userInfo).toEqual(mockUserData);
      expect(component.workerModel.workerList.length).toBe(0);
    }));

    it('should handle missing worker number', fakeAsync(() => {
      component.userInfo = { roles: ['InfraAdmin'] };

      component['loadUserHomeGAU']();

      expect(component.userInfo).toBeDefined();
    }));

    it('should handle no primary organization found', fakeAsync(() => {
      component.userInfo = mockUserData;
      const workerWithoutPrimaryOrg = {
        results: [
          {
            workerId: 1,
            organizationHistory: [
              {
                primaryOrganizationIndicator: false,
                organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
              }
            ]
          }
        ]
      };
      httpService.get.and.returnValue(of(workerWithoutPrimaryOrg));

      component['loadUserHomeGAU']();

      expect(component.myOrg).toBe('');
    }));
  });

  describe('searchWorkersByHomeGAU', () => {
    it('should search workers by home GAU', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));

      component['searchWorkersByHomeGAU']('BA1', 'ORG1', 10, 0);
      tick();

      expect(component.workerModel.workerList.length).toBe(2);
      expect(component.total).toBe(2);
      expect(component.searchResultsCount).toContain('2 worker(s) have been found');
    }));

    it('should handle no results found', fakeAsync(() => {
      httpService.get.and.returnValue(of({ meta: { total: 0 }, results: [] }));

      component['searchWorkersByHomeGAU']('BA1', 'ORG1', 10, 0);
      tick();

      expect(component.workerModel.workerList.length).toBe(0);
      expect(component.total).toBe(0);
      expect(component.searchResultsCount).toContain('No workers have been found');
    }));

    it('should handle search error', fakeAsync(() => {
      httpService.get.and.returnValue(throwError({ status: 500 }));

      component['searchWorkersByHomeGAU']('BA1', 'ORG1', 10, 0);
      tick();

      expect(component.workerModel.workerList.length).toBe(0);
      expect(component.total).toBe(0);
    }));

    it('should add primary organization to each worker', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));

      component['searchWorkersByHomeGAU']('BA1', 'ORG1', 10, 0);
      tick();

      component.workerModel.workerList.forEach((worker: any) => {
        expect(worker.primaryOrganization).toBeDefined();
      });
    }));
  });

  describe('toggleSearchView', () => {
    it('should toggle between basic and advanced search', () => {
      component.otherSearchView = 'basic';
      component.toggleSearchView();
      expect(component.otherSearchView).toBe('advanced');

      component.toggleSearchView();
      expect(component.otherSearchView).toBe('basic');
    });
  });

  describe('searchWorkers', () => {
    it('should search workers using ActingSPEService', () => {
      const mockResponse = { results: [] };
      actingSPEService.getActingSPEs.and.returnValue(of(mockResponse));
      component.showType = 'active';

      component.searchWorkers({ searchText: 'test' });

      expect(actingSPEService.getActingSPEs).toHaveBeenCalledWith(false, 'test');
      expect(component.workerRecords).toEqual(mockResponse);
    });

    it('should pass includeInactive=true when showType is inactive', () => {
      const mockResponse = { results: [] };
      actingSPEService.getActingSPEs.and.returnValue(of(mockResponse));
      component.showType = 'inactive';

      component.searchWorkers({ searchText: 'test' });

      expect(actingSPEService.getActingSPEs).toHaveBeenCalledWith(true, 'test');
    });
  });

  describe('handleAdvancedSearch', () => {
    it('should handle advanced search with criteria', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        lastName: { value: 'familyName', description: 'Doe' },
        firstName: { value: 'givenName', description: 'John' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(component.workerModel.workerList.length).toBe(2);
      expect(component.basicSearch).toBe(false);
    }));

    it('should handle invalid search event', () => {
      component.handleAdvancedSearch(null);

      expect(component.workerModel.workerList.length).toBe(0);
    });

    it('should handle search error', fakeAsync(() => {
      httpService.get.and.returnValue(throwError({ status: 500 }));
      const searchCriteria = { lastName: { value: 'familyName', description: 'Doe' } };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(component.workerModel.workerList.length).toBe(0);
      expect(component.total).toBe(0);
    }));

    it('should build URL with all search criteria', fakeAsync(() => {
      httpService.get.and.returnValue(of(mockSearchResults));
      const searchCriteria = {
        ssn: { value: 'socialSecurityNumber', description: '123-45-6789' },
        workerNumber: { value: 'workerNumber', description: '12345' },
        lastName: { value: 'familyName', description: 'Doe' },
        firstName: { value: 'givenName', description: 'John' },
        phoneNumber: { value: 'phoneNumber', description: '555-1234' }
      };

      component.handleAdvancedSearch({ searchCriteria });
      tick();

      expect(httpService.get).toHaveBeenCalled();
      const callArgs = httpService.get.calls.mostRecent().args[0];
      expect(callArgs).toContain('socialSecurityNumber=');
      expect(callArgs).toContain('workerNumber=');
      expect(callArgs).toContain('familyName=');
    }));
  });

  describe('handleClearSearch', () => {
    it('should clear search results and reload home GAU', fakeAsync(() => {
      component.userInfo = mockUserData;
      component.myOrg = 'BA1/ORG1';
      component.workerModel.workerList = [{ workerId: 1 }];
      component.total = 10;
      component.searchResultsCount = '10 results';
      component.limit = 10;
      httpService.get.and.callFake((url: string) => {
        if (url.includes('/workers?includeInactive=false')) return of(mockSearchResults);
        return of({});
      });

      component.handleClearSearch();
      flush();

      // After clearing and reloading, the search results should be populated from mockSearchResults
      expect(component.searchResultsCount).toBe('2 worker(s) have been found in my GAU/Organization (BA1/ORG1)');
      // savedSearchCriteria is set to null initially, but then the component reloads the search
      // which doesn't set savedSearchCriteria, so it should remain null
      expect(component.workerModel.workerList.length).toBeGreaterThan(0);
    }));

    it('should not reload if user info is not available', () => {
      component.userInfo = null;
      component.handleClearSearch();
      expect(component.workerModel.workerList.length).toBe(0);
    });
  });

  describe('pageSizeChangedEvent', () => {
    it('should update limit and re-run search', fakeAsync(() => {
      component.userInfo = mockUserData;
      component.myOrg = 'BA1/ORG1';
      component.savedSearchCriteria = { businessAreaCode: 'BA1', shortName: 'ORG1' };
      httpService.get.and.returnValue(of(mockSearchResults));

      component.pageSizeChangedEvent(20);
      tick();

      expect(component.limit).toBe(20);
    }));
  });

  describe('onPageChanged', () => {
    it('should calculate skip and re-run search', fakeAsync(() => {
      component.userInfo = mockUserData;
      component.myOrg = 'BA1/ORG1';
      component.limit = 10;
      component.savedSearchCriteria = { businessAreaCode: 'BA1', shortName: 'ORG1' };
      httpService.get.and.returnValue(of(mockSearchResults));

      component.onPageChanged(2);
      tick();

      expect(httpService.get).toHaveBeenCalled();
    }));
  });

  describe('editCapabilities', () => {
    it('should open edit capabilities dialog for admin user', () => {
      const mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
      mockDialogRef.afterClosed.and.returnValue(of(null));
      matDialog.open.and.returnValue(mockDialogRef);

      component.userInfo = { roles: ['InfraAdmin'] };
      component.capabilityList = mockCapabilities.results;
      const worker = {
        workerId: 1,
        givenName: 'John',
        familyName: 'Doe',
        capabilities: []
      };

      component.editCapabilities(worker);

      expect(matDialog.open).toHaveBeenCalledWith(EditCapabilitiesDialogComponent, jasmine.any(Object));
    });

    it('should not open dialog for non-admin user', () => {
      component.userInfo = { roles: ['User'] };
      const worker = { workerId: 1, givenName: 'John', familyName: 'Doe' };

      component.editCapabilities(worker);

      expect(matDialog.open).not.toHaveBeenCalled();
    });

    it('should save capabilities when dialog returns data', fakeAsync(() => {
      const mockDialogRef = jasmine.createSpyObj('MatDialogRef', ['afterClosed']);
      const dialogResult = {
        newCapabilityList: [{ id: 1 }],
        availableCapabilities: [],
        beginDate: '2024-01-01',
        endDate: '2024-12-31'
      };
      mockDialogRef.afterClosed.and.returnValue(of(dialogResult));
      matDialog.open.and.returnValue(mockDialogRef);
      actingSPEService.updateActingSPE.and.returnValue(of({}));

      component.userInfo = { roles: ['InfraAdmin'] };
      component.capabilityList = mockCapabilities.results;
      component.savedSearchCriteria = { businessAreaCode: 'BA1', shortName: 'ORG1' };
      httpService.get.and.returnValue(of(mockSearchResults));

      const worker = {
        workerId: 1,
        workerNumber: '12345',
        givenName: 'John',
        familyName: 'Doe',
        capabilities: [],
        organizationHistory: [
          {
            primaryOrganizationIndicator: true,
            organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
          }
        ]
      };

      component.editCapabilities(worker);
      tick();

      expect(actingSPEService.updateActingSPE).toHaveBeenCalled();
    }));
  });

  describe('validateEndDate', () => {
    it('should return error if begin date is missing', () => {
      const error = component['validateEndDate']('', '2024-12-31');
      expect(error).toBe('Both start and end dates are required');
    });

    it('should return error if end date is missing', () => {
      const error = component['validateEndDate']('2024-01-01', '');
      expect(error).toBe('Both start and end dates are required');
    });

    it('should return error if end date is before begin date', () => {
      const error = component['validateEndDate']('2024-12-31', '2024-01-01');
      expect(error).toBe('End date must be after start date');
    });

    it('should return null if dates are valid', () => {
      const error = component['validateEndDate']('2024-01-01', '2024-12-31');
      expect(error).toBeNull();
    });
  });

  describe('getPostList', () => {
    it('should identify new capabilities', () => {
      const newList: any[] = [{ id: 1 }, { id: 2 }];
      const oldList: any[] = [{ id: 1, stndCapability: { id: 1 } }];
      const availableCapabilities: any[] = [{ id: 2 }];

      const result = component['getPostList'](newList, oldList, availableCapabilities);

      expect(result.postList.length).toBe(1);
      expect(result.postList[0].id).toBe(2);
    });

    it('should identify updated capabilities', () => {
      const newList: any[] = [{ id: 1 }];
      const oldList: any[] = [{ id: 1, stndCapability: { id: 1 } }];
      const availableCapabilities: any[] = [];

      const result = component['getPostList'](newList, oldList, availableCapabilities);

      expect(result.putList.length).toBe(1);
    });

    it('should identify removed capabilities', () => {
      const newList: any[] = [];
      const oldList: any[] = [{ id: 1, stndCapability: { id: 1 } }];
      const availableCapabilities: any[] = [{ id: 1 }];

      const result = component['getPostList'](newList, oldList, availableCapabilities);

      expect(result.removeList.length).toBe(1);
    });
  });

  describe('isInList', () => {
    it('should find capability in list by id', () => {
      const list = [{ id: 1 }, { id: 2 }, { id: 3 }];
      const result = component['isInList'](list, 2);
      expect(result).toEqual({ id: 2 });
    });

    it('should find capability in list by stndCapability.id', () => {
      const list = [{ stndCapability: { id: 1 } }, { stndCapability: { id: 2 } }];
      const result = component['isInList'](list, 2);
      expect(result).toEqual({ stndCapability: { id: 2 } });
    });

    it('should return null if capability not found', () => {
      const list = [{ id: 1 }, { id: 2 }];
      const result = component['isInList'](list, 99);
      expect(result).toBeNull();
    });
  });

  describe('getPrimaryOrganization', () => {
    it('should return primary organization acronym', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
        },
        {
          primaryOrganizationIndicator: true,
          organization: { businessAreaCode: 'BA2', shortName: 'ORG2' }
        }
      ];

      const result = component['getPrimaryOrganization'](organizationHistory);
      expect(result).toBe('BA2/ORG2');
    });

    it('should return empty string if no primary organization found', () => {
      const organizationHistory = [
        {
          primaryOrganizationIndicator: false,
          organization: { businessAreaCode: 'BA1', shortName: 'ORG1' }
        }
      ];

      const result = component['getPrimaryOrganization'](organizationHistory);
      expect(result).toBe('');
    });
  });

  describe('hideMessageDiv', () => {
    it('should hide message', () => {
      component.hideMessage = false;
      component.hideMessageDiv();
      expect(component.hideMessage).toBe(true);
    });
  });

  describe('workerAdd', () => {
    it('should navigate to add contractor page', () => {
      component.workerEmploymentType = 'C';
      component.workerAdd();
      expect(appService.changePage).toHaveBeenCalledWith('/app/add-worker/contractor');
    });

    it('should navigate to add worker page', () => {
      component.workerEmploymentType = 'E';
      component.workerAdd();
      expect(appService.changePage).toHaveBeenCalledWith('/app/add-worker/worker');
    });

    it('should set isTrademarkWorker in localStorage', () => {
      component.workerAdd(true);
      expect(localStorageService.setItem).toHaveBeenCalledWith('isTrademarkWorker', 'true');
    });
  });

  describe('buildAdvancedWorkerSearchExportQueryParamTwo', () => {
    it('should build URL with all search criteria', () => {
      const savedSearchCriteria = {
        classCode: { value: 'classCode', description: 'CC1' },
        firmName: { value: 'firmName', description: 'Firm1' },
        firmAdministrator: { value: 'firmAdministrator', description: 'Admin1' },
        businessAreaCode: { value: 'businessAreaCode', description: 'BA1' },
        shortName: { value: 'shortName', description: 'ORG1' },
        allFirms: false,
        loginWorkerNumber: { value: 'loginWorkerNumber', description: '12345' },
        workerAssociatedFirms: { value: 'workerAssociatedFirms', description: 'Firm1' },
        buildingCode: { value: 'buildingCode', description: 'BLDG1' },
        floorNumber: { value: 'floorNumber', description: '1' },
        corridorId: { value: 'corridorId', description: 'COR1' },
        roomId: { value: 'roomId', description: 'ROOM1' },
        suiteId: { value: 'suiteId', description: 'SUITE1' },
        zoneId: { value: 'zoneId', description: 'ZONE1' },
        phoneNumber: { value: 'phoneNumber', description: '555-1234' }
      };

      let url = 'base';
      url = component.buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria, url);

      expect(url).toContain('classCode=CC1');
      expect(url).toContain('firmName=Firm1');
      expect(url).toContain('phoneNumber=555-1234');
    });

    it('should skip empty criteria', () => {
      const savedSearchCriteria = {
        classCode: { value: 'classCode', description: '' },
        firmName: { value: 'firmName', description: '' },
        firmAdministrator: { value: 'firmAdministrator', description: '' },
        businessAreaCode: { value: 'businessAreaCode', description: '' },
        shortName: { value: 'shortName', description: '' },
        allFirms: true,
        loginWorkerNumber: { value: 'loginWorkerNumber', description: '' },
        workerAssociatedFirms: { value: 'workerAssociatedFirms', description: '' },
        buildingCode: { value: 'buildingCode', description: '' },
        floorNumber: { value: 'floorNumber', description: '' },
        corridorId: { value: 'corridorId', description: '' },
        roomId: { value: 'roomId', description: '' },
        suiteId: { value: 'suiteId', description: '' },
        zoneId: { value: 'zoneId', description: '' },
        phoneNumber: { value: 'phoneNumber', description: '' }
      };

      let url = 'base';
      url = component.buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria, url);

      expect(url).toBe('base');
    });
  });

  describe('exportDataCallback', () => {
    it('should build export URL for active workers', () => {
      component.activeWorker = 'active';
      component.applicationType = 'Worker';
      component.basicSearch = false;
      component.savedSearchCriteria = {};
      component.sortColumn = 'lastName';
      component.sortDirection = 'asc';
      component.total = 100;
      component.buildAdvancedWorkerSearchExportQueryParamOne = jasmine.createSpy().and.returnValue('url1');
      component.buildAdvancedWorkerSearchExportQueryParamTwo = jasmine.createSpy().and.returnValue('url2');

      component.exportDataCallback();

      expect(component.showWait).toBe(true);
    });

    it('should build export URL for contractors', () => {
      component.activeWorker = 'active';
      component.applicationType = 'Contractor';
      component.basicSearch = false;
      component.savedSearchCriteria = {};
      component.sortColumn = 'lastName';
      component.sortDirection = 'asc';
      component.total = 100;
      component.buildAdvancedWorkerSearchExportQueryParamOne = jasmine.createSpy().and.returnValue('url1');
      component.buildAdvancedWorkerSearchExportQueryParamTwo = jasmine.createSpy().and.returnValue('url2');

      component.exportDataCallback();

      expect(component.showWait).toBe(true);
    });
  });

  describe('workerAddmultipleContractor', () => {
    it('should navigate to create multiple contractors page', () => {
      component.workerEmploymentType = 'C';
      component.workerAddmultipleContractor();
      expect(appService.changePage).toHaveBeenCalledWith('/createMultipleContractors/Contractor');
    });
  });

  describe('employeeStatus', () => {
    it('should be defined', () => {
      expect(component.employeeStatus).toBeDefined();
    });
  });

  describe('contractorStatus', () => {
    it('should be defined', () => {
      expect(component.contractorStatus).toBeDefined();
    });
  });

  describe('generateReports', () => {
    it('should be defined', () => {
      expect(component.generateReports).toBeDefined();
    });
  });
});
