import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdvancedSearchActingSPEComponent } from './advanced-search-actingspe.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('AdvancedSearchActingSPEComponent', () => {
  let component: AdvancedSearchActingSPEComponent;
  let fixture: ComponentFixture<AdvancedSearchActingSPEComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdvancedSearchActingSPEComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(AdvancedSearchActingSPEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('initialization', () => {
    it('should initialize with default values', () => {
      expect(component.status).toBe(true);
      expect(component.workerNumber).toBe(123);
      expect(component.userRoles).toEqual(['InfraAdmin']);
    });

    it('should initialize advanceSearchOptions', () => {
      expect(component.advanceSearchOptions).toBeDefined();
      expect(component.advanceSearchOptions.ssn).toBeDefined();
      expect(component.advanceSearchOptions.workerNumber).toBeDefined();
    });
  });

  describe('setSearchType', () => {
    it('should emit search event for advanced search', () => {
      spyOn(component.search, 'emit');
      component.advanceSearchOptions.lastName.description = 'Doe';

      component.setSearchType(false);

      expect(component.search.emit).toHaveBeenCalledWith({
        searchType: 'advanced',
        searchCriteria: component.advanceSearchOptions
      });
    });

    it('should clear search results when switching to basic search', () => {
      spyOn(component, 'clearAdvanvedSearch');
      component.setSearchType(true);
      expect(component.clearAdvanvedSearch).toHaveBeenCalled();
    });

    it('should not search if all fields are blank', () => {
      spyOn(component.search, 'emit');
      component.setSearchType(false);
      expect(component.search.emit).not.toHaveBeenCalled();
    });
  });

  describe('checkBlankAdvanceSearch', () => {
    it('should return false if ssn2 has value', () => {
      component.advanceSearchOptions.ssn2.description = '123';
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(false);
    });

    it('should return false if birthDate has value', () => {
      component.advanceSearchOptions.birthDate.description = '01/15/1990';
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(false);
    });

    it('should return false if classCode has value', () => {
      component.advanceSearchOptions.classCode.description = 'CC1';
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(false);
    });

    it('should return false if firmName has value', () => {
      component.advanceSearchOptions.firmName.description = 'Firm1';
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(false);
    });

    it('should return false if lastName has value', () => {
      component.advanceSearchOptions.lastName.description = 'Doe';
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(false);
    });

    it('should return true if all fields are blank', () => {
      const result = component.checkBlankAdvanceSearch();
      expect(result).toBe(true);
    });
  });

  describe('checkBlankAdvanceSearchHelper', () => {
    it('should return false if ssn has value', () => {
      component.advanceSearchOptions.ssn.description = '123-45-6789';
      const result = component.checkBlankAdvanceSearchHelper();
      expect(result).toBe(false);
    });

    it('should return false if workerNumber has value', () => {
      component.advanceSearchOptions.workerNumber.description = '12345';
      const result = component.checkBlankAdvanceSearchHelper();
      expect(result).toBe(false);
    });

    it('should return false if firstName has value', () => {
      component.advanceSearchOptions.firstName.description = 'John';
      const result = component.checkBlankAdvanceSearchHelper();
      expect(result).toBe(false);
    });

    it('should return true if all fields are blank', () => {
      const result = component.checkBlankAdvanceSearchHelper();
      expect(result).toBe(true);
    });
  });

  describe('searchKeyEventAdvanced', () => {
    it('should trigger search on Enter key', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 13 };

      component.searchKeyEventAdvanced(event);

      expect(component.setSearchType).toHaveBeenCalledWith(false);
    });

    it('should not trigger search on other keys', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 65 };

      component.searchKeyEventAdvanced(event);

      expect(component.setSearchType).not.toHaveBeenCalled();
    });
  });

  describe('buildingChanged', () => {
    it('should clear building floors', () => {
      component.buildingFloors = [{ id: 1 }, { id: 2 }];

      component.buildingChanged();

      expect(component.buildingFloors).toEqual([]);
    });
  });

  describe('onAcronymChange', () => {
    it('should parse acronym and set business area code and short name', () => {
      component.onAcronymChange('BA1/ORG1');

      expect(component.advanceSearchOptions.businessAreaCode.description).toBe('BA1');
      expect(component.advanceSearchOptions.shortName.description).toBe('ORG1');
    });

    it('should clear values if acronym is empty', () => {
      component.advanceSearchOptions.businessAreaCode.description = 'BA1';
      component.advanceSearchOptions.shortName.description = 'ORG1';

      component.onAcronymChange('');

      expect(component.advanceSearchOptions.businessAreaCode.description).toBe('');
      expect(component.advanceSearchOptions.shortName.description).toBe('');
    });

    it('should handle invalid acronym format', () => {
      component.onAcronymChange('InvalidAcronym');

      expect(component.advanceSearchOptions.businessAreaCode.description).toBe('');
      expect(component.advanceSearchOptions.shortName.description).toBe('');
    });
  });

  describe('onAcronymSelected', () => {
    it('should set business area code and short name from dialog result', () => {
      const result = {
        organizationType: { businessArea: { code: 'BA1' } },
        shortName: 'ORG1'
      };

      component.onAcronymSelected(result);

      expect(component.advanceSearchOptions.businessAreaCode.description).toBe('BA1');
      expect(component.advanceSearchOptions.shortName.description).toBe('ORG1');
    });

    it('should handle null result', () => {
      component.onAcronymSelected(null);

      expect(component.advanceSearchOptions.businessAreaCode.description).toBe('');
      expect(component.advanceSearchOptions.shortName.description).toBe('');
    });
  });

  describe('clearAdvanvedSearch', () => {
    it('should reset all search options', () => {
      component.advanceSearchOptions.lastName.description = 'Doe';
      component.advanceSearchAcronym = 'BA1/ORG1';

      component.clearAdvanvedSearch();

      expect(component.advanceSearchOptions.lastName.description).toBe('');
      expect(component.advanceSearchAcronym).toBe('');
    });

    it('should emit clear event', () => {
      spyOn(component.clear, 'emit');

      component.clearAdvanvedSearch();

      expect(component.clear.emit).toHaveBeenCalled();
    });

    it('should reset validation flags', () => {
      component.invalidAdvancedAcronym = true;
      component.acronymInvalid = true;

      component.clearAdvanvedSearch();

      expect(component.invalidAdvancedAcronym).toBe(false);
      expect(component.acronymInvalid).toBe(false);
    });
  });

  describe('setAdvanceSearchOptions', () => {
    it('should reset all search options to empty', () => {
      component.advanceSearchOptions.lastName.description = 'Doe';
      component.advanceSearchOptions.firstName.description = 'John';

      component.setAdvanceSearchOptions();

      expect(component.advanceSearchOptions.lastName.description).toBe('');
      expect(component.advanceSearchOptions.firstName.description).toBe('');
    });

    it('should set loginWorkerNumber from userInfo', () => {
      component.userInfo = { workerNumber: '12345' };

      component.setAdvanceSearchOptions();

      expect(component.advanceSearchOptions.loginWorkerNumber.description).toBe('12345');
    });

    it('should set workerAssociatedFirms to true', () => {
      component.setAdvanceSearchOptions();

      expect(component.advanceSearchOptions.workerAssociatedFirms.description).toBe(true);
    });
  });

  describe('searchKeyEventBasic', () => {
    it('should trigger search on Enter key', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 13 };

      component.searchKeyEventBasic(event);

      expect(component.setSearchType).toHaveBeenCalledWith(true);
    });

    it('should not trigger search on other keys', () => {
      spyOn(component, 'setSearchType');
      const event = { keyCode: 65 };

      component.searchKeyEventBasic(event);

      expect(component.setSearchType).not.toHaveBeenCalled();
    });
  });
});
