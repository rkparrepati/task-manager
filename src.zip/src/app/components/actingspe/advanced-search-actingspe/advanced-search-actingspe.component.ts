import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-advanced-search-actingspe',
  templateUrl: './advanced-search-actingspe.component.html',
  styleUrls: ['./advanced-search-actingspe.component.scss'],
})
export class AdvancedSearchActingSPEComponent {
  @Output() search = new EventEmitter<any>();
  @Output() clear = new EventEmitter<void>();
  @Input() userInfo: any;
  @Input() jobClassCodeList: any[] = [];
  
  workerModel: any;
  basicSearch: any;
  savedSearchCriteria: any;
  basicSearchText: any;
  selectedSearchCriteria: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  searchResultsCount: any;
  basicSearchAcronym: any;
  basicSearchCriteria: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchSSNDiv: any;
  basicSearchFirmnameDiv: any;
  basicSearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  basicSearchDOBDiv: any;
  basicSearchLoginDiv: any;
  workerNumber: any = 123;
  addWorkerButton: any;
  buildingFloors: any;
  userRoles: any = ['InfraAdmin'];
  isContractor: any;
  hideSSN: any;
  applicationType: any;
  hideFirms: any;
  cedrRoleSearch: any;
  invalidBirthDate: any;
  birthDateErrorMessage: any;
  hideBuildingSearch: any;
  acronymInvalid: any;
  acronymEnter: any;
  advanceSearchAcronym: any;
  invalidAdvancedAcronym: any;
  hidePhoneNumberSearch: any;
  buildingCodeList: any;
  contractorFirmNames: any;
  status: boolean = true;
  advanceSearchOptions = {
    ssn: {
      value: 'socialSecurityNumber',
      description: '',
    },
    workerNumber: {
      value: 'workerNumber',
      description: '',
    },
    lastName: {
      value: 'familyName',
      description: '',
    },
    firstName: {
      value: 'givenName',
      description: '',
    },
    preferredFirstName: {
      value: 'preferredFirstName',
      description: '',
    },
    loginId: {
      value: 'loginId',
      description: '',
    },
    ssn2: {
      value: 'ssn2',
      description: '',
    },
    birthDate: {
      value: 'birthDate',
      description: '',
    },
    classCode: {
      value: 'classCode',
      description: '',
    },
    firmName: {
      value: 'firmName',
      description: '',
    },
    firmAdministrator: {
      value: 'firmAdministrator',
      description: '',
    },
    businessAreaCode: {
      value: 'businessAreaCode',
      description: '',
    },
    shortName: {
      value: 'shortName',
      description: '',
    },
    workerAssociatedFirms: {
      value: 'workerAssociatedFirms',
      description: true,
    },
    loginWorkerNumber: {
      value: 'loginWorkerNumber',
      description: this.workerNumber,
    },
    phoneNumber: {
      value: 'phoneNumber',
      description: '',
    },
    buildingCode: {
      value: 'buildingCode',
      description: '',
    },
    floorNumber: {
      value: 'floorNumber',
      description: '',
    },
    corridorId: {
      value: 'corridorId',
      description: '',
    },
    roomId: {
      value: 'roomId',
      description: '',
    },
    suiteId: {
      value: 'suiteId',
      description: '',
    },
    zoneId: {
      value: 'zoneId',
      description: '',
    },
    cedrRoles: {
      value: 'cedrRoles',
      description: '',
    },
  };
  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
  setSearchType(searchType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria?.value,
        },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo?.workerNumber,
      };
      this.clearAdvanvedSearch();
    } else {
      // Log the current state of advanceSearchOptions before validation      if (this.checkBlankAdvanceSearch()) {
        this.searchResultsCount = '';        return;
      }      // Emit search event with advanced search options
      this.search.emit({
        searchType: 'advanced',
        searchCriteria: this.advanceSearchOptions
      });
      
      this.savedSearchCriteria = { ...this.advanceSearchOptions };
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchAcronym = '';
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
    }
  }
  checkBlankAdvanceSearch() {
    if (
      this.advanceSearchOptions.ssn2.description ||
      this.advanceSearchOptions.birthDate.description ||
      this.advanceSearchOptions.classCode.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firmName.description ||
      this.advanceSearchOptions.businessAreaCode.description ||
      this.advanceSearchOptions.shortName.description ||
      this.advanceSearchOptions.firmAdministrator.description ||
      this.advanceSearchOptions.cedrRoles.description
    ) {
      return false;
    }

    return this.checkBlankAdvanceSearchHelper();
  }
  checkBlankAdvanceSearchHelper() {
    if (
      this.advanceSearchOptions.ssn.description ||
      this.advanceSearchOptions.workerNumber.description ||
      this.advanceSearchOptions.lastName.description ||
      this.advanceSearchOptions.phoneNumber.description
    ) {
      return false;
    }

    if (
      this.advanceSearchOptions.firstName.description ||
      this.advanceSearchOptions.preferredFirstName.description ||
      this.advanceSearchOptions.loginId.description ||
      this.advanceSearchOptions.buildingCode.description
    ) {
      return false;
    }
    if (this.advanceSearchOptions.workerNumber) {
      return true;
    }

    return true;
  }
  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }
  buildingChanged() {
    this.buildingFloors = [];
  }
  
  onAcronymChange(acronym: string) {    this.advanceSearchAcronym = acronym;
    
    // Parse the acronym to extract businessAreaCode and shortName
    if (acronym && acronym.includes('/')) {
      const parts = acronym.split('/');
      if (parts.length === 2) {
        this.advanceSearchOptions.businessAreaCode.description = parts[0].trim();
        this.advanceSearchOptions.shortName.description = parts[1].trim();      }
    } else {
      // Clear if acronym is empty or invalid
      this.advanceSearchOptions.businessAreaCode.description = '';
      this.advanceSearchOptions.shortName.description = '';
    }
  }
  
  onAcronymSelected(result: any) {    if (result && result.organizationType && result.shortName) {
      const businessAreaCode = result.organizationType.businessArea.code.trim();
      const shortName = result.shortName.trim();
      this.advanceSearchOptions.businessAreaCode.description = businessAreaCode;
      this.advanceSearchOptions.shortName.description = shortName;    }
  }
  clearAdvanvedSearch() {
    this.setAdvanceSearchOptions();
    this.advanceSearchAcronym = '';
    this.invalidAdvancedAcronym = false;
    this.acronymInvalid = false;
    
    // Emit clear event to parent component
    this.clear.emit();
  }
  setAdvanceSearchOptions() {
    this.advanceSearchOptions = {
      ssn: {
        value: 'socialSecurityNumber',
        description: '',
      },
      workerNumber: {
        value: 'workerNumber',
        description: '',
      },
      lastName: {
        value: 'familyName',
        description: '',
      },
      firstName: {
        value: 'givenName',
        description: '',
      },
      preferredFirstName: {
        value: 'preferredFirstName',
        description: '',
      },
      loginId: {
        value: 'loginId',
        description: '',
      },
      ssn2: {
        value: 'ssn2',
        description: '',
      },
      birthDate: {
        value: 'birthDate',
        description: '',
      },
      classCode: {
        value: 'classCode',
        description: '',
      },
      firmName: {
        value: 'firmName',
        description: '',
      },
      firmAdministrator: {
        value: 'firmAdministrator',
        description: '',
      },
      businessAreaCode: {
        value: 'businessAreaCode',
        description: '',
      },
      shortName: {
        value: 'shortName',
        description: '',
      },
      workerAssociatedFirms: {
        value: 'workerAssociatedFirms',
        description: true,
      },
      loginWorkerNumber: {
        value: 'loginWorkerNumber',
        description: this.userInfo?.workerNumber || '',
      },
      phoneNumber: {
        value: 'phoneNumber',
        description: '',
      },
      buildingCode: {
        value: 'buildingCode',
        description: '',
      },
      floorNumber: {
        value: 'floorNumber',
        description: '',
      },
      corridorId: {
        value: 'corridorId',
        description: '',
      },
      roomId: {
        value: 'roomId',
        description: '',
      },
      suiteId: {
        value: 'suiteId',
        description: '',
      },
      zoneId: {
        value: 'zoneId',
        description: '',
      },
      cedrRoles: {
        value: 'cedrRoles',
        description: '',
      },
    };
  }
}
