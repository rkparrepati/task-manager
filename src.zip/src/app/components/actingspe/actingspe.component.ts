import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { ActingSPEService } from './actingspe.service';
import { HttpService } from 'src/app/services/http.service';
import { forkJoin } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { EditCapabilitiesDialogComponent } from './edit-capabilities-dialog/edit-capabilities-dialog.component';
import { EmployeeStatusDialogComponent } from '../worker-management/employee-status-dialog/employee-status-dialog.component';

@Component({
  selector: 'app-actingspe',
  templateUrl: './actingspe.component.html',
  styleUrls: ['./actingspe.component.scss'],
})
export class ActingSPEComponent implements OnInit {
  public workerRecords: any = { meta: {}, results: [] };
  disableShowRadioButton: any;
  showType: any = 'active';
  setActiveWorkerList: any;
  searchResultsCount: any;
  showWait: any;
  savedSearchCriteria: any;
  activeWorker: any;
  basicSearch: any;
  sortColumn: any = 'lastName';
  userRoles: any = ['InfraAdmin', 'InfraOfficeCoordinator', 'InfraContractorAdmin'];
  isContractor: boolean = false;
  canAdd: boolean = true;
  workerModel: any = { workerList: [] };
  WorkerSearchService: any;
  sortDirection: any;
  buildBasicWorkerSearchExportQuery: any;
  applicationType: any;
  limit: number = 10;
  total: number = 0;
  workerEmploymentType: any;
  showWaitWorkerSearch: any;
  addWorkerButton: any;
  applicationTypeLowerCase: any = 'worker';
  loadingMessage: any;
  appTitle: any;
  buildAdvancedWorkerSearchExportQueryParamOne: any;
  otherSearchView: string = 'advanced';
  capabilityList: any[] = [];
  jobClassCodeList: any[] = [];
  userInfo: any;
  myOrg: string = '';
  infraAdminEmailAddress: string = '';
  
  // Message display properties (matching old AngularJS pattern)
  returnCode: number = 0;
  returnMessage: string = '';
  hideMessage: boolean = true;
  accessDenied: string = '';

  constructor(
    private appService: AppService,
    private localStorageService: LocalStorageService,
    private actingSPEService: ActingSPEService,
    private httpService: HttpService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // Initialize component first (loads reference data)
    this.initializeComponent();
    
    // Try to get user data with multiple retries
    this.waitForUserData(0);
  }
  
  private waitForUserData(attempt: number): void {
    const userData = this.appService.getUserData();
    if (userData && userData.workerNumber) {
      this.userInfo = userData;
      // Now load user-specific data
      this.loadUserHomeGAU();
    } else if (attempt < 10) {
      // Retry up to 10 times with 500ms delay
      setTimeout(() => {
        this.waitForUserData(attempt + 1);
      }, 500);
    } else {
    }
  }

  /**
   * Initialize component by loading all required data on page load
   * API calls made on page load (matching old AngularJS implementation):
   * 1. GET references/capabilities - for Acting SPE capabilities list
   * 2. GET references/job-classes - for job class codes dropdown
   * 3. GET parameters - to get INFRA_ADMIN_EMAIL_ADDRESS
   * 4. GET workers?workerNumber={logged-in-user}&includeInactive=true - to get user's home organization
   * 5. GET /workers?includeInactive=false&businessAreaCode=X&shortName=XXX&limit=10&skip=0&sortColumn=lastName&sortOrder=asc
   *    - default search based on user's organization from step 4
   */
  private initializeComponent(): void {
    // Load all initial data in parallel (matching old AngularJS: calls 1-3)
    forkJoin({
      capabilities: this.httpService.get('/references/capabilities'),
      jobClasses: this.httpService.get('/references/job-classes'),
      parameters: this.httpService.get('/parameters')
    }).subscribe({
      next: (results: any) => {
        // Store capabilities list (for Acting SPE capabilities management)
        this.capabilityList = results.capabilities?.results || [];
        
        // Store job class codes (for dropdown population)
        this.jobClassCodeList = results.jobClasses?.results || [];
        
        // Extract INFRA_ADMIN_EMAIL_ADDRESS from parameters
        const infraAdminParam = results.parameters?.results?.find(
          (param: any) => param.parameterName === 'INFRA_ADMIN_EMAIL_ADDRESS'
        );
        if (infraAdminParam) {
          this.infraAdminEmailAddress = infraAdminParam.parameterValueText;
          if (this.userInfo) {
            this.userInfo.infraAdminEmailAddress = infraAdminParam.parameterValueText;
          }
        }
        
        // Get user's worker info and load their home GAU workers (calls 4-5)
        // Only call if userInfo is available
        if (this.userInfo && this.userInfo.workerNumber) {
          this.loadUserHomeGAU();
        } else {
        }
      },
      error: (error: any) => {
      }
    });
  }

  /**
   * Loads the logged-in user's worker info and performs initial search for their home GAU
   * This replicates the old AngularJS behavior of automatically showing workers in user's GAU
   */
  private loadUserHomeGAU(): void {
    // Get worker number from userInfo (populated in ngOnInit from appService)
    const workerNumber = this.userInfo?.workerNumber;
    if (!workerNumber) {
      return;
    }

    // Get user's worker info to find their home GAU
    this.httpService.get(`/workers?workerNumber=${workerNumber}&includeInactive=true`).subscribe({
      next: (response: any) => {
        if (response.results && response.results.length > 0) {
          const worker = response.results[0];
          // Find primary organization (home GAU)
          const primaryOrg = worker.organizationHistory?.find(
            (org: any) => org.primaryOrganizationIndicator
          );
          if (primaryOrg && primaryOrg.organization) {
            const businessAreaCode = primaryOrg.organization.businessAreaCode;
            const shortName = primaryOrg.organization.shortName;
            this.myOrg = `${businessAreaCode}/${shortName}`;
            this.userInfo.myOrg = this.myOrg;
            // Perform initial search for workers in user's home GAU
            this.searchWorkersByHomeGAU(businessAreaCode, shortName);
          } else {
          }
        } else {
        }
      },
      error: (error: any) => {
      }
    });
  }

  /**
   * Search for workers in the user's home GAU (default search on page load)
   * This matches the old AngularJS handleAdvancedSearch function
   */
  private searchWorkersByHomeGAU(businessAreaCode: string, shortName: string, limit: number = 10, skip: number = 0): void {
    const url = `/workers?includeInactive=false&businessAreaCode=${businessAreaCode}&shortName=${shortName}&limit=${limit}&skip=${skip}&sortColumn=lastName&sortOrder=asc`;
    // Store search parameters for pagination
    this.savedSearchCriteria = {
      businessAreaCode: businessAreaCode,
      shortName: shortName
    };
    
    this.httpService.get(url).subscribe({
      next: (response: any) => {
        // Store results in workerModel.workerList (matching old AngularJS structure)
        this.workerModel = {
          workerList: response.results || [],
          selectedWorker: {},
          newWorker: {}
        };
        
        // Also store in workerRecords for grid component
        this.workerRecords = response;
        // Set total count for pagination
        this.total = response.meta?.total || 0;
        // Process each worker to add primaryOrganization (matching old code lines 211-218)
        this.workerModel.workerList.forEach((worker: any) => {
          worker.primaryOrganization = {};
          if (worker.organizationHistory) {
            const primaryOrg = worker.organizationHistory.find(
              (organization: any) => organization.primaryOrganizationIndicator
            );
            if (primaryOrg) {
              worker.primaryOrganization = primaryOrg;
            }
          }
        });
        
        // Set search results count message (matching old code lines 294-296)
        this.searchResultsCount = this.total > 0
          ? `${this.total} worker(s) have been found in my GAU/Organization (${this.myOrg})`
          : 'No workers have been found with the entered search criteria.';
      },
      error: (error: any) => {
        // Set empty results (matching old code lines 252-259)
        this.workerModel = {
          workerList: [],
          selectedWorker: {},
          newWorker: {}
        };
        this.workerRecords = { meta: {}, results: [] };
        this.total = 0;
        this.searchResultsCount = 'No workers have been found with the entered search criteria.';
      }
    });
  }
  toggleSearchView() {
    if (this.otherSearchView === 'basic') {
      this.otherSearchView = 'advanced';
    } else {
      this.otherSearchView = 'basic';
    }
  }
  exportDataCallback() {
    let url;
    this.showWait = true;
    const savedSearchCriteria = this.savedSearchCriteria;
    if (this.activeWorker === 'active') {
      url =
        this.applicationType === 'Contractor'
          ? 'workers/contractorExcelReport?includeInactive=false'
          : 'workers/workerExcelReport?includeInactive=false';
    } else {
      url =
        this.applicationType === 'Contractor'
          ? 'workers/contractorExcelReport?includeInactive=true'
          : 'workers/workerExcelReport?includeInactive=true';
    }
    url += this.applicationType === 'Contractor' ? '&isContractor=true' : '';
    if (this.basicSearch) {
      url = this.buildBasicWorkerSearchExportQuery(savedSearchCriteria, url);
    } else {
      url = this.buildAdvancedWorkerSearchExportQueryParamOne(savedSearchCriteria, url);
      url = this.buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria, url);
    }
    url += '&sortColumn=' + this.sortColumn;
    url += '&sortOrder=' + this.sortDirection;
    url += '&limit=' + this.total;

    this.showWaitWorkerSearch = true;
    //   WorkerSearchService.exportTableService(url, this.applicationType + 'SearchExport.xls',
    //     'application/vnd.ms-excel', true);
  }
  buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria: any, url: any) {
    url += savedSearchCriteria.classCode.description
      ? '&' + savedSearchCriteria.classCode.value + '=' + savedSearchCriteria.classCode.description
      : '';
    url += savedSearchCriteria.firmName.description
      ? '&' + savedSearchCriteria.firmName.value + '=' + savedSearchCriteria.firmName.description
      : '';
    url += savedSearchCriteria.firmAdministrator.description
      ? '&' +
        savedSearchCriteria.firmAdministrator.value +
        '=' +
        savedSearchCriteria.firmAdministrator.description
      : '';
    url += savedSearchCriteria.businessAreaCode.description
      ? '&' +
        savedSearchCriteria.businessAreaCode.value +
        '=' +
        savedSearchCriteria.businessAreaCode.description
      : '';
    url += savedSearchCriteria.shortName.description
      ? '&' + savedSearchCriteria.shortName.value + '=' + savedSearchCriteria.shortName.description
      : '';
    if (!savedSearchCriteria.allFirms) {
      url += savedSearchCriteria.loginWorkerNumber.description
        ? '&' +
          savedSearchCriteria.loginWorkerNumber.value +
          '=' +
          savedSearchCriteria.loginWorkerNumber.description
        : '';
      url += savedSearchCriteria.workerAssociatedFirms.description
        ? '&' +
          savedSearchCriteria.workerAssociatedFirms.value +
          '=' +
          savedSearchCriteria.workerAssociatedFirms.description
        : '';
    }
    url += savedSearchCriteria.buildingCode.description
      ? '&' +
        savedSearchCriteria.buildingCode.value +
        '=' +
        savedSearchCriteria.buildingCode.description
      : '';
    url += savedSearchCriteria.floorNumber.description
      ? '&' +
        savedSearchCriteria.floorNumber.value +
        '=' +
        savedSearchCriteria.floorNumber.description
      : '';
    url += savedSearchCriteria.corridorId.description
      ? '&' +
        savedSearchCriteria.corridorId.value +
        '=' +
        savedSearchCriteria.corridorId.description
      : '';
    url += savedSearchCriteria.roomId.description
      ? '&' + savedSearchCriteria.roomId.value + '=' + savedSearchCriteria.roomId.description
      : '';
    url += savedSearchCriteria.suiteId.description
      ? '&' + savedSearchCriteria.suiteId.value + '=' + savedSearchCriteria.suiteId.description
      : '';
    url += savedSearchCriteria.zoneId.description
      ? '&' + savedSearchCriteria.zoneId.value + '=' + savedSearchCriteria.zoneId.description
      : '';
    url += savedSearchCriteria.phoneNumber.description
      ? '&' +
        savedSearchCriteria.phoneNumber.value +
        '=' +
        savedSearchCriteria.phoneNumber.description
      : '';
    return url;
  }
  workerAdd(isTrademarkWorker: boolean = false) {
    this.localStorageService.removeItem('isTrademarkWorker');
    isTrademarkWorker = isTrademarkWorker || false;
    this.localStorageService.setItem('isTrademarkWorker', isTrademarkWorker.toString());
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/app/add-worker/contractor');
    } else {
      this.appService.changePage('/app/add-worker/worker');
    }
  }
  employeeStatus() {
    const dialogRef = this.dialog.open(EmployeeStatusDialogComponent, {
      width: '600px',
      height: 'auto',
      maxHeight: '800px',
      autoFocus: false,
      disableClose: false,
      data: null,
      panelClass: 'employee-status-dialog'
    });

    dialogRef.afterClosed().subscribe((result) => {
      // Dialog closed, no additional action needed
    });
  }
  contractorStatus = function () {
    // ngDialog.openConfirm({
    //     template : 'app/ActingSPE/multiContractorStatus.html',
    //     controller : 'MultiContractorStatusDialogController',
    //     data : null,
    //     controllerAs : 'vm'
    // // }).then(function(confirmSaveExit) {
    // }).then(function(workersList) {
    //     var promises = [];
    //     vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilityService.exportTableServicePOST(url, 'ContractorStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    // }, function() {
    // });
  };
  generateReports = function () {
    // ngDialog.openConfirm({
    //     template : 'app/ActingSPE/accessionSelectDialog.html',
    //     controller : 'SelectAccessionReportController',
    //     data : null,
    //     controllerAs : 'vm'
    // }).then(function(confirmSaveExit) {
    //     if (confirmSaveExit === 'yes') {
    //         vm.showSelectAssesionDialog();
    //     } else {
    //         vm.exitToWorkerSearch();
    //     }
    // }, function() {
    // });
  };
  workerAddmultipleContractor() {
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/createMultipleContractors/Contractor');
    }
    //  else {
    //     vm.gotoPage("/workerAdd/Worker");
    // }
  }

  public searchWorkers(data: any): void {
    this.actingSPEService
      .getActingSPEs(this.showType === 'active' ? false : true, data.searchText)
      .subscribe((response) => {
        this.workerRecords = response;
      });
  }

  /**
   * Handle advanced search from the advanced search component
   */
  public handleAdvancedSearch(event: any): void {
    if (!event || !event.searchCriteria) {
      return;
    }

    const searchCriteria = event.searchCriteria;
    
    // Build query parameters from search criteria
    let queryParams: string[] = [];
    
    // Add each search field if it has a value
    if (searchCriteria.ssn?.description) {
      queryParams.push(`${searchCriteria.ssn.value}=${encodeURIComponent(searchCriteria.ssn.description)}`);
    }
    if (searchCriteria.workerNumber?.description) {
      queryParams.push(`${searchCriteria.workerNumber.value}=${encodeURIComponent(searchCriteria.workerNumber.description)}`);
    }
    if (searchCriteria.lastName?.description) {
      queryParams.push(`${searchCriteria.lastName.value}=${encodeURIComponent(searchCriteria.lastName.description)}`);
    }
    if (searchCriteria.firstName?.description) {
      queryParams.push(`${searchCriteria.firstName.value}=${encodeURIComponent(searchCriteria.firstName.description)}`);
    }
    if (searchCriteria.preferredFirstName?.description) {
      queryParams.push(`${searchCriteria.preferredFirstName.value}=${encodeURIComponent(searchCriteria.preferredFirstName.description)}`);
    }
    if (searchCriteria.loginId?.description) {
      queryParams.push(`${searchCriteria.loginId.value}=${encodeURIComponent(searchCriteria.loginId.description)}`);
    }
    if (searchCriteria.ssn2?.description) {
      queryParams.push(`${searchCriteria.ssn2.value}=${encodeURIComponent(searchCriteria.ssn2.description)}`);
    }
    if (searchCriteria.birthDate?.description) {
      queryParams.push(`${searchCriteria.birthDate.value}=${encodeURIComponent(searchCriteria.birthDate.description)}`);
    }
    if (searchCriteria.classCode?.description) {
      queryParams.push(`${searchCriteria.classCode.value}=${encodeURIComponent(searchCriteria.classCode.description)}`);
    }
    if (searchCriteria.firmName?.description) {
      queryParams.push(`${searchCriteria.firmName.value}=${encodeURIComponent(searchCriteria.firmName.description)}`);
    }
    if (searchCriteria.firmAdministrator?.description) {
      queryParams.push(`${searchCriteria.firmAdministrator.value}=${encodeURIComponent(searchCriteria.firmAdministrator.description)}`);
    }
    if (searchCriteria.businessAreaCode?.description) {
      queryParams.push(`${searchCriteria.businessAreaCode.value}=${encodeURIComponent(searchCriteria.businessAreaCode.description)}`);
    }
    if (searchCriteria.shortName?.description) {
      queryParams.push(`${searchCriteria.shortName.value}=${encodeURIComponent(searchCriteria.shortName.description)}`);
    }
    if (searchCriteria.phoneNumber?.description) {
      queryParams.push(`${searchCriteria.phoneNumber.value}=${encodeURIComponent(searchCriteria.phoneNumber.description)}`);
    }
    if (searchCriteria.buildingCode?.description) {
      queryParams.push(`${searchCriteria.buildingCode.value}=${encodeURIComponent(searchCriteria.buildingCode.description)}`);
    }
    if (searchCriteria.floorNumber?.description) {
      queryParams.push(`${searchCriteria.floorNumber.value}=${encodeURIComponent(searchCriteria.floorNumber.description)}`);
    }
    if (searchCriteria.corridorId?.description) {
      queryParams.push(`${searchCriteria.corridorId.value}=${encodeURIComponent(searchCriteria.corridorId.description)}`);
    }
    if (searchCriteria.roomId?.description) {
      queryParams.push(`${searchCriteria.roomId.value}=${encodeURIComponent(searchCriteria.roomId.description)}`);
    }
    if (searchCriteria.suiteId?.description) {
      queryParams.push(`${searchCriteria.suiteId.value}=${encodeURIComponent(searchCriteria.suiteId.description)}`);
    }
    if (searchCriteria.zoneId?.description) {
      queryParams.push(`${searchCriteria.zoneId.value}=${encodeURIComponent(searchCriteria.zoneId.description)}`);
    }
    if (searchCriteria.cedrRoles?.description) {
      queryParams.push(`${searchCriteria.cedrRoles.value}=${encodeURIComponent(searchCriteria.cedrRoles.description)}`);
    }

    // Add default parameters
    queryParams.push('includeInactive=false');
    queryParams.push(`limit=${this.limit}`);
    queryParams.push('skip=0');
    queryParams.push('sortColumn=lastName');
    queryParams.push('sortOrder=asc');

    const url = `/workers?${queryParams.join('&')}`;
    // Store search criteria for pagination
    this.savedSearchCriteria = searchCriteria;
    this.basicSearch = false;

    this.httpService.get(url).subscribe({
      next: (response: any) => {
        // Store results
        this.workerModel = {
          workerList: response.results || [],
          selectedWorker: {},
          newWorker: {}
        };

        this.workerRecords = response;
        this.total = response.meta?.total || 0;

        // Process each worker to add primaryOrganization
        this.workerModel.workerList.forEach((worker: any) => {
          worker.primaryOrganization = {};
          if (worker.organizationHistory) {
            const primaryOrg = worker.organizationHistory.find(
              (organization: any) => organization.primaryOrganizationIndicator
            );
            if (primaryOrg) {
              worker.primaryOrganization = primaryOrg;
            }
          }
        });

        // Set search results count message
        this.searchResultsCount = this.total > 0
          ? `${this.total} worker(s) have been found with the entered search criteria.`
          : 'No workers have been found with the entered search criteria.';
      },
      error: (error: any) => {
        this.workerModel = {
          workerList: [],
          selectedWorker: {},
          newWorker: {}
        };
        this.workerRecords = { meta: {}, results: [] };
        this.total = 0;
        this.searchResultsCount = 'No workers have been found with the entered search criteria.';
      }
    });
  }

  /**
   * Handle clear search - reset to default home GAU search
   */
  public handleClearSearch(): void {
    // Reset search results
    this.workerModel = {
      workerList: [],
      selectedWorker: {},
      newWorker: {}
    };
    this.workerRecords = { meta: {}, results: [] };
    this.total = 0;
    this.searchResultsCount = '';
    this.savedSearchCriteria = null;
    
    // Reload default home GAU search if user info is available
    if (this.userInfo && this.myOrg) {
      const [businessAreaCode, shortName] = this.myOrg.split('/');
      if (businessAreaCode && shortName) {
        this.searchWorkersByHomeGAU(businessAreaCode, shortName, this.limit, 0);
      }
    }
  }

  /**
   * Handle page size change event from pagination component
   */
  pageSizeChangedEvent(limit: number): void {
    this.limit = limit;
    // Re-run the search with the new page size
    if (this.savedSearchCriteria && this.savedSearchCriteria.businessAreaCode) {
      this.searchWorkersByHomeGAU(
        this.savedSearchCriteria.businessAreaCode,
        this.savedSearchCriteria.shortName,
        this.limit,
        0
      );
    }
  }

  /**
   * Handle page change event from pagination component
   */
  onPageChanged(pageNumber: number): void {
    const skip = (pageNumber - 1) * this.limit;
    // Re-run the search with the new skip value
    if (this.savedSearchCriteria && this.savedSearchCriteria.businessAreaCode) {
      this.searchWorkersByHomeGAU(
        this.savedSearchCriteria.businessAreaCode,
        this.savedSearchCriteria.shortName,
        this.limit,
        skip
      );
    }
  }

  /**
   * Handle edit capabilities event from grid component
   * Opens dialog to edit worker's Acting SPE capabilities
   */
  public editCapabilities(worker: any): void {
    // Check if user has admin role
    const isAdmin = this.userInfo?.roles?.indexOf('InfraAdmin') >= 0 ||
                    this.userInfo?.roles?.indexOf('InfraSupervisorAdmin') >= 0;
    
    if (!isAdmin) {
      return;
    }

    // Hide any existing messages before opening dialog
    this.hideMessage = true;

    const dialogInfo = {
      titleType: 'text-info',
      title: `Add/Remove Acting SPE capabilities for ${worker.givenName} ${worker.familyName}`,
      button: 'Update capabilities',
      worker: worker,
      capabilities: this.capabilityList
    };

    const dialogRef = this.dialog.open(EditCapabilitiesDialogComponent, {
      width: '800px',
      data: dialogInfo,
      disableClose: true,  // Prevent closing by clicking outside
      hasBackdrop: true,   // Ensure backdrop is present
      autoFocus: true      // Auto focus first element
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.saveCapabilities(worker, result);
      }
    });
  }

  /**
   * Save capabilities from dialog. Creates a create, edit and delete list.
   */
  private saveCapabilities(worker: any, data: any): void {
    // Validate dates
    const dateError = this.validateEndDate(data.beginDate, data.endDate);
    if (dateError) {
      this.returnMessage = dateError;
      this.returnCode = 400;
      this.hideMessage = false;
      return;
    }

    const theLists = this.getPostList(data.newCapabilityList, worker.capabilities, data.availableCapabilities);
    
    if (theLists.postList.length === 0 && theLists.putList.length === 0 && theLists.removeList.length === 0) {
      this.returnMessage = 'No changes detected to capability lists';
      this.returnCode = 100;
      this.hideMessage = false;
      return;
    }

    worker.homeOrg = this.getPrimaryOrganization(worker.organizationHistory);
    
    this.actingSPEService.updateActingSPE(
      worker,
      theLists.postList,
      theLists.putList,
      theLists.removeList,
      data.beginDate,
      data.endDate,
      this.userInfo
    ).subscribe({
      next: () => {
        // Display success message on the page (matching old AngularJS pattern)
        this.returnMessage = `Employee ${worker.workerNumber} capabilities have been updated successfully`;
        this.returnCode = 200;
        this.hideMessage = false;
        
        // Refresh the search results
        if (this.savedSearchCriteria && this.savedSearchCriteria.businessAreaCode) {
          this.searchWorkersByHomeGAU(
            this.savedSearchCriteria.businessAreaCode,
            this.savedSearchCriteria.shortName,
            this.limit,
            0
          );
        }
      },
      error: (error: any) => {
        this.returnCode = error.status || 500;
        this.returnMessage = 'Problem saving capability list. Please try again.';
        this.hideMessage = false;
      }
    });
  }

  /**
   * Validate that end date is after begin date
   */
  private validateEndDate(beginDate: string, endDate: string): string | null {
    if (!beginDate || !endDate) {
      return 'Both start and end dates are required';
    }

    const begin = new Date(beginDate);
    const end = new Date(endDate);

    if (end < begin) {
      return 'End date must be after start date';
    }

    return null;
  }

  /**
   * Builds the create, update, and delete capability lists
   */
  private getPostList(newList: any[], oldList: any[], availableCapabilities: any[]): any {
    const postList: any[] = [];
    const putList: any[] = [];
    const removeList: any[] = [];

    // Check for new and updated capabilities
    newList.forEach((anItem: any) => {
      const matchedItem = this.isInList(oldList, anItem.id);
      if (!matchedItem) {
        postList.push(anItem);
      } else {
        putList.push(matchedItem);
      }
    });

    // Check for removed capabilities
    oldList.forEach((anItem: any) => {
      const matchedItem = this.isInList(availableCapabilities, anItem.stndCapability.id);
      if (matchedItem) {
        removeList.push(anItem);
      }
    });

    return {
      postList: postList,
      putList: putList,
      removeList: removeList
    };
  }

  /**
   * Sees if capability is in the passed in list
   */
  private isInList(list: any[], capabilityId: number): any {
    let inList: any = null;
    list.forEach((item: any) => {
      let id: number;
      if (item.id) {
        id = item.id;
      } else {
        id = item.stndCapability.id;
      }
      if (id === capabilityId) {
        inList = item;
      }
    });
    return inList;
  }

  /**
   * Gets the primary organization of history list
   */
  private getPrimaryOrganization(organizationHistory: any[]): string {
    let acronym = '';
    organizationHistory.forEach((organization: any) => {
      if (organization.primaryOrganizationIndicator) {
        acronym = organization.organization.businessAreaCode + '/' +
                  organization.organization.shortName;
      }
    });
    return acronym;
  }

  /**
   * Hides success/error message (matching old AngularJS pattern)
   */
  public hideMessageDiv(): void {
    this.hideMessage = true;
  }
}
