import { Component } from '@angular/core';
import { AppService } from 'src/app/services/app.service';

@Component({
  selector: 'app-infra-coordinator-admin',
  templateUrl: './infra-coordinator-admin.component.html',
  styleUrls: ['./infra-coordinator-admin.component.scss'],
})
export class InfraCoordinatorAdminComponent {
  accessInfo: any = this.appService.getNavData();
  constructor(public appService: AppService) {}
}
