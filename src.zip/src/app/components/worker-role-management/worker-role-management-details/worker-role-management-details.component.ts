import { Component } from '@angular/core';

@Component({
  selector: 'app-worker-role-management-details',
  templateUrl: './worker-role-management-details.component.html',
  styleUrls: ['./worker-role-management-details.component.scss'],
})
export class WorkerRoleManagementDetailsComponent {}
