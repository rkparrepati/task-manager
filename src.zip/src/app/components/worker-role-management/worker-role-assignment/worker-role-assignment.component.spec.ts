import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { WorkerRoleAssignmentComponent } from './worker-role-assignment.component';
import { OrderByPipe } from '../../../pipes/orderby.pipe';

describe('WorkerRoleAssignmentComponent', () => {
  let component: WorkerRoleAssignmentComponent;
  let fixture: ComponentFixture<WorkerRoleAssignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WorkerRoleAssignmentComponent, OrderByPipe],
      imports: [FormsModule, BrowserAnimationsModule, AccordionModule.forRoot()],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkerRoleAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with empty roles', () => {
    expect(component.availableRoles.length).toBe(0);
    expect(component.assignedRoles.length).toBe(0);
  });

  it('should move selected available roles to assigned', () => {
    const mockRole = {
      reportRole: { displayItem: 'Test Role', code: 'TR' },
    };
    component.availableRoles = [mockRole];
    component.selectedAvailableRoles = [mockRole];

    component.moveWorkerRole('all', 'assigned');

    expect(component.availableRoles.length).toBe(0);
    expect(component.assignedRoles.length).toBe(1);
    expect(component.selectedAvailableRoles.length).toBe(0);
  });

  it('should move all available roles to assigned', () => {
    const mockRole1 = {
      reportRole: { displayItem: 'Test Role 1', code: 'TR1' },
    };
    const mockRole2 = {
      reportRole: { displayItem: 'Test Role 2', code: 'TR2' },
    };
    component.availableRoles = [mockRole1, mockRole2];

    component.moveAllWorkerRoles('all', 'assigned');

    expect(component.availableRoles.length).toBe(0);
    expect(component.assignedRoles.length).toBe(2);
  });

  it('should move selected assigned roles to available', () => {
    const mockRole = {
      reportRole: { displayItem: 'Test Role', code: 'TR' },
    };
    component.assignedRoles = [mockRole];
    component.selectedAssignedRoles = [mockRole];

    component.moveWorkerRole('assigned', 'all');

    expect(component.assignedRoles.length).toBe(0);
    expect(component.availableRoles.length).toBe(1);
    expect(component.selectedAssignedRoles.length).toBe(0);
  });

  it('should move all assigned roles to available', () => {
    const mockRole1 = {
      reportRole: { displayItem: 'Test Role 1', code: 'TR1' },
    };
    const mockRole2 = {
      reportRole: { displayItem: 'Test Role 2', code: 'TR2' },
    };
    component.assignedRoles = [mockRole1, mockRole2];

    component.moveAllWorkerRoles('assigned', 'all');

    expect(component.assignedRoles.length).toBe(0);
    expect(component.availableRoles.length).toBe(2);
  });

  it('should highlight assigned roles when they exist', () => {
    const mockRole = {
      reportRole: { displayItem: 'Test Role', code: 'TR' },
    };
    component.assignedRoles = [mockRole];

    expect(component.shouldHighlightAssignedRoles()).toBe(true);
  });

  it('should not highlight assigned roles when empty', () => {
    component.assignedRoles = [];

    expect(component.shouldHighlightAssignedRoles()).toBe(false);
  });

  it('should not move roles when no selection', () => {
    const mockRole = {
      reportRole: { displayItem: 'Test Role', code: 'TR' },
    };
    component.availableRoles = [mockRole];
    component.selectedAvailableRoles = [];

    component.moveWorkerRole('all', 'assigned');

    expect(component.availableRoles.length).toBe(1);
    expect(component.assignedRoles.length).toBe(0);
  });

  it('should set organization name and acronym from inputs', () => {
    component.organizationName = 'Test Organization';
    component.organizationAcronym = 'TO';

    expect(component.organizationName).toBe('Test Organization');
    expect(component.organizationAcronym).toBe('TO');
  });
});
