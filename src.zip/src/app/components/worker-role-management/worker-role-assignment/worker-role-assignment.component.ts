import { Component, Input, OnInit } from '@angular/core';

interface WorkerRole {
  reportRole: {
    displayItem: string;
    code: string;
  };
  [key: string]: any;
}

@Component({
  selector: 'app-worker-role-assignment',
  templateUrl: './worker-role-assignment.component.html',
  styleUrls: ['./worker-role-assignment.component.scss'],
})
export class WorkerRoleAssignmentComponent implements OnInit {
  @Input() organizationName: string = '';
  @Input() organizationAcronym: string = '';
  @Input() availableRoles: WorkerRole[] = [];
  @Input() assignedRoles: WorkerRole[] = [];

  selectedAvailableRoles: WorkerRole[] = [];
  selectedAssignedRoles: WorkerRole[] = [];

  constructor() {}

  ngOnInit(): void {
    this.initializeRoles();
  }

  /**
   * Initialize roles from input data
   */
  private initializeRoles(): void {
    // Roles are initialized from @Input properties
  }

  /**
   * Move selected roles between available and assigned lists
   * @param source - Source list ('all' for available, 'assigned' for assigned)
   * @param destination - Destination list ('all' for available, 'assigned' for assigned)
   */
  moveWorkerRole(source: string, destination: string): void {
    if (source === 'all' && destination === 'assigned') {
      this.moveSelectedToAssigned();
    } else if (source === 'assigned' && destination === 'all') {
      this.moveSelectedToAvailable();
    }
  }

  /**
   * Move all roles between available and assigned lists
   * @param source - Source list ('all' for available, 'assigned' for assigned)
   * @param destination - Destination list ('all' for available, 'assigned' for assigned)
   */
  moveAllWorkerRoles(source: string, destination: string): void {
    if (source === 'all' && destination === 'assigned') {
      this.moveAllToAssigned();
    } else if (source === 'assigned' && destination === 'all') {
      this.moveAllToAvailable();
    }
  }

  /**
   * Move selected available roles to assigned roles
   */
  private moveSelectedToAssigned(): void {
    if (this.selectedAvailableRoles.length === 0) {
      return;
    }

    this.selectedAvailableRoles.forEach((role) => {
      const index = this.availableRoles.indexOf(role);
      if (index > -1) {
        this.availableRoles.splice(index, 1);
        this.assignedRoles.push(role);
      }
    });

    this.selectedAvailableRoles = [];
  }

  /**
   * Move all available roles to assigned roles
   */
  private moveAllToAssigned(): void {
    this.assignedRoles.push(...this.availableRoles);
    this.availableRoles = [];
    this.selectedAvailableRoles = [];
  }

  /**
   * Move selected assigned roles to available roles
   */
  private moveSelectedToAvailable(): void {
    if (this.selectedAssignedRoles.length === 0) {
      return;
    }

    this.selectedAssignedRoles.forEach((role) => {
      const index = this.assignedRoles.indexOf(role);
      if (index > -1) {
        this.assignedRoles.splice(index, 1);
        this.availableRoles.push(role);
      }
    });

    this.selectedAssignedRoles = [];
  }

  /**
   * Move all assigned roles to available roles
   */
  private moveAllToAvailable(): void {
    this.availableRoles.push(...this.assignedRoles);
    this.assignedRoles = [];
    this.selectedAssignedRoles = [];
  }

  /**
   * Determine if assigned roles should be highlighted
   * @returns boolean indicating if highlight should be applied
   */
  shouldHighlightAssignedRoles(): boolean {
    return this.assignedRoles.length > 0;
  }
}
