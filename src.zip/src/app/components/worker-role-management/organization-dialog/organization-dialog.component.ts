import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ManagementService } from 'src/app/shared/services/management.service';
import { OrganizationService } from '../../organization/services/organization.service';

@Component({
  selector: 'app-organization-dialog',
  templateUrl: './organization-dialog.component.html',
  styleUrls: ['./organization-dialog.component.scss'],
})
export class OrganizationDialogComponent implements OnInit {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  reportsData: Array<any> = [];
  reportRoleData: any = {};

  constructor(
    private dialogRef: MatDialogRef<OrganizationDialogComponent>,
    private managementService: ManagementService,
    private organizationService: OrganizationService
  ) {}

  ngOnInit(): void {
    this.reportsData = [];
    // this.getOrganization();
    // this.managementService.getOrganizations(this.data.id).subscribe((response: any) => {
      this.reportRoleData = this.data[0].reportRole;
      for (const org of this.data) {
        // this.organizationService.getOrganization(org.organizationId as string).subscribe((response: any) => {
        if (org && org.organization) {
          this.reportsData.push(org.organization);
        }
        // });
      }
    // });
  }

  getOrganization() {
    this.organizationService.getOrganization(this.data.id as string).subscribe((response: any) => {
      this.reportRoleData = response;
    });
  }
  confirm() {
    this.dialogRef.close(true);
  }
  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
}
