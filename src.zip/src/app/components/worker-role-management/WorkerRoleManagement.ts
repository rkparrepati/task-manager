// Root myDeserializedClass = JsonConvert.DeserializeObject<List<Root>>(myJsonResponse);

export interface Audit {
  createdDate: string;
  createdUser: string | null;
  lastModifiedDate: string | null;
  lockControlNumber: number;
  createdLoginId: string;
  lastModifiedLoginId: string;
}
export interface Lifecycle {
  beginDate: string;
  endDate: string | null;
}
export interface WorkerRoleManagement {
  id: number;
  value: string;
  viewMode: number;
  description: string;
  lifecycle: Lifecycle;
  audit: Audit;
}
