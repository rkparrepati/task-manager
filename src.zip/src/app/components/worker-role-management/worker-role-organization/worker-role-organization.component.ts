import { Component, inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ManagementService } from 'src/app/shared/services/management.service';

@Component({
  selector: 'app-worker-role-organization',
  templateUrl: './worker-role-organization.component.html',
  styleUrls: ['./worker-role-organization.component.scss'],
})
export class WorkerRoleOrganizationComponent implements OnInit {
  data: any = inject(MAT_DIALOG_DATA);
  rootOrgData: any = {};
  orgData: any[] = [];
  title: string = '';
  constructor(
    private dialogRef: MatDialogRef<WorkerRoleOrganizationComponent>,
    private managementService: ManagementService
  ) {}

  ngOnInit(): void {
    this.getOrganization();
  }
  closeThisDialog(message: string = 'continue') {
    this.dialogRef.close(message);
  }
  confirm(message: any) {}
  updateFn(family: any) {}
  toggleExpand(orgData: any): void {
    orgData.showChildren = !orgData.showChildren;
  }
  childOrganization(family: any) {
    this.managementService
      .getOrganizationByParentId(family.organization.parentOrganization, family.children.length > 0)
      .subscribe((response: any) => {});
  }
  getOrganization() {
    this.managementService.getOrganization().subscribe((results: any) => {
      if (results) {
        let response = results.results;
        this.rootOrgData = {
          organization: response[0],
          name:
            response[0].organizationType.businessArea.code.trim() +
            '/' +
            response[0].shortName.trim() +
            ' ' +
            response[0].organizationName.trim(),
          showChildren: false,
          id: response[0].organizationType.businessArea.code.trim() + response[0].shortName.trim(),
          showFamily: true,
          root: true,
          inactive: false,
          selected: false,
          loaded: true,
          icon: 'fa-plus-square-o',
          toggleLabel: 'Expand',
          children: [],
        };
        this.list();
      }
    });
  }
  list(): void {
    this.managementService
      .getOrganizationById(this.rootOrgData.organization.parentOrganization.id)
      .subscribe((response: any) => {
        if (response) {
          for (let i = 0; i < response.results.length; i++) {
            let node = response.results[i];
            this.orgData.push({
              id: node.organizationType.businessArea.code.trim() + node.shortName.trim(),
              organization: node,
              name:
                node.organizationType.businessArea.code.trim() +
                '/' +
                node.shortName.trim() +
                ' ' +
                node.organizationName.trim(),
              // parentName : family.organization.name,
              showChildren: false,
              selected: false,
              loaded: false,
              root: false,
              showFamily: true,
              hasChildren: false,
              icon: 'fa-plus-square-o',
              toggleLabel: 'Expand',
              inactive: false,
              isDisabled: '',

              children: [],
            });
          }
        }
      });
  }
}
