import { Component, inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { WorkerRoleManagement } from './WorkerRoleManagement';
import { ManagementService } from 'src/app/shared/services/management.service';
import { MatDialog } from '@angular/material/dialog';
import { TemplateRef, ViewChild } from '@angular/core';
import { WorkerRoleOrganizationComponent } from './worker-role-organization/worker-role-organization.component';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { UtilityService } from 'src/app/services/utility.service';
import { OrganizationDialogComponent } from './organization-dialog/organization-dialog.component';
import { AppService } from 'src/app/services/app.service';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-worker-role-management',
  templateUrl: './worker-role-management.component.html',
  styleUrls: ['./worker-role-management.component.scss'],
})
export class WorkerRoleManagementComponent implements OnInit {
  dialog = inject(MatDialog);
  @ViewChild('secondDialog') secondDialogRef!: TemplateRef<any>;
  componentName: string = 'Worker Role';
  edit: boolean = false;
  hasError: boolean = false;
  hasSuccessor: boolean = false;
  resultMessage: string = '';
  errors: string[] = [];
  returnCode: number = 700;
  hideMessage: boolean = true;
  displayDescription: boolean = false;
  add: boolean = false;
  showType: string = 'active';
  total: number = 0;
  searchText: string = '';
  searchResultsMode: boolean = false;
  currentSearchText: string | null = '';
  workerRoleManagements: WorkerRoleManagement[] = [];
  dataWorkerRoleBYLastModifiedDate: any = [];
  // Toast message properties for app-acme-navbar-component
  main = { creationDate: new Date() };
  workerRoleManagement: WorkerRoleManagement = {
    id: 0,
    value: '',
    description: '',
    viewMode: 0,
    lifecycle: {
      beginDate: '',
      endDate: '',
    },
    audit: {
      createdDate: '',
      createdUser: '',
      lastModifiedDate: '',
      lockControlNumber: 0,
      createdLoginId: '',
      lastModifiedLoginId: '',
    },
  };
  public base: any = {
    newLocation: {
      invalidHiddenIndicator: true,
      singlePrimary: '',
      noPrimary: '',
      setPrimary: '',
      lifecycle: {},
      invalidPrimaryIndicator: false,
      multipleHiddenAssignments: false,
      multiplePrimaryAssignments: false,
      mailLocationIndicator: false,
    },
  };
  model: any = {};
  startDateHeader: string = 'Start Date *';
  disableShowRadioButton: boolean = true;
  invalidCode: string = '';
  sortDirection: string = 'asc';
  sortColumn: string = 'value';
  invalidDescription: boolean = false;
  invalidRoleCode: boolean = false;
  invalidStartDate: boolean = false;
  invalidEndDate: boolean = false;
  acronym: string = '';
  inValidRoleCodeErrorMessage: string | null = '';
  // invalidRoleCodeMessage: string = '';
  invalidDescriptionErrorMessage: string = '';
  beginDateErrorMessage: string | null = '';
  endDateErrorMessage: string | null = '';
  invalidSystemName: string = '';
  searchResults: string | null = '';
  added: boolean = false;
  edited: boolean = false;
  urls: any = {
    list: '/references/report-roles',
    add: '/sites',
    edit: '',
    delete: '',
    savePayload: this.workerRoleManagement,
  };
  managementService: any;
  userRoles: any;
  pageSize: number = 10;
  pageNumber: number = 0;
  constructor(
    managementService: ManagementService,
    private utilityService: UtilityService,
    public appService: AppService,
    private httpService: HttpService,
    private cdr: ChangeDetectorRef,
  ) {
    this.managementService = managementService;
  }
  setshowMode(management: any, expand: string): void {}
  ngOnInit(): void {
    this.appService.isShowingExportLoader = false;
    this.list();
    this.getDatabyLastModifiedDate();
  }
  search(): void {
    this.searchResultsMode = true;
    this.list();
  }
  searchKeyEvent(event: KeyboardEvent): void {
    if (event.keyCode === 13) {
      this.search();
    }
  }

  clearSearch() {
    this.searchResultsMode = false;
    this.searchText = '';
    this.list();
  }

  // validateRoleCode(): void {
  //   const value = this.model?.selectedManagement?.value;
  //   if (!value || value.trim() === '') {
  //     this.invalidRoleCode = true;
  //     this.invalidRoleCodeMessage = 'Role code is required';
  //   } else if (value.length > 6) {
  //     this.invalidRoleCode = true;
  //     this.invalidRoleCodeMessage = 'Role code cannot exceed 6 characters';
  //   } else {
  //     this.invalidRoleCode = false;
  //     this.invalidRoleCodeMessage = '';
  //   }
  // }

    validateBeginDate(): void {
    this.beginDateErrorMessage = this.utilityService.validateBeginDate(
      this.model?.selectedManagement?.lifecycle?.beginDate,
      true
    ) as string;
    this.invalidStartDate = !!this.beginDateErrorMessage;
    if (!this.beginDateErrorMessage) {
      this.validateEndDate();
    }
  }

  validateEndDate(): void {
    this.endDateErrorMessage = this.utilityService.validateEndDate(
      this.model?.selectedManagement?.lifecycle?.beginDate as string,
      this.model?.selectedManagement?.lifecycle?.endDate as string
    ) as string;
    this.invalidEndDate = !!this.endDateErrorMessage;
  }

  onAddBeginDateChanged(date: string | undefined): void {
    this.model.selectedManagement.lifecycle.beginDate = date || null;
    this.validateBeginDate();
  }

  onAddEndDateChanged(date: string | undefined): void {
    this.model.selectedManagement.lifecycle.endDate = date || null;
    this.validateEndDate();
  }

  updateSaveManagement(event: any): void {
    this.clearError();
    if (event.data == null) {
      this.hasError = true;
      this.hideMessage = false;
      this.resultMessage = 'Invalid input was detected. Please correct required/invalid fields.';
      setTimeout(() => {}, 5000);
    } else {
      event.viewMode = 0;
      // Validate the incoming data directly
      if (!this.validateEventData(event.data)) {
        this.hasError = true;
        this.hideMessage = false;
        this.resultMessage = 'Invalid input was detected. Please correct required/invalid fields.';
        setTimeout(() => {}, 5000);
      } else {
        // Ensure endDate is null if empty
        if (!event.data.lifecycle?.endDate) {
          event.data.lifecycle.endDate = null;
        }
        // Correct payload format: lifecycle first, then value, then description
        let payload = {
          lifecycle: {
            beginDate: event.data.lifecycle.beginDate,
            endDate: event.data.lifecycle.endDate,
          },
          value: event.data.value ? (event.data.value).toUpperCase() : '',
          description: event.data.description ? (event.data.description).toUpperCase() : '',
        };
        this.managementService
          .updateRoleWorker(payload, event.data.id, event.data.audit.lockControlNumber)
          .subscribe(
            (response: any) => {
              if (response) {
                this.edit = false;
                this.hasError = true;
                this.hideMessage = false;
                this.returnCode = 200;
                this.resultMessage =
                  'Successfully updated worker role: ' + response.value;
                this.list();
                this.getDatabyLastModifiedDate();
                this.cdr.detectChanges();
              }
              setTimeout(() => {
                this.clearError();
              }, 5000);
            },
            (error: any) => {
              this.hasError = true;
              this.hideMessage = false;
              this.returnCode = error.status || 500;
              this.resultMessage = error.error?.message || 'Failed to update worker role';
              this.errors = [error.error?.message || 'Update failed'];
              setTimeout(() => {
                this.clearError();
              }, 5000);
            }
          );
      }

      this.cancelWorkerRoleManagement();
    }
  }

  updateCancle(event: any): void {
    event.viewMode = 0;
    this.edit = false;
    this.hasError = false;
    this.cancelWorkerRoleManagement();
  }
  showAssociatedOrganizations(management: any): void {
    this.managementService.getOrganizations(management.id).subscribe(
      (response: any) => {
        if (response && response.results && response.results.length) {
          this.dialog.open(OrganizationDialogComponent, {
            width: '50vw',
            height: '65vh',
            data: response.results,
          });
        }
        //  else {
        //   this.hasError = true;
        //   this.returnCode = 404;
        //   this.resultMessage = c;
        // }
      },
      (error: any) => {
        this.hasError = true;
        this.hideMessage = false;
        this.returnCode = error.status;
        this.resultMessage = error.error.message;
      }
    );
  }

  cancelWorkerRoleManagement(): void {
    this.resetManagement();
    this.add = false;
  }

  exportDataCallback(): void {
    const params = new URLSearchParams();
    const isActive = this.showType === 'all' ? 'true' : 'false';
    params.set('includeInactive' , isActive);
    if (this.searchText) {
      params.set('codePrefix', this.searchText);
    }
    const url = `/associated-org-report-roles/excelReport?${params.toString()}`;

    this.utilityService.exportTableService(
      url,
      'WorkerRoleManagement.xls',
      'application/vnd.ms-excel'
    );
  }

  createNewWorkerRoleManagement(): void {
    this.resetManagement();
    this.add = true;
    this.edit = false;
    this.clearError();
  }

  resetManagement(): void {
    this.clearError();
    const today = new Date();
    const todayString = today.toISOString(); // Format: YYYY-MM-DD
    this.model.selectedManagement = {
      id: 0,
      value: '',
      description: '',
      viewMode: 0,
      lifecycle: {
        beginDate: todayString,
        endDate: '',
      },
      audit: {
        createdDate: '',
        createdUser: '',
        lastModifiedDate: '',
        lockControlNumber: 0,
        createdLoginId: '',
        lastModifiedLoginId: '',
      },
    };
  }
  cancelManagement(): void {
    this.add = false;
    this.clearError();
  }

  showWorkerRoleOrganization() {
    this.clearError();
    console.log("this is it")
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      data: {
        title: 'Search acronym and apply role association',
        buttontext: 'Apply role association'
      },

      // height: '80vh',
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.acronym = result.shortName;
      this.base.newLocation.workerOrganization.organization.acronym =
        result.organizationType.businessArea.code + '/' + result.shortName;
      this.base.newLocation.workerOrganization.organization.businessAreaCode =
        result.organizationType.businessArea.code;
      this.base.newLocation.workerOrganization.organization.shortName = result.shortName;
    });
  }
  checkManagement(): boolean {
    this.errors = [];
    if (this.model.selectedManagement.value == null || this.model.selectedManagement.value == '') {
      this.invalidRoleCode = true;
      this.errors.push('Role Code Is Required.');
    }
    if (
      this.model.selectedManagement.description == null ||
      this.model.selectedManagement.description == ''
    ) {
      this.invalidDescription = true;
      this.errors.push('Role Description Is Required.');
    }
    if (
      this.model.selectedManagement.lifecycle.beginDate == null ||
      this.model.selectedManagement.lifecycle.beginDate == ''
    ) {
      this.invalidStartDate = true;
      this.errors.push('Start Date Is Required.');
    }
    // Validate end date
    this.validateEndDate();
    if (this.endDateErrorMessage) {
      this.invalidEndDate = true;
      this.errors.push(this.endDateErrorMessage);
    }
    if (this.invalidRoleCode || this.invalidDescription || this.invalidStartDate || this.invalidEndDate) {
      return true;
    }
    return false;
  }

  private validateEventData(data: any): boolean {
    this.errors = [];
    if (!data.value || data.value.trim() === '') {
      this.errors.push('Role Code Is Required.');
      return false;
    }
    if (!data.description || data.description.trim() === '') {
      this.errors.push('Role Description Is Required.');
      return false;
    }
    if (!data.lifecycle?.beginDate) {
      this.errors.push('Start Date Is Required.');
      return false;
    }
    // End date is optional, so we don't require it
    return true;
  }

  clearError(): void {
    this.hasError = false;
    this.hasSuccessor = false;
    this.hideMessage = true;
    this.returnCode = 700;
    this.resultMessage = '';
    this.invalidRoleCode = false;
    this.invalidDescription = false;
    this.invalidStartDate = false;
    this.invalidEndDate = false;
    this.beginDateErrorMessage = '';
    this.endDateErrorMessage = '';
    this.errors = [];
  }

  save(): void {
    this.clearError();
    if (this.checkManagement()) {
      this.hasError = true;
      this.hideMessage = false;
      this.resultMessage = 'Invalid input was detected. Please correct required/invalid fields.';
      setTimeout(() => {
        //this.clearError();
      }, 5000);
    } else {
      // Ensure endDate is null if empty
      const endDate = this.model.selectedManagement.lifecycle.endDate ? this.model.selectedManagement.lifecycle.endDate : null;
      // Correct payload format: lifecycle first, then value, then description
      let payload = {
        lifecycle: {
          beginDate: this.model.selectedManagement.lifecycle.beginDate,
          endDate: endDate,
        },
        value: this.model.selectedManagement.value ? (this.model.selectedManagement.value).toUpperCase() : '',
        description: this.model.selectedManagement.description ? (this.model.selectedManagement.description).toUpperCase() : '',
      };
      //this.model.selectedManagement.value
      this.managementService.saveRoleWorker(payload).subscribe(
        (response: any) => {
          if (response) {
            this.added = true;
            this.add = false;
            this.hasError = true;
            this.hideMessage = false;
            this.returnCode = 200;
            this.resultMessage =
              'Successfully created worker role: ' + response.description;
            this.list();
            this.getDatabyLastModifiedDate();
            this.cdr.detectChanges();
          }
          setTimeout(() => {
            this.clearError();
          }, 5000);
        },
        (error: any) => {
          this.hasError = true;
          this.hideMessage = false;
          this.returnCode = error.status || 500;
          this.resultMessage = error.error?.message || 'Failed to create worker role';
          this.errors = [error.error?.message || 'Creation failed'];
          setTimeout(() => {
            this.clearError();
          }, 5000);
        }
      );
    }
  }
  toggleActiveAll(): void {
    this.pageNumber = 0;
    this.list();
  }

  deleteConfirmation(model: any): void {}
  sortBy(column: string): void {
    if (this.sortColumn === column) {
      // Toggle sort direction if clicking the same column
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // Set new column and default to ascending
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.list();
  }
  editModel(management: any): void {
    // Reset all rows to viewMode 0 to prevent multiple edits
    this.add = false;
    this.workerRoleManagements.forEach((item) => {
      item.viewMode = 0;
    });

    this.model.selectedManagement = JSON.parse(JSON.stringify(management));
    this.edit = true;
    management.viewMode = 2;
  }
  get(): void {
    this.managementService.getSites().subscribe((response: any) => {
      if (response) {
        for (let i = 0; i < response.results.length; i++) {}
      }
    });
  }
  list(): void {
    console.log("called")
    this.total = 0;
    if (!this.add && !this.edit) {
      const includeInactive = this.showType === 'all';
      this.managementService
        .getManagements(
          includeInactive,
          this.pageSize,
          this.sortColumn,
          this.sortDirection,
          this.urls.list,
          this.searchText,
          this.pageNumber
        )
        .subscribe((response: any) => {
          this.workerRoleManagements = [];
          if (response) {
            for (let i = 0; i < response.results.length; i++) {
              response.results[i].viewMode = 0;
              if (!(this.showType === 'all')) {
                response.results[i].lifecycle.endDate = '';
              }
              this.workerRoleManagements.push(response.results[i]);
            }
            this.total = response.meta.total;
          }
        });
    }
  }

  getDatabyLastModifiedDate(limit: number = 1, skip: number = 0): void {
    if (!this.add && !this.edit) {
      this.dataWorkerRoleBYLastModifiedDate = [];
      this.managementService
        .getManagements(
          true,
          limit,
          'lastModifiedDate',
          'desc',
          this.urls.list,
          this.searchText
        )
        .subscribe((response: any) => {
          if (response) {
            this.dataWorkerRoleBYLastModifiedDate.push(response.results[0]);

            // this.total = response.meta.total;
          }
        });
    }
  }
  getOrganization(): void {
    this.managementService.getOrganization().subscribe((response: any) => {
      if (response) {
        for (let i = 0; i < response.results.length; i++) {}
      }
    });
  }
  getOrganizationById(id: number): void {
    this.managementService.getOrganizationById(id).subscribe((response: any) => {
      if (response) {
        for (let i = 0; i < response.results.length; i++) {}
      }
    });
  }
  pageSizeChangedEvent(pageSize: number) {
    this.pageSize = pageSize;
    this.pageNumber = 0;
    this.list();
  }

  onPageChanged(pageNumber: number) {
    this.pageNumber = pageNumber;
    this.list();
  }
}
