import { Component, EventEmitter, inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SiteService } from 'src/app/services/site.services';
import { Management } from 'src/app/shared/components/management/Management';
import { ManagementService } from 'src/app/shared/services/management.service';
import { WorkerRoleManagement } from '../WorkerRoleManagement';
import { OrganizationSelectTreeDialogComponent } from 'src/app/shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'src/app/services/app.service';
import { UtilityService } from 'src/app/services/utility.service';

@Component({
  selector: 'app-worker-role-management-edit',
  templateUrl: './worker-role-management-edit.component.html',
  styleUrls: ['./worker-role-management-edit.component.scss'],
})
export class WorkerRoleManagementEditComponent implements OnInit {
  @Input() componentName: string = '';
  @Input() workerRoleManagement: WorkerRoleManagement | null = null;
  @Input() workerRoleManagementModel: WorkerRoleManagement | null = null;
  @Input() edit: boolean = false;
  @Output() cancel = new EventEmitter<WorkerRoleManagement>();
  @Output() save = new EventEmitter<{ index: number; data: WorkerRoleManagement }>();

  @ViewChild('editForm') editForm!: NgForm;

  dialog = inject(MatDialog);
  invalidroleCode: string = '';
  invalidDescription: string = '';
  beginDateErrorMessage: string = '';
  endDateErrorMessage: string = '';
  // Form model for template-driven forms
  formModel = {
    value: '',
    description: '',
    beginDate: null as any,
    endDate: null as any,
  };

  constructor(private appService: AppService, private utilityService: UtilityService) {}
  ngOnInit(): void {
    this.initializeFormModel();
  }

  private initializeFormModel(): void {
    if (!this.workerRoleManagementModel) {
      return;
    }

    const wrModel = this.appService.deepCopy(this.workerRoleManagementModel);
    this.formModel = {
      value: wrModel.value || '',
      description: wrModel.description || '',
      beginDate: wrModel.lifecycle?.beginDate,
      endDate: wrModel.lifecycle?.endDate,
    };
  }

  validateDescription(): void {
    const value = this.formModel.description;
    if (!value || value.trim() === '') {
      this.invalidDescription = 'Description is required';
    } else if (value.length > 100) {
      this.invalidDescription = 'Description cannot exceed 100 characters';
    } else {
      this.invalidDescription = '';
    }
  }

  validateBeginDate(): void {
    const value = this.formModel.beginDate;
    if (!value) {
      this.beginDateErrorMessage = 'Start date is required';
    } else {
      this.beginDateErrorMessage = '';
      this.validateEndDate();
    }
  }

  validateEndDate(): void {
    const beginDate = this.formModel.beginDate;
    const endDate = this.formModel.endDate;
    
    if (endDate && beginDate) {
      // Use utility service to validate end date (checks if end date is tomorrow or later)
      this.endDateErrorMessage = this.utilityService.validateEndDate(
        beginDate as string,
        endDate as string
      ) as string;
    } else {
      this.endDateErrorMessage = '';
    }
  }

  onBeginDateChanged(date: string | undefined): void {
    this.formModel.beginDate = date || null;
    this.validateBeginDate();
  }

  onEndDateChanged(date: string | undefined): void {
    this.formModel.endDate = date || null;
    this.validateEndDate();
  }

  cancelWorkerRoleManagement(WorkerRoleManagement?: WorkerRoleManagement | null): void {
    if (WorkerRoleManagement) {
      this.cancel.emit(WorkerRoleManagement);
    }
  }

  resetWorkerRoleManagement(WorkerRoleManagement?: WorkerRoleManagement | null): void {
    if (WorkerRoleManagement) {
      // this.reset.emit(WorkerRoleManagement);
      // if (this.editForm) {
      //   this.editForm.resetForm();
      // }
      this.initializeFormModel();
    }
  }
  validateroleCode(): void {
    const value = this.formModel.value;
    if (!value || value.trim() === '') {
      this.invalidroleCode = 'Role code is required';
    } else if (value.length > 6) {
      this.invalidroleCode = 'Role code cannot exceed 6 characters';
    } else {
      this.invalidroleCode = '';
    }
  }
  saveWorkerRoleManagement(index: number): void {
    this.validateAllFields();
    let updatedLocation: any | null = null;
    if (this.isFormValid() && this.workerRoleManagement) {
      // Ensure endDate is null if empty
      const endDate = this.formModel.endDate ? this.formModel.endDate : null;
      updatedLocation = {
        ...this.workerRoleManagement,
        value: this.formModel.value,
        description: this.formModel.description,
        lifecycle: {
          beginDate: this.formModel.beginDate,
          endDate: endDate,
        },
      };
      this.save.emit({ index, data: updatedLocation });
    }
    // else{
    //   const _data = {
    //     id: -1,
    //       value: '',
    //       viewMode: 0,
    //       description: '',
    //       lifecycle: {
    //         beginDate: '',
    //         endDate: null,
    //       },
    //       audit: {
    //         createdDate: '',
    //         createdUser: null,
    //         lastModifiedDate: null,
    //         lockControlNumber: 0,
    //         createdLoginId: '',
    //         lastModifiedLoginId: '',
    //       },
    //   }
    //   this.save.emit({ index, data: _data });
    // }
  }

  private validateAllFields(): void {
    this.validateroleCode();
    this.validateDescription();
    this.validateBeginDate();
    this.validateEndDate();
  }

  private isFormValid(): boolean {
    return (
      !this.invalidroleCode &&
      !this.invalidDescription &&
      !this.beginDateErrorMessage &&
      !this.endDateErrorMessage &&
      this.formModel.value &&
      this.formModel.description &&
      this.formModel.beginDate
    );
  }

  isFieldInvalid(fieldName: string): boolean {
    if (!this.editForm) {
      return false;
    }

    const field = this.editForm.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  showWorkerRoleOrganization() {
    const dialogRef = this.dialog.open(OrganizationSelectTreeDialogComponent, {
      width: '80vw',
      // height: '',
       data: {
        title: 'Search acronym and apply role association',
        buttontext:"Apply role association"
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      // this.acronym = result.shortName;
      // this.base.newLocation.workerOrganization.organization.acronym =
      //   result.organizationType.businessArea.code + '/' + result.shortName;
      // this.base.newLocation.workerOrganization.organization.businessAreaCode =
      //   result.organizationType.businessArea.code;
      // this.base.newLocation.workerOrganization.organization.shortName = result.shortName;
    });
  }
}
