import { Component } from '@angular/core';

@Component({
  selector: 'app-location-select-dialog',
  templateUrl: './location-select-dialog.component.html',
  styleUrls: ['./location-select-dialog.component.scss'],
})
export class LocationSelectDialogComponent {}
