import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Building, BuildingResults } from 'src/app/shared/interfaces/models';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { LocationService } from '../location.service';
import { LocationPurpose } from '../../worker-management/add-worker/locationselect-dialog/location-confirmation';
//ort { LocationService } from '../components/location/location.service';
import { DatePipe } from '@angular/common';
import { UtilityService } from 'src/app/services/utility.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-location-advanced-search',
  templateUrl: './advanced-location-search.component.html',
  styleUrls: ['./advanced-location-search.component.scss'],
  providers: [DatePipe],
})
export class AdvancedLocationSearchComponent implements OnInit {
  ssnMask = { mask: '000-00-0000' };
  invalidStartDate: any;
  limit: number = 10;
  total: number = 0;
  skip: number = 0;
  includeInactive: boolean = false;
  startDate: string | null = null;
  endDate: string | null = null;
  startDateErrorMessage: any;
  displayMessage: string = '';
  subscription: Subscription = new Subscription();
  @Output() public advanceSearch = new EventEmitter();
  @Output() dataEvent = new EventEmitter<any>();
  
  // Store the current search criteria for pagination
  private currentSearchCriteria: string = '';
  constructor(
    private organizationService: OrganizationService,
    private locationService: LocationService,
    private utilityService: UtilityService,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.organizationService.getBuildings().subscribe((res: any) => {
      this.buildingCodeList = res.results as BuildingResults[];
    });

    this.organizationService.getFirms().subscribe((res: any) => {
      this.contractorFirmNames = res.results;
    });

    this.locationService.getLocationPurposeList().subscribe((res: any) => {
      this.locationPurposeList = res.results;
    });
    this.setDefaultLocationByDescription(6);
  }
  public locationSearchList: any = { meta: {}, results: [] };
  workerModel: any;
  selectedBuildingObject: Building | null = null;
  selectedLocationValue: number | undefined;
  basicSearch: any;
  savedSearchCriteria: any;
  basicSearchText: any;
  selectedSearchCriteria: any;
  basicSearchBusinessAreaCode: any;
  basicSearchShortName: any;
  showType = 'active';
  searchResultsCount: any;
  basicSearchAcronym: any;
  basicSearchCriteria: any;
  basicSearchDiv: any;
  basicSearchAcronymDiv: any;
  basicSearchSSNDiv: any;
  basicSearchFirmnameDiv: any;
  basicSearchFirmAdministratorDiv: any;
  cedrRolesDiv: any;
  basicSearchDOBDiv: any;
  basicSearchLoginDiv: any;
  userInfo: any;
  workerNumber: any = 123;
  addWorkerButton: any;
  buildingFloors: any;
  userRoles: any = ['InfraAdmin'];
  isContractor: any;
  hideSSN: any;
  applicationType: any;
  hideFirms: any;
  cedrRoleSearch: any;
  invalidBirthDate: any;
  birthDateErrorMessage: any;
  hideBuildingSearch: any;
  acronymInvalid: any;
  acronymEnter: any;
  advanceSearchAcronym: any;
  invalidAdvancedAcronym: any;
  hidePhoneNumberSearch: any;
  jobClassCodeList: any;
  buildingCodeList: any[] = [];
  locationPurposeList: any[] = [];
  contractorFirmNames: any[] = [];
  floorNumber: any;
  buildingCode: any;
  corridorId: any;
  roomId: any;
  suiteId: any;
  status: boolean = true;
  advanceSearchOptions = {
    startDate: {
      value: 'startDate',
      description: '',
    },
    endDate: {
      value: 'endDate',
      description: '',
    },
    buildingCode: {
      value: 'buildingCode',
      description: '',
    },
    floorNumber: {
      value: 'floorNumber',
      description: '',
    },
    corridorId: {
      value: 'corridorId',
      description: '',
    },
    roomId: {
      value: 'roomId',
      description: '',
    },
    purposeSearch: {
      value: 'purposeId',
      description: 'Worker Location',
    },
    suiteId: {
      value: 'suiteId',
      description: '',
    },
  };

  setDefaultLocationByDescription(id: number): void {
    // Iterate through the list to find the matching item
    const defaultItem = this.locationPurposeList.find((location) => location.id === id);

    if (defaultItem) {
      this.selectedLocationValue = defaultItem.id;
    } else {
      this.selectedLocationValue = 6;
    }
  }

  searchKeyEventBasic($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(true);
    }
  }
  setSearchType(searchType: any) {
    if (this.workerModel) {
      this.workerModel = '';
    }
    this.basicSearch = searchType;

    if (this.basicSearch) {
      this.savedSearchCriteria = {
        basicSearchText: this.basicSearchText,
        selectedSearchCriteria: {
          value: this.selectedSearchCriteria.value,
        },
        basicSearchBusinessAreaCode: this.basicSearchBusinessAreaCode,
        basicSearchShortName: this.basicSearchShortName,
        workerAssociatedFirms: true,
        loginWorkerNumber: this.userInfo.workerNumber,
      };
      this.clearAdvanvedSearch();
      // this.firstPage();
    } else {
      if (this.checkBlankAdvanceSearch()) {
        this.searchResultsCount = '';
        return;
      }
      // this.savedSearchCriteria = angular.copy(this.advanceSearchOptions);
      this.basicSearchText = '';
      this.basicSearchBusinessAreaCode = '';
      this.basicSearchShortName = '';
      this.basicSearchAcronym = '';
      // begin set default basic search to Last Name
      // angular.forEach(this.basicSearchCriteria, function (basicSearch) {
      //   if (basicSearch.value === 'workerNumber' && basicSearch.description === 'Worker number') {
      //     this.selectedSearchCriteria = basicSearch;
      //   }
      // });
      // end set default to Last Name
      this.basicSearchDiv = true;
      this.basicSearchAcronymDiv = false;
      this.basicSearchSSNDiv = false;
      this.basicSearchFirmnameDiv = false;
      this.basicSearchFirmAdministratorDiv = false;
      this.cedrRolesDiv = false;
      this.basicSearchDOBDiv = false;
      this.basicSearchLoginDiv = false;
      // this.firstPage();
      // }
    }

    this.advanceSearch.emit(this.advanceSearchOptions);
  }
  checkBlankAdvanceSearch() {
    return this.checkBlankAdvanceSearchHelper();
  }
  checkBlankAdvanceSearchHelper() {
    if (this.advanceSearchOptions.buildingCode.description) {
      return false;
    }
    return true;
  }
  searchKeyEventAdvanced($event: any) {
    if ($event.keyCode === 13) {
      this.setSearchType(false);
    }
  }

  buildingChanged() {
    if (this.selectedBuildingObject) {
      // Access the description property from the bound object:
      this.buildingCode = this.selectedBuildingObject.buildingCode;
      //const buildingCode1 = this.selectedBuildingObject.results;    } else {
    }
  }
  purposeChanged() {
    if (this.selectedLocationValue) {
    }
  }
  clearAdvanvedSearch() {
    this.setAdvanceSearchOptions();
    this.advanceSearchAcronym = '';
    this.invalidAdvancedAcronym = false;
    this.acronymInvalid = false;
  }
  setAdvanceSearchOptions() {
    this.advanceSearchOptions.startDate.value = '';
    this.advanceSearchOptions.endDate.value = '';
    this.buildingCode = '';
    this.floorNumber = '';
    this.corridorId = '';
    this.roomId = '';
    this.suiteId = '';
    this.selectedBuildingObject = null;
    this.advanceSearchOptions.purposeSearch.description = 'Worker Location';
    this.setDefaultLocationByDescription(6);
    this.includeInactive = false;
    this.showType = 'active';
  }
  setLocationSearch() {
    this.startDate = this.advanceSearchOptions.startDate.value;
    this.endDate = this.advanceSearchOptions.endDate.value;
    this.startDate =
      this.startDate != null && this.startDate !== 'startDate' && this.startDate.length > 0
        ? this.datePipe.transform(this.startDate, 'yyyy-MM-dd')
        : '';
    this.endDate =
      this.endDate != null && this.endDate !== 'endDate' && this.endDate.length > 0
        ? this.datePipe.transform(this.endDate, 'yyyy-MM-dd')
        : '';    if (
      this.buildingCode != null &&
      this.buildingCode != undefined &&
      this.buildingCode.length > 0
    ) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria = 'buildingCode=' + this.buildingCode;
    }
    if (this.floorNumber != null && this.floorNumber.length > 0) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'floorPrefix=' + this.floorNumber;
    }
    if (this.corridorId != null && this.corridorId.length > 0) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'corridorPrefix=' + this.corridorId;
    }
    if (this.endDate != null && this.endDate.length > 0) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'endDate=' + this.endDate;
    }
    if (this.selectedLocationValue != null && this.selectedLocationValue != undefined) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'locationPurposeId=' + this.selectedLocationValue;
    }
    if (this.roomId != null && this.roomId.length > 0) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'roomPrefix=' + this.roomId;
    }
    if (this.startDate != null && this.startDate.length > 0) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'startDate=' + this.startDate;
    }
    if (this.suiteId != null) {
      if (this.selectedSearchCriteria != null && this.selectedSearchCriteria.length > 0) {
        this.selectedSearchCriteria += '&';
      }
      this.selectedSearchCriteria += 'suitePrefix=' + this.suiteId;
    }
    this.selectedSearchCriteria = this.selectedSearchCriteria.replace('undefined', '');
    
    // Store the search criteria for pagination (without includeInactive as it will be added in executeLocationSearch)
    this.currentSearchCriteria = this.selectedSearchCriteria;
    
    // Reset pagination on new search
    this.skip = 0;
    
    this.executeLocationSearch();
  }

  /**
   * Execute location search with current pagination parameters
   * This method can be called by the parent component for pagination
   */
  public executeLocationSearch(limit?: number, skip?: number): void {
    const searchLimit = limit !== undefined ? limit : this.limit;
    const searchSkip = skip !== undefined ? skip : this.skip;
    
    // Build the complete search criteria with includeInactive
    let fullSearchCriteria = this.currentSearchCriteria || this.selectedSearchCriteria;
    
    // Remove any existing includeInactive parameter to avoid duplicates
    fullSearchCriteria = fullSearchCriteria.replace(/&?includeInactive=(true|false)/g, '');
    
    // Add includeInactive parameter
    fullSearchCriteria += '&includeInactive=' + this.includeInactive;
    
    this.locationService
      .getLocations(
        this.includeInactive,
        '',
        fullSearchCriteria,
        false,
        searchLimit,
        searchSkip
      )
      .subscribe((res: any) => {
        // Send the full response object (including meta) to subscribers
        this.locationService.sendData(res, fullSearchCriteria);
        
        // Keep backward compatibility for changeTabData
        this.locationService.changeTabData(res.results || []);
        
        // Update local total from meta if available
        if (res.meta && res.meta.total !== undefined) {
          this.total = res.meta.total;
        }
        // this.dataEvent.emit(this.locationSearchList);
      });
  }

  toggleActiveAll() {
    // Update includeInactive based on showType
    this.includeInactive = this.showType === 'all';
    this.setLocationSearch();
  }
}
