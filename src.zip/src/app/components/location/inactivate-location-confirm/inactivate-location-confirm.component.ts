import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inactivate-location-confirm',
  templateUrl: './inactivate-location-confirm.component.html',
  styleUrls: ['./inactivate-location-confirm.component.scss'],
})
export class InactivateLocationConfirmComponent implements OnInit {
  // Define the structure of your data. The 'vm.location' from AngularJS is now just 'location'
  location: any[] = [
    // Example data structure, adjust based on your actual data source
    {
      building: { name: 'Main Bldg', floorNumber: 2 },
      roomId: '201A',
      suiteId: 'Suite 200',
      zoneId: 'Zone A',
    },
  ];

  constructor() {}

  ngOnInit(): void {
    // Data loading logic goes here if needed
  }

  // Method to handle the "Cancel" action
  closeThisDialog(message: string): void {    // Add logic here to close your dialog/modal (e.g., using MatDialogRef or similar service)
  }

  // Method to handle the "Confirm" action
  confirm(isConfirmed: boolean): void {    // Add logic here to perform the inactivation (e.g., call a service, close the dialog)
  }
}
