import { Injectable } from '@angular/core';
import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { LocationValidationsService } from './location-validations.service';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { NewLocation } from 'src/app/shared/interfaces/models';
@Injectable({
  providedIn: 'root',
})
export class LocationService {
  private inactivateClickedSource = new Subject<void>();
  inactivateClicked$ = this.inactivateClickedSource.asObservable();
  private messageSubject = new Subject<string>();
  // Expose as an Observable so components can subscribe
  messages: Observable<string> = this.messageSubject.asObservable();
  
  // Subject to trigger search refresh after save
  private refreshSearchSource = new Subject<string>();
  refreshSearch$ = this.refreshSearchSource.asObservable();
  
  // Toast message management (following transfer-search pattern)
  private hideMessageSubject = new BehaviorSubject<boolean>(true);
  private returnMessageSource = new BehaviorSubject<string>('');
  private returnMessageSourceArray = new BehaviorSubject<string[]>([]);
  private returnCodeSource = new BehaviorSubject<string | number>('');

  // Observable for components to listen to
  hideMessage$ = this.hideMessageSubject.asObservable();
  returnMessage$ = this.returnMessageSource.asObservable();
  returnMessagesArray$ = this.returnMessageSourceArray.asObservable();
  returnCode$ = this.returnCodeSource.asObservable();
  
  triggerInactivate(): void {
    this.inactivateClickedSource.next();
  }
  
  triggerRefreshSearch(message: string): void {
    this.refreshSearchSource.next(message);
  }

  // Methods to update toast messages (following transfer-search pattern)
  updateHideMessage(value: boolean) {
    this.hideMessageSubject.next(value);
  }

  updateReturnMessage(msg: string) {
    this.scrolltoTop();
    this.returnMessageSource.next(msg);
  }

  updateReturnMessageArray(messages: string[]) {
    this.returnMessageSourceArray.next(messages);
  }

  updateReturnCode(code: string | number) {
    this.returnCodeSource.next(code);
  }

  scrolltoTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  inactivateLocations(selectedLoc: NewLocation) {
    const locid = selectedLoc.locationId;

    const lockControlNum = selectedLoc.audit.lockControlNumber;
    const url = '/locations/' + locid + '?lockControlNumber=' + lockControlNum;
    return this.httpservice.put(url, selectedLoc);
  }

  reactivateLocation(selectedLoc: NewLocation) {
    const locid = selectedLoc.locationId;

    const lockControlNum = selectedLoc.audit.lockControlNumber;
    const url = '/locations/' + locid + '?lockControlNumber=' + lockControlNum;
    return this.httpservice.put(url, selectedLoc);
  }
  getAssociatedWorkers(selectedLoc: NewLocation) {
    const locid = selectedLoc.locationId;
    const url = '/workers?locationId=' + locid;
    return this.httpservice.get(url);
  }
  private selectedIdsSubject = new BehaviorSubject<number[]>([]);
  selectedIds$: Observable<number[]> = this.selectedIdsSubject.asObservable();

  updateSelectedIds(ids: number[]): void {
    this.selectedIdsSubject.next(ids);
  }
  getCurrentIds(): number[] {
    return this.selectedIdsSubject.value;
  }
  private expandCollapseSubject = new Subject<'expand' | 'collapse'>();

  // Expose this as an Observable for components to subscribe to
  get command$(): Observable<'expand' | 'collapse'> {
    return this.expandCollapseSubject.asObservable();
  }

  // Methods the button component calls
  expandAllRows(): void {
    this.expandCollapseSubject.next('expand');
  }

  collapseAllRows(): void {
    this.expandCollapseSubject.next('collapse');
  }

  private tabDataSource = new BehaviorSubject<string>('');

  currentTabData = this.tabDataSource.asObservable();

  changeTabData(data: string) {
    this.tabDataSource.next(data);
  }

  readonly searchCriteriaMap: any = {
    buildingCode: 'buildingCode',
    corridorPrefix: 'corridorId',
    endDate: 'endDate',
    floorPrefix: 'floorNumber',
    locationPurposeId: 'locationPurposeId',
    dateOfBirth: 'dateOfBirth',
    roomPrefix: 'roomId',
    startDate: 'startDate',
    suitePrefix: 'suiteId',
  };

  constructor(
    private httpservice: HttpService,
    private appservice: AppService,
    private http: HttpClient,
    private locationValidationsService: LocationValidationsService
  ) {}

  executeLocationMassUpload(validRequests: any) {
    return this.httpservice.post('/locations/execute', validRequests);
  }

  getLocationPurpose(purposeDescription: string) {
    const url = `/references/location-purposes?description=${purposeDescription}`;
    return this.httpservice.get(url);
  }
  getLocationPurposeList() {
    const url = '/references/location-purposes?includeInactive=false';
    return this.httpservice.get(url);
  }
  public getSearchCriteriaKey(searchCriteria: string): string {
    const key = this.searchCriteriaMap[searchCriteria];
    return key ? key : searchCriteria;
  }

  validateContractorId(dateOfBirth: string, contractorSSN: string) {
    const url = 'workers';
    const params = {
      isContractor: true,
      includeInactive: true,
      dateOfBirth: dateOfBirth,
      contractorSSN: contractorSSN,
    };
    const queryParams = this.appservice.mergeQueryParams(params);
    const _url = `${url}?${queryParams}`;
    return this.httpservice.get(_url);
  }

  public getLocations(
    showAll: boolean,
    searchText: string,
    searchCriteria: string,
    isContractor: boolean = false,
    limit: number = 10,
    skip: number = 0
  ): Observable<any> {
    // Clean up search criteria to avoid double ampersands
    let cleanCriteria = searchCriteria;
    if (cleanCriteria && cleanCriteria.startsWith('&')) {
      cleanCriteria = cleanCriteria.substring(1);
    }
    
    // Build URL with proper parameter formatting
    let url = `/locations?${cleanCriteria}&limit=${limit}&skip=${skip}&sortOrder=asc`;
    
    // Clean up any double ampersands that might have been created
    url = url.replace(/\?&/, '?').replace(/&&+/g, '&');    return this.httpservice.get(url);
  }

  public getWorkersWithAdvanceSearch(
    showAll: boolean,
    queryParameters: string,
    limit: number = 10,
    skip: number = 0
  ): Observable<any> {
    // Build the locations URL with proper pagination parameters
    let url = `/locations?includeInactive=${showAll}${queryParameters}&limit=${limit}&skip=${skip}&sortOrder=asc`;
    
    return this.httpservice.get(url);
  }

  public getWorkerAssignments(workerId: number): Observable<any> {
    let url = `/workers/${workerId}/assignments`;
    return this.httpservice.get(url);
  }

  public workerExcelReport(
    showAll: boolean,
    queryParameters: string,
    totalrecords: number
  ): Observable<Blob> {
    const headers = new HttpHeaders().set('Accept', 'application/vnd.ms-excel');

    let url = `/api/infra-services/workers/workerExcelReport?includeInactive=${showAll}${queryParameters}&limit=${totalrecords}&sortColumn=lastName&sortOrder=asc`;
    return this.http.get(url, {
      headers: headers,
      responseType: 'blob',
    });
  }

  public getParameters(): Observable<any> {
    return this.httpservice.get('/parameters');
  }

  canViewSecureData(userRoles: any, employmentType: string) {
    if (
      (employmentType === 'E' &&
        (userRoles.indexOf('InfraAdmin') >= 0 || userRoles.indexOf('InfraHRAdmin') >= 0)) ||
      userRoles.indexOf('InfraHRViewer') >= 0
    ) {
      return true;
    }

    const canViewContractorSecure =
      userRoles.indexOf('InfraAdmin') >= 0 ||
      userRoles.indexOf('InfraHRAdmin') >= 0 ||
      userRoles.indexOf('InfraContractorAdmin') >= 0 ||
      userRoles.indexOf('InfraOfficeCoordinator') >= 0;

    return employmentType === 'C' && canViewContractorSecure;
  }

  getContractorStatusValidResponse(validRequests: any) {
    return this.httpservice.post('/createValidContractors', validRequests);
  }

  getContractorCreationResponse(validRequests: any) {
    return this.httpservice.post('/createMultipleContractors', validRequests);
  }

  getContractorValidCreationResponse(validRequests: any) {
    return this.httpservice.post('/createValidMultipleContractors', validRequests);
  }

  getContractorsByFirmSearch(firmName: string) {
    const url = `/workers?includeInactive=false&limit=1000&skip=0&sortColumn=lastName&sortOrder=asc&firmName=${firmName}`;
    return this.httpservice.get(url);
  }

  moveContractorsList(servicesObject: any) {
    return this.httpservice.put('/workers/firm/association', servicesObject);
  }

  saveLocation(location: any, url: string) {
    return this.httpservice.put(url, location);
  }
  addNewLocation(location: any, url: string) {
    return this.httpservice.post(url, location);
  }

  getBuilding(buildingId: string) {
    return this.httpservice.get('/buildings/' + buildingId);
  }
  saveBuildingFloor(building: any, url: string) {
    return this.httpservice.put(url, building);
  }

  orgRoles(orgId: string) {
    const url = '/workers/' + orgId + '/orgRoles';
    return this.httpservice.get(url);
  }

  getBuildingFloors(buildingId: string) {
    const url = '/buildings/' + buildingId;
    return this.httpservice.get(url);
  }
  private dataSubject = new BehaviorSubject<any>(null);
  private paramSubject = new BehaviorSubject<any>(null);

  sendData(data: any, param: any) {
    this.dataSubject.next(data);
    this.paramSubject.next(param);
  }

  sendMessage(message: string, messageType: 'success' | 'danger' = 'success') {    // Scroll to top whenever a message is sent (matches AngularJS $anchorScroll behavior)
    window.scrollTo(0, 0);
    
    // Update message observables for ACME navbar component
    this.updateReturnMessage(message);
    
    // Set return code based on message type
    // 200 for success (shows green/success toast)
    // 400+ for danger (shows red/danger toast)
    const returnCode = messageType === 'success' ? 200 : 400;    this.updateReturnCode(returnCode);
    
    // Clear any previous message arrays for simple messages
    this.updateReturnMessageArray([]);
    
    // Show the message (stays visible until user manually closes it)
    this.updateHideMessage(false);
  }
  
  sendSuccessMessage(message: string) {
    this.sendMessage(message, 'success');
  }
  
  sendErrorMessage(message: string) {
    this.sendMessage(message, 'danger');
  }
  getParams(): Observable<any> {
    return this.paramSubject.asObservable();
  }

  getData(): Observable<any> {
    return this.dataSubject.asObservable();
  }

  /**
   * Get standardized message based on operation type and status
   * Matches the AngularJS LocationService.getMessage() pattern
   *
   * @param operation - Operation type: 'AddLocation', 'UpdateLocation', 'AddFloor', 'UpdateFloor'
   * @param statusText - HTTP status text
   * @param status - HTTP status code
   * @returns Observable<string> - Formatted message
   */
  getMessage(operation: string, statusText: string, status: number): Observable<string> {
    let message = '';
    
    // Success messages (status 200-299)
    if (status >= 200 && status < 300) {
      switch (operation) {
        case 'AddLocation':
          message = 'Add location successful';
          break;
        case 'UpdateLocation':
          message = 'Update location successful';
          break;
        case 'AddFloor':
          message = 'Add floor successful';
          break;
        case 'UpdateFloor':
          message = 'Update floor successful';
          break;
        default:
          message = statusText || 'Operation successful';
      }
    } else {
      // Error messages
      switch (operation) {
        case 'AddLocation':
          message = 'Add location failed';
          break;
        case 'UpdateLocation':
          message = 'Update location failed';
          break;
        case 'AddFloor':
          message = 'Add floor failed';
          break;
        case 'UpdateFloor':
          message = 'Update floor failed';
          break;
        default:
          message = statusText || 'Operation failed';
      }
    }
    
    return new Observable(observer => {
      observer.next(message);
      observer.complete();
    });
  }
}
