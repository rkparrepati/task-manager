import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
} from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AppService } from 'src/app/services/app.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';

import { MatSort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { LocationService } from '../location.service';
import {
  BuildingCode,
  BuildingFloor,
  LocationPurpose,
  Building,
  BuildingResults,
  FloorDetail,
  NewLocation,
  Lifecycle,
} from 'src/app/shared/interfaces/models';
import { Subject, Subscription } from 'rxjs';

import { takeUntil } from 'rxjs/operators';
import { OrganizationService } from 'src/app/shared/services/organizations.services';
import { UtilityService } from 'src/app/services/utility.service';
import { InactivateLocationConfirmDialogComponent } from '../inactivate-location-confirm-dialog/inactivate-location-confirm-dialog.component';
import { AssociatedObjectLocationsComponent } from '../associated-object-locations/associated-object-locations.component';
import { ReactivateLocationConfirmDialogComponent } from '../reactivate-location-confirm-dialog/reactivate-location-confirm-dialog.component';
/**
 * @title Table with expandable rows
 */
@Component({
  selector: 'app-location-grid',
  styleUrls: ['location-grid.component.scss'],
  templateUrl: 'location-grid.component.html',
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

//https://infra-services.sit.uspto.gov/infra-services/locations?buildingCode=AAA&floorPrefix=&includeInactive=false&limit=10&locationPurposeId=6
//https://infra-services.sit.uspto.gov/infra-services/locations/10032431?lockControlNumber=8
export class LocationGridComponent implements OnInit, OnDestroy, OnChanges {
  @Input() dataSource: any = { meta: {}, results: [] };
  @Input() selectedIds: number[] = [];
  @Output() messageEvent = new EventEmitter<string>();
  @Output() selectedIdsChange = new EventEmitter<number[]>();
  private inactivateSubscription!: Subscription;
  receivedData: any;
  searchMsg: any;
  invalidLocationStartDate: any;
  locationBeginDateErrorMessage: any;
  //invalidFloorStartDate: any;
  floorBeginDateErrorMessage: any;
  invalidFloorNumberInput: any;
  invalidRequiredFloorNumberInput: any;
  addFloor: any;
  floorData: any;
  buildingCodeList: any[] = [];
  locationPurposeList: any[] = [];
  applicationType: String = 'Location';
  total: number = 0;
  sortColumn: any;
  sortDirection: any;
  resort: any;
  formattedIsoDate: string | null = null;
  buildingFloorList: any[] = [];
  newBuildingFloorList: any[] = [];
  tmpBuildingFloorList: any[] = [];
  updateLlocationButton: any;
  inactivateLocations: any = {};
  locationResults: any = {};
  workerResults: any = {};
  locationParams: string = '';
  locationModel: any = { locationList: [] };
  rows = [];
  selectedDate: Date = new Date();
  locationResultsCount: string = '';
  currentLifecycleData: Lifecycle = {
    beginDate: undefined,
    endDate: null,
    cascade: false,
  };
  userInfo: any;
  location: any = {};
  floor: any = {};
  newFloor: any = {};
  phoneNumberDetail: any = {};
  matdataSource!: MatTableDataSource<any>;
  expandedElement: any | null;
  @Output() pageChange: EventEmitter<PageEvent> = new EventEmitter();
  floorNumber: string = '';
  floorStartDate: string = new Date().toISOString().split('T')[0]; // Use string for input[type=date]
  // Note: floorEndDate was not used in the original logic provided
  selectedBuilding: Building | undefined;
  building: any = {};
  // Status/Error flags
  invalidFloorEntry: boolean = false;
  invalidFloorStartDate: boolean = false;
  invalidFloorEndDate: boolean = false;
  hideMessage: boolean = true;
  returnCode: number | null = null;
  returnMessage: string = '';
  buildingCodeHeader: string = 'Building Code';
  floorNumberHeader: string = 'Floor';
  purposeTextHeader: string = 'Purpose';
  userRoles: string[] = ['InfraAdmin']; // Example role
  add: boolean = false;
  editRow: boolean = false;
  edit: boolean = false;
  selectedAll: boolean = false;
  selectAllDisabled: boolean = false;
  originalDataCopy: any;
  oldLocationValue: number | undefined;
  show: boolean = false; // Example: show the add row by default

  invalidBuildingCode: boolean = false;
  invalidFloorNumber: boolean = false;
  invalidLocationPurpose: boolean = false;
  selectedLocationValue: number | undefined;
  selectedLocationDesc: string = '';
  // Define interfaces for your data structures

  //buildingCodeList: BuildingCode[] = [ /* ... list of codes ... */];
  //public buildingFloorList:  any = { meta: {}, results: [] }; // BuildingFloor[] = [ /* ... list of floors ... */ ];
  // purposeList: LocationPurpose[] = [ /* ... list of purposes ... */];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  subscription: Subscription = new Subscription();
  activeLocation: Location | null = null;
  selectedBuildingObject: Building | null = null;
  buildingCode: any;
  selectedFloorId: any;
  selectedFloor: any;
  selectedEditFloor: any;
  selectedFloorObject: any;
  private destroy$ = new Subject<void>();

  constructor(
    private organizationService: OrganizationService,
    private appService: AppService,
    private locationService: LocationService,
    private utilities: UtilityService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}
  ngOnDestroy(): void {
    this.inactivateSubscription.unsubscribe();
    this.subscription.unsubscribe();
    this.destroy$.next();
    this.destroy$.complete();
  }

  handleInactivateAction(): void {
    const selectedIds = this.locationResults
      .filter((location: { isSelected: any }) => location.isSelected)
      .map((location: { id: any }) => location.id);

    const selectedLocations = this.locationResults.filter(
      (location: { id: number; name: string; isSelected: boolean }) => location.isSelected === true
    );
    // Iterate using forEach
    this.openInactivateDialog(selectedLocations);
  }

  onCheckboxChange(): void {
    this.isAllSelected();
  }

  // Helper to manage master checkbox (select/deselect all)
  toggleMasterSelection(): void {
    for (const item of this.locationResults) {
      item.isSelected = this.masterSelected;
    }
  }

  purposeChanged(): void {
    const latestValue = this.selectedLocationValue;
    const selectedLocationObject = this.locationPurposeList.find(
      (location) => location.id === Number(latestValue)
    );
    this.location = {
      ...this.location,
      locationPurpose: { ...selectedLocationObject }, // Deep copy the nested object
    };
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.dataSource && changes.dataSource.currentValue) {
      this.matdataSource = new MatTableDataSource<any>(changes.dataSource.currentValue.results);
      this.matdataSource.paginator = this.paginator;
    }
  }

  buildingChanged() {
    if (this.selectedBuildingCode) {
      this.buildingCode = this.selectedBuildingCode;
    }

    this.getBuildingFloors(Number(this.selectedBuildingCode));

    this.locationService.getBuilding(this.selectedBuildingCode).subscribe((res: any) => {
      this.building = res;
    });
  }

  buildingChanged1(code: any) {
    if (code) {
      // If you need to deep clone it to avoid reference issues:
      this.building = structuredClone(code);
      this.selectedBuildingObject = this.building.buildingCode;
    }

    this.getBuildingFloors(Number(this.building.buildingId));
  }

  onFloorChange() {
    this.selectedFloorObject = this.buildingFloorList.find(
      (floor) => floor.floorNumber === this.selectedEditFloor
    );

    if (!this.selectedFloorObject) {
      this.selectedFloorObject = this.selectedEditFloor;
    }
    // Now you have the complete object in this.selectedFloorObject
    if (this.selectedFloorObject) {
    } else {
    }
  }

  cancelUpdateFloor(floor: BuildingFloor) {
    // Use setTimeout to defer the update to the next change detection cycle
    setTimeout(() => {
      // Store original floor data before canceling
      this.location.selectedFloor = {};
      floor.isedit = false;
      
      // Reload the building floors to reset any changes
      if (this.location && this.location.building && this.location.building.buildingId) {
        this.getBuildingFloors(this.location.building.buildingId);
      }
      
      this.cdr.markForCheck();
    }, 0);
  }

  updateFloor(floor: BuildingFloor, location: any) {
    // Validate that we have the necessary data (matching create component pattern)
    const errorMessages: string[] = [];
    
    if (!floor || !floor.lifecycle || !floor.lifecycle.beginDate) {
      errorMessages.push('Floor start date is required');
    }

    // Get the building ID from the location
    const buildingId = location?.building?.buildingId || this.location?.building?.buildingId;
    
    if (!buildingId) {
      errorMessages.push('Building ID not found');
    }
    
    // If validation errors exist, display them and return
    if (errorMessages.length > 0) {
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(errorMessages);
      this.locationService.updateHideMessage(false);
      return;
    }

    // Update the floor in the buildingFloorList
    const floorIndex = this.buildingFloorList.findIndex(
      (f) => f.buildingFloorId === floor.buildingFloorId
    );

    if (floorIndex !== -1) {
      // Update the floor's lifecycle dates
      this.buildingFloorList[floorIndex].lifecycle.beginDate = floor.lifecycle.beginDate;
      if (floor.lifecycle.endDate) {
        this.buildingFloorList[floorIndex].lifecycle.endDate = floor.lifecycle.endDate;
      }
    }

    // Get the building object and update it with the modified floor list
    this.locationService.getBuilding(buildingId.toString()).subscribe({
      next: (buildingData: any) => {
        // Clean the floor list by removing UI-specific properties before sending to API
        const cleanedFloors = this.buildingFloorList.map((f) => {
          const { isedit, ...cleanFloor } = f;
          // Ensure all floors have endDate: null if not present (matching legacy behavior)
          if (!cleanFloor.lifecycle.endDate) {
            cleanFloor.lifecycle.endDate = null;
          }
          return cleanFloor;
        });

        // Update the building's floor list with our cleaned list
        buildingData.buildingFloors = cleanedFloors;
        
        const lockControlNumber = buildingData.audit?.lockControlNumber || 0;
        const url = `/buildings/${buildingId}?lockControlNumber=${lockControlNumber}`;

        // Save the updated building (which includes the updated floor)
        this.locationService.saveBuildingFloor(buildingData, url).subscribe({
          next: (response: any) => {
            // Success - turn off edit mode for this floor
            floor.isedit = false;
            this.location.selectedFloor = {};
            
            // Refresh the floor list to show updated data
            this.getBuildingFloors(buildingId);
            
            // Keep location in edit mode with expansion open (same as addFloors behavior)
            location.isEdit = true;
            location.expanded = true;
            
            // Send success message using direct pattern (same as addFloors)
            this.locationService.updateReturnCode(200);
            this.locationService.updateReturnMessage('Floor(s) has been successfully updated');
            this.locationService.updateReturnMessageArray([]);
            this.locationService.updateHideMessage(false);
          },
          error: (error) => {
            // Handle error using direct pattern
            const errorMessages: string[] = [];
            let errorMessage = 'An error occurred';
            let statusCode = error?.status || 500;
            
            if (error?.error?.message) {
              errorMessage = error.error.message;
            } else if (error?.message) {
              errorMessage = error.message;
            } else if (typeof error === 'string') {
              errorMessage = error;
            }
            
            const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
            if (duplicateFloorMatch) {
              const floorNumber = duplicateFloorMatch[1];
              errorMessage = `Add floor failed: ${floorNumber} already exists`;
            }
            
            errorMessages.push(errorMessage);
            
            this.locationService.updateReturnCode(statusCode);
            this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
            this.locationService.updateReturnMessageArray(errorMessages);
            this.locationService.updateHideMessage(false);
          },
        });
      },
      error: (error) => {
        // Handle building retrieval error using direct pattern
        const errorMessages: string[] = ['Failed to retrieve building data'];
        this.locationService.updateReturnCode(error?.status || 500);
        this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.locationService.updateReturnMessageArray(errorMessages);
        this.locationService.updateHideMessage(false);
      },
    });
  }
  getLocationTemplate1(location: Location) {
    return this.location;
  }
  showUpdateFloor(floor: any): void {
    // Use setTimeout to defer the update to the next change detection cycle
    setTimeout(() => {
      this.location.selectedFloor = { ...floor };
      floor.isedit = true;
      this.cdr.markForCheck();
    }, 0);
  }

  updateFloorInAddMode(floor: BuildingFloor): void {
    // Validate that we have the necessary data (matching create component pattern)
    const errorMessages: string[] = [];
    
    if (!floor || !floor.lifecycle || !floor.lifecycle.beginDate) {
      errorMessages.push('Floor start date is required');
    }

    // Get the building ID
    const buildingId = this.building?.buildingId;
    
    if (!buildingId) {
      errorMessages.push('Building ID not found');
    }
    
    // If validation errors exist, display them and return
    if (errorMessages.length > 0) {
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(errorMessages);
      this.locationService.updateHideMessage(false);
      return;
    }

    // Update the floor in the newBuildingFloorList
    const floorIndex = this.newBuildingFloorList.findIndex(
      (f) => f.buildingFloorId === floor.buildingFloorId
    );

    if (floorIndex !== -1) {
      // Update the floor's lifecycle dates
      this.newBuildingFloorList[floorIndex].lifecycle.beginDate = floor.lifecycle.beginDate;
      if (floor.lifecycle.endDate) {
        this.newBuildingFloorList[floorIndex].lifecycle.endDate = floor.lifecycle.endDate;
      }
    }

    // Get the building object and update it with the modified floor list
    this.locationService.getBuilding(buildingId.toString()).subscribe({
      next: (buildingData: any) => {
        // Clean the floor list by removing UI-specific properties before sending to API
        const cleanedFloors = this.newBuildingFloorList.map((f) => {
          const { isedit, ...cleanFloor } = f;
          // Ensure all floors have endDate: null if not present
          if (!cleanFloor.lifecycle.endDate) {
            cleanFloor.lifecycle.endDate = null;
          }
          return cleanFloor;
        });

        // Update the building's floor list with our cleaned list
        buildingData.buildingFloors = cleanedFloors;
        
        const lockControlNumber = buildingData.audit?.lockControlNumber || 0;
        const url = `/buildings/${buildingId}?lockControlNumber=${lockControlNumber}`;

        // Save the updated building (which includes the updated floor)
        this.locationService.saveBuildingFloor(buildingData, url).subscribe({
          next: (response: any) => {
            // Success - turn off edit mode for this floor
            floor.isedit = false;
            this.location.selectedFloor = {};
            
            // Refresh the floor list to show updated data
            this.getBuildingFloors(buildingId);
            
            // Send success message using direct pattern
            this.locationService.updateReturnCode(200);
            this.locationService.updateReturnMessage('Floor(s) has been successfully updated');
            this.locationService.updateReturnMessageArray([]);
            this.locationService.updateHideMessage(false);
          },
          error: (error) => {
            // Handle error using direct pattern
            const errorMessages: string[] = [];
            let errorMessage = 'An error occurred';
            let statusCode = error?.status || 500;
            
            if (error?.error?.message) {
              errorMessage = error.error.message;
            } else if (error?.message) {
              errorMessage = error.message;
            } else if (typeof error === 'string') {
              errorMessage = error;
            }
            
            const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
            if (duplicateFloorMatch) {
              const floorNumber = duplicateFloorMatch[1];
              errorMessage = `Add floor failed: ${floorNumber} already exists`;
            }
            
            errorMessages.push(errorMessage);
            
            this.locationService.updateReturnCode(statusCode);
            this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
            this.locationService.updateReturnMessageArray(errorMessages);
            this.locationService.updateHideMessage(false);
          },
        });
      },
      error: (error) => {
        // Handle building retrieval error using direct pattern
        const errorMessages: string[] = ['Failed to retrieve building data'];
        this.locationService.updateReturnCode(error?.status || 500);
        this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.locationService.updateReturnMessageArray(errorMessages);
        this.locationService.updateHideMessage(false);
      },
    });
  }

  getLockControlNumber(data: any) {
    return data.audit.lockControlNumber || null;
  }

  selectedBuildingCode: string = 'B';
  
  // Helper method to check if any row is currently being edited
  isAnyRowInEditMode(): boolean {
    return this.locationResults.some((loc: any) => loc.isEdit === true) || this.show === true;
  }
  
  editLocation(selLocation: Location): void {
    this.editRow = true;
    //this.location.isEdit = true;
    this.location = selLocation;
    this.originalDataCopy = structuredClone(selLocation);
    this.oldLocationValue = this.selectedLocationValue;
    this.organizationService.getBuildings().subscribe((res: any) => {
      this.selectedEditFloor = this.location.building.floorNumber;
      this.buildingCodeList = res.results as BuildingResults[];
    });

    this.location.lifecycle.beginDate = new Date(this.location.lifecycle.beginDate);

    //   this.floor.lifecycle.beginDate = new Date(this.floor.lifecycle.beginDate);
    this.locationService.getLocationPurposeList().subscribe((res: any) => {
      this.locationPurposeList = res.results;
    });
    if (selLocation) {
      this.getBuildingFloors(this.location.building.buildingId);
      this.getBuildingFloors(this.location.building.buildingId);
      this.selectedBuildingObject = this.location.building;
      this.selectedBuildingCode = this.location.building.code;
      this.selectedFloor = this.location.building.floorNumber;
      this.floor.lifecycle = this.getLifecycleForFloor(this.selectedFloor);
      this.selectedLocationValue = this.location.locationPurpose.id;
      this.selectedLocationDesc = this.location.locationPurpose.description;
      // this.floor = this.buildingFloorList[0];
      if (this.location.lifecycle && typeof this.location.lifecycle.beginDate === 'string') {
        this.location.lifecycle.beginDate = new Date(this.location.lifecycle.beginDate);
      }
      if (this.floor.lifecycle && typeof this.floor.lifecycle.beginDate === 'string') {
        this.floor.lifecycle.beginDate = new Date(this.floor.lifecycle.beginDate);
      }
    }

    // this.location.isEdit = false;
    // this.location.expanded = false;
    this.toggleDetails(this.location);
  }

  locationSearch(): void {
    this.locationService
      .getLocations(false, '', this.locationParams, false, 10, 0)
      .subscribe((res: any) => {
        this.locationResults = res.results;
        // Send data to parent component to update total count
        this.locationService.sendData(res, this.locationParams);
      });
  }

  locationSearchWithMessage(message: string): void {
    this.locationService
      .getLocations(false, '', this.locationParams, false, 10, 0)
      .subscribe((res: any) => {
        this.locationResults = res.results;
        // Send data to parent component to update total count
        this.locationService.sendData(res, this.locationParams);
        // Send success message after data is sent
        // Use setTimeout to ensure message is sent after data subscription processes
        setTimeout(() => {
          this.locationService.sendMessage(message);
        }, 0);
      });
  }

  getLifecycleForFloor(targetFloorNumber: string): any | undefined {
    // Use the find() method to get the correct floor object
    const floor = this.buildingFloorList.find((f) => f.floorNumber === targetFloorNumber);

    // Return the lifecycle if the floor was found, otherwise return undefined
    return floor ? floor.lifecycle : undefined;
  }
  toggleDetails(selLocation: any): void {
    if (selLocation) {
      this.location = selLocation;
      // Fetch building floors when expanding the row
      if (selLocation.expanded && selLocation.building && selLocation.building.buildingId) {
        this.getBuildingFloors(selLocation.building.buildingId);
      }
    }
  }

  ngOnInit() {
    this.currentLifecycleData = {
      beginDate: undefined,
      endDate: null,
      cascade: false,
    };
    this.buildingFloorList = [];
    this.inactivateSubscription = this.locationService.inactivateClicked$
      // .subscribe(() => {
      //   this.handleInactivateAction();
      // });
      .subscribe({
        next: (res: any) => {
          // 'res' is captured here inside the 'next' handler
          this.handleInactivateAction();
        },
        error: (error) => {
          // Handle error using direct pattern
          const errorMessages: string[] = [];
          let errorMessage = 'An error occurred';
          let statusCode = error?.status || 500;
          
          if (error?.error?.message) {
            errorMessage = error.error.message;
          } else if (error?.message) {
            errorMessage = error.message;
          } else if (typeof error === 'string') {
            errorMessage = error;
          }
          
          errorMessages.push(errorMessage);
          
          this.locationService.updateReturnCode(statusCode);
          this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
          this.locationService.updateReturnMessageArray(errorMessages);
          this.locationService.updateHideMessage(false);
        },
      });

    this.locationService.command$.pipe(takeUntil(this.destroy$)).subscribe((command) => {
      if (command === 'expand') {
        this.expandAll();
      } else if (command === 'collapse') {
        this.collapseAll();
      }
    });

    this.subscription = this.locationService.getData().subscribe((data) => {
      if (data) {
        // Check if data has meta information (full response object)
        if (data.meta && data.results) {
          this.receivedData = data.results;
          this.locationResults = data.results;
          this.total = data.meta.total || data.results.length;
          // Initialize expanded property for all locations
          this.initializeExpansionState();
        }
        // Fallback: if data is an array (backward compatibility)
        else if (Array.isArray(data)) {
          this.receivedData = data;
          this.locationResults = data;
          this.total = data.length;
          // Initialize expanded property for all locations
          this.initializeExpansionState();
        }
      }
    });
    this.subscription = this.locationService.getParams().subscribe((data) => {
      this.locationParams = data;
    });

    this.locationService.sendData(this.locationResults, this.locationParams);

    this.initializeExpansionState();

    if (this.location && this.location.building) {
      this.getBuildingFloors(this.location.building.buildingId);
    }

    this.organizationService.getBuildings().subscribe((res: any) => {
      this.buildingCodeList = res.results as BuildingResults[];
    });

    this.locationService.getLocationPurposeList().subscribe((res: any) => {
      this.locationPurposeList = res.results;
    });
  }

  reactivateLocation(locnObject: NewLocation): void {
    const dialogRef = this.dialog.open(ReactivateLocationConfirmDialogComponent, {
      width: '720px',
      data: { location: locnObject }, // Passing data to the dialog
    });

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed) {
        const date = new Date();
        date.setHours(date.getHours() - 22);
        this.currentLifecycleData.beginDate = locnObject.lifecycle.beginDate;
        this.currentLifecycleData.endDate = '';
        this.currentLifecycleData.cascade = false;
        locnObject.lifecycle = this.currentLifecycleData;
        this.inactivateLocations = locnObject;
        this.building = locnObject?.building;

        const buildingName = this.building?.name || '';

        this.locationService.reactivateLocation(locnObject).subscribe({
          next: (res: any) => {
            // Send success message using direct pattern
            this.setwindowtotop();
            this.locationService.updateReturnCode(200);
            this.locationService.updateReturnMessage('Successfully reactivated location:  ' + buildingName); 
            this.locationService.updateReturnMessageArray([]);
            this.locationService.updateHideMessage(false);
          },
          error: (err) => {
            this.locationService.getAssociatedWorkers(locnObject).subscribe((res: any) => {
              this.openAssociatedLocDialog(res.results);
            });
          },
        });
      }
    });
  }
  openInactivateDialog(locationObject: any[]): void {
    if(locationObject.length === 0) {
      return;
    }
    const dialogRef = this.dialog.open(InactivateLocationConfirmDialogComponent, {
      width: '720px',
      data: { locations: locationObject }, // Passing data to the dialog
    });

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed) {
        // Track the number of inactivation requests to know when all are complete
        let completedRequests = 0;
        const totalRequests = locationObject.length;
        
        locationObject.forEach((locnObject: NewLocation) => {
          // Save the original lifecycle before modifying it
          const originalLifecycle = structuredClone(locnObject.lifecycle);
          
          const date = new Date();
          date.setHours(date.getHours() - 22);
          const beginDate = date;

          date.setHours(date.getHours() - 23);
          const endDate = date;
          
          // Create a fresh lifecycle object for each location (don't reuse currentLifecycleData)
          const lifecycleData: Lifecycle = {
            beginDate: beginDate,
            endDate: endDate,
            cascade: true
          };
          
          locnObject.lifecycle = lifecycleData;
          this.inactivateLocations = locnObject;
          
          this.locationService.inactivateLocations(locnObject).subscribe({
            next: (res: any) => {
              const buildingName = res.building?.name || res.building?.code || '';
              // Send success message using direct pattern
              this.setwindowtotop();
              this.locationService.updateReturnCode(200);
              this.locationService.updateReturnMessage('Successfully inactivated location: ' + buildingName);
              this.locationService.updateReturnMessageArray([]);
              this.locationService.updateHideMessage(false);
              
              // Increment completed requests counter
              completedRequests++;
              
              // Reset the row's edit state
              locnObject.isEdit = false;
              locnObject.expanded = false;
              
              // When all requests are complete, refresh the search
              if (completedRequests === totalRequests) {
                this.locationSearch();
              }
            },
            error: (err) => {
              // Increment completed requests counter even on error
              completedRequests++;
              
              // Restore the original lifecycle data so the row shows edit icon, not reactivate
              locnObject.lifecycle = originalLifecycle;
              
              // Reset the row's edit state
              locnObject.isEdit = false;
              locnObject.expanded = false;
              
              this.locationService.getAssociatedWorkers(locnObject).subscribe((res: any) => {
                this.openAssociatedLocDialog(res.results);
              });
              
              // When all requests are complete, refresh the search
              if (completedRequests === totalRequests) {
                this.locationSearch();
              }
            },
          });
        });
      }
    });
  }

  openAssociatedLocDialog(locationObject: any[]): void {
    const dialogRef = this.dialog.open(AssociatedObjectLocationsComponent, {
      width: '800px',
      data: { locations: locationObject }, // Passing data to the dialog
    });

    dialogRef.afterClosed().subscribe((confirmed) => {
      if (confirmed) {
        // Don't refresh search here - just close the dialog
        // The location data should not be modified by the associated dialog
      }
    });
  }

  getLocationTemplate(location: any): string {
    // Return 'editLocationRow' if location is in edit mode, otherwise 'displayLocationRow'
    if (location.isEdit) {
      return 'editLocationRow';
    }
    return 'displayLocationRow';
  }

  initializeExpansionState(): void {
    if (this.locationResults.length > 0) {
      this.locationResults.forEach((location: { expanded: boolean }) => {
        location.expanded = false; // Default state is collapsed
      });
    }
  }

  onDateChanged(newDate: any) {
    if (!this.location.lifecycle) {
      this.location.lifecycle = {};
    }
    this.location.lifecycle.beginDate = newDate;

    const floorDetail1: FloorDetail = {
      floorNumber: this.location?.building?.floorNumber,
      lifecycle: {
        beginDate: this.setTodaysDate(),
        endDate: null,
      },
      active: true,
    };
    this.buildingFloorList.push(floorDetail1);
  }

  floorDateChanged(newDate: any) {
    // if (!this.location.lifecycle) {
    //   this.location.lifecycle = {};
    // }
    // this.location.lifecycle.beginDate = newDate;

    const floorDetail1: FloorDetail = {
      floorNumber: this.floor.floorNumber,
      lifecycle: {
        beginDate: newDate, //this.setTodaysDate(),
        endDate: null,
      },
      active: true,
    };

    this.buildingFloorList.push(floorDetail1);
    //this.location.buildingFloors = this.buildingFloorList;
  }
  showAddRow(): void {
    // Toggle the add row visibility
    this.show = !this.show;
    
    // If opening the add row, reset all fields
    if (this.show) {
      this.location.isEdit = false;
      this.buildingFloorList = [];
      this.newBuildingFloorList = [];
      this.buildingCodeHeader = 'Building Code*';
      this.floorNumberHeader = 'Floor*';
      this.purposeTextHeader = 'Purpose*';
      
      // Reset form fields
      this.selectedBuildingCode = '';
      this.selectedEditFloor = '';
      this.selectedFloor = '';
      this.selectedLocationValue = 6;
      this.addFloor = '';
      
      // Reset location object for new entry
      this.location = {
        corridorId: '',
        suiteId: '',
        roomId: '',
        zoneId: '',
        mailStopIndicator: false,
        isEdit: false,
        expanded: false
      };
    }
    else {
      // If closing the add row, remove asterisks from headers
      this.buildingCodeHeader = 'Building Code';
      this.floorNumberHeader = 'Floor';
      this.purposeTextHeader = 'Purpose';
    }
  }
  compareById(item1: any, item2: any): boolean {
    return item1 && item2 ? item1.id === item2.id : item1 === item2;
  }

  // checkAll(): void {

  //   // Logic for select all checkbox
  // }

  getBuildingFloors(buildingId: number): void {
    this.locationService.getBuildingFloors(buildingId + '').subscribe((res: any) => {
      // Process building floors similar to legacy implementation
      const floors: any[] = [];
      const now = new Date();
      
      if (res && res.buildingFloors) {
        res.buildingFloors.forEach((floor: any) => {
          // Ensure endDate is null if not set
          if (!floor.lifecycle.endDate) {
            floor.lifecycle.endDate = null;
          }
          
          // Add all floors (filtering logic can be added based on showAllSearch if needed)
          floors.push(floor);
        });
      }
      
      // Use setTimeout to defer the update to the next change detection cycle
      setTimeout(() => {
        this.buildingFloorList = floors;
        this.newBuildingFloorList = floors;
        // Sort floor list by floor number
        this.sortFloorList();
        
        // Mark for check to ensure change detection runs
        this.cdr.markForCheck();
      }, 0);
    });
  }

  sortFloorList(): void {
    if (this.buildingFloorList && this.buildingFloorList.length > 0) {
      this.buildingFloorList.sort((a, b) => {
        // Convert floor numbers to strings for comparison
        const floorA = String(a.floorNumber || '');
        const floorB = String(b.floorNumber || '');
        
        // Try to parse as numbers for numeric comparison
        const numA = parseFloat(floorA);
        const numB = parseFloat(floorB);
        
        // If both are valid numbers, compare numerically
        if (!isNaN(numA) && !isNaN(numB)) {
          return numA - numB;
        }
        
        // Otherwise, compare as strings
        return floorA.localeCompare(floorB);
      });
    }
  }

  resetRow(selLocation: Location): void {
    // Check if we're in "add new location" mode
    if (this.show) {
      // ADD ROW CASE: Clear all input fields
      this.location = {
        corridorId: '',
        suiteId: '',
        roomId: '',
        zoneId: '',
        mailStopIndicator: false,
        isEdit: false,
        expanded: false
      };
      
      // Clear all form field selections
      this.selectedBuildingCode = '';
      this.selectedEditFloor = '';
      this.selectedFloor = '';
      this.selectedLocationValue = 6; // Default purpose value
      this.addFloor = ''; // Clear add floor input
      this.buildingCode = '';
      
      // Clear floor lists
      this.buildingFloorList = [];
      this.newBuildingFloorList = [];
      
      // Clear building object
      this.building = {};
      this.selectedBuildingObject = null;
      this.selectedFloorObject = null;

      this.invalidBuildingCode=false;
      this.invalidFloorNumber=false;
      this.invalidLocationPurpose=false;
      this.invalidRequiredFloorNumberInput=false;
      this.cdr.markForCheck();
    } else {
      // EDIT CASE: Restore original values from backup
      this.location = selLocation || {};
      
      // Restore from original data copy if available
      if (this.originalDataCopy) {
        Object.assign(this.location, structuredClone(this.originalDataCopy));
        
        // Restore dropdown selections from original data
        this.selectedBuildingCode = this.originalDataCopy.building?.code || '';
        this.selectedEditFloor = this.originalDataCopy.building?.floorNumber || '';
        this.selectedFloor = this.originalDataCopy.building?.floorNumber || '';
        this.selectedLocationValue = this.originalDataCopy.locationPurpose?.id || 6;
        this.buildingCode = this.originalDataCopy.building?.code || '';
        
        // Restore building object
        this.selectedBuildingObject = this.originalDataCopy.building;
        
        // Restore floor list for the original building
        if (this.originalDataCopy.building?.buildingId) {
          this.getBuildingFloors(this.originalDataCopy.building.buildingId);
        }
      } else {
        // Fallback if no original copy exists
        this.buildingCode = this.selectedBuildingCode || '';
        this.selectedEditFloor = this.location?.building?.floorNumber || '';
        this.selectedLocationValue = this.location?.locationPurpose?.id || 6;
      }
    }
  }

  expandAll(): void {
    // Expand all rows and load floor data for each location
    this.locationResults.forEach((row: any) => {
      row.expanded = true;
      // Load floor data for each location when expanding
      if (row.building && row.building.buildingId) {
        this.getBuildingFloors(row.building.buildingId);
      }
    });
  }

  collapseAll(): void {
    this.locationResults.forEach((row: { expanded: boolean }) => (row.expanded = false));
  }

  confirmReactivateLocation(location: any): void {
    this.reactivateLocation(location);
  }

  saveLocation(selLocation: any): void {
    // Validate required fields before submission (matching create component pattern)
    const errorMessages: string[] = [];
    
    if (!this.selectedBuildingCode) {
      errorMessages.push('Building Code is required');
      this.invalidBuildingCode = true;
    }
    
    if (!this.selectedFloorObject && !this.selectedEditFloor) {
      errorMessages.push('Floor is required');
      this.invalidFloorNumber = true;
    }
    
    if (!this.selectedLocationValue) {
      errorMessages.push('Location Purpose is required');
      this.invalidLocationPurpose = true;
    }
    
    // If validation errors exist, display them and return
    if (errorMessages.length > 0) {
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(errorMessages);
      this.locationService.updateHideMessage(false);
      return;
    }
    
    this.location = structuredClone(selLocation);
    const locId = this.location.locationId;
    const selectedLocationObject = this.locationPurposeList.find(
      (location) => location.id === Number(this.selectedLocationValue)
    );

    this.selectedBuildingObject = this.buildingCodeList.find(
      (building) => building.buildingCode === this.selectedBuildingCode
    );
    const buildingCopy = structuredClone(this.selectedBuildingObject);
    const purposeCopy = structuredClone(selectedLocationObject);

    this.location = {
      ...structuredClone(selLocation), // Start with a fresh base
    };

    // Only update locationPurpose if a valid purpose was selected
    if (purposeCopy) {
      this.location.locationPurpose = {
        id: purposeCopy.id,
        value: purposeCopy.value,
        description: purposeCopy.description,
      };
    }

    if (this.selectedFloorObject) {
      this.location.building.buildingFloorId = this.selectedFloorObject?.buildingFloorId;
      this.location.building.floorNumber = this.selectedFloorObject?.floorNumber;
    }
    const { isEdit, expanded, ...cleanedLocation } = this.location;
    const locNum = this.location.audit?.lockControlNumber ?? 0; //this.getLockControlNumber(this.location);

    this.locationService
      .saveLocation(cleanedLocation, '/locations/' + locId + '?lockControlNumber=' + locNum)
      .subscribe({
        next: (res: any) => {
          this.setwindowtotop();
          
          // Send success message using direct pattern
          this.locationService.updateReturnCode(200);
          this.locationService.updateReturnMessage('Location(s) has been successfully updated');
          this.locationService.updateReturnMessageArray([]);
          this.locationService.updateHideMessage(false);
          
          // Collapse the location after successful save
          selLocation.isEdit = false;
          selLocation.expanded = false;
          
          // Trigger refresh search which will call executeLocationSearch from advanced search component
          this.locationService.triggerRefreshSearch('Location(s) has been successfully updated');
        },
        error: (error) => {
          // Handle error using direct pattern
          const errorMessages: string[] = [];
          let errorMessage = 'An error occurred';
          let statusCode = error?.status || 500;
          
          if (error?.error?.message) {
            errorMessage = error.error.message;
          } else if (error?.message) {
            errorMessage = error.message;
          } else if (typeof error === 'string') {
            errorMessage = error;
          }
          
          errorMessages.push(errorMessage);
          
          this.locationService.updateReturnCode(statusCode);
          this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
          this.locationService.updateReturnMessageArray(errorMessages);
          this.locationService.updateHideMessage(false);
        },
      });
  }

  private handleSaveSuccess(message: string): void {
    this.setwindowtotop();
    
    // Use the same pattern as create component
    this.locationService.updateReturnCode(200);
    this.locationService.updateReturnMessage(message);
    this.locationService.updateReturnMessageArray([]);
    this.locationService.updateHideMessage(false);
  }
  
  private handleSaveSuccess1(message: string): void {
    // Use the same pattern as create component
    this.locationService.updateReturnCode(200);
    this.locationService.updateReturnMessage(message);
    this.locationService.updateReturnMessageArray([]);
    this.locationService.updateHideMessage(false);
  }

  private handleSaveError(error: any): void {
    // Collect error messages in an array (matching create component pattern)
    const errorMessages: string[] = [];
    let errorMessage = 'An error occurred';
    let statusCode = error?.status || 500;
    
    // Handle different error formats
    if (error?.error?.message) {
      // HTTP error response
      errorMessage = error.error.message;
    } else if (error?.message) {
      // Custom error object or standard Error
      errorMessage = error.message;
    } else if (typeof error === 'string') {
      // String error
      errorMessage = error;
    }
    
    // Check for "Duplicate floor" pattern and transform the message
    // Pattern: "Duplicate floor : 01" -> "Add floor failed: 01 already exists"
    const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
    if (duplicateFloorMatch) {
      const floorNumber = duplicateFloorMatch[1];
      errorMessage = `Add floor failed: ${floorNumber} already exists`;
    }
    
    errorMessages.push(errorMessage);
    
    // Use the same pattern as create component for error handling
    this.locationService.updateReturnCode(statusCode);
    this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
    this.locationService.updateReturnMessageArray(errorMessages);
    this.locationService.updateHideMessage(false);
  }
  addNewLocation(selLocation: Location): void {
    // Validate required fields before submission (matching create component pattern)
    const errorMessages: string[] = [];
    
    if (!this.selectedBuildingCode) {
      errorMessages.push('Building Code is required');
      this.invalidBuildingCode = true;
    }
    
    if (!this.selectedFloorObject) {
      errorMessages.push('Floor is required');
      this.invalidFloorNumber = true;
    }
    
    if (!this.selectedLocationValue) {
      errorMessages.push('Location Purpose is required');
      this.invalidLocationPurpose = true;
    }
    
    // If validation errors exist, display them and return
    if (errorMessages.length > 0) {
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(errorMessages);
      this.locationService.updateHideMessage(false);
      return;
    }
    
    // Find the selected location purpose object
    const selectedLocationObject = this.locationPurposeList.find(
      (location) => location.id === Number(this.selectedLocationValue)
    );

    // Find the selected building object
    this.selectedBuildingObject = this.buildingCodeList.find(
      (building) => building.buildingCode === this.selectedBuildingCode
    );

    // Find the selected floor object with full details
    const selectedFloorWithDetails = this.buildingFloorList.find(
      (floor) => floor.floorNumber === this.selectedFloorObject?.floorNumber
    );

    // Construct the payload matching the expected format
    const payload: any = {
      lifecycle: {
        beginDate: this.location.lifecycle?.beginDate || new Date().toISOString(),
        endDate: null
      },
      locationPurpose: selectedLocationObject ? {
        id: selectedLocationObject.id,
        value: selectedLocationObject.value,
        description: selectedLocationObject.description,
        lifecycle: selectedLocationObject.lifecycle,
        audit: selectedLocationObject.audit
      } : undefined,
      mailStopIndicator: this.location.mailStopIndicator || false,
      building: {
        buildingFloorId: selectedFloorWithDetails?.buildingFloorId || this.selectedFloorObject?.buildingFloorId,
        floorNumber: this.selectedFloorObject?.floorNumber,
        buildingId: this.building?.buildingId,
        lifecycle: selectedFloorWithDetails?.lifecycle || {
          beginDate: new Date().toISOString(),
          endDate: null
        },
        audit: selectedFloorWithDetails?.audit,
        code: this.building?.buildingCode
      },
      corridorId: this.location.corridorId || '',
      suiteId: this.location.suiteId || '',
      roomId: this.location.roomId || '',
      zoneId: this.location.zoneId || ''
    };

    // Log the payload for verification
    this.locationService.addNewLocation(payload, '/locations').subscribe({
      next: (res: any) => {
        // Send success message using direct pattern
        this.setwindowtotop();
        this.locationService.updateReturnCode(200);
        this.locationService.updateReturnMessage('Location(s) has been successfully added');
        this.locationService.updateReturnMessageArray([]);
        this.locationService.updateHideMessage(false);
      },
      error: (error) => {
        // Handle error using direct pattern
        const errorMessages: string[] = [];
        let errorMessage = 'An error occurred';
        let statusCode = error?.status || 500;
        
        if (error?.error?.message) {
          errorMessage = error.error.message;
        } else if (error?.message) {
          errorMessage = error.message;
        } else if (typeof error === 'string') {
          errorMessage = error;
        }
        
        const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
        if (duplicateFloorMatch) {
          const floorNumber = duplicateFloorMatch[1];
          errorMessage = `Add floor failed: ${floorNumber} already exists`;
        }
        
        errorMessages.push(errorMessage);
        
        this.locationService.updateReturnCode(statusCode);
        this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
        this.locationService.updateReturnMessageArray(errorMessages);
        this.locationService.updateHideMessage(false);
      },
    });
  }

  cancelAddLocation(selLocation: Location): void {
    this.resetRow(this.location);
    this.location = selLocation;
    this.location.isEdit = false;
    this.location.expanded = false;
    this.show = false; // Close the add/edit row
    this.invalidRequiredFloorNumberInput = false;
    this.newBuildingFloorList = [];
    this.buildingFloorList = [];
    
    // Clear all form fields
    this.selectedBuildingCode = '';
    this.selectedEditFloor = '';
    this.selectedFloor = '';
    this.selectedLocationValue = undefined;
    this.addFloor = '';
    this.selectedDate = undefined as any;
    
    // Reset headers to remove asterisks
    this.buildingCodeHeader = 'Building Code';
    this.floorNumberHeader = 'Floor';
    this.purposeTextHeader = 'Purpose';
    
    // Don't call toggleDetails if we're closing the add row (show was true)
    // Only toggle if this was an edit operation on an existing location
    if (selLocation && (selLocation as any).locationId) {
      this.toggleDetails(this.location);
    }
  }

  addLocation(): void {
    // Logic to save the new location
  }
  collapsePhoneNumber() {
    this.locationModel.selectedLocation = {};
  }
  pageSizeChangedEvent(pageSize: number) {}

  public onPageChange(event: PageEvent): void {}

  toggleRowDetails(assignment: any): void {}

  // Function to check if a row is expanded

  isExpanded(assignment: any): any {}

  masterSelected: boolean = false;

  checkUncheckAll() {
    // For each location in the array, set its isSelected property
    // to the value of the masterSelected checkbox
    this.locationResults.forEach((location: { isSelected: boolean }) => {
      location.isSelected = this.masterSelected;
    });
  }
  toggleSelection(id: number): void {
    const index = this.selectedIds.indexOf(id);
    if (index > -1) {
      this.selectedIds.splice(index, 1); // Remove if already selected
    } else {
      this.selectedIds.push(id); // Add if not selected
    }
    this.locationService.updateSelectedIds(this.selectedIds);
    // Emit the updated list to Component A
    this.selectedIdsChange.emit(this.selectedIds);
  }
  // Function to update master checkbox status if individual items are toggled manually
  isAllSelected() {
    // Check if ALL items currently have isSelected set to true
    this.masterSelected = this.locationResults.every(
      (location: { isSelected: boolean }) => location.isSelected === true
    );
  }

  // Example of how to retrieve the selected items
  getSelectedLocations() {
    const selectedItems = this.locationResults.filter(
      (location: { isSelected: any }) => location.isSelected
    );
  }

  getFloors(floorInput: string): string[] {
    // Logic to parse input string into an array of floor strings
    // Example: "1,2,3" -> ["1", "2", "3"]
    return floorInput
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f.length > 0);
  }

  duplicateFloor(aFloor: string, currentFloorDetails: FloorDetail[]): boolean {
    // Normalize the input floor number: single digit becomes "0X" (e.g., "1" -> "01")
    let normalizedInput = aFloor.toUpperCase();
    if (/^\d$/.test(normalizedInput)) {
      normalizedInput = '0' + normalizedInput;
    }
    
    // Check if the normalized floor number already exists in the list
    return currentFloorDetails.some((existingFloor) => {
      let normalizedExisting = existingFloor.floorNumber.toUpperCase();
      // Also normalize existing floor numbers if they're single digits
      if (/^\d$/.test(normalizedExisting)) {
        normalizedExisting = '0' + normalizedExisting;
      }
      return normalizedExisting === normalizedInput;
    });
  }

  convertToDateObject(dateString: string | Date | null | undefined): Date | null {
    if (!dateString) {
      return null;
    }
    // Check if it's already a Date object
    if (dateString instanceof Date) {
      return dateString;
    }

    // Convert string to Date
    const date = new Date(dateString);

    // Return null if the resulting date is invalid
    return isNaN(date.getTime()) ? null : date;
  }
  // targetFloorNumber: number, newDateValue: Date
  updateFloorBeginDate(floor: BuildingFloor): void {
    //const targetFloorNumber = floor.floorNumber;

    const floorToUpdate = this.buildingFloorList.find((floor) => {
      return floor.floorNumber === floor.floorNumber;
    });

    // Check if the floor was actually found
    if (floorToUpdate) {
      // Update the property directly.
      // Because floorToUpdate is an object reference, the original array item is updated.
      floorToUpdate.lifecycle.beginDate = floor.lifecycle.beginDate;

    } else {
    }

    this.locationService.getBuilding(this.location.building.buildingId).subscribe((res: any) => {
      // Clean the floor list by removing UI-specific properties before sending to API
      res.buildingFloors = this.buildingFloorList.map((f) => {
        const { isedit, ...cleanFloor } = f;
        return cleanFloor;
      });
      const locNum = res.audit.lockControlNumber;
      this.locationService
        .saveBuildingFloor(res, '/buildings/' + res.buildingId + '?lockControlNumber=' + locNum)
        .subscribe({
          next: (res: any) => {
            // 'res' is captured here inside the 'next' handler
            this.floor.isedit = true;
            this.location.expanded = true;
            // Send success message using direct pattern
            this.setwindowtotop();
            this.locationService.updateReturnCode(200);
            this.locationService.updateReturnMessage('Floor(s) has been successfully updated');
            this.locationService.updateReturnMessageArray([]);
            this.locationService.updateHideMessage(false);
          },
          error: (error) => {
            // Handle error using direct pattern
            const errorMessages: string[] = [];
            let errorMessage = 'An error occurred';
            let statusCode = error?.status || 500;
            
            if (error?.error?.message) {
              errorMessage = error.error.message;
            } else if (error?.message) {
              errorMessage = error.message;
            } else if (typeof error === 'string') {
              errorMessage = error;
            }
            
            errorMessages.push(errorMessage);
            
            this.locationService.updateReturnCode(statusCode);
            this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
            this.locationService.updateReturnMessageArray(errorMessages);
            this.locationService.updateHideMessage(false);
          },
        });
    });
  }

  setTodaysDate(): string {
    // 1. Get the current date and time
    const today = new Date();

    // 2. Format the date into the required ISO 8601 UTC string format
    //    toISOString() produces the format "YYYY-MM-DDTHH:mm:ss.sssZ"
    const isoString = today.toISOString();

    // 3. Assign the formatted string to the field in your data object
    return isoString;

    // Example Output: "2025-12-11T15:14:00.000Z" (based on current time)
  }
  convertToIso(dateString: string): string | null {
    const now = new Date();
    const currentYear = now.getFullYear();

    // The input format is "Wkd Mon DDTHH:mm:ss"
    const parts = dateString.split('T');
    const datePart = parts[0];
    const timePart = parts[1];
    const standardFormat = `${datePart.substring(4, 7)} ${datePart.substring(8, 10)} ${currentYear} ${timePart}`;

    // 2. Create a Date object
    let dateObj = new Date(standardFormat);

    // Check if the date is valid (NaN indicates an invalid date)
    if (isNaN(dateObj.getTime())) {
      return null;
    }
    return dateObj.toISOString();
  }

  addFloors(): void {
    // Clear all previous validation messages at the start of each add floor operation
    this.locationService.updateReturnMessageArray([]);
    this.locationService.updateHideMessage(true);
    
    // 1. Reset flags
    this.invalidFloorEntry = false;
    this.invalidFloorStartDate = false;
    this.invalidFloorEndDate = false;
    this.invalidRequiredFloorNumberInput = false;
    
    // Collect all validation errors before displaying
    let validationErrors: string[] = [];
    
    // 2. Initial Validation (floorNumber required check)
    if (!this.addFloor || this.addFloor.trim() === '') {
      this.invalidRequiredFloorNumberInput = true;
      
      // Add validation error
      const requiredMessage = 'Floor number is required';
      validationErrors.push(requiredMessage);
      
      // Display validation error using the same pattern as create component
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(validationErrors);
      this.locationService.updateHideMessage(false);
      return;
    }
    
    // 3. Validation: Check if addFloor is not null but buildingCode is null
    if (this.addFloor && this.addFloor.trim() !== '') {
      // Check building code based on mode (add new location vs edit existing)
      const buildingCode = this.show ? this.selectedBuildingCode : this.location?.building?.code;
      const buildingId = this.show ? this.building?.buildingId : this.location?.building?.buildingId;
      
      if (!buildingCode || !buildingId) {
        this.invalidBuildingCode = true;
        
        // Add validation error
        const buildingCodeMessage = 'No details found';
        validationErrors.push(buildingCodeMessage);
        
        // Display validation error with 700 code array validation message
        this.locationService.updateReturnCode('700');
        this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
        this.locationService.updateReturnMessageArray(validationErrors);
        this.locationService.updateHideMessage(false);
        return;
      }
    }
    
    // 4. Processing Logic
    const floorsToAdd = this.getFloors(this.addFloor);
    
    // Pre-validate all floors before processing
    floorsToAdd.forEach((aFloor) => {
      if (aFloor.length > 4) {
        this.invalidFloorEntry = true;
        const lengthMessage = `Floor number '${aFloor}' exceeds maximum length of 4 characters`;
        // Add to validation errors if not already present
        if (!validationErrors.includes(lengthMessage)) {
          validationErrors.push(lengthMessage);
        }
      }
    });
    
    // If there are validation errors, display them and return
    if (validationErrors.length > 0) {
      this.locationService.updateReturnCode('700');
      this.locationService.updateReturnMessage('Invalid input was detected. Please correct required/invalid fields.');
      this.locationService.updateReturnMessageArray(validationErrors);
      this.locationService.updateHideMessage(false);
      return;
    }
    
    // Clear validation messages if we reach here (all validations passed)
    this.hideMessage = true;
    this.returnMessage = '';
    
    // Check if we're in "add new location" mode (show = true)
    if (this.show) {
      // Adding floors to a NEW location - need to make API calls
      const buildingId = this.building?.buildingId;
      
      if (!buildingId) {
        this.addFloor = '';
        return;
      }

      // 1. GET call - Fetch building info with current floors
      this.locationService.getBuilding(buildingId).subscribe((res: any) => {
        // Get current floors from the building response
        const currentFloors = res.buildingFloors || [];
        const floorsToAddFiltered: any[] = [];
        
        // 2. Process floors to add - check for duplicates (validation already done above)
        const duplicateFloors: string[] = [];
        floorsToAdd.forEach((aFloor) => {
          // Check if floor already exists
          if (!this.duplicateFloor(aFloor, currentFloors)) {
            // Format floor number: single digit becomes "0X" (e.g., "1" -> "01")
            let formattedFloor = aFloor.toUpperCase();
            if (/^\d$/.test(formattedFloor)) {
              formattedFloor = '0' + formattedFloor;
            }
            
            const floorDetail1: any = {
              buildingFloorId: 0,
              floorNumber: formattedFloor,
              buildingId: buildingId,
              lifecycle: {
                beginDate: this.floorStartDate ? new Date(this.floorStartDate).toISOString() : this.setTodaysDate(),
                endDate: null
              }
            };
            floorsToAddFiltered.push(floorDetail1);
          } else {
            // Format floor number for display
            let displayFloor = aFloor.toUpperCase();
            if (/^\d$/.test(displayFloor)) {
              displayFloor = '0' + displayFloor;
            }
            duplicateFloors.push(displayFloor);
          }
        });

        // If there are duplicate floors, show error and return
        if (duplicateFloors.length > 0) {
          const floorList = duplicateFloors.join(', ');
          this.locationService.updateReturnCode(400);
          this.locationService.updateReturnMessage(`Add floor failed: ${floorList} already exists`);
          this.locationService.updateReturnMessageArray([]);
          this.locationService.updateHideMessage(false);
          this.addFloor = '';
          return;
        }

        // If no valid floors to add, return early
        if (floorsToAddFiltered.length === 0) {
          return;
        }

        // 3. Add new floors to the building's floor list
        floorsToAddFiltered.forEach((floor) => {
          currentFloors.push(floor);
        });

        // Ensure all floors have endDate: null if not present
        currentFloors.forEach((f: any) => {
          if (!f.lifecycle.endDate) {
            f.lifecycle.endDate = null;
          }
        });

        // Clean the floor list by removing UI-specific properties before sending to API
        res.buildingFloors = currentFloors.map((f: any) => {
          const { isedit, ...cleanFloor } = f;
          return cleanFloor;
        });

        // 4. PUT call - Save the updated building with new floors
        const locNum = res.audit.lockControlNumber;
        this.locationService
          .saveBuildingFloor(res, '/buildings/' + res.buildingId + '?lockControlNumber=' + locNum)
          .subscribe({
            next: (saveRes: any) => {
              // Send success message using direct pattern
              this.locationService.updateReturnCode(200);
              this.locationService.updateReturnMessage('Floor(s) has been successfully added');
              this.locationService.updateReturnMessageArray([]);
              this.locationService.updateHideMessage(false);
              
              // 5. Refresh the floor lists to show updated data
              this.getBuildingFloors(buildingId);
            },
            error: (error) => {
              // Handle error using direct pattern
              const errorMessages: string[] = [];
              let errorMessage = 'An error occurred';
              let statusCode = error?.status || 500;
              
              if (error?.error?.message) {
                errorMessage = error.error.message;
              } else if (error?.message) {
                errorMessage = error.message;
              } else if (typeof error === 'string') {
                errorMessage = error;
              }
              
              const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
              if (duplicateFloorMatch) {
                const floorNumber = duplicateFloorMatch[1];
                errorMessage = `Add floor failed: ${floorNumber} already exists`;
                // For duplicate floor errors, show as simple message (not array)
                this.locationService.updateReturnCode(400);
                this.locationService.updateReturnMessage(errorMessage);
                this.locationService.updateReturnMessageArray([]);
                this.locationService.updateHideMessage(false);
              } else {
                // For other errors, show with array
                errorMessages.push(errorMessage);
                this.locationService.updateReturnCode(statusCode);
                this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
                this.locationService.updateReturnMessageArray(errorMessages);
                this.locationService.updateHideMessage(false);
              }
            },
          });
      });
      
      // Clean up input field
      this.addFloor = '';
      return;
    }

    // ELSE: We're editing an existing location - use buildingFloorList and save to API
    const bid = this.location.building.buildingId;
    if (!bid) {
      this.location.building.buildingId = this.buildingFloorList?.[0]?.buildingId;
    }

    // 1. GET call - Fetch building info with current floors
    this.locationService.getBuilding(this.location.building.buildingId).subscribe((res: any) => {
      // Get current floors from the building response
      const currentFloors = res.buildingFloors || [];
      const floorsToAddFiltered: any[] = [];
      
      // 2. Process floors to add - check for duplicates (validation already done above)
      const duplicateFloors: string[] = [];
      floorsToAdd.forEach((aFloor) => {
        // Check if floor already exists
        if (!this.duplicateFloor(aFloor, currentFloors)) {
          // Format floor number: single digit becomes "0X" (e.g., "1" -> "01")
          let formattedFloor = aFloor.toUpperCase();
          if (/^\d$/.test(formattedFloor)) {
            formattedFloor = '0' + formattedFloor;
          }
          
          const floorDetail1: any = {
            buildingFloorId: 0,
            floorNumber: formattedFloor,
            buildingId: this.location.building.buildingId,
            lifecycle: {
              beginDate: this.floorStartDate ? new Date(this.floorStartDate).toISOString() : this.setTodaysDate(),
              endDate: null
            }
          };
          floorsToAddFiltered.push(floorDetail1);
        } else {
          // Format floor number for display
          let displayFloor = aFloor.toUpperCase();
          if (/^\d$/.test(displayFloor)) {
            displayFloor = '0' + displayFloor;
          }
          duplicateFloors.push(displayFloor);
        }
      });

      // If there are duplicate floors, show error and return
      if (duplicateFloors.length > 0) {
        const floorList = duplicateFloors.join(', ');
        this.locationService.updateReturnCode(400);
        this.locationService.updateReturnMessage(`Add floor failed: ${floorList} already exists`);
        this.locationService.updateReturnMessageArray([]);
        this.locationService.updateHideMessage(false);
        this.addFloor = '';
        return;
      }

      // If no valid floors to add, return early
      if (floorsToAddFiltered.length === 0) {
        return;
      }

      // 3. Add new floors to the building's floor list
      floorsToAddFiltered.forEach((floor) => {
        currentFloors.push(floor);
      });

      // Ensure all floors have endDate: null if not present (matching legacy behavior)
      // currentFloors.forEach((f: any) => {
      //   if (!f.lifecycle.endDate) {
      //     f.lifecycle.endDate = null;
      //   }
      // });

      // Clean the floor list by removing UI-specific properties before sending to API
      res.buildingFloors = currentFloors.map((f: any) => {
        const { isedit, ...cleanFloor } = f;
        return cleanFloor;
      });

      // 4. PUT call - Save the updated building with new floors
      const locNum = res.audit.lockControlNumber;
      this.locationService
        .saveBuildingFloor(res, '/buildings/' + res.buildingId + '?lockControlNumber=' + locNum)
        .subscribe({
          next: (saveRes: any) => {
            // Send success message using direct pattern
            this.locationService.updateReturnCode(200);
            this.locationService.updateReturnMessage('Floor(s) has been successfully added');
            this.locationService.updateReturnMessageArray([]);
            this.locationService.updateHideMessage(false);
            
            // 5. Refresh the floor list to show updated data
            this.getBuildingFloors(this.location.building.buildingId);
          },
          error: (error) => {
            // Handle error using direct pattern
            const errorMessages: string[] = [];
            let errorMessage = 'An error occurred';
            let statusCode = error?.status || 500;
            
            if (error?.error?.message) {
              errorMessage = error.error.message;
            } else if (error?.message) {
              errorMessage = error.message;
            } else if (typeof error === 'string') {
              errorMessage = error;
            }
            
            const duplicateFloorMatch = errorMessage.match(/Duplicate floor\s*:\s*(\S+)/i);
            if (duplicateFloorMatch) {
              const floorNumber = duplicateFloorMatch[1];
              errorMessage = `Add floor failed: ${floorNumber} already exists`;
              // For duplicate floor errors, show as simple message (not array)
              this.locationService.updateReturnCode(400);
              this.locationService.updateReturnMessage(errorMessage);
              this.locationService.updateReturnMessageArray([]);
              this.locationService.updateHideMessage(false);
            } else {
              // For other errors, show with array
              errorMessages.push(errorMessage);
              this.locationService.updateReturnCode(statusCode);
              this.locationService.updateReturnMessage('An error occurred. Please review the errors below.');
              this.locationService.updateReturnMessageArray(errorMessages);
              this.locationService.updateHideMessage(false);
            }
          },
        });
    });
    
    // 5. Clean up input field
    this.addFloor = '';
  }

  // Placeholder function for the 'invalidFloorDates' check which was external in AngularJS
  private isValidFloorDates(): boolean {
    // Implement your actual validation logic here
    if (!this.floorStartDate) {
      this.invalidFloorStartDate = true;
      return false;
    }
    return true;
  }

  public getCurrentDate(): string {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${month}/${day}/${year}`;
  }

  public setwindowtotop(): void {
    window.scrollTo(0, 0);
  }

  // Handler for floor date changes to prevent ExpressionChangedAfterItHasBeenCheckedError
  onFloorDateChanged(floor: any, newDate: any): void {
    setTimeout(() => {
      floor.lifecycle.beginDate = newDate;
      this.cdr.markForCheck();
    }, 0);
  }
}


