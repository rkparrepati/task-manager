import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-reactivate-location-confirm-dialog',
  templateUrl: './reactivate-location-confirm-dialog.component.html',
  styleUrls: ['./reactivate-location-confirm-dialog.component.scss'],
})
export class ReactivateLocationConfirmDialogComponent {
  location: any;

  constructor(
    public dialogRef: MatDialogRef<ReactivateLocationConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.location = data.location;
  }

  onCancel(): void {
    this.dialogRef.close(false); // Closes and returns false
  }

  onConfirm(): void {
    this.dialogRef.close(true); // Closes and returns true
  }
}
