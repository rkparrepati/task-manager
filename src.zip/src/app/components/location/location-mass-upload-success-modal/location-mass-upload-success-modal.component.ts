import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-location-mass-upload-success-modal',
  templateUrl: './location-mass-upload-success-modal.component.html',
  styleUrls: ['./location-mass-upload-success-modal.component.scss'],
})
export class LocationMassUploadSuccessModalComponent {
  data: any = inject(MAT_DIALOG_DATA);
  constructor(private dialogRef: MatDialogRef<LocationMassUploadSuccessModalComponent>) {}

  confirm() {
    this.dialogRef.close(true);
  }
}
