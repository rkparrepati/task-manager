import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { LocationDialogData } from 'src/app/shared/interfaces/models';

@Component({
  selector: 'app-location-delete-confirm',
  templateUrl: './location-delete-confirm.component.html',
  styleUrls: ['./location-delete-confirm.component.scss'],
})
export class LocationDeleteConfirmComponent {
  constructor(
    public dialogRef: MatDialogRef<LocationDeleteConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: LocationDialogData
  ) {}

  // Handles closing the dialog when Cancel is clicked
  closeThisDialog(resultData: LocationDialogData): void {
    // Pass back data, typically indicating the action was cancelled or providing context
    this.dialogRef.close('cancel');
  }

  // Handles closing the dialog when Delete is clicked
  confirm(resultData: LocationDialogData): void {
    // Pass back data, typically indicating the action was confirmed
    this.dialogRef.close('confirm');
    // You might also pass back the 'data' object itself: this.dialogRef.close(resultData);
  }
}
