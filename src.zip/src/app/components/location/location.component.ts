import { Component, ViewChild, ElementRef, OnChanges, OnDestroy, OnInit } from '@angular/core';

import { AppService } from 'src/app/services/app.service';
import { HttpService } from 'src/app/services/http.service';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { LocationService } from './location.service';
import { MatDialog } from '@angular/material/dialog';
import { LocationSelectDialogComponent } from './location-select-dialog/location-select-dialog.component';
import { AdvanceSearchOptions } from 'src/app/shared/interfaces/models';
import { PageEvent } from '@angular/material/paginator';
import { Subscription } from 'rxjs';
import { AdvancedLocationSearchComponent } from './advanced-location-search/advanced-location-search.component';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss'],
})
export class LocationComponent implements OnInit, OnDestroy {
  @ViewChild(AdvancedLocationSearchComponent) advancedSearchComponent!: AdvancedLocationSearchComponent;
  
  selectedIds: number[] = [];
  public workerRecords: any = { meta: {}, results: [] };
  disabledCheckboxes: boolean = false;
  location: any = { selected: false };
  std: any = { selected: true };
  
  // Track if we're using advanced search
  isAdvancedSearch: boolean = false;

  // Toast message properties for app-acme-navbar-component (following transfer-search pattern)
  main = { creationDate: new Date() };
  moduleName = 'Location Management';
  returnCode: string | number = '';
  returnMessage: string = '';
  accessDenied: boolean = false;
  resetTimeout: boolean = false;
  canUserInactivate(): boolean {
    return this.userRoles.includes('InfraAdmin') || this.userRoles.includes('InfraLocationAdmin');
  }

  /**
   * The method called when the "Inactivate" button is clicked.
   */
  inactivateAllLocation(): void {
    this.locationService.triggerInactivate();
    // if (this.selectedIds.length > 0) {
    //  
    //   // Call your service method here:
    //   // this.locationService.inactivate(this.selectedIds).subscribe(...)
    // } else {
    //   
    // }
  }

  displayMessage: string = '';

  // Reference to the message element in the HTML
  @ViewChild('messageContainer') messageElement!: ElementRef;

  handleMessage(msg: string) {
    this.displayMessage = msg;

    // Use setTimeout to ensure the element is rendered by *ngIf before focusing
    setTimeout(() => {
      if (this.messageElement) {
        this.messageElement.nativeElement.focus();
      }
    }, 0);
  }

  disableShowRadioButton: any;
  showType: any = 'active';
  searchResultsCount: any;
  showWait: any;
  savedSearchCriteria: any;
  activeWorker: any;
  basicSearch: any;
  sortColumn: any;
  userRoles: any = ['InfraAdmin', 'InfraOfficeCoordinator', 'InfraContractorAdmin'];
  isContractor: boolean = false;
  canAdd: boolean = true;
  workerModel: any = { workerList: [] };
  WorkerSearchService: any;
  sortDirection: any;
  buildBasicWorkerSearchExportQuery: any;
  applicationType: any;
  total: number = 0;
  searchMsg: any;
  workerEmploymentType: any;
  showWaitWorkerSearch: any;
  addWorkerButton: any;
  applicationTypeLowerCase: any = 'worker';
  loadingMessage: any;
  appTitle: string = 'Location Management';
  buildAdvancedWorkerSearchExportQueryParamOne: any;
  otherSearchView: string = 'advanced';
  locationParams: string = '';
  subscription: Subscription = new Subscription();
  
  // Pagination properties
  currentPage: number = 1;
  pageSize: number = 10;
  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private localStorageService: LocalStorageService,
    public locationService: LocationService,
    private dialog: MatDialog
  ) {}
  ngOnDestroy(): void {
    //throw new Error('Method not implemented.');

    this.subscription.unsubscribe();
  }

  hideMessage: boolean = true;

  ngOnInit() {
    // Subscribe to message observables for ACME navbar component
    this.locationService.hideMessage$.subscribe((val) => {
      this.hideMessage = val;
    });

    this.locationService.returnMessage$.subscribe((msg) => {
      this.returnMessage = msg;
    });

    this.locationService.returnCode$.subscribe((code) => {
      this.returnCode = code;
    });

    // Flush/clear grid data and total results for child components
    this.total = 0;
    this.searchMsg = `<b> 0</b> locations were found`;
    this.workerRecords = { meta: {}, results: [] };
    
    // Emit empty data to flush child components that are subscribing
    this.locationService.sendData({ meta: {}, results: [] }, {});
    
    // Single subscription to handle data from service
    this.subscription = this.locationService.getData().subscribe((data) => {
      if (data) {
        // Check if data has meta information (full response object)
        if (data.meta && data.results !== undefined) {
          // Use meta.total for accurate count
          this.total = data.meta.total;
          this.searchMsg = data.meta.total + ` locations were found`;
          // Set workerRecords with the full response object for the grid
          // Create new object reference to trigger change detection
          this.workerRecords = {
            meta: { ...data.meta },
            results: data.results || []
          };
        }
      } else {
        this.total = this.workerRecords.length || 0;
        this.searchMsg = `0 locations were found`;
        this.workerRecords = { meta: {}, results: [] };
      }
    });

    this.subscription.add(
      this.locationService.getParams().subscribe((data) => {
        this.locationParams = data;
      })
    );
    
    // Subscribe to refresh search trigger from grid component
    this.subscription.add(
      this.locationService.refreshSearch$.subscribe((message) => {
        if (message) {
          // Re-execute the last search to refresh data
          if (this.isAdvancedSearch && this.advancedSearchComponent) {
            const skip = (this.currentPage - 1) * this.pageSize;
            this.advancedSearchComponent.executeLocationSearch(this.pageSize, skip);
          } else if (this.selectedData) {
            this.searchWorker();
          } else if (this.locationParams) {
            // If we have locationParams but no selectedData, use the params directly
            const skip = (this.currentPage - 1) * this.pageSize;
            const includeInactive = this.showType === 'active' ? false : true;
            this.locationService
              .getLocations(includeInactive, '', this.locationParams, false, this.pageSize, skip)
              .subscribe(
                (response) => {
                  this.locationService.sendData(response, this.locationParams);
                }
              );
          }
        }
      })
    );
  }

  toggleSearchView() {
    if (this.otherSearchView === 'basic') {
      this.otherSearchView = 'advanced';
    } else {
      this.otherSearchView = 'basic';
    }
  }

  callBack(event: any) {
    // Callback for navbar component events
  }
  buildAdvancedWorkerSearchExportQueryParamTwo(savedSearchCriteria: any, url: any) {
    url += savedSearchCriteria.classCode.description
      ? '&' + savedSearchCriteria.classCode.value + '=' + savedSearchCriteria.classCode.description
      : '';
    url += savedSearchCriteria.firmName.description
      ? '&' + savedSearchCriteria.firmName.value + '=' + savedSearchCriteria.firmName.description
      : '';
    url += savedSearchCriteria.firmAdministrator.description
      ? '&' +
        savedSearchCriteria.firmAdministrator.value +
        '=' +
        savedSearchCriteria.firmAdministrator.description
      : '';
    url += savedSearchCriteria.businessAreaCode.description
      ? '&' +
        savedSearchCriteria.businessAreaCode.value +
        '=' +
        savedSearchCriteria.businessAreaCode.description
      : '';
    url += savedSearchCriteria.shortName.description
      ? '&' + savedSearchCriteria.shortName.value + '=' + savedSearchCriteria.shortName.description
      : '';
    if (!savedSearchCriteria.allFirms) {
      url += savedSearchCriteria.loginWorkerNumber.description
        ? '&' +
          savedSearchCriteria.loginWorkerNumber.value +
          '=' +
          savedSearchCriteria.loginWorkerNumber.description
        : '';
      url += savedSearchCriteria.workerAssociatedFirms.description
        ? '&' +
          savedSearchCriteria.workerAssociatedFirms.value +
          '=' +
          savedSearchCriteria.workerAssociatedFirms.description
        : '';
    }
    url += savedSearchCriteria.buildingCode.description
      ? '&' +
        savedSearchCriteria.buildingCode.value +
        '=' +
        savedSearchCriteria.buildingCode.description
      : '';
    url += savedSearchCriteria.floorNumber.description
      ? '&' +
        savedSearchCriteria.floorNumber.value +
        '=' +
        savedSearchCriteria.floorNumber.description
      : '';
    url += savedSearchCriteria.corridorId.description
      ? '&' +
        savedSearchCriteria.corridorId.value +
        '=' +
        savedSearchCriteria.corridorId.description
      : '';
    url += savedSearchCriteria.roomId.description
      ? '&' + savedSearchCriteria.roomId.value + '=' + savedSearchCriteria.roomId.description
      : '';
    url += savedSearchCriteria.suiteId.description
      ? '&' + savedSearchCriteria.suiteId.value + '=' + savedSearchCriteria.suiteId.description
      : '';
    url += savedSearchCriteria.zoneId.description
      ? '&' + savedSearchCriteria.zoneId.value + '=' + savedSearchCriteria.zoneId.description
      : '';
    url += savedSearchCriteria.phoneNumber.description
      ? '&' +
        savedSearchCriteria.phoneNumber.value +
        '=' +
        savedSearchCriteria.phoneNumber.description
      : '';
    return url;
  }
  workerAdd(isTrademarkWorker: boolean = false) {
    this.localStorageService.removeItem('isTrademarkWorker');
    isTrademarkWorker = isTrademarkWorker || false;
    this.localStorageService.setItem('isTrademarkWorker', isTrademarkWorker.toString());
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/app/add-worker/contractor');
    } else {
      this.appService.changePage('/app/add-worker/worker');
    }
  }
  employeeStatus() {
    // ngDialog.openConfirm({
    //     template: 'app/location/multiWorkerStatus.html',
    //     controller: 'MultiWorkerStatusDialogController',
    //     data: null,
    //     controllerAs: 'vm'
    // }).then(function (workersList) {
    //     if (workersList.length) {
    //         vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilitiesService.exportTableServicePOST(url, 'WorkerStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    //     }
    // }, function () {
    // });
  }
  contractorStatus() {
    // ngDialog.openConfirm({
    //     template : 'app/location/multiContractorStatus.html',
    //     controller : 'MultiContractorStatusDialogController',
    //     data : null,
    //     controllerAs : 'vm'
    // // }).then(function(confirmSaveExit) {
    // }).then(function(workersList) {
    //     var promises = [];
    //     vm.loadingMessage = "Exporting Worker data...";
    //         vm.showWait = true;
    //         var url = "workers/statusExcelReport";
    //         UtilitiesService.exportTableServicePOST(url, 'ContractorStatus.xls', 'application/vnd.ms-excel', true, "", workersList);
    // }, function() {
    // });
  }
  public generateReports() {
    const dialogRef = this.dialog.open(LocationSelectDialogComponent, {
      width: '25vw',
      height: '100',
    });

    dialogRef.afterClosed().subscribe((result) => {
      // this.acronym = result.shortName;
    });
  }
  workerAddmultipleContractor() {
    if (this.workerEmploymentType === 'C') {
      this.appService.changePage('/createMultipleContractors/Contractor');
    }
    //  else {
    //     vm.gotoPage("/workerAdd/Worker");
    // }
  }

  private selectedData: any;
  public setActiveWorkerList(showIactive: boolean) {
    this.locationService
      .getLocations(
        this.showType === 'active' ? false : true,
        this.selectedData.searchTex,
        this.selectedData.searchCriteria
      )
      .subscribe((response) => {
        this.workerRecords = response;
      });
  }

  public searchWorkers(data: any): void {
    this.selectedData = data;
    this.currentPage = 1; // Reset to first page on new search
    this.isAdvancedSearch = false; // Mark as basic search
    this.searchWorker();
  }

  /**
   * Execute search with current pagination parameters
   */
  private searchWorker(): void {
    if (!this.selectedData) {
      return;
    }

    const skip = (this.currentPage - 1) * this.pageSize;
    const includeInactive = this.showType === 'active' ? false : true;

    this.locationService
      .getLocations(
        includeInactive,
        this.selectedData.searchText || '',
        this.selectedData.searchCriteria || '',
        false,
        this.pageSize,
        skip
      )
      .subscribe(
        (response) => {
          // Send data through the service to update grid and total count
          this.locationService.sendData(response, this.selectedData.searchCriteria || '');
          
          if (response.results) {
            response.results.forEach((worker: any) => {
              worker.primaryOrganization =
                worker.organizationHistory?.find(
                  (organization: any) => organization.primaryOrganizationIndicator
                ) || {};
              worker.primaryCommunication =
                worker.communicationHistory?.find(
                  (communication: any) => communication.primaryIndicator
                ) || {};
            });
          }
        }
      );
  }

  public handlePageChange(event: PageEvent): void {
    this.currentPage = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    
    // Determine which search method to use
    if (this.isAdvancedSearch && this.advancedSearchComponent) {
      const skip = (this.currentPage - 1) * this.pageSize;
      this.advancedSearchComponent.executeLocationSearch(this.pageSize, skip);
    } else {
      this.searchWorker();
    }
  }

  public onPageChanged(pageNumber: number): void {
    this.currentPage = pageNumber;
    
    // Determine which search method to use
    if ( this.advancedSearchComponent) {
      const skip = (this.currentPage - 1) * this.pageSize;
      this.advancedSearchComponent.executeLocationSearch(this.pageSize, skip);
    } else if (this.selectedData) {
      this.searchWorker();
    }
  }

  public onPageSizeChanged(pageSize: number): void {
    
    this.pageSize = pageSize;
    this.currentPage = 1; // Reset to first page when page size changes
    
    // Determine which search method to use
    if ( this.advancedSearchComponent) {
      this.advancedSearchComponent.executeLocationSearch(this.pageSize, 0);
    } else if (this.selectedData) {
      this.searchWorker();
    }
  }

  public handleAdvanceSearch(data: AdvanceSearchOptions) {
    // Mark that we're using advanced search
    this.isAdvancedSearch = true;
    this.currentPage = 1; // Reset to first page on new search
    
    // Store a minimal selectedData object to prevent undefined errors during pagination
    // This ensures pagination can work even if basic search data isn't available
    this.selectedData = {
      searchText: '',
      searchCriteria: ''
    };
    
    // The advanced search component already makes the API call and sends data via sendData()
    // So we don't need to make another API call here
    // The getData() subscription will handle setting workerRecords
  }
  private url: string = '';
  private buildUrl(data: AdvanceSearchOptions): void {
    let url = '';
    
    if (data.buildingCode?.description) {
      url += `&${data.buildingCode.value}=${data.buildingCode.description}`;
    }

    this.url = url;
    const skip = (this.currentPage - 1) * this.pageSize;
    const includeInactive = this.showType === 'active' ? false : true;
    
    this.locationService
      .getWorkersWithAdvanceSearch(includeInactive, url, this.pageSize, skip)
      .subscribe((response) => {
        this.workerRecords = response;
      });
  }

  exportDataCallback(): void {
    // Determine showAll based on current showType
    const includeInactive = this.showType === 'active' ? false : true;
    
    // Build URL with query parameters - matching transfer-search component format
    const url = `/locations/excelReport?${this.locationParams}&includeInactive=${includeInactive}`;
    
    const fileName = 'Location Management.xls';
    
    // Use HttpService.getExcelReport which handles blob response type
    this.httpService.getExcelReport(url).subscribe({
      next: (data: Blob) => {
        // Check for IE > 10 which has msSaveBlob
        if (window.navigator && (window.navigator as any).msSaveBlob) {
          (window.navigator as any).msSaveBlob(data, fileName);
        } else {
          // For Chrome and other modern browsers
          const blobUrl = URL.createObjectURL(data);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = fileName;
          a.target = '_blank';
          
          // Append to body to ensure it works in Firefox
          document.body.appendChild(a);
          a.click();
          
          // Clean up
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
        }
      },
      error: (error) => {
        // Show error message using service
        this.locationService.sendData(
          `Failed to download Excel report: ${error.error?.message || error.message || 'Unknown error'}`,
          {}
        );
      }
    });
  }
  redirectToMoveContractors() {
    this.appService.changePage('/app/contractor-management/move-contractors');
  }

  onExpandAll(): void {
    this.locationService.expandAllRows();
  }

  onCollapseAll(): void {
    this.locationService.collapseAllRows();
  }
  changeState(state: any) {}

  showLocationImport() {
    this.appService.changePage('/app/location/location-mass-upload');
  }
}
