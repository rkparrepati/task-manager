import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-inactivate-location-confirm-dialog',
  templateUrl: './inactivate-location-confirm-dialog.component.html',
  styleUrls: ['./inactivate-location-confirm-dialog.component.scss'],
})
export class InactivateLocationConfirmDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<InactivateLocationConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  onCancel(): void {
    this.dialogRef.close(false); // Closes and returns false
  }

  onConfirm(): void {
    this.dialogRef.close(true); // Closes and returns true
  }
}
