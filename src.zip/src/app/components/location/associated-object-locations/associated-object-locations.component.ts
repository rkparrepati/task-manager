import { Component, Inject, OnInit } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AppService } from 'src/app/services/app.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { MatSort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { LocationService } from '../location.service';
import {
  BuildingCode,
  BuildingFloor,
  LocationPurpose,
  Building,
  BuildingResults,
  FloorDetail,
  NewLocation,
  Lifecycle,
} from 'src/app/shared/interfaces/models';
import { Subject, Subscription } from 'rxjs';

import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-associated-object-locations',
  templateUrl: './associated-object-locations.component.html',
  styleUrls: ['./associated-object-locations.component.scss'],
})
export class AssociatedObjectLocationsComponent {
  public location: any[];
  public worList: any[] = [];
  public workersList: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<AssociatedObjectLocationsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, // Equivalent to $scope.ngDialogData
    private locationService: LocationService
  ) {
    this.location = data;
  }
  ngOnInit(): void {
    this.fetchAssociatedWorkers();
  }

  onCancel(): void {
    this.dialogRef.close(false); // Closes and returns false
  }

  onConfirm(): void {
    // Uncheck all selected rows in the location grid
    this.uncheckAllSelectedRows();
    this.dialogRef.close(true); // Closes and returns true
  }

  private uncheckAllSelectedRows(): void {
    // Get the current location results from the service
    this.locationService.getData().subscribe((data) => {
      if (data && data.results) {
        // Uncheck all locations by setting isSelected to false
        // Use setTimeout to ensure this happens after dialog closes
        setTimeout(() => {
          data.results.forEach((location: any) => {
            location.isSelected = false;
          });
          // Also reset the master checkbox state
          this.locationService.updateSelectedIds([]);
        }, 0);
      }
    });
  }
  private fetchAssociatedWorkers(): void {
    if (!this.location || !Array.isArray(this.location)) return;

    // Create an array of observables for each location item
    const workerRequests = this.location.map((item) =>
      this.locationService.getAssociatedWorkers(item).subscribe({
        next: (res: any) => {
          //alert('associated workers fetched successfully');
        },
        error: (err) => {
          // alert('error in getting inactive associated locations');        },
      })
    );
  }
}
