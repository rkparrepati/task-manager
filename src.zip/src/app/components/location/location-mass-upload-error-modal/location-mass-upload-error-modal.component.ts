import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
// import { LocationService } from '../components/location/location.service';
// import { LocationMassUploadSuccessModalComponent } from '../components/location/location-mass-upload-success-modal/location-mass-upload-success-modal.component';

import { AppService } from 'src/app/services/app.service';
import { LocationService } from '../location.service';
import { LocationMassUploadSuccessModalComponent } from '../location-mass-upload-success-modal/location-mass-upload-success-modal.component';

@Component({
  selector: 'app-location-mass-upload-error-modal',
  templateUrl: './location-mass-upload-error-modal.component.html',
  styleUrls: ['./location-mass-upload-error-modal.component.scss'],
})
export class LocationMassUploadErrorModalComponent {
  data: any = inject(MAT_DIALOG_DATA);
  dialog = inject(MatDialog);
  constructor(
    private dialogRef: MatDialogRef<LocationMassUploadErrorModalComponent>,
    private locationService: LocationService,
    private appService: AppService
  ) {}
  importTheFile() {}
  ngOnInit() {  }

  showImportDialogSuccess(parsedObject: any) {
    this.appService.changePage('/app/location');
    const successDialogRef = this.dialog.open(LocationMassUploadSuccessModalComponent, {
      width: '90vw',
      height: '75vh',
      data: parsedObject,
    });
    successDialogRef.afterClosed().subscribe((result) => {});
  }

  closeThisDialog() {
    this.dialogRef.close(false);
  }
  confirm() {
    this.dialogRef.close('continue');
  }
}
