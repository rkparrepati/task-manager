import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppComponent } from './app.component';
import { NotificationBannerComponent } from './components/core/notification-banner/notification-banner.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AppComponent, NotificationBannerComponent],
      imports: [
        RouterTestingModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have title set to cedrinfra', () => {
    expect(component.title).toBe('cedrinfra');
  });

  it('should render app-notification-banner component', () => {
    fixture.detectChanges();
    const notificationBanner = fixture.nativeElement.querySelector(
      'app-notification-banner'
    );
    expect(notificationBanner).toBeTruthy();
  });

  it('should render router-outlet', () => {
    fixture.detectChanges();
    const routerOutlet = fixture.nativeElement.querySelector('router-outlet');
    expect(routerOutlet).toBeTruthy();
  });

  it('should have container-fluid div with correct classes', () => {
    fixture.detectChanges();
    const container = fixture.nativeElement.querySelector('.container-fluid');
    expect(container).toBeTruthy();
    expect(container.classList.contains('mt-3')).toBeTruthy();
  });

  it('should call ngOnInit without errors', () => {
    expect(() => {
      component.ngOnInit();
    }).not.toThrow();
  });

  it('should initialize theme on component construction', () => {
    expect(component).toBeTruthy();
    // Theme is set in constructor via setTheme('bs4')
  });
});
