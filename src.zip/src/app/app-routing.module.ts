import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './guards/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { WorkerManagementComponent } from './components/worker-management/worker-management.component';
import { RootComponent } from './components/root/root.component';
import { ContractorManagementComponent } from './components/contractor-management/contractor-management.component';
import { RelocationManagementComponent } from './components/relocation-management/relocation-management.component';
import { AddWorkerComponent } from './components/worker-management/add-worker/add-worker.component';
import { TransferSearchComponent } from './components/transfer-search/transfer-search.component';
import { ActingSPEComponent } from './components/actingspe/actingspe.component';
import { AddMultipleContractorsComponent } from './components/contractor-management/add-multiple-contractors/add-multiple-contractors.component';
import { MoveContractorComponent } from './components/contractor-management/move-contractor/move-contractor.component';
import { ContractorFirmMovementComponent } from './components/worker-management/contractor-firm-movement/contractor-firm-movement.component';
import { CreateMultipleContractorsComponent } from './components/worker-management/create-multiple-contractors/create-multiple-contractors.component';
import { ContractorStatusManagementComponent } from './components/worker-management/contractor-status-management/contractor-status-management.component';
import { MoveEmployeeLocationComponent } from './components/relocation-management/move-employee-location/move-employee-location.component';
import { RelocateWorkerGauComponent } from './components/relocation-management/relocate-worker-gau/relocate-worker-gau.component';
import { RelocateWorkerGauQueueComponent } from './components/relocation-management/relocate-worker-gau-queue/relocate-worker-gau-queue.component';
import { ImportPhoneNumbersComponent } from './components/relocation-management/import-phone-numbers/import-phone-numbers.component';
import { ImportRoleCodeComponent } from './components/relocation-management/import-role-code/import-role-code.component';
import { ReportsComponent } from './components/reports/reports.component';
import { RelocationPlanDetailsComponent } from './components/relocation-management/relocation-plan-details/relocation-plan-details.component';
import { ReportsToComponent } from './components/reports-to/reports-to.component';
import { ApplicationReferenceComponent } from './components/application-reference/application-reference.component';
import { ReportToAssignMutipleComponent } from './components/reportTo/report-to-assign-mutiple/report-to-assign-mutiple.component';
import { BuildingManagementComponent } from './components/building-management/building-management.component';
import { RbacComponent } from './components/rbac/rbac.component';
import { CoordinatorContactInfoComponent } from './components/cordinator-contact-info/coordinator-contact-info.component';
import { FirmAssignmentComponent } from './components/firm-assignment/firm-assignment.component';
import { OrganizationCoordinatorAssignmentComponent } from './components/organization-coordinator-assignment/organization-coordinator-assignment.component';
import { WorkerreportComponent } from './components/worker-management/workerreport/workerreport.component';
import { OrganizationComponent } from './components/organization/organization.component';
import { OktaAuthGuard, OktaCallbackComponent } from '@okta/okta-angular';
import { PalmLocationComponent } from './components/palm-location/palm-location.component';
import { SubclassGAUComponent } from './components/subclass-gau/subclass-gau.component';
import { SiteManagementComponent } from './components/site-management/site-management.component';
import { WorkerRoleManagementComponent } from './components/worker-role-management/worker-role-management.component';
import { HotelingAndLocationComponent } from './components/hoteling-and-location/hoteling-and-location.component';
import { AuditTrailReportComponent } from './components/audit-trail-report/audit-trail-report.component';
import { LocationComponent } from './components/location/location.component';
import { LocationMassUploadComponent } from './components/location-mass-upload/location-mass-upload.component';
import { WorkerOrganizationRoleAssignmentComponent } from './components/worker-organization-role-assignment/worker-organization-role-assignment.component';
import { RegionManagementComponent } from './components/region-management/region-management.component';
import { OrganizationAddUpdateComponent } from './components/organization/organization-add-update/organization-add-update.component';
const routes: Routes = [
  {
    path: 'app',
    component: RootComponent,
    canActivate: [OktaAuthGuard],
    children: [
      {
        path: 'home',
        component: HomeComponent,
      },
      {
        path: 'workerManagement/:applicationType/:status/:workerId',
        component: WorkerManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerManagement/Worker',
        component: WorkerManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'worker-management',
        redirectTo: 'workerManagement/Worker',
        pathMatch: 'full'
      },
      {
        path: 'actingSPE',
        component: ActingSPEComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Acting SPE',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerAdd/:workerType',
        component: AddWorkerComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Add Worker',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerUpdate/:workerId/:workerNumber/:workerType/:type',
        component: AddWorkerComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Update Worker',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerManagement/Contractor',
        component: ContractorManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Contractor Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'transferSearch',
        component: TransferSearchComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'UPSC Challenge Assistance',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'location',
        component: LocationComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Location Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerOrganizationRoleAssignment',
        component: WorkerOrganizationRoleAssignmentComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Organization Role Assignment',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'location/location-mass-upload',
        component: LocationMassUploadComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Location Management',
              url: '/app/location',
              tooltip: 'Go to Location Management',
            },
            {
              title: 'Location Mass Upload',
              url:'/app/location/location-mass-upload',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'reportsTo',
        component: ReportsToComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Reports To',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'actingSPE',
        component: ActingSPEComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Acting SPE',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocation',
        component: RelocationManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },

            {
              title: 'Relocation Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocate-employee-location',
        component: MoveEmployeeLocationComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Import and Execute Employee Location',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocate-employee-gau',
        component: RelocateWorkerGauComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Import and Execute Employee Organization Relocation',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocate-employee-gau-queue',
        component: RelocateWorkerGauQueueComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Import and Execute Employee Organization Relocation',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'auditTrailReport',
        component: AuditTrailReportComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Audit Trail and History View',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'import-phone-numbers',
        component: ImportPhoneNumbersComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Import and assign phone numbers',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'import-role-code',
        component: ImportRoleCodeComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Import and Execute Employee Role Code',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocation-plan-details/:relocationPlanId',
        component: RelocationPlanDetailsComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Plan Details',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'relocation-plan-details/:relocationPlanId/import',
        component: RelocationPlanDetailsComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Relocation Management',
              url: '/app/relocation',
              tooltip: 'Go to Relocation management',
            },
            {
              title: 'Plan Details',
              url: '/app/relocation-plan-details/:relocationPlanId',
              tooltip: 'Go to Plan Details',
            },
            {
              title: 'Import',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'contractor-management/createMultipleContractors/Contractors',
        component: AddMultipleContractorsComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Contractor Management',
              url: '/app/workerManagement/Contractor',
              tooltip: 'Go to Contractor management search',
            },
            {
              title: 'Create Multiple Contractors',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'contractor-management/move-contractors',
        component: MoveContractorComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Contractor Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'worker-management/contractor-firm-movement',
        component: ContractorFirmMovementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Contractor Firm Movement',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'worker-management/create-multiple-contractors',
        component: CreateMultipleContractorsComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Create Multiple Contractors',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'worker-management/contractor-status-management',
        component: ContractorStatusManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Contractor Status Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'applicationReference',
        component: ApplicationReferenceComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Application Reference Data Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'building',
        component: BuildingManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Building Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'accessManagement',
        component: RbacComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'CEDR Role Based Access Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'coordinatorContactInfo',
        component: CoordinatorContactInfoComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Coordinator Contact Information',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'firmAssignment',
        component: FirmAssignmentComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Firm Assignment',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'organizationCoordinator',
        component: OrganizationCoordinatorAssignmentComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Organization Coordinator Assignment',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'organization',
        component: OrganizationComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Organization Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'organization/update/:organizationId',
        component: OrganizationAddUpdateComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Organization Management',
              url: '/app/organization',
              tooltip: 'Go to organization management',
            },
            {
              title: 'Update',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'organization/add/:organizationId',
        component: OrganizationAddUpdateComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Organization Management',
              url: '/app/organization',
              tooltip: 'Go to organization management',
            },
            {
              title: 'Add',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'region',
        component: RegionManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Region Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'palmLocation',
        component: PalmLocationComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'PALM Location Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'workerForms',
        component: WorkerreportComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Management',
              url: '/app/worker-management',
              tooltip: 'Go to Worker management search',
            },
            {
              title: 'Print Multiple Accession/Affidavit Forms',
              isActive: true,
            },
          ],
        },
      }, //WorkerRoleManagementComponent
      {
        path: 'workerRoleManagement',
        component: WorkerRoleManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Worker Role Management',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'site',
        component: SiteManagementComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Site Management',
              isActive: true,
            },
          ],
        },
      },
      //app-site-management
      {
        path: 'subclassGAU',
        component: SubclassGAUComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Subclass GAU and Search Room Assignments',
              isActive: true,
            },
          ],
        },
      },
      {
        path: 'hotelingAndLocation',
        component: HotelingAndLocationComponent,
        data: {
          breadcrumb: [
            {
              title: 'CEDR INFRA Home',
              url: '/app/home',
              tooltip: 'Go to CEDR INFRA home',
            },
            {
              title: 'Location and Hoteling Program Management',
              isActive: true,
            },
          ],
        },
      },
    ],
  },
  {
    path: 'login/oauth2/code/oidc',
    component: OktaCallbackComponent,
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'app-report-to-assign-mutiple',
    component: ReportToAssignMutipleComponent,
  },
  {
    path: '**',
    redirectTo: 'app/home',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
