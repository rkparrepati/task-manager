import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OktaAuthModule, OKTA_CONFIG } from '@okta/okta-angular';
import { OktaAuth } from '@okta/okta-auth-js';
import { environment } from 'src/environments/environment';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { InfraCoordinatorAdminComponent } from './components/infra-coordinator-admin/infra-coordinator-admin.component';
import { HumanResouresToolsComponent } from './components/human-resoures-tools/human-resoures-tools.component';
import { OtherManagementToolsComponent } from './components/other-management-tools/other-management-tools.component';
import { InfraAdminToolsComponent } from './components/infra-admin-tools/infra-admin-tools.component';
import { WorkerManagementComponent } from './components/worker-management/worker-management.component';
import { ActingSPEComponent } from './components/actingspe/actingspe.component';
import { RootComponent } from './components/root/root.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ContractorManagementComponent } from './components/contractor-management/contractor-management.component';
import { RelocationManagementComponent } from './components/relocation-management/relocation-management.component';
import { AdvancedSearchComponent } from './components/worker-management/advanced-search/advanced-search.component';
import { BasicSearchComponent } from './components/worker-management/basic-search/basic-search.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GridComponent } from './components/worker-management/grid/grid.component';
import { ExpandableTableComponent } from './components/transfer-search/expandable-table/expandable-table.component';
import { GridActingSPEComponent } from './components/actingspe/grid-actingspe/grid-actingspe.component';
import { AdvancedSearchActingSPEComponent } from './components/actingspe/advanced-search-actingspe/advanced-search-actingspe.component';
import { BasicSearchActingSPEComponent } from './components/actingspe/basic-search-actingspe/basic-search-actingspe.component';
import { TelephonePipe } from './pipes/telephone.pipe';
import { FilterByPrimaryPipe } from './pipes/filter-by-primary.pipe';
import { AddWorkerComponent } from './components/worker-management/add-worker/add-worker.component';
import { ConfInfoTabComponent } from './components/worker-management/add-worker/conf-info-tab/conf-info-tab.component';
import { SsnConfirmDialogComponent } from './components/worker-management/add-worker/conf-info-tab/ssn-confirm-dialog/ssn-confirm-dialog.component';
import { PrimaryInfoTabComponent } from './components/worker-management/add-worker/primary-info-tab/primary-info-tab.component';
import { DetailsInfoTabComponent } from './components/worker-management/add-worker/details-info-tab/details-info-tab.component';
import { OrgCodeConfirmationDialogComponent } from './components/worker-management/add-worker/org-code-confirmation-dialog/org-code-confirmation-dialog.component';
import { InactivateWorkerConfirmComponent } from './components/worker-management/add-worker/inactivate-worker-confirm/inactivate-worker-confirm.component';
import { WorkerNavbarComponent } from './components/worker-management/add-worker/worker-navbar/worker-navbar.component';
import { SortOrderDirective } from './directives/sort-order.directive';
import { PaginationComponent } from './components/core/pagination/pagination.component';
import { TransferSearchComponent } from './components/transfer-search/transfer-search.component';
import { CreateComponent } from './components/transfer-search/create/create.component';
import { SearchComponent } from './components/transfer-search/search/search.component';
import { ConfirmDialogComponent } from './components/transfer-search/confirm-dialog.component';
import { ConfirmDialogComponent as WorkerConfirmDialogComponent } from './components/worker-management/add-worker/confirm-dialog/confirm-dialog.component';
import { WorkerSearchDialogComponent } from './components/transfer-search/worker-search-dialog/worker-search-dialog.component';
import { ArtClassSearchDialogComponent } from './components/transfer-search/art-class-search-dialog/art-class-search-dialog.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { TabsComponent } from './components/tabs/tabs.component';
import { AcronymInputComponent } from './shared/components/acronym-input/acronym-input.component';
import { AppComponent } from './app.component';
import { BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { OrganizationSelectTreeDialogComponent } from './shared/components/organization-select-tree-dialog/organization-select-tree-dialog.component';
import { MatTreeModule } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { UpdateDialogComponent } from './components/transfer-search/update-dialog.component';
import { AccessionSelectDialogComponent } from './components/worker-management/accession-select-dialog/accession-select-dialog.component';
import { IMaskModule } from 'angular-imask';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatMenuModule } from '@angular/material/menu';
import { ContractorBasicSearchComponent } from './components/contractor-management/contractor-basic-search/contractor-basic-search.component';
import { ContractorAdvancedSearchComponent } from './components/contractor-management/contractor-advance-search/contractor-advance-search.component';
import { ContractorGridComponent } from './components/contractor-management/contractor-grid/contractor-grid.component';
import { ContractorStatusDialogComponent } from './components/contractor-management/contractor-status-dialog/contractor-status-dialog.component';
import { EmployeeStatusDialogComponent } from './components/worker-management/employee-status-dialog/employee-status-dialog.component';
import { WorkerAssignmentComponent } from './components/worker-management/add-worker/worker-assignment/worker-assignment.component';
import { WorkerOrgLocationAddEditComponent } from './components/worker-management/add-worker/worker-org-location-add-edit/worker-org-location-add-edit.component';
import { AddMultipleContractorsComponent } from './components/contractor-management/add-multiple-contractors/add-multiple-contractors.component';
import { AddMultipleContractorsErrorModalComponent } from './components/contractor-management/add-multiple-contractors-error-modal/add-multiple-contractors-error-modal.component';
import { AddMultipleContractorsSuccessModalComponent } from './components/contractor-management/add-multiple-contractors-success-modal/add-multiple-contractors-success-modal.component';
import { MoveContractorComponent } from './components/contractor-management/move-contractor/move-contractor.component';
import { CommunicationAssignmentComponent } from './components/worker-management/add-worker/communication-assignment/communication-assignment.component';
import { LocationselectDialogComponent } from './components/worker-management/add-worker/locationselect-dialog/locationselect-dialog.component';
import { AssignmentSelectComponent } from './components/worker-management/add-worker/assignment-select/assignment-select.component';
import { PalmLocationLookupComponent } from './components/worker-management/add-worker/palm-location-lookup/palm-location-lookup.component';
import { BreadCrumbComponent } from './components/bread-crumb/bread-crumb.component';
import { RelocationDetailsComponent } from './components/relocation-management/relocation-details/relocation-details.component';
import { RelocationEditComponent } from './components/relocation-management/relocation-edit/relocation-edit.component';
import { MoveEmployeeLocationComponent } from './components/relocation-management/move-employee-location/move-employee-location.component';
import { RelocateWorkerGauComponent } from './components/relocation-management/relocate-worker-gau/relocate-worker-gau.component';
import { ImportPhoneNumbersComponent } from './components/relocation-management/import-phone-numbers/import-phone-numbers.component';
import { ImportRoleCodeComponent } from './components/relocation-management/import-role-code/import-role-code.component';
import { RelocateWorkerGauQueueComponent } from './components/relocation-management/relocate-worker-gau-queue/relocate-worker-gau-queue.component';
import { DialogComponent } from './components/relocation-management/dialog/dialog.component';
import { UploadEmployeeRoleCodeErrorComponent } from './components/relocation-management/upload-employee-role-code-error/upload-employee-role-code-error.component';
import { RelocateWorkerGauImmediateComponent } from './components/relocation-management/relocate-worker-gau-immediate/relocate-worker-gau-immediate.component';
import { RelocationGauAttentionDialogComponent } from './components/relocation-management/relocation-gau-attention-dialog/relocation-gau-attention-dialog.component';
import { MoveEmployeeLocationAttentionDialogComponent } from './components/relocation-management/move-employee-location-attention-dialog/move-employee-location-attention-dialog.component';
import { ImportPhoneNumbersAttentionDialogComponent } from './components/relocation-management/import-phone-numbers-attention-dialog/import-phone-numbers-attention-dialog.component';
import { ImportRoleCodeAttentionDialogComponent } from './components/relocation-management/import-role-code-attention-dialog/import-role-code-attention-dialog.component';
import { ReportsComponent } from './components/reports/reports.component';
import { RelocationPlanDetailsComponent } from './components/relocation-management/relocation-plan-details/relocation-plan-details.component';
import { DataGridComponent } from './components/grid/grid.component';
import { RelocationDeleteConfirmDialogComponent } from './components/relocation-management/relocation-delete-confirm-dialog/relocation-delete-confirm-dialog.component';
import { AddWorkerWizardDialogComponent } from './components/relocation-management/add-worker-wizard-dialog/add-worker-wizard-dialog.component';
import { WorkerPickerComponent } from './components/relocation-management/add-worker-wizard-dialog/worker-picker/worker-picker.component';
import { LocationPickerComponent } from './components/relocation-management/add-worker-wizard-dialog/location-picker/location-picker.component';
import { ReusableGridComponent } from './components/reusable-grid/reusable-grid.component';
import { ReportsToComponent } from './components/reports-to/reports-to.component';
import { ReportsToSearchResultsComponent } from './components/reports-to/reports-to-search-results/reports-to-search-results.component';
import { WaitingForAssignmentComponent as ReportsToWaitingForAssignmentComponent } from './components/reports-to/waiting-for-assignment/waiting-for-assignment.component';
import { HistoryOfManagersComponent } from './components/reports-to/history-of-managers/history-of-managers.component';
import { ReportToAssignMultipleComponent as ReportsToAssignMultipleComponent } from './components/reports-to/report-to-assign-multiple/report-to-assign-multiple.component';
import { WorkerRoleAssignmentComponent } from './components/worker-management/add-worker/worker-role-assignment/worker-role-assignment.component';
import { WorkerOverrideTabComponent } from './components/worker-management/add-worker/worker-override-tab/worker-override-tab.component';
import { CreateWorkerOverrideDialogComponent } from './components/worker-management/add-worker/worker-override-tab/create-worker-override-dialog/create-worker-override-dialog.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatToolbarModule } from '@angular/material/toolbar';
import { ReportTolandingComponent } from './components/reportTo/report-tolanding/report-tolanding.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { PopupComponent } from './components/reportTo/popup/popup/popup.component';
import { ApplicationReferenceComponent } from './components/application-reference/application-reference.component';
import { ReferenceDataTypeFormatPipe } from './components/application-reference/reference-data-type-format.pipe';
import { DatePipe } from '@angular/common';
import { DatePickerComponent } from './shared/components/date-picker/date-picker.component';
import { InactivateBuildingConfirmComponent } from './components/building-management/inactivate-building-confirm/inactivate-building-confirm.component';
import { AssoiatedObjectBuildingComponent } from './components/building-management/assoiated-object-building/assoiated-object-building.component';
import { InactivateFloorConfirmComponent } from './components/building-management/inactivate-floor-confirm/inactivate-floor-confirm.component';
import { AssoiatedObjectFloorComponent } from './components/building-management/assoiated-object-floor/assoiated-object-floor.component';
import { ReactivateBuildingConfirmComponent } from './components/building-management/reactivate-building-confirm/reactivate-building-confirm.component';
import { ReactivateFloorConfirmComponent } from './components/building-management/reactivate-floor-confirm/reactivate-floor-confirm.component';
import { BuildingManagementComponent } from './components/building-management/building-management.component';
import { BuildingInfoComponent } from './components/building-management/building-info/building-info.component';
import { EditBuildingComponent } from './components/building-management/edit-building/edit-building.component';
import { NumbersOnlyDirective } from './directives/numbers-only.directive';
import { ReportToAssignMutipleComponent } from './components/reportTo/report-to-assign-mutiple/report-to-assign-mutiple.component';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';
import { NewFloorComponent } from './components/building-management/new-floor/new-floor.component';
import { EditFloorComponent } from './components/building-management/edit-floor/edit-floor.component';
import { RbacComponent } from './components/rbac/rbac.component';
import { RoleManagementGridComponent } from './components/rbac/role-management-grid/role-management-grid.component';
import { WaitingForAssignmentComponent } from './components/reportTo/waiting-for-assignment/waiting-for-assignment.component';
import { RbacAdvancedSearchComponent } from './components/rbac/rbac-advanced-search/rbac-advanced-search.component';
import { RoleDialogComponent } from './components/rbac/role-dialog/role-dialog.component';
import { HistoryofmanagementComponent } from './components/reportTo/historyofmanagement/historyofmanagement.component';
import { HistoryManagementmodalComponent } from './components/reportTo/history-managementmodal/history-managementmodal.component';
import { CoordinatorContactInfoComponent } from './components/cordinator-contact-info/coordinator-contact-info.component';
import { CoordinatorContactDeleteDialogComponent } from './components/cordinator-contact-info/delete-dialog/coordinator-contact-delete-dialog.component';
import { CoordinatorContactMessageDialogComponent } from './components/cordinator-contact-info/message-dialog/coordinator-contact-message-dialog.component';
import { FirmAssignmentComponent } from './components/firm-assignment/firm-assignment.component';
import { WorkerLookupComponent } from './components/firm-assignment/worker-lookup/worker-lookup.component';
import { OrganizationCoordinatorAssignmentComponent } from './components/organization-coordinator-assignment/organization-coordinator-assignment.component';
import { WorkerreportComponent } from './components/worker-management/workerreport/workerreport.component';
import { WorkerreportPopupComponent } from './components/worker-management/workerreport/workerreport-popup/workerreport-popup.component';
import { ContractorFirmMovementComponent } from './components/worker-management/contractor-firm-movement/contractor-firm-movement.component';
import { CreateMultipleContractorsComponent } from './components/worker-management/create-multiple-contractors/create-multiple-contractors.component';
import { ContractorStatusManagementComponent } from './components/worker-management/contractor-status-management/contractor-status-management.component';
import { AvailableAcronymsComponent } from './components/organization-coordinator-assignment/available-acronyms/available-acronyms.component';
import { AssociatedObjectsOrganizationComponent } from './components/organization/associated-objects-organization/associated-objects-organization.component';
import { OrganizationSelectComponent } from './components/organization/organization-select/organization-select.component';
import { OrganizationAddUpdateComponent } from './components/organization/organization-add-update/organization-add-update.component';
import { OrganizationComponent } from './components/organization/organization.component';
import { OrganisationSelectTreeComponent } from './components/organization/organisation-select-tree/organisation-select-tree.component';
import { OrganizationTreeComponent } from './components/organization/organization-tree/organization-tree.component';
import { PalmLocationComponent } from './components/palm-location/palm-location.component';
import { PalmLocationDetailsComponent } from './components/palm-location/palm-location-details/palm-location-details.component';
import { PalmLocationEditComponent } from './components/palm-location/palm-location-edit/palm-location-edit.component';
import { SubclassGAUComponent } from './components/subclass-gau/subclass-gau.component';
import { SubclassGauSearchResultsComponent } from './components/subclass-gau/subclass-gau-search-results/subclass-gau-search-results.component';
import { ConfirmationDialogComponent } from './components/core/confirmation-dialog/confirmation-dialog.component';
import { NotificationBannerComponent } from './components/core/notification-banner/notification-banner.component';
import { ArtClassSearchWizardComponent } from './components/subclass-gau/art-class-search-wizard/art-class-search-wizard.component';
import { FilterSubclassesDialogComponent } from './components/subclass-gau/filter-subclasses-dialog/filter-subclasses-dialog.component';
import { FilterSearchRoomSubclassesDialogComponent } from './components/subclass-gau/filter-search-room-subclasses-dialog/filter-search-room-subclasses-dialog.component';
import { UpdateDatesWizardComponent } from './components/subclass-gau/update-dates-wizard/update-dates-wizard.component';
import { SiteManagementComponent } from './components/site-management/site-management.component';
import { ManagementComponent } from './shared/components/management/management.component';
import { ManagementDetailsComponent } from './shared/components/management/management-details/management-details.component';
import { ManagementEditComponent } from './shared/components/management/management-edit/management-edit.component';
import { WorkerRoleManagementComponent } from './components/worker-role-management/worker-role-management.component';
import { WorkerRoleManagementDetailsComponent } from './components/worker-role-management/worker-role-management-details/worker-role-management-details.component';
import { WorkerRoleManagementEditComponent } from './components/worker-role-management/worker-role-management-edit/worker-role-management-edit.component';
import { HotelingAndLocationComponent } from './components/hoteling-and-location/hoteling-and-location.component';
import { HotelingSearchComponent } from './components/hoteling-and-location/search/hoteling-search.component';
import { HotelingEditComponent } from './components/hoteling-and-location/edit/hoteling-edit.component';
import { HotelingViewComponent } from './components/hoteling-and-location/view/hoteling-view.component';
import { HotelingAdvanceSearchComponent } from './components/hoteling-and-location/advance-search/advance-search.component';
import { WorkerRoleOrganizationComponent } from './components/worker-role-management/worker-role-organization/worker-role-organization.component';
import { AuditTrailReportComponent } from './components/audit-trail-report/audit-trail-report.component';
import { AcmeNavbarComponentComponent } from './components/audit-trail-report/acme-navbar-component/acme-navbar-component.component';
import { SortButtonComponent } from './components/audit-trail-report/sort-button/sort-button.component';
import { WorkerSelectionDialogComponentComponent } from './components/audit-trail-report/worker-selection-dialog-component/worker-selection-dialog-component.component';
import { LocationComponent } from './components/location/location.component';
import { AdvancedLocationSearchComponent } from './components/location/advanced-location-search/advanced-location-search.component';
import { LocationGridComponent } from './components/location/location-grid/location-grid.component';
import { LocationSelectDialogComponent } from './components/location/location-select-dialog/location-select-dialog.component';
import { LocationMassUploadComponent } from './components/location-mass-upload/location-mass-upload.component';
import { LocationMassUploadSuccessModalComponent } from './components/location/location-mass-upload-success-modal/location-mass-upload-success-modal.component';
import { LocationMassUploadErrorModalComponent } from './components/location/location-mass-upload-error-modal/location-mass-upload-error-modal.component';
import { InactivateLocationConfirmComponent } from './components/location/inactivate-location-confirm/inactivate-location-confirm.component';
import { AssociatedObjectLocationsComponent } from './components/location/associated-object-locations/associated-object-locations.component';
import { LocationDeleteConfirmComponent } from './components/location/location-delete-confirm/location-delete-confirm.component';
import { InactivateLocationConfirmDialogComponent } from './components/location/inactivate-location-confirm-dialog/inactivate-location-confirm-dialog.component';
import { ReactivateLocationConfirmDialogComponent } from './components/location/reactivate-location-confirm-dialog/reactivate-location-confirm-dialog.component';
import { ReactivateOrganizationConfirmDialogComponent } from './components/organization/reactivate-organization-confirm-dialog/reactivate-organization-confirm-dialog.component';
import { WorkerOrganizationRoleAssignmentComponent } from './components/worker-organization-role-assignment/worker-organization-role-assignment.component';
import { AssignRoleComponent } from './components/worker-organization-role-assignment/assign-role/assign-role.component';
import { RegionManagementComponent } from './components/region-management/region-management.component';
import { RegionManagementDetailsComponent } from './components/region-management/region-management-details/region-management-details.component';
import { RegionManagementEditComponent } from './components/region-management/region-management-edit/region-management-edit.component';
import { ErrorMessagesComponent } from './shared/components/error-messages/error-messages.component';
import { OrganizationDialogComponent } from './components/worker-role-management/organization-dialog/organization-dialog.component';
import { UppercaseDirective } from './directives/uppercase.directive';
import { DateFormatDirective } from './directives/date-format.directive';
import { SsnFieldDirective } from './directives/ssn-field.directive';
import { EditCapabilitiesDialogComponent } from './components/actingspe/edit-capabilities-dialog/edit-capabilities-dialog.component';
import { OrderByPipe } from './pipes/orderby.pipe';
import { CommonModule } from '@angular/common';
import { AcronymDirective } from './directives/acronym.directive';
import { ReportsToNewComponent } from './components/reports-to-new/reports-to-new.component';
import { ReportsToSearchResultsNewComponent } from './components/reports-to-new/reports-to-search-results-new/reports-to-search-results-new.component';
import { ReportToAssignMultipleNewComponent } from './components/reports-to-new/report-to-assign-multiple-new/report-to-assign-multiple-new.component';
import { WaitingForAssignmentNewComponent } from './components/reports-to-new/waiting-for-assignment-new/waiting-for-assignment-new.component';
import { HistoryOfManagersNewComponent } from './components/reports-to-new/history-of-managers-new/history-of-managers-new.component';
import { ConfirmDialogComponent as SharedConfirmDialogComponent } from './shared/components/confirm-dialog/confirm-dialog.component';
import { EditAssignmentDialogComponent } from './components/reports-to/edit-assignment-dialog/edit-assignment-dialog.component';
import { WorkerSelectionDialogComponent } from './components/reports-to/worker-selection-dialog/worker-selection-dialog.component';
import { ReassignmentDialogComponent } from './components/reports-to/reassignment-dialog/reassignment-dialog.component';
import { HistoryMngrDialogComponent } from './components/reports-to/history-mngr-dialog/history-mngr-dialog.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';

const oktaAuth = new OktaAuth({
  issuer: environment.okta.issuer,
  clientId: environment.okta.clientId,
  redirectUri: environment.okta.redirectUri,
  postLogoutRedirectUri: environment.okta.postLogoutRedirectUri,
  scopes: environment.okta.scopes,
  responseType: 'code',
  pkce: true,
  tokenManager: {
    autoRenew: true,
    secure: true,
  },
});
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    TransferSearchComponent,
    SearchComponent,
    CreateComponent,
    WorkerSearchDialogComponent,
    ArtClassSearchDialogComponent,
    TabsComponent,
    InfraCoordinatorAdminComponent,
    HumanResouresToolsComponent,
    OtherManagementToolsComponent,
    InfraAdminToolsComponent,
    WorkerManagementComponent,
    ActingSPEComponent,
    RootComponent,
    NavbarComponent,
    ContractorManagementComponent,
    RelocationManagementComponent,
    AdvancedSearchComponent,
    BasicSearchComponent,
    GridComponent,
    AdvancedSearchActingSPEComponent,
    BasicSearchActingSPEComponent,
    GridActingSPEComponent,
    TelephonePipe,
    FilterByPrimaryPipe,
    AddWorkerComponent,
    ConfInfoTabComponent,
    SsnConfirmDialogComponent,
    PrimaryInfoTabComponent,
    DetailsInfoTabComponent,
    OrgCodeConfirmationDialogComponent,
    InactivateWorkerConfirmComponent,
    UpdateDialogComponent,
    ConfirmDialogComponent,
    WorkerConfirmDialogComponent,
    WorkerNavbarComponent,
    SortOrderDirective,
    PaginationComponent,
    AcronymInputComponent,
    OrganizationSelectTreeDialogComponent,
    AccessionSelectDialogComponent,
    ContractorBasicSearchComponent,
    ContractorAdvancedSearchComponent,
    ContractorGridComponent,
    ContractorStatusDialogComponent,
    EmployeeStatusDialogComponent,
    WorkerAssignmentComponent,
    WorkerOrgLocationAddEditComponent,
    AddMultipleContractorsComponent,
    AddMultipleContractorsErrorModalComponent,
    AddMultipleContractorsSuccessModalComponent,
    MoveContractorComponent,
    CommunicationAssignmentComponent,
    LocationselectDialogComponent,
    AssignmentSelectComponent,
    PalmLocationLookupComponent,
    BreadCrumbComponent,
    RelocationDetailsComponent,
    RelocationEditComponent,
    MoveEmployeeLocationComponent,
    RelocateWorkerGauComponent,
    ImportPhoneNumbersComponent,
    ImportRoleCodeComponent,
    RelocateWorkerGauQueueComponent,
    DialogComponent,
    UploadEmployeeRoleCodeErrorComponent,
    RelocateWorkerGauImmediateComponent,
    RelocationGauAttentionDialogComponent,
    MoveEmployeeLocationAttentionDialogComponent,
    ImportPhoneNumbersAttentionDialogComponent,
    ImportRoleCodeAttentionDialogComponent,
    ReportsComponent,
    RelocationPlanDetailsComponent,
    DataGridComponent,
    RelocationDeleteConfirmDialogComponent,
    AddWorkerWizardDialogComponent,
    WorkerPickerComponent,
    LocationPickerComponent,
    ReusableGridComponent,
    ReportsToComponent,
    ReportsToSearchResultsComponent,
    ReportsToWaitingForAssignmentComponent,
    HistoryOfManagersComponent,
    ReportsToAssignMultipleComponent,
    WorkerRoleAssignmentComponent,
    WorkerOverrideTabComponent,
    CreateWorkerOverrideDialogComponent,
    ReportTolandingComponent,
    PopupComponent,
    ApplicationReferenceComponent,
    ReferenceDataTypeFormatPipe,
    DatePickerComponent,
    InactivateBuildingConfirmComponent,
    AssoiatedObjectBuildingComponent,
    InactivateFloorConfirmComponent,
    AssoiatedObjectFloorComponent,
    ReactivateBuildingConfirmComponent,
    ReactivateFloorConfirmComponent,
    BuildingManagementComponent,
    BuildingInfoComponent,
    EditBuildingComponent,
    NumbersOnlyDirective,
    ReportToAssignMutipleComponent,
    NewFloorComponent,
    EditFloorComponent,
    RbacComponent,
    RoleManagementGridComponent,
    WaitingForAssignmentComponent,
    RbacAdvancedSearchComponent,
    RoleDialogComponent,
    HistoryofmanagementComponent,
    HistoryManagementmodalComponent,
    CoordinatorContactInfoComponent,
    CoordinatorContactDeleteDialogComponent,
    CoordinatorContactMessageDialogComponent,
    FirmAssignmentComponent,
    WorkerLookupComponent,
    OrganizationCoordinatorAssignmentComponent,
    WorkerreportComponent,
    WorkerreportPopupComponent,
    OrganizationCoordinatorAssignmentComponent,
    WorkerreportComponent,
    ContractorFirmMovementComponent,
    CreateMultipleContractorsComponent,
    ContractorStatusManagementComponent,
    AvailableAcronymsComponent,
    OrganizationComponent,
    OrganizationAddUpdateComponent,
    OrganizationSelectComponent,
    AssociatedObjectsOrganizationComponent,
    OrganisationSelectTreeComponent,
    OrganizationTreeComponent,
    PalmLocationComponent,
    PalmLocationDetailsComponent,
    PalmLocationEditComponent,
    RegionManagementComponent,
    RegionManagementDetailsComponent,
    SubclassGAUComponent,
    SubclassGauSearchResultsComponent,
    ConfirmationDialogComponent,
    NotificationBannerComponent,
    RegionManagementEditComponent,
    ArtClassSearchWizardComponent,
    FilterSubclassesDialogComponent,
    FilterSearchRoomSubclassesDialogComponent,
    UpdateDatesWizardComponent,
    SiteManagementComponent,
    ManagementComponent,
    ManagementDetailsComponent,
    ManagementEditComponent,
    WorkerRoleManagementComponent,
    WorkerRoleManagementDetailsComponent,
    WorkerRoleManagementEditComponent,
    HotelingAndLocationComponent,
    HotelingSearchComponent,
    HotelingEditComponent,
    HotelingViewComponent,
    HotelingAdvanceSearchComponent,
    WorkerRoleOrganizationComponent,
    ExpandableTableComponent,
    LocationComponent,
    AdvancedLocationSearchComponent,
    LocationGridComponent,
    LocationSelectDialogComponent,
    LocationMassUploadComponent,
    LocationMassUploadSuccessModalComponent,
    LocationMassUploadErrorModalComponent,
    InactivateLocationConfirmComponent,
    AssociatedObjectLocationsComponent,
    LocationDeleteConfirmComponent,
    InactivateLocationConfirmDialogComponent,
    ReactivateLocationConfirmDialogComponent,
    ReactivateOrganizationConfirmDialogComponent,
    WorkerOrganizationRoleAssignmentComponent,
    AssignRoleComponent,
    AuditTrailReportComponent,
    AcmeNavbarComponentComponent,
    SortButtonComponent,
    WorkerSelectionDialogComponentComponent,
    ErrorMessagesComponent,
    OrganizationDialogComponent,
    EditCapabilitiesDialogComponent,
    UppercaseDirective,
    DateFormatDirective,
    SsnFieldDirective,
       OrderByPipe,
       AcronymDirective,
       ReportsToNewComponent,
       ReportsToSearchResultsNewComponent,
       ReportToAssignMultipleNewComponent,
       WaitingForAssignmentNewComponent,
       HistoryOfManagersNewComponent,
       SharedConfirmDialogComponent,
       EditAssignmentDialogComponent,
       WorkerSelectionDialogComponent,
       ReassignmentDialogComponent,
       HistoryMngrDialogComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    DragDropModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    AccordionModule.forRoot(),
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    TypeaheadModule.forRoot(),
    MatDialogModule,
    MatTableModule,
    MatTreeModule,
    MatIconModule,
    MatListModule,
    MatTooltipModule,
    MatExpansionModule,
    MatPaginatorModule,
    MatSidenavModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatStepperModule,
    MatSortModule,
    MatMenuModule,
    IMaskModule,
    MatSnackBarModule,
    OktaAuthModule.forRoot({ oktaAuth }),
   ],
  exports: [MatSidenavModule, MatToolbarModule, DragDropModule],
  providers: [
    BsModalService,
    {
      provide: OKTA_CONFIG,
      useValue: { oktaAuth },
    },
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    //{ provide: OAuthStorage, useValue: localStorage },
    DatePipe,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
