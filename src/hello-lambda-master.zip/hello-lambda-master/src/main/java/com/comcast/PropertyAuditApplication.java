package com.comcast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PropertyAuditApplication {
    public static void main(String[] args) {
        SpringApplication.run(PropertyAuditApplication.class, args);
    }
}