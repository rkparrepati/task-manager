package com.example;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.example.service.*;
import com.example.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class HelloWorldFunction implements RequestHandler<Map<String, Object>, String> {

    private static final Logger LOG = LoggerFactory.getLogger(HelloWorldFunction.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    private final SecretService secretService = new SecretService();
    private final TokenService tokenService = new TokenService();
    private final PropertyService propertyService = new PropertyService();
    private final DataProcessingService dataProcessingService = new DataProcessingService();
    private final JsonService jsonService = new JsonService();

    @Override
    public String handleRequest(Map<String, Object> event, Context context) {
        try {
            TokenService.clearCache();

            String region = System.getenv("REGION_NAME");
            String secretName = System.getenv("SECRET_NAME");

            if (region == null || secretName == null) {
                LOG.error("REGION_NAME or SECRET_NAME missing from env");
                return createErrorResponse("Missing environment variables");
            }

            Map<String, Object> secret = secretService.getSecret(secretName, region);
            String propertyVendorId = (String) event.get("property_vendor_id");

            if (propertyVendorId == null) {
                LOG.error("property_vendor_id not provided");
                return createErrorResponse("property_vendor_id not provided");
            }

            PropertyInfo propertyInfo = propertyService.getPropertyInfo(propertyVendorId, secret);
            LOG.info("Property name: {}", propertyInfo.getName());

            List<Map<String, Object>> unitsList = propertyService.getUnitsFromProperty(propertyVendorId, secret);
            if (unitsList == null || unitsList.isEmpty()) {
                LOG.error("Invalid property vendor ID or units_list not returned");
                return createErrorResponse("No units found");
            }

            // Get all tokens
            String elocToken = tokenService.getElocToken(secret);
            String ftnsToken = tokenService.getFtsToken(secret);
            String entToken = tokenService.getEntToken(secret);
            String xrayToken = tokenService.getXrayToken(secret);
            String rpilToken = tokenService.getRpilToken(secret);
            String odpToken = tokenService.getOdpToken(secret);

            LOG.info("Starting async processing for {} units", unitsList.size());

            // Process data asynchronously
            CompletableFuture<List<Map<String, Object>>> unitsFuture = dataProcessingService
                    .processUnitsAsync(unitsList, elocToken, ftnsToken, secret);

            List<Map<String, Object>> processedUnits = unitsFuture.get();

            CompletableFuture<List<Map<String, Object>>> entFuture = dataProcessingService
                    .processResultAsync(processedUnits, entToken, secret);

            List<Map<String, Object>> entProcessed = entFuture.get();

            CompletableFuture<List<Map<String, Object>>> xrayFuture = dataProcessingService.processXrayAsync(
                    entProcessed, xrayToken, rpilToken,
                    propertyInfo.getAmenitySSID(), unitsList, odpToken, secret);

            List<Map<String, Object>> finalList = xrayFuture.get();

            jsonService.saveToJson(finalList, propertyInfo.getName());

            return createSuccessResponse("Processing completed successfully", finalList, propertyInfo.getName());

        } catch (Exception e) {
            LOG.error("Error processing request", e);
            return createErrorResponse(e.getMessage());
        }
    }

    private String createSuccessResponse(String message, List<Map<String, Object>> data, String propertyName) {
        try {
            ApiResponse response = ApiResponse.success(message, data, propertyName);
            return objectMapper.writeValueAsString(response);
        } catch (Exception e) {
            LOG.error("Failed to create success response", e);
            return "{\"status\":\"error\",\"message\":\"Failed to serialize response\"}";
        }
    }

    private String createErrorResponse(String error) {
        try {
            ApiResponse response = ApiResponse.error(error);
            return objectMapper.writeValueAsString(response);
        } catch (Exception e) {
            LOG.error("Failed to create error response", e);
            return "{\"status\":\"error\",\"message\":\"" + error + "\"}";
        }
    }
}
