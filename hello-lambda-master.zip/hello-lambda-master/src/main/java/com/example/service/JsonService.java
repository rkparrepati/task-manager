package com.example.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class JsonService {
    private static final Logger LOG = LoggerFactory.getLogger(JsonService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    public void saveToJson(List<Map<String, Object>> dataList, String propertyName) {
        if (dataList == null || dataList.isEmpty()) {
            LOG.info("No data to write.");
            return;
        }

        String filename = "/tmp/" + propertyName + "_Audit.json";

        try {
            // Write JSON to local file
            String jsonContent = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(dataList);

            try (FileWriter writer = new FileWriter(filename)) {
                writer.write(jsonContent);
            }

            LOG.info("JSON file created: '{}'", filename);

            // Upload to S3
            uploadToS3(jsonContent, propertyName);

            // Clean up local file
            new File(filename).delete();

        } catch (IOException e) {
            LOG.error("Failed to create JSON file", e);
        }
    }

    private void uploadToS3(String jsonContent, String propertyName) {
        String s3Bucket = System.getenv("Bucket");
        String s3Prefix = System.getenv("Bucket_prefix");

        if (s3Bucket == null || s3Prefix == null) {
            LOG.warn("S3 bucket or prefix not configured, skipping upload");
            return;
        }

        String s3Key = s3Prefix + propertyName + "_Audit.json";

        try {
            AmazonS3 s3Client = AmazonS3ClientBuilder.defaultClient();

            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType("application/json");
            metadata.setContentLength(jsonContent.getBytes().length);

            ByteArrayInputStream inputStream = new ByteArrayInputStream(jsonContent.getBytes());
            s3Client.putObject(s3Bucket, s3Key, inputStream, metadata);

            LOG.info("JSON file uploaded to s3://{}/{}", s3Bucket, s3Key);
        } catch (Exception e) {
            LOG.error("S3 upload failed", e);
        }
    }
}